// ---------------------------------------------------------------------------
// tool_faq.dart — "ye tool kya karta hai?" ka ek hi sach (1.5.97).
//
// 1.5.97 (user decision): tiles par chhoti description hat gayi — grid ab
// barabar (icon + naam) hai. Har tool ka brief + uski asli details yahan
// FAQ me hai, dono sections ke liye.
//
// FAQ text code se match karta hai (thresholds, formulas, limits). Number
// badle to yahan bhi badalna hai — `test/features/help/tool_faq_test.dart`
// pin karta hai ki har live tool ka FAQ entry maujood hai.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';

/// Ek tool ka FAQ entry.
class ToolFaq {
  const ToolFaq({
    required this.title,
    required this.icon,
    required this.summary,
    required this.points,
  });

  /// Tile ka naam — hub ke tool se bilkul same.
  final String title;
  final IconData icon;

  /// Do line ka brief (kya hai / kiske liye).
  final String summary;

  /// Details — kaise kaam karta hai, kya chahiye, kya nahi hota.
  final List<String> points;
}

// ---------------------------------------------------------------------------
// EQUITY
// ---------------------------------------------------------------------------

const List<ToolFaq> kEquityFaq = [
  ToolFaq(
    title: 'IPO Screener',
    icon: Icons.new_releases_rounded,
    summary:
        'Naye listed stocks ko listing-day high/low ke aas-paas dhoondhta hai. '
        'Un stocks ke liye jinke listing ke baad abhi base bana ho.',
    points: [
      'IPO master app ke saath aata hai — mainboard IPOs (2015 se) ka symbol '
          'aur listing date, isliye pehle din se hi list taiyaar hai.',
      'Listing-day high/low broker ke daily candles se nikalta hai (Angel One '
          'SmartAPI) — koi third-party site nahi.',
      'Har row batati hai: LTP, listing-day high/low, aur usse kitna % door.',
      'Filter se sirf wo stocks rakhein jo high ya low ke ek chhote % (default '
          '5%) ke andar hain.',
      'Naya listing aa jaye to master apne aap refresh hota hai (listing dates '
          'NSE ke official master se cross-check hote hain).',
      'Data kahan se aaya — har level ke saath source note rehta hai, guess '
          'nahi kiya jaata.',
    ],
  ),
  ToolFaq(
    title: 'Golden Cross',
    icon: Icons.timeline_rounded,
    summary:
        '50-day aur 200-day moving average ka cross — golden cross (upar) aur '
        'death cross (neeche), poore NSE universe par.',
    points: [
      'SMA 50 jab SMA 200 ko upar se kaatte hai = Golden Cross; neeche se = '
          'Death Cross.',
      'Ek scan me dono directions milte hain — direction switch karne par '
          'dobara download nahi hota.',
      'Har signal ke saath: cross kitne din pehle hua, price, SMA 50/200 aur '
          'unke beech ka gap.',
      '250+ trading din (~205 bars) ka history chahiye — kam data wale stocks '
          '"skipped" list me reason ke saath aate hain (chupaya nahi jaata).',
      'Candles ka cache RSI Scanner ke saath share hota hai: jo scan pehle '
          'chalega, doosre ko lagbhag free kar dega.',
      'Tab khulte hi (6 PM ke baad) din ka auto-scan chalta hai — API quota '
          'bina zaroorat kharch nahi hota.',
    ],
  ),
  ToolFaq(
    title: 'RSI Scanner',
    icon: Icons.speed_rounded,
    summary:
        'Wilder RSI se overbought aur oversold stocks — ek hi scan me dono '
        'taraf, levels apne hisaab se set kar sakte hain.',
    points: [
      'Default: period 14, overbought 67 se upar, oversold 33 se neeche '
          '(edit karke 9/21 jaisa fast/slow bhi chala sakte hain).',
      'Ek pass me dono tables bharte hain — "upar" aur "neeche" ke beech '
          'switch karne par naya scan nahi chalta.',
      'Fresh cross (level abhi-abhi toda) alag se mark hota hai — sirf '
          '"abhi overbought hai" se alag baat hai.',
      'RSI(14) ke liye kam se kam 205 daily bars chahiye; kam ho to row skip '
          'hoke reason dikhta hai.',
      'Scan progressive hai — rows aate hi dikhte hain, beech me rok bhi '
          'sakte hain (jo ho gaya wo cache me rehta hai).',
      'Broker limit 3 requests/second hai, isliye scan me time lagta hai — '
          'calls 3-ke-batch me jaati hain par rate limit kabhi nahi tootta.',
    ],
  ),
  ToolFaq(
    title: 'Magic Formula',
    icon: Icons.functions_rounded,
    summary:
        'Greenblatt style screener: achhi company (high ROCE) jo sasti ho '
        '(high earnings yield) — dono ek table me.',
    points: [
      'ROCE = EBIT ÷ (Total Assets − Current Liabilities).',
      'Earnings Yield = EBIT ÷ EV, jahan EV = Market Cap + Total Debt − Cash.',
      'Data NSE filings se aata hai; jo value filing me nahi mili wo "—" '
          'rehti hai — anumaan nahi lagaya jaata.',
      'Sector aur market-cap filters se shortlist banayein; baskets me apni '
          'pasand ke stocks save kar sakte hain.',
      'F&O Scanner (isi module ka doosra part) top gainers/losers, OI change, '
          'narrow CPR aur volume ×2 par trade plan deta hai.',
    ],
  ),
  ToolFaq(
    title: 'Paper Trading',
    icon: Icons.account_balance_wallet_rounded,
    summary:
        'Asli prices par nakli trading — practice ke liye, real paisa ya real '
        'order bilkul nahi.',
    points: [
      'Buy/sell, quantity, SL/target — sab kuch app ke andar simulate hota '
          'hai; broker ko koi order nahi jaata.',
      'Charges asli hisaab se lagte hain (brokerage, STT, exchange, GST, '
          'stamp) taaki P&L sach jaisa lage.',
      'Live LTP WebSocket feed se aata hai; feed toot jaye to app saaf batata '
          'hai ki price purani hai.',
      'Groups (tags) se alag-alag strategies ke trades alag rakhein — Reports '
          'me group-wise P&L milta hai.',
    ],
  ),
  ToolFaq(
    title: 'Reports',
    icon: Icons.bar_chart_rounded,
    summary: 'Paper trading ka pura hisaab: P&L, win rate, ledger aur exports.',
    points: [
      'Date range (aaj / 1 mahina / custom) aur group se filter hota hai.',
      'Ledger me har trade: entry, exit, charges, net P&L — naye se purane.',
      'Khali range par win rate "—" dikhta hai, 0% nahi (galat impression na '
          'bane).',
      'Excel, CSV aur PDF export — file phone me save hoti hai, share bhi kar '
          'sakte hain.',
    ],
  ),
  ToolFaq(
    title: 'Settings',
    icon: Icons.tune_rounded,
    summary: 'Broker login, theme, notifications aur data refresh — sab yahan.',
    points: [
      'Angel One SmartAPI login (client ID, PIN, TOTP) — session device ke '
          'secure storage me rehta hai.',
      'Theme: light / dark / system; dark mode me logo white plate par aata '
          'hai.',
      'Scrip master aur IPO master ka manual refresh (naye listings ke liye) '
          'aur cache clear karne ke options.',
      'App version aur data-source note — kuch bhi chhupaya nahi jaata.',
    ],
  ),
];

// ---------------------------------------------------------------------------
// F&O
// ---------------------------------------------------------------------------

const List<ToolFaq> kFnoFaq = [
  ToolFaq(
    title: '3-Month Study',
    icon: Icons.query_stats_rounded,
    summary:
        'F&O stocks ka 3 mahine ka study: trend, volatility, high/low se doori, '
        'ATM option ka price aur IV — ek table me.',
    points: [
      'Har stock ke liye: trend (SMA 20/50 se upar-neeche), ATR%, 3M high/low '
          'se kitna % door, ATM IV.',
      'ATM jodi (CE + PE) ka price broker ke option quotes se aata hai; OTM '
          'jodi (~half strike door) bhi saath dikhti hai.',
      'Day-over-day edge = ATR% − IV/√252 — matlab option me kitni "asli" '
          'harkat chhupi hai.',
      'Expiry dropdown se chuni hui expiry par sab calculation hoti hai.',
      'Skips (kam candles, suspended, quote na milna) reason ke saath — '
          'chupaya nahi jaata.',
      'Scan ke baad Excel/CSV/PDF export aur "table copy" dono milte hain.',
    ],
  ),
  ToolFaq(
    title: '3-Month Study · Advance Filter',
    icon: Icons.filter_alt_rounded,
    summary:
        'Wahi study, par 12-point score ke saath — Best Buy / Watch jaise '
        'saaf labels aur advance filters.',
    points: [
      'Wahi candles aur wahi option book use hoti hai — do baar scan nahi '
          'karna padta.',
      'Score trend, momentum, volatility aur option pricing ko mila kar banta '
          'hai; Best Buy / Watch label uska seedha matlab hai.',
      'Filters se sirf apne criteria wale stocks rakhein (score, IV, ATR%, '
          'high/low se doori).',
      'Score ka backtest bhi hai — historical data par score kab chala, kab '
          'nahi, ye dekh sakte hain.',
    ],
  ),
  ToolFaq(
    title: 'Bankex–Bank Nifty Strategies',
    icon: Icons.account_balance_rounded,
    summary:
        'Bank Nifty + Bankex par market regime detect karke 6 defined-risk '
        'option strategies suggest karta hai.',
    points: [
      'Regime detection: trend, IV level aur skew dekh kar batata hai ki '
          'market kis tarah ka hai (trending / range-bound / high-vol).',
      '6 strategies: Cross-Expiry Calendar, Long Straddle/Strangle, Short '
          'Strangle + Cross-Index Hedge, Diagonal Ratio Backspread, Iron '
          'Butterfly, Delta-Neutral Pair (Bankex vs BN).',
      'Har strategy ke saath legs, strikes, premium aur max profit/loss '
          'defined hota hai — lots apne hisaab se set karein.',
      '🔧 Data Sync card se Bankex + BN contracts taiyaar hote hain; adhoora '
          'data ho to screen saaf batati hai.',
      'Sirf suggestion hai — koi order app place nahi karta.',
    ],
  ),
  ToolFaq(
    title: 'Index OI Build–Unwind',
    icon: Icons.trending_up_rounded,
    summary:
        'NSE aur BSE dono ke saare index options ka OI build-up / unwind — '
        'saari expiries, 2030/2031 wali long-dated tak.',
    points: [
      'Index dropdown: NIFTY, BANKNIFTY, FINNIFTY, MIDCPNIFTY, NIFTYNXT50, '
          'NIFTYFPI (NSE) · SENSEX, BANKEX, FOCIT (BSE). Jo index us din ki '
          'official file me hai, wahi list me aata hai.',
      'Expiry dropdown me **saari** expiries hoti hain — aaj NIFTY ki 18 '
          '(weekly se 2031-06 tak). Har line par "kitne din door" likha hota hai.',
      '"Saari expiries — ek nazar me" card: har expiry ka net ΔOI, builds/'
          'unwinds. Line par tap karo → wahi expiry select, uske strikes ka OI.',
      'Rules stock wale hi hain (price × OI): long build-up, short build-up, '
          'short covering, long unwinding, flat.',
      'Default filter bhi same — Balanced: OI ≥ 5,000 aur |ΔOI%| ≥ 10. '
          'Long-dated expiries me OI patla hota hai, "All" se dekh sakte hain.',
      'Data official NSE + BSE F&O bhavcopy (EOD). Live intraday OI nahi — '
          'broker quotes me OI field nahi aata. Ek exchange ki file na mile to '
          'screen saaf likhti hai.',
    ],
  ),
  ToolFaq(
    title: 'Stock OI Build–Unwind',
    icon: Icons.bar_chart_rounded,
    summary:
        'Aaj kis strike par badi OI bani (build-up) ya hat gayi (unwind) — '
        'stock options me position ka pata.',
    points: [
      'Stock options only; index options is table me nahi aate.',
      'Expiry dropdown se ek expiry chunte hain — usi ke strikes compare '
          'hote hain.',
      'Default "Balanced" filter: OI ≥ 5,000 aur ΔOI% ≥ 10% — bahut chhoti '
          'position shor nahi machaye.',
      'Build-up = OI badhi, unwind = OI ghati; dono ke saath price ka rukh '
          'bhi dikhta hai.',
    ],
  ),
  ToolFaq(
    title: 'IV Spike',
    icon: Icons.bolt_rounded,
    summary:
        'Jin F&O stocks ki aaj ki ATM IV kal ki IV se badh gayi ho — simple '
        'table: stock, kal ka IV, aaj ka IV, change, IVP, IVR.',
    points: [
      'Aaj ka IV: Angel ke option greeks se ATM CE+PE ka average. Broker IV na '
          'mile to asli premium se Black-Scholes — har row par source (Broker / '
          'BS) dikhta hai.',
      'Kal ka IV: Settings wali Google Sheet ke `iv` column se. Sheet me wo '
          'column na ho to app ke pichhle din ke apne snapshot se — aur row par '
          '"kal = apna snapshot" likha jaata hai. Dono na ho to "—" (guess nahi).',
      'IVP / IVR bhi usi sheet se (jaisa pehle se chalta hai). Sheet missing '
          'values ko kabhi bhar kar nahi dikhata.',
      'Scan 213 F&O stocks par chalta hai (3 requests/sec cap) — pehli baar '
          '~5–7 min, cache ke baad tez. Jo stock na mile, wo "data nahi" list '
          'me wajah ke saath aata hai.',
      'Apna snapshot roz banta hai — doosre din se kal ka IV apne data se bhi '
          'mil jaata hai (pichhla din, din ke hisaab se).',
    ],
  ),
  ToolFaq(
    title: 'IV Crush',
    icon: Icons.trending_down_rounded,
    summary:
        'Jin F&O stocks ki aaj ki ATM IV kal se sabse zyada giri — % change me, '
        'IVP/IVR ke saath. IV Spike ka ulta (girawat ki taraf).',
    points: [
      'Data wahi jo IV Spike me: aaj ka IV Angel greeks se (na mile to '
          'Black-Scholes), kal ka IV Sheet ke `iv` column se ya app ke pichhle '
          'snapshot se.',
      'Change **percentage** me: (aaj − kal) ÷ kal × 100. Neeche chhote akshar '
          'me percentage points (pp) bhi dikhte hain — dono saaf, ek doosre se '
          'alag.',
      'Sort: sabse tez girawat sabse upar (sabse bada negative %). Spike screen '
          'me ulta — sabse bada positive % upar.',
      'IV crush aksar results/event ke baad aata hai — option premium girta hai '
          'chahe stock side me na chale. Ye list wahi dikhati hai; koi trade '
          'suggestion nahi.',
      'Do list ek hi scan se banti hain — upar ke toggle se spike ↔ crush turant '
          'badal sakte hain (data dobara download nahi hota).',
    ],
  ),
  ToolFaq(
    title: '52W · ATH · Dividend',
    icon: Icons.show_chart_rounded,
    summary:
        'Kaun apne 52-hafte / all-time high-low ke paas hai, aur kis stock ka '
        'dividend aa raha hai.',
    points: [
      '52W tab: default sirf wo stocks jo high ya low ke 5% ke andar hain; '
          '"Sabhi stocks" chip se poora scanned universe.',
      'All-Time tab: wahi 5% niyam ATH/ATL par — ATH Angel ki chunked history '
          '(15 saal tak) se aata hai, Yahoo se nahi.',
      'Dividend tab: sirf aane wale dividends — stock · ₹/share · price · '
          'price ka % · ex-date.',
      'Jo stock scan nahi hua uske liye "price ka %" "—" rehta hai — guess '
          'nahi.',
      'Scan 5 din se purana ho to screen "stale" batati hai.',
    ],
  ),
  ToolFaq(
    title: 'Results Calendar',
    icon: Icons.event_rounded,
    summary:
        'F&O universe ke results aur board meetings — kis stock ka result kab '
        'hai.',
    points: [
      'NSE ke announcement/board-meeting endpoints se dates aati hain.',
      'Aane wale results pehle; date announce nahi hui ho to "TBA" jaisa saaf '
          'status.',
      'Result ke din options me IV aksar zyada hota hai — study ke IV column '
          'ke saath padhein.',
    ],
  ),
  ToolFaq(
    title: 'AI Suggestion',
    icon: Icons.auto_awesome_rounded,
    summary:
        'Rule-based idea + entry/exit levels — koi "magic AI" nahi, saaf niyam.',
    points: [
      'Sirf rule-engine chalta hai (koi LLM ya internet prediction nahi).',
      'Har suggestion ke saath reason aur entry/SL/target levels hote hain, '
          'taaki aap khud jaanch sakein.',
      'Data study wale hi candles/options se aata hai — do jagah alag number '
          'nahi.',
      'Export (Excel/CSV/PDF) aur share available hai.',
    ],
  ),
  ToolFaq(
    title: 'News',
    icon: Icons.article_rounded,
    summary:
        'NSE announcements aur market feeds — jo news price hila sakti hai, ek '
        'jagah.',
    points: [
      'NSE ki official RSS/announcements, F&O ban list (fo_secban), Google '
          'News RSS aur Telegram channels se headlines.',
      'Headline ke saath source aur time — sirf jis source se aaya, wahi '
          'likha jaata hai.',
      'Koi summary "bana kar" nahi likhi jaati; feed ka text jaisa hai waisa '
          'dikhta hai.',
    ],
  ),
  ToolFaq(
    title: 'F&O Scanner',
    icon: Icons.radar_rounded,
    summary:
        'Din ke paanch F&O lists — top gainers, top losers, OI change, narrow '
        'CPR, volume ×2 — aur unke common stocks ka trade plan.',
    points: [
      'Official NSE EOD bhavcopy (CM + FO) se banta hai; as-of trade date '
          'screen par likhi hoti hai. Market hours me har 5 min live overlay '
          '(Angel quotes) chalta hai.',
      'Har list ki top-10 dikhti hai; jo stock do ya zyada lists me aata hai '
          'wo Shortlist me aata hai — score 0–100 (kitni lists + kitna strong).',
      'Har pick ke saath plan: stock (Entry/SL/Target, 1×ATR SL · 2×ATR '
          'target) aur options (ATM CE/PE, strike, lot, asli premium, '
          'premium ×0.5/×1.5).',
      'Numbers mechanical rules hain — guarantee nahi, suggestion bhi nahi. '
          'Trading se pehle khud verify karein.',
    ],
  ),
];

// ---------------------------------------------------------------------------
// BUILDER (1.5.102) — apni strategy banao aur backtest karo.
// ---------------------------------------------------------------------------

const List<ToolFaq> kBuilderFaq = [
  ToolFaq(
    title: 'Strategy Builder',
    icon: Icons.rule_rounded,
    summary:
        'Apni strategy banao — indicator chuno, entry/exit rules lagao, aur '
        'poore universe par backtest karke report dekho (win rate, equity '
        'curve, har trade).',
    points: [
      '10 indicator: SMA, EMA, RSI (Wilder), MACD, Bollinger, ATR, ADX, '
          'Stochastic, Volume SMA, 52-week range — har ek ke apne params, '
          'aur doosre indicator se compare ka option.',
      'Universe: All NSE / Nifty 100 / F&O 213 — daily candles official Angel '
          'One EOD se, SQLite cache me (dobara run sasta).',
      'Entry signal us din ke close par maana jaata hai, exit agle din se — '
          'koi look-ahead nahi. Stop/target intraday low/high par trigger, gap '
          'par open par fill.',
      'Timeframe: Daily (5 saal), 15 min aur 5 min. Intraday bars broker se '
          'sirf ~100 din ka milta hai — report par ye baat warning ke saath '
          'likhi jaati hai, isliye intraday ko daily jitna bharosemand na maane.',
      'Fundamentals filter: market cap, ROCE, debt/equity, earnings yield — '
          'NSE/BSE filings se (Magic Formula wala hi official source). Poora '
          'data app ke paas hai; P/E ka option jaan-boojh kar nahi hai (PAT data '
          'nahi). Ye **aaj ke** numbers poore backtest window par lagte hain — '
          'report par saaf likha hota hai.',
      'Cost default 0.35% (brokerage + STT + slippage) har trade se katta hai; '
          '0% par report khud likhta hai "cost include nahi".',
      'Index: 10 index (Nifty 50, Bank Nifty, Fin Nifty, Midcap Select, Nifty '
          '500/100, IT, Auto, Pharma, Metal) — Angel ke AMXIDX tokens par wahi '
          'daily candles. Broker data na mile to Yahoo fallback **label ke saath**; '
          'dono na mile to "index data available nahi" — number banaya nahi jaata.',
      'Report: trades, win %, avg trade, profit factor, max drawdown + daily '
          'drawdown strip, 10-slot equity curve (buy & hold, aur stocks par '
          'Nifty 50 ke saath), saal × mahina monthly heatmap, 70/30 '
          'out-of-sample check, trades table, aur skipped stocks ki wajah. 30 se '
          'kam trades par warning aati hai.',
      'Export: Excel (.xlsx — Report/Trades/Skipped sheet), CSV, WhatsApp text '
          'recap, aur Telegram bot (Settings me bot token + chat id). Strategy '
          'file (.tradeedge) WhatsApp/Telegram se bhejiye — doosre phone par '
          '"Import" se khul jaati hai.',
      'Historic candles par hisaab — survivorship bias possible hai (jo stock '
          'aaj list me hai wahi test hota hai). Guarantee nahi.',
    ],
  ),
];

// ---------------------------------------------------------------------------
// EXTRA (1.5.101) — Telegram, alerts, data sources, about.
// User: "Telegram channel wala option equity aur fno jaise ek alag section
// bana do, jisme aisi extra cheezein set kar sake."
// ---------------------------------------------------------------------------

const List<ToolFaq> kExtraFaq = [
  ToolFaq(
    title: 'Telegram Channels',
    icon: Icons.cell_tower_rounded,
    summary:
        'Public Telegram channels ke buy/sell calls — capture, paper par '
        'track (SL/target), aur scoreboard.',
    points: [
      'Channels tab me public channel ka link add karo (jaise '
          't.me/apnachannel) — jitne chahe. Sirf public web page padha jaata '
          'hai, koi Telegram login/API key nahi chahiye.',
      'Calls tab: message parse hoke Buy/Sell draft banti hai; entry, SL aur '
          'target ke saath paper position ki tarah track hoti hai.',
      'Scoreboard tab: kaun sa channel kitna sahi nikla — hit/miss, R '
          'multiple. Purana data delete nahi hota.',
      'Ye tips nahi hain: jo channel likhta hai wahi dikhta hai, uski quality '
          'ka app guarantee nahi deta.',
    ],
  ),
  ToolFaq(
    title: 'Telegram Bot Export',
    icon: Icons.send_rounded,
    summary:
        'Apna Telegram bot token + chat id daal kar study/scan ki file seedha '
        'apne chat me bhejo.',
    points: [
      '@BotFather se bot banao, token yahan paste karo, phir us bot ko ek '
          'baar /start bhejo. Chat id @userinfobot se (group me -100… hota '
          'hai).',
      'Bhar diya to 3-Month Study / Study Advance ke export menu me '
          '"Telegram pe bhejo" dikhega — XLSX/CSV file seedha chat me jaati '
          'hai.',
      'Khaali chhodo to kuch nahi bhejta — file sirf phone par rehti hai. '
          'Token sirf device ki settings table me save hota hai.',
      'Wahi setting Settings → F&O card me bhi milti hai (ek hi value, do '
          'rastas).',
    ],
  ),
  ToolFaq(
    title: 'Alerts & Notifications',
    icon: Icons.notifications_active_rounded,
    summary:
        'Ek jagah saare alerts — calls SL/target, price alerts aur screener '
        'signals ki history.',
    points: [
      'Alerts tab: kya kab hua (calls SL/target hit, study/scanner signal) — '
          'padhne par unread badge zero.',
      'Prices tab: apne price alerts add/remove (one-shot — ek baar fire hone '
          'par hat jaata hai).',
      'Phone notification + notification center, dono ek hi event se aate '
          'hain; market band ho to naye price alerts fire nahi hote.',
      'Sab alerts hataao se sirf history saaf hoti hai — price alerts jaise '
          'ke waise rehte hain.',
    ],
  ),
  ToolFaq(
    title: 'Morning Brief',
    icon: Icons.wb_sunny_rounded,
    summary:
        'Trading day ki subah Top 20 list — 3-Month Study ke mechanical rank '
        'se.',
    points: [
      '8:30 AM (IST) par trading days me automatic banti hai; app band raha '
          'ho to khulte hi ban jaati hai.',
      'Ranking 3-Month Study ka rank hai — koi alag "opinion" nahi.',
      'Notification tap se ya EXTRA → Morning Brief se khulti hai.',
      'Pehla brief banne se pehle screen khud bata deti hai ki abhi data '
          'nahi hai (khaali list nahi dikhati).',
    ],
  ),
  ToolFaq(
    title: 'Data Sources',
    icon: Icons.cloud_sync_rounded,
    summary:
        'Kaunsa number kahan se aata hai — official pehle, fallback label ke '
        'saath.',
    points: [
      'Angel One SmartAPI: login, scrip master, candles, quotes, option '
          'greeks — primary source.',
      'NSE bhavcopy/archives: EOD spot + F&O, index lists, announcements, '
          'results/dividend calendar.',
      'NSE RSS, F&O ban list (fo_secban) aur public Telegram (t.me/s/) — news '
          'aur calls.',
      'Yahoo Finance sirf fallback hai (jab official se value na mile) aur '
          'screen par "Yahoo" likha hota hai. Jo value kisi source se nahi '
          'mili wo "—" rehti hai — guess nahi hoti.',
    ],
  ),
  ToolFaq(
    title: 'About & Help',
    icon: Icons.info_outline_rounded,
    summary: 'App version, disclaimer aur har tool ka brief — ek jagah.',
    points: [
      'TRADE EDGE Angel One SmartAPI par bana hai, par Angel One ka product '
          'nahi.',
      'Har order paper trading hai — order place karne ki line hi nahi hai, '
          'isliye asli order broker ko jaana possible nahi.',
      'Koi tip/suggestion nahi: jo aata hai wo official data + mechanical '
          'rules se aata hai.',
      'Formula kabhi badalte nahi: ROCE = EBIT ÷ (Total Assets − Current '
          'Liabilities), EY = EBIT ÷ EV, EV = Market Cap + Total Debt − Cash.',
    ],
  ),
];

/// Dono sections ka poora FAQ (help/settings se ek hi list me dekhne ke liye). (help/settings se ek hi list me dekhne ke liye).
const List<ToolFaq> kAllFaq = [
  ...kEquityFaq,
  ...kFnoFaq,
  ...kBuilderFaq,
  ...kExtraFaq,
];
