// ---------------------------------------------------------------------------
// index_oi_service.dart — 1.5.108: NSE + BSE ki official F&O bhavcopy.
//
// Do files, dono exchange-official:
//   • NSE → `nsearchives.nseindia.com/content/fo/BhavCopy_NSE_FO_…csv.zip`
//     (wahi file jo F&O Scanner / Stock OI use karte hain). Index options
//     `IDO` rows: NIFTY, BANKNIFTY, FINNIFTY, MIDCPNIFTY, NIFTYNXT50, NIFTYFPI.
//   • BSE → `www.bseindia.com/download/BhavCopy/Derivative/`
//     `BhavCopy_BSE_FO_0_0_0_YYYYMMDD_F_0000.CSV.zip` (raw CSV bhi chalta hai).
//     `IDO` rows: SENSEX, BANKEX, FOCIT.
//
// BSE Akamai ke peeche hai: **poora Chrome header set chahiye** (Origin,
// Sec-Fetch-*, sec-ch-ua, X-Requested-With) warna 403. Sahi headers ke saath
// file `Content-Encoding: gzip` me aati hai — isliye `HttpClient` se seedha
// bytes lete hain (package:http auto-decompress wahan karta hai jahan header
// set karna possible nahi hota).
//
// File na mile (holiday / abhi publish nahi hui) to ek-ek din peeche walk
// karta hai — dono exchange alag-alag, isliye ek fail ho to doosra chalta hai.
// Dono ke din alag ho sakte hain (BSE kabhi ek din pehle band karta hai) —
// UI par dono date alag likhi jaati hain, ek meel me nahi.
//
// Cache: parsed book memory me (date-key wise) — underlying/expiry badalne par
// dobara download nahi.
// ---------------------------------------------------------------------------

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:archive/archive.dart';

import '../../../core/utils/markets.dart';
import '../../../services/magic_formula_data_source.dart' show NseMagicFormulaHttp;
import 'index_oi_engine.dart';

class IndexOiFetchException implements Exception {
  const IndexOiFetchException(this.message);
  final String message;
  @override
  String toString() => message;
}

enum IndexOiExchange {
  nse('NSE'),
  bse('BSE');

  const IndexOiExchange(this.label);
  final String label;
}

class IndexOiService {
  IndexOiService({
    Future<List<int>> Function(Uri uri)? fetchNse,
    Future<List<int>> Function(Uri uri)? fetchBse,
    DateTime Function()? clock,
  }) : _fetchNse = fetchNse ?? _defaultNse,
       _fetchBse = fetchBse ?? _defaultBse,
       _clock = clock ?? MarketCalendar.nowIst;

  final Future<List<int>> Function(Uri uri) _fetchNse;
  final Future<List<int>> Function(Uri uri) _fetchBse;
  final DateTime Function() _clock;

  /// date-key → (nse parse, bse parse) — ek hi din dobara parse nahi hota.
  final Map<String, IndexOiParse?> _nseCache = {};
  final Map<String, IndexOiParse?> _bseCache = {};

  /// NSE: wahi archives host jo baaki app use karti hai.
  static Uri nseUrl(DateTime date) => Uri.https(
    'nsearchives.nseindia.com',
    '/content/fo/BhavCopy_NSE_FO_0_0_0_'
    '${date.year}${date.month.toString().padLeft(2, '0')}'
    '${date.day.toString().padLeft(2, '0')}_F_0000.csv.zip',
  );

  /// BSE: official download path (2024 ke UDiFF naming ke saath).
  static Uri bseUrl(DateTime date) => Uri.https(
    'www.bseindia.com',
    '/download/BhavCopy/Derivative/'
    'BhavCopy_BSE_FO_0_0_0_'
    '${date.year}${date.month.toString().padLeft(2, '0')}'
    '${date.day.toString().padLeft(2, '0')}_F_0000.CSV.zip',
  );

  /// Dono exchange ek saath load. Ek fail ho to doosra phir bhi aata hai.
  Future<({IndexOiBook book, DateTime? tradeDate})> load({
    DateTime? onOrBefore,
    int maxWalkBack = 10,
    bool force = false,
    void Function(String stage)? onProgress,
    bool includeNse = true,
    bool includeBse = true,
  }) async {
    final start = onOrBefore ?? _clock();

    final futures = <Future<_Loaded?>>[
      if (includeNse)
        _walk(
          IndexOiExchange.nse,
          start,
          maxWalkBack,
          force,
          onProgress,
        ),
      if (includeBse)
        _walk(
          IndexOiExchange.bse,
          start,
          maxWalkBack,
          force,
          onProgress,
        ),
    ];
    final results = await Future.wait(futures);

    _Loaded? nse;
    _Loaded? bse;
    for (final r in results) {
      if (r == null) continue;
      if (r.exchange == IndexOiExchange.nse) {
        nse = r;
      } else {
        bse = r;
      }
    }

    final book = mergeIndexOi(
      nse: nse?.parse,
      bse: bse?.parse,
      nseDate: nse?.date,
      bseDate: bse?.date,
    );
    if (book.rowCount == 0) {
      throw IndexOiFetchException(
        'Index option ka data nahi mila ($maxWalkBack din tak, NSE + BSE '
        'dono) — ${book.notes.join(' · ')}',
      );
    }
    return (book: book, tradeDate: book.tradeDate);
  }

  Future<_Loaded?> _walk(
    IndexOiExchange exchange,
    DateTime start,
    int maxWalkBack,
    bool force,
    void Function(String stage)? onProgress,
  ) async {
    final cache = exchange == IndexOiExchange.nse ? _nseCache : _bseCache;
    for (var offset = 0; offset < maxWalkBack; offset++) {
      final date = DateTime(
        start.year,
        start.month,
        start.day,
      ).subtract(Duration(days: offset));
      final key = _key(date);
      if (cache.containsKey(key) && !force) {
        final hit = cache[key];
        if (hit != null && hit.rowCount > 0) {
          return _Loaded(exchange: exchange, date: date, parse: hit);
        }
        continue; // parsed lekin khaali — agla din
      }
      onProgress?.call(
        '${exchange.label} F&O bhavcopy — ${date.day.toString().padLeft(2, '0')}/'
        '${date.month.toString().padLeft(2, '0')}/${date.year}…',
      );
      try {
        final uri = exchange == IndexOiExchange.nse
            ? nseUrl(date)
            : bseUrl(date);
        final bytes = exchange == IndexOiExchange.nse
            ? await _fetchNse(uri)
            : await _fetchBse(uri);
        final csv = _toCsv(bytes);
        final parsed = parseIndexOptionOi(
          csv,
          date,
          source: exchange.label,
        );
        cache[key] = parsed;
        if (parsed.rowCount > 0) {
          return _Loaded(exchange: exchange, date: date, parse: parsed);
        }
      } catch (_) {
        cache[key] = null;
      }
    }
    return null;
  }

  /// ZIP ya seedha CSV — dono chalte hain (BSE kabhi plain CSV deta hai).
  String _toCsv(List<int> bytes) {
    if (bytes.length >= 2 && bytes[0] == 0x50 && bytes[1] == 0x4b) {
      final archive = ZipDecoder().decodeBytes(bytes);
      for (final file in archive) {
        if (file.isFile && file.name.toLowerCase().endsWith('.csv')) {
          return utf8.decode(file.content as List<int>, allowMalformed: true);
        }
      }
      throw const IndexOiFetchException('ZIP me CSV nahi mili');
    }
    // Gzip (0x1f 0x8b) — BSE kabhi compressed bhejta hai.
    var raw = bytes;
    if (bytes.length >= 2 && bytes[0] == 0x1f && bytes[1] == 0x8b) {
      raw = gzip.decode(bytes);
    }
    return utf8.decode(raw, allowMalformed: true);
  }

  static String _key(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-'
      '${d.day.toString().padLeft(2, '0')}';

  void clearCache() {
    _nseCache.clear();
    _bseCache.clear();
  }

  // ------------------------------------------------------------------ network

  static Future<List<int>> _defaultNse(Uri uri) async {
    final http = NseMagicFormulaHttp();
    try {
      return await http.getBytes(uri, refererPath: '/all-reports');
    } finally {
      http.close();
    }
  }

  /// BSE — poora Chrome header set (measured against the live site; headers
  /// ke bina 403). `HttpClient` isliye ki gzip body khud decode karni padti hai.
  static Future<List<int>> _defaultBse(Uri uri) async {
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 20)
      ..autoUncompress = false;
    try {
      final request = await client.getUrl(uri);
      const headers = {
        'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
            '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
        'Accept': 'application/json, text/plain, application/xml, */*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Origin': 'https://www.bseindia.com',
        'Referer': 'https://www.bseindia.com/',
        'Sec-Fetch-Site': 'same-site',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'sec-ch-ua': '"Chromium";v="126", "Not)A;Brand";v="24"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'X-Requested-With': 'XMLHttpRequest',
        'Accept-Encoding': 'gzip, deflate',
      };
      headers.forEach(request.headers.set);
      final response = await request.close().timeout(
        const Duration(seconds: 45),
      );
      final builder = BytesBuilder(copy: false);
      await for (final chunk in response) {
        builder.add(chunk);
      }
      if (response.statusCode >= 400) {
        throw IndexOiFetchException(
          'BSE ${response.statusCode} — ${uri.path}',
        );
      }
      return builder.takeBytes();
    } finally {
      client.close(force: true);
    }
  }
}

class _Loaded {
  const _Loaded({
    required this.exchange,
    required this.date,
    required this.parse,
  });

  final IndexOiExchange exchange;
  final DateTime date;
  final IndexOiParse parse;
}
