// ---------------------------------------------------------------------------
// index_oi_screen.dart — 1.5.108 "F&O Index OI Build–Unwind".
//
// Stock OI (1.5.86) jaisa hi, par **index** ke liye aur **NSE + BSE dono**:
//   • index dropdown  — NIFTY, BANKNIFTY, FINNIFTY, MIDCPNIFTY, NIFTYNXT50,
//     NIFTYFPI (NSE) · SENSEX, BANKEX, FOCIT (BSE) — jo file me hai wahi.
//   • expiry dropdown — **saari** expiries, 2030/2031 tak (aaj 18 NIFTY).
//     "18 of 18" type count + "kitne din door" dikhta hai.
//   • expiry summary card — har expiry ki ek line (net ΔOI, builds/unwinds);
//     tap karo to wahi expiry select ho jaati hai.
//   • select hone par: top build-ups, top unwinds, aur poora CE/PE strike
//     chain (OI + ΔOI qty + ΔOI % + signal).
//
// Filter/sort/limits **stock wale hi** (Balanced: OI≥5000 · ΔOI%≥10).
// Data official EOD bhavcopy — koi live OI jhooth nahi, koi number guess nahi.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../core/layout/desktop_layout.dart';
import '../../../core/utils/share_helper.dart';
import '../../../core/widgets/ui.dart';
import 'index_oi_engine.dart';
import 'index_oi_service.dart';

class IndexOiScreen extends StatefulWidget {
  const IndexOiScreen({super.key, this.service});

  /// Test seam — production me `null` (asli NSE + BSE fetchers).
  final IndexOiService? service;

  @override
  State<IndexOiScreen> createState() => _IndexOiScreenState();
}

class _IndexOiScreenState extends State<IndexOiScreen> {
  late final IndexOiService _service = widget.service ?? IndexOiService();

  IndexOiBook? _book;
  DateTime? _tradeDate;
  String? _error;
  String? _progress;
  bool _loading = true;

  String? _underlying;
  DateTime? _expiry;
  IndexOiFilter _filter = IndexOiFilter.balanced;
  IndexOiSort _sort = IndexOiSort.byQty;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load({bool force = false}) async {
    setState(() {
      _loading = true;
      _error = null;
      _progress = 'NSE + BSE F&O bhavcopy…';
    });
    try {
      final res = await _service.load(
        force: force,
        onProgress: (p) {
          if (!mounted) return;
          setState(() => _progress = p);
        },
      );
      if (!mounted) return;
      final names = res.book.orderedUnderlyings;
      setState(() {
        _book = res.book;
        _tradeDate = res.tradeDate;
        _loading = false;
        _progress = null;
        _underlying ??= names.isEmpty ? null : _defaultUnderlying(names);
      });
      _ensureExpiry();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _progress = null;
        _error = '$e';
      });
    }
  }

  /// Default: NIFTY agar hai, warna BSE ka SENSEX, warna pehla.
  String _defaultUnderlying(List<String> names) {
    for (final preferred in ['NIFTY', 'SENSEX']) {
      if (names.contains(preferred)) return preferred;
    }
    return names.first;
  }

  void _ensureExpiry() {
    final snap = _snapshot;
    if (snap == null) return;
    final expiries = snap.expiries;
    if (expiries.isEmpty) return;
    final current = _expiry;
    final valid = current != null && expiries.any((e) => _sameDay(e, current));
    if (!valid) {
      // Default = sabse nayi (front) expiry, jo aaj se pehle nahi hai.
      final today = _tradeDate ?? DateTime.now();
      final upcoming = expiries.where((e) => !e.isBefore(today)).toList();
      setState(() {
        _expiry = upcoming.isNotEmpty ? upcoming.first : expiries.first;
      });
    }
  }

  IndexOiSnapshot? get _snapshot => _book?[_underlying];

  static bool _sameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final wide = DesktopLayout.isWide(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          '📈 Index OI Build–Unwind',
          style: TextStyle(fontSize: 15),
        ),
        actions: [
          IconButton(
            tooltip: 'NSE + BSE bhavcopy refresh (dobara download)',
            icon: const Icon(Icons.refresh_rounded),
            onPressed: _loading ? null : () => _load(force: true),
          ),
          IconButton(
            tooltip: 'Report share',
            icon: const Icon(Icons.share_rounded),
            onPressed: _book == null ? null : () => _share(context),
          ),
        ],
      ),
      body: _loading
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const CircularProgressIndicator(),
                  const SizedBox(height: 12),
                  Text(
                    _progress ?? 'Load ho raha hai…',
                    style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant),
                  ),
                ],
              ),
            )
          : _error != null
          ? _errorBody(scheme)
          : wide
          ? Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(flex: 3, child: _body(scheme, twoColumn: true)),
              ],
            )
          : _body(scheme),
    );
  }

  Widget _errorBody(ColorScheme scheme) => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.cloud_off_rounded, size: 36, color: scheme.error),
          const SizedBox(height: 10),
          Text(
            _error!,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 12, height: 1.5),
          ),
          const SizedBox(height: 14),
          FilledButton.tonal(
            onPressed: () => _load(force: true),
            child: const Text('Dobara try karo'),
          ),
        ],
      ),
    ),
  );

  Widget _body(ColorScheme scheme, {bool twoColumn = false}) {
    final snap = _snapshot;
    final expiry = _expiry;
    if (snap == null || expiry == null) {
      return const Center(
        child: Text(
          'Koi index option data nahi mila.',
          style: TextStyle(fontSize: 12),
        ),
      );
    }
    final summary = snap.filteredSummary(expiry, _filter);
    final builds = snap.topBuilds(expiry: expiry, filter: _filter, sort: _sort);
    final unwinds = snap.topUnwinds(
      expiry: expiry,
      filter: _filter,
      sort: _sort,
    );
    final expiryRows = snap.expiryRows();

    final picker = Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(child: _underlyingPicker(scheme)),
                const SizedBox(width: 8),
                Expanded(child: _expiryPicker(scheme, snap)),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              '${snap.expiries.length} expiry file me hain · '
              'ye ${snap.forExpiry(expiry).length} rows · '
              '${snap.strikesFor(expiry).length} strikes',
              style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 4,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                const Text(
                  'Filter',
                  style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700),
                ),
                for (final f in IndexOiFilter.presets)
                  ChoiceChip(
                    label: Text(
                      f == IndexOiFilter.all
                          ? 'All'
                          : '${f.label} (OI≥${_k(f.minOi)} · ≥${f.minOiChangePct.round()}%)',
                      style: const TextStyle(fontSize: 10),
                    ),
                    selected: _filter == f,
                    onSelected: (_) => setState(() => _filter = f),
                  ),
              ],
            ),
            const SizedBox(height: 6),
            Wrap(
              spacing: 6,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                const Text(
                  'Sort',
                  style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700),
                ),
                for (final s in IndexOiSort.values)
                  ChoiceChip(
                    label: Text(
                      s.label,
                      style: const TextStyle(fontSize: 10),
                    ),
                    selected: _sort == s,
                    onSelected: (_) => setState(() => _sort = s),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                _stat(scheme, '🟢 Builds', '${summary.builds}', scheme.primary),
                _stat(scheme, '🟠 Unwinds', '${summary.unwinds}', scheme.error),
                _stat(
                  scheme,
                  'Net ΔOI',
                  _signed(summary.netOiChange),
                  summary.netOiChange >= 0 ? scheme.primary : scheme.error,
                ),
              ],
            ),
          ],
        ),
      ),
    );

    final cards = <Widget>[
      if (_book != null && _book!.notes.isNotEmpty)
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Text(
            _book!.notes.join(' · '),
            style: TextStyle(fontSize: 10, color: scheme.error, height: 1.4),
          ),
        ),
      _sourceBanner(scheme, snap),
      const SizedBox(height: 10),
      _legendCard(scheme),
      const SizedBox(height: 10),
      picker,
      const SizedBox(height: 10),
      _expirySummaryCard(scheme, expiryRows, snap),
      const SizedBox(height: 10),
      _movesCard(
        scheme,
        title: '🔨 Top build-ups',
        subtitle: 'Nayi positions bani (long ya short)',
        legs: builds,
        empty: 'Filter ke andar koi build-up nahi mila.',
      ),
      const SizedBox(height: 10),
      _movesCard(
        scheme,
        title: '🌀 Top unwinds',
        subtitle: 'Position windup / covering (OI ghata)',
        legs: unwinds,
        empty: 'Filter ke andar koi unwind nahi mila.',
      ),
      const SizedBox(height: 10),
      _chainCard(scheme, snap, expiry),
    ];

    if (twoColumn) {
      // Desktop: summary + moves ek taraf, chain doosri taraf — list scroll
      // (1.5.92 ka rule: poora page ek scroll).
      final chain = cards.removeLast();
      final left = cards.sublist(0, cards.length - 1);
      final right = cards.sublist(cards.length - 1);
      return ListView(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 26),
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                flex: 5,
                child: Column(children: [...left, chain]),
              ),
              const SizedBox(width: 12),
              Expanded(
                flex: 4,
                child: Column(children: right),
              ),
            ],
          ),
        ],
      );
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 26),
      children: cards,
    );
  }

  // ------------------------------------------------------------------ pieces

  Widget _sourceBanner(ColorScheme scheme, IndexOiSnapshot snap) {
    final nse = _book?.nseDate;
    final bse = _book?.bseDate;
    final parts = <String>[
      if (nse != null) 'NSE ${_d(nse)} (${_book?.nseRows ?? 0} rows)',
      if (bse != null) 'BSE ${_d(bse)} (${_book?.bseRows ?? 0} rows)',
    ];
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: scheme.primaryContainer,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        '🏛️ Official NSE + BSE F&O bhavcopy · ${parts.join(' · ')} · '
        'EOD data (market close ke baad). Live intraday OI nahi — broker '
        'quotes me OI field nahi aata.\n'
        '${snap.underlying} ${snap.source} ki file se.',
        style: const TextStyle(fontSize: 10.5, height: 1.45),
      ),
    );
  }

  Widget _legendCard(ColorScheme scheme) => InfoSection(
    emoji: '📐',
    title: 'Rules — price × OI',
    tooltip:
        'Stock OI wale hi rules: price direction + OI change se pata chalta '
        'hai nayi position bani ya purani band hui.',
    children: [
      for (final s in [
        IndexOiSignal.longBuildup,
        IndexOiSignal.shortBuildup,
        IndexOiSignal.shortCovering,
        IndexOiSignal.longUnwinding,
      ])
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 1.5),
          child: Text(
            '${s.emoji} ${s.label} — ${s.meaning}',
            style: const TextStyle(fontSize: 10.5, height: 1.4),
          ),
        ),
    ],
  );

  Widget _underlyingPicker(ColorScheme scheme) {
    final names = _book?.orderedUnderlyings ?? const <String>[];
    return DropdownButtonFormField<String>(
      key: const ValueKey('index-oi-underlying'),
      initialValue: _underlying,
      isExpanded: true,
      decoration: const InputDecoration(
        labelText: 'Index',
        isDense: true,
        border: OutlineInputBorder(),
      ),
      items: [
        for (final n in names)
          DropdownMenuItem(
            value: n,
            child: Text(
              '$n · ${_book?[n]?.source ?? ''}',
              style: const TextStyle(fontSize: 12),
            ),
          ),
      ],
      onChanged: (v) {
        if (v == null) return;
        setState(() {
          _underlying = v;
          _expiry = null;
        });
        _ensureExpiry();
      },
    );
  }

  Widget _expiryPicker(ColorScheme scheme, IndexOiSnapshot snap) {
    final expiries = snap.expiries;
    final asOf = _tradeDate ?? DateTime.now();
    return DropdownButtonFormField<DateTime>(
      key: const ValueKey('index-oi-expiry'),
      initialValue: _expiry,
      isExpanded: true,
      decoration: const InputDecoration(
        labelText: 'Expiry (sabhi)',
        isDense: true,
        border: OutlineInputBorder(),
      ),
      items: [
        for (final e in expiries)
          DropdownMenuItem(
            value: e,
            child: Text(
              '${DateFormat('dd MMM yyyy').format(e)}'
              ' · ${_daysLabel(e, asOf)}',
              style: const TextStyle(fontSize: 12),
            ),
          ),
      ],
      onChanged: (v) => setState(() => _expiry = v),
    );
  }

  Widget _stat(ColorScheme scheme, String label, String value, Color color) =>
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant),
            ),
            Text(
              value,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w900,
                color: color,
              ),
            ),
          ],
        ),
      );

  /// Har expiry ki ek line — tap karo to wahi expiry select.
  Widget _expirySummaryCard(
    ColorScheme scheme,
    List<IndexExpiryRow> rows,
    IndexOiSnapshot snap,
  ) {
    final asOf = _tradeDate ?? DateTime.now();
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '📅 Saari expiries — ek nazar me',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800),
            ),
            Text(
              'Har expiry ka aaj ka net ΔOI (OI qty me). Line par tap karo → '
              'wahi expiry select ho jaayegi.',
              style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                _hdr('Expiry', scheme, flex: 5),
                _hdr('Din', scheme, flex: 2, right: true),
                _hdr('Builds', scheme, flex: 2, right: true),
                _hdr('Unwinds', scheme, flex: 2, right: true),
                _hdr('Net ΔOI', scheme, flex: 4, right: true),
              ],
            ),
            const Divider(height: 10),
            for (final r in rows)
              InkWell(
                onTap: () => setState(() => _expiry = r.expiry),
                child: Container(
                  color: _expiry != null && _sameDay(r.expiry, _expiry!)
                      ? scheme.primary.withValues(alpha: 0.08)
                      : null,
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    children: [
                      Expanded(
                        flex: 5,
                        child: Text(
                          DateFormat('dd MMM yyyy').format(r.expiry),
                          style: const TextStyle(fontSize: 10.5),
                        ),
                      ),
                      Expanded(
                        flex: 2,
                        child: Text(
                          '${r.daysTo(asOf)}d',
                          textAlign: TextAlign.right,
                          style: TextStyle(
                            fontSize: 10,
                            color: scheme.onSurfaceVariant,
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 2,
                        child: Text(
                          '${r.summary.builds}',
                          textAlign: TextAlign.right,
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            color: scheme.primary,
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 2,
                        child: Text(
                          '${r.summary.unwinds}',
                          textAlign: TextAlign.right,
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            color: scheme.error,
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 4,
                        child: Text(
                          _signed(r.summary.netOiChange),
                          textAlign: TextAlign.right,
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            color: r.summary.netOiChange >= 0
                                ? scheme.primary
                                : scheme.error,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            const SizedBox(height: 4),
            Text(
              'Din = trade date se kitne din. Long-dated (2030/2031) expiries '
              'me OI patla hota hai — chhota ΔOI normal hai, "sabse bada move" '
              'ka matlab yahan alag hai.',
              style: TextStyle(
                fontSize: 9,
                height: 1.4,
                color: scheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _hdr(String t, ColorScheme scheme, {int flex = 1, bool right = false}) =>
      Expanded(
        flex: flex,
        child: Text(
          t,
          textAlign: right ? TextAlign.right : TextAlign.left,
          style: TextStyle(
            fontSize: 9,
            fontWeight: FontWeight.w800,
            color: scheme.onSurfaceVariant,
          ),
        ),
      );

  Widget _movesCard(
    ColorScheme scheme, {
    required String title,
    required String subtitle,
    required List<IndexOiLeg> legs,
    required String empty,
  }) => Card(
    child: Padding(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 11),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800),
          ),
          Text(
            subtitle,
            style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant),
          ),
          const SizedBox(height: 6),
          if (legs.isEmpty)
            Text(
              empty,
              style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
            )
          else
            for (final l in legs)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 2.5),
                child: Row(
                  children: [
                    SizedBox(
                      width: 64,
                      child: Text(
                        l.strike.toStringAsFixed(0),
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 30,
                      child: Text(
                        l.optionType,
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          color: l.isCall ? scheme.primary : scheme.error,
                        ),
                      ),
                    ),
                    Expanded(
                      child: Text(
                        '${l.signal.emoji} ${l.signal.label}',
                        style: const TextStyle(fontSize: 10.5),
                      ),
                    ),
                    SizedBox(
                      width: 76,
                      child: Text(
                        _signed(l.oiChange),
                        textAlign: TextAlign.right,
                        style: TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w800,
                          color: l.oiChange >= 0
                              ? scheme.primary
                              : scheme.error,
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 58,
                      child: Text(
                        '${_signed(l.oiChangePct)}%',
                        textAlign: TextAlign.right,
                        style: TextStyle(
                          fontSize: 10,
                          color: scheme.onSurfaceVariant,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
        ],
      ),
    ),
  );

  Widget _chainCard(ColorScheme scheme, IndexOiSnapshot snap, DateTime expiry) {
    final strikes = snap.strikesFor(expiry);
    final legs = snap.forExpiry(expiry);
    IndexOiLeg? legFor(double strike, String type) {
      for (final l in legs) {
        if (l.strike == strike && l.optionType == type) return l;
      }
      return null;
    }

    const wStrike = 64.0;
    const wOi = 74.0;
    const wChange = 92.0;
    const wPct = 60.0;
    final total = wStrike + (wOi + wChange + wPct) * 2;

    Widget hdr(String t, double w, {bool right = false}) => SizedBox(
      width: w,
      child: Text(
        t,
        textAlign: right ? TextAlign.right : TextAlign.left,
        style: TextStyle(
          fontSize: 9,
          fontWeight: FontWeight.w800,
          color: scheme.onSurfaceVariant,
        ),
      ),
    );

    Widget oiCell(IndexOiLeg? l) => SizedBox(
      width: wOi,
      child: Text(
        l == null ? '—' : _k(l.oi),
        textAlign: TextAlign.right,
        style: const TextStyle(fontSize: 9.5),
      ),
    );

    Widget changeCell(IndexOiLeg? l) {
      if (l == null) {
        return SizedBox(
          width: wChange,
          child: Text(
            '—',
            textAlign: TextAlign.right,
            style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant),
          ),
        );
      }
      return SizedBox(
        width: wChange,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Text(
              _k(l.oiChange),
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w700,
                color: l.oiChange >= 0 ? scheme.primary : scheme.error,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 3),
              child: Text(l.signal.emoji, style: const TextStyle(fontSize: 9)),
            ),
          ],
        ),
      );
    }

    Widget pctCell(IndexOiLeg? l) => SizedBox(
      width: wPct,
      child: Text(
        l == null ? '—' : '${_signed(l.oiChangePct)}%',
        textAlign: TextAlign.right,
        style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant),
      ),
    );

    Widget row(double strike) {
      final ce = legFor(strike, 'CE');
      final pe = legFor(strike, 'PE');
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 2.5),
        child: Row(
          children: [
            SizedBox(
              width: wStrike,
              child: Text(
                strike.toStringAsFixed(0),
                style: const TextStyle(
                  fontSize: 10.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            oiCell(ce),
            changeCell(ce),
            pctCell(ce),
            oiCell(pe),
            changeCell(pe),
            pctCell(pe),
          ],
        ),
      );
    }

    final level = snap.indexLevelOn(expiry);
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '📋 Strike-wise OI (${DateFormat('dd MMM yyyy').format(expiry)})',
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800),
            ),
            Text(
              level == null
                  ? 'Poora chain — OI, ΔOI qty + ΔOI %. Emoji = signal.'
                  : 'Index ${_k(level)} · poora chain — OI, ΔOI qty + ΔOI %. '
                        'Emoji = signal.',
              style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant),
            ),
            const SizedBox(height: 8),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: SizedBox(
                width: total,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        hdr('Strike', wStrike),
                        hdr('CE OI', wOi, right: true),
                        hdr('CE ΔOI', wChange, right: true),
                        hdr('CE %', wPct, right: true),
                        hdr('PE OI', wOi, right: true),
                        hdr('PE ΔOI', wChange, right: true),
                        hdr('PE %', wPct, right: true),
                      ],
                    ),
                    const Divider(height: 10),
                    for (final s in strikes) row(s),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'CE/PE alag rows hote hain (bhavcopy me). OI qty me hai (lots '
              'nahi). ΔOI % = ΔOI ÷ kal ka OI. Ek bhi number tab tak nahi '
              'aata jab tak file me na ho.',
              style: TextStyle(
                fontSize: 9,
                height: 1.4,
                color: scheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------------ helpers

  Future<void> _share(BuildContext context) async {
    final text = _asText();
    if (text.isEmpty) return;
    await ShareHelper.shareText(
      text,
      subject: 'Index OI ${_underlying ?? ''} · ${_d(_tradeDate)}',
    );
  }

  static String _d(DateTime? d) =>
      d == null ? '—' : DateFormat('dd MMM yyyy').format(d);

  static String _daysLabel(DateTime expiry, DateTime asOf) {
    final days = DateTime(expiry.year, expiry.month, expiry.day)
        .difference(DateTime(asOf.year, asOf.month, asOf.day))
        .inDays;
    if (days <= 0) return 'expiry day';
    return '$days din';
  }

  static String _signed(double v) => '${v >= 0 ? '+' : '−'}${_k(v.abs())}';

  /// 120000 → 1.2L, 5000000 → 50.00L, 10000000 → 1.00Cr.
  static String _k(double v) {
    final n = v.round();
    if (n.abs() >= 10000000) return '${(n / 10000000).toStringAsFixed(2)}Cr';
    if (n.abs() >= 100000) return '${(n / 100000).toStringAsFixed(2)}L';
    return NumberFormat.decimalPattern('en_IN').format(n);
  }

  String _asText() {
    final snap = _snapshot;
    final expiry = _expiry;
    if (snap == null || expiry == null) return '';
    final b = StringBuffer()
      ..writeln('=== ${snap.underlying} (${snap.source}) · Index OI Build–Unwind ===')
      ..writeln('Trade date: ${_d(_tradeDate)} · Expiry: ${_d(expiry)}')
      ..writeln('Filter: ${_filter.label} · Sort: ${_sort.label}')
      ..writeln('Expiries in file: ${snap.expiries.length}');
    void section(String title, List<IndexOiLeg> legs) {
      b.writeln('\n$title');
      for (final l in legs) {
        b.writeln(
          '• ${l.strike.toStringAsFixed(0)} ${l.optionType} — '
          '${l.signal.label} · ΔOI ${_signed(l.oiChange)} '
          '(${_signed(l.oiChangePct)}%) · OI ${_k(l.oi)}',
        );
      }
    }

    section(
      'BUILD-UPS:',
      snap.topBuilds(expiry: expiry, filter: _filter, sort: _sort),
    );
    section(
      'UNWINDS:',
      snap.topUnwinds(expiry: expiry, filter: _filter, sort: _sort),
    );
    b.writeln('\nSource: NSE + BSE official F&O bhavcopy (EOD).');
    return b.toString();
  }
}
