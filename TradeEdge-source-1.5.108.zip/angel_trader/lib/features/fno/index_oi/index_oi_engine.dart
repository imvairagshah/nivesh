// ---------------------------------------------------------------------------
// index_oi_engine.dart — 1.5.108 "F&O Index OI Build–Unwind".
//
// Stock OI (1.5.86) ka index jodi. **Rules bilkul same** (user-confirmed):
//   price ↑ + OI ↑ → Long build-up
//   price ↓ + OI ↑ → Short build-up
//   price ↑ + OI ↓ → Short covering
//   price ↓ + OI ↓ → Long unwinding
//   OI change ~0   → Flat
//   Default filter bhi same: Balanced (OI ≥ 5000 · |ΔOI%| ≥ 10).
//
// Farak sirf data ka hai:
//   • Index options UDiFF me alag `FinInstrmTp` hote hain — **`IDO`** (index
//     derivative option), stock wale `STO` nahi. Isliye stock parser inhe
//     jaan-boojh kar chhod deta hai (do kaam mix na hon).
//   • **Do exchange:** NSE (NIFTY · BANKNIFTY · FINNIFTY · MIDCPNIFTY ·
//     NIFTYNXT50 · NIFTYFPI) aur BSE (SENSEX · BANKEX · FOCIT). Dono ki
//     official bhavcopy alag file hai — ek din = do download.
//   • **Saari expiries** jitni file me hain — NIFTY ke 2030/2031 tak
//     (aaj ki file me 18 expiries). Koi cap nahi.
//
// Koi number bana kar nahi dikhaya jaata: jo row file me nahi, wo "—".
// ---------------------------------------------------------------------------

import 'dart:math' as math;

/// Index / exchange / index-OI leg. (StockOiLeg se jaan-boojh kar alag rakha
/// hai taaki stock screen ka contract ek line bhi na badle.)
class IndexOiLeg {
  const IndexOiLeg({
    required this.underlying,
    required this.source,
    required this.expiry,
    required this.strike,
    required this.optionType,
    required this.oi,
    required this.oiChange,
    required this.close,
    required this.previousClose,
    this.lotSize = 0,
    this.underlyingPrice,
  });

  /// `NIFTY`, `BANKNIFTY`, `SENSEX`, …
  final String underlying;

  /// `NSE` | `BSE` — kis exchange ki file se aaya.
  final String source;

  final DateTime expiry;
  final double strike;

  /// `CE` | `PE`.
  final String optionType;

  /// `OpnIntrst` (qty, lots nahi).
  final double oi;

  /// `ChngInOpnIntrst` (qty, signed).
  final double oiChange;

  final double close;
  final double previousClose;
  final int lotSize;

  /// `UndrlygPric` — us din ka index level (file me hota hai, guess nahi).
  final double? underlyingPrice;

  bool get isCall => optionType == 'CE';

  /// Kal ka OI (change se derive — bhavcopy me seedha column nahi).
  double get previousOi => oi - oiChange;

  double get oiChangePct => previousOi <= 0 ? 0 : oiChange / previousOi * 100;

  double get priceChangePct =>
      previousClose <= 0 ? 0 : (close - previousClose) / previousClose * 100;

  IndexOiSignal get signal => classifyIndexSignal(
    priceChangePct: priceChangePct,
    oiChangePct: oiChangePct,
  );
}

/// Price × OI matrix — stock OI ke `OiSignal` ke bilkul wahi 5 natije.
enum IndexOiSignal {
  longBuildup('Long build-up', '🟢', 'Price ↑ + OI ↑ — nayi buy positions'),
  shortBuildup('Short build-up', '🔴', 'Price ↓ + OI ↑ — nayi sell positions'),
  shortCovering('Short covering', '🟡', 'Price ↑ + OI ↓ — short windup'),
  longUnwinding('Long unwinding', '🟠', 'Price ↓ + OI ↓ — long windup'),
  flat('Flat', '⚪', 'OI me meaningful change nahi');

  const IndexOiSignal(this.label, this.emoji, this.meaning);
  final String label;
  final String emoji;
  final String meaning;

  bool get isBuild => this == longBuildup || this == shortBuildup;
  bool get isUnwind => this == shortCovering || this == longUnwinding;
}

/// Wahi rules jo stock OI me hain — band se chhota move "no move".
IndexOiSignal classifyIndexSignal({
  required double priceChangePct,
  required double oiChangePct,
  double priceBandPct = 0.05,
  double oiBandPct = 1.0,
}) {
  if (oiChangePct.abs() < oiBandPct) return IndexOiSignal.flat;
  final up = priceChangePct > priceBandPct;
  final down = priceChangePct < -priceBandPct;
  if (up) {
    return oiChangePct > 0
        ? IndexOiSignal.longBuildup
        : IndexOiSignal.shortCovering;
  }
  if (down) {
    return oiChangePct > 0
        ? IndexOiSignal.shortBuildup
        : IndexOiSignal.longUnwinding;
  }
  return IndexOiSignal.flat;
}

/// Filter presets — **stock wale hi** (user: "stocks jaisa hi").
class IndexOiFilter {
  const IndexOiFilter({
    required this.label,
    required this.minOi,
    required this.minOiChangePct,
  });

  final String label;
  final double minOi;
  final double minOiChangePct;

  static const balanced = IndexOiFilter(
    label: 'Balanced',
    minOi: 5000,
    minOiChangePct: 10,
  );
  static const strict = IndexOiFilter(
    label: 'Strict',
    minOi: 10000,
    minOiChangePct: 20,
  );
  static const all = IndexOiFilter(label: 'All', minOi: 0, minOiChangePct: 0);

  static const presets = [balanced, strict, all];

  bool passes(IndexOiLeg leg) =>
      leg.oi >= minOi && leg.oiChangePct.abs() >= minOiChangePct;
}

/// Sort — stock wale options.
enum IndexOiSort {
  byQty('ΔOI qty', 'absolute change'),
  byPct('ΔOI %', 'relative change');

  const IndexOiSort(this.label, this.hint);
  final String label;
  final String hint;

  double valueOf(IndexOiLeg leg) =>
      this == IndexOiSort.byQty ? leg.oiChange.abs() : leg.oiChangePct.abs();
}

/// Ek index ka poora book (saari expiries, saare strikes).
class IndexOiSnapshot {
  const IndexOiSnapshot({
    required this.underlying,
    required this.tradeDate,
    required this.legs,
  });

  final String underlying;
  final DateTime tradeDate;
  final List<IndexOiLeg> legs;

  /// Kis exchange se aaya (NSE/BSE) — label ke liye.
  String get source => legs.isEmpty ? '' : legs.first.source;

  /// Saari expiries, ascending — jitni file me hain (2030/2031 tak bhi).
  List<DateTime> get expiries {
    final set = <DateTime>{for (final l in legs) l.expiry};
    return set.toList()..sort();
  }

  List<IndexOiLeg> forExpiry(DateTime expiry) =>
      legs.where((l) => _sameDay(l.expiry, expiry)).toList();

  List<double> strikesFor(DateTime expiry) {
    final set = <double>{for (final l in forExpiry(expiry)) l.strike};
    return set.toList()..sort();
  }

  /// Us din ka index level (file se; na mile to null).
  double? indexLevelOn(DateTime expiry) {
    for (final l in forExpiry(expiry)) {
      final level = l.underlyingPrice;
      if (level != null && level > 0) return level;
    }
    return null;
  }

  List<IndexOiLeg> _ranked(DateTime expiry, IndexOiFilter filter, IndexOiSort sort) =>
      forExpiry(expiry).where(filter.passes).toList()
        ..sort((a, b) => sort.valueOf(b).compareTo(sort.valueOf(a)));

  List<IndexOiLeg> topBuilds({
    required DateTime expiry,
    required IndexOiFilter filter,
    required IndexOiSort sort,
    int limit = 10,
  }) => _ranked(
    expiry,
    filter,
    sort,
  ).where((l) => l.signal.isBuild && l.oiChange > 0).take(limit).toList();

  List<IndexOiLeg> topUnwinds({
    required DateTime expiry,
    required IndexOiFilter filter,
    required IndexOiSort sort,
    int limit = 10,
  }) => _ranked(
    expiry,
    filter,
    sort,
  ).where((l) => l.signal.isUnwind || l.oiChange < 0).take(limit).toList();

  /// Ek expiry ka summary — build/unwind count + net ΔOI (**filter ke bahar
  /// wale bhi** count hote hain, kyunki ye "us expiry ka aaj ka sach" hai).
  ({int builds, int unwinds, double netOiChange}) summary(DateTime expiry) {
    var builds = 0;
    var unwinds = 0;
    var net = 0.0;
    final rows = forExpiry(expiry);
    for (final l in rows) {
      net += l.oiChange;
      if (l.oiChange > 0) {
        builds++;
      } else if (l.oiChange < 0) {
        unwinds++;
      }
    }
    return (builds: builds, unwinds: unwinds, netOiChange: net);
  }

  /// Filter ke andar wale rows ka summary (cards par wahi dikhta hai).
  ({int builds, int unwinds, double netOiChange}) filteredSummary(
    DateTime expiry,
    IndexOiFilter filter,
  ) {
    var builds = 0;
    var unwinds = 0;
    var net = 0.0;
    for (final l in forExpiry(expiry)) {
      if (!filter.passes(l)) continue;
      net += l.oiChange;
      if (l.oiChange > 0) {
        builds++;
      } else if (l.oiChange < 0) {
        unwinds++;
      }
    }
    return (builds: builds, unwinds: unwinds, netOiChange: net);
  }

  /// Saari expiries ki ek line — "kis expiry me aaj sabse zyada position
  /// bani". User ki demand: 2030 wali expiry bhi isi list me.
  List<IndexExpiryRow> expiryRows({IndexOiFilter filter = IndexOiFilter.all}) {
    return [
      for (final e in expiries)
        IndexExpiryRow(
          expiry: e,
          legs: forExpiry(e).length,
          strikes: strikesFor(e).length,
          summary: summary(e),
          indexLevel: indexLevelOn(e),
        ),
    ];
  }

  static bool _sameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;
}

/// Ek expiry ki summary line (expiry dropdown/card ke liye).
class IndexExpiryRow {
  const IndexExpiryRow({
    required this.expiry,
    required this.legs,
    required this.strikes,
    required this.summary,
    this.indexLevel,
  });

  final DateTime expiry;

  /// File me is expiry ke option rows (CE+PE).
  final int legs;
  final int strikes;
  final ({int builds, int unwinds, double netOiChange}) summary;
  final double? indexLevel;

  /// Din se kitna door — "2030 ka long-dated" saaf dikhe.
  int daysTo(DateTime asOf) =>
      DateTime(expiry.year, expiry.month, expiry.day)
          .difference(DateTime(asOf.year, asOf.month, asOf.day))
          .inDays;
}

/// Do exchange ki files ka joda hua book.
class IndexOiBook {
  const IndexOiBook({
    required this.byUnderlying,
    required this.nseRows,
    required this.bseRows,
    this.nseDate,
    this.bseDate,
    this.notes = const [],
  });

  final Map<String, IndexOiSnapshot> byUnderlying;

  /// Kitni rows har file se aayi (0 = wo file nahi mili).
  final int nseRows;
  final int bseRows;
  final DateTime? nseDate;
  final DateTime? bseDate;

  /// Fail hone wali file ki wajah (UI par saaf likha jaata hai — chhupaya
  /// nahi jaata).
  final List<String> notes;

  int get rowCount => nseRows + bseRows;

  List<String> get underlyings => byUnderlying.keys.toList()..sort();

  /// `NSE` wale pehle, phir `BSE` — dropdown ke liye.
  List<String> get orderedUnderlyings {
    final list = underlyings;
    list.sort((a, b) {
      final sa = byUnderlying[a]?.source ?? 'NSE';
      final sb = byUnderlying[b]?.source ?? 'NSE';
      if (sa != sb) return sa == 'NSE' ? -1 : 1;
      return a.compareTo(b);
    });
    return list;
  }

  IndexOiSnapshot? operator [](String? underlying) =>
      underlying == null ? null : byUnderlying[underlying];

  /// Dono files ka sabse naya trade date.
  DateTime? get tradeDate {
    final dates = [nseDate, bseDate].whereType<DateTime>().toList()..sort();
    return dates.isEmpty ? null : dates.last;
  }
}

// ---------------------------------------------------------------------------
// Parser — UDiFF F&O bhavcopy CSV → **index option** (IDO) rows.
// ---------------------------------------------------------------------------

String _normIndexHeader(String s) =>
    s.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

int _indexCol(List<String> header, List<String> names) {
  final norm = header.map(_normIndexHeader).toList();
  for (final n in names) {
    final idx = norm.indexOf(_normIndexHeader(n));
    if (idx >= 0) return idx;
  }
  return -1;
}

const List<String> _indexMonths = [
  'JAN',
  'FEB',
  'MAR',
  'APR',
  'MAY',
  'JUN',
  'JUL',
  'AUG',
  'SEP',
  'OCT',
  'NOV',
  'DEC',
];

/// `2026-10-27` / `27-Oct-2026` / `27OCT2026` → DateTime.
DateTime? parseIndexOiDate(String raw) {
  final text = raw.trim();
  if (text.isEmpty) return null;
  final iso = DateTime.tryParse(text);
  if (iso != null) return DateTime(iso.year, iso.month, iso.day);
  final cleaned = text.toUpperCase().replaceAll(RegExp(r'[-/\s]'), '');
  if (cleaned.length >= 9) {
    final day = int.tryParse(cleaned.substring(0, 2));
    final mon = _indexMonths.indexOf(cleaned.substring(2, 5));
    final year = int.tryParse(cleaned.substring(5, 9));
    if (day != null && mon >= 0 && year != null) {
      return DateTime(year, mon + 1, day);
    }
  }
  return null;
}

/// Cross-check: ye underlying index hi hai? (file ka `Sgmt`/type pehle hi
/// filter karta hai; ye safety net hai taaki koi stock galti se na aa jaye.)
const Set<String> kIndexUnderlyings = {
  'NIFTY',
  'BANKNIFTY',
  'FINNIFTY',
  'MIDCPNIFTY',
  'NIFTYNXT50',
  'NIFTYFPI',
  'SENSEX',
  'BANKEX',
  'FOCIT',
  'SENSEX50',
};

/// Ek file (NSE ya BSE) ka CSV → index-option legs + underlying ke hisaab se.
///
/// Sirf `FinInstrmTp == 'IDO'` rows. Jo file me hai wahi aata hai — koi index
/// bana kar nahi jodta.
IndexOiParse parseIndexOptionOi(
  String csv,
  DateTime tradeDate, {
  required String source,
}) {
  final lines = csv.split(RegExp(r'[\r\n]+'));
  if (lines.length < 2) {
    return const IndexOiParse(byUnderlying: {}, rowCount: 0);
  }
  final header = lines.first.split(',');
  final iSymbol = _indexCol(header, ['TckrSymb', 'Symbol']);
  final iExpiry = _indexCol(header, ['XpryDt', 'ExpiryDt', 'ExpiryDate']);
  final iType = _indexCol(header, ['FinInstrmTp']);
  final iOpt = _indexCol(header, ['OptnTp', 'OptionTyp']);
  final iStrike = _indexCol(header, ['StrkPric', 'StrikePrice', 'Strike']);
  final iOi = _indexCol(header, ['OpnIntrst', 'OpenInt', 'OpenInterest']);
  final iChg = _indexCol(header, ['ChngInOpnIntrst', 'ChgInOI']);
  final iClose = _indexCol(header, ['ClsPric', 'ClosePrice', 'Close']);
  final iPrev = _indexCol(header, ['PrvsClsgPric', 'PrevClose']);
  final iLot = _indexCol(header, ['NewBrdLotQty', 'MarketLot', 'LotSize']);
  final iUnder = _indexCol(header, ['UndrlygPric', 'UnderlyingPrice']);
  if (iSymbol < 0 || iExpiry < 0 || iStrike < 0 || iOi < 0 || iChg < 0) {
    return const IndexOiParse(
      byUnderlying: {},
      rowCount: 0,
      error: 'header me zaroori columns nahi mile',
    );
  }

  final rows = <String, List<IndexOiLeg>>{};
  var rowCount = 0;
  for (var i = 1; i < lines.length; i++) {
    final line = lines[i].trim();
    if (line.isEmpty) continue;
    final parts = line.split(',');
    if (parts.length <= math.max(iOi, iChg)) continue;
    String at(int idx) =>
        idx >= 0 && idx < parts.length ? parts[idx].trim() : '';
    double? numAt(int idx) {
      final raw = at(idx);
      if (raw.isEmpty) return null;
      return double.tryParse(raw);
    }

    // Sirf index options. Type column na ho (purani file) to underlying
    // whitelist se decide — phir bhi stock nahi ghusega.
    final type = at(iType).toUpperCase();
    final underlying = at(iSymbol).toUpperCase();
    if (underlying.isEmpty) continue;
    final isIndexOption = type.isNotEmpty
        ? type == 'IDO'
        : kIndexUnderlyings.contains(underlying);
    if (!isIndexOption) continue;
    if (!kIndexUnderlyings.contains(underlying)) continue;

    final opt = at(iOpt).toUpperCase();
    if (opt != 'CE' && opt != 'PE') continue;

    final expiry = parseIndexOiDate(at(iExpiry));
    final strike = numAt(iStrike);
    final oi = numAt(iOi);
    final chg = numAt(iChg);
    if (expiry == null || strike == null || strike <= 0) continue;
    if (oi == null || oi <= 0 || chg == null) continue;

    rows
        .putIfAbsent(underlying, () => [])
        .add(
          IndexOiLeg(
            underlying: underlying,
            source: source,
            expiry: expiry,
            strike: strike,
            optionType: opt,
            oi: oi,
            oiChange: chg,
            close: numAt(iClose) ?? 0,
            previousClose: numAt(iPrev) ?? 0,
            lotSize: numAt(iLot)?.round() ?? 0,
            underlyingPrice: numAt(iUnder),
          ),
        );
    rowCount++;
  }

  return IndexOiParse(
    byUnderlying: {
      for (final e in rows.entries)
        e.key: IndexOiSnapshot(
          underlying: e.key,
          tradeDate: tradeDate,
          legs: e.value,
        ),
    },
    rowCount: rowCount,
  );
}

/// Ek file ka parse natija.
class IndexOiParse {
  const IndexOiParse({
    required this.byUnderlying,
    required this.rowCount,
    this.error,
  });

  final Map<String, IndexOiSnapshot> byUnderlying;
  final int rowCount;
  final String? error;
}

/// Do parsed files → ek book (NSE pehle, BSE ka same naam ho to NSE hi rehta
/// hai — dono exchange ek underlying par clash nahi karte).
IndexOiBook mergeIndexOi({
  required IndexOiParse? nse,
  required IndexOiParse? bse,
  DateTime? nseDate,
  DateTime? bseDate,
}) {
  final merged = <String, IndexOiSnapshot>{};
  if (nse != null) merged.addAll(nse.byUnderlying);
  if (bse != null) {
    for (final e in bse.byUnderlying.entries) {
      merged.putIfAbsent(e.key, () => e.value);
    }
  }
  final notes = <String>[
    if (nse == null) 'NSE F&O bhavcopy nahi mili — sirf BSE ka data dikha rahe hain.',
    if (bse == null) 'BSE F&O bhavcopy nahi mili — sirf NSE ka data dikha rahe hain.',
    if (nse?.error != null) 'NSE file: ${nse!.error}',
    if (bse?.error != null) 'BSE file: ${bse!.error}',
  ];
  return IndexOiBook(
    byUnderlying: merged,
    nseRows: nse?.rowCount ?? 0,
    bseRows: bse?.rowCount ?? 0,
    nseDate: nseDate,
    bseDate: bseDate,
    notes: notes,
  );
}
