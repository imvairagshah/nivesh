// 1.5.93 — F&O hub (design B: category rows + long-press drag reorder).
//
// Yahan teen cheezein pin hoti hain:
//   1. saved order merge logic (naya tool aaye to user ka order na toote),
//   2. hub render — section order + har row me sirf naam + ek line,
//   3. long-press drag se row ka upar-neeche jaana + save call.

import 'package:angel_trader/features/fno/fno_hub_config.dart';
import 'package:angel_trader/features/fno/fno_hub_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

class _FakeStore implements FnoHubOrderStore {
  _FakeStore([this._saved]);

  Map<String, List<String>>? _saved;
  int saves = 0;

  @override
  Future<Map<String, List<String>>> load() async =>
      mergeHubOrder(_saved ?? defaultHubOrder());

  @override
  Future<void> save(Map<String, List<String>> order) async {
    _saved = order;
    saves++;
  }
}

void main() {
  group('hub order merge', () {
    test(
      'default order — har tool apne section me, section ke andar config order',
      () {
        final order = defaultHubOrder();
        // 1.5.101: F&O Scanner study section me juda (Magic Formula ke andar
        // chhupa hua tha, kisi tile se khulta hi nahi tha).
        expect(order['study'], ['study', 'adv', 'fno_scanner']);
        expect(order['index'], ['bankex']);
        // 1.5.108 — index_oi stock_oi ke baad, iv_spike se pehle.
        expect(order['options'], [
          'stock_oi',
          'index_oi',
          'iv_spike',
          'iv_crush',
          'extremes',
        ]);
        expect(order['calendar'], ['results', 'ai', 'news']);
        expect(
          order.values.fold<int>(0, (a, b) => a + b.length),
          kHubTools.length,
        );
      },
    );

    test('saved order barqarar rehta hai', () {
      final merged = mergeHubOrder({
        'study': ['adv', 'study'],
        'options': ['extremes', 'stock_oi'],
        'calendar': ['ai', 'results'],
        'index': ['bankex'],
      });
      // Naya tool (fno_scanner / news) apne section ke aakhir me jud jaata hai.
      expect(merged['study'], ['adv', 'study', 'fno_scanner']);
      expect(merged['options'], [
        'extremes',
        'stock_oi',
        'index_oi',
        'iv_spike',
        'iv_crush',
      ]);
      expect(merged['calendar'], ['ai', 'results', 'news']);
    });

    test(
      'naya tool apne section ke aakhir me judta hai (order nahi tootta)',
      () {
        // Purana saved order jisme 'extremes' hi nahi tha.
        final merged = mergeHubOrder({
          'study': ['adv', 'study'],
          'options': ['stock_oi'],
        });
        expect(merged['study'], ['adv', 'study', 'fno_scanner']);
        expect(merged['options'], [
          'stock_oi',
          'index_oi',
          'iv_spike',
          'iv_crush',
          'extremes',
        ]);
      },
    );

    test('kharab / adhoora JSON → default order (crash nahi)', () {
      expect(mergeHubOrder(null)['study'], ['study', 'adv', 'fno_scanner']);
      expect(mergeHubOrder('garbage')['study'], [
        'study',
        'adv',
        'fno_scanner',
      ]);
      expect(mergeHubOrder(<String, dynamic>{'study': 'not-a-list'})['study'], [
        'study',
        'adv',
        'fno_scanner',
      ]);
    });

    test('unknown id chhoot jata hai, duplicate nahi aata', () {
      final merged = mergeHubOrder({
        'study': ['ghost', 'study', 'study', 'adv'],
      });
      expect(merged['study'], ['study', 'adv', 'fno_scanner']);
    });

    test('moveInSection — neeche aur upar dono', () {
      expect(moveInSection(['a', 'b', 'c'], 'a', 2), ['b', 'c', 'a']);
      expect(moveInSection(['a', 'b', 'c'], 'c', 0), ['c', 'a', 'b']);
      expect(moveInSection(['a', 'b'], 'zz', 0), ['a', 'b']);
      expect(moveInSection(['a', 'b'], 'a', 99), ['b', 'a']);
    });
  });

  group('hub screen', () {
    Widget wrap(Widget child) => MaterialApp(home: child);

    testWidgets('section order + compact rows (naam + ek line)', (
      tester,
    ) async {
      await tester.pumpWidget(wrap(FnoHubScreen(orderStore: _FakeStore())));
      await tester.pumpAndSettle();

      // Section headings config ke order me.
      final headings = [
        'SCREENER & STUDY',
        'INDEX STRATEGIES',
        'OPTIONS DATA',
        'CALENDAR & AI',
      ];
      final positions = [
        for (final h in headings) tester.getTopLeft(find.text(h)).dy,
      ];
      for (var i = 1; i < positions.length; i++) {
        expect(
          positions[i],
          greaterThan(positions[i - 1]),
          reason: '${headings[i]} ${headings[i - 1]} ke neeche hona chahiye',
        );
      }

      // Saare live tools ek hi page par.
      for (final tool in kHubTools) {
        expect(find.text(tool.title), findsOneWidget, reason: tool.title);
      }
    });

    testWidgets('1.5.97 — har tile barabar, koi chhoti description nahi', (
      tester,
    ) async {
      await tester.pumpWidget(wrap(FnoHubScreen(orderStore: _FakeStore())));
      await tester.pumpAndSettle();

      // Description tile par nahi dikhti (wo FAQ me hai).
      for (final tool in kHubTools) {
        expect(
          find.text(tool.blurb),
          findsNothing,
          reason: '${tool.id} ki description tile par nahi honi chahiye',
        );
      }

      // Grid ke saare tiles ek hi height ke hain.
      final tiles = tester
          .widgetList<AnimatedContainer>(
            find.descendant(
              of: find.byType(DragTarget<String>),
              matching: find.byType(AnimatedContainer),
            ),
          )
          .toList();
      expect(tiles, isNotEmpty);
      final heights = tester
          .renderObjectList<RenderBox>(
            find.descendant(
              of: find.byType(DragTarget<String>),
              matching: find.byType(AnimatedContainer),
            ),
          )
          .map((r) => r.size.height.round())
          .toSet();
      expect(
        heights,
        hasLength(1),
        reason: 'saare tiles ki height same honi chahiye',
      );
    });

    testWidgets(
      'long-press drag se tile doosri jagah jaata hai aur save hota hai',
      (tester) async {
        final store = _FakeStore();
        await tester.pumpWidget(wrap(FnoHubScreen(orderStore: store)));
        await tester.pumpAndSettle();

        // 1.5.96: hub ab grid hai — Study ke do tiles side-by-side hain, isliye
        // pehla tile **daayein** wale tile par drop hota hai. 1.5.97 se tiles
        // barabar hain, par naam 2 line ka ho sakta hai — isliye tile ke rect se
        // naap lete hain, title ke text se nahi.
        final firstTile = find.ancestor(
          of: find.text('3-Month Study'),
          matching: find.byType(DragTarget<String>),
        );
        final secondTile = find.ancestor(
          of: find.text('3-Month Study · Advance Filter'),
          matching: find.byType(DragTarget<String>),
        );
        expect(
          tester.getTopLeft(firstTile.first).dy,
          closeTo(tester.getTopLeft(secondTile.first).dy, 1),
          reason: 'dono Study tiles ek hi row me hain',
        );

        // Grid columns test surface ke hisaab se badalte hain (2/3/4), isliye
        // drop target ka offset naapo — hard-coded pixel nahi.
        final delta =
            tester.getCenter(secondTile.first) -
            tester.getCenter(firstTile.first);
        final gesture = await tester.startGesture(
          tester.getCenter(firstTile.first),
        );
        await tester.pump(
          const Duration(milliseconds: 700),
        ); // long-press delay
        await gesture.moveBy(delta);
        await tester.pump(const Duration(milliseconds: 200));
        await gesture.up();
        await tester.pumpAndSettle();

        // Model me order badal gaya + store.save call hua.
        expect(store.saves, greaterThan(0));
        final saved = await store.load();
        // 1.5.101 ka naya tool (fno_scanner) apni jagah — drag se wo nahi
        // hilta, sirf study/adv ka aapas ka order badalta hai.
        expect(saved['study'], ['adv', 'study', 'fno_scanner']);
      },
    );
  });
}
