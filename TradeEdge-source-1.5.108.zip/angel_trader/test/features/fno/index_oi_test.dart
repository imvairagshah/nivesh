// ---------------------------------------------------------------------------
// index_oi_test.dart — 1.5.108 "F&O Index OI Build–Unwind".
//
// Pin hota hai:
//   1. Parser sirf **IDO** (index option) rows leta hai — stock (STO) nahi.
//   2. NSE + BSE dono files ek book me merge hote hain, aur **saari expiries**
//      aati hain (2030/2031 wali long-dated bhi) — koi cap nahi.
//   3. Rules stock OI wale hi (price × OI), default filter bhi same.
//   4. Expiry summary me har expiry ki line (tap par wahi expiry select).
//   5. Ek exchange fail ho to doosre ka data aata hai + reason saaf likha
//      jaata hai (chhupaya nahi jaata).
// ---------------------------------------------------------------------------

import 'package:angel_trader/features/fno/index_oi/index_oi_engine.dart';
import 'package:angel_trader/features/fno/index_oi/index_oi_screen.dart';
import 'package:angel_trader/features/fno/index_oi/index_oi_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

/// Do-teen index + long-dated expiry wali asli-shape CSV.
const _nseCsv = '''
TradDt,BizDt,Sgmt,Src,FinInstrmTp,FinInstrmId,ISIN,TckrSymb,SctySrs,XpryDt,FininstrmActlXpryDt,StrkPric,OptnTp,FinInstrmNm,OpnPric,HghPric,LwPric,ClsPric,LastPric,PrvsClsgPric,UndrlygPric,SttlmPric,OpnIntrst,ChngInOpnIntrst,TtlTradgVol,NewBrdLotQty
2026-10-01,2026-10-01,FO,NSE,STO,1,,SBIN,,2026-10-27,2026-10-27,800.00,CE,SBIN26OCT800CE,1,1,1,10,10,9,812,10,999999,99999,100,500
2026-10-01,2026-10-01,FO,NSE,IDO,2,,NIFTY,,2026-10-06,2026-10-06,25000.00,CE,NIFTY26OCT25000CE,10,10,10,120,120,100,25050,120,400000,40000,1000,75
2026-10-01,2026-10-01,FO,NSE,IDO,3,,NIFTY,,2026-10-06,2026-10-06,25000.00,PE,NIFTY26OCT25000PE,10,10,10,90,90,100,25050,90,600000,-120000,900,75
2026-10-01,2026-10-01,FO,NSE,IDO,4,,NIFTY,,2026-10-06,2026-10-06,25500.00,CE,NIFTY26OCT25500CE,1,1,1,50,50,50,25050,50,8000,100,10,75
2026-10-01,2026-10-01,FO,NSE,IDO,5,,NIFTY,,2030-06-25,2030-06-25,30000.00,CE,NIFTY30JUN30000CE,1,1,1,400,400,380,25050,400,25000,5000,5,75
2026-10-01,2026-10-01,FO,NSE,IDO,6,,BANKNIFTY,,2027-09-28,2027-09-28,60000.00,CE,BANKNIFTY27SEP60000CE,5,5,5,900,900,850,58000,900,30000,-6000,3,35
2026-10-01,2026-10-01,FO,NSE,IDF,7,,NIFTY,,2026-10-06,2026-10-06,,,,,,,,,,,5000,0,10,75
''';

const _bseCsv = '''
TradDt,BizDt,Sgmt,Src,FinInstrmTp,FinInstrmId,ISIN,TckrSymb,SctySrs,XpryDt,FininstrmActlXpryDt,StrkPric,OptnTp,FinInstrmNm,OpnPric,HghPric,LwPric,ClsPric,LastPric,PrvsClsgPric,UndrlygPric,SttlmPric,OpnIntrst,ChngInOpnIntrst,TtlTradgVol,NewBrdLotQty
2026-10-01,2026-10-01,FO,BSE,IDO,10,,SENSEX,,2026-10-01,2026-10-01,81300.00,CE,SENSEX26O0181300CE,1,1,1,0.45,0.40,0.65,81300,0.45,520,-40,600,20
2026-10-01,2026-10-01,FO,BSE,IDO,11,,SENSEX,,2026-10-29,2026-10-29,82000.00,PE,SENSEX26O2982000PE,1,1,1,300,300,280,81300,300,120000,30000,50,20
2026-10-01,2026-10-01,FO,BSE,IDO,12,,BANKEX,,2026-10-29,2026-10-29,70000.00,CE,BANKEX26OCT70000CE,1,1,1,120,120,110,69782,120,45000,-5000,20,15
2026-10-01,2026-10-01,FO,BSE,IDO,13,,FOCIT,,2026-10-29,2026-10-29,37000.00,CE,FOCIT26OCT37000CE,1,1,1,90,90,90,37428,90,12000,0,5,10
2026-10-01,2026-10-01,FO,BSE,STO,14,,RELIANCE,,2026-10-29,2026-10-29,1500.00,CE,RELIANCE26OCT1500CE,1,1,1,20,20,20,1480,20,700000,70000,10,500
''';

void main() {
  final day = DateTime(2026, 10, 1);

  group('parser', () {
    test('sirf IDO rows — stock option (STO) aur futures (IDF) nahi', () {
      final nse = parseIndexOptionOi(_nseCsv, day, source: 'NSE');
      // 5 IDO rows (NIFTY 4 + BANKNIFTY 1). SBIN (STO) aur IDF ignore.
      expect(nse.rowCount, 5);
      expect(nse.byUnderlying.keys.toSet(), {'NIFTY', 'BANKNIFTY'});
      // Stock ka number kahin nahi aaya.
      final all = nse.byUnderlying.values.expand((s) => s.legs);
      expect(all.any((l) => l.oi == 999999), isFalse);
    });

    test('saari expiries aati hain — 2030/2031 bhi (koi cap nahi)', () {
      final nse = parseIndexOptionOi(_nseCsv, day, source: 'NSE');
      final nifty = nse.byUnderlying['NIFTY']!;
      expect(nifty.expiries.length, 2); // 06 Oct 2026 + 25 Jun 2030
      expect(nifty.expiries.last, DateTime(2030, 6, 25));
      // 2030 wali expiry ke rows select ho sakte hain.
      final longDated = nifty.forExpiry(DateTime(2030, 6, 25));
      expect(longDated.length, 1);
      expect(longDated.first.strike, 30000);
    });

    test('BSE file — SENSEX, BANKEX, FOCIT; stock rows nahi', () {
      final bse = parseIndexOptionOi(_bseCsv, day, source: 'BSE');
      expect(bse.rowCount, 4);
      expect(bse.byUnderlying.keys.toSet(), {'SENSEX', 'BANKEX', 'FOCIT'});
      expect(bse.byUnderlying['SENSEX']!.source, 'BSE');
      // RELIANCE (STO) nahi aaya.
      expect(bse.byUnderlying['RELIANCE'], isNull);
    });

    test('merge — dono exchange ek book, rows + dates alag-alag', () {
      final book = mergeIndexOi(
        nse: parseIndexOptionOi(_nseCsv, day, source: 'NSE'),
        bse: parseIndexOptionOi(_bseCsv, day, source: 'BSE'),
        nseDate: day,
        bseDate: day.subtract(const Duration(days: 1)),
      );
      expect(book.nseRows, 5);
      expect(book.bseRows, 4);
      expect(book.nseDate, day);
      expect(book.bseDate, day.subtract(const Duration(days: 1)));
      expect(book.orderedUnderlyings, [
        'BANKNIFTY',
        'NIFTY',
        'BANKEX',
        'FOCIT',
        'SENSEX',
      ]);
      expect(book.notes, isEmpty);
    });

    test('ek exchange fail → doosra data + reason saaf (chhupaya nahi)', () {
      final book = mergeIndexOi(
        nse: parseIndexOptionOi(_nseCsv, day, source: 'NSE'),
        bse: null,
        nseDate: day,
      );
      expect(book.rowCount, 5);
      expect(book.notes.any((n) => n.contains('BSE')), isTrue);
    });

    test('header galat → khaali parse + wajah (crash nahi)', () {
      final bad = parseIndexOptionOi('a,b,c\n1,2,3', day, source: 'NSE');
      expect(bad.rowCount, 0);
      expect(bad.error, isNotNull);
    });
  });

  group('rules + filters (stock OI wale hi)', () {
    test('price × OI matrix — chaaron signal', () {
      expect(
        classifyIndexSignal(priceChangePct: 2, oiChangePct: 5),
        IndexOiSignal.longBuildup,
      );
      expect(
        classifyIndexSignal(priceChangePct: -2, oiChangePct: 5),
        IndexOiSignal.shortBuildup,
      );
      expect(
        classifyIndexSignal(priceChangePct: 2, oiChangePct: -5),
        IndexOiSignal.shortCovering,
      );
      expect(
        classifyIndexSignal(priceChangePct: -2, oiChangePct: -5),
        IndexOiSignal.longUnwinding,
      );
      // Price flat par OI badha — direction ka pata nahi, flat hi honest.
      expect(
        classifyIndexSignal(priceChangePct: 0.01, oiChangePct: 40),
        IndexOiSignal.flat,
      );
    });

    test('default filter Balanced (OI ≥ 5000 · |ΔOI%| ≥ 10)', () {
      expect(IndexOiFilter.balanced.minOi, 5000);
      expect(IndexOiFilter.balanced.minOiChangePct, 10);
      expect(IndexOiFilter.presets.first, IndexOiFilter.balanced);

      final nse = parseIndexOptionOi(_nseCsv, day, source: 'NSE');
      final nifty = nse.byUnderlying['NIFTY']!;
      final expiry = DateTime(2026, 10, 6);
      final builds = nifty.topBuilds(
        expiry: expiry,
        filter: IndexOiFilter.balanced,
        sort: IndexOiSort.byQty,
      );
      // 25000 CE: OI 4L, ΔOI +40k (prev 3.6L → +11.1%) → build.
      expect(builds.map((l) => l.strike), contains(25000));
      expect(builds.first.optionType, 'CE');

      final unwinds = nifty.topUnwinds(
        expiry: expiry,
        filter: IndexOiFilter.balanced,
        sort: IndexOiSort.byQty,
      );
      // 25000 PE: OI 6L, ΔOI −1.2L (prev 7.2L → −16.7%) → unwind.
      expect(unwinds.map((l) => l.strike), contains(25000));
      expect(unwinds.first.optionType, 'PE');
      expect(unwinds.first.signal.isUnwind, isTrue);
    });

    test('expiry summary — har expiry ki ek line (2030 bhi)', () {
      final nse = parseIndexOptionOi(_nseCsv, day, source: 'NSE');
      final nifty = nse.byUnderlying['NIFTY']!;
      final rows = nifty.expiryRows();
      expect(rows.length, 2);
      expect(rows.last.expiry, DateTime(2030, 6, 25));
      // Din = trade date se.
      expect(rows.last.daysTo(day), greaterThan(1000));
      // 2030 wali expiry: ek CE, ΔOI +5000, OI 25000.
      expect(rows.last.summary.netOiChange, 5000);
      expect(rows.last.summary.builds, 1);
      expect(rows.last.strikes, 1);
      // Index level file se (guess nahi).
      expect(nifty.indexLevelOn(DateTime(2026, 10, 6)), 25050);
    });
  });

  group('screen', () {
    IndexOiService fakeService({bool bseFails = false}) => IndexOiService(
      clock: () => day,
      fetchNse: (uri) async => _nseCsv.codeUnits,
      fetchBse: (uri) async {
        if (bseFails) throw const IndexOiFetchException('BSE 403');
        return _bseCsv.codeUnits;
      },
    );

    testWidgets('khulti hai, NIFTY default, saari 2 expiries dropdown me', (
      tester,
    ) async {
      await tester.pumpWidget(
        MaterialApp(home: IndexOiScreen(service: fakeService())),
      );
      await tester.pumpAndSettle();

      expect(find.text('📈 Index OI Build–Unwind'), findsOneWidget);
      expect(find.textContaining('Official NSE + BSE'), findsOneWidget);
      // Expiry dropdown me 2 expiries (2026 + 2030) — dono label.
      expect(find.textContaining('25 Jun 2030'), findsWidgets);
      // Saari expiries ka card.
      expect(find.text('📅 Saari expiries — ek nazar me'), findsOneWidget);
      // Build/unwind cards.
      expect(find.text('🔨 Top build-ups'), findsOneWidget);
      expect(find.text('🌀 Top unwinds'), findsOneWidget);
      expect(tester.takeException(), isNull);
    });

    testWidgets('BSE fail → NSE data dikhe + reason screen par', (
      tester,
    ) async {
      await tester.pumpWidget(
        MaterialApp(home: IndexOiScreen(service: fakeService(bseFails: true))),
      );
      await tester.pumpAndSettle();
      expect(find.textContaining('BSE F&O bhavcopy nahi mili'), findsOneWidget);
      // NSE ka data phir bhi render hai.
      expect(find.text('🔨 Top build-ups'), findsOneWidget);
      expect(tester.takeException(), isNull);
    });

    testWidgets('expiry summary line par tap → wahi expiry select', (
      tester,
    ) async {
      await tester.pumpWidget(
        MaterialApp(home: IndexOiScreen(service: fakeService())),
      );
      await tester.pumpAndSettle();

      // Default current expiry (06 Oct 2026) ka chain — strike 25000 dikhta hai.
      expect(find.text('25000'), findsWidgets);

      // 2030 wali line tak scroll, phir tap.
      final row = find.text('25 Jun 2030').first;
      await tester.ensureVisible(row);
      await tester.pumpAndSettle();
      await tester.tap(row);
      await tester.pumpAndSettle();

      // Chain ab 2030 ki expiry ka — 30000 strike dikhta hai, 25000 nahi.
      await tester.ensureVisible(find.text('30000').last);
      expect(find.text('30000'), findsWidgets);
      expect(tester.takeException(), isNull);
    });
  });
}
