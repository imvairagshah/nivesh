// swift-tools-version: 5.9
// The swift-tools-version declares the minimum version of Swift required to build this package.

import PackageDescription

let package = Package(
    name: "wakelock_plus",
    platforms: [
        .iOS("13.0"),
        .tvOS("13.0")
    ],
    products: [
        .library(name: "wakelock-plus", targets: ["wakelock_plus"])
    ],
    dependencies: [
        .package(name: "FlutterFramework", path: "../FlutterFramework")
    ],
    targets: [
        .target(
            name: "wakelock_plus",
            dependencies: [
                .product(name: "FlutterFramework", package: "FlutterFramework")
            ],
            resources: [
                .process("Resources")
            ],
            cSettings: [
                .headerSearchPath("include/wakelock_plus")
            ]
        )
    ]
)