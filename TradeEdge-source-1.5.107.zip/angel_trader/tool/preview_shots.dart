// Screenshot harness (not part of the suite): renders the redesigned screens
// to PNG so the layout can be eyeballed without a device.
//   flutter test tool/preview_shots.dart
import 'dart:io';
import 'dart:ui' as ui;

import 'package:angel_trader/app.dart';
import 'package:angel_trader/core/theme/app_theme.dart';
import 'package:angel_trader/features/alerts/alerts_center.dart';
import 'package:angel_trader/features/equity/equity_hub_screen.dart';
import 'package:angel_trader/features/extra/extra_hub_screen.dart';
import 'package:angel_trader/features/fno/fno_hub_config.dart';
import 'package:angel_trader/features/help/tool_faq.dart';
import 'package:angel_trader/features/help/tool_faq_screen.dart';
import 'package:angel_trader/features/fno/fno_hub_screen.dart';
import 'package:angel_trader/features/auth/login_screen.dart';
import 'package:angel_trader/features/shell/home_hub_screen.dart';
import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/features/settings/settings_provider.dart';
import 'package:angel_trader/services/auth_service.dart';
import 'package:angel_trader/services/secure_store.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';

const _fonts = '/usr/local/sdk/flutter/bin/cache/artifacts/material_fonts';

Future<void> _loadFonts() async {
  Future<void> load(String family, List<String> files) async {
    final loader = FontLoader(family);
    for (final f in files) {
      final bytes = File('$_fonts/$f').readAsBytesSync();
      loader.addFont(Future.value(ByteData.view(bytes.buffer)));
    }
    await loader.load();
  }

  await load('Roboto', [
    'Roboto-Regular.ttf',
    'Roboto-Medium.ttf',
    'Roboto-Bold.ttf',
    'Roboto-Black.ttf',
  ]);
  await load('MaterialIcons', ['MaterialIcons-Regular.otf']);
}

Future<void> shoot(
  WidgetTester tester,
  Widget child,
  String name, {
  Brightness brightness = Brightness.light,
}) async {
  await tester.binding.setSurfaceSize(const Size(392, 844));
  final key = GlobalKey();
  await tester.pumpWidget(
    RepaintBoundary(
      key: key,
      child: MultiProvider(
        providers: [
          ChangeNotifierProvider<AuthService>(
            create: (_) => AuthService(store: SecureStore()),
          ),
          ChangeNotifierProvider<AlertsCenter>.value(
            value: AlertsCenter.instance,
          ),
          ChangeNotifierProvider<SettingsProvider>(
            create: (_) => SettingsProvider(SettingsDao(AppDatabase.instance)),
          ),
        ],
        child: MaterialApp(
          debugShowCheckedModeBanner: false,
          // Harness-only: test VM ka default font Ahem hai (solid blocks);
          // AppBar title style theme se aata hai isliye usme family set karni
          // padti hai. Asli device par Roboto system font hai.
          theme:
              (brightness == Brightness.dark
                      ? AppTheme.dark()
                      : AppTheme.light())
                  .copyWith(
                    textTheme:
                        (brightness == Brightness.dark
                                ? AppTheme.dark()
                                : AppTheme.light())
                            .textTheme
                            .apply(fontFamily: 'Roboto'),
                    appBarTheme:
                        (brightness == Brightness.dark
                                ? AppTheme.dark()
                                : AppTheme.light())
                            .appBarTheme
                            .copyWith(
                              titleTextStyle: AppTheme.light()
                                  .appBarTheme
                                  .titleTextStyle
                                  ?.copyWith(fontFamily: 'Roboto'),
                            ),
                  ),
          home: child,
        ),
      ),
    ),
  );
  await tester.runAsync(
    () => Future<void>.delayed(const Duration(milliseconds: 250)),
  );
  for (var i = 0; i < 20; i++) {
    await tester.pump(const Duration(milliseconds: 100));
  }
  final image = await tester.runAsync(() async {
    final boundary =
        key.currentContext!.findRenderObject()! as RenderRepaintBoundary;
    final ui.Image img = await boundary.toImage(pixelRatio: 2);
    final data = await img.toByteData(format: ui.ImageByteFormat.png);
    return data!.buffer.asUint8List();
  });
  File('/home/user/preview/$name.png')
    ..createSync(recursive: true)
    ..writeAsBytesSync(image!);
}

class _MemoryOrder implements FnoHubOrderStore {
  @override
  Future<Map<String, List<String>>> load() async => defaultHubOrder();

  @override
  Future<void> save(Map<String, List<String>> order) async {}
}

Future<void> shootSplash(WidgetTester tester, String name) async {
  final key = GlobalKey();
  await tester.binding.setSurfaceSize(const Size(392, 844));
  await tester.pumpWidget(
    RepaintBoundary(key: key, child: const AngelTraderApp()),
  );
  await tester.pump();
  // Assets async decode hote hain — test ke fake clock me wo complete nahi
  // hote, isliye ek asli (runAsync) pause + phir frames.
  await tester.runAsync(
    () => Future<void>.delayed(const Duration(milliseconds: 250)),
  );
  for (var i = 0; i < 20; i++) {
    await tester.pump(const Duration(milliseconds: 100));
  }
  final image = await tester.runAsync(() async {
    final boundary =
        key.currentContext!.findRenderObject()! as RenderRepaintBoundary;
    final ui.Image img = await boundary.toImage(pixelRatio: 2);
    final data = await img.toByteData(format: ui.ImageByteFormat.png);
    return data!.buffer.asUint8List();
  });
  File('/home/user/preview/$name.png')
    ..createSync(recursive: true)
    ..writeAsBytesSync(image!);
}

void main() {
  setUpAll(_loadFonts);

  testWidgets('splash', (t) async => shootSplash(t, 'splash'));
  testWidgets('home', (t) async => shoot(t, const HomeHubScreen(), 'home'));
  testWidgets(
    'equity',
    (t) async => shoot(t, const EquityHubScreen(), 'equity'),
  );
  testWidgets(
    'home_dark',
    (t) async => shoot(
      t,
      const HomeHubScreen(),
      'home_dark',
      brightness: Brightness.dark,
    ),
  );
  testWidgets(
    'fno_dark',
    (t) async => shoot(
      t,
      FnoHubScreen(orderStore: _MemoryOrder()),
      'fno_dark',
      brightness: Brightness.dark,
    ),
  );
  testWidgets(
    'login_dark',
    (t) async => shoot(
      t,
      LoginScreen(onBrowseOffline: () {}),
      'login_dark',
      brightness: Brightness.dark,
    ),
  );
  testWidgets(
    'equity_dark',
    (t) async => shoot(
      t,
      const EquityHubScreen(),
      'equity_dark',
      brightness: Brightness.dark,
    ),
  );
  testWidgets(
    'faq_dark',
    (t) async => shoot(
      t,
      const ToolFaqScreen(title: 'Equity · FAQ', entries: kEquityFaq),
      'faq_dark',
      brightness: Brightness.dark,
    ),
  );
  testWidgets(
    'faq',
    (t) async => shoot(
      t,
      const ToolFaqScreen(title: 'F&O · FAQ', entries: kFnoFaq),
      'faq',
    ),
  );
  testWidgets(
    'fno',
    (t) async => shoot(t, FnoHubScreen(orderStore: _MemoryOrder()), 'fno'),
  );
  testWidgets('extra', (t) async => shoot(t, const ExtraHubScreen(), 'extra'));
  testWidgets(
    'extra_dark',
    (t) async => shoot(
      t,
      const ExtraHubScreen(),
      'extra_dark',
      brightness: Brightness.dark,
    ),
  );
}
