// ---------------------------------------------------------------------------
// home_hub_screen.dart — TRADE EDGE ka ghar (1.5.96).
//
// Pehle app ek bottom-nav shell tha (IPO | Golden Cross | RSI | Paper |
// Reports). User ka naya flow:
//
//      Splash → Home → EQUITY ya F&O → us segment ke saare tools (icons)
//
// Isliye yahan sirf do bade cards hain — EQUITY (green, light card) aur F&O
// (navy). Dono ke andar jitne tools hain wo `equity_hub_screen.dart` aur
// `fno_hub_screen.dart` (icon grid) dikhate hain. Bottom nav hata diya gaya
// hai: wapas jaana back se hota hai, jo mobile par swabhavik hai.
//
// Yahan koi **nakli number** nahi dikhta: Nifty/Banknifty ka quote is app me
// index token se aata nahi, isliye snapshot ki jagah honest status card hai
// (login hua ya nahi, data kahan se aata hai).
// ---------------------------------------------------------------------------

import '../strategy_builder/strategy_builder_screen.dart';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/layout/desktop_layout.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/motion.dart';
import '../../core/widgets/brand.dart';
import '../../services/auth_service.dart';
import '../../services/notification_service.dart';
import '../alerts/alerts_center.dart';
import '../alerts/morning_brief_screen.dart';
import '../alerts/notifications_screen.dart';
import '../equity/equity_hub_screen.dart';
import '../extra/extra_hub_screen.dart';
import '../fno/fno_hub_screen.dart';
import '../settings/settings_screen.dart';

class HomeHubScreen extends StatefulWidget {
  const HomeHubScreen({super.key});

  @override
  State<HomeHubScreen> createState() => _HomeHubScreenState();
}

class _HomeHubScreenState extends State<HomeHubScreen> {
  @override
  void initState() {
    super.initState();
    // 1.5.75 — notification tap routing (payload → destination screen).
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      void route(String payload) {
        if (payload == 'morning_brief') {
          Navigator.of(context).push(
            MaterialPageRoute<void>(builder: (_) => const MorningBriefScreen()),
          );
        }
      }

      final pending = NotificationService.pendingPayload;
      if (pending != null) {
        NotificationService.pendingPayload = null;
        route(pending);
      }
      NotificationService.onPayload = route;
    });
  }

  void _open(Widget screen) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => screen));
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final wide = DesktopLayout.modeOf(context) != UiMode.compact;
    final auth = context.watch<AuthService>();

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            // Desktop par cards screen ki poori chaudai na lein.
            constraints: const BoxConstraints(maxWidth: 760),
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(
                wide ? 32 : 20,
                14,
                wide ? 32 : 20,
                26,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _HomeHeader(
                    loggedIn: auth.isLoggedIn,
                    onSearch: () => _open(const SettingsScreen()),
                    onBell: () => _open(const NotificationsScreen()),
                  ),
                  SizedBox(height: wide ? 34 : 26),
                  const FadeSlideIn(
                    index: 0,
                    child: Text(
                      'Aaj kaam kis\nsegment pe?',
                      style: TextStyle(
                        fontSize: 27,
                        height: 1.14,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -0.4,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Equity, F&O, Builder ya Extra — ek chuno, saare tools andar.',
                    style: TextStyle(
                      fontSize: 12.5,
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
                  SizedBox(height: wide ? 26 : 22),
                  const FadeSlideIn(index: 1, child: _EquityCard()),
                  const SizedBox(height: 14),
                  const FadeSlideIn(index: 2, child: _FnoCard()),
                  const SizedBox(height: 14),
                  const FadeSlideIn(index: 3, child: _BuilderCard()),
                  const SizedBox(height: 14),
                  const FadeSlideIn(index: 4, child: _ExtraCard()),
                  const SizedBox(height: 16),
                  FadeSlideIn(
                    index: 5,
                    child: _SessionCard(
                      loggedIn: auth.isLoggedIn,
                      onSettings: () => _open(const SettingsScreen()),
                    ),
                  ),
                  const SizedBox(height: 18),
                  Center(
                    child: Text(
                      'TRADE EDGE · paper trading only · no real orders',
                      style: TextStyle(
                        fontSize: 10,
                        letterSpacing: 0.6,
                        color: scheme.onSurfaceVariant.withValues(alpha: 0.75),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Header
// ---------------------------------------------------------------------------

class _HomeHeader extends StatelessWidget {
  const _HomeHeader({
    required this.loggedIn,
    required this.onSearch,
    required this.onBell,
  });

  final bool loggedIn;
  final VoidCallback onSearch;
  final VoidCallback onBell;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Row(
      children: [
        const BrandMark(size: 46),
        const SizedBox(width: 12),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            const BrandWordmark(fontSize: 15),
            const SizedBox(height: 3),
            Text(
              loggedIn ? 'Angel One connected' : 'Login baaki hai',
              style: TextStyle(
                fontSize: 10.5,
                fontWeight: FontWeight.w600,
                color: loggedIn ? Brand.green : scheme.error,
              ),
            ),
          ],
        ),
        const Spacer(),
        _RoundIcon(
          icon: Icons.search_rounded,
          tooltip: 'Settings — broker, data aur theme',
          onTap: onSearch,
        ),
        const SizedBox(width: 8),
        Consumer<AlertsCenter>(
          builder: (context, alerts, _) => _RoundIcon(
            icon: Icons.notifications_none_rounded,
            tooltip: 'Notifications — calls SL/target, price alerts, signals',
            badge: alerts.unreadCount > 0 ? '${alerts.unreadCount}' : null,
            onTap: onBell,
          ),
        ),
      ],
    );
  }
}

class _RoundIcon extends StatelessWidget {
  const _RoundIcon({
    required this.icon,
    required this.tooltip,
    required this.onTap,
    this.badge,
  });

  final IconData icon;
  final String tooltip;
  final VoidCallback onTap;
  final String? badge;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Tooltip(
      message: tooltip,
      child: Material(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap,
          child: Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: scheme.outlineVariant),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                Icon(icon, size: 18, color: scheme.onSurfaceVariant),
                if (badge != null)
                  Positioned(
                    right: 3,
                    top: 4,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      decoration: BoxDecoration(
                        color: scheme.error,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        badge!,
                        style: const TextStyle(
                          fontSize: 8.5,
                          fontWeight: FontWeight.w800,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// The two big choices
// ---------------------------------------------------------------------------

class _EquityCard extends StatelessWidget {
  const _EquityCard();

  static const List<String> _chips = [
    'IPO',
    'Golden Cross',
    'RSI',
    'Magic Formula',
    'Paper',
    'Reports',
  ];

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return _SegmentCard(
      onTap: () => Navigator.of(
        context,
      ).push(MaterialPageRoute<void>(builder: (_) => const EquityHubScreen())),
      background: scheme.surface,
      border: scheme.outlineVariant,
      accentBar: Brand.greenGradient(),
      iconBg: const Color(0xFFE7F8F0),
      icon: Icons.trending_up_rounded,
      iconColor: Brand.green,
      title: 'EQUITY',
      titleColor: scheme.onSurface,
      subtitle: '7 tools · screens + research',
      subtitleColor: scheme.onSurfaceVariant,
      chipBg: scheme.surfaceContainerHigh,
      chipFg: scheme.onSurfaceVariant,
      arrowBg: scheme.surfaceContainerHigh,
      arrowColor: scheme.onSurfaceVariant,
      chips: _chips,
    );
  }
}

class _FnoCard extends StatelessWidget {
  const _FnoCard();

  static const List<String> _chips = [
    'Study',
    'Advanced',
    'Bankex',
    'Stock OI',
    '52W · ATH',
    'Results',
  ];

  @override
  Widget build(BuildContext context) {
    return _SegmentCard(
      onTap: () => Navigator.of(
        context,
      ).push(MaterialPageRoute<void>(builder: (_) => const FnoHubScreen())),
      background: Brand.navy,
      border: Brand.navy,
      iconBg: Brand.greenBright.withValues(alpha: 0.18),
      icon: Icons.layers_rounded,
      iconColor: Brand.greenBright,
      title: 'F&O',
      titleColor: Colors.white,
      subtitle: '10 tools · options + study',
      subtitleColor: const Color(0xFF9DB0CC),
      chipBg: Colors.white.withValues(alpha: 0.08),
      chipFg: const Color(0xFFD5E2F7),
      arrowBg: Colors.white.withValues(alpha: 0.10),
      arrowColor: const Color(0xFFCFE1FF),
      chips: _chips,
      watermark: Icons.layers_rounded,
    );
  }
}

/// 1.5.102 — chautha segment card: BUILDER. User apne rules (indicator +
/// params + operator) chunta hai aur poora backtest + data report dekhta hai.
/// Triple RSI lab nahi — generic rule engine (fixed preset ko replace karta hai).
class _BuilderCard extends StatelessWidget {
  const _BuilderCard();

  static const List<String> _chips = [
    '10 Indicators',
    'Stocks + Index',
    'Daily · 15m · 5m',
    'Fundamentals',
    'Report',
    'Excel · Telegram',
  ];

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return _SegmentCard(
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute<void>(builder: (_) => const StrategyBuilderScreen()),
      ),
      background: scheme.surface,
      border: scheme.outlineVariant,
      accentBar: const LinearGradient(
        colors: [Color(0xFF7A5312), Color(0xFFC79A3E)],
      ),
      iconBg: scheme.surfaceContainerHigh,
      icon: Icons.rule_rounded,
      iconColor: const Color(0xFF7A5312),
      title: 'BUILDER',
      titleColor: scheme.onSurface,
      subtitle: 'Apni strategy · stocks + index backtest',
      subtitleColor: scheme.onSurfaceVariant,
      chipBg: scheme.surfaceContainerHigh,
      chipFg: scheme.onSurfaceVariant,
      arrowBg: scheme.surfaceContainerHigh,
      arrowColor: scheme.onSurfaceVariant,
      chips: _chips,
      watermark: Icons.rule_rounded,
    );
  }
}

/// 1.5.101 — teesra segment card: EXTRA. Telegram channels pehle Equity ke
/// Calls Board tile par the; user ne kaha "equity aur fno jaise alag section
/// bana do jisme aisi extra cheezein set kar sake" — isliye wo yahan aa gaye.
class _ExtraCard extends StatelessWidget {
  const _ExtraCard();

  static const List<String> _chips = [
    'Telegram',
    'Bot Export',
    'Alerts',
    'Brief',
    'Data',
  ];

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return _SegmentCard(
      onTap: () => Navigator.of(
        context,
      ).push(MaterialPageRoute<void>(builder: (_) => const ExtraHubScreen())),
      background: scheme.surface,
      border: scheme.outlineVariant,
      accentBar: const LinearGradient(
        colors: [Color(0xFF2C6BEF), Color(0xFF7FA8F5)],
      ),
      iconBg: scheme.surfaceContainerHigh,
      icon: Icons.extension_rounded,
      iconColor: Brand.blue,
      title: 'EXTRA',
      titleColor: scheme.onSurface,
      subtitle: '6 items · Telegram + more',
      subtitleColor: scheme.onSurfaceVariant,
      chipBg: scheme.surfaceContainerHigh,
      chipFg: scheme.onSurfaceVariant,
      arrowBg: scheme.surfaceContainerHigh,
      arrowColor: scheme.onSurfaceVariant,
      chips: _chips,
      watermark: Icons.extension_rounded,
    );
  }
}

class _SegmentCard extends StatelessWidget {
  const _SegmentCard({
    required this.onTap,
    required this.background,
    required this.border,
    required this.iconBg,
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.titleColor,
    required this.subtitle,
    required this.subtitleColor,
    required this.chipBg,
    required this.chipFg,
    required this.arrowBg,
    required this.arrowColor,
    required this.chips,
    this.accentBar,
    this.watermark,
  });

  final VoidCallback onTap;
  final Color background;
  final Color border;
  final LinearGradient? accentBar;
  final Color iconBg;
  final IconData icon;
  final Color iconColor;
  final String title;
  final Color titleColor;
  final String subtitle;
  final Color subtitleColor;
  final Color chipBg;
  final Color chipFg;
  final Color arrowBg;
  final Color arrowColor;
  final List<String> chips;
  final IconData? watermark;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: background,
      borderRadius: BorderRadius.circular(22),
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: border),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(
                  alpha: background == Brand.navy ? 0.18 : 0.06,
                ),
                blurRadius: 24,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          clipBehavior: Clip.antiAlias,
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 18),
          child: Stack(
            children: [
              if (watermark != null)
                Positioned(
                  right: -30,
                  bottom: -34,
                  child: Icon(
                    watermark,
                    size: 130,
                    color: Colors.white.withValues(alpha: 0.05),
                  ),
                ),
              if (accentBar != null)
                Positioned(
                  right: -20,
                  top: -20,
                  bottom: -18,
                  child: Container(width: 6, color: Brand.green),
                ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 46,
                        height: 46,
                        decoration: BoxDecoration(
                          color: iconBg,
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Icon(icon, size: 23, color: iconColor),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              title,
                              style: TextStyle(
                                fontSize: 19,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 0.8,
                                color: titleColor,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              subtitle,
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                color: subtitleColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          color: arrowBg,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Icon(
                          Icons.arrow_forward_rounded,
                          size: 16,
                          color: arrowColor,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Wrap(
                    spacing: 7,
                    runSpacing: 7,
                    children: [
                      for (final chip in chips)
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: chipBg,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            chip,
                            style: TextStyle(
                              fontSize: 10.5,
                              fontWeight: FontWeight.w700,
                              color: chipFg,
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Session / data status — honest, no invented numbers
// ---------------------------------------------------------------------------

class _SessionCard extends StatelessWidget {
  const _SessionCard({required this.loggedIn, required this.onSettings});

  final bool loggedIn;
  final VoidCallback onSettings;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 12, 14),
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Icon(
            loggedIn ? Icons.verified_rounded : Icons.lock_outline_rounded,
            size: 18,
            color: loggedIn ? Brand.green : scheme.error,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  loggedIn
                      ? 'Session chalu — data Angel One SmartAPI se'
                      : 'Login nahi hua — sirf cached data dikhega',
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'Prices/candles broker se aate hain; koi order app place nahi karta.',
                  style: TextStyle(
                    fontSize: 10.5,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          // Row ke andar button khud ko stretch kar deta tha (green bar
          // jaisa dikhta tha) — isliye fixed-size tap target.
          InkWell(
            onTap: onSettings,
            borderRadius: BorderRadius.circular(10),
            child: Container(
              height: 34,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Brand.green.withValues(alpha: 0.10),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Text(
                'Settings',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  color: Brand.greenDeep,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
