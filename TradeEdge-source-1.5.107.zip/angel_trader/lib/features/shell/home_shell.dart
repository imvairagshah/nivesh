// ---------------------------------------------------------------------------
// home_shell.dart — app ka root shell (1.5.96 redesign).
//
// Pehle: bottom navigation ke paanch tabs (IPO | Golden Cross | RSI | Paper |
// Reports) + desktop rail. Ab **nahi** — user ka chuna hua flow:
//
//      Splash → (login) → Home → EQUITY / F&O → tools → back
//
// Isliye shell itna hi karta hai: HomeHubScreen dikhana. Har tool apni
// normal route par khulta hai (back se wapas), jo mobile par swabhavik hai
// aur desktop par bhi wahi ek-scroll behaviour deta hai.
//
// Yahan notification routing (1.5.75) HomeHubScreen ke andar shift ho gaya
// hai — shell ke paas ab koi tab state nahi hai jo route badalne par reset
// ho.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';

import 'home_hub_screen.dart';

class HomeShell extends StatelessWidget {
  const HomeShell({super.key});

  @override
  Widget build(BuildContext context) => const HomeHubScreen();
}
