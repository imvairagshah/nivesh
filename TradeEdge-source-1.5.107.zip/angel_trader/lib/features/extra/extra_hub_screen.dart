// ---------------------------------------------------------------------------
// extra_hub_screen.dart — EXTRA section (1.5.101).
//
// Equity aur F&O ke bagal me teesra hub. Yahan **wo sab** hai jo kisi ek
// segment ka nahi: Telegram (channels + bot export), alerts, morning brief,
// data sources aur about. Design wahi hai — 2 column icon grid (desktop par
// 4), barabar tiles, sirf icon + naam (1.5.97 ka rule: tile par description
// nahi), aur poora page ek hi scroll me (1.5.92).
//
// Tools ki list `extra_hub_config.dart` me hai — naya item wahan add karo.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_theme.dart';
import '../../core/widgets/brand.dart';
import '../../core/widgets/edge_header.dart';
import '../../core/widgets/page_scroll.dart';
import '../../data/local/dao/settings_dao.dart';
import '../alerts/morning_brief_screen.dart';
import '../alerts/notifications_screen.dart';
import '../calls_board/calls_screen.dart';
import '../help/tool_faq.dart';
import '../help/tool_faq_screen.dart';
import '../settings/settings_provider.dart';
import '../settings/settings_screen.dart';
import 'extra_hub_config.dart';

class ExtraHubScreen extends StatelessWidget {
  const ExtraHubScreen({super.key});

  void _open(BuildContext context, String id) {
    final route = switch (id) {
      'calls' => MaterialPageRoute<void>(builder: (_) => const CallsScreen()),
      'telegram_bot' => MaterialPageRoute<void>(
        builder: (_) => const TelegramBotSettingsScreen(),
      ),
      'alerts' => MaterialPageRoute<void>(
        builder: (_) => const NotificationsScreen(),
      ),
      'morning_brief' => MaterialPageRoute<void>(
        builder: (_) => const MorningBriefScreen(),
      ),
      'data_sources' => MaterialPageRoute<void>(
        builder: (_) => const DataSourcesScreen(),
      ),
      'about' => MaterialPageRoute<void>(
        builder: (_) => ToolFaqScreen(
          title: 'About & Help',
          entries: kExtraFaq,
          header: const _AboutBox(),
        ),
      ),
      _ => null,
    };
    if (route == null) return;
    Navigator.of(context).push(route);
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: EdgeAppBar(
        title: 'Extra',
        subtitle: 'Telegram · alerts · data',
        actions: [
          IconButton(
            tooltip: 'FAQ — har extra item ka brief',
            icon: const Icon(Icons.help_outline_rounded),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => const ToolFaqScreen(
                  title: 'Extra · FAQ',
                  entries: kExtraFaq,
                ),
              ),
            ),
          ),
        ],
      ),
      body: PageScroll.children([
        Text(
          'Wo cheezein jo ek segment ki nahi — Telegram, alerts, data aur app '
          'ki jaankari. Equity/F&O ke saare tools apne hub me hi hain.',
          style: TextStyle(
            fontSize: 11.5,
            height: 1.5,
            color: scheme.onSurfaceVariant,
          ),
        ),
        const SizedBox(height: 12),
        _ExtraGrid(tools: kExtraTools, onTap: (id) => _open(context, id)),
        const SizedBox(height: 14),
        _SetupCard(onOpen: () => _open(context, 'telegram_bot')),
        const SizedBox(height: 16),
        _FaqButton(
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute<void>(
              builder: (_) =>
                  const ToolFaqScreen(title: 'Extra · FAQ', entries: kExtraFaq),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Center(
          child: Text(
            'TRADE EDGE · paper trading only',
            style: TextStyle(
              fontSize: 10,
              letterSpacing: 0.6,
              color: scheme.onSurfaceVariant.withValues(alpha: 0.75),
            ),
          ),
        ),
      ], padding: const EdgeInsets.fromLTRB(16, 8, 16, 24)),
    );
  }
}

// ---------------------------------------------------------------------------
// Grid — Equity/F&O tiles ke bilkul barabar (1.5.97: same size)
// ---------------------------------------------------------------------------

class _ExtraGrid extends StatelessWidget {
  const _ExtraGrid({required this.tools, required this.onTap});

  final List<ExtraTool> tools;
  final void Function(String id) onTap;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final columns = constraints.maxWidth >= 900
            ? 4
            : (constraints.maxWidth >= 620 ? 3 : 2);
        const gap = 11.0;
        final width = (constraints.maxWidth - gap * (columns - 1)) / columns;
        return Wrap(
          spacing: gap,
          runSpacing: gap,
          children: [
            for (final tool in tools)
              SizedBox(
                width: width,
                child: _ExtraTile(tool: tool, onTap: () => onTap(tool.id)),
              ),
          ],
        );
      },
    );
  }
}

class _ExtraTile extends StatelessWidget {
  const _ExtraTile({required this.tool, required this.onTap});

  final ExtraTool tool;
  final VoidCallback onTap;

  /// Equity/F&O tiles ki hi height — sab barabar.
  static const double height = 96;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Material(
      color: scheme.surface,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Container(
          height: height,
          padding: const EdgeInsets.fromLTRB(13, 12, 13, 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: scheme.outlineVariant),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: scheme.primaryContainer,
                      borderRadius: BorderRadius.circular(11),
                    ),
                    child: Icon(tool.icon, size: 19, color: Brand.green),
                  ),
                  const Spacer(),
                  if (tool.badge != null)
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        // 1.5.100 ka sabak: badge ka chip accent ka tint hai,
                        // to text accent bhi chip par 4.5:1 de (scheme role).
                        color: scheme.surfaceContainerHigh,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        tool.badge!,
                        style: TextStyle(
                          fontSize: 8,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.5,
                          color: scheme.onSurfaceVariant,
                        ),
                      ),
                    ),
                ],
              ),
              const Spacer(),
              Text(
                tool.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 12.5,
                  height: 1.15,
                  fontWeight: FontWeight.w800,
                  color: scheme.onSurface,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Chhota setup card — Telegram bot token/chat id ka rasta seedha dikhe.
class _SetupCard extends StatelessWidget {
  const _SetupCard({required this.onOpen});

  final VoidCallback onOpen;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final settings = context.watch<SettingsProvider>().settings;
    final done =
        settings.telegramBotToken.isNotEmpty &&
        settings.telegramChatId.isNotEmpty;

    return Material(
      color: scheme.surface,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onOpen,
        child: Container(
          padding: const EdgeInsets.fromLTRB(14, 12, 12, 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: scheme.outlineVariant),
          ),
          child: Row(
            children: [
              Icon(
                done
                    ? Icons.check_circle_rounded
                    : Icons.settings_suggest_rounded,
                size: 20,
                color: done ? Brand.green : scheme.onSurfaceVariant,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      done
                          ? 'Telegram bot ready'
                          : 'Setup — Telegram bot token + chat id',
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w800,
                        color: scheme.onSurface,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      done
                          ? 'Study/scan ki file seedha Telegram par bhej sakte hain.'
                          : 'Bhar diya to har export "Telegram pe bhejo" kar sakta hai.',
                      style: TextStyle(
                        fontSize: 10.5,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.chevron_right_rounded, color: scheme.onSurfaceVariant),
            ],
          ),
        ),
      ),
    );
  }
}

class _FaqButton extends StatelessWidget {
  const _FaqButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Material(
      color: scheme.surface,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.fromLTRB(14, 13, 12, 13),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: scheme.outlineVariant),
          ),
          child: Row(
            children: [
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  color: scheme.primaryContainer,
                  borderRadius: BorderRadius.circular(9),
                ),
                child: const Icon(
                  Icons.help_outline_rounded,
                  size: 17,
                  color: Brand.green,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'FAQ — har extra item ka brief',
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w800,
                        color: scheme.onSurface,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Telegram, alerts, data sources — sab yahan samjhaya hai.',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 10.5,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.chevron_right_rounded, color: scheme.onSurfaceVariant),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Telegram bot export — wahi do setting keys jo Settings me the (ek hi sach,
// do jagah se pahunchne ka rasta). Settings > F&O card bhi inhi ko edit karta
// hai, isliye value dono taraf same rehti hai.
// ---------------------------------------------------------------------------

class TelegramBotSettingsScreen extends StatefulWidget {
  const TelegramBotSettingsScreen({super.key});

  @override
  State<TelegramBotSettingsScreen> createState() =>
      _TelegramBotSettingsScreenState();
}

class _TelegramBotSettingsScreenState extends State<TelegramBotSettingsScreen> {
  late final SettingsProvider _settings = context.read<SettingsProvider>();
  late final TextEditingController _token = TextEditingController(
    text: _settings.settings.telegramBotToken,
  );
  late final TextEditingController _chat = TextEditingController(
    text: _settings.settings.telegramChatId,
  );

  @override
  void dispose() {
    _token.dispose();
    _chat.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    await context.read<SettingsProvider>().setTelegramCredentials(
      botToken: _token.text,
      chatId: _chat.text,
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Telegram settings save ho gayi.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: const EdgeAppBar(
        title: 'Telegram Bot Export',
        subtitle: 'Study/scan file seedha Telegram par',
      ),
      body: PageScroll.children([
        Text(
          'Bot @BotFather se banao, token yahan paste karo, phir us bot ko ek '
          'baar /start bhejo. Chat id ke liye @userinfobot se apna id le lo '
          '(group me -100… hota hai).',
          style: TextStyle(
            fontSize: 11.5,
            height: 1.5,
            color: scheme.onSurfaceVariant,
          ),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: _token,
          style: const TextStyle(fontSize: 13),
          decoration: const InputDecoration(
            labelText: 'Bot token (optional)',
            hintText: '123456:ABC-DEF…',
            isDense: true,
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _chat,
          style: const TextStyle(fontSize: 13),
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
            labelText: 'Chat id (optional)',
            hintText: '123456789',
            isDense: true,
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 14),
        FilledButton.icon(
          onPressed: _save,
          icon: const Icon(Icons.save_rounded),
          label: const Text('Save'),
        ),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: scheme.surfaceContainerLow,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: scheme.outlineVariant),
          ),
          child: Text(
            'Bhar diya to 3-Month Study / Study Advance ke export menu me '
            '"Telegram pe bhejo" dikhega — XLSX/CSV file seedha us chat me '
            'jaayegi. Khaali chhodo to kuch nahi bhejta (file phone par hi '
            'rehti hai).',
            style: TextStyle(
              fontSize: 11,
              height: 1.5,
              color: scheme.onSurfaceVariant,
            ),
          ),
        ),
        const SizedBox(height: 14),
        TextButton.icon(
          onPressed: () => Navigator.of(context).push(
            MaterialPageRoute<void>(builder: (_) => const SettingsScreen()),
          ),
          icon: const Icon(Icons.tune_rounded, size: 18),
          label: const Text('Poori Settings kholo'),
        ),
      ], padding: const EdgeInsets.fromLTRB(16, 10, 16, 24)),
    );
  }
}

// ---------------------------------------------------------------------------
// Data Sources — "data kahan se aata hai" ek jagah, imaandari se.
// Koi API key ya naya secret nahi: sirf wahi sources jo app asli me use karta
// hai, aur unka fail hone par kya hota hai.
// ---------------------------------------------------------------------------

class DataSourcesScreen extends StatelessWidget {
  const DataSourcesScreen({super.key});

  static const List<(String, String, String)> _sources = [
    (
      'Angel One SmartAPI',
      'Official',
      'Login, scrip master, candles, quotes aur option greeks. Ye primary '
          'source hai — sab pehle yahin se aata hai.',
    ),
    (
      'NSE bhavcopy / archives',
      'Official',
      'EOD spot + F&O bhavcopy (F&O Scanner, OI build-unwind), index lists, '
          'announcements, results/dividend calendar.',
    ),
    (
      'NSE RSS + fo_secban + Telegram (t.me/s/)',
      'Official / public',
      'News screen aur Calls Board. Telegram sirf public channel ke web page '
          'se padha jaata hai — koi login nahi.',
    ),
    (
      'Yahoo Finance',
      'Fallback only',
      'Sirf tab jab official source se value na mile — aur screen par '
          '"Yahoo" likha hota hai. Formula isse nahi badalta.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final dao = context.read<SettingsDao>();

    return Scaffold(
      appBar: const EdgeAppBar(
        title: 'Data Sources',
        subtitle: 'Kaunsa number kahan se aata hai',
      ),
      body: PageScroll.children([
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: scheme.surfaceContainerLow,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: scheme.outlineVariant),
          ),
          child: Text(
            'Rule: official data pehle. Jo value kisi source se nahi mili, wo '
            '"—" rehti hai — guess nahi hoti. Estimate ho to "est." likha '
            'hota hai.',
            style: TextStyle(
              fontSize: 11.5,
              height: 1.5,
              color: scheme.onSurfaceVariant,
            ),
          ),
        ),
        const SizedBox(height: 12),
        for (final (name, tag, detail) in _sources) ...[
          Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.fromLTRB(13, 12, 13, 12),
            decoration: BoxDecoration(
              color: scheme.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: scheme.outlineVariant),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        name,
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w800,
                          color: scheme.onSurface,
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 7,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: scheme.surfaceContainerHigh,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        tag,
                        style: TextStyle(
                          fontSize: 9,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.4,
                          color: scheme.onSurfaceVariant,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 5),
                Text(
                  detail,
                  style: TextStyle(
                    fontSize: 11,
                    height: 1.5,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ],
        const SizedBox(height: 6),
        FutureBuilder<String>(
          future: _refreshedOn(dao),
          builder: (context, snap) => Text(
            'Scrip master / cache ki last update: ${snap.data ?? '—'}',
            style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
          ),
        ),
        const SizedBox(height: 12),
        TextButton.icon(
          onPressed: () => Navigator.of(context).push(
            MaterialPageRoute<void>(builder: (_) => const SettingsScreen()),
          ),
          icon: const Icon(Icons.refresh_rounded, size: 18),
          label: const Text('Settings me refresh/clear'),
        ),
      ], padding: const EdgeInsets.fromLTRB(16, 10, 16, 24)),
    );
  }

  /// Scrip master kab update hua — settings table se (na mile to "—").
  Future<String> _refreshedOn(SettingsDao dao) async {
    try {
      final raw = await dao.raw();
      final value =
          raw['scrip_master_updated_at'] ??
          raw['last_scrip_master_sync'] ??
          raw['scripMasterUpdatedAt'];
      if (value == null || value.isEmpty) return '—';
      return value;
    } catch (_) {
      return '—';
    }
  }
}

/// About box — FAQ ke saath, sabse upar (version + disclaimer).
class _AboutBox extends StatefulWidget {
  const _AboutBox();

  @override
  State<_AboutBox> createState() => _AboutBoxState();
}

class _AboutBoxState extends State<_AboutBox> {
  String _version = '—';

  @override
  void initState() {
    super.initState();
    PackageInfo.fromPlatform()
        .then((info) {
          if (mounted) setState(() => _version = info.version);
        })
        .catchError((_) => null);
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const BrandMark(size: 26),
              const SizedBox(width: 8),
              Text(
                'TRADE EDGE',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                  color: scheme.onSurface,
                ),
              ),
              const Spacer(),
              Text(
                'v$_version',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: scheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            'Angel One SmartAPI par bana, par Angel One ka product nahi. Har '
            'order paper trading hai — koi asli order broker ko nahi jaata '
            '(order place karne ki line hi nahi hai). Koi tip/suggestion nahi: '
            'jo bhi aata hai wo official data par mechanical rules se aata hai.',
            style: TextStyle(
              fontSize: 11,
              height: 1.5,
              color: scheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}
