// ---------------------------------------------------------------------------
// extra_hub_config.dart — "EXTRA" section ka ek hi sach (1.5.101).
//
// User: *"Telegram channel wala option equity aur fno jaise ek alag section
// bana do, jisme aisi extra cheezein set kar sake."*
//
// Isliye Equity/F&O ke bagal me teesra card — **EXTRA** — jahan wo cheezein
// rehti hain jo kisi ek segment ki nahi hain:
//
//   • Telegram Channels  — Calls Board (pehle Equity me tha, yahan shift)
//   • Telegram Bot       — study/scan XLSX seedha Telegram par
//   • Alerts & Notifications — SL/target, price alerts, signals
//   • Morning Brief      — Top 20 list
//   • Data Sources       — data kahan se aata hai (official / fallback)
//   • About & Help       — version, FAQ, disclaimer
//
// Naya "extra" add karna ho to: yahan [kExtraTools] me entry, `_openExtra()`
// me ek case (ya seedhi screen), aur `tool_faq.dart` me FAQ entry — test
// `extra_hub_test.dart` teeno ka match pin karta hai.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';

/// Ek extra tile — Equity/F&O tiles ki tarah fixed height grid.
class ExtraTool {
  const ExtraTool({
    required this.id,
    required this.title,
    required this.icon,
    this.badge,
  });

  /// Route key (screen `extra_hub_screen.dart` me khulti hai).
  final String id;

  /// Tile ka naam — FAQ entry ka title bhi yahi hota hai.
  final String title;
  final IconData icon;

  /// 'LIVE' / 'NAYA' — null = koi badge nahi.
  final String? badge;
}

/// EXTRA ke saare tools, isi tarteeb me.
const List<ExtraTool> kExtraTools = [
  ExtraTool(
    id: 'calls',
    title: 'Telegram Channels',
    icon: Icons.cell_tower_rounded,
    badge: 'LIVE',
  ),
  ExtraTool(
    id: 'telegram_bot',
    title: 'Telegram Bot Export',
    icon: Icons.send_rounded,
  ),
  ExtraTool(
    id: 'alerts',
    title: 'Alerts & Notifications',
    icon: Icons.notifications_active_rounded,
    badge: 'LIVE',
  ),
  ExtraTool(
    id: 'morning_brief',
    title: 'Morning Brief',
    icon: Icons.wb_sunny_rounded,
  ),
  ExtraTool(
    id: 'data_sources',
    title: 'Data Sources',
    icon: Icons.cloud_sync_rounded,
  ),
  ExtraTool(
    id: 'about',
    title: 'About & Help',
    icon: Icons.info_outline_rounded,
  ),
];
