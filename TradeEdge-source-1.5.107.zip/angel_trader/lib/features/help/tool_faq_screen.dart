// ---------------------------------------------------------------------------
// tool_faq_screen.dart — FAQ screen (1.5.97).
//
// User decision ke hisaab se: tiles par chhoti description nahi, aur har tool
// ka brief + details yahan. Ek hi screen dono sections ke liye — bas list
// pass hoti hai (equity / F&O / dono).
//
// Sab kuch khula hua dikhta hai (collapse karne ki zaroorat nahi), ek hi page
// scroll (PageScroll), aur upar search — 9–8 entries me bhi seedha tool
// dhoondhna aasan ho.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../core/widgets/edge_header.dart';
import '../../core/widgets/page_scroll.dart';
import 'tool_faq.dart';

class ToolFaqScreen extends StatefulWidget {
  const ToolFaqScreen({
    super.key,
    required this.title,
    required this.entries,
    this.header,
  });

  final String title;
  final List<ToolFaq> entries;

  /// Search ke upar ek extra box (EXTRA → About & Help ka version/disclaimer
  /// card, 1.5.101). Null = sirf intro text.
  final Widget? header;

  @override
  State<ToolFaqScreen> createState() => _ToolFaqScreenState();
}

class _ToolFaqScreenState extends State<ToolFaqScreen> {
  final TextEditingController _query = TextEditingController();
  String _needle = '';

  @override
  void dispose() {
    _query.dispose();
    super.dispose();
  }

  List<ToolFaq> get _visible {
    final q = _needle.trim().toLowerCase();
    if (q.isEmpty) return widget.entries;
    return widget.entries
        .where(
          (e) =>
              e.title.toLowerCase().contains(q) ||
              e.summary.toLowerCase().contains(q) ||
              e.points.any((p) => p.toLowerCase().contains(q)),
        )
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final rows = _visible;

    return Scaffold(
      appBar: EdgeAppBar(
        title: widget.title,
        subtitle: 'Har tool ka kaam aur limit',
      ),
      body: PageScroll.children([
        Text(
          'Har tool ka kaam, uska data source aur uski limit — chhota sa '
          'brief. Jo cheez app me nahi hoti, wo yahan bhi nahi likhi hai.',
          style: TextStyle(
            fontSize: 12,
            height: 1.45,
            color: scheme.onSurfaceVariant,
          ),
        ),
        if (widget.header != null) ...[
          const SizedBox(height: 12),
          widget.header!,
        ],
        const SizedBox(height: 14),
        TextField(
          controller: _query,
          onChanged: (v) => setState(() => _needle = v),
          textInputAction: TextInputAction.search,
          decoration: InputDecoration(
            hintText: 'Tool dhoondo (jaise: RSI, Bankex, dividend)',
            prefixIcon: const Icon(Icons.search_rounded, size: 20),
            isDense: true,
            suffixIcon: _needle.isEmpty
                ? null
                : IconButton(
                    tooltip: 'Search clear',
                    icon: const Icon(Icons.close_rounded, size: 18),
                    onPressed: () {
                      _query.clear();
                      setState(() => _needle = '');
                    },
                  ),
          ),
        ),
        const SizedBox(height: 16),
        if (rows.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 40),
            child: Center(
              child: Text(
                'Is naam ka koi tool nahi mila.',
                style: TextStyle(
                  fontSize: 12.5,
                  color: scheme.onSurfaceVariant,
                ),
              ),
            ),
          )
        else
          for (final entry in rows) ...[
            _FaqCard(entry: entry),
            const SizedBox(height: 12),
          ],
        const SizedBox(height: 6),
        Center(
          child: Text(
            'TRADE EDGE · paper trading only · no real orders',
            style: TextStyle(
              fontSize: 10,
              letterSpacing: 0.6,
              color: scheme.onSurfaceVariant.withValues(alpha: 0.75),
            ),
          ),
        ),
      ]),
    );
  }
}

class _FaqCard extends StatelessWidget {
  const _FaqCard({required this.entry});

  final ToolFaq entry;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: scheme.primaryContainer,
                  borderRadius: BorderRadius.circular(11),
                ),
                child: Icon(entry.icon, size: 18, color: Brand.green),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  entry.title,
                  style: const TextStyle(
                    fontSize: 13.5,
                    fontWeight: FontWeight.w800,
                    height: 1.25,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            entry.summary,
            style: TextStyle(
              fontSize: 12,
              height: 1.45,
              color: scheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 10),
          for (final point in entry.points)
            Padding(
              padding: const EdgeInsets.only(bottom: 7),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: Container(
                      width: 5,
                      height: 5,
                      decoration: const BoxDecoration(
                        color: Brand.green,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Text(
                      point,
                      style: const TextStyle(fontSize: 11.5, height: 1.45),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
