// ---------------------------------------------------------------------------
// strategy_indicators.dart — Strategy Builder ke saare indicator maths.
//
// Sab kuch **pure** hai: koi Flutter, koi network, koi clock nahi. Isliye har
// indicator ka number ek test se pin ho sakta hai (aur ek hi jagah define hota
// hai). Series hamesha oldest → newest hoti hai, aur output me wahi length
// hoti hai — jahan value nahi ban sakti (warm-up) wahan `null`.
//
// 1.5.102 ke 10 indicators:
//   SMA · EMA · RSI (Wilder) · MACD · Bollinger Bands · ATR · ADX/DI ·
//   Stochastic %K · Volume SMA · 52-week range % · ROC (momentum)
// ---------------------------------------------------------------------------

import 'dart:math' as math;

/// Ek OHLCV bar — engine ka input (Candle se copy, taaki engine Flutter-free
/// rahe aur tests me plain bars pass ho sakein).
class Bar {
  const Bar({
    required this.time,
    required this.open,
    required this.high,
    required this.low,
    required this.close,
    this.volume = 0,
  });

  final DateTime time;
  final double open;
  final double high;
  final double low;
  final double close;
  final int volume;
}

/// Ek indicator ka poora output — series + `null` ka matlab "abhi warm-up".
typedef Series = List<double?>;

// ---------------------------------------------------------------------------
// Moving averages
// ---------------------------------------------------------------------------

/// Simple moving average. Pehle `period - 1` bars par `null`.
Series sma(List<double> values, int period) {
  final out = List<double?>.filled(values.length, null);
  if (period <= 0 || values.length < period) return out;
  var run = 0.0;
  for (var i = 0; i < values.length; i++) {
    run += values[i];
    if (i >= period) run -= values[i - period];
    if (i >= period - 1) out[i] = run / period;
  }
  return out;
}

/// Exponential moving average. Seed = pehle `period` bars ka simple average
/// (taaki ek hi bar par do jagah do number na banein).
Series ema(List<double> values, int period) {
  final out = List<double?>.filled(values.length, null);
  if (period <= 0 || values.length < period) return out;
  var seed = 0.0;
  for (var i = 0; i < period; i++) {
    seed += values[i];
  }
  var prev = seed / period;
  out[period - 1] = prev;
  final k = 2 / (period + 1);
  for (var i = period; i < values.length; i++) {
    prev = values[i] * k + prev * (1 - k);
    out[i] = prev;
  }
  return out;
}

// ---------------------------------------------------------------------------
// RSI (Wilder) — jaise charting apps me hota hai
// ---------------------------------------------------------------------------

Series rsi(List<double> closes, [int period = 14]) {
  final out = List<double?>.filled(closes.length, null);
  if (closes.length <= period || period <= 0) return out;

  var gain = 0.0;
  var loss = 0.0;
  for (var i = 1; i <= period; i++) {
    final ch = closes[i] - closes[i - 1];
    gain += math.max(ch, 0);
    loss += math.max(-ch, 0);
  }
  var avgGain = gain / period;
  var avgLoss = loss / period;
  out[period] = _rsiFrom(avgGain, avgLoss);

  for (var i = period + 1; i < closes.length; i++) {
    final ch = closes[i] - closes[i - 1];
    avgGain = (avgGain * (period - 1) + math.max(ch, 0)) / period;
    avgLoss = (avgLoss * (period - 1) + math.max(-ch, 0)) / period;
    out[i] = _rsiFrom(avgGain, avgLoss);
  }
  return out;
}

double _rsiFrom(double avgGain, double avgLoss) =>
    avgLoss == 0 ? 100.0 : 100 - 100 / (1 + avgGain / avgLoss);

// ---------------------------------------------------------------------------
// MACD
// ---------------------------------------------------------------------------

class MacdResult {
  const MacdResult({required this.macd, required this.signal, this.histogram});

  final Series macd;
  final Series signal;
  final Series? histogram;
}

MacdResult macd(
  List<double> closes, {
  int fast = 12,
  int slow = 26,
  int signalPeriod = 9,
  bool withHistogram = true,
}) {
  final fastE = ema(closes, fast);
  final slowE = ema(closes, slow);
  final line = List<double?>.filled(closes.length, null);
  for (var i = 0; i < closes.length; i++) {
    final f = fastE[i];
    final s = slowE[i];
    if (f != null && s != null) line[i] = f - s;
  }
  // Signal = EMA of the MACD line, sirf wahan se jahan line banti hai.
  final firstLine = line.indexWhere((v) => v != null);
  final signal = List<double?>.filled(closes.length, null);
  if (firstLine >= 0) {
    final compact = line.sublist(firstLine).map((v) => v ?? 0.0).toList();
    final sig = ema(compact, signalPeriod);
    for (var i = 0; i < sig.length; i++) {
      signal[firstLine + i] = sig[i];
    }
  }
  Series? hist;
  if (withHistogram) {
    hist = List<double?>.filled(closes.length, null);
    for (var i = 0; i < closes.length; i++) {
      final l = line[i];
      final s = signal[i];
      if (l != null && s != null) hist[i] = l - s;
    }
  }
  return MacdResult(macd: line, signal: signal, histogram: hist);
}

// ---------------------------------------------------------------------------
// Bollinger Bands
// ---------------------------------------------------------------------------

class BollingerResult {
  const BollingerResult({
    required this.middle,
    required this.upper,
    required this.lower,
  });

  final Series middle;
  final Series upper;
  final Series lower;
}

BollingerResult bollinger(
  List<double> closes, {
  int period = 20,
  double multiplier = 2,
}) {
  final middle = sma(closes, period);
  final upper = List<double?>.filled(closes.length, null);
  final lower = List<double?>.filled(closes.length, null);
  for (var i = period - 1; i < closes.length; i++) {
    final mid = middle[i];
    if (mid == null) continue;
    var sumSq = 0.0;
    for (var j = i - period + 1; j <= i; j++) {
      final d = closes[j] - mid;
      sumSq += d * d;
    }
    // Population standard deviation (charting apps ka standard).
    final sd = math.sqrt(sumSq / period);
    upper[i] = mid + multiplier * sd;
    lower[i] = mid - multiplier * sd;
  }
  return BollingerResult(middle: middle, upper: upper, lower: lower);
}

// ---------------------------------------------------------------------------
// True Range / ATR (Wilder smoothing)
// ---------------------------------------------------------------------------

List<double?> trueRange(List<Bar> bars) {
  final out = List<double?>.filled(bars.length, null);
  for (var i = 1; i < bars.length; i++) {
    final h = bars[i].high;
    final l = bars[i].low;
    final prevClose = bars[i - 1].close;
    out[i] = math.max(
      h - l,
      math.max((h - prevClose).abs(), (l - prevClose).abs()),
    );
  }
  return out;
}

Series atr(List<Bar> bars, [int period = 14]) {
  final tr = trueRange(bars);
  final out = List<double?>.filled(bars.length, null);
  if (bars.length <= period) return out;
  var sum = 0.0;
  for (var i = 1; i <= period; i++) {
    sum += tr[i] ?? 0;
  }
  var prev = sum / period;
  out[period] = prev;
  for (var i = period + 1; i < bars.length; i++) {
    prev = (prev * (period - 1) + (tr[i] ?? 0)) / period;
    out[i] = prev;
  }
  return out;
}

/// ATR as a % of close — "kitna hilta hai" ka comparable number.
Series atrPercent(List<Bar> bars, [int period = 14]) {
  final a = atr(bars, period);
  return List<double?>.generate(bars.length, (i) {
    final v = a[i];
    if (v == null || bars[i].close == 0) return null;
    return v / bars[i].close * 100;
  });
}

// ---------------------------------------------------------------------------
// ADX / +DI / -DI (Wilder)
// ---------------------------------------------------------------------------

class AdxResult {
  const AdxResult({
    required this.adx,
    required this.plusDi,
    required this.minusDi,
  });

  final Series adx;
  final Series plusDi;
  final Series minusDi;
}

AdxResult adx(List<Bar> bars, [int period = 14]) {
  final n = bars.length;
  final adxOut = List<double?>.filled(n, null);
  final plusDiOut = List<double?>.filled(n, null);
  final minusDiOut = List<double?>.filled(n, null);
  if (n <= period * 2) {
    return AdxResult(adx: adxOut, plusDi: plusDiOut, minusDi: minusDiOut);
  }

  final plusDm = List<double>.filled(n, 0);
  final minusDm = List<double>.filled(n, 0);
  final tr = List<double>.filled(n, 0);
  for (var i = 1; i < n; i++) {
    final up = bars[i].high - bars[i - 1].high;
    final down = bars[i - 1].low - bars[i].low;
    plusDm[i] = (up > down && up > 0) ? up : 0;
    minusDm[i] = (down > up && down > 0) ? down : 0;
    tr[i] = math.max(
      bars[i].high - bars[i].low,
      math.max(
        (bars[i].high - bars[i - 1].close).abs(),
        (bars[i].low - bars[i - 1].close).abs(),
      ),
    );
  }

  double sumPlus = 0, sumMinus = 0, sumTr = 0;
  for (var i = 1; i <= period; i++) {
    sumPlus += plusDm[i];
    sumMinus += minusDm[i];
    sumTr += tr[i];
  }

  final dx = List<double?>.filled(n, null);
  for (var i = period; i < n; i++) {
    if (i > period) {
      sumPlus = sumPlus - sumPlus / period + plusDm[i];
      sumMinus = sumMinus - sumMinus / period + minusDm[i];
      sumTr = sumTr - sumTr / period + tr[i];
    }
    if (sumTr == 0) continue;
    final pdi = 100 * sumPlus / sumTr;
    final mdi = 100 * sumMinus / sumTr;
    plusDiOut[i] = pdi;
    minusDiOut[i] = mdi;
    final denom = pdi + mdi;
    dx[i] = denom == 0 ? 0 : 100 * (pdi - mdi).abs() / denom;
  }

  // ADX = Wilder-smoothed DX, period bars se shuru.
  final firstDx = period * 2 - 1;
  if (firstDx >= n) {
    return AdxResult(adx: adxOut, plusDi: plusDiOut, minusDi: minusDiOut);
  }
  var sumDx = 0.0;
  var count = 0;
  for (var i = period; i < firstDx + 1 && i < n; i++) {
    final d = dx[i];
    if (d != null) {
      sumDx += d;
      count++;
    }
  }
  if (count == 0) {
    return AdxResult(adx: adxOut, plusDi: plusDiOut, minusDi: minusDiOut);
  }
  var prev = sumDx / count;
  adxOut[firstDx] = prev;
  for (var i = firstDx + 1; i < n; i++) {
    final d = dx[i];
    if (d == null) continue;
    prev = (prev * (period - 1) + d) / period;
    adxOut[i] = prev;
  }
  return AdxResult(adx: adxOut, plusDi: plusDiOut, minusDi: minusDiOut);
}

// ---------------------------------------------------------------------------
// Stochastic %K / %D
// ---------------------------------------------------------------------------

class StochasticResult {
  const StochasticResult({required this.k, required this.d});

  final Series k;
  final Series d;
}

StochasticResult stochastic(
  List<Bar> bars, {
  int kPeriod = 14,
  int dPeriod = 3,
}) {
  final n = bars.length;
  final k = List<double?>.filled(n, null);
  for (var i = kPeriod - 1; i < n; i++) {
    var hi = double.negativeInfinity;
    var lo = double.infinity;
    for (var j = i - kPeriod + 1; j <= i; j++) {
      hi = math.max(hi, bars[j].high);
      lo = math.min(lo, bars[j].low);
    }
    k[i] = (hi - lo) == 0 ? 50 : 100 * (bars[i].close - lo) / (hi - lo);
  }
  final firstK = k.indexWhere((v) => v != null);
  final d = List<double?>.filled(n, null);
  if (firstK >= 0) {
    final compact = k.sublist(firstK).map((v) => v ?? 0.0).toList();
    final ds = sma(compact, dPeriod);
    for (var i = 0; i < ds.length; i++) {
      d[firstK + i] = ds[i];
    }
  }
  return StochasticResult(k: k, d: d);
}

// ---------------------------------------------------------------------------
// Volume SMA
// ---------------------------------------------------------------------------

Series volumeSma(List<Bar> bars, [int period = 20]) =>
    sma(bars.map((b) => b.volume.toDouble()).toList(), period);

// ---------------------------------------------------------------------------
// 52-week range position (0–100: 52W low se kitna upar)
// ---------------------------------------------------------------------------

Series rangePercent52w(List<Bar> bars, {int lookback = 250}) {
  final n = bars.length;
  final out = List<double?>.filled(n, null);
  for (var i = 0; i < n; i++) {
    final from = math.max(0, i - lookback + 1);
    var hi = double.negativeInfinity;
    var lo = double.infinity;
    for (var j = from; j <= i; j++) {
      hi = math.max(hi, bars[j].high);
      lo = math.min(lo, bars[j].low);
    }
    // Kam se kam 60 bars ke baad hi number banao (chhota history = bekaar number).
    if (i - from + 1 < math.min(60, lookback)) continue;
    out[i] = hi == lo ? 50 : 100 * (bars[i].close - lo) / (hi - lo);
  }
  return out;
}

// ---------------------------------------------------------------------------
// ROC — rate of change % over N bars
// ---------------------------------------------------------------------------

Series roc(List<double> closes, [int period = 10]) {
  final out = List<double?>.filled(closes.length, null);
  for (var i = period; i < closes.length; i++) {
    final prev = closes[i - period];
    if (prev == 0) continue;
    out[i] = 100 * (closes[i] / prev - 1);
  }
  return out;
}

// ---------------------------------------------------------------------------
// Chhote helpers (engine inhi par chalta hai)
// ---------------------------------------------------------------------------

/// Series ke aakhri `n` bar me lagataar gir raha hai? (strictly decreasing)
bool fallingFor(Series s, int index, int days) {
  if (index - days < 0) return false;
  for (var i = index - days + 1; i <= index; i++) {
    final a = s[i];
    final b = s[i - 1];
    if (a == null || b == null || !(a < b)) return false;
  }
  return true;
}

/// Series ke aakhri `n` bar me lagataar badh raha hai? (strictly increasing)
bool risingFor(Series s, int index, int days) {
  if (index - days < 0) return false;
  for (var i = index - days + 1; i <= index; i++) {
    final a = s[i];
    final b = s[i - 1];
    if (a == null || b == null || !(a > b)) return false;
  }
  return true;
}

/// `a` ne `b` ko upar ki taraf cross kiya (kal neeche tha / aaj upar)?
bool crossedAbove(Series a, Series b, int index) {
  if (index < 1) return false;
  final a0 = a[index - 1], b0 = b[index - 1];
  final a1 = a[index], b1 = b[index];
  if (a0 == null || b0 == null || a1 == null || b1 == null) return false;
  return a0 <= b0 && a1 > b1;
}

/// `a` ne `b` ko neeche ki taraf cross kiya?
bool crossedBelow(Series a, Series b, int index) {
  if (index < 1) return false;
  final a0 = a[index - 1], b0 = b[index - 1];
  final a1 = a[index], b1 = b[index];
  if (a0 == null || b0 == null || a1 == null || b1 == null) return false;
  return a0 >= b0 && a1 < b1;
}
