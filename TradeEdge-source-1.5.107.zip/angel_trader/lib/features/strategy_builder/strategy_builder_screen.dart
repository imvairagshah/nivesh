// ---------------------------------------------------------------------------
// strategy_builder_screen.dart — Strategy Builder ka form (1.5.102).
//
// User yahan **indicator select karta hai** (formula nahi likhta): universe,
// entry/exit rules, risk settings — phir "Run backtest". Poora page ek scroll
// me hai (1.5.92 rule), tiles barabar, aur light/dark dono theme me readable
// (1.5.99/1.5.100 ka contrast discipline).
//
// Numbers yahan calculate nahi hote — sab `strategy_engine.dart` se aate hain.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:flutter/services.dart';

import '../../core/widgets/edge_header.dart';
import '../../core/widgets/page_scroll.dart';
import '../../services/cross_scan_service.dart' show ScanUniverse;
import '../help/tool_faq.dart';
import '../help/tool_faq_screen.dart';
import 'index_catalog.dart';
import 'strategy_builder_provider.dart';
import 'strategy_delivery.dart';
import 'strategy_fundamentals.dart';
import 'strategy_report_screen.dart';
import 'strategy_rules.dart';

class StrategyBuilderScreen extends StatefulWidget {
  const StrategyBuilderScreen({super.key});

  @override
  State<StrategyBuilderScreen> createState() => _StrategyBuilderScreenState();
}

class _StrategyBuilderScreenState extends State<StrategyBuilderScreen> {
  int _estimateSymbols = 0;
  String _estimateText = 'universe check ho raha hai…';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      final p = context.read<StrategyBuilderProvider>();
      await p.loadSaved();
      final e = await p.estimate();
      if (!mounted) return;
      setState(() {
        _estimateSymbols = e.symbols;
        _estimateText = e.estimate;
      });
    });
  }

  Future<void> _run() async {
    final p = context.read<StrategyBuilderProvider>();
    final problem = p.validate();
    if (problem != null) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(problem)));
      return;
    }
    await p.run();
    if (!mounted) return;
    if (p.status == BuilderStatus.ready ||
        p.status == BuilderStatus.cancelled) {
      Navigator.of(context).push(
        MaterialPageRoute<void>(builder: (_) => const StrategyReportScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.watch<StrategyBuilderProvider>();
    final s = p.strategy;

    return Scaffold(
      appBar: EdgeAppBar(
        title: 'Strategy Builder',
        subtitle: 'Rules banao · backtest · report',
        actions: [
          IconButton(
            tooltip: 'Saved strategies',
            icon: const Icon(Icons.bookmarks_outlined),
            onPressed: () => _showSaved(context, p),
          ),
          IconButton(
            tooltip: 'FAQ — ye tool kaise kaam karta hai',
            icon: const Icon(Icons.help_outline_rounded),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => const ToolFaqScreen(
                  title: 'Builder · FAQ',
                  entries: kBuilderFaq,
                ),
              ),
            ),
          ),
          IconButton(
            tooltip: 'Preset: Triple RSI',
            icon: const Icon(Icons.restore_rounded),
            onPressed: () =>
                p.loadPreset(tripleRsiPreset(universeKey: s.universeKey)),
          ),
        ],
      ),
      body: PageScroll.children([
        _Intro(estimateText: _estimateText, symbols: _estimateSymbols),
        const SizedBox(height: 14),
        _UniversePicker(
          selected: s.universeKey,
          onPick: (key) {
            p.setUniverse(key);
            p.estimate().then((e) {
              if (!mounted) return;
              setState(() {
                _estimateSymbols = e.symbols;
                _estimateText = e.estimate;
              });
            });
          },
        ),
        const SizedBox(height: 12),
        const _TimeframeCard(),
        const SizedBox(height: 12),
        const _FundamentalsCard(),
        const SizedBox(height: 14),
        _RulesCard(
          title: 'Entry — kab kharidna hai',
          subtitle: 'Jab ye conditions poori hon, us din ke close par buy.',
          rules: s.entry,
          join: s.entryJoin,
          isEntry: true,
        ),
        const SizedBox(height: 12),
        _RulesCard(
          title: 'Exit — kab bechna hai',
          subtitle:
              'Rule na daalo to sirf stop loss / target / time stop par band '
              'hoga.',
          rules: s.exit,
          join: s.exitJoin,
          isEntry: false,
        ),
        const SizedBox(height: 12),
        const _RiskCard(),
        const SizedBox(height: 12),
        _SaveRow(p: p),
        const SizedBox(height: 16),
        if (p.running) _Progress(p: p) else _RunButton(p: p, onRun: _run),
        if (p.error != null)
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Text(
              p.error!,
              style: TextStyle(
                fontSize: 12,
                color: Theme.of(context).colorScheme.error,
              ),
            ),
          ),
        const SizedBox(height: 18),
        Center(
          child: Text(
            'TRADE EDGE · backtest official EOD candles par · paper only',
            style: TextStyle(
              fontSize: 10,
              letterSpacing: 0.5,
              color: Theme.of(
                context,
              ).colorScheme.onSurfaceVariant.withValues(alpha: 0.8),
            ),
          ),
        ),
      ], padding: const EdgeInsets.fromLTRB(16, 8, 16, 28)),
    );
  }

  void _showSaved(BuildContext context, StrategyBuilderProvider p) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) => Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Saved strategies',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 8),
              if (p.saved.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 16),
                  child: Text('Abhi kuch save nahi hua.'),
                )
              else
                for (final saved in p.saved)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(saved.strategy.name),
                    subtitle: Text(
                      '${saved.strategy.entry.length} entry · '
                      '${saved.strategy.exit.length} exit · '
                      '${saved.strategy.universeKey}',
                    ),
                    onTap: () {
                      p.loadPreset(saved.strategy);
                      Navigator.pop(ctx);
                    },
                    trailing: IconButton(
                      tooltip: 'Delete',
                      icon: const Icon(Icons.delete_outline_rounded, size: 20),
                      onPressed: () async {
                        await p.deleteSaved(saved.strategy.name);
                        setSheet(() {});
                      },
                    ),
                  ),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Intro + universe
// ---------------------------------------------------------------------------

class _Intro extends StatelessWidget {
  const _Intro({required this.estimateText, required this.symbols});

  final String estimateText;
  final int symbols;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Rules chuno, backtest chalao, aur poora report dekho — win rate, '
            'equity curve, monthly returns, har trade. Koi formula likhne ki '
            'zaroorat nahi.',
            style: TextStyle(
              fontSize: 12,
              height: 1.5,
              color: scheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(
                Icons.timer_outlined,
                size: 14,
                color: scheme.onSurfaceVariant,
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  symbols > 0
                      ? '$symbols stocks · $estimateText'
                      : estimateText,
                  style: TextStyle(
                    fontSize: 10.5,
                    fontWeight: FontWeight.w600,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _UniversePicker extends StatelessWidget {
  const _UniversePicker({required this.selected, required this.onPick});

  final String selected;
  final void Function(String key) onPick;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    // IPO database is tool ke liye bekaar hai — sirf stock universes.
    final options = StrategyBuilderProvider.universes
        .where((u) => u.key != 'ipos')
        .toList();

    Widget chip({
      required String key,
      required String label,
      required bool selected,
      required void Function() onTap,
    }) => ChoiceChip(
      label: Text(label),
      selected: selected,
      onSelected: (_) => onTap(),
      labelStyle: TextStyle(
        fontSize: 11.5,
        fontWeight: FontWeight.w700,
        color: selected ? scheme.onPrimaryContainer : scheme.onSurfaceVariant,
      ),
      selectedColor: scheme.primaryContainer,
      backgroundColor: scheme.surface,
      side: BorderSide(color: scheme.outlineVariant),
      showCheckmark: false,
    );

    final indexSelected = IndexCatalog.all.any(
      (i) => i.cacheSymbol == selected,
    );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _SectionTitle('Kis par backtest karna hai'),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final ScanUniverse u in options)
              chip(
                key: u.key,
                label: u.label,
                selected: u.key == selected,
                onTap: () => onPick(u.key),
              ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Text(
              'INDEX',
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.8,
                color: scheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                'index par strategy = wahi index kharidna/bechna',
                style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant),
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final idx in IndexCatalog.all)
              chip(
                key: idx.cacheSymbol,
                label: idx.label,
                selected: idx.cacheSymbol == selected,
                onTap: () => onPick(idx.cacheSymbol),
              ),
          ],
        ),
        const SizedBox(height: 6),
        Text(
          indexSelected
              ? 'Index candles: Angel (broker) primary — login na ho ya token '
                    'reject ho to Yahoo fallback, aur report par saaf label '
                    'lagega. Dono na mile to "index data available nahi".'
              : 'Index backtest 10 indices par chalta hai · stocks ke liye upar '
                    'ke universes.',
          style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Rules
// ---------------------------------------------------------------------------

class _RulesCard extends StatelessWidget {
  const _RulesCard({
    required this.title,
    required this.subtitle,
    required this.rules,
    required this.join,
    required this.isEntry,
  });

  final String title;
  final String subtitle;
  final List<Rule> rules;
  final RuleJoin join;
  final bool isEntry;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final p = context.read<StrategyBuilderProvider>();

    return Container(
      padding: const EdgeInsets.fromLTRB(13, 13, 13, 10),
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 13.5,
              fontWeight: FontWeight.w900,
              color: scheme.onSurface,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            subtitle,
            style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
          ),
          const SizedBox(height: 10),
          if (rules.isEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Text(
                isEntry
                    ? 'Koi entry rule nahi — kam se kam ek chahiye.'
                    : 'Koi exit rule nahi.',
                style: TextStyle(
                  fontSize: 11,
                  color: isEntry ? scheme.error : scheme.onSurfaceVariant,
                ),
              ),
            ),
          for (var i = 0; i < rules.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _RuleEditor(
                key: ValueKey(
                  '${isEntry ? 'e' : 'x'}-$i-${rules[i].indicator.id}',
                ),
                rule: rules[i],
                onChanged: (rule) =>
                    p.replaceRule(entry: isEntry, index: i, rule: rule),
                onDelete: () => p.removeRule(entry: isEntry, index: i),
              ),
            ),
          Row(
            children: [
              OutlinedButton.icon(
                onPressed: () => p.addRule(entry: isEntry),
                icon: const Icon(Icons.add_rounded, size: 18),
                label: const Text('Rule jodo'),
              ),
              const SizedBox(width: 8),
              if (rules.length > 1)
                DropdownButton<RuleJoin>(
                  value: join,
                  underline: const SizedBox.shrink(),
                  style: TextStyle(fontSize: 11.5, color: scheme.onSurface),
                  items: [
                    for (final j in RuleJoin.values)
                      DropdownMenuItem(
                        value: j,
                        child: Text(
                          j.label,
                          style: const TextStyle(fontSize: 11.5),
                        ),
                      ),
                  ],
                  onChanged: (j) {
                    if (j != null) p.setJoin(entry: isEntry, join: j);
                  },
                ),
            ],
          ),
        ],
      ),
    );
  }
}

/// Ek rule ka editor: indicator + params + operator + value/compareTo.
class _RuleEditor extends StatefulWidget {
  const _RuleEditor({
    super.key,
    required this.rule,
    required this.onChanged,
    required this.onDelete,
  });

  final Rule rule;
  final void Function(Rule rule) onChanged;
  final VoidCallback onDelete;

  @override
  State<_RuleEditor> createState() => _RuleEditorState();
}

class _RuleEditorState extends State<_RuleEditor> {
  late final Map<String, TextEditingController> _params = {
    for (final name in widget.rule.indicator.paramNames)
      name: TextEditingController(
        text: '${widget.rule.effectiveParams[name] ?? 0}',
      ),
  };
  late final TextEditingController _value = TextEditingController(
    text: _fmt(widget.rule.value),
  );
  late final TextEditingController _againstPeriod = TextEditingController(
    text: '${widget.rule.against?['period'] ?? 200}',
  );

  static String _fmt(num v) => v == v.roundToDouble() ? '${v.toInt()}' : '$v';

  @override
  void dispose() {
    for (final c in _params.values) {
      c.dispose();
    }
    _value.dispose();
    _againstPeriod.dispose();
    super.dispose();
  }

  void _emitParams() {
    final p = <String, num>{};
    for (final e in _params.entries) {
      final parsed = num.tryParse(e.value.text.trim());
      if (parsed != null && parsed > 0) p[e.key] = parsed;
    }
    widget.onChanged(widget.rule.copyWith(params: p));
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final rule = widget.rule;
    final ind = rule.indicator;

    return Container(
      padding: const EdgeInsets.fromLTRB(10, 8, 6, 8),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: DropdownButton<Indicator>(
                  value: ind,
                  isExpanded: true,
                  underline: const SizedBox.shrink(),
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: scheme.onSurface,
                  ),
                  items: [
                    for (final i in Indicator.values)
                      DropdownMenuItem(
                        value: i,
                        child: Text(
                          i.label,
                          style: const TextStyle(fontSize: 12),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                  ],
                  onChanged: (next) {
                    if (next == null) return;
                    widget.onChanged(
                      Rule(
                        indicator: next,
                        op: rule.op,
                        value: rule.value == 0 ? 30 : rule.value,
                      ),
                    );
                  },
                ),
              ),
              IconButton(
                tooltip: 'Rule hataao',
                visualDensity: VisualDensity.compact,
                icon: Icon(
                  Icons.close_rounded,
                  size: 17,
                  color: scheme.onSurfaceVariant,
                ),
                onPressed: widget.onDelete,
              ),
            ],
          ),
          if (ind.paramNames.isNotEmpty && !ind.isCross)
            Wrap(
              spacing: 8,
              runSpacing: 6,
              children: [
                for (final name in ind.paramNames)
                  SizedBox(
                    width: 86,
                    child: TextField(
                      controller: _params[name],
                      keyboardType: TextInputType.number,
                      style: const TextStyle(fontSize: 12),
                      decoration: InputDecoration(
                        labelText: name,
                        isDense: true,
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 8,
                        ),
                        border: const OutlineInputBorder(),
                      ),
                      onChanged: (_) => _emitParams(),
                    ),
                  ),
              ],
            ),
          if (ind.isCross && ind.paramNames.contains('other'))
            SizedBox(
              width: 120,
              child: TextField(
                controller: _againstPeriod,
                keyboardType: TextInputType.number,
                style: const TextStyle(fontSize: 12),
                decoration: const InputDecoration(
                  labelText: 'doosra period',
                  isDense: true,
                  contentPadding: EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 8,
                  ),
                  border: OutlineInputBorder(),
                ),
                onChanged: (text) {
                  final parsed = num.tryParse(text.trim());
                  if (parsed == null) return;
                  widget.onChanged(
                    rule.copyWith(
                      params: {...rule.effectiveParams, 'other': parsed},
                    ),
                  );
                },
              ),
            ),
          if (!ind.isTrend && !ind.isCross) ...[
            const SizedBox(height: 6),
            Row(
              children: [
                DropdownButton<RuleOp>(
                  value: rule.op,
                  underline: const SizedBox.shrink(),
                  style: TextStyle(fontSize: 13, color: scheme.onSurface),
                  items: [
                    for (final op in RuleOp.values)
                      DropdownMenuItem(
                        value: op,
                        child: Text(
                          op.symbol,
                          style: const TextStyle(fontSize: 13),
                        ),
                      ),
                  ],
                  onChanged: (op) {
                    if (op != null) widget.onChanged(rule.copyWith(op: op));
                  },
                ),
                const SizedBox(width: 6),
                if (rule.compareTo == null)
                  SizedBox(
                    width: 96,
                    child: TextField(
                      controller: _value,
                      keyboardType: TextInputType.number,
                      style: const TextStyle(fontSize: 12),
                      decoration: const InputDecoration(
                        labelText: 'value',
                        isDense: true,
                        contentPadding: EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 8,
                        ),
                        border: OutlineInputBorder(),
                      ),
                      onChanged: (text) {
                        final parsed = num.tryParse(text.trim());
                        if (parsed != null) {
                          widget.onChanged(rule.copyWith(value: parsed));
                        }
                      },
                    ),
                  )
                else
                  SizedBox(
                    width: 130,
                    child: TextField(
                      controller: _againstPeriod,
                      keyboardType: TextInputType.number,
                      style: const TextStyle(fontSize: 12),
                      decoration: InputDecoration(
                        labelText: '${rule.compareTo!.label} period',
                        isDense: true,
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 8,
                        ),
                        border: const OutlineInputBorder(),
                      ),
                      onChanged: (text) {
                        final parsed = num.tryParse(text.trim());
                        if (parsed != null) {
                          widget.onChanged(
                            rule.copyWith(against: {'period': parsed}),
                          );
                        }
                      },
                    ),
                  ),
                const Spacer(),
                IconButton(
                  tooltip: rule.compareTo == null
                      ? 'Doosre indicator se compare karo'
                      : 'Value se compare karo',
                  visualDensity: VisualDensity.compact,
                  icon: Icon(
                    rule.compareTo == null
                        ? Icons.compare_arrows_rounded
                        : Icons.tag_rounded,
                    size: 18,
                    color: scheme.onSurfaceVariant,
                  ),
                  onPressed: () {
                    if (rule.compareTo == null) {
                      widget.onChanged(
                        rule.copyWith(
                          compareTo: Indicator.sma,
                          against: {'period': 200},
                        ),
                      );
                    } else {
                      widget.onChanged(rule.copyWith(clearCompareTo: true));
                    }
                  },
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Risk settings
// ---------------------------------------------------------------------------

class _RiskCard extends StatefulWidget {
  const _RiskCard();

  @override
  State<_RiskCard> createState() => _RiskCardState();
}

class _RiskCardState extends State<_RiskCard> {
  @override
  Widget build(BuildContext context) {
    final p = context.watch<StrategyBuilderProvider>();
    final s = p.strategy.settings;
    final scheme = Theme.of(context).colorScheme;

    Widget field(
      String label,
      String value,
      void Function(num) onSet, {
      String? hint,
    }) => SizedBox(
      width: 104,
      child: TextFormField(
        initialValue: value,
        keyboardType: TextInputType.number,
        style: const TextStyle(fontSize: 12),
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          isDense: true,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 8,
            vertical: 10,
          ),
          border: const OutlineInputBorder(),
        ),
        onFieldSubmitted: (text) {
          final parsed = num.tryParse(text.trim());
          if (parsed != null) onSet(parsed);
        },
      ),
    );

    return Container(
      padding: const EdgeInsets.fromLTRB(13, 13, 13, 13),
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Risk aur position',
            style: TextStyle(
              fontSize: 13.5,
              fontWeight: FontWeight.w900,
              color: scheme.onSurface,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            'Enter dabane par value lagti hai. 0 = band.',
            style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              field('Stop loss %', '${s.stopLossPct}', (v) {
                p.setSettings(s.copyWith(stopLossPct: v.toDouble()));
              }),
              field('Target %', '${s.targetPct}', (v) {
                p.setSettings(s.copyWith(targetPct: v.toDouble()));
              }),
              field('Time stop (din)', '${s.timeStopBars}', (v) {
                p.setSettings(s.copyWith(timeStopBars: v.toInt()));
              }),
              field('Cost %', '${s.costPct}', (v) {
                p.setSettings(s.copyWith(costPct: v.toDouble()));
              }),
              field('Max positions', '${s.maxPositions}', (v) {
                p.setSettings(s.copyWith(maxPositions: v.toInt()));
              }),
              field('History (saal)', '${s.years}', (v) {
                p.setSettings(s.copyWith(years: v.toInt()));
              }),
            ],
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Save / run / progress
// ---------------------------------------------------------------------------

/// Import — clipboard se strategy JSON/file text.
Future<void> _importFromClipboard(
  BuildContext context,
  StrategyBuilderProvider p,
) async {
  final messenger = ScaffoldMessenger.of(context);
  final data = await Clipboard.getData(Clipboard.kTextPlain);
  final text = data?.text ?? '';
  final parsed = StrategyDeliveryService.parseStrategyFile(text);
  if (parsed == null) {
    messenger.showSnackBar(
      const SnackBar(
        content: Text(
          'Clipboard me strategy file nahi mili — pehle WhatsApp/Telegram se '
          'poore file text ko copy kariye.',
        ),
      ),
    );
    return;
  }
  p.loadPreset(parsed);
  messenger.showSnackBar(
    SnackBar(content: Text('Import ho gaya: ${parsed.name}')),
  );
}

class _SaveRow extends StatelessWidget {
  const _SaveRow({required this.p});

  final StrategyBuilderProvider p;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        OutlinedButton.icon(
          onPressed: () => _importFromClipboard(context, p),
          icon: const Icon(Icons.download_rounded, size: 18),
          label: const Text('Import'),
        ),
        OutlinedButton.icon(
          onPressed: () async {
            await p.saveCurrent();
            if (!context.mounted) return;
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Save ho gaya: ${p.strategy.name}')),
            );
          },
          icon: const Icon(Icons.save_rounded, size: 18),
          label: const Text('Save'),
        ),
        OutlinedButton.icon(
          onPressed: () {
            showDialog<void>(
              context: context,
              builder: (ctx) {
                final controller = TextEditingController(text: p.strategy.name);
                return AlertDialog(
                  title: const Text('Naam badlo'),
                  content: TextField(controller: controller, autofocus: true),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(ctx),
                      child: const Text('Cancel'),
                    ),
                    FilledButton(
                      onPressed: () {
                        p.update(
                          p.strategy.copyWith(name: controller.text.trim()),
                        );
                        Navigator.pop(ctx);
                      },
                      child: const Text('Save'),
                    ),
                  ],
                );
              },
            );
          },
          icon: const Icon(Icons.drive_file_rename_outline_rounded, size: 18),
          label: const Text('Rename'),
        ),
        OutlinedButton.icon(
          onPressed: () async {
            final outcome = await StrategyDeliveryService().shareStrategyFile(
              p.strategy,
            );
            if (!context.mounted) return;
            ScaffoldMessenger.of(
              context,
            ).showSnackBar(SnackBar(content: Text(outcome.message)));
          },
          icon: const Icon(Icons.file_upload_outlined, size: 18),
          label: const Text('File'),
        ),
        OutlinedButton.icon(
          onPressed: () => showDialog<void>(
            context: context,
            builder: (ctx) {
              final exported = p.exportCurrent();
              return AlertDialog(
                title: const Text('Strategy share karo'),
                content: SingleChildScrollView(
                  child: SelectableText(
                    exported,
                    style: TextStyle(
                      fontSize: 11,
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(ctx),
                    child: const Text('Band'),
                  ),
                  FilledButton(
                    onPressed: () async {
                      await Clipboard.setData(ClipboardData(text: exported));
                      if (!ctx.mounted) return;
                      Navigator.pop(ctx);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Copy ho gaya')),
                      );
                    },
                    child: const Text('Copy'),
                  ),
                ],
              );
            },
          ),
          icon: const Icon(Icons.ios_share_rounded, size: 18),
          label: const Text('Share'),
        ),
      ],
    );
  }
}

class _Progress extends StatelessWidget {
  const _Progress({required this.p});

  final StrategyBuilderProvider p;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final value = p.total == 0 ? null : p.scanned / p.total;
    return Container(
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            p.progress ?? 'Chal raha hai…',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: scheme.onSurface,
            ),
          ),
          const SizedBox(height: 8),
          LinearProgressIndicator(value: value),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: Text(
                  'Rate limit: 3 requests/sec — jaan-boojh kar dheere, broker '
                  'block na kare.',
                  style: TextStyle(
                    fontSize: 10,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ),
              TextButton(onPressed: p.cancel, child: const Text('Cancel')),
            ],
          ),
        ],
      ),
    );
  }
}

class _RunButton extends StatelessWidget {
  const _RunButton({required this.p, required this.onRun});

  final StrategyBuilderProvider p;
  final Future<void> Function() onRun;

  @override
  Widget build(BuildContext context) {
    final hasResult = p.result != null;
    return Column(
      children: [
        SizedBox(
          width: double.infinity,
          child: FilledButton.icon(
            onPressed: onRun,
            icon: const Icon(Icons.play_arrow_rounded),
            label: Text(hasResult ? 'Dobara backtest' : 'Run backtest'),
          ),
        ),
        if (hasResult) ...[
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => const StrategyReportScreen(),
                ),
              ),
              icon: const Icon(Icons.assessment_rounded, size: 18),
              label: const Text('Report kholo'),
            ),
          ),
        ],
      ],
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w800,
          letterSpacing: 0.8,
          color: Theme.of(context).colorScheme.onSurfaceVariant,
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// 1.5.104 — timeframe + fundamentals filter
// ---------------------------------------------------------------------------

class _TimeframeCard extends StatelessWidget {
  const _TimeframeCard();

  @override
  Widget build(BuildContext context) {
    final p = context.watch<StrategyBuilderProvider>();
    final scheme = Theme.of(context).colorScheme;
    final tf = p.strategy.settings.timeframe;

    return Container(
      padding: const EdgeInsets.fromLTRB(13, 13, 13, 12),
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Timeframe',
            style: TextStyle(
              fontSize: 13.5,
              fontWeight: FontWeight.w900,
              color: scheme.onSurface,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            tf.isIntraday
                ? 'Intraday bars broker se sirf ~${tf.maxLookbackDays} din ka '
                      'milta hai — window chhota, isliye results daily se kam '
                      'bharosemand.'
                : 'Daily candles — 5 saal tak ka itihaas, sabse bharosemand.',
            style: TextStyle(
              fontSize: 10.5,
              height: 1.45,
              color: scheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: [
              for (final t in Timeframe.values)
                ChoiceChip(
                  label: Text(t.label),
                  selected: t == tf,
                  onSelected: (_) =>
                      p.setSettings(p.strategy.settings.copyWith(timeframe: t)),
                  labelStyle: TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w700,
                    color: t == tf
                        ? scheme.onPrimaryContainer
                        : scheme.onSurfaceVariant,
                  ),
                  selectedColor: scheme.primaryContainer,
                  backgroundColor: scheme.surface,
                  side: BorderSide(color: scheme.outlineVariant),
                  showCheckmark: false,
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _FundamentalsCard extends StatefulWidget {
  const _FundamentalsCard();

  @override
  State<_FundamentalsCard> createState() => _FundamentalsCardState();
}

class _FundamentalsCardState extends State<_FundamentalsCard> {
  @override
  Widget build(BuildContext context) {
    final p = context.watch<StrategyBuilderProvider>();
    final scheme = Theme.of(context).colorScheme;
    final f = p.strategy.fundamentals;

    void set(FundamentalFilter next) =>
        p.update(p.strategy.copyWith(fundamentals: next));

    Widget box(
      String label,
      String hint,
      double? value,
      void Function(String text) onSet,
    ) => SizedBox(
      width: 118,
      child: TextFormField(
        key: ValueKey('$label-${value ?? 'x'}'),
        initialValue: value == null
            ? ''
            : (value == value.roundToDouble()
                  ? '${value.toInt()}'
                  : value.toStringAsFixed(2)),
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        style: const TextStyle(fontSize: 12),
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          isDense: true,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 8,
            vertical: 10,
          ),
          border: const OutlineInputBorder(),
        ),
        onFieldSubmitted: onSet,
      ),
    );

    return Container(
      padding: const EdgeInsets.fromLTRB(13, 13, 13, 12),
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'Fundamentals filter',
                  style: TextStyle(
                    fontSize: 13.5,
                    fontWeight: FontWeight.w900,
                    color: scheme.onSurface,
                  ),
                ),
              ),
              Switch(
                value: f.isActive,
                onChanged: (on) => set(
                  on
                      ? const FundamentalFilter(
                          minMarketCapCr: 500,
                          minRocePct: 10,
                        )
                      : const FundamentalFilter(),
                ),
              ),
            ],
          ),
          Text(
            'NSE/BSE filings se — Enter dabane par lagta hai. Ye **aaj ke** numbers '
            'hain, poore backtest window par (2023 ka asli fundamental nahi). '
            'P/E available nahi (PAT data app me nahi) — isliye option hi nahi.',
            style: TextStyle(
              fontSize: 10,
              height: 1.45,
              color: scheme.onSurfaceVariant,
            ),
          ),
          if (f.isActive) ...[
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                box('Min MCap (cr)', '0 = koi nahi', f.minMarketCapCr, (t) {
                  final v = double.tryParse(t.trim());
                  set(
                    v == null
                        ? f.copyWith(clearMinMarketCap: true)
                        : f.copyWith(minMarketCapCr: v),
                  );
                }),
                box('Min ROCE %', '0 = koi nahi', f.minRocePct, (t) {
                  final v = double.tryParse(t.trim());
                  set(
                    v == null
                        ? f.copyWith(clearMinRoce: true)
                        : f.copyWith(minRocePct: v),
                  );
                }),
                box('Max D/E', 'khali = koi nahi', f.maxDebtEquity, (t) {
                  final v = double.tryParse(t.trim());
                  set(
                    v == null
                        ? f.copyWith(clearMaxDebtEquity: true)
                        : f.copyWith(maxDebtEquity: v),
                  );
                }),
                box(
                  'Min Earn. Yield %',
                  'khali = koi nahi',
                  f.minEarningsYieldPct,
                  (t) {
                    final v = double.tryParse(t.trim());
                    set(
                      v == null
                          ? f.copyWith(clearMinEarningsYield: true)
                          : f.copyWith(minEarningsYieldPct: v),
                    );
                  },
                ),
              ],
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                Checkbox(
                  value: f.requireData,
                  visualDensity: VisualDensity.compact,
                  onChanged: (v) => set(f.copyWith(requireData: v ?? false)),
                ),
                Expanded(
                  child: Text(
                    'Sirf jinke fundamentals mile (data na ho to stock hataao)',
                    style: TextStyle(
                      fontSize: 10.5,
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
                ),
              ],
            ),
            Text(
              f.describe(),
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w700,
                color: scheme.primary,
              ),
            ),
          ],
        ],
      ),
    );
  }
}
