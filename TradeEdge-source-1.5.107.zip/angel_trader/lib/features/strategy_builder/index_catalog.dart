// ---------------------------------------------------------------------------
// index_catalog.dart — kaun se index backtest ho sakte hain (1.5.103).
//
// Source hamesha **broker (Angel One)** hai, koi scraper nahi:
//   • Angel ke scrip master me NSE indices `instrumenttype = AMXIDX` rows hote
//     hain (Nifty 50 = token 99926000, Bank Nifty = 99926009, …).
//   • `getCandleData` un tokens par wahi daily candles deta hai jo stocks par
//     deta hai — isliye engine ke liye index bhi bas ek "symbol" hai.
//
// NSE ki index files (ind_close_all, archives) is sandbox/app se 403 aati hain
// — wo raasta band hai, isliye us par depend nahi karte aur fake number kabhi
// nahi banate. Agar broker se candles na aayein to screen par saaf likha jaata
// hai "index data available nahi" (chhupaya nahi jaata).
// ---------------------------------------------------------------------------

/// Ek index jo backtest ho sakta hai.
class BenchIndex {
  const BenchIndex({
    required this.token,
    required this.symbol,
    required this.name,
    required this.label,
  });

  /// Angel ka AMXIDX token (string — API strings bhejti hai).
  final String token;

  /// Symbol jo `getCandleData` ko jaata hai (NSE segment).
  final String symbol;

  /// Broker ka naam (report me).
  final String name;

  /// UI par dikhne wala chhota naam.
  final String label;

  /// Candle cache / loader ke liye pseudo-scrip symbol.
  String get cacheSymbol => 'IDX:$symbol';
}

class IndexCatalog {
  IndexCatalog._();

  /// 10 index jo NSE par sabse zyada dekhe jaate hain. Tokens **scrip master se
  /// liye gaye** hain (AMXIDX, NSE) — hand-written nahi.
  static const List<BenchIndex> all = [
    BenchIndex(
      token: '99926000',
      symbol: 'NIFTY',
      name: 'Nifty 50',
      label: 'Nifty 50',
    ),
    BenchIndex(
      token: '99926009',
      symbol: 'BANKNIFTY',
      name: 'Nifty Bank',
      label: 'Bank Nifty',
    ),
    BenchIndex(
      token: '99926037',
      symbol: 'FINNIFTY',
      name: 'Nifty Fin Service',
      label: 'Fin Nifty',
    ),
    BenchIndex(
      token: '99926074',
      symbol: 'MIDCPNIFTY',
      name: 'NIFTY MID SELECT',
      label: 'Midcap Select',
    ),
    BenchIndex(
      token: '99926004',
      symbol: 'NIFTY 500',
      name: 'Nifty 500',
      label: 'Nifty 500',
    ),
    BenchIndex(
      token: '99926012',
      symbol: 'NIFTY 100',
      name: 'Nifty 100',
      label: 'Nifty 100',
    ),
    BenchIndex(
      token: '99926008',
      symbol: 'NIFTY IT',
      name: 'Nifty IT',
      label: 'Nifty IT',
    ),
    BenchIndex(
      token: '99926029',
      symbol: 'NIFTY AUTO',
      name: 'Nifty Auto',
      label: 'Nifty Auto',
    ),
    BenchIndex(
      token: '99926023',
      symbol: 'NIFTY PHARMA',
      name: 'Nifty Pharma',
      label: 'Nifty Pharma',
    ),
    BenchIndex(
      token: '99926030',
      symbol: 'NIFTY METAL',
      name: 'Nifty Metal',
      label: 'Nifty Metal',
    ),
  ];

  static BenchIndex? byToken(String token) {
    for (final i in all) {
      if (i.token == token) return i;
    }
    return null;
  }

  static BenchIndex? bySymbol(String symbol) {
    final upper = symbol.toUpperCase();
    for (final i in all) {
      if (i.symbol == upper || i.label.toUpperCase() == upper) return i;
    }
    return null;
  }
}
