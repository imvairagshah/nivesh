// ---------------------------------------------------------------------------
// strategy_engine.dart — backtest ka dil (pure Dart, network/flutter nahi).
//
// Do hisse hain:
//   1. per-stock trade nikalna ([runOnBars]) — signal → entry → exit
//   2. saare stocks ko ek portfolio me jodna ([runPortfolio]) — 10 slots,
//      equity curve, drawdown, monthly.
//
// Rules jo kabhi nahi todne (1.5.102 ka contract):
//   • **No look-ahead.** Signal bar `i` ke *close* par entry hoti hai; exit bhi
//     kisi baad wale bar par hi possible hai. Bar ke andar ka high/low sirf
//     stop/target check ke liye use hota hai (jaise asli me hota hai).
//   • **Slots.** Ek din me kai signal aate hain — poora paisa har trade me
//     lagana jhooth hai. Isliye max N positions, har trade ko capital ka 1/N.
//   • **Cost.** Har round trip par `costPct` (default 0.35%) kata jaata hai.
//   • **Honest skip.** Data kam / indicator warm-up nahi → stock `skipped` me
//     wajah ke saath, chupchaap gayab nahi.
//   • **Gap.** Stop/target gap ke through ho to **open** par fill hota hai,
//     na ki stop price par (warna curve jhooth bolta hai).
// ---------------------------------------------------------------------------

import 'dart:math' as math;

import 'strategy_indicators.dart';
import 'strategy_rules.dart';

/// Ek closed trade.
class StrategyTrade {
  const StrategyTrade({
    required this.symbol,
    required this.entryIndex,
    required this.exitIndex,
    required this.entryDate,
    required this.exitDate,
    required this.entryPrice,
    required this.exitPrice,
    required this.returnPct,
    required this.netPct,
    required this.bars,
    required this.reason,
    this.maePct = 0,
    this.mfePct = 0,
  });

  final String symbol;
  final int entryIndex;
  final int exitIndex;
  final DateTime entryDate;
  final DateTime exitDate;
  final double entryPrice;
  final double exitPrice;

  /// Cost se **pehle** ka return (%).
  final double returnPct;

  /// Cost ke **baad** ka return (%) — report isi par chalti hai.
  final double netPct;

  final int bars;

  /// `exit`, `stop`, `target`, `time`, `end`.
  final String reason;

  /// Trade ke andar sabse kharab/best point (%).
  final double maePct;
  final double mfePct;

  bool get isWin => netPct > 0;

  /// 1.5.107 — report cache se trade wapas.
  factory StrategyTrade.fromJson(Map<String, dynamic> j) {
    DateTime day(String k) =>
        DateTime.tryParse('${j[k]}') ?? DateTime(2015);
    double d(String k) => (j[k] as num? ?? 0).toDouble();
    return StrategyTrade(
      symbol: '${j['symbol'] ?? ''}',
      entryIndex: 0,
      exitIndex: 0,
      entryDate: day('entryDate'),
      exitDate: day('exitDate'),
      entryPrice: d('entryPrice'),
      exitPrice: d('exitPrice'),
      returnPct: d('returnPct'),
      netPct: d('netPct'),
      bars: (j['bars'] as num? ?? 0).toInt(),
      reason: '${j['reason'] ?? ''}',
      maePct: d('maePct'),
      mfePct: d('mfePct'),
    );
  }

  Map<String, dynamic> toJson() => {
    'symbol': symbol,
    'entryDate': entryDate.toIso8601String().split('T').first,
    'exitDate': exitDate.toIso8601String().split('T').first,
    'entryPrice': entryPrice,
    'exitPrice': exitPrice,
    'returnPct': returnPct,
    'netPct': netPct,
    'bars': bars,
    'reason': reason,
    'maePct': maePct,
    'mfePct': mfePct,
  };
}

/// Ek stock jo scan nahi hua — wajah ke saath (chhupaya nahi jaata).
class StrategySkip {
  const StrategySkip(this.symbol, this.reason);

  final String symbol;
  final String reason;
}

/// Ek stock ka result.
class SymbolResult {
  const SymbolResult({required this.symbol, required this.trades, this.skip});

  final String symbol;
  final List<StrategyTrade> trades;
  final StrategySkip? skip;
}

/// Indicator cache — ek stock ke bars par saare series ek baar.
///
/// (Warna har rule ke liye RSI/SMA dobara banti — 213 stocks × 500 bars par
/// ye seedha 10x slow hota hai.)
class _Indicators {
  _Indicators(this.bars)
    : closes = bars.map((b) => b.close).toList(growable: false);

  final List<Bar> bars;
  final List<double> closes;

  final Map<String, Series> _cache = {};

  Series _get(String key, Series Function() build) =>
      _cache.putIfAbsent(key, build);

  Series of(Indicator indicator, Map<String, num> params) {
    final p = {...indicator.defaultParams, ...params};
    int i(String k) => (p[k] ?? 0).toInt();
    switch (indicator) {
      case Indicator.price:
        return _get('price', () => closes.map<double?>((c) => c).toList());
      case Indicator.rsi:
        return _get('rsi${i('period')}', () => rsi(closes, i('period')));
      case Indicator.sma:
        return _get('sma${i('period')}', () => sma(closes, i('period')));
      case Indicator.ema:
        return _get('ema${i('period')}', () => ema(closes, i('period')));
      case Indicator.macd:
        return _get(
          'macd${i('fast')}-${i('slow')}-${i('signal')}',
          () => macd(
            closes,
            fast: i('fast'),
            slow: i('slow'),
            signalPeriod: i('signal'),
          ).macd,
        );
      case Indicator.macdSignal:
        return _get(
          'macdSig${i('fast')}-${i('slow')}-${i('signal')}',
          () => macd(
            closes,
            fast: i('fast'),
            slow: i('slow'),
            signalPeriod: i('signal'),
          ).signal,
        );
      case Indicator.bollUpper:
        return _get(
          'bbU${i('period')}-${i('mult')}',
          () => bollinger(
            closes,
            period: i('period'),
            multiplier: (p['mult'] ?? 2).toDouble(),
          ).upper,
        );
      case Indicator.bollLower:
        return _get(
          'bbL${i('period')}-${i('mult')}',
          () => bollinger(
            closes,
            period: i('period'),
            multiplier: (p['mult'] ?? 2).toDouble(),
          ).lower,
        );
      case Indicator.atrPercent:
        return _get('atrP${i('period')}', () => atrPercent(bars, i('period')));
      case Indicator.adx:
        return _get('adx${i('period')}', () => adx(bars, i('period')).adx);
      case Indicator.plusDi:
        return _get('pdi${i('period')}', () => adx(bars, i('period')).plusDi);
      case Indicator.minusDi:
        return _get('mdi${i('period')}', () => adx(bars, i('period')).minusDi);
      case Indicator.stochK:
        return _get(
          'k${i('period')}',
          () => stochastic(bars, kPeriod: i('period')).k,
        );
      case Indicator.volumeRatio:
        return _get('vol${i('period')}', () {
          final avg = volumeSma(bars, i('period'));
          return List<double?>.generate(bars.length, (idx) {
            final a = avg[idx];
            if (a == null || a == 0) return null;
            return bars[idx].volume / a;
          });
        });
      case Indicator.range52:
        return _get(
          'r52${i('period')}',
          () => rangePercent52w(bars, lookback: i('period')),
        );
      case Indicator.roc:
        return _get('roc${i('period')}', () => roc(closes, i('period')));
      case Indicator.rsiRising:
      case Indicator.rsiFalling:
        return _get('rsi${i('period')}', () => rsi(closes, i('period')));
      case Indicator.smaCrossAbove:
      case Indicator.smaCrossBelow:
        // Cross ke liye dono series chahiye — rule khud `series` se poochta hai.
        return _get('sma${i('period')}', () => sma(closes, i('period')));
      case Indicator.macdCrossAboveSignal:
      case Indicator.macdCrossBelowSignal:
        return _get(
          'macd${i('fast')}-${i('slow')}-${i('signal')}',
          () => macd(
            closes,
            fast: i('fast'),
            slow: i('slow'),
            signalPeriod: i('signal'),
          ).macd,
        );
    }
  }

  /// Cross indicators ke "doosra" series.
  Series other(Indicator indicator, Map<String, num> params, Rule rule) {
    final p = {...indicator.defaultParams, ...params};
    int i(String k) => (p[k] ?? 0).toInt();
    switch (indicator) {
      case Indicator.smaCrossAbove:
      case Indicator.smaCrossBelow:
        return _get('sma${i('other')}', () => sma(closes, i('other')));
      case Indicator.macdCrossAboveSignal:
      case Indicator.macdCrossBelowSignal:
        return _get(
          'macdSig${i('fast')}-${i('slow')}-${i('signal')}',
          () => macd(
            closes,
            fast: i('fast'),
            slow: i('slow'),
            signalPeriod: i('signal'),
          ).signal,
        );
      default:
        return const [];
    }
  }

  /// Ek rule bar `index` par sach hai ya nahi. Warm-up par `null`.
  bool? evaluate(Rule rule, int index) {
    final ind = rule.indicator;
    final params = rule.effectiveParams;

    if (ind.isTrend) {
      final s = of(ind, params);
      final days = (params['days'] ?? 3).toInt();
      if (s[index] == null) return null;
      return ind == Indicator.rsiRising
          ? risingFor(s, index, days)
          : fallingFor(s, index, days);
    }

    if (ind.isCross) {
      final a = of(ind, params);
      final b = other(ind, params, rule);
      if (index < 1 || a[index] == null || b[index] == null) return null;
      return ind == Indicator.smaCrossAbove ||
              ind == Indicator.macdCrossAboveSignal
          ? crossedAbove(a, b, index)
          : crossedBelow(a, b, index);
    }

    final left = of(ind, params)[index];
    if (left == null) return null;
    if (rule.compareTo != null) {
      final right = of(rule.compareTo!, rule.against ?? const {})[index];
      if (right == null) return null;
      return rule.op.test(left, right);
    }
    return rule.op.test(left, rule.value.toDouble());
  }
}

/// Ek strategy + ek stock ke bars → us stock ke trades.
///
/// [windowStart] se pehle ke bars sirf **warm-up** hain (indicator banana),
/// trade sirf uske baad wale bars par. Yehi no-look-ahead ka practical hissa.
SymbolResult runOnBars({
  required String symbol,
  required List<Bar> bars,
  required Strategy strategy,
  required DateTime? windowStart,
}) {
  if (bars.length < strategy.settings.minBars) {
    return SymbolResult(
      symbol: symbol,
      trades: const [],
      skip: StrategySkip(
        symbol,
        'data kam — ${bars.length} bars (chahiye ${strategy.settings.minBars})',
      ),
    );
  }
  if (strategy.entry.isEmpty) {
    return SymbolResult(
      symbol: symbol,
      trades: const [],
      skip: const StrategySkip('', 'entry rule nahi'),
    );
  }

  final ctx = _Indicators(bars);
  final settings = strategy.settings;
  final trades = <StrategyTrade>[];
  var entryIndex = -1;

  for (var i = 0; i < bars.length; i++) {
    final inWindow = windowStart == null || !bars[i].time.isBefore(windowStart);

    if (entryIndex < 0) {
      if (!inWindow) continue;
      final checks = <bool>[];
      var warm = false;
      for (final rule in strategy.entry) {
        final v = ctx.evaluate(rule, i);
        if (v == null) {
          warm = true;
          break;
        }
        checks.add(v);
      }
      if (warm) continue;
      if (strategy.entryJoin.combine(checks)) entryIndex = i;
      continue;
    }

    // ---- position khuli hai: stop → target → exit rule → time stop ------
    final entryBar = bars[entryIndex];
    final entryPrice = entryBar.close;
    var exitPrice = bars[i].close;
    var reason = 'exit';
    var done = false;

    if (settings.stopLossPct > 0) {
      final stop = entryPrice * (1 - settings.stopLossPct / 100);
      if (bars[i].low <= stop) {
        // Gap-down: open hi stop se neeche ho to open par fill.
        exitPrice = math.min(bars[i].open, stop);
        reason = 'stop';
        done = true;
      }
    }
    if (!done && settings.targetPct > 0) {
      final target = entryPrice * (1 + settings.targetPct / 100);
      if (bars[i].high >= target) {
        exitPrice = math.max(bars[i].open, target);
        reason = 'target';
        done = true;
      }
    }
    if (!done && strategy.exit.isNotEmpty) {
      final checks = <bool>[];
      var warm = false;
      for (final rule in strategy.exit) {
        final v = ctx.evaluate(rule, i);
        if (v == null) {
          warm = true;
          break;
        }
        checks.add(v);
      }
      if (!warm && strategy.exitJoin.combine(checks)) {
        exitPrice = bars[i].close;
        reason = 'exit';
        done = true;
      }
    }
    if (!done &&
        settings.timeStopBars > 0 &&
        i - entryIndex >= settings.timeStopBars) {
      exitPrice = bars[i].close;
      reason = 'time';
      done = true;
    }

    if (done) {
      trades.add(
        _makeTrade(
          symbol: symbol,
          bars: bars,
          entryIndex: entryIndex,
          exitIndex: i,
          entryPrice: entryPrice,
          exitPrice: exitPrice,
          reason: reason,
          costPct: settings.costPct,
        ),
      );
      entryIndex = -1;
    }
  }

  // Window ke end par khuli position — mark-to-market par band (honest: reason 'end').
  if (entryIndex >= 0) {
    trades.add(
      _makeTrade(
        symbol: symbol,
        bars: bars,
        entryIndex: entryIndex,
        exitIndex: bars.length - 1,
        entryPrice: bars[entryIndex].close,
        exitPrice: bars.last.close,
        reason: 'end',
        costPct: settings.costPct,
      ),
    );
  }

  return SymbolResult(symbol: symbol, trades: trades);
}

StrategyTrade _makeTrade({
  required String symbol,
  required List<Bar> bars,
  required int entryIndex,
  required int exitIndex,
  required double entryPrice,
  required double exitPrice,
  required String reason,
  required double costPct,
}) {
  var hi = entryPrice;
  var lo = entryPrice;
  for (var k = entryIndex; k <= exitIndex; k++) {
    hi = math.max(hi, bars[k].high);
    lo = math.min(lo, bars[k].low);
  }
  final gross = entryPrice == 0 ? 0.0 : (exitPrice / entryPrice - 1) * 100;
  return StrategyTrade(
    symbol: symbol,
    entryIndex: entryIndex,
    exitIndex: exitIndex,
    entryDate: bars[entryIndex].time,
    exitDate: bars[exitIndex].time,
    entryPrice: entryPrice,
    exitPrice: exitPrice,
    returnPct: gross,
    netPct: gross - costPct,
    bars: exitIndex - entryIndex,
    reason: reason,
    maePct: entryPrice == 0 ? 0 : (lo / entryPrice - 1) * 100,
    mfePct: entryPrice == 0 ? 0 : (hi / entryPrice - 1) * 100,
  );
}

/// Ek portfolio run ka poora result.
class BacktestResult {
  const BacktestResult({
    required this.trades,
    required this.skips,
    required this.equity,
    required this.equityDates,
    required this.benchmark,
    required this.benchmarkDates,
    required this.monthly,
    required this.stats,
    required this.skippedTrades,
    required this.windowStart,
    required this.windowEnd,
    required this.symbolsScanned,
  });

  final List<StrategyTrade> trades;
  final List<StrategySkip> skips;

  /// Portfolio equity (shuru = 1.0), har trading date par.
  final List<double> equity;
  final List<DateTime> equityDates;

  /// Benchmark = universe ka equal-weight buy & hold (shuru = 1.0).
  final List<double> benchmark;
  final List<DateTime> benchmarkDates;

  /// 'yyyy-MM' → us mahine ka portfolio return %.
  final Map<String, double> monthly;

  final BacktestStats stats;

  /// Signals jo aaye par slots full the (honest disclosure).
  final int skippedTrades;

  final DateTime windowStart;
  final DateTime windowEnd;
  final int symbolsScanned;

  /// 1.5.107 — `scan_runs` se report wapas (Strategy Builder ka report cache).
  factory BacktestResult.fromJson(Map<String, dynamic> j) {
    DateTime day(Object? raw, DateTime fallback) =>
        DateTime.tryParse('$raw') ?? fallback;
    final start = day(j['windowStart'], DateTime(2015));
    return BacktestResult(
      trades: [
        for (final t in (j['trades'] as List? ?? const []))
          if (t is Map) StrategyTrade.fromJson(t.cast<String, dynamic>()),
      ],
      skips: [
        for (final s in (j['skips'] as List? ?? const []))
          if (s is Map) StrategySkip('${s['symbol']}', '${s['reason']}'),
      ],
      equity: [
        for (final v in (j['equity'] as List? ?? const []))
          if (v is num) v.toDouble(),
      ],
      equityDates: [
        for (final d in (j['equityDates'] as List? ?? const []))
          day(d, start),
      ],
      benchmark: [
        for (final v in (j['benchmark'] as List? ?? const []))
          if (v is num) v.toDouble(),
      ],
      benchmarkDates: [
        for (final d in (j['benchmarkDates'] as List? ?? const []))
          day(d, start),
      ],
      monthly: {
        for (final e in ((j['monthly'] as Map?) ?? const {}).entries)
          if (e.value is num) '${e.key}': (e.value as num).toDouble(),
      },
      stats: BacktestStats.fromJson(
        Map<String, dynamic>.from((j['stats'] as Map?) ?? const {}),
      ),
      skippedTrades: (j['skippedTrades'] as num? ?? 0).toInt(),
      windowStart: start,
      windowEnd: day(j['windowEnd'], start),
      symbolsScanned: (j['symbolsScanned'] as num? ?? 0).toInt(),
    );
  }

  Map<String, dynamic> toJson() => {
    'trades': trades.map((t) => t.toJson()).toList(),
    'skips': skips
        .map((s) => {'symbol': s.symbol, 'reason': s.reason})
        .toList(),
    'equity': equity,
    'equityDates': equityDates
        .map((d) => d.toIso8601String().split('T').first)
        .toList(),
    'benchmark': benchmark,
    'benchmarkDates': benchmarkDates
        .map((d) => d.toIso8601String().split('T').first)
        .toList(),
    'monthly': monthly,
    'stats': stats.toJson(),
    'skippedTrades': skippedTrades,
    'windowStart': windowStart.toIso8601String().split('T').first,
    'windowEnd': windowEnd.toIso8601String().split('T').first,
    'symbolsScanned': symbolsScanned,
  };
}

class BacktestStats {
  /// 1.5.107 — cache se report wapas banane ke liye (same fields, koi guess
  /// nahi; jo field cache me nahi hai uske liye default chalta hai).
  factory BacktestStats.fromJson(Map<String, dynamic> j) {
    double d(String k) => (j[k] as num? ?? 0).toDouble();
    return BacktestStats(
      trades: (j['trades'] as num? ?? 0).toInt(),
      winRate: d('winRate'),
      avgTrade: d('avgTrade'),
      medianTrade: d('medianTrade'),
      avgWin: d('avgWin'),
      avgLoss: d('avgLoss'),
      profitFactor: d('profitFactor'),
      avgBars: d('avgBars'),
      maxDrawdownPct: d('maxDrawdownPct'),
      totalReturnPct: d('totalReturnPct'),
      expectancyPct: d('expectancyPct'),
      niftyReturnPct: (j['niftyReturnPct'] as num?)?.toDouble(),
      niftyMaxDrawdownPct: (j['niftyMaxDrawdownPct'] as num?)?.toDouble(),
    );
  }

  const BacktestStats({
    required this.trades,
    required this.winRate,
    required this.avgTrade,
    required this.medianTrade,
    required this.avgWin,
    required this.avgLoss,
    required this.profitFactor,
    required this.avgBars,
    required this.maxDrawdownPct,
    required this.totalReturnPct,
    required this.expectancyPct,
    this.niftyReturnPct,
    this.niftyMaxDrawdownPct,
  });

  final int trades;
  final double winRate;
  final double avgTrade;
  final double medianTrade;
  final double avgWin;
  final double avgLoss;
  final double profitFactor;
  final double avgBars;
  final double maxDrawdownPct;
  final double totalReturnPct;
  final double expectancyPct;

  /// 1.5.103 — Nifty 50 ka wahi window ka buy & hold (agar data mila).
  final double? niftyReturnPct;
  final double? niftyMaxDrawdownPct;

  Map<String, dynamic> toJson() => {
    'trades': trades,
    'winRate': winRate,
    'avgTrade': avgTrade,
    'medianTrade': medianTrade,
    'avgWin': avgWin,
    'avgLoss': avgLoss,
    'profitFactor': profitFactor,
    'avgBars': avgBars,
    'maxDrawdownPct': maxDrawdownPct,
    'totalReturnPct': totalReturnPct,
    'expectancyPct': expectancyPct,
    if (niftyReturnPct != null) 'niftyReturnPct': niftyReturnPct,
    if (niftyMaxDrawdownPct != null) 'niftyMaxDrawdownPct': niftyMaxDrawdownPct,
  };
}

/// Saare stocks ke trades → ek portfolio (slots + equity + benchmark + monthly).
BacktestResult runPortfolio({
  required List<SymbolResult> results,
  required StrategySettings settings,
  required DateTime windowStart,
  required DateTime windowEnd,
  Map<String, List<Bar>> barsBySymbol = const {},

  /// 1.5.103 — Nifty 50 ke bars (optional). Milne par stats me Nifty ka
  /// return/drawdown aata hai — report "strategy vs nifty" compare kar sakti hai.
  List<Bar>? niftyBars,
}) {
  final trades = <StrategyTrade>[];
  final skips = <StrategySkip>[];
  for (final r in results) {
    if (r.skip != null) skips.add(r.skip!);
    trades.addAll(r.trades);
  }
  trades.sort((a, b) {
    final byDate = a.entryDate.compareTo(b.entryDate);
    return byDate != 0 ? byDate : a.symbol.compareTo(b.symbol);
  });

  // ---- trading calendar: window ke andar ke saare bar dates --------------
  final dateSet = <DateTime>{};
  for (final bars in barsBySymbol.values) {
    for (final b in bars) {
      if (!b.time.isBefore(windowStart) && !b.time.isAfter(windowEnd)) {
        dateSet.add(DateTime(b.time.year, b.time.month, b.time.day));
      }
    }
  }
  final dates = dateSet.toList()..sort();
  if (dates.isEmpty) {
    return BacktestResult(
      trades: trades,
      skips: skips,
      equity: const [1.0],
      equityDates: [windowStart],
      benchmark: const [1.0],
      benchmarkDates: [windowStart],
      monthly: const {},
      stats: _stats(trades, const [1.0]),
      skippedTrades: 0,
      windowStart: windowStart,
      windowEnd: windowEnd,
      symbolsScanned: results.length,
    );
  }

  // ---- slots model -------------------------------------------------------
  final slots = math.max(1, settings.maxPositions);
  final weight = 1.0 / slots;
  final byEntry = <DateTime, List<StrategyTrade>>{};
  for (final t in trades) {
    final key = DateTime(t.entryDate.year, t.entryDate.month, t.entryDate.day);
    byEntry.putIfAbsent(key, () => []).add(t);
  }

  // Open positions: (exitDate, netPct, weight) — entry wale din se agle din tak
  // capital blocked. Exit date par us din ke close ke baad free (equity us
  // din end me update hoti hai — thoda conservative, honest).
  final open = <({DateTime exitDate, double netPct, double w})>[];
  final equity = <double>[];
  final monthlyCapital = <String, ({double start, double end})>{};
  var cap = 1.0;
  var skipped = 0;
  final investedDays = <DateTime, double>{};

  for (final day in dates) {
    // Aaj ke signals → slots me daalo (pehle se aaye hue pehle).
    final todays = byEntry[day] ?? const <StrategyTrade>[];
    for (final t in todays) {
      if (open.length >= slots) {
        skipped++;
        continue;
      }
      open.add((
        exitDate: DateTime(t.exitDate.year, t.exitDate.month, t.exitDate.day),
        netPct: t.netPct,
        w: weight,
      ));
    }

    // Aaj band hone wali positions — **aaj ke** equity me hi settle (exit din
    // ke close par trade band hota hai, to usi din ka hissa hai).
    final still = <({DateTime exitDate, double netPct, double w})>[];
    for (final p in open) {
      if (!p.exitDate.isAfter(day)) {
        cap *= 1 + p.netPct / 100 * p.w;
      } else {
        still.add(p);
      }
    }
    open
      ..clear()
      ..addAll(still);

    equity.add(cap);
    investedDays[day] = open.length / slots;
    final key = '${day.year}-${day.month.toString().padLeft(2, '0')}';
    final prev = monthlyCapital[key];
    monthlyCapital[key] = (start: prev?.start ?? cap, end: cap);
  }

  // ---- monthly returns ---------------------------------------------------
  final monthly = <String, double>{
    for (final e in monthlyCapital.entries)
      e.key: (e.value.end / e.value.start - 1) * 100,
  };

  // ---- benchmark: equal-weight buy & hold of the same universe ----------
  final benchmark = <double>[];
  final firstDate = dates.first;
  final baselines = <String, double>{};
  for (final entry in barsBySymbol.entries) {
    for (final b in entry.value) {
      final d = DateTime(b.time.year, b.time.month, b.time.day);
      if (!d.isBefore(firstDate)) {
        baselines[entry.key] = b.open > 0 ? b.open : b.close;
        break;
      }
    }
  }
  for (final d in dates) {
    var sum = 0.0;
    var n = 0;
    for (final entry in barsBySymbol.entries) {
      final base = baselines[entry.key];
      if (base == null) continue;
      Bar? last;
      for (final b in entry.value) {
        final bd = DateTime(b.time.year, b.time.month, b.time.day);
        if (bd.isAfter(d)) break;
        last = b;
      }
      if (last == null) continue;
      sum += last.close / base;
      n++;
    }
    benchmark.add(n == 0 ? 1.0 : sum / n);
  }

  // ---- Nifty 50 benchmark (aligned to the same date axis) ----------------
  double? niftyReturn;
  double? niftyDd;
  if (niftyBars != null && niftyBars.length > 1) {
    final curve = _alignedBuyHold(niftyBars, dates);
    if (curve != null) {
      niftyReturn = (curve.last - 1) * 100;
      var peak = curve.first;
      var dd = 0.0;
      for (final v in curve) {
        if (v > peak) peak = v;
        dd = math.max(dd, peak > 0 ? (1 - v / peak) * 100 : 0);
      }
      niftyDd = dd;
    }
  }

  final baseStats = _stats(trades, equity);

  return BacktestResult(
    trades: trades,
    skips: skips,
    equity: equity,
    equityDates: dates,
    benchmark: benchmark,
    benchmarkDates: dates,
    monthly: monthly,
    stats: BacktestStats(
      trades: baseStats.trades,
      winRate: baseStats.winRate,
      avgTrade: baseStats.avgTrade,
      medianTrade: baseStats.medianTrade,
      avgWin: baseStats.avgWin,
      avgLoss: baseStats.avgLoss,
      profitFactor: baseStats.profitFactor,
      avgBars: baseStats.avgBars,
      maxDrawdownPct: baseStats.maxDrawdownPct,
      totalReturnPct: baseStats.totalReturnPct,
      expectancyPct: baseStats.expectancyPct,
      niftyReturnPct: niftyReturn,
      niftyMaxDrawdownPct: niftyDd,
    ),
    skippedTrades: skipped,
    windowStart: windowStart,
    windowEnd: windowEnd,
    symbolsScanned: results.length,
  );
}

BacktestStats _stats(List<StrategyTrade> trades, List<double> equity) {
  if (trades.isEmpty) {
    return const BacktestStats(
      trades: 0,
      winRate: 0,
      avgTrade: 0,
      medianTrade: 0,
      avgWin: 0,
      avgLoss: 0,
      profitFactor: 0,
      avgBars: 0,
      maxDrawdownPct: 0,
      totalReturnPct: 0,
      expectancyPct: 0,
    );
  }
  final nets = trades.map((t) => t.netPct).toList()..sort();
  final wins = nets.where((n) => n > 0).toList();
  final losses = nets.where((n) => n <= 0).toList();
  final sumWin = wins.fold<double>(0, (a, b) => a + b);
  final sumLoss = losses.fold<double>(0, (a, b) => a + b);
  final median = nets.length.isOdd
      ? nets[nets.length ~/ 2]
      : (nets[nets.length ~/ 2 - 1] + nets[nets.length ~/ 2]) / 2;

  var peak = equity.isEmpty ? 1.0 : equity.first;
  var maxDd = 0.0;
  for (final e in equity) {
    peak = math.max(peak, e);
    if (peak > 0) maxDd = math.max(maxDd, (1 - e / peak) * 100);
  }

  final avg = nets.fold<double>(0, (a, b) => a + b) / nets.length;
  final winRate = 100 * wins.length / nets.length;
  final avgWin = wins.isEmpty ? 0.0 : sumWin / wins.length;
  final avgLoss = losses.isEmpty ? 0.0 : sumLoss / losses.length;

  return BacktestStats(
    trades: nets.length,
    winRate: winRate,
    avgTrade: avg,
    medianTrade: median,
    avgWin: avgWin,
    avgLoss: avgLoss,
    profitFactor: sumLoss == 0 ? (sumWin > 0 ? 99 : 0) : sumWin / sumLoss.abs(),
    avgBars: trades.fold<double>(0, (a, t) => a + t.bars) / trades.length,
    maxDrawdownPct: maxDd,
    totalReturnPct: equity.isEmpty ? 0 : (equity.last - 1) * 100,
    // Expectancy = (win% × avg win) + (loss% × avg loss) — per trade %.
    expectancyPct: winRate / 100 * avgWin + (1 - winRate / 100) * avgLoss,
  );
}

/// Bench ke liye simple benchmark series (single index/stock).
List<double> buyHoldCurve(List<Bar> bars, DateTime? from) {
  final start = bars.indexWhere((b) => from == null || !b.time.isBefore(from));
  if (start < 0) return const [];
  final base = bars[start].close;
  if (base == 0) return const [];
  return [for (final b in bars.sublist(start)) b.close / base];
}

/// Nifty bars ko portfolio ki date axis par align karke buy & hold curve (1.0
/// se shuru). Bars na hon / base 0 ho to null — caller "—" dikhata hai.
List<double>? _alignedBuyHold(List<Bar> bars, List<DateTime> dates) {
  if (dates.isEmpty) return null;
  DateTime day(Bar b) => DateTime(b.time.year, b.time.month, b.time.day);
  Bar? base;
  for (final b in bars) {
    if (!day(b).isBefore(dates.first)) {
      base = b;
      break;
    }
  }
  if (base == null || base.open <= 0) return null;
  final basePx = base.open;
  final curve = <double>[];
  var idx = 0;
  Bar? last;
  for (final d in dates) {
    while (idx < bars.length && !day(bars[idx]).isAfter(d)) {
      last = bars[idx];
      idx++;
    }
    if (last == null) {
      curve.add(1.0);
    } else {
      curve.add(last.close / basePx);
    }
  }
  return curve;
}
