// ---------------------------------------------------------------------------
// strategy_builder_provider.dart — UI ka state + data plumbing.
//
// Zimmedari:
//   • universe resolve karna (wahi `UniverseCatalog`, wahi rules jo baaki app
//     me hain — F&O list ke liye `fnoSymbols` dena **zaroori** hai, warna
//     universe khaali aata hai; 1.5.100 ka sabak),
//   • daily bars laana (LocalBarsLoader: SQLite cache + Angel), 3 req/s ke
//     andar (`mapPool(concurrency: 3)`),
//   • progress + cancel (cancel par jo chal raha hai wo rukta hai, aur report
//     "adhoora" likh kar dikhti hai — chhupaya nahi jaata),
//   • strategy CRUD (settings table me JSON — ek hi sach, koi naya table nahi),
//   • aur result ko UI ke liye pakka karna.
//
// Engine yahan nahi hai — wo `strategy_engine.dart` (pure) me hai, isliye
// numbers ka test engine par hota hai aur UI sirf dikhata hai.
// ---------------------------------------------------------------------------

import 'dart:convert';

import 'package:flutter/foundation.dart';

import '../../core/utils/parallel_pool.dart';
import '../../data/local/dao/candle_dao.dart';
import '../../data/local/dao/ipo_dao.dart';
import '../../data/local/dao/scrip_dao.dart';
import '../../data/local/dao/scan_cache_dao.dart';
import '../../data/local/dao/settings_dao.dart';
import '../../data/remote/dto/candle.dart';
import '../../data/remote/dto/scrip.dart';
import '../../services/candle_source.dart';
import '../../services/cross_scan_service.dart' show ScanUniverse;
import '../../services/daily_bars_loader.dart';
import '../../services/fno_universe.dart';
import '../../services/token_resolver.dart';
import '../../services/universe_catalog.dart';
import '../../data/remote/dto/scrip.dart' show Scrip;
import 'index_bar_source.dart';
import 'index_catalog.dart';
import 'strategy_engine.dart';
import 'strategy_fundamentals.dart';
import 'strategy_indicators.dart';
import 'strategy_rules.dart';

enum BuilderStatus { idle, resolving, running, ready, error, cancelled }

/// Fundamentals loader ka seam — symbol (NSE ticker) → snapshot.
typedef FundamentalLoader = Future<FundamentalSnapshot> Function(String symbol);

/// Broker se index candles lene ka seam (tests me fake).
typedef IndexBarFetcher =
    Future<List<Candle>> Function(BenchIndex index, DateTime from, DateTime to);

/// Ek saved strategy ka halka reference (list ke liye).
class SavedStrategy {
  const SavedStrategy({required this.strategy, required this.savedAt});

  final Strategy strategy;
  final DateTime savedAt;
}

class StrategyBuilderProvider extends ChangeNotifier {
  StrategyBuilderProvider({
    required CandleSource source,
    required CandleDao candles,
    required ScripDao scripDao,
    required IpoDao ipoDao,
    required SettingsDao settingsDao,
    ScanCacheDao? cache,
    FnoUniverse? fnoUniverse,
    IndexBarFetcher? indexBars,
    YahooIndexSource? yahoo,
    FundamentalLoader? fundamentals,
    DateTime Function()? clock,
  }) : _indexBars = indexBars,
       _fundamentals = fundamentals,
       _yahoo = yahoo,
       _source = source,
       _candles = candles,
       _scripDao = scripDao,
       _ipoDao = ipoDao,
       _settingsDao = settingsDao,
       _cache = cache,
       _fno = fnoUniverse,
       _clock = clock ?? DateTime.now;

  final CandleSource _source;
  final CandleDao _candles;
  final ScripDao _scripDao;
  final IpoDao _ipoDao;
  final SettingsDao _settingsDao;

  /// 1.5.107 — aakhri report ka cache (`scan_runs`, kind `strategy_builder`),
  /// taaki app kholne par report screen khaali na mile.
  final ScanCacheDao? _cache;
  FnoUniverse? _fno;
  final IndexBarFetcher? _indexBars;
  final FundamentalLoader? _fundamentals;
  final YahooIndexSource? _yahoo;
  final DateTime Function() _clock;

  /// Index run ke baad: data kahan se aaya (report me label ke liye).
  IndexSourceKind? indexSource;
  String? indexNote;

  /// Out-of-sample split (70/30) — pehla 70% "in-sample", aakhri 30% "test".
  BacktestResult? oosTrain;
  BacktestResult? oosTest;
  double oosSplit = 0.7;

  bool get isIndex => _index() != null;

  static const String savedKey = 'strategy_builder_saved';
  static const String lastUsedKey = 'strategy_builder_last';
  static const String fundamentalsKey = 'strategy_builder_fundamentals';

  // ---- state ------------------------------------------------------------
  Strategy _strategy = tripleRsiPreset();
  Strategy get strategy => _strategy;

  BuilderStatus status = BuilderStatus.idle;
  String? progress;
  String? error;
  BacktestResult? result;

  /// Jab [result] cache se aaya ho — us report ka din (UI label ke liye).
  DateTime? resultCachedOn;
  bool get running =>
      status == BuilderStatus.resolving || status == BuilderStatus.running;

  int resolvedSymbols = 0;
  int scanned = 0;
  int total = 0;
  bool _cancelled = false;

  List<SavedStrategy> saved = [];

  /// Fundamentals cache (symbol → snapshot). Filings roz nahi badalti, isliye
  /// ek din tak reuse — aur report me "aaj ka snapshot" saaf likha jaata hai.
  final Map<String, FundamentalSnapshot> _fundamentalsCache = {};
  DateTime? _fundamentalsFetchedAt;

  /// Kitne stocks fundamentals data ke bina chhode gaye (report ke liye).
  final Map<String, String> fundamentalsBlocked = {};
  final Set<String> fundamentalsMissing = {};

  /// Universe picker ke liye (UI `UniverseCatalog.all` dikhata hai).
  static List<ScanUniverse> get universes => UniverseCatalog.all;

  // ---- strategy editing --------------------------------------------------
  void update(Strategy next) {
    _strategy = next;
    notifyListeners();
  }

  void loadPreset(Strategy preset) {
    _strategy = preset;
    notifyListeners();
  }

  /// Ek rule jodo. Naya rule usi indicator ka pehla default hota hai.
  void addRule({required bool entry, Indicator indicator = Indicator.rsi}) {
    final rule = Rule(indicator: indicator);
    _strategy = entry
        ? _strategy.copyWith(entry: [..._strategy.entry, rule])
        : _strategy.copyWith(exit: [..._strategy.exit, rule]);
    notifyListeners();
  }

  void replaceRule({
    required bool entry,
    required int index,
    required Rule rule,
  }) {
    final list = [...(entry ? _strategy.entry : _strategy.exit)];
    if (index < 0 || index >= list.length) return;
    list[index] = rule;
    _strategy = entry
        ? _strategy.copyWith(entry: list)
        : _strategy.copyWith(exit: list);
    notifyListeners();
  }

  void removeRule({required bool entry, required int index}) {
    final list = [...(entry ? _strategy.entry : _strategy.exit)];
    if (index < 0 || index >= list.length) return;
    list.removeAt(index);
    _strategy = entry
        ? _strategy.copyWith(entry: list)
        : _strategy.copyWith(exit: list);
    notifyListeners();
  }

  void setJoin({required bool entry, required RuleJoin join}) {
    _strategy = entry
        ? _strategy.copyWith(entryJoin: join)
        : _strategy.copyWith(exitJoin: join);
    notifyListeners();
  }

  void setUniverse(String key) {
    _strategy = _strategy.copyWith(universeKey: key);
    notifyListeners();
  }

  void setSettings(StrategySettings settings) {
    _strategy = _strategy.copyWith(settings: settings);
    notifyListeners();
  }

  void cancel() {
    if (!running) return;
    _cancelled = true;
    progress = 'Ruk raha hai…';
    notifyListeners();
  }

  BenchIndex? _index() {
    for (final i in IndexCatalog.all) {
      if (i.cacheSymbol == _strategy.universeKey) return i;
    }
    return null;
  }

  // ---- estimate (run se pehle honest number) -----------------------------
  /// Kitne stocks hain + pehli baar kitna time lag sakta hai.
  Future<({int symbols, String estimate})> estimate() async {
    if (isIndex) {
      return (symbols: 1, estimate: 'index · 1 series · ~10 sec');
    }
    try {
      final scrips = await _resolveScrips();
      final fresh = await _candles.count();
      final mins = (scrips.length * 0.45).ceil();
      return (
        symbols: scrips.length,
        estimate: fresh == 0
            ? 'pehli baar ~$mins min (candles download honge)'
            : 'cache se — ~${(scrips.length * 0.02).ceil()} min',
      );
    } catch (_) {
      return (symbols: 0, estimate: 'estimate nahi bana');
    }
  }

  // ---- run ---------------------------------------------------------------
  Future<void> run() async {
    if (running) return;
    _cancelled = false;
    error = null;
    result = null;
    resolvedSymbols = 0;
    scanned = 0;
    total = 0;
    status = BuilderStatus.resolving;
    progress = 'Universe resolve ho raha hai…';
    notifyListeners();

    try {
      final idx = _index();
      if (idx != null) {
        await _runIndex(idx);
        return;
      }
      var scrips = await _resolveScrips();
      resolvedSymbols = scrips.length;

      // 1.5.104 — fundamentals filter (sirf tab jab active ho).
      if (_strategy.fundamentals.isActive && scrips.isNotEmpty) {
        final filtered = await _applyFundamentals(scrips);
        if (filtered != null) scrips = filtered;
        if (_cancelled) {
          _finishCancelled();
          return;
        }
        if (scrips.isEmpty) {
          status = BuilderStatus.error;
          error =
              'Fundamentals filter ne saare stocks hata diye — filter dheela '
              'kariye ya "sirf jinke fundamentals mile" band kariye.';
          notifyListeners();
          return;
        }
      }

      if (_cancelled) {
        _finishCancelled();
        return;
      }
      if (scrips.isEmpty) {
        status = BuilderStatus.error;
        error =
            'Is universe me 0 symbol mila — doosra universe chuniye '
            '(F&O / Nifty 50 / All NSE).';
        notifyListeners();
        return;
      }

      final tf = _strategy.settings.timeframe;
      final years = tf.isIntraday ? 1 : _strategy.settings.years.clamp(1, 5);
      final today = _today();
      final windowStart = tf.isIntraday
          ? today.subtract(Duration(days: tf.maxLookbackDays))
          : DateTime(today.year - years, today.month, today.day);
      // Daily: warm-up (SMA200/RSI/ADX) ke liye 400 extra din.
      // Intraday: broker 100 din se zyada 5/15-min nahi deta — poora window
      // hi warm-up ke saath aata hai, aur report "chhota window" likhti hai.
      final loader = DailyBarsLoader(
        source: _source,
        candles: _candles,
        minimumBars: 60,
        lookbackDays: tf.isIntraday ? tf.maxLookbackDays : years * 365 + 400,
        deltaFetch: !tf.isIntraday,
      );

      total = scrips.length;
      status = BuilderStatus.running;
      progress = 'Candles aa rahe hain…';
      notifyListeners();

      const chunk = 9;
      final symbolResults = <SymbolResult>[];
      final barsBySymbol = <String, List<Bar>>{};
      final failures = <StrategySkip>[];

      for (var base = 0; base < scrips.length; base += chunk) {
        if (_cancelled) break;
        final batch = scrips.sublist(
          base,
          (base + chunk < scrips.length) ? base + chunk : scrips.length,
        );
        final fetched = await mapPool<Scrip, List<Candle>?>(
          items: batch,
          concurrency: 3,
          isCancelled: () => _cancelled,
          action: (_, scrip) async {
            try {
              if (tf.isIntraday) {
                // Cache-first (same loader), warna interval ke saath seedha call.
                final end = DateTime(
                  today.year,
                  today.month,
                  today.day,
                  15,
                  30,
                );
                final start = end.subtract(
                  Duration(days: tf.maxLookbackDays - 2),
                );
                return await _source.fetchDailyCandles(
                  scrip: scrip,
                  from: start,
                  to: end,
                  interval: tf.apiInterval,
                );
              }
              final result = await loader.barsFor(scrip, today);
              return result.bars;
            } catch (_) {
              return null; // pool me koi exception nahi — neeche skip banta hai
            }
          },
        );
        for (var i = 0; i < batch.length; i++) {
          if (_cancelled) break;
          final scrip = batch[i];
          final symbol = Scrip.plainSymbol(scrip.symbol);
          final candles = fetched[i];
          scanned = base + i + 1;
          if (candles == null || candles.isEmpty) {
            failures.add(StrategySkip(symbol, 'candles nahi mile'));
            continue;
          }
          final bars = [
            for (final c in candles)
              Bar(
                time: c.istDate,
                open: c.open,
                high: c.high,
                low: c.low,
                close: c.close,
                volume: c.volume,
              ),
          ];
          barsBySymbol[symbol] = bars;
          symbolResults.add(
            runOnBars(
              symbol: symbol,
              bars: bars,
              strategy: _strategy,
              windowStart: windowStart,
            ),
          );
        }
        progress =
            'Candles $scanned / $total · ${symbolResults.length} stocks scan hue';
        notifyListeners();
      }

      // 1.5.103 — Nifty 50 benchmark (best effort; na mile to "—").
      final niftyBars = await _niftyBarsFor(windowStart, today);

      final portfolio = runPortfolio(
        niftyBars: niftyBars,
        results: [
          ...symbolResults,
          // Fetch fail hone wale stocks bhi skip list me (chhupaye nahi jaate).
          for (final f in failures)
            SymbolResult(symbol: f.symbol, trades: const [], skip: f),
        ],
        settings: _strategy.settings,
        windowStart: windowStart,
        windowEnd: today,
        barsBySymbol: barsBySymbol,
      );
      result = portfolio;
      resultCachedOn = null;
      await _saveReport(portfolio);
      status = _cancelled ? BuilderStatus.cancelled : BuilderStatus.ready;
      progress = _cancelled
          ? 'Cancel kiya — jo hissa chal chuka wo dikh raha hai'
          : 'Ho gaya · ${portfolio.trades.length} trades';
      notifyListeners();
    } catch (e) {
      status = BuilderStatus.error;
      error = 'Run fail hua: $e';
      notifyListeners();
    }
  }

  /// Index backtest: ek hi series, isliye portfolio model nahi — position
  /// 100% (slots = 1) aur benchmark = **wahi index ka buy & hold**.
  Future<void> _runIndex(BenchIndex index) async {
    status = BuilderStatus.running;
    progress = '${index.label} ke candles aa rahe hain…';
    total = 1;
    scanned = 0;
    notifyListeners();

    final years = _strategy.settings.years.clamp(1, 5);
    final today = _today();
    final windowStart = DateTime(today.year - years, today.month, today.day);
    final from = windowStart.subtract(const Duration(days: 400));

    var bars = const <Bar>[];
    var kind = IndexSourceKind.broker;
    String? note;

    // 1. Broker (primary) — cache se pehle, phir Angel.
    try {
      final scrip = indexScrip(index);
      final loader = DailyBarsLoader(
        source: _brokerIndexSource,
        candles: _candles,
        minimumBars: 60,
        lookbackDays: years * 365 + 400,
      );
      final loaded = await loader.barsFor(scrip, today);
      bars = _toBars(loaded.bars);
      if (bars.length < 60 && !_cancelled) {
        // Cache adhoora — seedha broker call (loader ne cache-first kiya tha).
        final fresh = await _indexBars?.call(index, from, today);
        if (fresh != null && fresh.isNotEmpty) {
          bars = _toBars(fresh);
        }
      }
    } catch (e) {
      note = 'Broker index data fail: $e';
    }

    // 2. Yahoo fallback (labelled) — sirf tab jab broker se kuch na mila.
    if (bars.length < 60 && _yahoo != null && !_cancelled) {
      final fallback = await _yahoo.fetch(index, years: years);
      kind = IndexSourceKind.yahoo;
      if (fallback.bars.isNotEmpty) {
        bars = _toBars(fallback.bars);
        note = [
          'Yahoo fallback use hua — broker (Angel) se ${index.label} ke candles '
              'nahi mile. Yahoo daily close 15:25 IST ka hota hai; official '
              'broker series nahi hai.',
          if (note != null) note,
          if (fallback.note != null) fallback.note!,
        ].join(' ');
      } else {
        note = [
          if (note != null) note,
          if (fallback.note != null) fallback.note!,
        ].join(' ');
      }
    }

    scanned = 1;
    indexSource = kind;
    indexNote = note;
    if (bars.isEmpty || _cancelled) {
      status = _cancelled ? BuilderStatus.cancelled : BuilderStatus.error;
      error = bars.isEmpty
          ? 'Index data available nahi — na broker (Angel) se ${index.label} ke '
                'candles mile, na Yahoo se. Koi number bana kar nahi dikhaya '
                'jaata.'
          : null;
      progress = _cancelled ? 'Cancel kiya' : null;
      notifyListeners();
      return;
    }

    final strategy = _strategy.copyWith(
      settings: _strategy.settings.copyWith(maxPositions: 1),
    );
    final single = runOnBars(
      symbol: index.label,
      bars: bars,
      strategy: strategy,
      windowStart: windowStart,
    );
    final result = runPortfolio(
      results: [single],
      settings: strategy.settings,
      windowStart: windowStart,
      windowEnd: today,
      barsBySymbol: {index.label: bars},
    );
    this.result = result;
    _buildOos(bars, strategy, windowStart, today, index.label);
    status = BuilderStatus.ready;
    progress = 'Ho gaya · ${result.trades.length} trades';
    notifyListeners();
  }

  /// Bars ko window me kaat kar 70/30 split par do backtest.
  ///
  /// 70% par strategy "seekhi" nahi jaati (koi parameter fit nahi hota) —
  /// isliye ye asli walk-forward nahi, sirf **stability check** hai: agar
  /// aakhri 30% me strategy bilkul ulti pad jaaye to us par bharosa mat karo.
  void _buildOos(
    List<Bar> bars,
    Strategy strategy,
    DateTime windowStart,
    DateTime windowEnd,
    String symbol,
  ) {
    oosTrain = null;
    oosTest = null;
    final inWindow = bars
        .where(
          (b) => !b.time.isBefore(windowStart) && !b.time.isAfter(windowEnd),
        )
        .toList();
    if (inWindow.length < 60) return;
    final cut = inWindow[(inWindow.length * oosSplit).floor()];
    final splitAt = DateTime(cut.time.year, cut.time.month, cut.time.day);

    BacktestResult runFor(DateTime a, DateTime b) => runPortfolio(
      results: [
        runOnBars(
          symbol: symbol,
          bars: bars,
          strategy: strategy,
          windowStart: a,
        ),
      ],
      settings: strategy.settings,
      windowStart: a,
      windowEnd: b,
      barsBySymbol: {symbol: bars},
    );

    oosTrain = runFor(windowStart, splitAt);
    oosTest = runFor(splitAt, windowEnd);
  }

  /// Broker candles ka `CandleSource` — index ka token NSE segment par.
  CandleSource get _brokerIndexSource => _IndexCandleSource(
    fetch: (scrip, from, to) async {
      final fetch = _indexBars;
      if (fetch == null) {
        throw StateError('Broker login nahi — index candles nahi aa sakte');
      }
      final index = IndexCatalog.byToken(scrip.token);
      if (index == null) throw StateError('Anjaan index token ${scrip.token}');
      return fetch(index, from, to);
    },
  );

  /// Fundamentals filter lagao. Data na mile to **cached** snapshot use hota
  /// hai; loader hi na ho to filter chupchaap lagta hai sirf jinke data hai
  /// (aur warning me likha jaata hai) — kisi stock ko jhooth se reject nahi
  /// karte.
  Future<List<Scrip>?> _applyFundamentals(List<Scrip> scrips) async {
    final loader = _fundamentals;
    if (loader == null) {
      progress = 'Fundamentals source available nahi — filter lag nahi raha';
      notifyListeners();
      return null;
    }

    await _loadFundamentalsCache();
    fundamentalsBlocked.clear();
    fundamentalsMissing.clear();

    final keep = <Scrip>[];
    const chunk = 9;
    for (var base = 0; base < scrips.length; base += chunk) {
      if (_cancelled) return keep;
      final batch = scrips.sublist(
        base,
        (base + chunk < scrips.length) ? base + chunk : scrips.length,
      );
      progress =
          'Fundamentals ${base + batch.length} / ${scrips.length} (NSE/BSE filings)…';
      notifyListeners();

      for (final scrip in batch) {
        if (_cancelled) return keep;
        final symbol = Scrip.plainSymbol(scrip.symbol);
        var snap = _fundamentalsCache[symbol];
        if (snap == null || snap.missingReason.isNotEmpty) {
          try {
            snap = await loader(symbol);
            _fundamentalsCache[symbol] = snap;
          } catch (_) {
            // Fail par purana cached snapshot (agar hai) hi rehne do.
          }
        }
        final verdict = _strategy.fundamentals.test(snap);
        if (verdict.pass) {
          keep.add(scrip);
          if (snap == null || !snap.hasAny) fundamentalsMissing.add(symbol);
        } else {
          fundamentalsBlocked[symbol] = verdict.reason;
        }
      }
    }

    await _saveFundamentalsCache();
    return keep;
  }

  Future<void> _loadFundamentalsCache() async {
    if (_fundamentalsFetchedAt != null) return;
    try {
      final raw = await _settingsDao.raw();
      final text = raw[fundamentalsKey];
      if (text == null || text.isEmpty) return;
      final decoded = jsonDecode(text);
      if (decoded is! Map) return;
      final at = DateTime.tryParse('${decoded['fetchedAt'] ?? ''}');
      // 1 din se purana cache dobara padha jaata hai (filings update hoti hain).
      if (at == null || _today().difference(at).inDays >= 1) return;
      final rows = decoded['rows'];
      if (rows is! Map) return;
      rows.forEach((key, value) {
        if (value is Map) {
          _fundamentalsCache['$key'] = FundamentalSnapshot.fromJson(
            Map<String, dynamic>.from(value),
          );
        }
      });
      _fundamentalsFetchedAt = at;
    } catch (_) {
      // Kharab cache se run nahi rukta.
    }
  }

  Future<void> _saveFundamentalsCache() async {
    _fundamentalsFetchedAt = _today();
    try {
      await _settingsDao.put(
        fundamentalsKey,
        jsonEncode({
          'fetchedAt': _fundamentalsFetchedAt!.toIso8601String(),
          'rows': {
            for (final e in _fundamentalsCache.entries) e.key: e.value.toJson(),
          },
        }),
      );
    } catch (_) {
      // Cache likhna optional.
    }
  }

  /// Nifty 50 ke bars (broker, warna Yahoo) — stock report ka benchmark.
  /// Fail ho to `null` (report "—" dikhati hai, jhooth nahi).
  Future<List<Bar>?> _niftyBarsFor(DateTime from, DateTime to) async {
    final nifty = IndexCatalog.bySymbol('NIFTY');
    if (nifty == null) return null;
    final withWarmup = from.subtract(const Duration(days: 400));
    try {
      final fetch = _indexBars;
      if (fetch != null) {
        final bars = _toBars(await fetch(nifty, withWarmup, to));
        if (bars.length > 60) return bars;
      }
    } catch (_) {
      // Neeche Yahoo try hoga.
    }
    try {
      final fallback = await _yahoo?.fetch(nifty, years: 5);
      final bars = fallback == null ? const <Bar>[] : _toBars(fallback.bars);
      return bars.length > 60 ? bars : null;
    } catch (_) {
      return null;
    }
  }

  static List<Bar> _toBars(List<Candle> candles) => [
    for (final c in candles)
      Bar(
        time: c.istDate,
        open: c.open,
        high: c.high,
        low: c.low,
        close: c.close,
        volume: c.volume,
      ),
  ];

  void _finishCancelled() {
    status = BuilderStatus.cancelled;
    progress = 'Cancel kiya';
    notifyListeners();
  }

  DateTime _today() {
    final d = _clock();
    return DateTime(d.year, d.month, d.day);
  }

  Future<List<Scrip>> _resolveScrips() async {
    final key = _strategy.universeKey;
    final universe = UniverseCatalog.byKey(key);
    final fno = universe.key == UniverseCatalog.fno
        ? (_fno ??= await FnoUniverse.load())
        : null;
    final resolution = await UniverseCatalog.resolve(
      key,
      scripDao: _scripDao,
      ipoDao: _ipoDao,
      // Har non-master universe ko resolver chahiye (nifty50/fno dono) —
      // 1.5.100 ka sabak: resolver na ho to universe chupchaap khaali aata hai.
      resolver: universe.dynamic == false
          ? TokenResolver.fromScrips(await _scripDao.allEquities())
          : null,
      fnoSymbols: fno?.symbols,
    );
    return resolution.scrips;
  }

  // ---- saved strategies --------------------------------------------------
  Future<void> loadSaved() async {
    try {
      final raw = await _settingsDao.raw();
      final text = raw[savedKey];
      final last = raw[lastUsedKey];
      if (last != null && last.isNotEmpty) {
        _strategy = Strategy.decode(last);
      }
      if (text == null || text.isEmpty) {
        notifyListeners();
        return;
      }
      final list = jsonDecode(text) as List;
      saved = [
        for (final item in list)
          SavedStrategy(
            strategy: Strategy.fromJson(
              Map<String, dynamic>.from(item['strategy'] as Map),
            ),
            savedAt: DateTime.tryParse('${item['savedAt']}') ?? _clock(),
          ),
      ];
    } catch (_) {
      // Kharab saved data se app nahi rukta — khali list dikhati hai.
      saved = [];
    }
    notifyListeners();
  }

  Future<void> saveCurrent({String? name}) async {
    final toSave = name == null || name.trim().isEmpty
        ? _strategy
        : _strategy.copyWith(name: name.trim());
    final existing = saved
        .where((s) => s.strategy.name == toSave.name)
        .toList();
    final next = [
      for (final s in saved)
        if (s.strategy.name != toSave.name) s,
      SavedStrategy(strategy: toSave, savedAt: _clock()),
    ];
    saved = existing.isEmpty ? next : next;
    await _persistSaved();
    await _settingsDao.put(lastUsedKey, toSave.encode());
    _strategy = toSave;
    notifyListeners();
  }

  Future<void> deleteSaved(String name) async {
    saved = [
      for (final s in saved)
        if (s.strategy.name != name) s,
    ];
    await _persistSaved();
    notifyListeners();
  }

  Future<void> _persistSaved() async {
    try {
      await _settingsDao.put(
        savedKey,
        jsonEncode([
          for (final s in saved)
            {
              'strategy': s.strategy.toJson(),
              'savedAt': s.savedAt.toIso8601String(),
            },
        ]),
      );
    } catch (_) {
      // Save fail ho to bhi is session ka kaam chalta rahega.
    }
  }

  /// Strategy file (share/WhatsApp) — ek line ka JSON.
  String exportCurrent() => _strategy.encode();

  /// File se wapas (galat file par crash nahi — false return).
  bool importFrom(String raw) {
    try {
      _strategy = Strategy.decode(raw);
      notifyListeners();
      return true;
    } catch (_) {
      return false;
    }
  }

  /// Run se pehle ka validation — UI isi se "Run" disable karta hai.
  String? validate() {
    if (_strategy.entry.isEmpty) return 'Kam se kam ek entry rule chahiye.';
    if (_strategy.settings.costPct < 0) return 'Cost % negative nahi ho sakta.';
    if (_strategy.settings.maxPositions < 1) return 'Max positions 1+ chahiye.';
    return null;
  }

  /// Report me dikhne wali honest warnings (koi chhupa hua assumption nahi).
  // -------------------------------------------------------------------------
  // Report cache (1.5.107)
  // -------------------------------------------------------------------------

  /// Aakhri backtest ka report cache se (network/data ke bina).
  ///
  /// Pehle report sirf us session me thi: app band karke kholne par "Abhi koi
  /// backtest nahi chala" dikhta tha, bhale kal hi 213 stocks par scan chala ho.
  /// Ab report save rehti hai aur **strategy bhi wahi** wapas lag jaati hai —
  /// warna purana report nayi strategy ke naam ke neeche dikhta (jhooth).
  Future<void> loadReport() async {
    if (_cache == null || result != null) return;
    try {
      final run = await _cache.latestRun(ScanKind.strategyBuilder);
      if (run == null || run.rows.isEmpty) return;
      final payload = run.rows.first;
      final resultRaw = payload['result'];
      final strategyRaw = payload['strategy'];
      if (resultRaw is! Map) return;
      final restored = BacktestResult.fromJson(
        Map<String, dynamic>.from(resultRaw),
      );
      result = restored;
      resultCachedOn = DateTime.tryParse('${payload['asOf'] ?? run.asOf}');
      if (strategyRaw is Map) {
        _strategy = Strategy.fromJson(Map<String, dynamic>.from(strategyRaw));
      }
      status = BuilderStatus.ready;
      notifyListeners();
    } catch (_) {
      // Corrupt cache = koi report nahi (crash nahi).
    }
  }

  /// Report + strategy ko `scan_runs` me likho (best-effort).
  Future<void> _saveReport(BacktestResult portfolio) async {
    final cache = _cache;
    if (cache == null) return;
    try {
      final day = _today();
      await cache.saveRun(
        kind: ScanKind.strategyBuilder,
        asOf: _isoDay(day),
        rows: [
          {
            'asOf': _isoDay(day),
            'strategy': _strategy.toJson(),
            'result': portfolio.toJson(),
          },
        ],
      );
    } catch (_) {
      // Report save fail ho to backtest ka result kam nahi hota.
    }
  }

  Future<void> clearReportCache() async {
    await _cache?.clearRuns(ScanKind.strategyBuilder);
    result = null;
    resultCachedOn = null;
    status = BuilderStatus.idle;
    notifyListeners();
  }

  static String _isoDay(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-'
      '${d.month.toString().padLeft(2, '0')}-'
      '${d.day.toString().padLeft(2, '0')}';

  List<String> warnings() {
    final r = result;
    final list = <String>[];
    if (r == null) return list;
    if (r.stats.trades < 30) {
      list.add(
        'Sirf ${r.stats.trades} trades — sample chhota hai. Isse koi conclusion '
        'mat nikaaliye (30+ trades se pehle numbers shor hote hain).',
      );
    }
    if (_strategy.settings.costPct == 0) {
      list.add(
        'Cost 0% par run hua — asli brokerage/STT/slippage include nahi hai.',
      );
    }
    if (r.skippedTrades > 0) {
      list.add(
        '${r.skippedTrades} signals aaye par slots (${_strategy.settings.maxPositions}) '
        'bhar gaye the — wo trades report me nahi hain.',
      );
    }
    if (r.skips.isNotEmpty) {
      list.add(
        '${r.skips.length} stocks skip hue (data kam / candles nahi mile) — list neeche hai.',
      );
    }
    final tf = _strategy.settings.timeframe;
    if (tf.isIntraday) {
      list.add(
        'Intraday ${tf.label} bars: broker sirf ~${tf.maxLookbackDays} din ka '
        'intraday data deta hai — window chhota hai, isliye ${_strategy.settings.timeframe.label} '
        'ke results daily se kam bharosemand hain. Cost ${_strategy.settings.costPct}% '
        'per trade intraday me zyada chubhta hai.',
      );
    }
    if (_strategy.fundamentals.isActive) {
      list.add(
        'Fundamentals filter (${_strategy.fundamentals.describe()}): ye **aaj ke** '
        'NSE/BSE filing numbers hain, poore backtest window par lagaye gaye — '
        '2023 wala asli fundamental nahi. ${fundamentalsBlocked.length} stock '
        'filter se baaahar, ${fundamentalsMissing.length} ka data nahi mila.',
      );
    }
    if (indexSource == IndexSourceKind.yahoo) {
      list.add('Yahoo fallback: ${indexNote ?? 'broker data nahi mila'}');
    }
    final test = oosTest;
    if (test != null && test.stats.trades >= 5) {
      list.add(
        'Out-of-sample (aakhri ${((1 - oosSplit) * 100).round()}% window): '
        '${test.stats.trades} trades, win ${test.stats.winRate.toStringAsFixed(1)}%, '
        'PF ${test.stats.profitFactor.toStringAsFixed(2)}. In-sample se bahut '
        'alag ho to strategy par bharosa mat karo.',
      );
    }
    if (status == BuilderStatus.cancelled) {
      list.add('Run beech me cancel hua — report adhoori hai.');
    }
    return list;
  }

  /// Report me benchmark ka naam — index par wahi index, stocks par equal-weight.
  String get benchmarkLabel =>
      isIndex ? '${_index()!.label} buy & hold' : 'Equal-weight B&H';

  /// Kaunsa data source (report ke header ke liye).
  String get sourceLabel {
    if (!isIndex) return 'Angel One daily candles';
    return switch (indexSource) {
      IndexSourceKind.yahoo => 'Yahoo Finance (fallback, unofficial)',
      _ => 'Angel One (broker) NSE index candles',
    };
  }

  /// Benchmark ka final number (universe ka equal-weight buy & hold).
  double? get benchmarkReturnPct =>
      (result == null || result!.benchmark.isEmpty)
      ? null
      : (result!.benchmark.last - 1) * 100;
}

/// `CandleSource` ka chhota adapter: index ke liye broker call.
class _IndexCandleSource implements CandleSource {
  _IndexCandleSource({required this.fetch});

  final Future<List<Candle>> Function(Scrip, DateTime, DateTime) fetch;

  @override
  Future<List<Candle>> fetchDailyCandles({
    required Scrip scrip,
    required DateTime from,
    required DateTime to,
    String interval = 'ONE_DAY',
  }) => fetch(scrip, from, to);
}
