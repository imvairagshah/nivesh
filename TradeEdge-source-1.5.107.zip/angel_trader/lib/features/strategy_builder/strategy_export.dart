// ---------------------------------------------------------------------------
// strategy_export.dart — report ka CSV (1.5.102).
//
// Pure function: `BacktestResult` + `Strategy` → CSV text. File/share ka kaam
// UI karta hai, isliye ye test me seedha check ho sakta hai (kitne rows, kaunse
// columns, cost ka label). Excel me seedha khulta hai — isliye pehli lines
// strategy ki settings hain, phir khaali line, phir trades.
// ---------------------------------------------------------------------------

import '../../core/utils/csv_io.dart';
import 'strategy_engine.dart';
import 'strategy_rules.dart';

/// Report ka poora CSV: header + settings + trades + skipped stocks.
String strategyCsvReport(BacktestResult result, Strategy strategy) {
  final s = strategy.settings;
  final stats = result.stats;
  final rows = <List<String>>[
    ['TRADE EDGE — Strategy Builder report'],
    ['Strategy', strategy.name],
    ['Universe', strategy.universeKey],
    ['Window', '${_d(result.windowStart)} to ${_d(result.windowEnd)}'],
    [
      'Entry',
      strategy.entry
          .map((r) => r.describe())
          .join(' ${strategy.entryJoin.name.toUpperCase()} '),
    ],
    [
      'Exit',
      strategy.exit.isEmpty
          ? 'sirf SL / target / time stop'
          : strategy.exit
                .map((r) => r.describe())
                .join(' ${strategy.exitJoin.name.toUpperCase()} '),
    ],
    ['Stop loss %', '${s.stopLossPct}'],
    ['Target %', '${s.targetPct}'],
    ['Time stop (bars)', '${s.timeStopBars}'],
    ['Cost % per trade', '${s.costPct}'],
    ['Max positions', '${s.maxPositions}'],
    [],
    ['Trades', '${stats.trades}'],
    ['Win rate %', stats.winRate.toStringAsFixed(2)],
    ['Avg trade %', stats.avgTrade.toStringAsFixed(3)],
    ['Profit factor', stats.profitFactor.toStringAsFixed(2)],
    ['Avg holding (din)', stats.avgBars.toStringAsFixed(1)],
    ['Max drawdown %', stats.maxDrawdownPct.toStringAsFixed(2)],
    ['Portfolio return %', stats.totalReturnPct.toStringAsFixed(2)],
    [],
    [
      'Symbol',
      'Entry date',
      'Exit date',
      'Entry ₹',
      'Exit ₹',
      'Net %',
      'Din',
      'Reason',
    ],
    for (final t in result.trades)
      [
        t.symbol,
        _d(t.entryDate),
        _d(t.exitDate),
        t.entryPrice.toStringAsFixed(2),
        t.exitPrice.toStringAsFixed(2),
        t.netPct.toStringAsFixed(2),
        '${t.bars}',
        t.reason,
      ],
    [],
    ['Skipped stocks', '${result.skips.length}'],
    ['Symbol', 'Wajah'],
    for (final skip in result.skips) [skip.symbol, skip.reason],
    [],
    [
      'Note',
      'Backtest past ka hisaab hai, future ki guarantee nahi. Cost '
          '${s.costPct}% per round trip ${s.costPct == 0 ? 'include NAHI hai' : 'include hai'}.',
    ],
  ];
  return CsvCodec.encode(rows);
}

String _d(DateTime d) =>
    '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
