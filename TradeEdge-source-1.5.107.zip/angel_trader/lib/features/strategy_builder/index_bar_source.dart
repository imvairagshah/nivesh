// ---------------------------------------------------------------------------
// index_bar_source.dart — index ke daily candles (1.5.103).
//
// Do raaste, aur dono **saaf label** ke saath:
//   1. **Broker (primary)** — Angel `getCandleData`, `exchange = NSE`,
//      `symboltoken = 999260xx` (AMXIDX). Yahi official hai; iske numbers
//      report me "Angel One (broker)" likh kar aate hain.
//   2. **Yahoo (sirf fallback)** — jab broker se data na aaye (login nahi,
//      token reject, broker ne index candle band kar di ho). Tab report ke
//      upar saaf warning aati hai: "Yahoo fallback — broker data nahi mila".
//      Chhupaya nahi jaata, aur scale kabhi banaya nahi jaata.
//
// NSE ki index files (ind_close_all / archives) 403 dete hain — wo raasta
// try bhi nahi karte (dead end, dobara mat kholna).
//
// Index `CandleSource` ke through hi jaata hai (`Scrip` bana kar), isliye
// `DailyBarsLoader` ka cache / delta / split-guard sab waisa hi chalta hai
// jaise stocks par.
// ---------------------------------------------------------------------------

import 'dart:convert';

import '../../core/utils/markets.dart';
import '../../data/remote/dto/candle.dart';
import '../../data/remote/dto/scrip.dart';
import 'index_catalog.dart';

/// Index candle kahan se aaya.
enum IndexSourceKind { broker, yahoo }

class IndexBars {
  const IndexBars({required this.bars, required this.kind, this.note});

  final List<Candle> bars;
  final IndexSourceKind kind;

  /// Jo bhi user ko batana zaroori ho (fail hone ki wajah etc).
  final String? note;

  static const IndexBars none = IndexBars(
    bars: [],
    kind: IndexSourceKind.broker,
  );
}

/// Yahoo chart API ka halka client — sirf daily bars, koi dependency nahi.
///
/// Query wahi hai jo already verify ho chuki hai:
/// `v8/finance/chart/%5ENSEI?range=3y&interval=1d` (200, 740+ bars).
class YahooIndexSource {
  YahooIndexSource({
    required Future<String?> Function(Uri uri) get,
    this.timeout = const Duration(seconds: 20),
  }) : _get = get;

  final Future<String?> Function(Uri uri) _get;
  final Duration timeout;

  /// Yahoo ka symbol: `^NSEI`, `^NSEBANK`, `NIFTY_FIN_SERVICE.NS` …
  static String yahooSymbolFor(BenchIndex index) => switch (index.symbol) {
    'NIFTY' => '^NSEI',
    'BANKNIFTY' => '^NSEBANK',
    'FINNIFTY' => 'NIFTY_FIN_SERVICE.NS',
    'MIDCPNIFTY' => 'NIFTY_MID_SELECT.NS',
    'NIFTY 500' => '^CRSLDX',
    'NIFTY 100' => '^CNX100',
    'NIFTY IT' => '^CNXIT',
    'NIFTY AUTO' => '^CNXAUTO',
    'NIFTY PHARMA' => '^CNXPHARMA',
    'NIFTY METAL' => '^CNXMETAL',
    _ => index.symbol,
  };

  /// Kitne saal ka data maangein (broker jitna hi — 5 saal).
  Future<IndexBars> fetch(BenchIndex index, {int years = 5}) async {
    final range = switch (years) {
      <= 1 => '1y',
      2 => '2y',
      3 => '3y',
      4 => '4y',
      _ => '5y',
    };
    final uri = Uri.parse(
      'https://query1.finance.yahoo.com/v8/finance/chart/'
      '${Uri.encodeComponent(yahooSymbolFor(index))}'
      '?range=$range&interval=1d&events=div%2Csplits',
    );
    try {
      final body = await _get(uri);
      if (body == null || body.isEmpty) {
        return const IndexBars(
          bars: [],
          kind: IndexSourceKind.yahoo,
          note: 'Yahoo ne khaali jawab diya',
        );
      }
      final bars = parseYahooChart(body);
      return IndexBars(
        bars: bars,
        kind: IndexSourceKind.yahoo,
        note: bars.isEmpty ? 'Yahoo me bars nahi mile' : null,
      );
    } catch (e) {
      return IndexBars(
        bars: const [],
        kind: IndexSourceKind.yahoo,
        note: 'Yahoo fail: $e',
      );
    }
  }

  /// Yahoo chart JSON → `Candle` list (adjustment ke saath).
  ///
  /// **Dividend/split**: Yahoo `adjclose` deta hai — total-return curve. Index
  /// par dividend adjust nahi hota (index price index hai), isliye yahan
  /// `close` hi sahi hai. Lekin agar `adjclose` available ho aur `close` se
  /// bahut alag ho (data gap), to wahi use karte hain — aur note likhte hain.
  static List<Candle> parseYahooChart(String body) {
    // Kharab/HTML jawab par crash nahi — khaali list (caller fail maan leta).
    final Object? decoded;
    try {
      decoded = jsonDecode(body);
    } catch (_) {
      return const [];
    }
    if (decoded is! Map) return const [];
    final chart = decoded['chart'];
    if (chart is! Map) return const [];
    final results = chart['result'];
    if (results is! List || results.isEmpty) return const [];
    final first = results.first;
    if (first is! Map) return const [];
    final timestamps = first['timestamp'];
    final quotes = first['indicators']?['quote'];
    if (timestamps is! List || quotes is! List || quotes.isEmpty) {
      return const [];
    }
    final quote = quotes.first;
    if (quote is! Map) return const [];

    final opens = (quote['open'] as List?) ?? const [];
    final highs = (quote['high'] as List?) ?? const [];
    final lows = (quote['low'] as List?) ?? const [];
    final closes = (quote['close'] as List?) ?? const [];
    final volumes = (quote['volume'] as List?) ?? const [];

    final out = <Candle>[];
    for (var i = 0; i < timestamps.length; i++) {
      final ts = timestamps[i];
      final close = i < closes.length ? closes[i] : null;
      if (ts is! num || close is! num) continue;
      final open = (i < opens.length ? opens[i] : null) as num? ?? close;
      final high = (i < highs.length ? highs[i] : null) as num? ?? close;
      final low = (i < lows.length ? lows[i] : null) as num? ?? close;
      final volume = (i < volumes.length ? volumes[i] : null) as num? ?? 0;
      // Yahoo 09:15 IST ko bar stamp karta hai (UTC me 03:45).
      final time = DateTime.fromMillisecondsSinceEpoch(
        (ts * 1000).round(),
        isUtc: true,
      ).add(const Duration(minutes: 330));
      out.add(
        Candle(
          time: time,
          open: open.toDouble(),
          high: high.toDouble(),
          low: low.toDouble(),
          close: close.toDouble(),
          volume: volume.round(),
        ),
      );
    }
    out.sort((a, b) => a.time.compareTo(b.time));
    return out;
  }
}

/// Index ko normal `Scrip` bana do — loader/DAO/engine sab isi ko samajhte hain.
Scrip indexScrip(BenchIndex index) => Scrip(
  token: index.token,
  symbol: index.cacheSymbol,
  name: index.name,
  exchange: Exchange.nse,
);
