// ---------------------------------------------------------------------------
// strategy_delivery.dart — report ko bahar bhejne ke raaste (1.5.104).
//
//   1. **CSV**   — flat table (Excel me seedha khulti hai)
//   2. **Excel** — 3 sheet workbook: Report (stats), Trades, Skipped
//   3. **Text**  — WhatsApp/Telegram par paste karne layak Hinglish recap
//   4. **Telegram bot** — XLSX **document** upload (Settings me bot token +
//      chat id; wahi bot jo 3-Month Study use karti hai — ek hi jagah set karo)
//   5. **Strategy file** — `.tradeedge` (JSON) — WhatsApp/Telegram se bhejo,
//      doosre phone par "Import" se wahi strategy khul jaati hai.
//
// Har raaste ka jawab `StrategyDeliveryOutcome` me aata hai (ok + Hinglish
// message) — screen snackbar me wahi dikhati hai, kabhi fail hone par chup
// nahi rehti.
// ---------------------------------------------------------------------------

import 'dart:convert';
import 'dart:io';

import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';

import '../../core/utils/share_helper.dart';
import '../../data/local/models/app_settings.dart';
import 'strategy_engine.dart';
import 'strategy_rules.dart';

class StrategyDeliveryOutcome {
  const StrategyDeliveryOutcome({required this.ok, required this.message});

  final bool ok;
  final String message;
}

class StrategyDeliveryService {
  StrategyDeliveryService({HttpClient? http}) : _http = http ?? HttpClient();

  final HttpClient _http;

  // -------------------------------------------------------------------------
  // Text recap
  // -------------------------------------------------------------------------

  /// WhatsApp / Telegram message ke liye chhota recap.
  ///
  /// Rule: numbers **wahi** jo report me hain, aur teen warnings (cost, sample,
  /// data source) hamesha saath — aage forward hone wali cheez me bhi sach
  /// chale.
  static String recap(
    BacktestResult r,
    Strategy strategy, {
    String sourceLabel = 'Angel One daily candles',
    String benchmarkLabel = 'Equal-weight B&H',
    List<String> warnings = const [],
  }) {
    final s = r.stats;
    final sett = strategy.settings;
    String signed(double v, [int d = 2]) =>
        '${v >= 0 ? '+' : ''}${v.toStringAsFixed(d)}';
    final lines = <String>[
      'TRADE EDGE · Strategy backtest',
      strategy.name,
      '${strategy.universeKey} · ${r.windowStart.year}–${r.windowEnd.year} · '
          '${r.trades.length} trades',
      '',
      'Win rate: ${s.winRate.toStringAsFixed(1)}%',
      'Avg trade: ${signed(s.avgTrade)}%  (W ${signed(s.avgWin)} / L ${signed(s.avgLoss)})',
      'Profit factor: ${s.profitFactor.toStringAsFixed(2)} · '
          'expectancy ${signed(s.expectancyPct)}%',
      'Max drawdown: -${s.maxDrawdownPct.toStringAsFixed(1)}% · '
          'avg holding ${s.avgBars.toStringAsFixed(1)} din',
      'Portfolio: ${signed(s.totalReturnPct, 1)}%  vs  $benchmarkLabel '
          '${signed((r.benchmark.isEmpty ? 1 : r.benchmark.last) * 100 - 100, 1)}%',
      '',
      'Rules: ${strategy.entry.map((e) => e.describe()).join(' ${strategy.entryJoin.name.toUpperCase()} ')}',
      if (strategy.exit.isNotEmpty)
        'Exit: ${strategy.exit.map((e) => e.describe()).join(' ${strategy.exitJoin.name.toUpperCase()} ')}',
      'SL ${sett.stopLossPct == 0 ? '—' : '${sett.stopLossPct}%'} · '
          'Target ${sett.targetPct == 0 ? '—' : '${sett.targetPct}%'} · '
          'Time stop ${sett.timeStopBars == 0 ? '—' : '${sett.timeStopBars}d'} · '
          'Cost ${sett.costPct}%',
      '',
      'Data: $sourceLabel',
      if (warnings.isNotEmpty) ...['', '⚠️ ${warnings.first}'],
      if (warnings.length > 1) '⚠️ ${warnings[1]}',
      '',
      'Backtest past ka hisaab hai — guarantee nahi. Paper only.',
    ];
    return lines.join('\n');
  }

  // -------------------------------------------------------------------------
  // Excel
  // -------------------------------------------------------------------------

  /// 3-sheet workbook: Report / Trades / Skipped.
  static Future<File> writeXlsx(
    BacktestResult r,
    Strategy strategy, {
    String sourceLabel = 'Angel One daily candles',
    String benchmarkLabel = 'Equal-weight B&H',
    List<String> warnings = const [],

    /// Tests ke liye — production me null (path_provider temp dir).
    Directory? directory,
  }) async {
    final excel = Excel.createExcel();
    // Default sheet ka naam badal do — khaali "Sheet1" na chhodo.
    final report = excel['Report'];
    excel.setDefaultSheet('Report');

    // excel 4.x: `appendRow` void hai — style alag se last row par lagti hai.
    void row(List<CellValue?> cells, {bool bold = false}) {
      report.appendRow(cells);
      if (!bold) return;
      final index = report.maxRows - 1;
      final style = CellStyle(bold: true);
      for (var c = 0; c < cells.length; c++) {
        report
                .cell(
                  CellIndex.indexByColumnRow(columnIndex: c, rowIndex: index),
                )
                .cellStyle =
            style;
      }
    }

    final s = r.stats;
    final sett = strategy.settings;
    row([TextCellValue('TRADE EDGE — Strategy Builder')], bold: true);
    row([TextCellValue('Strategy'), TextCellValue(strategy.name)]);
    row([TextCellValue('Universe'), TextCellValue(strategy.universeKey)]);
    row([
      TextCellValue('Window'),
      TextCellValue('${_d(r.windowStart)} to ${_d(r.windowEnd)}'),
    ]);
    row([
      TextCellValue('Entry'),
      TextCellValue(
        strategy.entry
            .map((e) => e.describe())
            .join(' ${strategy.entryJoin.name.toUpperCase()} '),
      ),
    ]);
    row([
      TextCellValue('Exit'),
      TextCellValue(
        strategy.exit.isEmpty
            ? 'SL / target / time stop only'
            : strategy.exit
                  .map((e) => e.describe())
                  .join(' ${strategy.exitJoin.name.toUpperCase()} '),
      ),
    ]);
    row([
      TextCellValue('SL %'),
      DoubleCellValue(sett.stopLossPct),
      TextCellValue('Target %'),
      DoubleCellValue(sett.targetPct),
      TextCellValue('Time stop'),
      IntCellValue(sett.timeStopBars),
    ]);
    row([
      TextCellValue('Cost %'),
      DoubleCellValue(sett.costPct),
      TextCellValue('Max positions'),
      IntCellValue(sett.maxPositions),
    ]);
    row([TextCellValue('Data source'), TextCellValue(sourceLabel)]);
    row([]);
    row([TextCellValue('Metric'), TextCellValue('Value')], bold: true);
    final metrics = <(String, double)>[
      ('Trades', s.trades.toDouble()),
      ('Win rate %', s.winRate),
      ('Avg trade %', s.avgTrade),
      ('Median trade %', s.medianTrade),
      ('Avg win %', s.avgWin),
      ('Avg loss %', s.avgLoss),
      ('Profit factor', s.profitFactor),
      ('Expectancy %', s.expectancyPct),
      ('Avg holding (din)', s.avgBars),
      ('Max drawdown %', s.maxDrawdownPct),
      ('Portfolio return %', s.totalReturnPct),
      (
        'Benchmark return % ($benchmarkLabel)',
        (r.benchmark.isEmpty ? 1 : r.benchmark.last) * 100 - 100,
      ),
    ];
    for (final m in metrics) {
      row([TextCellValue(m.$1), DoubleCellValue(_round(m.$2))]);
    }
    if (s.niftyReturnPct != null) {
      row([
        TextCellValue('Nifty B&H %'),
        DoubleCellValue(_round(s.niftyReturnPct!)),
      ]);
    }
    if (s.niftyMaxDrawdownPct != null) {
      row([
        TextCellValue('Nifty max drawdown %'),
        DoubleCellValue(_round(s.niftyMaxDrawdownPct!)),
      ]);
    }
    row([]);
    row([TextCellValue('Warnings')], bold: true);
    for (final w in warnings) {
      row([TextCellValue(w)]);
    }
    if (warnings.isEmpty) row([TextCellValue('koi warning nahi')]);
    row([]);
    row([
      TextCellValue(
        'Backtest past ka hisaab hai — future ki guarantee nahi. Cost '
        '${sett.costPct}% per round trip ${sett.costPct == 0 ? 'include NAHI hai' : 'include hai'}.',
      ),
    ]);

    final trades = excel['Trades'];
    trades.appendRow([
      TextCellValue('Symbol'),
      TextCellValue('Entry date'),
      TextCellValue('Exit date'),
      TextCellValue('Entry ₹'),
      TextCellValue('Exit ₹'),
      TextCellValue('Net %'),
      TextCellValue('Din'),
      TextCellValue('Reason'),
    ]);
    for (final t in r.trades) {
      trades.appendRow([
        TextCellValue(t.symbol),
        TextCellValue(_d(t.entryDate)),
        TextCellValue(_d(t.exitDate)),
        DoubleCellValue(_round(t.entryPrice)),
        DoubleCellValue(_round(t.exitPrice)),
        DoubleCellValue(_round(t.netPct)),
        IntCellValue(t.bars),
        TextCellValue(t.reason),
      ]);
    }

    final skipped = excel['Skipped'];
    skipped.appendRow([TextCellValue('Symbol'), TextCellValue('Wajah')]);
    for (final skip in r.skips) {
      skipped.appendRow([
        TextCellValue(skip.symbol),
        TextCellValue(skip.reason),
      ]);
    }

    final dir = directory ?? await getTemporaryDirectory();
    final file = File('${dir.path}/${_slug(strategy.name)}_report.xlsx');
    final bytes = excel.save();
    if (bytes == null) throw StateError('Excel banane me fail');
    await file.writeAsBytes(bytes, flush: true);
    return file;
  }

  // -------------------------------------------------------------------------
  // Deliveries
  // -------------------------------------------------------------------------

  Future<StrategyDeliveryOutcome> shareText(String text) async {
    final r = await ShareHelper.shareText(text, subject: 'TRADE EDGE backtest');
    return StrategyDeliveryOutcome(ok: r.ok, message: r.message);
  }

  Future<StrategyDeliveryOutcome> shareFile(File file, String subject) async {
    final r = await ShareHelper.shareFile(file, subject);
    return StrategyDeliveryOutcome(ok: r.ok, message: r.message);
  }

  /// Telegram par XLSX bhejo — wahi bot jo 3-Month Study ka hai.
  Future<StrategyDeliveryOutcome> sendTelegram({
    required File file,
    required String caption,
    required AppSettings settings,
  }) async {
    final token = settings.telegramBotToken.trim();
    final chatId = settings.telegramChatId.trim();
    if (token.isEmpty || chatId.isEmpty) {
      return const StrategyDeliveryOutcome(
        ok: false,
        message:
            'Telegram ke liye Settings me bot token + chat id daalo '
            '(@BotFather se bot banao, phir bot ko /start bhejo).',
      );
    }
    try {
      await _postDocument(
        token: token,
        chatId: chatId,
        file: file,
        caption: caption,
      );
      return const StrategyDeliveryOutcome(
        ok: true,
        message: 'Telegram pe XLSX bhej di.',
      );
    } catch (e) {
      return StrategyDeliveryOutcome(ok: false, message: 'Telegram fail: $e');
    }
  }

  // -------------------------------------------------------------------------
  // Strategy file (.tradeedge) — share / import
  // -------------------------------------------------------------------------

  /// Strategy ko file me likho; mobile par share sheet, desktop par Downloads.
  Future<StrategyDeliveryOutcome> shareStrategyFile(
    Strategy strategy, {
    Directory? directory,
  }) async {
    try {
      final dir = directory ?? await getTemporaryDirectory();
      final file = File('${dir.path}/${_slug(strategy.name)}.tradeedge');
      // Header line — file ko insaan bhi padh sake, parser ignore karta hai.
      await file.writeAsString(
        '# TRADE EDGE strategy file — app ke Builder → Import me kholo\n'
        '${strategy.encode()}',
        flush: true,
      );
      final r = await ShareHelper.shareFile(file, 'TRADE EDGE strategy');
      return StrategyDeliveryOutcome(ok: r.ok, message: r.message);
    } catch (e) {
      return StrategyDeliveryOutcome(ok: false, message: 'File fail: $e');
    }
  }

  /// File/string se strategy — comment lines aur extra whitespace tolerate
  /// karta hai. Galat file par null (crash nahi).
  static Strategy? parseStrategyFile(String raw) {
    for (final line in const LineSplitter().convert(raw)) {
      final text = line.trim();
      if (text.isEmpty || text.startsWith('#')) continue;
      try {
        return Strategy.decode(text);
      } catch (_) {
        continue;
      }
    }
    return null;
  }

  /// Multipart upload — wahi shape jo 3-Month Study use karti hai
  /// (`sendDocument`, XLSX as document, caption 1000 chars tak).
  Future<void> _postDocument({
    required String token,
    required String chatId,
    required File file,
    required String caption,
  }) async {
    final boundary = '----TRADE EDGE${DateTime.now().microsecondsSinceEpoch}';
    final request = await _http.postUrl(
      Uri.parse('https://api.telegram.org/bot$token/sendDocument'),
    );
    request.headers.set(
      HttpHeaders.contentTypeHeader,
      'multipart/form-data; boundary=$boundary',
    );

    void field(String name, String value) {
      request.add(
        utf8.encode(
          '--$boundary\r\n'
          'Content-Disposition: form-data; name="$name"\r\n\r\n'
          '$value\r\n',
        ),
      );
    }

    field('chat_id', chatId);
    field(
      'caption',
      caption.length > 1000 ? caption.substring(0, 1000) : caption,
    );
    request.add(
      utf8.encode(
        '--$boundary\r\n'
        'Content-Disposition: form-data; name="document"; '
        'filename="${file.uri.pathSegments.last}"\r\n'
        'Content-Type: application/vnd.openxmlformats-officedocument.'
        'spreadsheetml.sheet\r\n\r\n',
      ),
    );
    request.add(await file.readAsBytes());
    request.add(utf8.encode('\r\n--$boundary--\r\n'));

    final response = await request.close();
    final body = await response.transform(utf8.decoder).join();
    final decoded = jsonDecode(body);
    final ok = decoded is Map && decoded['ok'] == true;
    if (response.statusCode != 200 || !ok) {
      throw HttpException('Telegram ne mana kar diya: $body');
    }
  }

  static String _d(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  static String _slug(String name) {
    final slug = name
        .toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9]+'), '_')
        .replaceAll(RegExp(r'^_|_$'), '');
    return slug.isEmpty ? 'strategy' : slug;
  }

  static double _round(double v) =>
      (v * 10000).roundToDouble() / 10000; // chhota noise hataao
}
