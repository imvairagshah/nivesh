// ---------------------------------------------------------------------------
// strategy_fundamentals.dart — fundamentals filter (1.5.104).
//
// **Sirf wahi numbers jo app ke paas asli me hain.** Magic Formula ka data
// source NSE/BSE filings + bhavcopy se market cap, EBIT (TTM), debt, cash,
// total assets aur current liabilities deta hai. Usse ye teen ratio **banaye
// ja sakte hain** (kuch bhi guess kiye bina):
//
//   • ROCE %        = EBIT ÷ (Total Assets − Current Liabilities)
//   • Debt/Equity   = Total Debt ÷ (Total Assets − Current Liabilities − Debt)
//   • Earnings yield = EBIT ÷ (Market Cap + Debt − Cash)      [Magic Formula]
//   • Market cap (₹ cr)
//
// P/E yahan **nahi** hai: uske liye PAT (net profit) chahiye, jo is data me
// nahi aata. Fake P/E banane se behtar hai na dikhana — isliye filter me P/E
// ka option hi nahi hai.
//
// ⚠️ Honesty: ye **aaj ke** fundamentals hain, poore backtest window par
// lagaye jaate hain. Iska matlab hai ki filter ek "aaj ka stock selection"
// hai, 2023 ka asli fundamental nahi — isliye report par ye baat likhi jaati
// hai aur backtest ko isse "future-proof" nahi maana jaata.
// ---------------------------------------------------------------------------

/// Ek stock ka fundamentals snapshot (₹ crore me, jaisa filing me hai).
class FundamentalSnapshot {
  const FundamentalSnapshot({
    required this.symbol,
    this.marketCapCr,
    this.rocePct,
    this.debtEquity,
    this.earningsYieldPct,
    this.asOf,
    this.source = 'NSE/BSE filings',
    this.missingReason = '',
  });

  final String symbol;
  final double? marketCapCr;
  final double? rocePct;
  final double? debtEquity;
  final double? earningsYieldPct;
  final DateTime? asOf;
  final String source;

  /// Kyu khaali hai (filing nahi mili / parse fail / HTTP error).
  final String missingReason;

  bool get hasAny =>
      marketCapCr != null ||
      rocePct != null ||
      debtEquity != null ||
      earningsYieldPct != null;

  Map<String, dynamic> toJson() => {
    'symbol': symbol,
    if (marketCapCr != null) 'mcap': marketCapCr,
    if (rocePct != null) 'roce': rocePct,
    if (debtEquity != null) 'de': debtEquity,
    if (earningsYieldPct != null) 'ey': earningsYieldPct,
    if (asOf != null) 'asOf': asOf!.toIso8601String(),
    'source': source,
    if (missingReason.isNotEmpty) 'missing': missingReason,
  };

  static FundamentalSnapshot fromJson(Map<String, dynamic> json) {
    double? num_(String key) {
      final v = json[key];
      return v is num ? v.toDouble() : null;
    }

    return FundamentalSnapshot(
      symbol: '${json['symbol']}',
      marketCapCr: num_('mcap'),
      rocePct: num_('roce'),
      debtEquity: num_('de'),
      earningsYieldPct: num_('ey'),
      asOf: DateTime.tryParse('${json['asOf'] ?? ''}'),
      source: '${json['source'] ?? 'NSE/BSE filings'}',
      missingReason: '${json['missing'] ?? ''}',
    );
  }

  /// NSE/BSE filing ke numbers se snapshot — jo bhi missing ho, null rehta hai.
  ///
  /// Formulas Magic Formula se bilkul same hain (formula change nahi kiya).
  static FundamentalSnapshot fromFiling({
    required String symbol,
    double? marketCapCr,
    double? ebitTtmCr,
    double? totalDebtCr,
    double? cashCr,
    double? totalAssetsCr,
    double? currentLiabilitiesCr,
    DateTime? asOf,
    String source = 'NSE/BSE filings',
    String missingReason = '',
  }) {
    double? roce;
    double? debtEquity;
    double? earningsYield;

    final capitalEmployed =
        (totalAssetsCr != null && currentLiabilitiesCr != null)
        ? totalAssetsCr - currentLiabilitiesCr
        : null;
    if (capitalEmployed != null && capitalEmployed > 0 && ebitTtmCr != null) {
      roce = ebitTtmCr / capitalEmployed * 100;
    }
    if (capitalEmployed != null &&
        totalDebtCr != null &&
        capitalEmployed - totalDebtCr > 0) {
      debtEquity = totalDebtCr / (capitalEmployed - totalDebtCr);
    }
    if (marketCapCr != null &&
        totalDebtCr != null &&
        cashCr != null &&
        ebitTtmCr != null) {
      final ev = marketCapCr + totalDebtCr - cashCr;
      if (ev > 0) earningsYield = ebitTtmCr / ev * 100;
    }

    return FundamentalSnapshot(
      symbol: symbol,
      marketCapCr: marketCapCr,
      rocePct: roce,
      debtEquity: debtEquity,
      earningsYieldPct: earningsYield,
      asOf: asOf,
      source: source,
      missingReason: missingReason,
    );
  }
}

/// User ka fundamentals filter. Har field `null` = us par filter nahi.
class FundamentalFilter {
  const FundamentalFilter({
    this.minMarketCapCr,
    this.minRocePct,
    this.maxDebtEquity,
    this.minEarningsYieldPct,
    this.requireData = false,
  });

  final double? minMarketCapCr;
  final double? minRocePct;
  final double? maxDebtEquity;
  final double? minEarningsYieldPct;

  /// Data na mile to stock hataao (default: nahi hataao — coverage chhoti ho
  /// to poora universe ud na jaaye).
  final bool requireData;

  bool get isActive =>
      minMarketCapCr != null ||
      minRocePct != null ||
      maxDebtEquity != null ||
      minEarningsYieldPct != null ||
      requireData;

  /// Human line — report me dikhti hai ("MCap ≥ 5000 cr · ROCE ≥ 15%").
  String describe() {
    final parts = <String>[
      if (minMarketCapCr != null) 'MCap ≥ ${_n(minMarketCapCr!)} cr',
      if (minRocePct != null) 'ROCE ≥ ${_n(minRocePct!)}%',
      if (maxDebtEquity != null)
        'D/E ≤ ${minRocePct == null ? '' : ''}${_n(maxDebtEquity!)}',
      if (minEarningsYieldPct != null)
        'Earnings yield ≥ ${_n(minEarningsYieldPct!)}%',
      if (requireData) 'sirf jinke fundamentals mile',
    ];
    return parts.isEmpty ? 'koi filter nahi' : parts.join(' · ');
  }

  static String _n(double v) =>
      v == v.roundToDouble() ? '${v.toInt()}' : v.toStringAsFixed(2);

  /// Pass/fail. Data na ho to `requireData` decide karta hai.
  ({bool pass, String reason}) test(FundamentalSnapshot? snap) {
    if (!isActive) return (pass: true, reason: '');
    if (snap == null || !snap.hasAny) {
      if (requireData) {
        return (
          pass: false,
          reason:
              'fundamentals nahi mile'
              '${snap != null && snap.missingReason.isNotEmpty ? ' (${snap.missingReason})' : ''}',
        );
      }
      return (pass: true, reason: '');
    }
    final mcap = minMarketCapCr;
    if (mcap != null) {
      if (snap.marketCapCr == null) return _missing('market cap');
      if (snap.marketCapCr! < mcap) {
        return (
          pass: false,
          reason: 'MCap ${_n(snap.marketCapCr!)} cr < ${_n(mcap)}',
        );
      }
    }
    final roce = minRocePct;
    if (roce != null) {
      if (snap.rocePct == null) return _missing('ROCE');
      if (snap.rocePct! < roce) {
        return (
          pass: false,
          reason: 'ROCE ${_n(snap.rocePct!)}% < ${_n(roce)}%',
        );
      }
    }
    final de = maxDebtEquity;
    if (de != null) {
      if (snap.debtEquity == null) return _missing('D/E');
      if (snap.debtEquity! > de) {
        return (pass: false, reason: 'D/E ${_n(snap.debtEquity!)} > ${_n(de)}');
      }
    }
    final ey = minEarningsYieldPct;
    if (ey != null) {
      if (snap.earningsYieldPct == null) return _missing('earnings yield');
      if (snap.earningsYieldPct! < ey) {
        return (
          pass: false,
          reason: 'Earnings yield ${_n(snap.earningsYieldPct!)}% < ${_n(ey)}%',
        );
      }
    }
    return (pass: true, reason: '');
  }

  ({bool pass, String reason}) _missing(String what) => requireData
      ? (pass: false, reason: '$what nahi mila')
      : (pass: true, reason: '');

  FundamentalFilter copyWith({
    double? minMarketCapCr,
    double? minRocePct,
    double? maxDebtEquity,
    double? minEarningsYieldPct,
    bool? requireData,
    bool clearMinMarketCap = false,
    bool clearMinRoce = false,
    bool clearMaxDebtEquity = false,
    bool clearMinEarningsYield = false,
  }) => FundamentalFilter(
    minMarketCapCr: clearMinMarketCap
        ? null
        : (minMarketCapCr ?? this.minMarketCapCr),
    minRocePct: clearMinRoce ? null : (minRocePct ?? this.minRocePct),
    maxDebtEquity: clearMaxDebtEquity
        ? null
        : (maxDebtEquity ?? this.maxDebtEquity),
    minEarningsYieldPct: clearMinEarningsYield
        ? null
        : (minEarningsYieldPct ?? this.minEarningsYieldPct),
    requireData: requireData ?? this.requireData,
  );

  Map<String, dynamic> toJson() => {
    if (minMarketCapCr != null) 'minMcap': minMarketCapCr,
    if (minRocePct != null) 'minRoce': minRocePct,
    if (maxDebtEquity != null) 'maxDe': maxDebtEquity,
    if (minEarningsYieldPct != null) 'minEy': minEarningsYieldPct,
    if (requireData) 'requireData': true,
  };

  static FundamentalFilter fromJson(Map<String, dynamic>? json) {
    if (json == null) return const FundamentalFilter();
    double? num_(String key) {
      final v = json[key];
      return v is num ? v.toDouble() : null;
    }

    return FundamentalFilter(
      minMarketCapCr: num_('minMcap'),
      minRocePct: num_('minRoce'),
      maxDebtEquity: num_('maxDe'),
      minEarningsYieldPct: num_('minEy'),
      requireData: json['requireData'] == true,
    );
  }
}

/// Filter ka poora result — kitne pass, kitne fail (report ke liye).
class FundamentalOutcome {
  const FundamentalOutcome({
    required this.allowed,
    required this.blocked,
    required this.missing,
    required this.describe,
  });

  /// Symbol → snapshot (jo mile).
  final Map<String, FundamentalSnapshot> allowed;
  final Map<String, String> blocked;
  final Set<String> missing;
  final String describe;

  int get coverage => allowed.length + blocked.length;
}
