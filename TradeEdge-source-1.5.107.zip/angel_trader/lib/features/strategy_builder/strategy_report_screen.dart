// ---------------------------------------------------------------------------
// strategy_report_screen.dart — backtest ka poora report (1.5.102).
//
// Sab numbers `BacktestResult` se aate hain (engine me already test hue).
// Report ka maksad: **jhooth na bole** — isliye:
//   • headline me trades + win rate + PF + drawdown,
//   • equity curve **benchmark** (universe ka equal-weight buy & hold) ke saath,
//   • warnings (kam trades, cost 0, slots skip, cancel) sabse upar,
//   • har trade ki table + skip list (data kam wale stocks),
//   • aur "cost include hai / nahi" line hamesha.
// ---------------------------------------------------------------------------

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_theme.dart';
import '../../core/widgets/edge_header.dart';
import '../../core/widgets/page_scroll.dart';
import 'strategy_builder_provider.dart';
import 'strategy_engine.dart';
import 'strategy_delivery.dart';
import 'strategy_export.dart';
import '../settings/settings_provider.dart';

class StrategyReportScreen extends StatelessWidget {
  const StrategyReportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.watch<StrategyBuilderProvider>();
    final r = p.result;
    final scheme = Theme.of(context).colorScheme;

    if (r == null) {
      return Scaffold(
        appBar: const EdgeAppBar(
          title: 'Report',
          subtitle: 'Abhi koi backtest nahi chala',
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.assessment_outlined,
                  size: 40,
                  color: scheme.onSurfaceVariant,
                ),
                const SizedBox(height: 12),
                Text(
                  'Abhi koi backtest nahi chala',
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                    color: scheme.onSurface,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Builder screen par "Run backtest" dabaiye. Yahan phir ye '
                  'sab aayega:',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 11.5,
                    height: 1.5,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
                const SizedBox(height: 10),
                for (final line in const [
                  'Headline stats — trades, win rate, PF, drawdown',
                  'Equity curve + buy & hold benchmark',
                  'Monthly heatmap, out-of-sample check, har trade',
                  'Excel / CSV / Telegram export',
                ])
                  Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Text(
                      '• $line',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 11,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      );
    }

    final stats = r.stats;
    final warnings = p.warnings();

    return Scaffold(
      appBar: EdgeAppBar(
        title: 'Backtest report',
        subtitle:
            '${p.strategy.name} · '
            '${r.windowStart.year}–${r.windowEnd.year}',
        actions: [
          Builder(
            builder: (context) => PopupMenuButton<String>(
              tooltip: 'Export / bhejo',
              icon: const Icon(Icons.ios_share_rounded),
              onSelected: (value) => _export(context, p, r, value),
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'xlsx', child: Text('Excel (.xlsx)')),
                PopupMenuItem(value: 'csv', child: Text('CSV')),
                PopupMenuItem(
                  value: 'text',
                  child: Text('Text recap (WhatsApp)'),
                ),
                PopupMenuItem(
                  value: 'telegram',
                  child: Text('Telegram pe bhejo'),
                ),
              ],
            ),
          ),
        ],
      ),
      body: PageScroll.children([
        // 1.5.107 — report cache se aaya ho to saaf likho (kal ka report aaj
        // ka nahi kahlata).
        if (p.resultCachedOn != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Text(
              'Ye pichhla saved report hai '
              '(${p.resultCachedOn!.day.toString().padLeft(2, '0')}/'
              '${p.resultCachedOn!.month.toString().padLeft(2, '0')}/'
              '${p.resultCachedOn!.year}) — naye numbers ke liye Builder me '
              'dobara Run dabaiye.',
              style: TextStyle(
                fontSize: 10.5,
                height: 1.5,
                color: scheme.onSurfaceVariant,
              ),
            ),
          ),
        // ---- headline -------------------------------------------------
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            _Stat(label: 'Trades', value: '${stats.trades}'),
            _Stat(
              label: 'Win rate',
              value: '${stats.winRate.toStringAsFixed(1)}%',
              good: stats.winRate >= 50,
            ),
            _Stat(
              label: 'Avg trade',
              value: '${_signed(stats.avgTrade)}%',
              good: stats.avgTrade > 0,
            ),
            _Stat(
              label: 'Profit factor',
              value: stats.profitFactor.toStringAsFixed(2),
              good: stats.profitFactor >= 1,
            ),
            _Stat(
              label: 'Avg holding',
              value: '${stats.avgBars.toStringAsFixed(1)} din',
            ),
            _Stat(
              label: 'Max drawdown',
              value: '-${stats.maxDrawdownPct.toStringAsFixed(1)}%',
              bad: stats.maxDrawdownPct > 20,
            ),
            _Stat(
              label: 'Portfolio return',
              value: '${_signed(stats.totalReturnPct)}%',
              good: stats.totalReturnPct > 0,
            ),
            _Stat(
              label: 'Nifty B&H',
              value: stats.niftyReturnPct == null
                  ? '—'
                  : '${_signed(stats.niftyReturnPct!)}%',
            ),
            _Stat(
              label: 'B&H',
              value: p.benchmarkReturnPct == null
                  ? '—'
                  : '${_signed(p.benchmarkReturnPct!)}%',
            ),
          ],
        ),
        const SizedBox(height: 12),

        // ---- honesty block --------------------------------------------
        if (warnings.isNotEmpty)
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: scheme.errorContainer.withValues(alpha: 0.35),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: scheme.outlineVariant),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (final w in warnings)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(
                          Icons.info_outline_rounded,
                          size: 14,
                          color: scheme.error,
                        ),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            w,
                            style: TextStyle(
                              fontSize: 10.5,
                              height: 1.45,
                              color: scheme.onSurface,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        const SizedBox(height: 14),

        // ---- equity curve ---------------------------------------------
        _SectionHeader(
          'Equity curve',
          'Shuru ₹1 · ${p.strategy.settings.maxPositions} slots · '
              'cost ${p.strategy.settings.costPct}% per trade',
        ),
        const SizedBox(height: 8),
        Container(
          height: 210,
          padding: const EdgeInsets.fromLTRB(6, 10, 10, 6),
          decoration: BoxDecoration(
            color: scheme.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: scheme.outlineVariant),
          ),
          child: CustomPaint(
            painter: _EquityPainter(
              equity: r.equity,
              benchmark: r.benchmark,
              line: Brand.green,
              bench: scheme.onSurfaceVariant,
              grid: scheme.outlineVariant,
            ),
            size: Size.infinite,
          ),
        ),
        const SizedBox(height: 6),
        Row(
          children: [
            const _LegendDot(color: Brand.green, label: 'Strategy'),
            const SizedBox(width: 12),
            _LegendDot(color: scheme.onSurfaceVariant, label: p.benchmarkLabel),
          ],
        ),
        const SizedBox(height: 14),

        // ---- monthly heatmap -------------------------------------------
        if (r.monthly.isNotEmpty) ...[
          const _SectionHeader(
            'Monthly returns heatmap',
            'saal × mahina · portfolio ke hisaab se (cell = us mahine ka %)',
          ),
          const SizedBox(height: 8),
          _MonthlyHeatmap(monthly: r.monthly),
          const SizedBox(height: 14),
        ],

        // ---- drawdown strip --------------------------------------------
        if (r.equity.length > 2) ...[
          _SectionHeader(
            'Drawdown',
            'peak se neeche kitna gaya · strategy max -'
                '${stats.maxDrawdownPct.toStringAsFixed(1)}%'
                '${stats.niftyMaxDrawdownPct == null ? '' : ' · Nifty max -${stats.niftyMaxDrawdownPct!.toStringAsFixed(1)}%'}',
          ),
          const SizedBox(height: 8),
          Container(
            height: 92,
            padding: const EdgeInsets.fromLTRB(6, 6, 10, 6),
            decoration: BoxDecoration(
              color: scheme.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: scheme.outlineVariant),
            ),
            child: CustomPaint(
              painter: _DrawdownPainter(
                equity: r.equity,
                fill: scheme.error.withValues(alpha: 0.28),
                line: scheme.error,
                grid: scheme.outlineVariant,
              ),
              size: Size.infinite,
            ),
          ),
          const SizedBox(height: 14),
        ],

        // ---- out of sample (70/30) -------------------------------------
        if (p.oosTrain != null && p.oosTest != null) ...[
          const _SectionHeader(
            'Out-of-sample check (70 / 30)',
            'window ko do hisson me baant kar wahi rules dobara — stability '
                'ka test, walk-forward nahi',
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: scheme.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: scheme.outlineVariant),
            ),
            child: Column(
              children: [
                _OosRow(
                  label: 'In-sample (pehle 70%)',
                  r: p.oosTrain!,
                  color: scheme.onSurface,
                ),
                const SizedBox(height: 8),
                _OosRow(
                  label: 'Out-of-sample (aakhri 30%)',
                  r: p.oosTest!,
                  color: scheme.onSurface,
                ),
                const SizedBox(height: 8),
                Text(
                  'Dono ka PF/win-rate bahut alag ho to strategy ek hi period '
                  'ka luck ho sakti hai — us par bharosa mat karo.',
                  style: TextStyle(
                    fontSize: 10,
                    height: 1.45,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
        ],

        // ---- trades ---------------------------------------------------
        _SectionHeader('Trades', '${r.trades.length} · entry/exit ke saath'),
        const SizedBox(height: 8),
        for (final t in r.trades.take(300)) _TradeRow(trade: t),
        if (r.trades.length > 300)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              'Pehle 300 trades dikhaye hain (total ${r.trades.length}).',
              style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant),
            ),
          ),
        const SizedBox(height: 14),

        // ---- skips ----------------------------------------------------
        if (r.skips.isNotEmpty) ...[
          _SectionHeader(
            'Skip hue stocks',
            '${r.skips.length} — wajah ke saath',
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: scheme.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: scheme.outlineVariant),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (final s in r.skips.take(40))
                  Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Text(
                      '${s.symbol} — ${s.reason}',
                      style: TextStyle(
                        fontSize: 10.5,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                  ),
                if (r.skips.length > 40)
                  Text(
                    '… aur ${r.skips.length - 40}',
                    style: TextStyle(
                      fontSize: 10,
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 14),
        ],

        Text(
          'Data: Angel One daily candles (cache) · report ke numbers engine se '
          'hain, koi estimate nahi. Backtest past ka hisaab hai — future ki '
          'guarantee nahi. Cost ${p.strategy.settings.costPct}% per round trip '
          'include hai.',
          style: TextStyle(
            fontSize: 10,
            height: 1.5,
            color: scheme.onSurfaceVariant,
          ),
        ),
        const SizedBox(height: 10),
      ], padding: const EdgeInsets.fromLTRB(16, 10, 16, 26)),
    );
  }

  /// Export menu — file banao, phir share sheet / Telegram.
  static Future<void> _export(
    BuildContext context,
    StrategyBuilderProvider p,
    BacktestResult r,
    String kind,
  ) async {
    final messenger = ScaffoldMessenger.of(context);
    final delivery = StrategyDeliveryService();
    final settings = context.read<SettingsProvider>().settings;
    final benchmark = p.benchmarkLabel;
    final source = p.sourceLabel;
    final warnings = p.warnings();

    try {
      switch (kind) {
        case 'text':
          final outcome = await delivery.shareText(
            StrategyDeliveryService.recap(
              r,
              p.strategy,
              sourceLabel: source,
              benchmarkLabel: benchmark,
              warnings: warnings,
            ),
          );
          messenger.showSnackBar(SnackBar(content: Text(outcome.message)));
        case 'telegram':
          final file = await StrategyDeliveryService.writeXlsx(
            r,
            p.strategy,
            sourceLabel: source,
            benchmarkLabel: benchmark,
            warnings: warnings,
          );
          final outcome = await delivery.sendTelegram(
            file: file,
            caption: StrategyDeliveryService.recap(
              r,
              p.strategy,
              sourceLabel: source,
              benchmarkLabel: benchmark,
              warnings: warnings,
            ),
            settings: settings,
          );
          messenger.showSnackBar(SnackBar(content: Text(outcome.message)));
        case 'xlsx':
          final file = await StrategyDeliveryService.writeXlsx(
            r,
            p.strategy,
            sourceLabel: source,
            benchmarkLabel: benchmark,
            warnings: warnings,
          );
          final outcome = await delivery.shareFile(file, 'Strategy backtest');
          messenger.showSnackBar(SnackBar(content: Text(outcome.message)));
        default:
          final dir = await getTemporaryDirectory();
          final slug = p.strategy.name
              .toLowerCase()
              .replaceAll(RegExp(r'[^a-z0-9]+'), '_')
              .replaceAll(RegExp(r'^_|_$'), '');
          final file = File(
            '${dir.path}/strategy_${slug.isEmpty ? 'report' : slug}.csv',
          );
          await file.writeAsString(strategyCsvReport(r, p.strategy));
          final outcome = await delivery.shareFile(file, 'Strategy backtest');
          messenger.showSnackBar(SnackBar(content: Text(outcome.message)));
      }
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('Export fail: $e')));
    }
  }

  static String _signed(double v) =>
      '${v >= 0 ? '+' : ''}${v.toStringAsFixed(2)}';
}

class _Stat extends StatelessWidget {
  const _Stat({
    required this.label,
    required this.value,
    this.good = false,
    this.bad = false,
  });

  final String label;
  final String value;
  final bool good;
  final bool bad;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      width: 104,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant),
          ),
          const SizedBox(height: 3),
          Text(
            value,
            style: TextStyle(
              fontSize: 13.5,
              fontWeight: FontWeight.w900,
              color: bad
                  ? scheme.error
                  : good
                  ? Brand.greenDeep
                  : scheme.onSurface,
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader(this.title, this.subtitle);

  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w900,
            color: scheme.onSurface,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          subtitle,
          style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant),
        ),
      ],
    );
  }
}

class _LegendDot extends StatelessWidget {
  const _LegendDot({required this.color, required this.label});

  final Color color;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 12,
          height: 3,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 5),
        Text(
          label,
          style: TextStyle(
            fontSize: 9.5,
            color: Theme.of(context).colorScheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }
}

class _TradeRow extends StatelessWidget {
  const _TradeRow({required this.trade});

  final StrategyTrade trade;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final win = trade.isWin;
    return Container(
      margin: const EdgeInsets.only(bottom: 5),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 84,
            child: Text(
              trade.symbol,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 11.5,
                fontWeight: FontWeight.w800,
                color: scheme.onSurface,
              ),
            ),
          ),
          Expanded(
            child: Text(
              '${_d(trade.entryDate)} → ${_d(trade.exitDate)} · '
              '${trade.bars}d · ${trade.reason}',
              style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant),
            ),
          ),
          Text(
            '${trade.netPct >= 0 ? '+' : ''}${trade.netPct.toStringAsFixed(2)}%',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: win ? Brand.greenDeep : scheme.error,
            ),
          ),
        ],
      ),
    );
  }

  static String _d(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year % 100}';
}

/// Equity + benchmark curve (koi naya package nahi — CustomPainter).
class _EquityPainter extends CustomPainter {
  _EquityPainter({
    required this.equity,
    required this.benchmark,
    required this.line,
    required this.bench,
    required this.grid,
  });

  final List<double> equity;
  final List<double> benchmark;
  final Color line;
  final Color bench;
  final Color grid;

  @override
  void paint(Canvas canvas, Size size) {
    if (equity.length < 2) return;
    final all = [...equity, ...benchmark];
    var lo = all.reduce((a, b) => a < b ? a : b);
    var hi = all.reduce((a, b) => a > b ? a : b);
    if (hi - lo < 0.02) {
      lo -= 0.02;
      hi += 0.02;
    }
    final pad = (hi - lo) * 0.08;
    lo -= pad;
    hi += pad;

    double x(int i, int n) => n <= 1 ? 0 : size.width * i / (n - 1);
    double y(double v) => size.height * (1 - (v - lo) / (hi - lo));

    // 1.0 ki line (break-even) — halki.
    final zeroPaint = Paint()
      ..color = grid
      ..strokeWidth = 1;
    canvas.drawLine(Offset(0, y(1.0)), Offset(size.width, y(1.0)), zeroPaint);

    Path build(List<double> values) {
      final path = Path();
      for (var i = 0; i < values.length; i++) {
        final p = Offset(x(i, values.length), y(values[i]));
        if (i == 0) {
          path.moveTo(p.dx, p.dy);
        } else {
          path.lineTo(p.dx, p.dy);
        }
      }
      return path;
    }

    canvas.drawPath(
      build(benchmark),
      Paint()
        ..color = bench
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4,
    );
    final equityPath = build(equity);
    canvas.drawPath(
      equityPath,
      Paint()
        ..color = line
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.1
        ..strokeCap = StrokeCap.round,
    );
  }

  @override
  bool shouldRepaint(_EquityPainter old) =>
      old.equity.length != equity.length || old.equity.last != equity.last;
}

/// Saal × mahina heatmap — har cell us mahine ka return %. Range ke hisaab se
/// rang: sabse bura laal, zero halka, sabse achha hara (magnitude se intensity).
class _MonthlyHeatmap extends StatelessWidget {
  const _MonthlyHeatmap({required this.monthly});

  final Map<String, double> monthly;

  static const _months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    // 'yyyy-MM' → (year, month, value)
    final byYear = <int, Map<int, double>>{};
    for (final e in monthly.entries) {
      final parts = e.key.split('-');
      if (parts.length != 2) continue;
      final y = int.tryParse(parts[0]);
      final m = int.tryParse(parts[1]);
      if (y == null || m == null) continue;
      byYear.putIfAbsent(y, () => {})[m] = e.value;
    }
    final years = byYear.keys.toList()..sort();
    if (years.isEmpty) return const SizedBox.shrink();
    final values = monthly.values.toList();
    final maxAbs = values.fold<double>(1, (a, b) => b.abs() > a ? b.abs() : a);

    Widget cell(int year, int month) {
      final v = byYear[year]?[month];
      if (v == null) {
        return Container(
          margin: const EdgeInsets.all(1.5),
          decoration: BoxDecoration(
            color: scheme.surfaceContainerHighest.withValues(alpha: 0.45),
            borderRadius: BorderRadius.circular(6),
          ),
        );
      }
      final t = (v.abs() / maxAbs).clamp(0.12, 1.0);
      final color = v >= 0
          ? Brand.greenDeep.withValues(alpha: 0.18 + 0.72 * t)
          : scheme.error.withValues(alpha: 0.18 + 0.72 * t);
      // Dark cells par safed, halke cells par ink — dono theme me readable.
      final ink = t > 0.45 ? Colors.white : scheme.onSurface;
      return Container(
        margin: const EdgeInsets.all(1.5),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(6),
        ),
        child: Text(
          '${v >= 0 ? '+' : ''}${v.toStringAsFixed(1)}',
          style: TextStyle(
            fontSize: 8.5,
            fontWeight: FontWeight.w800,
            color: ink,
          ),
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Column(
        children: [
          Row(
            children: [
              const SizedBox(width: 34),
              for (final m in _months)
                Expanded(
                  child: Center(
                    child: Text(
                      m,
                      style: TextStyle(
                        fontSize: 8,
                        fontWeight: FontWeight.w700,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 3),
          for (final y in years)
            Row(
              children: [
                SizedBox(
                  width: 34,
                  child: Text(
                    '$y',
                    style: TextStyle(
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
                ),
                for (var m = 1; m <= 12; m++)
                  Expanded(
                    child: AspectRatio(aspectRatio: 1.25, child: cell(y, m)),
                  ),
              ],
            ),
        ],
      ),
    );
  }
}

/// Drawdown strip: 0 se neeche kitna gaya, har din.
class _DrawdownPainter extends CustomPainter {
  _DrawdownPainter({
    required this.equity,
    required this.fill,
    required this.line,
    required this.grid,
  });

  final List<double> equity;
  final Color fill;
  final Color line;
  final Color grid;

  @override
  void paint(Canvas canvas, Size size) {
    if (equity.length < 2) return;
    final dd = <double>[];
    var peak = equity.first;
    for (final e in equity) {
      if (e > peak) peak = e;
      dd.add(peak > 0 ? (1 - e / peak) * 100 : 0);
    }
    final worst = dd.fold<double>(0.5, (a, b) => b > a ? b : a);
    double x(int i) => size.width * i / (dd.length - 1);
    double y(double v) => size.height * (v / worst);

    final path = Path()..moveTo(0, 0);
    for (var i = 0; i < dd.length; i++) {
      path.lineTo(x(i), y(dd[i]));
    }
    final area = Path.from(path)
      ..lineTo(size.width, 0)
      ..close();
    canvas.drawPath(area, Paint()..color = fill);
    canvas.drawPath(
      path,
      Paint()
        ..color = line
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4,
    );
    canvas.drawLine(Offset.zero, Offset(size.width, 0), Paint()..color = grid);
  }

  @override
  bool shouldRepaint(_DrawdownPainter old) =>
      old.equity.length != equity.length;
}

/// OOS ka ek row: label + trades/win/PF/return.
class _OosRow extends StatelessWidget {
  const _OosRow({required this.label, required this.r, required this.color});

  final String label;
  final BacktestResult r;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final s = r.stats;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 10.5,
            fontWeight: FontWeight.w800,
            color: color,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          '${s.trades} trades · win ${s.winRate.toStringAsFixed(1)}% · '
          'PF ${s.profitFactor.toStringAsFixed(2)} · '
          'avg ${s.avgTrade >= 0 ? '+' : ''}${s.avgTrade.toStringAsFixed(2)}% · '
          'return ${s.totalReturnPct >= 0 ? '+' : ''}'
          '${s.totalReturnPct.toStringAsFixed(1)}%',
          style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant),
        ),
      ],
    );
  }
}
