// ---------------------------------------------------------------------------
// strategy_rules.dart — "kaun sa rule" ka ek hi sach (JSON).
//
// Design: user **indicator select karta hai + parameter badalta hai**, formula
// nahi likhta. Jo bhi banta hai wo ek chhote JSON me convert hota hai —
// `{"indicator":"rsi","params":{"period":5},"op":"lt","value":30}` — aur wahi
// JSON save hota hai, share hota hai, aur engine chalata hai. Isse:
//   • saved strategy dobara load par bilkul wahi chalti hai,
//   • engine ko UI ki zaroorat nahi (pure Dart, testable),
//   • naya indicator add karna = ek enum + ek case.
//
// v1 ke indicators sirf **price/volume** se bante hain (RSI, SMA/EMA, MACD,
// Bollinger, ATR, ADX/DI, Stochastic, Volume SMA, 52W range, ROC) — isliye ye
// har stock par chalte hain, aur aage index par bhi bina badlav chalenge.
// ---------------------------------------------------------------------------

import 'dart:convert';

import 'strategy_fundamentals.dart';

/// Supported indicators — har ek ki apni params list hai.
enum Indicator {
  price('Close price', ['Close price'], defaultParams: {}),
  rsi('RSI', ['period'], defaultParams: {'period': 14}),
  sma('SMA', ['period'], defaultParams: {'period': 200}),
  ema('EMA', ['period'], defaultParams: {'period': 20}),
  macd(
    'MACD line',
    ['fast', 'slow', 'signal'],
    defaultParams: {'fast': 12, 'slow': 26, 'signal': 9},
  ),
  macdSignal(
    'MACD signal',
    ['fast', 'slow', 'signal'],
    defaultParams: {'fast': 12, 'slow': 26, 'signal': 9},
  ),
  bollUpper(
    'Bollinger upper',
    ['period', 'mult'],
    defaultParams: {'period': 20, 'mult': 2},
  ),
  bollLower(
    'Bollinger lower',
    ['period', 'mult'],
    defaultParams: {'period': 20, 'mult': 2},
  ),
  atrPercent('ATR % of close', ['period'], defaultParams: {'period': 14}),
  adx('ADX', ['period'], defaultParams: {'period': 14}),
  plusDi('+DI', ['period'], defaultParams: {'period': 14}),
  minusDi('-DI', ['period'], defaultParams: {'period': 14}),
  stochK('Stochastic %K', ['period'], defaultParams: {'period': 14}),
  volumeRatio('Volume ÷ volume SMA', ['period'], defaultParams: {'period': 20}),
  range52('52W range position %', ['period'], defaultParams: {'period': 250}),
  roc('ROC %', ['period'], defaultParams: {'period': 10}),
  rsiRising(
    'RSI rising (n days)',
    ['period', 'days'],
    defaultParams: {'period': 5, 'days': 3},
  ),
  rsiFalling(
    'RSI falling (n days)',
    ['period', 'days'],
    defaultParams: {'period': 5, 'days': 3},
  ),
  smaCrossAbove(
    'SMA cross above SMA',
    ['period', 'other'],
    defaultParams: {'period': 20, 'other': 50},
  ),
  smaCrossBelow(
    'SMA cross below SMA',
    ['period', 'other'],
    defaultParams: {'period': 20, 'other': 50},
  ),
  macdCrossAboveSignal(
    'MACD crosses above signal',
    ['fast', 'slow', 'signal'],
    defaultParams: {'fast': 12, 'slow': 26, 'signal': 9},
  ),
  macdCrossBelowSignal(
    'MACD crosses below signal',
    ['fast', 'slow', 'signal'],
    defaultParams: {'fast': 12, 'slow': 26, 'signal': 9},
  );

  const Indicator(this.label, this.paramNames, {required this.defaultParams});

  /// UI me dikhne wala naam.
  final String label;

  /// Kaun se parameter user badal sakta hai.
  final List<String> paramNames;

  /// Shuru me bhare hue parameter (user inhe badal sakta hai).
  final Map<String, num> defaultParams;

  /// Ye indicator cross-hai? Cross par `op`/`value` ki zaroorat nahi.
  bool get isCross => const {
    Indicator.smaCrossAbove,
    Indicator.smaCrossBelow,
    Indicator.macdCrossAboveSignal,
    Indicator.macdCrossBelowSignal,
  }.contains(this);

  /// Ye indicator "lagataar badh/gira" hai? (0/1 → comparison ka matlab nahi)
  bool get isTrend =>
      this == Indicator.rsiRising || this == Indicator.rsiFalling;

  String get id => name;

  static Indicator fromId(String id) => Indicator.values.firstWhere(
    (e) => e.id == id,
    orElse: () => Indicator.price,
  );
}

/// Comparison operators.
enum RuleOp {
  lt('<'),
  lte('≤'),
  gt('>'),
  gte('≥');

  const RuleOp(this.symbol);

  final String symbol;

  bool test(double a, double b) => switch (this) {
    RuleOp.lt => a < b,
    RuleOp.lte => a <= b,
    RuleOp.gt => a > b,
    RuleOp.gte => a >= b,
  };

  static RuleOp fromId(String id) =>
      RuleOp.values.firstWhere((e) => e.name == id, orElse: () => RuleOp.lt);
}

/// Ek condition.
class Rule {
  const Rule({
    required this.indicator,
    this.params = const {},
    this.op = RuleOp.lt,
    this.value = 0,
    this.compareTo,
    this.against,
  });

  final Indicator indicator;
  final Map<String, num> params;
  final RuleOp op;

  /// `indicator op value` — jab doosre indicator se compare nahi karna.
  final num value;

  /// Doosre indicator se compare (jaise `Close > SMA(200)`).
  final Indicator? compareTo;

  /// `compareTo` ke apne params.
  final Map<String, num>? against;

  /// Effective params (default ke upar user ke).
  Map<String, num> get effectiveParams => {
    ...indicator.defaultParams,
    ...params,
  };

  num param(String key) => effectiveParams[key] ?? 0;

  Rule copyWith({
    Indicator? indicator,
    Map<String, num>? params,
    RuleOp? op,
    num? value,
    Indicator? compareTo,
    Map<String, num>? against,
    bool clearCompareTo = false,
  }) => Rule(
    indicator: indicator ?? this.indicator,
    params: params ?? this.params,
    op: op ?? this.op,
    value: value ?? this.value,
    compareTo: clearCompareTo ? null : (compareTo ?? this.compareTo),
    against: clearCompareTo ? null : (against ?? this.against),
  );

  Map<String, dynamic> toJson() => {
    'indicator': indicator.id,
    'params': effectiveParams,
    'op': op.name,
    'value': value,
    if (compareTo != null) 'compareTo': compareTo!.id,
    if (against != null) 'against': against,
  };

  factory Rule.fromJson(Map<String, dynamic> json) {
    return Rule(
      indicator: Indicator.fromId('${json['indicator']}'),
      params:
          (json['params'] as Map?)?.map(
            (k, v) => MapEntry('$k', (v as num?) ?? 0),
          ) ??
          const {},
      op: RuleOp.fromId('${json['op']}'),
      value: (json['value'] as num?) ?? 0,
      compareTo: json['compareTo'] == null
          ? null
          : Indicator.fromId('${json['compareTo']}'),
      against: (json['against'] as Map?)?.map(
        (k, v) => MapEntry('$k', (v as num?) ?? 0),
      ),
    );
  }

  /// Screen par padhne layak line, jaise `RSI(5) < 30`.
  String describe() {
    final p = effectiveParams;
    final argText = indicator.paramNames
        .where((n) => p[n] != null)
        .map((n) => '${p[n]}')
        .join(' , ');
    final left = argText.isEmpty
        ? indicator.label
        : '${indicator.label}($argText)';
    // Trend/cross indicators apne aap me poore hain — inke aage `< 0` nahi.
    if (indicator.isTrend || indicator.isCross) return left;
    if (compareTo != null) {
      final a = against ?? const {};
      final rightArgs = compareTo!.paramNames
          .where((n) => a[n] != null)
          .map((n) => '${a[n]}')
          .join(' , ');
      final right = rightArgs.isEmpty
          ? compareTo!.label
          : '${compareTo!.label}($rightArgs)';
      return '$left ${op.symbol} $right';
    }
    return '$left ${op.symbol} ${_num(value)}';
  }
}

String _num(num v) =>
    v == v.roundToDouble() ? '${v.toInt()}' : v.toStringAsFixed(2);

/// Entry/exit conditions ko jodne ka tarika.
enum RuleJoin {
  and('AND — saare rules'),
  or('OR — koi bhi rule');

  const RuleJoin(this.label);

  final String label;

  bool combine(List<bool> results) => switch (this) {
    RuleJoin.and => results.isNotEmpty && results.every((r) => r),
    RuleJoin.or => results.any((r) => r),
  };
}

/// Backtest ka timeframe (1.5.104).
///
/// **Daily** = 5 saal tak ka itihaas, broker `ONE_DAY` candles.
/// **15 min / 5 min** = sirf jo data app ke paas asli me hai — Angel
/// `getCandleData` intraday window (≈100 din tak in sandbox/app conditions;
/// isse purana maange to "data available nahi", fake bars nahi).
enum Timeframe {
  daily('daily', 'Daily', 'ONE_DAY', 0),
  m15('m15', '15 min', 'FIFTEEN_MINUTE', 15),
  m5('m5', '5 min', 'FIVE_MINUTE', 5);

  const Timeframe(this.id, this.label, this.apiInterval, this.minutes);

  final String id;
  final String label;

  /// Angel `getCandleData` ka interval string.
  final String apiInterval;

  /// Bar ka size minutes me (0 = daily).
  final int minutes;

  bool get isIntraday => minutes > 0;

  /// Intraday me kitne calendar din ka itihaas maangte hain (broker ki limit
  /// ke andar — 5-min par 100 din, 15-min par 100 din; daily 5 saal).
  int get maxLookbackDays => isIntraday ? 100 : 5 * 365;

  static Timeframe fromId(String? id) =>
      values.firstWhere((t) => t.id == id, orElse: () => Timeframe.daily);
}

/// Risk / position settings.
class StrategySettings {
  const StrategySettings({
    this.stopLossPct = 0,
    this.targetPct = 0,
    this.timeStopBars = 0,
    this.costPct = 0.35,
    this.maxPositions = 10,
    this.capital = 100000,
    this.minBars = 260,
    this.years = 2,
    this.timeframe = Timeframe.daily,
  });

  /// 0 = stop loss nahi.
  final double stopLossPct;

  /// 0 = target nahi.
  final double targetPct;

  /// 0 = time stop nahi (bars me).
  final int timeStopBars;

  /// Round-trip cost (brokerage + STT + slippage) — default 0.35%.
  final double costPct;

  /// Ek saath max kitne position (10 slots model).
  final int maxPositions;

  final double capital;

  /// Itne bars se kam ho to stock "skip — data kam" me.
  final int minBars;

  final int years;

  /// 1.5.104 — daily / 15 min / 5 min.
  final Timeframe timeframe;

  StrategySettings copyWith({
    double? stopLossPct,
    double? targetPct,
    int? timeStopBars,
    double? costPct,
    int? maxPositions,
    double? capital,
    int? minBars,
    int? years,
    Timeframe? timeframe,
  }) => StrategySettings(
    stopLossPct: stopLossPct ?? this.stopLossPct,
    targetPct: targetPct ?? this.targetPct,
    timeStopBars: timeStopBars ?? this.timeStopBars,
    costPct: costPct ?? this.costPct,
    maxPositions: maxPositions ?? this.maxPositions,
    capital: capital ?? this.capital,
    minBars: minBars ?? this.minBars,
    years: years ?? this.years,
    timeframe: timeframe ?? this.timeframe,
  );

  Map<String, dynamic> toJson() => {
    'stopLossPct': stopLossPct,
    'targetPct': targetPct,
    'timeStopBars': timeStopBars,
    'costPct': costPct,
    'maxPositions': maxPositions,
    'capital': capital,
    'minBars': minBars,
    'years': years,
    'timeframe': timeframe.id,
  };

  factory StrategySettings.fromJson(Map<String, dynamic> j) => StrategySettings(
    stopLossPct: (j['stopLossPct'] as num?)?.toDouble() ?? 0,
    targetPct: (j['targetPct'] as num?)?.toDouble() ?? 0,
    timeStopBars: (j['timeStopBars'] as num?)?.toInt() ?? 0,
    costPct: (j['costPct'] as num?)?.toDouble() ?? 0.35,
    maxPositions: (j['maxPositions'] as num?)?.toInt() ?? 10,
    capital: (j['capital'] as num?)?.toDouble() ?? 100000,
    minBars: (j['minBars'] as num?)?.toInt() ?? 260,
    years: (j['years'] as num?)?.toInt() ?? 2,
    timeframe: Timeframe.fromId(j['timeframe'] as String?),
  );
}

/// Poori strategy — ek hi object jo save/share/hot hota hai.
class Strategy {
  const Strategy({
    required this.name,
    required this.universeKey,
    required this.entry,
    required this.exit,
    this.entryJoin = RuleJoin.and,
    this.exitJoin = RuleJoin.or,
    this.settings = const StrategySettings(),
    this.fundamentals = const FundamentalFilter(),
    this.notes = '',
  });

  final String name;

  /// `UniverseCatalog` key (fno / nifty50 / master_nse …).
  final String universeKey;

  final List<Rule> entry;
  final List<Rule> exit;
  final RuleJoin entryJoin;
  final RuleJoin exitJoin;
  final StrategySettings settings;

  /// 1.5.104 — fundamentals filter (aaj ke numbers, poore window par).
  final FundamentalFilter fundamentals;
  final String notes;

  Strategy copyWith({
    String? name,
    String? universeKey,
    List<Rule>? entry,
    List<Rule>? exit,
    RuleJoin? entryJoin,
    RuleJoin? exitJoin,
    StrategySettings? settings,
    FundamentalFilter? fundamentals,
    String? notes,
  }) => Strategy(
    name: name ?? this.name,
    universeKey: universeKey ?? this.universeKey,
    entry: entry ?? this.entry,
    exit: exit ?? this.exit,
    entryJoin: entryJoin ?? this.entryJoin,
    exitJoin: exitJoin ?? this.exitJoin,
    settings: settings ?? this.settings,
    fundamentals: fundamentals ?? this.fundamentals,
    notes: notes ?? this.notes,
  );

  Map<String, dynamic> toJson() => {
    'version': 1,
    'name': name,
    'universeKey': universeKey,
    'entry': entry.map((r) => r.toJson()).toList(),
    'exit': exit.map((r) => r.toJson()).toList(),
    'entryJoin': entryJoin.name,
    'exitJoin': exitJoin.name,
    'settings': settings.toJson(),
    if (fundamentals.isActive) 'fundamentals': fundamentals.toJson(),
    'notes': notes,
  };

  factory Strategy.fromJson(Map<String, dynamic> j) => Strategy(
    name: '${j['name'] ?? 'Strategy'}',
    universeKey: '${j['universeKey'] ?? 'fno'}',
    entry: ((j['entry'] as List?) ?? const [])
        .map((e) => Rule.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList(),
    exit: ((j['exit'] as List?) ?? const [])
        .map((e) => Rule.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList(),
    entryJoin: RuleJoin.values.firstWhere(
      (e) => e.name == '${j['entryJoin']}',
      orElse: () => RuleJoin.and,
    ),
    exitJoin: RuleJoin.values.firstWhere(
      (e) => e.name == '${j['exitJoin']}',
      orElse: () => RuleJoin.or,
    ),
    settings: StrategySettings.fromJson(
      Map<String, dynamic>.from((j['settings'] as Map?) ?? const {}),
    ),
    fundamentals: FundamentalFilter.fromJson(
      j['fundamentals'] == null
          ? null
          : Map<String, dynamic>.from(j['fundamentals'] as Map),
    ),
    notes: '${j['notes'] ?? ''}',
  );

  String encode() => jsonEncode(toJson());

  factory Strategy.decode(String raw) =>
      Strategy.fromJson(Map<String, dynamic>.from(jsonDecode(raw) as Map));
}

/// Shuru karne ke liye ek samajh me aane wali strategy (Triple RSI — jo
/// research me test ki gayi thi). Ye sirf default hai, user badal sakta hai.
Strategy tripleRsiPreset({String universeKey = 'fno'}) => Strategy(
  name: 'Triple RSI (uptrend pullback)',
  universeKey: universeKey,
  entry: const [
    Rule(
      indicator: Indicator.rsi,
      params: {'period': 5},
      op: RuleOp.lt,
      value: 30,
    ),
    Rule(indicator: Indicator.rsiFalling, params: {'period': 5, 'days': 3}),
    Rule(
      indicator: Indicator.price,
      op: RuleOp.gt,
      compareTo: Indicator.sma,
      against: {'period': 200},
    ),
  ],
  exit: const [
    Rule(
      indicator: Indicator.rsi,
      params: {'period': 5},
      op: RuleOp.gt,
      value: 50,
    ),
  ],
  settings: const StrategySettings(
    costPct: 0.35,
    maxPositions: 10,
    years: 2,
    minBars: 260,
  ),
  notes: 'Uptrend me 3 din ka RSI pullback kharido, RSI 50 cross par becho.',
);
