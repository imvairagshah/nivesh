// ---------------------------------------------------------------------------
// equity_hub_screen.dart — EQUITY segment ke saare tools, icons ke through
// (1.5.96 redesign, design "B" · Paper Light).
//
// Design decision: yahan **sirf** equity wale tools hain. F&O ke tools apne
// hub me (`fno_hub_screen.dart`). Har tile ek seedha route hai — pehle jo
// bottom-nav tabs the, wahi ab is grid ke tiles hain.
//
// 1.5.97 (user decision): tile par chhoti description hata di — tiles ab
// **barabar** hain (icon + naam, fixed height). Har tool ka brief + details
// FAQ me hai (`features/help/tool_faq.dart`), app bar ke ? se khulta hai.
//
// Do column ka grid; chhoti screen par bhi tap target 100+ px rehta hai, aur
// poori list ek hi scroll me hai (nested scroll nahi — 1.5.92 ka niyam).
//
// 1.5.101 (user): "Telegram channel wala option equity aur fno jaise ek alag
// section bana do" — isliye **Calls Board** (Telegram channels) yahan se hata
// kar naye EXTRA hub me chala gaya (`features/extra/`). Equity me ab 7 tools.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../core/widgets/edge_header.dart';
import '../../core/widgets/page_scroll.dart';
import '../golden_cross/golden_cross_screen.dart';
import '../ipo_screener/ipo_screener_screen.dart';
import '../magic_formula/magic_formula_screen.dart';
import '../paper_trading/paper_trading_screen.dart';
import '../reports/reports_screen.dart';
import '../rsi_scanner/rsi_scanner_screen.dart';
import '../help/tool_faq.dart';
import '../help/tool_faq_screen.dart';
import '../settings/settings_screen.dart';

/// Ek tile ka poora description.
class EquityTool {
  const EquityTool({
    required this.title,
    required this.icon,
    required this.build,
  });

  final String title;
  final IconData icon;

  /// Tap par kholne wali screen.
  final Widget Function() build;
}

/// Equity ke saare tools, isi tarteeb me grid me dikhte hain.
final List<EquityTool> kEquityTools = [
  EquityTool(
    title: 'IPO Screener',
    icon: Icons.new_releases_rounded,
    build: () => const IpoScreenerScreen(),
  ),
  EquityTool(
    title: 'Golden Cross',
    icon: Icons.timeline_rounded,
    build: () => const GoldenCrossScreen(),
  ),
  EquityTool(
    title: 'RSI Scanner',
    icon: Icons.speed_rounded,
    build: () => const RsiScannerScreen(),
  ),
  EquityTool(
    title: 'Magic Formula',
    icon: Icons.functions_rounded,
    build: () => const MagicFormulaScreen(),
  ),
  EquityTool(
    title: 'Paper Trading',
    icon: Icons.account_balance_wallet_rounded,
    build: () => const PaperTradingScreen(),
  ),
  EquityTool(
    title: 'Reports',
    icon: Icons.bar_chart_rounded,
    build: () => const ReportsScreen(),
  ),
  EquityTool(
    title: 'Settings',
    icon: Icons.tune_rounded,
    build: () => const SettingsScreen(),
  ),
];

class EquityHubScreen extends StatelessWidget {
  const EquityHubScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: EdgeAppBar(
        title: 'Equity',
        subtitle: 'Screener · IPO · research',
        actions: [
          IconButton(
            tooltip: 'FAQ — har tool ka brief',
            icon: const Icon(Icons.help_outline_rounded),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => const ToolFaqScreen(
                  title: 'Equity · FAQ',
                  entries: kEquityFaq,
                ),
              ),
            ),
          ),
        ],
      ),
      body: PageScroll.children([
        _ToolGrid(tools: kEquityTools),
        const SizedBox(height: 16),
        _FaqButton(
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute<void>(
              builder: (_) => const ToolFaqScreen(
                title: 'Equity · FAQ',
                entries: kEquityFaq,
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Center(
          child: Text(
            'TRADE EDGE · paper trading only',
            style: TextStyle(
              fontSize: 10,
              letterSpacing: 0.6,
              color: scheme.onSurfaceVariant.withValues(alpha: 0.75),
            ),
          ),
        ),
      ], padding: const EdgeInsets.fromLTRB(16, 8, 16, 24)),
    );
  }
}

/// Do column ka grid — desktop par chaar column.
class _ToolGrid extends StatelessWidget {
  const _ToolGrid({required this.tools});

  final List<EquityTool> tools;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final columns = constraints.maxWidth >= 900
            ? 4
            : (constraints.maxWidth >= 620 ? 3 : 2);
        const gap = 11.0;
        final width = (constraints.maxWidth - gap * (columns - 1)) / columns;
        return Wrap(
          spacing: gap,
          runSpacing: gap,
          children: [
            for (final tool in tools)
              SizedBox(
                width: width,
                child: _ToolTile(tool: tool),
              ),
          ],
        );
      },
    );
  }
}

class _ToolTile extends StatelessWidget {
  const _ToolTile({required this.tool});

  final EquityTool tool;

  /// 1.5.97 — sab tiles **ek hi height** ke (user complaint: text ki wajah se
  /// chhoti-badi ho rahi thin). Sirf icon + naam, isliye height fix rakhi ja
  /// sakti hai.
  static const double height = 96;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Material(
      color: scheme.surface,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => Navigator.of(
          context,
        ).push(MaterialPageRoute<void>(builder: (_) => tool.build())),
        child: Container(
          height: height,
          padding: const EdgeInsets.fromLTRB(13, 12, 13, 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: scheme.outlineVariant),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: scheme.primaryContainer,
                  borderRadius: BorderRadius.circular(11),
                ),
                child: Icon(tool.icon, size: 19, color: Brand.green),
              ),
              const SizedBox(height: 8),
              Text(
                tool.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w800,
                  height: 1.15,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// FAQ ka darwaza — grid ke neeche, taaki seedha dikhe.
class _FaqButton extends StatelessWidget {
  const _FaqButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Material(
      color: scheme.surface,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.fromLTRB(14, 13, 12, 13),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: scheme.outlineVariant),
          ),
          child: Row(
            children: [
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  color: scheme.primaryContainer,
                  borderRadius: BorderRadius.circular(9),
                ),
                child: const Icon(
                  Icons.help_outline_rounded,
                  size: 17,
                  color: Brand.green,
                ),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'FAQ — har tool ka brief',
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    SizedBox(height: 2),
                    Text(
                      'Kaam, data source aur limit — ek jagah',
                      style: TextStyle(fontSize: 10.5),
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.arrow_forward_rounded,
                size: 16,
                color: scheme.onSurfaceVariant,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
