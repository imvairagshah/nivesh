// ---------------------------------------------------------------------------
// fno_hub_screen.dart — F&O segment ke saare tools, icons ke through (1.5.96).
//
// Pehle (1.5.93): category rows, sirf naam + ek line, long-press se reorder.
// Ab: wahi chaar sections (Study / Index / Options / Calendar & AI), par har
// tool ek **icon tile** hai — 2-column grid, design "B" (Paper Light) ke
// hisaab se. User ka apna order bacha hua hai: tiles `fno_hub_order` se
// arrange hote hain aur long-press karke drag-drop se badle ja sakte hain.
//
// Ek hi page scroll (PageScroll) — koi nested list nahi (1.5.92 ka niyam).
// ---------------------------------------------------------------------------

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_theme.dart';
import '../../core/widgets/edge_header.dart';
import '../../core/widgets/page_scroll.dart';
import '../../data/local/app_database.dart';
import '../../data/local/dao/candle_dao.dart';
import '../../data/local/dao/settings_dao.dart';
import 'ai/ai_suggestion_screen.dart';
import 'bankex/bankex_screen.dart';
import 'extremes/extremes_screen.dart';
import 'extremes/extremes_service.dart';
import 'fno_hub_config.dart';
import 'iv_spike/iv_spike_engine.dart';
import 'iv_spike/iv_spike_screen.dart';
import '../magic_formula/fno_scanner/fno_scanner_screen.dart';
import '../help/tool_faq.dart';
import '../help/tool_faq_screen.dart';
import 'news/news_screen.dart';
import 'results/results_calendar_screen.dart';
import 'stock_oi/stock_oi_screen.dart';
import 'study/fno_study_screen.dart';
import 'study_adv/study_adv_screen.dart';

/// Order kahan save hota hai — test me fake store pass kar sakte hain.
abstract class FnoHubOrderStore {
  Future<Map<String, List<String>>> load();
  Future<void> save(Map<String, List<String>> order);
}

/// Asli store: settings table me ek JSON key.
class SettingsHubOrderStore implements FnoHubOrderStore {
  SettingsHubOrderStore([SettingsDao? dao])
    : _dao = dao ?? SettingsDao(AppDatabase.instance);

  static const String key = 'fno_hub_order';

  final SettingsDao _dao;

  @override
  Future<Map<String, List<String>>> load() async {
    try {
      final raw = await _dao.raw();
      final text = raw[key];
      if (text == null || text.isEmpty) return defaultHubOrder();
      return mergeHubOrder(jsonDecode(text));
    } catch (_) {
      // DB kharab / pehla launch — default order hi theek hai.
      return defaultHubOrder();
    }
  }

  @override
  Future<void> save(Map<String, List<String>> order) async {
    try {
      await _dao.put(key, jsonEncode(hubOrderToJson(order)));
    } catch (_) {
      // Save fail ho to bhi is session ka order chalta rahega.
    }
  }
}

class FnoHubScreen extends StatefulWidget {
  const FnoHubScreen({super.key, this.orderStore});

  /// Tests ke liye inject kar sakte hain; app me null = settings wala store.
  final FnoHubOrderStore? orderStore;

  @override
  State<FnoHubScreen> createState() => _FnoHubScreenState();
}

class _FnoHubScreenState extends State<FnoHubScreen> {
  late final FnoHubOrderStore _store =
      widget.orderStore ?? SettingsHubOrderStore();

  Map<String, List<String>> _order = defaultHubOrder();
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _loadOrder();
  }

  Future<void> _loadOrder() async {
    final order = await _store.load();
    if (!mounted) return;
    setState(() {
      _order = order;
      _loaded = true;
    });
  }

  void _dropTool(String sectionId, String toolId, int rawIndex) {
    final ids = _order[sectionId];
    if (ids == null) return;
    // 1.5.96 (grid): tile ko target tile ki **jagah** par rakho — purana
    // "row ke gap me insert" wala -1 adjustment yahan galat tha, kyunki
    // daayein->baayein drop par order badalta hi nahi tha.
    final next = moveInSection(ids, toolId, rawIndex);
    setState(() => _order = {..._order, sectionId: next});
    _store.save(_order);
  }

  Future<void> _resetOrder() async {
    setState(() => _order = defaultHubOrder());
    await _store.save(_order);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Order wapas default par set ho gaya.')),
    );
  }

  void _openTool(BuildContext context, String id) {
    final route = switch (id) {
      'study' => MaterialPageRoute<void>(
        builder: (_) => const FnoStudyScreen(),
      ),
      'adv' => MaterialPageRoute<void>(builder: (_) => const StudyAdvScreen()),
      'fno_scanner' => MaterialPageRoute<void>(
        builder: (_) => const FnoScannerScreen(),
      ),
      'bankex' => MaterialPageRoute<void>(
        builder: (_) => const BankexStrategiesScreen(),
      ),
      'iv_spike' => MaterialPageRoute<void>(
        builder: (_) => const IvSpikeScreen(),
      ),
      'iv_crush' => MaterialPageRoute<void>(
        builder: (_) => const IvSpikeScreen(mode: IvChangeMode.crush),
      ),
      'stock_oi' => MaterialPageRoute<void>(
        builder: (_) => const StockOiScreen(),
      ),
      'extremes' => MaterialPageRoute<void>(
        builder: (_) => ExtremesScreen(
          service: ExtremesService(
            marketData: context.read(),
            candles: CandleDao(AppDatabase.instance),
            scripMaster: context.read(),
            nseGet: nseExtremesGet(),
          ),
        ),
      ),
      'results' => MaterialPageRoute<void>(
        builder: (_) => const ResultsCalendarScreen(),
      ),
      'ai' => MaterialPageRoute<void>(
        builder: (_) => const AiSuggestionScreen(),
      ),
      'news' => MaterialPageRoute<void>(builder: (_) => const NewsScreen()),
      _ => null,
    };
    if (route == null) return;
    Navigator.of(context).push(route);
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: EdgeAppBar(
        title: 'F&O',
        subtitle: 'Options · study · market data',
        actions: [
          IconButton(
            tooltip: 'FAQ — har tool ka brief',
            icon: const Icon(Icons.help_outline_rounded),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) =>
                    const ToolFaqScreen(title: 'F&O · FAQ', entries: kFnoFaq),
              ),
            ),
          ),
          IconButton(
            tooltip: 'Order reset karo',
            onPressed: _loaded ? _resetOrder : null,
            icon: const Icon(Icons.restart_alt_rounded),
          ),
        ],
      ),
      body: !_loaded
          ? const Center(child: CircularProgressIndicator())
          : PageScroll.children([
              const _Hint(),
              for (final section in HubSection.values) ...[
                if (_order[section.id]?.isNotEmpty ?? false) ...[
                  _SectionHeader(section: section),
                  _SectionGrid(
                    section: section,
                    ids: _order[section.id]!,
                    onTapTool: (id) => _openTool(context, id),
                    onDrop: (id, index) => _dropTool(section.id, id, index),
                  ),
                  const SizedBox(height: 18),
                ],
              ],
              const _ComingSoonTools(),
              const SizedBox(height: 12),
              _FaqButton(
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => const ToolFaqScreen(
                      title: 'F&O · FAQ',
                      entries: kFnoFaq,
                    ),
                  ),
                ),
              ),
              Center(
                child: Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: Text(
                    'TRADE EDGE · paper trading only',
                    style: TextStyle(
                      fontSize: 10,
                      letterSpacing: 0.6,
                      color: scheme.onSurfaceVariant.withValues(alpha: 0.75),
                    ),
                  ),
                ),
              ),
            ], padding: const EdgeInsets.fromLTRB(14, 8, 14, 26)),
    );
  }
}

// ---------------------------------------------------------------------------
// Bits
// ---------------------------------------------------------------------------

class _Hint extends StatelessWidget {
  const _Hint();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 2, 4, 4),
      child: Row(
        children: [
          Icon(
            Icons.drag_indicator_rounded,
            size: 14,
            color: scheme.onSurfaceVariant,
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              'Long-press karke tile ko apni pasand se re-arrange karein.',
              style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader({required this.section});

  final HubSection section;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 10, 4, 10),
      child: Row(
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              color: section.colorOf(context),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 8),
          Text(
            section.label,
            style: TextStyle(
              fontSize: 10.5,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.1,
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}

/// Ek section ke tiles — 2 column (desktop par 4), drag-drop reorder ke saath.
class _SectionGrid extends StatelessWidget {
  const _SectionGrid({
    required this.section,
    required this.ids,
    required this.onTapTool,
    required this.onDrop,
  });

  final HubSection section;
  final List<String> ids;
  final void Function(String id) onTapTool;
  final void Function(String id, int index) onDrop;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final columns = constraints.maxWidth >= 900
            ? 4
            : (constraints.maxWidth >= 620 ? 3 : 2);
        const gap = 10.0;
        final width = (constraints.maxWidth - gap * (columns - 1)) / columns;
        return Wrap(
          spacing: gap,
          runSpacing: gap,
          children: [
            for (var i = 0; i < ids.length; i++)
              SizedBox(
                width: width,
                child: _ToolTile(
                  tool: hubToolById(ids[i]),
                  index: i,
                  onTap: () => onTapTool(ids[i]),
                  onDrop: (id) => onDrop(id, i),
                ),
              ),
          ],
        );
      },
    );
  }
}

class _ToolTile extends StatelessWidget {
  const _ToolTile({
    required this.tool,
    required this.index,
    required this.onTap,
    required this.onDrop,
  });

  final HubTool? tool;
  final int index;
  final VoidCallback onTap;
  final void Function(String id) onDrop;

  @override
  Widget build(BuildContext context) {
    final t = tool;
    if (t == null) return const SizedBox.shrink();

    return DragTarget<String>(
      onWillAcceptWithDetails: (details) => details.data != t.id,
      onAcceptWithDetails: (details) => onDrop(details.data),
      builder: (context, candidate, rejected) {
        final hovering = candidate.isNotEmpty;
        return LongPressDraggable<String>(
          data: t.id,
          feedback: Material(
            color: Colors.transparent,
            child: SizedBox(
              width: 150,
              child: _TileFace(tool: t, lifted: true),
            ),
          ),
          childWhenDragging: Opacity(opacity: 0.35, child: _TileFace(tool: t)),
          child: GestureDetector(
            onTap: onTap,
            child: _TileFace(tool: t, hovering: hovering),
          ),
        );
      },
    );
  }
}

class _TileFace extends StatelessWidget {
  const _TileFace({
    required this.tool,
    this.hovering = false,
    this.lifted = false,
  });

  final HubTool tool;
  final bool hovering;
  final bool lifted;

  /// Uniform tile height — bade/chhote naam se grid nahi hilta.
  static const double height = 96;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final accent = tool.section.colorOf(context);

    // 1.5.97 — sab tiles **ek hi height** ke; description hata di gayi hai
    // (details FAQ me). Isliye fixed height possible hai.
    return AnimatedContainer(
      duration: const Duration(milliseconds: 140),
      height: _TileFace.height,
      padding: const EdgeInsets.fromLTRB(13, 12, 13, 10),
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: hovering ? accent : scheme.outlineVariant,
          width: hovering ? 1.6 : 1,
        ),
        boxShadow: lifted
            ? [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.18),
                  blurRadius: 26,
                  offset: const Offset(0, 12),
                ),
              ]
            : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: accent.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(11),
                ),
                child: Icon(tool.icon, size: 19, color: accent),
              ),
              const Spacer(),
              if (tool.badge != null)
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 6,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: accent.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    tool.badge!,
                    style: TextStyle(
                      fontSize: 8,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.5,
                      color: accent,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            tool.title,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 12.5,
              fontWeight: FontWeight.w800,
              height: 1.15,
            ),
          ),
        ],
      ),
    );
  }
}

/// "Aa raha hai" tools — jo abhi live nahi hain, wo imandaari se neeche.
class _ComingSoonTools extends StatelessWidget {
  const _ComingSoonTools();

  static const List<(String, String)> _tools = [
    ('Option Chain Live', 'Live OI + IV ek screen me'),
    ('Backtest', 'Study ke signals par historical test'),
  ];

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(4, 10, 4, 8),
          child: Text(
            'AA RAHA HAI',
            style: TextStyle(
              fontSize: 10.5,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.1,
              color: scheme.onSurfaceVariant,
            ),
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: scheme.surfaceContainerLow,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: scheme.outlineVariant),
          ),
          child: Column(
            children: [
              for (final (title, subtitle) in _tools)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Row(
                    children: [
                      Icon(
                        Icons.schedule_rounded,
                        size: 14,
                        color: scheme.onSurfaceVariant,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        title,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          '· $subtitle',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 10,
                            color: scheme.onSurfaceVariant,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

/// FAQ ka darwaza — grid ke neeche (1.5.97).
class _FaqButton extends StatelessWidget {
  const _FaqButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Material(
      color: scheme.surface,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.fromLTRB(14, 13, 12, 13),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: scheme.outlineVariant),
          ),
          child: Row(
            children: [
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  color: scheme.primaryContainer,
                  borderRadius: BorderRadius.circular(9),
                ),
                child: const Icon(
                  Icons.help_outline_rounded,
                  size: 17,
                  color: Brand.green,
                ),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'FAQ — har tool ka brief',
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    SizedBox(height: 2),
                    Text(
                      'Kaam, data source aur limit — ek jagah',
                      style: TextStyle(fontSize: 10.5),
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.arrow_forward_rounded,
                size: 16,
                color: scheme.onSurfaceVariant,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
