// ---------------------------------------------------------------------------
// iv_result_cache.dart — IV Spike / IV Crush ka scan output (1.5.107).
//
// Pehle ye screen cache-less thi: app band karke kholne par 213 F&O stocks ka
// poora scan (candles → ATM → premiums → greeks) dobara chalta tha. Ab
// `scan_runs` me kind = `iv_spike` ke saath `{meta, rows}` save hota hai
// (wahi shape jo RSI/Study use karte hain), aur screen kholte hi wo turant
// paint hota hai — pichhle din ka label ke saath. **Naya scan tab chalta hai
// jab user khud \"Scan\" dabaye.**
//
// Rules (data honesty):
//   • Sirf wahi rows save hoti hain jo scan me aayi thi — IV, source, strike,
//     expiry, note — koi number dobara calculate nahi hota.
//   • `kal ka IV` cache se **nahi** aata: wo hamesha Sheet ya snapshot se
//     banta hai (warna ek hi din ka data do baar use ho jaata).
//   • Cache 30 din se purana ho to `ScanCacheDao.pruneRuns` hata deta hai.
// ---------------------------------------------------------------------------

import '../../../data/local/dao/scan_cache_dao.dart';
import 'iv_spike_engine.dart';

class IvResultCache {
  IvResultCache(this._cache);

  final ScanCacheDao _cache;

  static const String kind = ScanKind.ivSpike;

  /// Aaj ka IV per stock — cache se (purana ho sakta hai, `asOf` saath aata hai).
  Future<({Map<String, TodayIv> today, DateTime? asOf})?> load() async {
    try {
      final run = await _cache.latestRun(kind);
      if (run == null || run.rows.isEmpty) return null;
      final asOf = DateTime.tryParse(run.asOf);
      return (today: _rowsToToday(run.rows), asOf: asOf);
    } catch (_) {
      return null;
    }
  }

  /// [asOf] ke hisaab se `(kind, as_of)` row likho/replace karo.
  Future<void> save({
    required DateTime asOf,
    required Map<String, TodayIv> today,
  }) async {
    if (today.isEmpty) return;
    try {
      await _cache.saveRun(
        kind: kind,
        asOf: _isoDate(asOf),
        rows: [
          {'meta': {'asOf': _isoDate(asOf)}},
          for (final entry in today.entries) _todayToRow(entry.value),
        ],
      );
    } catch (_) {
      // Cache optional — scan ka result UI tak pahunch chuka hai.
    }
  }

  Future<void> clear() => _cache.clearRuns(kind);

  Map<String, TodayIv> _rowsToToday(List<Map<String, dynamic>> rows) {
    final out = <String, TodayIv>{};
    for (final row in rows) {
      if (row['meta'] is Map) continue;
      final symbol = '${row['symbol'] ?? ''}';
      if (symbol.isEmpty) continue;
      final sourceName = '${row['source'] ?? ''}';
      out[symbol] = TodayIv(
        symbol: symbol,
        iv: (row['iv'] as num?)?.toDouble(),
        source: IvTodaySource.values.firstWhere(
          (s) => s.name == sourceName,
          orElse: () => IvTodaySource.none,
        ),
        strike: (row['strike'] as num?)?.toDouble(),
        expiryLabel: row['expiry'] == null ? null : '${row['expiry']}',
        daysToExpiry: (row['dte'] as num?)?.toInt(),
        note: '${row['note'] ?? ''}',
      );
    }
    return out;
  }

  Map<String, dynamic> _todayToRow(TodayIv value) => {
    'symbol': value.symbol,
    'iv': value.iv,
    'source': value.source.name,
    'strike': value.strike,
    'expiry': value.expiryLabel,
    'dte': value.daysToExpiry,
    'note': value.note,
  };

  static String _isoDate(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-'
      '${d.month.toString().padLeft(2, '0')}-'
      '${d.day.toString().padLeft(2, '0')}';
}
