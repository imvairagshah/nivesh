// ---------------------------------------------------------------------------
// iv_spike_engine.dart — IV spike ka pura hisaab (1.5.105).
//
// **Do IV, do source — dono labelled:**
//   • "Aaj ka IV"  → broker (Angel) option greeks se ATM CE/PE ka average IV.
//     Na mile to Black-Scholes (premium + spot + strike + DTE) — aur row me
//     source likha jaata hai. Jo stock dono se na nikle, wo "—" rehta hai.
//   • "Kal ka IV"  → abhi ke liye **aapki Google Sheet** (Settings → IV sheet,
//     columns `symbol | ivp | ivr` jaisi hai waisi hi). Sheet me IV column ho
//     to wahi use hota hai. **Nahi ho to app jhooth nahi bolta**: kal ka IV
//     sirf tab dikhta hai jab Sheet me `iv` column ho — warna "—" aur wajah.
//
// Baseline ka option bhi hai: Sheet me IV na ho to app **apna** pichhla
// snapshot (Aaj ka IV jab scan chala tha, din-wise save) kal ke IV ki tarah
// use kar sakta hai — par tab row par likha hota hai "kal = apna snapshot
// (DD MMM)" taaki source saaf rahe.
//
// IVP / IVR: Sheet se aate hain (jaisa pehle se hai). Sheet me na ho to "—".
// Kabhi clamp/guess nahi.
// ---------------------------------------------------------------------------

import 'dart:convert';

import '../../../data/local/dao/settings_dao.dart';
import '../study/iv_sheet.dart';

/// Ek stock ka aaj ka IV reading (broker ya Black-Scholes).
class TodayIv {
  const TodayIv({
    required this.symbol,
    this.iv,
    this.source = IvTodaySource.none,
    this.strike,
    this.expiryLabel,
    this.daysToExpiry,
    this.note = '',
  });

  final String symbol;
  final double? iv;

  /// `broker` / `blackScholes` / `none` — table me chhota label.
  final IvTodaySource source;
  final double? strike;
  final String? expiryLabel;
  final int? daysToExpiry;
  final String note;

  bool get hasIv => iv != null && iv! > 0;
}

enum IvTodaySource {
  broker('Broker'),
  blackScholes('BS'),
  none('—');

  const IvTodaySource(this.label);
  final String label;
}

/// Screen ka mode — 1.5.106: IV Spike (up) ya IV Crush (down).
///
/// Dono ek hi data par chalte hain; farak sirf **kaunsi rows dikhein** aur
/// **kis taraf sort ho**. Change **percentage** me hota hai (aapki demand):
/// `(aaj − kal) / kal × 100` — percentage points sirf reference ke liye.
enum IvChangeMode {
  spike('IV Spike', 'Sabse zyada IV badhne wale'),
  crush('IV Crush', 'Sabse zyada IV girne wale');

  const IvChangeMode(this.title, this.subtitle);
  final String title;
  final String subtitle;
}

/// Kal ka IV kahan se aaya.
enum IvBaselineSource {
  sheet('Sheet'),
  snapshot('Apna snapshot'),
  none('—');

  const IvBaselineSource(this.label);
  final String label;
}

/// Ek row jo table me jaati hai.
class IvSpikeRow {
  const IvSpikeRow({
    required this.symbol,
    required this.todayIv,
    required this.yesterdayIv,
    required this.baseline,
    required this.ivp,
    required this.ivr,
    required this.baselineAsOf,
    this.todaySource = IvTodaySource.none,
    this.note = '',
  });

  final String symbol;
  final double? todayIv;
  final double? yesterdayIv;
  final IvBaselineSource baseline;
  final double? ivp;
  final double? ivr;
  final DateTime? baselineAsOf;
  final IvTodaySource todaySource;

  /// Kyu koi number nahi (missing data ki wajah) — table ke neeche dikhti hai.
  final String note;

  /// Aaj ka IV − kal ka IV (percentage points). Dono na hon to null.
  double? get change =>
      (todayIv == null || yesterdayIv == null) ? null : todayIv! - yesterdayIv!;

  /// Change % (kal ke hisaab se) — sheet me sirf IVP/IVR hone par bhi kaam
  /// aata hai jab baseline snapshot se aaya ho.
  double? get changePct {
    final delta = change;
    if (delta == null || yesterdayIv == null || yesterdayIv! <= 0) return null;
    return delta / yesterdayIv! * 100;
  }

  bool get isSpike => (change ?? 0) > 0;
}

/// Poora result: rows + honest header.
class IvSpikeResult {
  const IvSpikeResult({
    required this.rows,
    required this.asOf,
    required this.sheetAsOf,
    required this.sheetRows,
    required this.todayCount,
    required this.baselineFromSheet,
    required this.baselineFromSnapshot,
    required this.missing,
    this.note = '',
  });

  final List<IvSpikeRow> rows;
  final DateTime asOf;

  /// Sheet me likhi date (milne par) — "kal ki IV kis din ki hai".
  final DateTime? sheetAsOf;
  final int sheetRows;
  final int todayCount;
  final int baselineFromSheet;
  final int baselineFromSnapshot;

  /// Symbol → wajah (jo rows ban hi nahi paayi).
  final Map<String, String> missing;
  final String note;

  int get spikeCount => rows.where((r) => r.isSpike).length;
}

/// Engine — pure-ish: Sheet data, aaj ka IV aur snapshot map le kar rows banata hai.
class IvSpikeEngine {
  IvSpikeEngine._();

  /// [today] = symbol → TodayIv. [sheet] = IvSheetStore.bySymbol.
  /// [snapshot] = pichhle din ka apna IV map (symbol → IV) — optional.
  static IvSpikeResult build({
    required Map<String, TodayIv> today,
    required Map<String, IvSheetRow> sheet,
    required Map<String, double> snapshot,
    DateTime? snapshotAsOf,
    required DateTime asOf,

    /// Mode: spike = badhotri, crush = girawat (1.5.106).
    IvChangeMode mode = IvChangeMode.spike,

    /// Minimum |change %| jo list me aaye (0 = koi bhi movement).
    double minChangePct = 0,
  }) {
    final rows = <IvSpikeRow>[];
    final missing = <String, String>{};
    var fromSheet = 0;
    var fromSnapshot = 0;
    var todayCount = 0;

    final symbols = <String>{
      ...today.keys,
      ...sheet.keys,
      ...snapshot.keys,
    }.toList()..sort();

    for (final symbol in symbols) {
      final t = today[symbol];
      final s = sheet[symbol];
      final todayIv = t?.hasIv == true ? t!.iv : null;
      if (todayIv != null) todayCount++;

      // ---- kal ka IV: Sheet ka IV column pehle, phir apna snapshot -------
      double? yesterdayIv;
      var baseline = IvBaselineSource.none;
      DateTime? baselineAsOf;

      final sheetIv = sheetIvOf(s);
      if (sheetIv != null) {
        yesterdayIv = sheetIv;
        baseline = IvBaselineSource.sheet;
      } else if (snapshot[symbol] != null && snapshot[symbol]! > 0) {
        yesterdayIv = snapshot[symbol];
        baseline = IvBaselineSource.snapshot;
        baselineAsOf = snapshotAsOf;
        fromSnapshot++;
      }
      if (baseline == IvBaselineSource.sheet) fromSheet++;

      if (todayIv == null && yesterdayIv == null && s == null) {
        missing[symbol] = t?.note.isNotEmpty == true
            ? t!.note
            : 'aaj ka IV nahi mila, sheet me bhi row nahi';
        continue;
      }
      if (todayIv == null) {
        missing[symbol] = (t?.note.isNotEmpty ?? false)
            ? t!.note
            : 'aaj ka IV nahi mila';
        continue;
      }

      final delta = yesterdayIv == null ? null : todayIv - yesterdayIv;
      // Threshold **percentage** me hai (1.5.106): (aaj − kal) / kal × 100.
      // Sheet row ho par IV column na ho to IVP/IVR dikhte hain, change nahi —
      // aisi row "sab" view me rehti hai, par spike/crush nahi kehlati.
      final pct = (delta == null || yesterdayIv == null || yesterdayIv <= 0)
          ? null
          : delta / yesterdayIv * 100;
      final keep = pct == null
          ? (s != null)
          : switch (mode) {
              IvChangeMode.spike =>
                pct >= (minChangePct <= 0 ? 0.0001 : minChangePct),
              IvChangeMode.crush =>
                pct <= -(minChangePct <= 0 ? 0.0001 : minChangePct),
            };

      if (!keep) continue;

      rows.add(
        IvSpikeRow(
          symbol: symbol,
          todayIv: todayIv,
          yesterdayIv: yesterdayIv,
          baseline: baseline,
          baselineAsOf: baselineAsOf,
          ivp: s?.ivp,
          ivr: s?.ivr,
          todaySource: t?.source ?? IvTodaySource.none,
          note: t?.note ?? '',
        ),
      );
    }

    // Percentage ke hisaab se: spike me sabse bada **+%** upar, crush me sabse
    // bada **−%** (yaani sabse tez girawat) upar. Jinka change nahi (sheet row
    // bina `iv` column), wo neeche — symbol order me.
    rows.sort((a, b) {
      final pa = a.changePct;
      final pb = b.changePct;
      if (pa == null && pb == null) return a.symbol.compareTo(b.symbol);
      if (pa == null) return 1;
      if (pb == null) return -1;
      return switch (mode) {
        IvChangeMode.spike => pb.compareTo(pa),
        IvChangeMode.crush => pa.compareTo(pb),
      };
    });

    return IvSpikeResult(
      rows: rows,
      asOf: asOf,
      sheetAsOf: null,
      sheetRows: sheet.length,
      todayCount: todayCount,
      baselineFromSheet: fromSheet,
      baselineFromSnapshot: fromSnapshot,
      missing: missing,
    );
  }

  /// Sheet row me IV ho to nikaalo (0–100 range; bahar wale ignore).
  ///
  /// `IvSheetRow` me abhi sirf IVP/IVR hain — isliye IV column ke liye sheet
  /// ka raw text alag se padha jaata hai (neeche [parseSheetWithIv]).
  static double? sheetIvOf(IvSheetRow? row) => row?.iv;

  /// Sheet CSV ko **IV column ke saath** parse karo.
  ///
  /// `IvSheetParsers.parseCsv` sirf ivp/ivr leta hai (1.5.67 ka rule: sheet se
  /// sirf IVP/IVR). IV spike ke liye kal ka IV sheet se hi chahiye, isliye ye
  /// chhota parser usi line format par `iv` column bhi uthata hai — aur
  /// **jab tak sheet me `iv` column nahi hoga, tab tak wo `null` rahega**
  /// (koi bahana nahi, koi guess nahi).
  static ({Map<String, IvSheetRow> bySymbol, DateTime? asOf}) parseSheetWithIv(
    String csv,
  ) {
    final base = IvSheetParsers.parseCsv(csv);
    final lines = csv
        .split(RegExp(r'[\r\n]+'))
        .where((line) => line.trim().isNotEmpty)
        .toList();
    if (lines.length < 2) return base;

    String norm(String raw) =>
        raw.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
    final header = IvSheetParsers.splitLine(lines.first).map(norm).toList();
    final iSymbol = header.contains('symbol')
        ? header.indexOf('symbol')
        : header.indexOf('ticker');
    final iIv = header.indexOf('iv');
    if (iSymbol < 0 || iIv < 0) return base;

    final bySymbol = <String, IvSheetRow>{};
    for (var i = 1; i < lines.length; i++) {
      final parts = IvSheetParsers.splitLine(lines[i]);
      if (parts.length <= iIv || parts.length <= iSymbol) continue;
      final symbol = parts[iSymbol].trim().toUpperCase();
      final raw = parts[iIv].trim().replaceAll('%', '');
      final iv = double.tryParse(raw);
      if (symbol.isEmpty) continue;
      // 0–300% ka sane range; bahar wali value ko "data nahi" maana jaata hai.
      if (iv == null || iv <= 0 || iv > 300) continue;
      final existing = bySymbol[symbol];
      bySymbol[symbol] = IvSheetRow(
        ivp: existing?.ivp,
        ivr: existing?.ivr,
        iv: iv,
      );
    }
    // IV-only rows ko base ke saath merge karo (IVP/IVR base se).
    for (final entry in base.bySymbol.entries) {
      final own = bySymbol[entry.key];
      bySymbol[entry.key] = IvSheetRow(
        ivp: own?.ivp ?? entry.value.ivp,
        ivr: own?.ivr ?? entry.value.ivr,
        iv: own?.iv ?? entry.value.iv,
      );
    }
    return (bySymbol: bySymbol, asOf: base.asOf);
  }
}

/// Apna IV snapshot store — **sirf din me ek baar** likhta hai.
///
/// Ye "past IV" ka honest rasta hai: jab aaj scan chala, tab ke ATM IV save
/// ho gaye; kal wahi kal ka base ban jaate hain. Isse pehle ka data kisi ke
/// paas nahi tha — isliye pehle din "kal" khaali rahega aur screen wahi likhegi.
class IvSnapshotStore {
  IvSnapshotStore(this._settings);

  final SettingsDao _settings;

  static const String key = 'iv_spike_snapshot';

  /// `day → (symbol → iv)` — 60 din tak.
  Future<Map<String, Map<String, double>>> load() async {
    try {
      final raw = await _settings.raw();
      final text = raw[key];
      if (text == null || text.isEmpty) return {};
      final decoded = jsonDecode(text);
      if (decoded is! Map) return {};
      final out = <String, Map<String, double>>{};
      decoded.forEach((day, value) {
        if (value is! Map) return;
        out['$day'] = {
          for (final e in value.entries)
            if (e.value is num) '${e.key}': (e.value as num).toDouble(),
        };
      });
      return out;
    } catch (_) {
      return {};
    }
  }

  /// Aaj ka snapshot save karo (purane din overwrite nahi hote).
  Future<void> save(DateTime day, Map<String, double> values) async {
    if (values.isEmpty) return;
    try {
      final all = await load();
      all[_dayKey(day)] = values;
      // 60 din se purane hata do (storage saaf).
      final keys = all.keys.toList()..sort();
      while (keys.length > 60) {
        all.remove(keys.removeAt(0));
      }
      await _settings.put(key, jsonEncode(all));
    } catch (_) {
      // Snapshot optional — fail ho to scan nahi rukta.
    }
  }

  /// Sabse **taaza pichhla** din jo [today] se pehle ka ho.
  Future<({Map<String, double> values, DateTime day})?> previousBefore(
    DateTime today,
  ) async {
    final all = await load();
    final todayKey = _dayKey(today);
    final keys = all.keys.where((k) => k.compareTo(todayKey) < 0).toList()
      ..sort();
    if (keys.isEmpty) return null;
    final key = keys.last;
    final day = DateTime.tryParse(key);
    if (day == null) return null;
    return (values: all[key]!, day: day);
  }

  static String _dayKey(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
}
