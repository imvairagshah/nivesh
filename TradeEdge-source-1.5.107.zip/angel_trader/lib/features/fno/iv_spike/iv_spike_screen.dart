// ---------------------------------------------------------------------------
// iv_spike_screen.dart — "IV Spike" (1.5.105).
//
// User ki demand exactly ye thi: "jis stock ki aaj ki IV kal ki IV se spike
// ho, wo list, simple table me — stock ka naam, kal ka IV, aaj ka IV, IVP,
// IVR."
//
// Isliye screen jaan-boojh kar simple hai: ek hi table, 6 columns, aur
// upar chhoti si source line (kal ka IV kahan se aaya, aaj ka kahan se).
// Jo data nahi hai, wo "—" hai — koi bana hua number nahi.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/edge_header.dart';
import '../../../core/widgets/page_scroll.dart';
import 'iv_spike_engine.dart';
import 'iv_spike_provider.dart';

class IvSpikeScreen extends StatefulWidget {
  const IvSpikeScreen({super.key, this.mode = IvChangeMode.spike});

  /// 1.5.106 — same screen do tiles ke liye: spike aur crush.
  final IvChangeMode mode;

  @override
  State<IvSpikeScreen> createState() => _IvSpikeScreenState();
}

class _IvSpikeScreenState extends State<IvSpikeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final p = context.read<IvSpikeProvider>();
      p.mode = widget.mode;
      if (p.status == IvSpikeStatus.ready) {
        p.rebuild(); // dusre mode ke screen par aane par wahi data se list
      } else if (p.status == IvSpikeStatus.idle) {
        // 1.5.107 — pehle cache dekho (turant kuch dikhe), fresh scan user ke
        // Scan dabane par. Cache khaali ho to pehli baar khud scan chalta hai
        // (warna screen khaali reh jaati).
        p.bootstrap().then((_) {
          if (!mounted) return;
          if (p.status == IvSpikeStatus.idle) p.run();
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final p = context.watch<IvSpikeProvider>();
    final scheme = Theme.of(context).colorScheme;
    final result = p.result;

    return Scaffold(
      appBar: EdgeAppBar(
        title: p.mode.title,
        subtitle: '${p.mode.subtitle} · % change me',
        actions: [
          IconButton(
            tooltip: 'Refresh',
            icon: const Icon(Icons.refresh_rounded),
            onPressed: p.running ? null : p.run,
          ),
        ],
      ),
      body: PageScroll.children([
        if (p.running) _Progress(p: p),
        if (p.error != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Text(
              p.error!,
              style: TextStyle(fontSize: 11.5, color: scheme.error),
            ),
          ),
        _SourceLine(p: p),
        const SizedBox(height: 10),
        if (result != null) ...[
          _ModeSwitch(p: p),
          const SizedBox(height: 8),
          _Summary(p: p),
          const SizedBox(height: 10),
          _Table(rows: p.visibleRows, provider: p),
          const SizedBox(height: 14),
          if (result.missing.isNotEmpty) _MissingList(result: result),
        ] else if (!p.running)
          _Empty(onRun: p.run, sheetError: p.sheetError),
        const SizedBox(height: 12),
        Text(
          'IV = ATM CE/PE ka average implied volatility. Aaj ka IV broker '
          '(Angel greeks) se, na mile to premium se Black-Scholes — har row par '
          'source dikhta hai. Kal ka IV Google Sheet ke `iv` column se; column '
          'na ho to app ke pichhle scan se (din-wise snapshot). Missing values '
          '"—" rehti hain, kabhi bhar nahi jaati.',
          style: TextStyle(
            fontSize: 9.5,
            height: 1.5,
            color: scheme.onSurfaceVariant,
          ),
        ),
      ], padding: const EdgeInsets.fromLTRB(16, 10, 16, 26)),
    );
  }
}

class _Progress extends StatelessWidget {
  const _Progress({required this.p});

  final IvSpikeProvider p;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            p.progress ?? 'Chal raha hai…',
            style: TextStyle(
              fontSize: 11.5,
              fontWeight: FontWeight.w700,
              color: scheme.onSurface,
            ),
          ),
          const SizedBox(height: 8),
          LinearProgressIndicator(
            value: p.total == 0 ? null : (p.done / p.total).clamp(0, 1),
          ),
          const SizedBox(height: 6),
          Text(
            '213 stocks · 3 requests/sec se zyada nahi · pehli baar ~5–7 min',
            style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant),
          ),
        ],
      ),
    );
  }
}

class _SourceLine extends StatelessWidget {
  const _SourceLine({required this.p});

  final IvSpikeProvider p;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final r = p.result;
    final rows = <String>[
      if (p.sheetRows > 0)
        'Sheet: ${p.sheetRows} rows${p.sheetAsOf == null ? '' : ' · as of ${_d(p.sheetAsOf!)}'}'
      else if (p.sheetError != null)
        p.sheetError!
      else
        'Sheet: load nahi hui',
      if (r != null)
        'Kal ka IV: ${r.baselineFromSheet} sheet se · '
            '${r.baselineFromSnapshot} apna snapshot'
            '${p.baselineDay == null ? '' : ' (${_d(p.baselineDay!)})'}',
      if (p.cachedAsOf != null)
        'Ye pichhle scan ka result hai (${_d(p.cachedAsOf!)} ka) — aaj ka '
            'fresh data dekhne ke liye ↻ dabaiye.',
    ];

    return Container(
      padding: const EdgeInsets.all(11),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          for (final line in rows)
            Padding(
              padding: const EdgeInsets.only(bottom: 3),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(
                    Icons.info_outline_rounded,
                    size: 13,
                    color: scheme.onSurfaceVariant,
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      line,
                      style: TextStyle(
                        fontSize: 10,
                        height: 1.45,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          const SizedBox(height: 4),
          TextButton.icon(
            onPressed: () => _editSheet(context, p),
            icon: const Icon(Icons.table_chart_rounded, size: 16),
            label: const Text('IV sheet link set / badlo'),
          ),
        ],
      ),
    );
  }

  /// Sheet link ka chhota dialog — save karke turant rescan.
  static Future<void> _editSheet(
    BuildContext context,
    IvSpikeProvider p,
  ) async {
    final controller = TextEditingController();
    final messenger = ScaffoldMessenger.of(context);
    final url = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Google Sheet link'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Sheet "Publish to web" (CSV) honi chahiye. Columns: '
              'symbol, ivp, ivr, aur IV Spike ke liye iv (aaj/kal ka IV %).',
              style: TextStyle(fontSize: 11, height: 1.5),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: controller,
              autofocus: true,
              decoration: const InputDecoration(
                hintText: 'https://docs.google.com/spreadsheets/d/…',
                border: OutlineInputBorder(),
                isDense: true,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, controller.text),
            child: const Text('Save'),
          ),
        ],
      ),
    );
    if (url == null) return;
    final problem = await p.saveSheetUrl(url);
    messenger.showSnackBar(
      SnackBar(
        content: Text(
          problem ?? 'Sheet link save ho gaya — scan chal raha hai',
        ),
      ),
    );
    if (problem == null) await p.run();
  }

  static String _d(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year % 100}';
}

class _Summary extends StatelessWidget {
  const _Summary({required this.p});

  final IvSpikeProvider p;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final r = p.result!;
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        _Pill(
          label: p.mode == IvChangeMode.spike ? 'Spike' : 'Crush',
          value: '${r.rows.length}',
          tone: p.mode == IvChangeMode.spike ? Brand.greenDeep : scheme.error,
        ),
        _Pill(label: 'Rows', value: '${r.rows.length}', tone: scheme.onSurface),
        _Pill(
          label: 'IV mile',
          value: '${r.todayCount}',
          tone: scheme.onSurface,
        ),
        _Pill(
          label: 'Data nahi',
          value: '${r.missing.length}',
          tone: scheme.onSurfaceVariant,
        ),
        const SizedBox(width: 4),
        ChoiceChip(
          label: const Text('Sirf movement wale'),
          selected: p.onlySpikes,
          onSelected: p.setOnlySpikes,
          labelStyle: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w700,
            color: p.onlySpikes
                ? scheme.onPrimaryContainer
                : scheme.onSurfaceVariant,
          ),
          selectedColor: scheme.primaryContainer,
          backgroundColor: scheme.surface,
          side: BorderSide(color: scheme.outlineVariant),
          showCheckmark: false,
        ),
      ],
    );
  }
}

class _Pill extends StatelessWidget {
  const _Pill({required this.label, required this.value, required this.tone});

  final String label;
  final String value;
  final Color tone;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            label,
            style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant),
          ),
          const SizedBox(width: 6),
          Text(
            value,
            style: TextStyle(
              fontSize: 12.5,
              fontWeight: FontWeight.w900,
              color: tone,
            ),
          ),
        ],
      ),
    );
  }
}

/// **Simple table** — user ne yahi maanga: naam, kal ka IV, aaj ka IV, IVP, IVR.
class _Table extends StatelessWidget {
  const _Table({required this.rows, required this.provider});

  final List<IvSpikeRow> rows;
  final IvSpikeProvider provider;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    if (rows.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: scheme.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: scheme.outlineVariant),
        ),
        child: Text(
          'Koi IV spike nahi mila. Kal ka IV ke bina spike nikalna possible '
          'nahi — Sheet me `iv` column daalo, ya ek din app ko chalne do (apna '
          'snapshot ban jaayega).',
          style: TextStyle(
            fontSize: 11,
            height: 1.5,
            color: scheme.onSurfaceVariant,
          ),
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
            decoration: BoxDecoration(
              color: scheme.surfaceContainerHigh,
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(14),
              ),
            ),
            child: const Row(
              children: [
                _H('Stock', flex: 16),
                _H('Kal IV', flex: 11),
                _H('Aaj IV', flex: 11),
                _H('Change %', flex: 12),
                _H('IVP', flex: 8),
                _H('IVR', flex: 8),
              ],
            ),
          ),
          for (var i = 0; i < rows.length; i++)
            _Row(row: rows[i], index: i, provider: provider),
          if (rows.length >= 60)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Text(
                'Top ${rows.length} rows dikhaye hain (bade spike pehle).',
                style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant),
              ),
            ),
        ],
      ),
    );
  }
}

class _H extends StatelessWidget {
  const _H(this.text, {required this.flex});

  final String text;
  final int flex;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: flex,
      child: Text(
        text,
        textAlign: TextAlign.right,
        style: TextStyle(
          fontSize: 9,
          fontWeight: FontWeight.w800,
          letterSpacing: 0.3,
          color: Theme.of(context).colorScheme.onSurfaceVariant,
        ),
      ),
    );
  }
}

class _Row extends StatelessWidget {
  const _Row({required this.row, required this.index, required this.provider});

  final IvSpikeRow row;
  final int index;
  final IvSpikeProvider provider;

  static String _iv(double? v) => v == null ? '—' : v.toStringAsFixed(1);

  static String _pct(double? v) => v == null ? '—' : v.toStringAsFixed(0);

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final change = row.change;
    final positive = (change ?? 0) > 0;
    final spikeColor = index.isEven
        ? scheme.surface
        : scheme.surfaceContainerLow;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
      decoration: BoxDecoration(
        color: spikeColor,
        border: Border(
          top: BorderSide(color: scheme.outlineVariant.withValues(alpha: 0.5)),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 16,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  row.symbol,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w800,
                    color: scheme.onSurface,
                  ),
                ),
                if (row.baseline == IvBaselineSource.snapshot)
                  Text(
                    'kal = apna snapshot',
                    style: TextStyle(
                      fontSize: 8,
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            flex: 11,
            child: Text(
              _iv(row.yesterdayIv),
              textAlign: TextAlign.right,
              style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
            ),
          ),
          Expanded(
            flex: 11,
            child: Text(
              _iv(row.todayIv),
              textAlign: TextAlign.right,
              style: TextStyle(
                fontSize: 11.5,
                fontWeight: FontWeight.w700,
                color: scheme.onSurface,
              ),
            ),
          ),
          Expanded(
            flex: 12,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  row.changePct == null
                      ? '—'
                      : '${positive ? '+' : ''}${row.changePct!.toStringAsFixed(1)}%',
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w900,
                    color: change == null
                        ? scheme.onSurfaceVariant
                        : positive
                        ? Brand.greenDeep
                        : scheme.error,
                  ),
                ),
                // Reference: percentage points (chhota, halka).
                if (change != null)
                  Text(
                    '${positive ? '+' : ''}${change.toStringAsFixed(1)}pp',
                    textAlign: TextAlign.right,
                    style: TextStyle(
                      fontSize: 8,
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            flex: 8,
            child: Text(
              _pct(row.ivp),
              textAlign: TextAlign.right,
              style: TextStyle(fontSize: 11, color: scheme.onSurface),
            ),
          ),
          Expanded(
            flex: 8,
            child: Text(
              _pct(row.ivr),
              textAlign: TextAlign.right,
              style: TextStyle(fontSize: 11, color: scheme.onSurface),
            ),
          ),
        ],
      ),
    );
  }
}

class _MissingList extends StatelessWidget {
  const _MissingList({required this.result});

  final IvSpikeResult result;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final entries = result.missing.entries.toList()
      ..sort((a, b) => a.key.compareTo(b.key));
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Jin stocks ka IV nahi mila (${entries.length}) — wajah ke saath',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w800,
              color: scheme.onSurface,
            ),
          ),
          const SizedBox(height: 6),
          for (final e in entries.take(30))
            Padding(
              padding: const EdgeInsets.only(bottom: 3),
              child: Text(
                '${e.key} — ${e.value}',
                style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant),
              ),
            ),
          if (entries.length > 30)
            Text(
              '… aur ${entries.length - 30}',
              style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant),
            ),
        ],
      ),
    );
  }
}

class _Empty extends StatelessWidget {
  const _Empty({required this.onRun, this.sheetError});

  final Future<void> Function() onRun;
  final String? sheetError;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Abhi koi scan nahi chala.',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w900,
              color: scheme.onSurface,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Scan chalao: 213 F&O stocks ka aaj ka ATM IV nikal kar kal ke IV se '
            'tulna hoga. ${sheetError ?? ''}',
            style: TextStyle(
              fontSize: 11,
              height: 1.5,
              color: scheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: onRun,
            icon: const Icon(Icons.play_arrow_rounded),
            label: const Text('Scan karo'),
          ),
        ],
      ),
    );
  }
}

/// Spike ↔ Crush toggle — dono screens ek hi provider par chalte hain, isliye
/// ek jagah se doosri list turant milti hai (data dobara fetch nahi).
class _ModeSwitch extends StatelessWidget {
  const _ModeSwitch({required this.p});

  final IvSpikeProvider p;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Row(
      children: [
        for (final mode in IvChangeMode.values)
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: ChoiceChip(
              label: Text(
                mode == IvChangeMode.spike ? 'IV Spike ↑' : 'IV Crush ↓',
              ),
              selected: p.mode == mode,
              onSelected: (_) => p.setMode(mode),
              labelStyle: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                color: p.mode == mode
                    ? scheme.onPrimaryContainer
                    : scheme.onSurfaceVariant,
              ),
              selectedColor: scheme.primaryContainer,
              backgroundColor: scheme.surface,
              side: BorderSide(color: scheme.outlineVariant),
              showCheckmark: false,
            ),
          ),
      ],
    );
  }
}
