// ---------------------------------------------------------------------------
// iv_spike_service.dart — "aaj ka IV" har F&O stock ke liye (1.5.105).
//
// Per stock (213 F&O names, broker cap 3 req/s ke andar):
//   1. Daily candles (cache-first, wahi `DailyBarsLoader`) → aaj ka close (spot).
//   2. Local option book se **ATM strike** (wahi `FnoContractDao.atmPair` jo
//      3-Month Study use karti hai) → CE+PE tokens.
//   3. Ek batched quote call (50 tokens/call) → dono legs ka LTP.
//   4. Broker option-greeks (1 call per stock) → ATM CE/PE ka IV.
//   5. Broker IV na mile → **Black-Scholes** premium se (wahi solver jo Bankex
//      me hai) — aur row par source "BS" likha jaata hai.
//
// Jahan kuch bhi na mile, row "—" ke saath jaati hai aur wajah note me aati
// hai. Koi number bana kar nahi dikhaya jaata.
// ---------------------------------------------------------------------------

import 'dart:math' as math;

import '../../../core/utils/parallel_pool.dart';
import '../../../data/local/dao/candle_dao.dart';
import '../../../data/local/dao/fno_contract_dao.dart';
import '../../../data/local/dao/scrip_dao.dart';
import '../../../data/remote/dto/candle.dart';
import '../../../data/remote/dto/quote.dart';
import '../../../data/remote/dto/scrip.dart';
import '../../../services/bars_delta.dart';
import '../../../services/candle_source.dart';
import '../../../services/daily_bars_loader.dart';
import '../../../services/study_market_data.dart';
import '../study/black_scholes.dart';
import 'iv_spike_engine.dart';

class IvSpikeProgress {
  const IvSpikeProgress({
    required this.done,
    required this.total,
    required this.current,
    this.stage = '',
  });

  final int done;
  final int total;
  final String current;
  final String stage;
}

class IvSpikeScanResult {
  const IvSpikeScanResult({
    required this.today,
    required this.failed,
    required this.scanned,
  });

  final Map<String, TodayIv> today;

  /// Symbol → wajah (candles/chain/quote fail).
  final Map<String, String> failed;
  final int scanned;
}

class IvSpikeService {
  IvSpikeService({
    required CandleSource source,
    required CandleDao candles,
    required ScripDao scrips,
    required FnoContractDao contracts,
    required StudyMarketData market,
    this.minimumBars = 30,
    this.lookbackDays = 90,
  }) : _source = source,
       _candles = candles,
       _scrips = scrips,
       _contracts = contracts,
       _market = market;

  final CandleSource _source;
  final CandleDao _candles;
  final ScripDao _scrips;
  final FnoContractDao _contracts;
  final StudyMarketData _market;
  final int minimumBars;
  final int lookbackDays;

  /// [symbols] = F&O universe ke plain tickers.
  Future<IvSpikeScanResult> scan({
    required List<String> symbols,
    required DateTime asOf,
    void Function(IvSpikeProgress)? onProgress,
    bool Function()? isCancelled,
  }) async {
    final today = <String, TodayIv>{};
    final failed = <String, String>{};
    final loader = DailyBarsLoader(
      source: _source,
      candles: _candles,
      minimumBars: minimumBars,
      lookbackDays: lookbackDays,
    );

    // ---- Phase 1: candles → spot + ATM pair (serial-ish, 3 concurrent) ----
    final spots = <String, ({Scrip scrip, double spot, AtmPair pair})>{};
    var done = 0;
    for (final symbol in symbols) {
      if (isCancelled?.call() ?? false) break;
      done++;
      onProgress?.call(
        IvSpikeProgress(
          done: done,
          total: symbols.length,
          current: symbol,
          stage: 'Candles + ATM strike',
        ),
      );
      try {
        final scrip = await _resolve(symbol);
        if (scrip == null) {
          failed[symbol] = 'scrip master me nahi mila';
          today[symbol] = TodayIv(
            symbol: symbol,
            note: 'scrip master me nahi mila',
          );
          continue;
        }
        final bars = await loader.barsFor(scrip, asOf);
        if (bars.bars.length < minimumBars) {
          failed[symbol] = 'candles kam (${bars.bars.length})';
          today[symbol] = TodayIv(
            symbol: symbol,
            note: 'candles kam (${bars.bars.length})',
          );
          continue;
        }
        final spot = bars.bars.last.close;
        final pair = await _contracts.atmPair(
          underlying: symbol,
          spot: spot,
          asOf: asOf,
        );
        if (pair == null || !pair.isComplete) {
          failed[symbol] = 'option book me is stock ka ATM nahi';
          today[symbol] = TodayIv(
            symbol: symbol,
            note: 'option book me ATM strike nahi (scrip master refresh?)',
          );
          continue;
        }
        spots[symbol] = (scrip: scrip, spot: spot, pair: pair);
      } catch (e) {
        failed[symbol] = '$e';
        today[symbol] = TodayIv(symbol: symbol, note: '$e');
      }
    }

    // ---- Phase 2: batched quotes for every leg (50 tokens per call) -------
    final legScrips = <Scrip>[
      for (final item in spots.values)
        for (final c in [item.pair.ce, item.pair.pe])
          if (c != null) c.asScrip(),
    ];
    final quotes = <String, MarketQuote>{};
    if (legScrips.isNotEmpty) {
      onProgress?.call(
        IvSpikeProgress(
          done: spots.length,
          total: symbols.length,
          current: '${legScrips.length} option quotes',
          stage: 'Premiums',
        ),
      );
      try {
        for (var i = 0; i < legScrips.length; i += 50) {
          if (isCancelled?.call() ?? false) break;
          final chunk = legScrips.sublist(
            i,
            math.min(i + 50, legScrips.length),
          );
          quotes.addAll(await _market.fetchQuotesFull(chunk));
        }
      } catch (e) {
        // Quotes fail → Black-Scholes possible nahi; broker IV abhi bhi try.
        failed['_quotes'] = '$e';
      }
    }

    // ---- Phase 3: IV per stock (broker first, else Black-Scholes) --------
    final entries = spots.entries.toList();
    await mapPool<
      MapEntry<String, ({Scrip scrip, double spot, AtmPair pair})>,
      void
    >(
      items: entries,
      concurrency: 3,
      isCancelled: isCancelled,
      action: (index, entry) async {
        final symbol = entry.key;
        final item = entry.value;
        final pair = item.pair;
        onProgress?.call(
          IvSpikeProgress(
            done: index + 1,
            total: entries.length,
            current: symbol,
            stage: 'ATM IV',
          ),
        );

        double? iv;
        var source = IvTodaySource.none;
        String note = '';

        // 1. Broker greeks (1 call per underlying + expiry).
        try {
          final batch = await _market.fetchOptionGreeks(
            underlying: pair.underlying,
            expiryLabel: pair.expiryLabel,
          );
          final ce = batch.ivFor(pair.strike, 'CE');
          final pe = batch.ivFor(pair.strike, 'PE');
          final values = [
            if (ce != null && ce > 0) ce,
            if (pe != null && pe > 0) pe,
          ];
          if (values.isNotEmpty) {
            iv = values.reduce((a, b) => a + b) / values.length;
            source = IvTodaySource.broker;
          }
        } catch (_) {
          // Neeche BS fallback.
        }

        // 2. Black-Scholes from real premiums.
        if (iv == null) {
          final dte = pair.expiryDate.difference(asOf).inDays;
          final ceQuote = pair.ce == null ? null : quotes[pair.ce!.token];
          final peQuote = pair.pe == null ? null : quotes[pair.pe!.token];
          final solved = <double>[];
          if (dte > 0) {
            for (final (type, quote) in [('CE', ceQuote), ('PE', peQuote)]) {
              final premium = quote?.ltp ?? 0;
              if (premium <= 0) continue;
              final result = impliedVolatility(
                type: type == 'CE' ? OptionType.call : OptionType.put,
                premium: premium,
                spot: item.spot,
                strike: pair.strike,
                daysToExpiry: dte,
              );
              if (result.isSolved && (result.iv ?? 0) > 0) {
                solved.add(result.iv! * 100);
              }
            }
          }
          if (solved.isNotEmpty) {
            iv = solved.reduce((a, b) => a + b) / solved.length;
            source = IvTodaySource.blackScholes;
          } else if (dte <= 0) {
            note = 'expiry day — IV meaningless';
          } else {
            note = 'broker IV nahi, premium se bhi solve nahi hua';
          }
        }

        today[symbol] = TodayIv(
          symbol: symbol,
          iv: iv,
          source: source,
          strike: pair.strike,
          expiryLabel: pair.expiryLabel,
          daysToExpiry: pair.expiryDate.difference(asOf).inDays,
          note: note,
        );
      },
    );

    return IvSpikeScanResult(
      today: today,
      failed: failed,
      scanned: symbols.length,
    );
  }

  Future<Scrip?> _resolve(String symbol) async {
    final direct = await _scrips.findBySymbol('$symbol-EQ', exchange: 'NSE');
    if (direct != null) return direct;
    return _scrips.findBySymbol(symbol, exchange: 'NSE');
  }
}

/// Bars ki day-key (snapshot ke liye) — `bars_delta.dart` ke helper par.
String ivDayKey(DateTime d) =>
    '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

/// Cache me pehle se maujood **aakhri** bar ka din — snapshot ki as-of date.
DateTime? lastBarDay(List<Candle> bars) =>
    bars.isEmpty ? null : barDay(bars.last);
