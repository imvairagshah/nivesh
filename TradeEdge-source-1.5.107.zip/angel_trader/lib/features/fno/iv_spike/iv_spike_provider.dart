// ---------------------------------------------------------------------------
// iv_spike_provider.dart — IV Spike screen ka state (1.5.105).
//
// Flow:
//   1. Sheet padho (Settings ka IV sheet — IVP/IVR aur, agar column ho, IV).
//   2. Aaj ka ATM IV scan karo (broker greeks → Black-Scholes fallback).
//   3. Kal ka IV: Sheet ka `iv` column (agar hai) — warna apna pichhla
//      snapshot (din-wise). Source table me label ke saath.
//   4. Engine rows banata hai (spike wale pehle), aur snapshot aaj ke liye
//      save ho jaata hai — kal ye hi "kal ka IV" banega.
// ---------------------------------------------------------------------------

import 'package:flutter/foundation.dart';

import '../../../data/local/dao/scan_cache_dao.dart';
import '../../../data/local/dao/settings_dao.dart';
import '../../../services/fno_universe.dart';
import '../study/iv_sheet.dart';
import 'iv_result_cache.dart';
import 'iv_spike_engine.dart';
import 'iv_spike_service.dart';

enum IvSpikeStatus { idle, running, ready, error }

class IvSpikeProvider extends ChangeNotifier {
  IvSpikeProvider({
    required IvSpikeService service,
    required SettingsDao settings,
    ScanCacheDao? cache,
    DateTime Function()? clock,
  }) : _service = service,
       _settings = settings,
       _cache = cache == null ? null : IvResultCache(cache),
       _clock = clock ?? DateTime.now,
       _snapshots = IvSnapshotStore(settings);

  final IvSpikeService _service;
  final SettingsDao _settings;
  final DateTime Function() _clock;
  final IvSnapshotStore _snapshots;

  /// 1.5.107 — scan output ka cache (screen turant purana result dikhaye).
  final IvResultCache? _cache;

  IvSpikeStatus status = IvSpikeStatus.idle;
  String? error;
  String? progress;
  int done = 0;
  int total = 0;

  IvSpikeResult? result;
  Map<String, IvSheetRow> sheet = const {};
  String? sheetError;
  int sheetRows = 0;
  DateTime? sheetAsOf;

  /// Kal ka baseline kaunsa din tha (snapshot route).
  DateTime? baselineDay;

  /// 1.5.106 — spike ya crush (dono same engine, ulti list).
  IvChangeMode mode = IvChangeMode.spike;

  /// Minimum **|change %|** (kal ke IV ke hisaab se). 0 = koi bhi movement.
  double minChangePct = 0;

  /// Filter: sirf spike/crush wale (default) ya sab.
  bool onlySpikes = true;

  /// Aakhri scan ka raw aaj-ka data (mode/threshold badalne par reuse).
  Map<String, TodayIv> lastToday = const {};
  ({Map<String, double> values, DateTime day})? _lastSnapshot;

  /// Pichhle scan ka din — jab result cache se paint hua ho (label ke liye).
  DateTime? cachedAsOf;

  /// Result cache se aaya hai (Scan dabane se pehle).
  bool get fromCache => cachedAsOf != null;

  bool get running => status == IvSpikeStatus.running;

  Future<void> run() async {
    if (running) return;
    status = IvSpikeStatus.running;
    error = null;
    result = null;
    cachedAsOf = null;
    _cachedDay = null;
    done = 0;
    total = 0;
    progress = 'Google Sheet padh raha hai…';
    notifyListeners();

    final today = _day(_clock());
    try {
      await _loadSheet();

      final universe = await FnoUniverse.load();
      total = universe.symbols.length;
      progress = '${universe.length} F&O stocks ka ATM IV…';
      notifyListeners();

      final scan = await _service.scan(
        symbols: universe.symbols,
        asOf: today,
        onProgress: (p) {
          done = p.done;
          total = p.total;
          progress = '${p.stage} · ${p.current} (${p.done}/${p.total})';
          notifyListeners();
        },
      );

      final previous = await _snapshots.previousBefore(today);
      baselineDay = previous?.day;
      lastToday = scan.today;
      _lastSnapshot = previous;

      result = IvSpikeEngine.build(
        today: scan.today,
        sheet: sheet,
        snapshot: previous?.values ?? const {},
        snapshotAsOf: previous?.day,
        asOf: today,
        mode: mode,
        minChangePct: minChangePct,
      );

      // Aaj ke IV snapshot me daalo (kal ka base banega).
      await _snapshots.save(today, {
        for (final e in scan.today.entries)
          if (e.value.hasIv) e.key: e.value.iv!,
      });

      cachedAsOf = null;
      await _cache?.save(asOf: today, today: scan.today);

      status = IvSpikeStatus.ready;
      progress = 'Ho gaya · ${result!.rows.length} rows';
      notifyListeners();
    } catch (e) {
      status = IvSpikeStatus.error;
      error = '$e';
      notifyListeners();
    }
  }

  /// Screen kholte hi pichhla result paint karo (network ke bina).
  ///
  /// 1.5.107 — pehle screen kholne par 213 stocks ka poora scan shuru ho jaata
  /// tha. Ab: cache ho to turant wo dikhta hai (upar "scan ka din" likha
  /// jaata hai) aur fresh data sirf tab aata hai jab user Scan dabaye.
  Future<void> bootstrap() async {
    if (running) return;
    final cached = await _cache?.load();
    if (cached == null || cached.today.isEmpty) return;
    final day = cached.asOf ?? _day(_clock());
    _cachedDay = day;
    await _loadSheet();
    final previous = await _snapshots.previousBefore(day);
    baselineDay = previous?.day;
    lastToday = cached.today;
    _lastSnapshot = previous;
    result = _buildRows(day);
    if (result == null) {
      // Sheet/snapshot ke bagair kuch row bhi nahi — bilkul khaali table
      // dikhane se behtar hai normal scan shuru karna.
      _cachedDay = null;
      return;
    }
    cachedAsOf = day;
    status = IvSpikeStatus.ready;
    progress = 'Cache se · ${_dmy(day)} ka scan';
    notifyListeners();
  }

  static String _dmy(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')} ${_months[d.month - 1]} ${d.year}';

  static const List<String> _months = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
  ];

  Future<void> _loadSheet() async {
    sheetError = null;
    try {
      final map = await _settings.raw();
      final url = map[IvSheetStore.urlKey];
      if (url == null || url.trim().isEmpty) {
        sheet = const {};
        sheetRows = 0;
        sheetError =
            'IV sheet set nahi hai — Settings me Google Sheet link daalo '
            '(kal ka IV isi se aata hai).';
        return;
      }
      final store = IvSheetStore();
      final ok = await store.refresh(url);
      if (!ok) {
        sheet = const {};
        sheetRows = 0;
        sheetError = store.error ?? 'Sheet fetch fail';
        return;
      }
      sheet = store.bySymbol;
      sheetRows = store.bySymbol.length;
      sheetAsOf = store.asOf;
    } catch (e) {
      sheet = const {};
      sheetError = '$e';
    }
  }

  /// Table ke liye rows (filter + threshold).
  List<IvSpikeRow> get visibleRows {
    final r = result;
    if (r == null) return const [];
    if (!onlySpikes) return r.rows;
    return r.rows
        .where((row) => row.change == null ? row.ivp != null : true)
        .toList();
  }

  /// Sheet link Settings me save karo (wahi key jo Settings screen use karti
  /// hai) — phir dobara scan chalao.
  Future<String?> saveSheetUrl(String raw) async {
    final normalized = IvSheetParsers.normalizeUrl(raw);
    if (normalized == null) {
      return 'Google Sheets link sahi nahi lag raha (docs.google.com/spreadsheets/… chahiye).';
    }
    await _settings.put(IvSheetStore.urlKey, raw.trim());
    return null;
  }

  /// Threshold % badla → dobara build (data dobara fetch kiye bina).
  void setMinChangePct(double value) {
    minChangePct = value;
    rebuild();
  }

  /// Mode badla → same data par ulti list (spike ↔ crush).
  void setMode(IvChangeMode next) {
    if (mode == next) return;
    mode = next;
    rebuild();
  }

  /// Pichhle **scan ka din** (jab result cache se aaya ho; fresh scan par
  /// null). `rebuild()` isi din par hisaab karta hai — warna cache se aaya
  /// result "aaj ka" ban kar jhooth bol deta.
  DateTime? _cachedDay;

  IvSpikeResult? _buildRows(DateTime day) {
    if (lastToday.isEmpty) return null;
    final built = IvSpikeEngine.build(
      today: lastToday,
      sheet: sheet,
      snapshot: _lastSnapshot?.values ?? const {},
      snapshotAsOf: _lastSnapshot?.day,
      asOf: day,
      mode: mode,
      minChangePct: minChangePct,
    );
    // Cache-replay me koi bhi row ke paas dono IV nahi hain to list khaali
    // dikhegi — tab fresh scan hi sahi jawab hai.
    return built.rows.isEmpty ? null : built;
  }

  /// Data wahi, sirf engine dobara (mode/threshold ke liye).
  void rebuild() {
    final built = _buildRows(_cachedDay ?? _day(_clock()));
    if (built == null) return;
    result = built;
    notifyListeners();
  }

  void setOnlySpikes(bool value) {
    onlySpikes = value;
    notifyListeners();
  }

  static DateTime _day(DateTime d) => DateTime(d.year, d.month, d.day);
}
