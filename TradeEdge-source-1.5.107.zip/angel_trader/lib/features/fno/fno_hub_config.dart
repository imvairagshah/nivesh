// ---------------------------------------------------------------------------
// fno_hub_config.dart — "kaun sa tool kis section me" ka ek hi sach.
//
// 1.5.96: hub ab **icon grid** hai (design "B" · Paper Light) — section
// heading ke neeche 2-column tiles. Tiles ka order wahi `fno_hub_order` key se
// aata hai; user long-press karke tile ko doosri jagah drop kar sakta hai.
//
// Order ka format: {"study": ["study", "adv"], "index": ["bankex"], ...}
// Naya tool add karo to purane saved order me wo automatically apne section ke
// aakhir me aa jaata hai (mergeHubOrder) — user ka order kharab nahi hota.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';

/// Hub ke chaar section — order yahi rehta hai, andar ke tools user set karta hai.
enum HubSection {
  // 1.5.100: light accent badge ke tinted chip par baithta hai (accent 12%),
  // to accent ko chip ke hisaab se 4.5:1+ hona chahiye — isliye light tones
  // thode gehre hain (pehle study 3.03:1, calendar 2.95:1 the).
  study('study', 'SCREENER & STUDY', Color(0xFF0B7A4E), Color(0xFF4ADE9B)),
  strategies('index', 'INDEX STRATEGIES', Color(0xFF0E7490), Color(0xFF5FD3E8)),
  options('options', 'OPTIONS DATA', Color(0xFF6D28D9), Color(0xFFC4B5FD)),
  calendar('calendar', 'CALENDAR & AI', Color(0xFF7A5312), Color(0xFFF3C15C));

  const HubSection(this.id, this.label, this.light, this.dark);

  final String id;
  final String label;

  /// Light background par accent (badge text, icon, dot).
  final Color light;

  /// Dark background par wahi accent — 1.5.99: purane gehare tones dark
  /// surface par 2:1 se bhi kam contrast dete the (user: "kuch dikh nahi
  /// raha"). Ye shades dark par 4.5:1+ dete hain.
  final Color dark;

  /// Theme ke hisaab se accent.
  Color colorOf(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark ? dark : light;
}

/// Ek tool ka poora description — icon, ek line, badge, section.
class HubTool {
  const HubTool({
    required this.id,
    required this.title,
    required this.blurb,
    required this.icon,
    required this.section,
    this.badge,
  });

  final String id;
  final String title;

  /// Ek hi line — compact row (1.5.93 decision: "sirf naam + 1 line").
  final String blurb;
  final IconData icon;
  final HubSection section;

  /// 'LIVE' / 'NEW' / 'NAYA' — null = koi badge nahi.
  final String? badge;
}

/// Hub ke saare tools. Naya tool yahin add karo — screen khud dikha degi.
const List<HubTool> kHubTools = [
  HubTool(
    id: 'study',
    title: '3-Month Study',
    blurb: 'Trend, ATR, 3M high/low se doori, ATM IV aur edge',
    icon: Icons.query_stats_rounded,
    section: HubSection.study,
    badge: 'LIVE',
  ),
  HubTool(
    id: 'adv',
    title: '3-Month Study · Advance Filter',
    blurb: 'Wahi study, sudhare hue niyam + score (Best Buy / Watch)',
    icon: Icons.filter_alt_rounded,
    section: HubSection.study,
    badge: 'NAYA',
  ),
  // 1.5.101 — user: "Magic Formula ke sath F&O scanner bhi tha, uski link
  // kaha hai?" Sach me wo screen kisi tile se bandhi hi nahi thi (sirf
  // Magic Formula ke andar chhupi thi). Ab apna tile — F&O ka hi tool hai,
  // isliye SCREENER & STUDY section me.
  HubTool(
    id: 'fno_scanner',
    title: 'F&O Scanner',
    blurb: 'Top gainers/losers, OI change, narrow CPR, volume ×2 + trade plan',
    icon: Icons.radar_rounded,
    section: HubSection.study,
    badge: 'NAYA',
  ),
  HubTool(
    id: 'bankex',
    title: 'Bankex–Bank Nifty Strategies',
    blurb: 'Regime detection + 6 defined-risk spread strategies',
    icon: Icons.account_balance_rounded,
    section: HubSection.strategies,
    badge: 'NEW',
  ),
  HubTool(
    id: 'stock_oi',
    title: 'Stock OI Build–Unwind',
    blurb: 'Aaj kis strike par badi position bani ya windup hui',
    icon: Icons.bar_chart_rounded,
    section: HubSection.options,
    badge: 'NAYA',
  ),
  // 1.5.105 — user: "aaj ki IV kal ki IV se spike ho, wo list simple table me"
  HubTool(
    id: 'iv_spike',
    title: 'IV Spike',
    blurb: 'Aaj ka ATM IV vs kal ka IV — spike wale stocks, IVP/IVR ke saath',
    icon: Icons.bolt_rounded,
    section: HubSection.options,
    badge: 'NAYA',
  ),
  // 1.5.106 — IV Spike ka jodi: IV Crush (sabse tez girawat wale).
  HubTool(
    id: 'iv_crush',
    title: 'IV Crush',
    blurb: 'Aaj ka ATM IV kal se sabse zyada gira — %, IVP/IVR ke saath',
    icon: Icons.trending_down_rounded,
    section: HubSection.options,
    badge: 'NAYA',
  ),
  HubTool(
    id: 'extremes',
    title: '52W · ATH · Dividend',
    blurb: '52W high/low se doori, all-time high, aane wale dividend',
    icon: Icons.show_chart_rounded,
    section: HubSection.options,
    badge: 'NAYA',
  ),
  HubTool(
    id: 'results',
    title: 'Results Calendar',
    blurb: 'Kis stock ke results kab — F&O universe',
    icon: Icons.event_rounded,
    section: HubSection.calendar,
    badge: 'LIVE',
  ),
  HubTool(
    id: 'ai',
    title: 'AI Suggestion',
    blurb: 'Rule-based idea + entry/exit levels',
    icon: Icons.auto_awesome_rounded,
    section: HubSection.calendar,
    badge: 'LIVE',
  ),
  // 1.5.96 — News ab hub par apna tile hai (pehle sirf 3-Month Study ke andar
  // ek button tha). Wahi screen, seedha rasta.
  HubTool(
    id: 'news',
    title: 'News',
    blurb: 'NSE announcements + market feeds',
    icon: Icons.article_rounded,
    section: HubSection.calendar,
  ),
];

/// Tool id se tool dhoondo (unknown id → null).
HubTool? hubToolById(String id) {
  for (final tool in kHubTools) {
    if (tool.id == id) return tool;
  }
  return null;
}

/// Default order: section-wise, config ki tarteeb me.
Map<String, List<String>> defaultHubOrder() {
  final map = <String, List<String>>{
    for (final section in HubSection.values) section.id: <String>[],
  };
  for (final tool in kHubTools) {
    map[tool.section.id]!.add(tool.id);
  }
  return map;
}

/// Saved JSON ko default ke saath merge karta hai.
///
/// - saved me jo ids hain aur config me bhi hain → usi tarteeb me
/// - naye tools (saved me nahi) → apne section ke aakhir me
/// - hataye gaye tools (config me nahi) → chhod do
/// - kharab/adhoora JSON → default order (crash nahi)
Map<String, List<String>> mergeHubOrder(Object? saved) {
  final defaults = defaultHubOrder();
  if (saved is! Map) return defaults;

  final known = {for (final tool in kHubTools) tool.id: tool};
  final merged = <String, List<String>>{
    for (final section in HubSection.values) section.id: <String>[],
  };

  // 1) saved tarteeb, par sirf wahi tools jo abhi bhi usi section me hain.
  for (final section in HubSection.values) {
    final raw = saved[section.id];
    if (raw is! List) continue;
    for (final entry in raw) {
      final id = '$entry';
      final tool = known[id];
      if (tool == null) continue;
      if (tool.section != section) continue; // section badla → naya section
      if (merged[section.id]!.contains(id)) continue; // duplicate
      merged[section.id]!.add(id);
    }
  }

  // 2) jo reh gaye (naye tools) → apne section ke aakhir me.
  for (final tool in kHubTools) {
    final bucket = merged[tool.section.id]!;
    if (!bucket.contains(tool.id)) bucket.add(tool.id);
  }
  return merged;
}

/// Order ko JSON-friendly map me badlo (sirf ids).
Map<String, List<String>> hubOrderToJson(Map<String, List<String>> order) => {
  for (final entry in order.entries)
    if (entry.value.isNotEmpty) entry.key: List<String>.from(entry.value),
};

/// Ek id ko section ke andar naye index par le jao (drag-drop ka core).
///
/// `toIndex` wahi semantics rakhta hai jo ReorderableListView ka hota hai:
/// item ko hatane ke baad wali position. Index bounds me clamp hota hai,
/// unknown id par list waisi hi return hoti hai.
List<String> moveInSection(List<String> ids, String movingId, int toIndex) {
  final from = ids.indexOf(movingId);
  if (from < 0) return List<String>.from(ids);
  final next = List<String>.from(ids)..removeAt(from);
  final target = toIndex.clamp(0, next.length);
  next.insert(target, movingId);
  return next;
}
