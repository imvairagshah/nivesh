// ---------------------------------------------------------------------------
// brand.dart — TRADE EDGE ka logo aur wordmark (1.5.96).
//
// Mark ab **asset** hai (`assets/brand/trade_edge_mark.png`) — user ka apna
// banaya hua "TE + arrow" monogram, background se cut out kiya hua. Pehle mark
// code se paint hota tha; wo painter yahan se hata diya gaya hai kyunki ab
// brand ek fixed image hai, aur image hi user ne di hai.
//
// Teen sizes har jagah kaam karti hain: splash (200+), app bar (26–46),
// watermark (120). PNG 4x par upscaled hai, isliye 1024 launcher icon tak
// sharp rehta hai.
// ---------------------------------------------------------------------------

import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

/// The mark itself. `size` = width in logical pixels; height apne aap.
///
/// [plate] true karne par mark ek soft white plate par baithta hai — dark
/// theme me navy strokes kaat-te hain, isliye wahan plate default hai.
class BrandMark extends StatelessWidget {
  const BrandMark({
    super.key,
    this.size = 36,
    this.plate = false,
    this.plateRadius,
  });

  /// Width of the mark.
  final double size;

  /// White plate ke andar rakho (dark theme / busy background).
  final bool plate;

  /// Plate ka corner radius; null = `size * 0.28`.
  final double? plateRadius;

  /// Aspect ratio of `trade_edge_mark.png` (992 × 680).
  static const double aspect = 680 / 992;

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final onPlate = plate || dark;
    final mark = Image.asset(
      'assets/brand/trade_edge_mark.png',
      width: size,
      height: size * aspect,
      filterQuality: FilterQuality.medium,
      // Screen reader ke liye: yeh ek logo hai, decorative image nahi.
      semanticLabel: '${Brand.name} logo',
      // Asset na mile (kabhi nahi hona chahiye) to app crash na kare — bas
      // naam dikh jaye.
      errorBuilder: (_, __, ___) => SizedBox(
        width: size,
        height: size * aspect,
        child: Center(
          child: Text(
            'TE',
            style: TextStyle(
              fontSize: size * 0.42,
              fontWeight: FontWeight.w900,
              color: Brand.navy,
            ),
          ),
        ),
      ),
    );

    if (!onPlate) return mark;

    final pad = size * 0.16;
    return Container(
      padding: EdgeInsets.all(pad),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(plateRadius ?? size * 0.28),
        // Plate khud white hai, isliye dark mode me halka shadow.
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: dark ? 0.35 : 0.05),
            blurRadius: size * 0.35,
            offset: Offset(0, size * 0.12),
          ),
        ],
      ),
      child: mark,
    );
  }
}

/// Fade + scale entrance for the splash — the app's one piece of ceremony.
class AnimatedBrandMark extends StatefulWidget {
  const AnimatedBrandMark({
    super.key,
    this.size = 96,
    this.delay = const Duration(milliseconds: 150),
    this.plate = false,
  });

  final double size;
  final Duration delay;
  final bool plate;

  @override
  State<AnimatedBrandMark> createState() => _AnimatedBrandMarkState();
}

class _AnimatedBrandMarkState extends State<AnimatedBrandMark>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 700),
  );
  late final Animation<double> _curve = CurvedAnimation(
    parent: _controller,
    curve: Curves.easeOutCubic,
  );

  @override
  void initState() {
    super.initState();
    Future<void>.delayed(widget.delay, () {
      if (mounted) _controller.forward();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _curve,
      builder: (context, child) => Opacity(
        opacity: _curve.value.clamp(0.0, 1.0),
        child: Transform.scale(scale: 0.88 + 0.12 * _curve.value, child: child),
      ),
      child: BrandMark(size: widget.size, plate: widget.plate),
    );
  }
}

/// Mark + two-tone wordmark (+ optional tagline). [axis] switches between the
/// app-bar layout (mark left of the text) and the splash layout (stacked).
class BrandLogo extends StatelessWidget {
  const BrandLogo({
    super.key,
    this.markSize = 36,
    this.axis = Axis.horizontal,
    this.showTagline = false,
    this.alignment = CrossAxisAlignment.start,
    this.textAlign = TextAlign.start,
  });

  /// Side of the mark; the wordmark scales with it.
  final double markSize;
  final Axis axis;
  final bool showTagline;
  final CrossAxisAlignment alignment;
  final TextAlign textAlign;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final fontSize = markSize * 0.50;

    final wordmark = BrandWordmark(fontSize: fontSize, textAlign: textAlign);

    final text = Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: alignment,
      children: [
        wordmark,
        if (showTagline) ...[
          SizedBox(height: markSize * 0.10),
          Text(
            Brand.tagline,
            textAlign: textAlign,
            style: TextStyle(
              fontSize: math.max(8.5, markSize * 0.145),
              fontWeight: FontWeight.w700,
              letterSpacing: 1.4,
              color: scheme.onSurfaceVariant,
            ),
          ),
        ],
      ],
    );

    if (axis == Axis.vertical) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: alignment == CrossAxisAlignment.start
            ? CrossAxisAlignment.center
            : alignment,
        children: [
          BrandMark(size: markSize),
          SizedBox(height: markSize * 0.30),
          text,
        ],
      );
    }

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        BrandMark(size: markSize),
        SizedBox(width: markSize * 0.30),
        Flexible(child: text),
      ],
    );
  }
}

/// Just the two-tone wordmark: navy "TRADE" + green "EDGE". Sizes with
/// [fontSize] so callers can pair it with any mark size.
class BrandWordmark extends StatelessWidget {
  const BrandWordmark({
    super.key,
    this.fontSize = 20,
    this.textAlign = TextAlign.start,
    this.onDark = false,
  });

  final double fontSize;
  final TextAlign textAlign;

  /// Dark surface par "TRADE" white ho jaata hai (navy par navy nahi).
  final bool onDark;

  @override
  Widget build(BuildContext context) {
    return Text.rich(
      TextSpan(
        children: [
          TextSpan(
            text: '${Brand.namePrefix} ',
            style: TextStyle(
              color: onDark
                  ? Colors.white
                  : (Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Brand.navy),
              fontWeight: FontWeight.w900,
              letterSpacing: fontSize * 0.12,
            ),
          ),
          TextSpan(
            text: Brand.nameSuffix,
            style: TextStyle(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Brand.greenBright
                  : Brand.green,
              fontWeight: FontWeight.w900,
              letterSpacing: fontSize * 0.12,
            ),
          ),
        ],
      ),
      textAlign: textAlign,
      style: TextStyle(fontSize: fontSize, height: 1.05),
    );
  }
}

/// A very faint mark used behind empty states — brand presence without noise.
class BrandWatermark extends StatelessWidget {
  const BrandWatermark({super.key, this.size = 120, this.opacity = 0.06});

  final double size;
  final double opacity;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Opacity(
        opacity: opacity,
        child: BrandMark(size: size),
      ),
    );
  }
}
