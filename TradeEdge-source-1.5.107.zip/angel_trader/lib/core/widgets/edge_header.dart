// ---------------------------------------------------------------------------
// edge_header.dart — TRADE EDGE ka ek hi header, har screen par (1.5.98).
//
// PROBLEM (user report): "Equity section me header nahi aa rahe kisi bhi
// option me". Wajah: IPO / Golden Cross / RSI / Paper Trading / Reports pehle
// HomeShell ke tabs the — unka apna AppBar hi nahi tha, header shell deta tha.
// 1.5.96 me bottom-nav hata to wo screens **bina header** khulne lagin: na
// back button, na naam — user ko pata hi nahi chalta tha kahan hai.
//
// FIX: yahan ek hi header widget. Har screen par:
//   • back button (rounded box, tap target 40),
//   • title + ek line ka subtitle (naam + "kya karta hai"),
//   • daayein chhota brand mark (pehchaan),
//   • optional actions.
//
// Rang index se aate hain (Theme), background paper hai — isliye light aur
// dark dono me text poora readable rehta hai (1.5.98 me ink colours bhi
// explicitly set hue hain, see app_theme.dart).
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import 'brand.dart';

/// Header — `AppBar` ka drop-in, par TRADE EDGE ke look me.
///
/// `preferImplyLeading: false` chahiye to [canPop] `false` karein (root
/// screens ke liye).
class EdgeAppBar extends StatelessWidget implements PreferredSizeWidget {
  const EdgeAppBar({
    super.key,
    required this.title,
    this.subtitle,
    this.actions = const [],
    this.showMark = true,
    this.canPop = true,
    this.onBack,
  });

  final String title;

  /// Ek line — "kya karta hai". Har tool screen par same jagah.
  final String? subtitle;
  final List<Widget> actions;

  /// Daayein brand mark dikhana hai?
  final bool showMark;

  /// Back button dikhana hai? (root par false)
  final bool canPop;

  /// Back ka custom action (default: Navigator.pop).
  final VoidCallback? onBack;

  @override
  Size get preferredSize => const Size.fromHeight(62);

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final canGoBack =
        canPop && (onBack != null || Navigator.of(context).canPop());

    return AppBar(
      toolbarHeight: preferredSize.height,
      backgroundColor: scheme.surfaceContainerLowest,
      surfaceTintColor: Colors.transparent,
      scrolledUnderElevation: 0,
      elevation: 0,
      automaticallyImplyLeading: false,
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: Container(height: 1, color: scheme.outlineVariant),
      ),
      leadingWidth: canGoBack ? 56 : 14,
      leading: canGoBack
          ? Padding(
              padding: const EdgeInsets.only(left: 10),
              child: Center(
                child: Material(
                  color: dark
                      ? Colors.white.withValues(alpha: 0.06)
                      : const Color(0xFFF2F6FB),
                  borderRadius: BorderRadius.circular(12),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: onBack ?? () => Navigator.of(context).maybePop(),
                    child: SizedBox(
                      width: 38,
                      height: 38,
                      child: Icon(
                        Icons.arrow_back_rounded,
                        size: 19,
                        color: scheme.onSurface,
                      ),
                    ),
                  ),
                ),
              ),
            )
          : null,
      titleSpacing: canGoBack ? 6 : 16,
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.w900,
              letterSpacing: -0.2,
              color: scheme.onSurface,
            ),
          ),
          if (subtitle != null) ...[
            const SizedBox(height: 2),
            Text(
              subtitle!,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 10.5,
                fontWeight: FontWeight.w600,
                color: scheme.onSurfaceVariant,
              ),
            ),
          ],
        ],
      ),
      actions: [
        ...actions,
        if (showMark)
          const Padding(
            padding: EdgeInsets.only(right: 14, left: 4),
            child: Center(child: BrandMark(size: 34)),
          ),
      ],
    );
  }
}

/// Scaffold + [EdgeAppBar] — naye screens ke liye ek hi entry point.
class EdgeScaffold extends StatelessWidget {
  const EdgeScaffold({
    super.key,
    required this.title,
    this.subtitle,
    required this.body,
    this.actions = const [],
    this.showMark = true,
    this.canPop = true,
    this.onBack,
    this.floatingActionButton,
    this.bottomNavigationBar,
  });

  final String title;
  final String? subtitle;
  final Widget body;
  final List<Widget> actions;
  final bool showMark;
  final bool canPop;
  final VoidCallback? onBack;
  final Widget? floatingActionButton;
  final Widget? bottomNavigationBar;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Brand.bgOf(context),
      appBar: EdgeAppBar(
        title: title,
        subtitle: subtitle,
        actions: actions,
        showMark: showMark,
        canPop: canPop,
        onBack: onBack,
      ),
      floatingActionButton: floatingActionButton,
      bottomNavigationBar: bottomNavigationBar,
      body: body,
    );
  }
}
