// ---------------------------------------------------------------------------
// parallel_pool.dart — 1.5.95 "scan speed" ka pehla tukda.
//
// Scans aaj ek-ek stock ka network call karte hain: har stock par ~350 ms
// rate-limiter gap + ~300 ms network latency **jud jaate hain**. Pool se 3-4
// calls ek saath "udte" hain — gap wahi rehta hai (broker ki 3 req/s limit
// kabhi cross nahi hoti, kyunki calls ApiClient ke RateLimiter se guzarti
// hain), par latency chhup jaati hai.
//
// Order **hamesha input ka** rehta hai (results[i] ↔ items[i]) — isliye scan
// ka output pehle jaisa hi dikhta hai, sirf jaldi aata hai.
// ---------------------------------------------------------------------------

import 'dart:async';

/// [items] par [concurrency] workers chalata hai; result input ke order me.
///
/// Cancel hone par jitne ho gaye utne return hote hain aur baaki slots `null`
/// rehti hain — caller `null` ko "process nahi hua" samjhe (aadha result kabhi
/// poora batakar nahi dikhaya jaata).
Future<List<R?>> mapPool<T, R>({
  required List<T> items,
  required int concurrency,
  required Future<R> Function(int index, T item) action,
  bool Function()? isCancelled,
}) async {
  final out = List<R?>.filled(items.length, null);
  if (items.isEmpty) return out;

  final workers = concurrency.clamp(1, items.length);
  var next = 0;

  Future<void> worker() async {
    while (true) {
      if (isCancelled?.call() ?? false) return;
      final i = next++;
      if (i >= items.length) return;
      out[i] = await action(i, items[i]);
    }
  }

  await Future.wait([for (var i = 0; i < workers; i++) worker()]);
  return out;
}

/// Ek prefetch slot: ya value, ya woh error jisne use roka.
///
/// Pool ke andar throw hone par poora batch ud jaata; isliye error ko slot me
/// "le kar" chalte hain aur caller ke `try/catch` me [unwrap] se phenkte hain —
/// skip ka reason bilkul purane serial code jaisa rehta hai.
class FetchSlot<T> {
  const FetchSlot.ok(T this.value) : error = null;
  const FetchSlot.fail(Object this.error) : value = null;

  final T? value;
  final Object? error;

  /// Value deta hai, ya original error wapas throw karta hai.
  T unwrap() {
    final e = error;
    if (e != null) throw e;
    return value as T;
  }
}
