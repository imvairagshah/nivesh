// ---------------------------------------------------------------------------
// scan_cache_dao.dart — cached screener output + last-known prices.
//
// Two jobs:
//   * `scan_runs`  – the last result of each screener per trading day, so the
//                    app opens instantly and works with no network.
//   * `price_cache`– last LTP per symbol, so cards keep showing a price (clearly
//                    marked "cached") when the market feed is unavailable.
// ---------------------------------------------------------------------------

import 'dart:convert';

import 'package:sqflite/sqflite.dart';

import '../../../data/remote/dto/quote.dart';
import '../../../core/utils/markets.dart';
import '../app_database.dart';

/// Kind identifiers for [ScanCacheDao.saveRun].
class ScanKind {
  ScanKind._();
  static const String ipoProximity = 'ipo_proximity';
  static const String goldenCross = 'golden_cross';

  /// RSI extremes scan (Feature 4 — the RSI scanner tab).
  static const String rsi = 'rsi';

  /// 3-Month Study (F&O module) — trend + ATR + ATM option edge per stock.
  static const String fnoStudy = 'fno_study';

  /// IV Spike / IV Crush (1.5.105/106) — aaj ka ATM IV per F&O stock.
  ///
  /// 1.5.107 — pehle ye screen cache-less thi: app band karke kholne par 213
  /// stocks ka poora scan (greeks + quotes) dobara chalta tha.
  static const String ivSpike = 'iv_spike';

  /// Strategy Builder backtest (1.5.102) — strategy + stats + trades.
  static const String strategyBuilder = 'strategy_builder';

  /// Sab kinds — retention sweep aur Settings ke counter ke liye.
  static const List<String> all = [
    ipoProximity,
    goldenCross,
    rsi,
    fnoStudy,
    ivSpike,
    strategyBuilder,
  ];
}

class ScanRun {
  final String kind;
  final String asOf; // yyyy-MM-dd
  final List<Map<String, dynamic>> rows;
  final DateTime createdAt;

  const ScanRun({
    required this.kind,
    required this.asOf,
    required this.rows,
    required this.createdAt,
  });

  int get rowCount => rows.length;
}

class ScanCacheDao {
  ScanCacheDao(this._db);

  final AppDatabase _db;

  // -------------------------------------------------------------------------
  // Scanner output
  // -------------------------------------------------------------------------

  /// Persists a scan result, replacing any earlier run of the same kind/date.
  Future<void> saveRun({
    required String kind,
    required String asOf,
    required List<Map<String, dynamic>> rows,
  }) async {
    final db = await _db.database;
    await db.insert(AppDatabase.tableScanRuns, {
      'kind': kind,
      'as_of': asOf,
      'payload': jsonEncode(rows),
      'created_at': DateTime.now().millisecondsSinceEpoch,
    }, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  /// Latest run for [kind], or the run for [asOf] when supplied.
  Future<ScanRun?> latestRun(String kind, {String? asOf}) async {
    final db = await _db.database;
    final rows = await db.query(
      AppDatabase.tableScanRuns,
      where: asOf == null ? 'kind = ?' : 'kind = ? AND as_of = ?',
      whereArgs: asOf == null ? [kind] : [kind, asOf],
      orderBy: 'created_at DESC',
      limit: 1,
    );
    if (rows.isEmpty) return null;
    final row = rows.first;
    final payload = jsonDecode('${row['payload']}');
    return ScanRun(
      kind: '${row['kind']}',
      asOf: '${row['as_of']}',
      rows: payload is List
          ? payload
                .whereType<Map>()
                .map((e) => e.cast<String, dynamic>())
                .toList()
          : const [],
      createdAt: DateTime.fromMillisecondsSinceEpoch(
        (row['created_at'] as num?)?.toInt() ?? 0,
      ),
    );
  }

  Future<void> clearRuns(String kind) async {
    final db = await _db.database;
    await db.delete(
      AppDatabase.tableScanRuns,
      where: 'kind = ?',
      whereArgs: [kind],
    );
  }

  // -------------------------------------------------------------------------
  // Last known prices
  // -------------------------------------------------------------------------

  /// Bulk-upserts a price map keyed by `EXCHANGE:SYMBOL`.
  Future<void> savePrices(Map<String, PricedValue> prices) async {
    if (prices.isEmpty) return;
    final db = await _db.database;
    final batch = db.batch();
    prices.forEach((key, value) {
      batch.insert(AppDatabase.tablePriceCache, {
        'price_key': key.toUpperCase(),
        'token': '',
        'ltp': value.value,
        'change_pct': value.changePct,
        'as_of': value.asOf.millisecondsSinceEpoch,
      }, conflictAlgorithm: ConflictAlgorithm.replace);
    });
    await batch.commit(noResult: true);
  }

  /// Reads back the cached prices. Returned values are marked `isLive: false`
  /// so the UI can label them as cached rather than live.
  Future<Map<String, PricedValue>> loadPrices() async {
    final db = await _db.database;
    final rows = await db.query(AppDatabase.tablePriceCache);
    final result = <String, PricedValue>{};
    for (final row in rows) {
      result['${row['price_key']}'] = PricedValue(
        value: (row['ltp'] as num?)?.toDouble() ?? 0,
        changePct: (row['change_pct'] as num?)?.toDouble(),
        asOf: DateTime.fromMillisecondsSinceEpoch(
          (row['as_of'] as num?)?.toInt() ?? 0,
        ),
        isLive: false,
      );
    }
    return result;
  }

  /// Newest price timestamp in the cache — the "as of" label in the app bar.
  Future<DateTime?> lastPriceTimestamp() async {
    final db = await _db.database;
    final rows = await db.rawQuery(
      'SELECT MAX(as_of) AS m FROM ${AppDatabase.tablePriceCache}',
    );
    final value = rows.isEmpty ? null : rows.first['m'];
    if (value == null) return null;
    return DateTime.fromMillisecondsSinceEpoch((value as num).toInt());
  }

  Future<void> clearPrices() async {
    final db = await _db.database;
    await db.delete(AppDatabase.tablePriceCache);
  }

  /// Purane prices hata do — ek hafte se purana LTP dekh kar "aaj ka bhav"
  /// samajhna galat hoga. ``[before]`` se purane rows delete.
  Future<int> prunePrices({required DateTime before}) async {
    final db = await _db.database;
    return db.delete(
      AppDatabase.tablePriceCache,
      where: 'as_of < ?',
      whereArgs: [before.millisecondsSinceEpoch],
    );
  }

  /// Ek keyword se key dhoondo (live feed ke token ke badle symbol se).
  Future<PricedValue?> priceFor(String priceKey) async {
    final db = await _db.database;
    final rows = await db.query(
      AppDatabase.tablePriceCache,
      where: 'price_key = ?',
      whereArgs: [priceKey.toUpperCase()],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    final row = rows.first;
    return PricedValue(
      value: (row['ltp'] as num?)?.toDouble() ?? 0,
      changePct: (row['change_pct'] as num?)?.toDouble(),
      asOf: DateTime.fromMillisecondsSinceEpoch(
        (row['as_of'] as num?)?.toInt() ?? 0,
      ),
      isLive: false,
    );
  }

  /// Kitne run padhe hue hain (Settings → Storage ke liye).
  Future<int> runCount() async {
    final db = await _db.database;
    final rows = await db.rawQuery(
      'SELECT COUNT(*) AS c FROM ${AppDatabase.tableScanRuns}',
    );
    return (rows.first['c'] as num? ?? 0).toInt();
  }

  Future<int> priceCount() async {
    final db = await _db.database;
    final rows = await db.rawQuery(
      'SELECT COUNT(*) AS c FROM ${AppDatabase.tablePriceCache}',
    );
    return (rows.first['c'] as num? ?? 0).toInt();
  }

  // -------------------------------------------------------------------------
  // Retention (1.5.107)
  // -------------------------------------------------------------------------

  /// [before] se purane **har** kind ke run hata do.
  ///
  /// `scan_runs` ki `UNIQUE(kind, as_of)` har din ek nayi row banati hai aur
  /// purani kabhi delete nahi hoti thi — mahino me DB bas bharta jaata tha.
  /// Har kind ka apna as_of hota hai, isliye date-wise delete hi sahi hai
  /// (kind-wise limit lagane se kisi ek screener ka aaj ka run bhi ja sakta tha).
  Future<int> pruneRuns({required DateTime before}) async {
    final db = await _db.database;
    return db.delete(
      AppDatabase.tableScanRuns,
      where: 'as_of < ?',
      whereArgs: [_isoDate(before)],
    );
  }

  /// Poore cache ka ek sweep — scans ke baad aur app khulte waqt.
  ///
  /// Returns kitni rows hati (Settings/log ke liye). Sab best-effort: koi bhi
  /// step fail ho to baaki chalte rehte hain.
  Future<({int runs, int prices})> sweep({DateTime? now}) async {
    final day = now ?? DateTime.now();
    var runs = 0;
    var prices = 0;
    try {
      runs = await pruneRuns(
        before: day.subtract(const Duration(days: CacheRetention.scanRunDays)),
      );
    } catch (_) {}
    try {
      prices = await prunePrices(
        before: day.subtract(const Duration(days: CacheRetention.priceDays)),
      );
    } catch (_) {}
    return (runs: runs, prices: prices);
  }

  static String _isoDate(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-'
      '${d.month.toString().padLeft(2, '0')}-'
      '${d.day.toString().padLeft(2, '0')}';
}
