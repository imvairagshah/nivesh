// ---------------------------------------------------------------------------
// price_cache_writer.dart — "jo price aaj dekha, wo yaad rakho" (1.5.107).
//
// Pehle `price_cache` sirf IPO screener likhta tha. RSI / Golden Cross / F&O
// study / F&O scanner / IV Spike ko offline "last known price" milta hi nahi
// tha — feed fail hote hi unke columns khaali. Ab har scan jo price dekhta hai
// (close ya quote), wo yahan se cache me jaata hai — aur cache se padha jaata
// hai — bas ek hi key shape se: `EXCHANGE:SYMBOL` (wahi jo IPO likhta hai).
//
// Rules:
//   • Sirf **positive** price cache hoti hai (0 / NaN = "data nahi").
//   • `asOf` hamesha asli source ka hota hai (bar ka din ya quote ka time),
//     isliye UI "cached (DD MMM)" ke saath sach likh sakti hai.
//   • Likhna best-effort: cache fail ho to scan fail nahi hota.
//   • Cache se padha hua price **hamesha** `isLive: false` hota hai.
// ---------------------------------------------------------------------------

import '../core/utils/markets.dart';
import '../data/local/dao/scan_cache_dao.dart';
import '../data/remote/dto/candle.dart';
import '../data/remote/dto/quote.dart';
import '../data/remote/dto/scrip.dart';

/// Cache key — `NSE:SBIN`. Wahi shape IPO screener use karta hai
/// (`IpoScreenerEngine.priceKeyFor`), isliye ek hi price do jagah kaam aati hai.
String priceKey(String exchange, String symbol) =>
    '${exchange.toUpperCase()}:${symbol.toUpperCase()}';

class PriceCacheWriter {
  PriceCacheWriter(this._cache, {DateTime Function()? clock})
    : _clock = clock ?? DateTime.now;

  final ScanCacheDao _cache;
  final DateTime Function() _clock;

  /// Candle-based scans: har instrument ka **last close**, aur `asOf` = us bar
  /// ka IST din (guess nahi, wahi din jiska close hai).
  Future<void> saveCloses(List<({Scrip scrip, Candle last})> closes) async {
    final map = <String, PricedValue>{};
    for (final item in closes) {
      final price = item.last.close;
      if (!price.isFinite || price <= 0) continue;
      map[priceKey(item.scrip.exchange.code, item.scrip.symbol)] = PricedValue(
        value: price,
        asOf: item.last.istDate,
        isLive: false,
        changePct: null,
      );
    }
    await _save(map);
  }

  /// Quote-based scans (F&O study ka option premium, greeks ke saath aaya LTP
  /// etc.) — sirf wo keys jo caller ne maangi hain.
  Future<void> saveQuotes(
    Map<String, MarketQuote> quotes, {
    required Scrip Function(String token) scripFor,
  }) async {
    final now = _clock();
    final map = <String, PricedValue>{};
    quotes.forEach((token, quote) {
      if (!quote.ltp.isFinite || quote.ltp <= 0) return;
      final scrip = scripFor(token);
      map[priceKey(scrip.exchange.code, scrip.symbol)] = PricedValue(
        value: quote.ltp,
        asOf: now,
        isLive: true,
        changePct: quote.percentChange,
      );
    });
    await _save(map);
  }

  /// Cache se pichhla price — `null` jab kuch bhi na ho.
  ///
  /// `[maxAgeDays]` se purana price "aaj ka bhav" nahi kahlata, isliye reject.
  Future<PricedValue?> cached(
    String exchange,
    String symbol, {
    int maxAgeDays = CacheRetention.priceDays,
  }) async {
    try {
      final value = await _cache.priceFor(priceKey(exchange, symbol));
      if (value == null || value.value <= 0) return null;
      final age = _clock().difference(value.asOf).inDays;
      if (age > maxAgeDays) return null;
      return value;
    } catch (_) {
      return null;
    }
  }

  /// Poore cache ka last-known map (`EXCHANGE:SYMBOL` → value).
  Future<Map<String, PricedValue>> loadAll() async {
    try {
      return await _cache.loadPrices();
    } catch (_) {
      return const {};
    }
  }

  Future<void> _save(Map<String, PricedValue> map) async {
    if (map.isEmpty) return;
    try {
      await _cache.savePrices(map);
    } catch (_) {
      // Cache optional — network ka data pehle hi UI tak pahunch chuka hai.
    }
  }
}
