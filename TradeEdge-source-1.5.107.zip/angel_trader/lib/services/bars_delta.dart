// ---------------------------------------------------------------------------
// bars_delta.dart — 1.5.95. Cache me jo bars hain unhe rakho, sirf **tail**
// (naye din) maango — poore 400 din dobara nahi.
//
// Sabse bada darr: split / bonus. Agar stock 1:5 split ho gaya to naye bars
// purane se 5x chhote hote hain; purane cache ke saath mila dene par RSI / DMA
// / 52W galat ho jaate hain. Isliye yahan ek **guard** hai: naya pehla bar aur
// cache ka aakhri close compare hote hain. 25% se zyada farak = "kuch hua hai"
// → caller **poora window dobara** maangega (jaisa aaj hota hai). Guard fail
// hone par accuracy par koi samjhauta nahi.
//
// Poora hisaab pure functions me hai — network ke bina test ho jaata hai.
// ---------------------------------------------------------------------------

import '../data/remote/dto/candle.dart';

/// Merge ka nateeja.
class BarsMerge {
  const BarsMerge({
    required this.bars,
    required this.added,
    required this.suspicious,
  });

  /// Cache + naye bars, date se dedupe (naya jeetta hai), purane se naye.
  final List<Candle> bars;

  /// Kitne naye din jude.
  final int added;

  /// `true` = split/bonus jaisa jump mila → poora window dobara maango.
  final bool suspicious;
}

/// Ek din (IST date) — bars ka identity key.
DateTime barDay(Candle c) {
  final ist = c.time.toUtc().add(const Duration(hours: 5, minutes: 30));
  return DateTime(ist.year, ist.month, ist.day);
}

/// [cached] + [fresh] ko jodo. `fresh` jeetta hai (wahi din dobara aaya to).
///
/// [splitGuardPct] — itne % se zyada ka jump "suspicious" hai (default 25%).
BarsMerge mergeBars({
  required List<Candle> cached,
  required List<Candle> fresh,
  double splitGuardPct = 0.25,
}) {
  final byDay = <DateTime, Candle>{};
  for (final c in cached) {
    byDay[barDay(c)] = c;
  }
  var added = 0;
  for (final c in fresh) {
    final key = barDay(c);
    if (!byDay.containsKey(key)) added++;
    byDay[key] = c;
  }
  final days = byDay.keys.toList()..sort();
  final bars = [for (final d in days) byDay[d]!];

  return BarsMerge(
    bars: bars,
    added: added,
    suspicious: isSplitSuspicious(
      cached: cached,
      fresh: fresh,
      limit: splitGuardPct,
    ),
  );
}

/// Split/bonus ka shak: naya pehla bar purane aakhri close se bahut door.
///
/// (Angel ke candles unadjusted hote hain, isliye split ke baad price me seedha
/// jump dikhta hai. 25% se bada jump roz ka normal move nahi hota.)
bool isSplitSuspicious({
  required List<Candle> cached,
  required List<Candle> fresh,
  double limit = 0.25,
}) {
  if (cached.isEmpty || fresh.isEmpty) return false;
  final last = cached.last;
  final base = last.close;
  if (base <= 0) return false;

  // Sirf tab dekho jab naya bar cache ke baad ka ho (overlap wala bar ignore).
  final lastDay = barDay(last);
  for (final c in fresh) {
    if (barDay(c).isAfter(lastDay) && c.close > 0) {
      final jump = (c.close - base).abs() / base;
      return jump > limit;
    }
  }
  return false;
}
