// ---------------------------------------------------------------------------
// greeks_cache.dart — ek hi din me wahi greeks dobara mat maango (1.5.107).
//
// IV Spike / Study ke greeks calls **per underlying + expiry** hote hain, aur
// ek hi din me ek underlying ka greek batch nahi badalta (broker EOD series
// deta hai). Pehle din me doosri baar IV Spike chalane par bhi ~213 calls
// phir se jaate the (3 req/s par ~70 second sirf greeks).
//
// Ye ek din ka memory cache hai: `underlying|expiry` → batch. App band hone
// par gayab ho jaata hai, isliye stale hone ka sawal nahi (kuch bhi kal se
// nahi aata). Fail hue batches cache **nahi** hote — agli koshish phir real
// call karti hai.
// ---------------------------------------------------------------------------

import '../data/remote/dto/quote.dart';
import '../data/remote/dto/scrip.dart';
import 'study_market_data.dart';

class GreeksCache implements StudyMarketData {
  GreeksCache(this._inner, {DateTime Function()? clock})
    : _clock = clock ?? DateTime.now;

  /// Asli source (MarketDataService) — cache miss par isi se.
  final StudyMarketData _inner;
  final DateTime Function() _clock;

  final Map<String, ({OptionGreekBatch batch, DateTime fetchedAt})> _store = {};

  /// Kitni calls bache (diagnostics/log ke liye).
  int hits = 0;
  int misses = 0;

  /// Aaj ke cache ki entry count.
  int get size => _store.length;

  void clear() => _store.clear();

  static String keyFor(String underlying, String expiryLabel) =>
      '${underlying.trim().toUpperCase()}|${expiryLabel.trim().toUpperCase()}';

  @override
  Future<Map<String, MarketQuote>> fetchQuotesFull(List<Scrip> scrips) =>
      _inner.fetchQuotesFull(scrips);

  @override
  Future<OptionGreekBatch> fetchOptionGreeks({
    required String underlying,
    required String expiryLabel,
  }) async {
    final key = keyFor(underlying, expiryLabel);
    final now = _clock();
    final hit = _store[key];
    if (hit != null && _sameDay(hit.fetchedAt, now)) {
      hits++;
      return hit.batch;
    }
    misses++;
    final batch = await _inner.fetchOptionGreeks(
      underlying: underlying,
      expiryLabel: expiryLabel,
    );
    // Sirf asli data cache hota hai — error/empty batch agli baar dobara try
    // hone chahiye (warna ek network hiccup poore din ka IV maarde ga).
    if (batch.byStrike.isNotEmpty) {
      _store[key] = (batch: batch, fetchedAt: now);
    }
    return batch;
  }

  static bool _sameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;
}
