# TRADE EDGE — Windows laptop par `.exe` (1.5.107)

**Code wahi hai jo APK me hai** — `lib/` bilkul same (1.5.107, vc 2120).
`.exe` Windows par hi banta hai (Windows ka compiler chahiye), isliye do raste hain:

| Raasta | Kaam | Time |
|---|---|---|
| **A. GitHub Actions** (recommended) | laptop par kuch install nahi, sirf zip upload | ~15 min |
| **B. Apne laptop par** | Flutter + Visual Studio Build Tools install | pehli baar 45–60 min, phir 5 min |

---

## A. GitHub se `.exe` (kuch install nahi)

1. Zip `TradeEdge-source-1.5.107.zip` ko repo me **root par** upload karo
   (zip ke andar `angel_trader/` folder hai — workflow khud dhoondh leta hai).
2. `.github/workflows/windows-build.yml` bhi zip me hai — root par `.github/`
   folder ke saath upload ho jaaye to workflow aa jaata hai.
3. Repo → **Actions** → "NiveshDesk Windows .exe" → **Run workflow**.
4. ~12–15 min baad → run kholo → neeche **Artifacts → NiveshDesk-Windows** →
   download → unzip → **`TradeEdge.exe`** (poora folder saath rakho: DLLs +
   `data/`).

> Workflow me `flutter config --enable-windows-desktop`, ephemeral cleanup aur
> project-folder detect pehle se hai — 1.5.92 wali fail wajah fix hai.

---

## B. Apne laptop par

### Step 1 — Tools (sirf pehli baar)
1. **Visual Studio Build Tools** (free): https://visualstudio.microsoft.com/visual-cpp-build-tools/
   → "Desktop development with C++" workload tick → Install (~3–5 GB)
2. **Flutter SDK**: https://docs.flutter.dev/get-started/install/windows/desktop
   → `C:\flutter` me extract, `C:\flutter\bin` ko PATH me daalo
3. Naya Command Prompt:
   ```bat
   flutter doctor
   ```
   "Visual Studio" line green honi chahiye.

### Step 2 — Code
`TradeEdge-source-1.5.107.zip` ko extract karo → andar `angel_trader/` folder milega.

### Step 3 — Build
```bat
cd angel_trader
build_windows.bat
```
ya seedha:
```bat
flutter pub get
flutter build windows --release
```

**Output:** `build\windows\x64\runner\Release\TradeEdge.exe`
(poora Release folder saath rakho — exe akela nahi chalta).

### Step 4 (optional) — Installer
1. **Inno Setup**: https://jrsoftware.org/isinfo.php
2. `installer.iss` open → **Compile (F9)**
3. `Output\TRADE EDGE-Setup-1.5.107.exe`

> Code-signing certificate nahi hai → Windows pehli baar "More info → Run anyway"
> dikha sakta hai. Installer par bhi wahi.

---

## Is round me Windows ke liye kya theek kiya

| Cheez | Pehle | Ab |
|---|---|---|
| exe ka naam | `angel_trader.exe` | **`TradeEdge.exe`** (`windows/CMakeLists.txt`, `main.cpp`, `Runner.rc`) |
| Window title / file properties | "NiveshDesk" | "TradeEdge" |
| `build_windows.bat` ka output path | galat (TRADE EDGE.exe) | `TradeEdge.exe` |
| `installer.iss` version | 1.5.72 | **1.5.107** |
| `installer.iss` shortcut path | `_{#AppExeName}` (toota hua) | `\{#AppExeName}` |
| App data | `%APPDATA%\com.example.angel_trader\niveshdesk\angel_trader.db` | wahi (purana data safe) |

---

## Desktop par jo features automated test se bahar hain

Sabhi **1610 tests** (118 files) Docker/Linux par pass hue — inme app ke saare
engines, DAO/SQL (asli schema, sqflite FFI), providers aur theme sweep shamil
hain. Windows-only cheezein (native window, file picker dialog, notification
plugin) code-level par same rehti hain par **compile Windows par hi hota hai** —
agar GitHub run me koi Windows-specific plugin error aaye to run ka log bhejo,
wahi patch kar dunga.

## Zip me kya hai (complete)

```
TradeEdge-source-1.5.107.zip
└── angel_trader/
    ├── lib/                  # poora app code (1.5.107)
    ├── test/                 # 118 files / 1610 tests
    ├── assets/               # brand, fonts, icon, data (assets me sab kuch)
    ├── android/              # APK build + signing (jks/key.properties)
    ├── windows/              # .exe build (CMake + runner)
    ├── linux/                # desktop (Linux) build
    ├── .github/workflows/    # GitHub Actions se .exe
    ├── design/  docs/  tool/ # design refs, docs, dev tools
    ├── pubspec.yaml + pubspec.lock  # locked dependencies
    ├── analysis_options.yaml
    ├── build_windows.bat
    ├── installer.iss
    ├── README.md
    ├── .gitignore  .metadata
    └── angel_trader.iml
```
