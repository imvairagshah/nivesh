// ---------------------------------------------------------------------------
// edge_header_test.dart — 1.5.98 ka header rule.
//
// User report: "Equity section me header nahi aa rahe kisi bhi option me".
// Wajah: IPO / Golden Cross / RSI / Paper / Reports pehle shell ke tabs the —
// unka apna header hi nahi tha. Ab har screen ka apna header hai.
//
// Ye test do cheezein pakadta hai:
//   1. [EdgeAppBar] sach me title + subtitle + back + brand mark deta hai
//      (light aur dark dono me);
//   2. koi bhi equity screen bina header ke ship na ho — source-level guard,
//      kyunki har screen ko poore providers ke saath pump karna bhaari aur
//      nazuk hai.
// ---------------------------------------------------------------------------

import 'dart:io';

import 'package:angel_trader/core/theme/app_theme.dart';
import 'package:angel_trader/core/widgets/brand.dart';
import 'package:angel_trader/core/widgets/edge_header.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

Widget _host(Widget child, {Brightness brightness = Brightness.light}) =>
    MaterialApp(
      theme: brightness == Brightness.dark ? AppTheme.dark() : AppTheme.light(),
      home: child,
    );

void main() {
  group('EdgeAppBar', () {
    testWidgets('title, subtitle aur brand mark dikhte hain', (tester) async {
      await tester.pumpWidget(
        _host(
          const Scaffold(
            appBar: EdgeAppBar(
              title: 'RSI Scanner',
              subtitle: 'Overbought / oversold',
            ),
            body: SizedBox(),
          ),
        ),
      );

      expect(find.text('RSI Scanner'), findsOneWidget);
      expect(find.text('Overbought / oversold'), findsOneWidget);
      expect(find.byType(BrandMark), findsOneWidget);
    });

    testWidgets('root screen par back button nahi', (tester) async {
      await tester.pumpWidget(
        _host(
          const Scaffold(
            appBar: EdgeAppBar(title: 'Home', canPop: false),
            body: SizedBox(),
          ),
        ),
      );
      expect(find.byIcon(Icons.arrow_back_rounded), findsNothing);
    });

    testWidgets('dark mode me bhi title readable hai (ink theme se)', (
      tester,
    ) async {
      await tester.pumpWidget(
        _host(
          const Scaffold(
            appBar: EdgeAppBar(title: 'Paper Trading', subtitle: 'Simulated'),
            body: SizedBox(),
          ),
          brightness: Brightness.dark,
        ),
      );

      final title = tester.widget<Text>(find.text('Paper Trading'));
      final scheme = AppTheme.dark().colorScheme;
      expect(title.style!.color, scheme.onSurface);
      // Dark scheme ka ink light hai — yaani kaala text kaali surface par nahi.
      expect(title.style!.color!.computeLuminance(), greaterThan(0.5));
    });

    testWidgets('ink light aur dark dono me alag hai', (tester) async {
      expect(
        AppTheme.light().colorScheme.onSurface,
        isNot(AppTheme.dark().colorScheme.onSurface),
      );
      // Light ink navy-black hai (muddy green-grey nahi).
      expect(
        AppTheme.light().colorScheme.onSurface.computeLuminance(),
        lessThan(0.05),
      );
    });
  });

  group('har equity screen ka apna header hai', () {
    // Har screen jo Equity hub se khulti hai.
    const screens = {
      'IPO Screener': 'lib/features/ipo_screener/ipo_screener_screen.dart',
      'Golden Cross': 'lib/features/golden_cross/golden_cross_screen.dart',
      'RSI Scanner': 'lib/features/rsi_scanner/rsi_scanner_screen.dart',
      'Magic Formula': 'lib/features/magic_formula/magic_formula_screen.dart',
      'Paper Trading': 'lib/features/paper_trading/paper_trading_screen.dart',
      'Reports': 'lib/features/reports/reports_screen.dart',
      'Calls Board': 'lib/features/calls_board/calls_screen.dart',
      'Settings': 'lib/features/settings/settings_screen.dart',
      'Equity hub': 'lib/features/equity/equity_hub_screen.dart',
      'F&O hub': 'lib/features/fno/fno_hub_screen.dart',
      'FAQ': 'lib/features/help/tool_faq_screen.dart',
    };

    for (final entry in screens.entries) {
      test('${entry.key} — header maujood', () {
        final source = File(entry.value).readAsStringSync();
        final hasHeader =
            source.contains('EdgeAppBar(') ||
            source.contains('EdgeScaffold(') ||
            // Calls Board tabs ke liye raw AppBar use karta hai (title +
            // subtitle wahi).
            (source.contains('appBar: AppBar(') && source.contains('title:'));
        expect(hasHeader, isTrue, reason: '${entry.key} me header nahi hai');
      });
    }
  });
}
