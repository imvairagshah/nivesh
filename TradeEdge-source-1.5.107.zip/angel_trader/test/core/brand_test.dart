// ---------------------------------------------------------------------------
// brand_test.dart — TRADE EDGE ka logo aur wordmark (1.5.96 redesign).
//
// Mark ab code se paint nahi hota, user ka diya hua **asset** hai
// (`assets/brand/trade_edge_mark.png`). Isliye yahan wahi cheezein pin hoti
// hain jo user ko dikhti hain: asset load hota hai, white plate dark mode me
// aata hai, wordmark ke dono aadhe alag rang ke hain, tagline sach me
// brand ka hissa hai, aur splash ka entrance animation band nahi hota.
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/theme/app_theme.dart';
import 'package:angel_trader/core/widgets/brand.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

Widget _host(Widget child, {Brightness brightness = Brightness.light}) =>
    MaterialApp(
      theme: brightness == Brightness.dark ? AppTheme.dark() : AppTheme.light(),
      home: Scaffold(body: Center(child: child)),
    );

void main() {
  // -------------------------------------------------------------------------
  group('Brand constants', () {
    test('the wordmark is two tones of the same name', () {
      expect(Brand.name, '${Brand.namePrefix} ${Brand.nameSuffix}');
      expect(Brand.name, 'TRADE EDGE');
    });

    test('the product does not trade on Angel One’s name', () {
      // The app reads Angel One data but is not theirs; the visible brand
      // must never suggest otherwise.
      expect(Brand.name.toLowerCase(), isNot(contains('angel')));
      expect(Brand.tagline.toLowerCase(), isNot(contains('angel')));
    });

    test('the tagline is the one from the uploaded logo', () {
      expect(Brand.tagline, 'FNO & EQUITY ANALYSIS');
    });

    test('the palette comes from the logo: navy + green + paper', () {
      expect(Brand.navy, const Color(0xFF101B33));
      expect(Brand.green, const Color(0xFF0F9D63));
      expect(Brand.paper, const Color(0xFFF1F4F8));
      // Both hero gradients stay real gradients (no flat fill slipping in).
      for (final dark in [false, true]) {
        final gradient = Brand.heroGradient(dark: dark);
        expect(gradient.colors.length, greaterThanOrEqualTo(2));
        expect(gradient.colors.first, isNot(gradient.colors.last));
      }
      expect(
        Brand.greenGradient().colors.first,
        isNot(Brand.greenGradient().colors.last),
      );
    });
  });

  // -------------------------------------------------------------------------
  group('BrandMark', () {
    testWidgets('loads the uploaded mark as an asset', (tester) async {
      await tester.pumpWidget(_host(const BrandMark(size: 80)));
      final image = tester.widget<Image>(find.byType(Image));
      expect(
        (image.image as AssetImage).assetName,
        'assets/brand/trade_edge_mark.png',
      );
      // The size the caller asked for is the size it gets (width).
      final rect = tester.getRect(find.byType(BrandMark));
      expect(rect.width, 80);
    });

    testWidgets('sits on a white plate in dark mode only', (tester) async {
      double plateCount(Brightness b) {
        return tester
            .widgetList<Container>(
              find.descendant(
                of: find.byType(BrandMark),
                matching: find.byType(Container),
              ),
            )
            .length
            .toDouble();
      }

      await tester.pumpWidget(_host(const BrandMark(size: 60)));
      expect(plateCount(Brightness.light), 0, reason: 'light bg = no plate');

      await tester.pumpWidget(
        _host(const BrandMark(size: 61), brightness: Brightness.dark),
      );
      await tester.pump(const Duration(milliseconds: 250));
      expect(
        plateCount(Brightness.dark),
        1,
        reason: 'navy strokes need a light plate on dark',
      );
    });

    testWidgets('is exposed to accessibility as a logo', (tester) async {
      await tester.pumpWidget(_host(const BrandMark()));
      expect(find.bySemanticsLabel('${Brand.name} logo'), findsOneWidget);
    });
  });

  // -------------------------------------------------------------------------
  group('AnimatedBrandMark', () {
    testWidgets('fades and scales in, then settles at full opacity', (
      tester,
    ) async {
      await tester.pumpWidget(_host(const AnimatedBrandMark(size: 96)));

      double opacity() => tester
          .widget<Opacity>(
            find.descendant(
              of: find.byType(AnimatedBrandMark),
              matching: find.byType(Opacity),
            ),
          )
          .opacity;

      expect(opacity(), lessThan(0.2), reason: 'starts invisible');

      await tester.pump(const Duration(milliseconds: 250));
      await tester.pump(const Duration(milliseconds: 250));
      final mid = opacity();
      expect(mid, greaterThan(0.0));
      expect(mid, lessThanOrEqualTo(1.0));

      await tester.pump(const Duration(milliseconds: 800));
      expect(opacity(), 1);
    });

    testWidgets('a delayed mark still completes', (tester) async {
      await tester.pumpWidget(
        _host(
          const AnimatedBrandMark(size: 80, delay: Duration(milliseconds: 120)),
        ),
      );

      await tester.pump(const Duration(milliseconds: 60));
      expect(
        tester
            .widget<Opacity>(
              find.descendant(
                of: find.byType(AnimatedBrandMark),
                matching: find.byType(Opacity),
              ),
            )
            .opacity,
        0,
        reason: 'still inside the 120 ms delay',
      );
      await tester.pump(const Duration(milliseconds: 100));
      await tester.pump(const Duration(milliseconds: 900));
      expect(
        tester
            .widget<Opacity>(
              find.descendant(
                of: find.byType(AnimatedBrandMark),
                matching: find.byType(Opacity),
              ),
            )
            .opacity,
        1,
      );
    });
  });

  // -------------------------------------------------------------------------
  group('BrandLogo / wordmark', () {
    testWidgets('shows the two-tone name, and the tagline on request', (
      tester,
    ) async {
      await tester.pumpWidget(_host(const BrandLogo(markSize: 40)));
      expect(find.textContaining('TRADE'), findsOneWidget);
      expect(find.textContaining('EDGE'), findsWidgets);

      await tester.pumpWidget(
        _host(const BrandLogo(markSize: 40, showTagline: true)),
      );
      expect(find.text(Brand.tagline), findsOneWidget);
    });

    testWidgets('stacks vertically for the splash and login layouts', (
      tester,
    ) async {
      await tester.pumpWidget(
        _host(
          const BrandLogo(markSize: 54, axis: Axis.vertical, showTagline: true),
        ),
      );
      // Mark above the wordmark: the mark's bottom edge is above the text's.
      final mark = tester.getRect(find.byType(BrandMark));
      final text = tester.getRect(find.textContaining('TRADE'));
      expect(mark.bottom, lessThanOrEqualTo(text.top + 1));
    });

    testWidgets('the wordmark colours the two halves differently', (
      tester,
    ) async {
      await tester.pumpWidget(_host(const BrandLogo(markSize: 40)));
      final rich = tester.widget<Text>(find.textContaining('TRADE'));
      final span = rich.textSpan! as TextSpan;
      final childSpans = span.children!.cast<TextSpan>();
      expect(childSpans, hasLength(2));
      expect(childSpans[0].text, 'TRADE ');
      expect(
        childSpans[0].style!.color,
        isNot(childSpans[1].style!.color),
        reason: 'TRADE is navy, EDGE carries the brand green',
      );
      expect(childSpans[1].text, 'EDGE');
      expect(childSpans[1].style!.fontWeight, FontWeight.w900);
    });

    testWidgets('the wordmark stays readable on a dark surface', (
      tester,
    ) async {
      await tester.pumpWidget(
        _host(
          const BrandWordmark(fontSize: 22, onDark: true),
          brightness: Brightness.dark,
        ),
      );
      final span = tester.widget<Text>(find.byType(Text)).textSpan! as TextSpan;
      final childSpans = span.children!.cast<TextSpan>();
      expect(childSpans[0].style!.color, Colors.white);
    });
  });
}
