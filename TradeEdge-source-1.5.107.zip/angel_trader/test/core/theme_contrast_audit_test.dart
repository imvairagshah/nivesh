// ---------------------------------------------------------------------------
// theme_contrast_audit_test.dart — 1.5.99 "sabhi pages proper check karo".
//
// User report: "Equity section me background white hai aur font blue — kuch
// dikh nahi raha". Asli bug: `Brand.paper` hardcoded background tha, isliye
// dark mode me bhi safed reh jaata tha, par text theme ka light ink (navy)
// safed par gayab. Ye test us poori class ko pakadta hai:
//
//   1. palette ka har ink uske apne background par readable hai
//      (WCAG AA — 4.5:1 body, 3:1 large/UI);
//   2. koi screen `Brand.paper` ko **background** ke roop me hardcode nahi
//      karti (source guard — warna dark mode me phir wahi bug);
//   3. MarketColors (gain/loss/flat/stale) dono themes me background par
//      padhne layak hain.
// ---------------------------------------------------------------------------

import 'dart:io';

import 'package:angel_trader/core/theme/app_theme.dart';
import 'package:angel_trader/features/fno/fno_hub_config.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

/// Relative luminance — WCAG 2.1.
double _lum(Color c) => c.computeLuminance();

/// WCAG contrast ratio between two opaque colours.
double contrast(Color a, Color b) {
  final la = _lum(a);
  final lb = _lum(b);
  final hi = la > lb ? la : lb;
  final lo = la > lb ? lb : la;
  return (hi + 0.05) / (lo + 0.05);
}

void main() {
  group('ink readable hai (WCAG AA)', () {
    for (final entry in {
      'light': AppTheme.light().colorScheme,
      'dark': AppTheme.dark().colorScheme,
    }.entries) {
      final name = entry.key;
      final scheme = entry.value;
      final bg = scheme.surface;

      test('$name — onSurface on surface', () {
        expect(contrast(scheme.onSurface, bg), greaterThan(12));
      });

      test('$name — onSurfaceVariant on surface', () {
        expect(contrast(scheme.onSurfaceVariant, bg), greaterThan(4.5));
      });

      test('$name — onSurfaceVariant on surfaceContainerLow', () {
        expect(
          contrast(scheme.onSurfaceVariant, scheme.surfaceContainerLow),
          greaterThan(4.5),
        );
      });

      test('$name — primary ink on surface (links/icons)', () {
        expect(contrast(scheme.primary, bg), greaterThan(3.0));
      });

      test('$name — error on surface', () {
        expect(contrast(scheme.error, bg), greaterThan(3.0));
      });

      test('$name — scaffold background aur surface alag hain', () {
        final theme = name == 'light' ? AppTheme.light() : AppTheme.dark();
        expect(
          theme.scaffoldBackgroundColor,
          isNot(scheme.surface),
          reason: 'cards background par tairte dikhne chahiye',
        );
      });
    }
  });

  group('MarketColors dono themes me padhne layak', () {
    for (final (name, market, scheme) in [
      ('light', MarketColors.light, AppTheme.light().colorScheme),
      ('dark', MarketColors.dark, AppTheme.dark().colorScheme),
    ]) {
      test('$name — gain / loss / flat / stale / nearHigh / nearLow', () {
        for (final (label, color) in [
          ('gain', market.gain),
          ('loss', market.loss),
          ('flat', market.flat),
          ('stale', market.stale),
          ('nearHigh', market.nearHigh),
          ('nearLow', market.nearLow),
        ]) {
          expect(
            contrast(color, scheme.surface),
            greaterThan(3.0),
            reason: '$name · $label surface par kam dikhta hai',
          );
        }
      });
    }
  });

  group('background hardcode nahi (dark-mode bug ka source)', () {
    test('koi screen Brand.paper ko background me use nahi karti', () {
      final offenders = <String>[];
      for (final file
          in Directory('lib/features')
              .listSync(recursive: true)
              .whereType<File>()
              .where((f) => f.path.endsWith('.dart'))) {
        final source = file.readAsStringSync();
        // `Brand.paper` sirf tab theek hai jab wo kisi light-only surface par
        // ho; Scaffold/EdgeScaffold ka background hamesha `Brand.bgOf(...)`
        // ya theme se aana chahiye.
        final hardcodedBackground = RegExp(
          r'backgroundColor:\s*Brand\.paper\b',
        ).hasMatch(source);
        if (hardcodedBackground) offenders.add(file.path);
      }
      expect(offenders, isEmpty, reason: offenders.join(', '));
    });

    test('Brand.bgOf dono brightness ke liye alag colour deta hai', () {
      expect(Brand.paper, const Color(0xFFF1F4F8));
      expect(Brand.paperDark, const Color(0xFF0B121C));
      expect(Brand.paper, isNot(Brand.paperDark));
      // Dark background par light ink ka contrast achha hai.
      expect(
        contrast(AppTheme.dark().colorScheme.onSurface, Brand.paperDark),
        greaterThan(12),
      );
      // …aur light background par dark ink.
      expect(
        contrast(AppTheme.light().colorScheme.onSurface, Brand.paper),
        greaterThan(12),
      );
    });
  });

  group('F&O hub badge chip par readable (1.5.100)', () {
    // Badge = accent text par accent ka 12% tinted chip. Badge font 8px hai,
    // isliye 4.5:1 chahiye — 3:1 ka large-text exemption yahan nahi milta.
    Color tintOn(Color accent, Color base) =>
        Color.alphaBlend(accent.withValues(alpha: 0.12), base);

    for (final entry in {
      'light': (AppTheme.light().colorScheme, const Color(0xFFFFFFFF)),
      'dark': (AppTheme.dark().colorScheme, const Color(0xFF141C2A)),
    }.entries) {
      final base = entry.value.$2;

      test('${entry.key}: har section ka badge text 4.5:1+', () {
        for (final section in HubSection.values) {
          final accent = entry.key == 'dark' ? section.dark : section.light;
          final ratio = contrast(accent, tintOn(accent, base));
          expect(
            ratio,
            greaterThanOrEqualTo(4.5),
            reason:
                '${section.label} badge ${entry.key} me $ratio:1 '
                '(chahiye 4.5:1)',
          );
        }
      });
    }
  });
}
