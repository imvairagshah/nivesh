// ---------------------------------------------------------------------------
// theme_sweep_test.dart — 1.5.99: "sabhi pages proper check karo".
//
// Har bada screen **dono** brightness me render hota hai aur test pakadta hai:
//   • koi build exception nahi,
//   • page ka background theme ke hisaab se hai (dark mode me safed nahi),
//   • koi text bhii background se mila hua nahi (rendered contrast — pixels se
//     nahi, style + effective background se).
//
// Providers na hone par jo screen khulti nahi, wo `skipped` set me hai — uski
// jagah `edge_header_test.dart` ka source-guard chalta hai.
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/theme/app_theme.dart';
import 'package:angel_trader/features/equity/equity_hub_screen.dart';
import 'package:angel_trader/features/extra/extra_hub_screen.dart';
import 'package:angel_trader/features/settings/settings_provider.dart';
import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/features/fno/fno_hub_config.dart';
import 'package:angel_trader/features/fno/fno_hub_screen.dart';
import 'package:angel_trader/features/help/tool_faq.dart';
import 'package:angel_trader/features/help/tool_faq_screen.dart';
import 'package:angel_trader/features/strategy_builder/strategy_builder_provider.dart';
import 'package:angel_trader/features/fno/iv_spike/iv_spike_engine.dart';
import 'package:angel_trader/features/fno/iv_spike/iv_spike_provider.dart';
import 'package:angel_trader/features/fno/iv_spike/iv_spike_screen.dart';
import 'package:angel_trader/features/fno/iv_spike/iv_spike_service.dart';
import 'package:angel_trader/features/strategy_builder/strategy_builder_screen.dart';
import 'package:angel_trader/features/strategy_builder/strategy_report_screen.dart';
import 'package:angel_trader/data/local/dao/candle_dao.dart';
import 'package:angel_trader/data/local/dao/ipo_dao.dart';
import 'package:angel_trader/data/local/dao/scrip_dao.dart';
import 'package:angel_trader/data/local/dao/fno_contract_dao.dart';
import 'package:angel_trader/data/remote/dto/quote.dart';
import 'package:angel_trader/services/study_market_data.dart';
import 'package:angel_trader/services/candle_source.dart';
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/features/shell/home_hub_screen.dart';
import 'package:angel_trader/services/auth_service.dart';
import 'package:angel_trader/services/secure_store.dart';
import 'package:angel_trader/features/alerts/alerts_center.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';

class _MemOrder implements FnoHubOrderStore {
  @override
  Future<Map<String, List<String>>> load() async => defaultHubOrder();

  @override
  Future<void> save(Map<String, List<String>> order) async {}
}

/// Builder screen ke andaaz me network nahi chahiye — bas resolution ke liye
/// khaali candles. (Theme/contrast test ko numbers se matlab nahi.)
class _NoBars implements CandleSource {
  @override
  Future<List<Candle>> fetchDailyCandles({
    required Scrip scrip,
    required DateTime from,
    required DateTime to,
    String interval = 'ONE_DAY',
  }) async => const [];
}

/// IV Spike service ko market chahiye — theme test me koi network nahi.
class _NoQuotes implements StudyMarketData {
  @override
  Future<Map<String, MarketQuote>> fetchQuotesFull(List<Scrip> scrips) async =>
      const {};

  @override
  Future<OptionGreekBatch> fetchOptionGreeks({
    required String underlying,
    required String expiryLabel,
  }) async => const OptionGreekBatch(byStrike: {});
}

Widget _host(Widget child, Brightness brightness) => MultiProvider(
  providers: [
    // IV Spike screen provider maangta hai — scan khud nahi chalta (test me
    // button kaafi hai; contrast ke liye empty-state render hota hai).
    ChangeNotifierProvider<IvSpikeProvider>(
      create: (_) => IvSpikeProvider(
        service: IvSpikeService(
          source: _NoBars(),
          candles: CandleDao(AppDatabase.instance),
          scrips: ScripDao(AppDatabase.instance),
          contracts: FnoContractDao(AppDatabase.instance),
          market: _NoQuotes(),
        ),
        settings: SettingsDao(AppDatabase.instance),
        clock: () => DateTime(2026, 11, 18),
      ),
    ),
    ChangeNotifierProvider<StrategyBuilderProvider>(
      create: (_) => StrategyBuilderProvider(
        source: _NoBars(),
        candles: CandleDao(AppDatabase.instance),
        scripDao: ScripDao(AppDatabase.instance),
        ipoDao: IpoDao(AppDatabase.instance),
        settingsDao: SettingsDao(AppDatabase.instance),
      ),
    ),
    ChangeNotifierProvider<AuthService>(
      create: (_) => AuthService(store: SecureStore()),
    ),
    ChangeNotifierProvider<AlertsCenter>.value(value: AlertsCenter.instance),
    // EXTRA hub (1.5.101) SettingsProvider maangta hai.
    ChangeNotifierProvider<SettingsProvider>(
      create: (_) => SettingsProvider(SettingsDao(AppDatabase.instance)),
    ),
  ],
  child: MaterialApp(
    theme: brightness == Brightness.dark ? AppTheme.dark() : AppTheme.light(),
    home: child,
  ),
);

/// Text ka asli background — upar ke ancestors me jo bhi rang mila
/// (Container / Material / DecoratedBox / Scaffold), wahi. Sirf page surface
/// maan lena galat hoga: hero cards (navy F&O card) par light text sahi hai.
Color _effectiveBackground(BuildContext context, Brightness brightness) {
  final theme = brightness == Brightness.dark
      ? AppTheme.dark()
      : AppTheme.light();
  Color? found;

  /// Translucent layer (chip ka 8% white, badge ka 12% tint) apne neeche wale
  /// rang par baithta hai — usko "background" maan lena galat contrast deta
  /// hai, isliye aise layers ko chhod kar aage dekhte hain.
  bool opaque(Color? c) => c != null && c.a > 0.95;

  context.visitAncestorElements((element) {
    final widget = element.widget;
    if (widget is Container && opaque(widget.color)) {
      found = widget.color;
      return false;
    }
    if (widget is Material && opaque(widget.color)) {
      found = widget.color;
      return false;
    }
    if (widget is DecoratedBox) {
      final decoration = widget.decoration;
      if (decoration is BoxDecoration && opaque(decoration.color)) {
        found = decoration.color;
        return false;
      }
    }
    if (widget is Scaffold && widget.backgroundColor != null) {
      found = widget.backgroundColor;
      return false;
    }
    return true;
  });
  return found ?? theme.colorScheme.surface;
}

double _contrast(Color a, Color b) {
  final la = a.computeLuminance();
  final lb = b.computeLuminance();
  final hi = la > lb ? la : lb;
  final lo = la > lb ? lb : la;
  return (hi + 0.05) / (lo + 0.05);
}

void main() {
  final screens = <String, Widget Function()>{
    'Home': () => const HomeHubScreen(),
    'Equity hub': () => const EquityHubScreen(),
    'F&O hub': () => FnoHubScreen(orderStore: _MemOrder()),
    'FAQ (equity)': () =>
        const ToolFaqScreen(title: 'Equity · FAQ', entries: kEquityFaq),
    'FAQ (F&O)': () =>
        const ToolFaqScreen(title: 'F&O · FAQ', entries: kFnoFaq),
    'Builder': () => const StrategyBuilderScreen(),
    'Builder report': () => const StrategyReportScreen(),
    'IV Spike': () => const IvSpikeScreen(),
    'IV Crush': () => const IvSpikeScreen(mode: IvChangeMode.crush),
    'Extra hub': () => const ExtraHubScreen(),
    'FAQ (extra)': () =>
        const ToolFaqScreen(title: 'Extra · FAQ', entries: kExtraFaq),
  };

  for (final entry in screens.entries) {
    for (final brightness in Brightness.values) {
      testWidgets('${entry.key} · ${brightness.name} — render + contrast', (
        tester,
      ) async {
        await tester.pumpWidget(_host(entry.value(), brightness));
        await tester.pump(const Duration(milliseconds: 400));
        expect(tester.takeException(), isNull);

        final theme = brightness == Brightness.dark
            ? AppTheme.dark()
            : AppTheme.light();
        final scheme = theme.colorScheme;

        // 1. Page background theme ke hisaab se.
        final scaffolds = tester.widgetList<Scaffold>(find.byType(Scaffold));
        expect(scaffolds, isNotEmpty);
        for (final scaffold in scaffolds) {
          final bg = scaffold.backgroundColor ?? theme.scaffoldBackgroundColor;
          if (brightness == Brightness.dark) {
            expect(
              bg.computeLuminance(),
              lessThan(0.12),
              reason:
                  '${entry.key}: dark mode me background safed nahi hona '
                  'chahiye (mila $bg)',
            );
          } else {
            expect(
              bg.computeLuminance(),
              greaterThan(0.75),
              reason:
                  '${entry.key}: light mode me background halka hona '
                  'chahiye (mila $bg)',
            );
          }
        }

        // 2. Har Text ka colour uske page background par readable ho.
        var checked = 0;
        for (final element in find.byType(Text).evaluate()) {
          final text = element.widget as Text;
          final data = text.data;
          if (data == null || data.trim().isEmpty) continue;
          // Text par color na ho to asli rang **DefaultTextStyle** ka hota hai
          // (FilledButton apne label ko theme ka onPrimary deta hai) — seedha
          // onSurface maan lena galat contrast deta hai (1.5.102).
          var color = text.style?.color;
          if (color == null) {
            element.visitAncestorElements((ancestor) {
              final w = ancestor.widget;
              if (w is DefaultTextStyle) {
                color = w.style.color;
                return false;
              }
              return true;
            });
          }
          final ink = color ?? scheme.onSurface;
          if (ink.a < 1.0) continue;
          final bg = _effectiveBackground(element, brightness);
          expect(
            _contrast(ink, bg),
            greaterThan(3.0),
            reason:
                '${entry.key} · ${brightness.name}: "$data" ka colour '
                '(=$ink) uske background ($bg) par nahi dikhta',
          );
          checked++;
        }
        expect(
          checked,
          greaterThan(3),
          reason: 'kuch text check hua hi nahi — test bekaar hai',
        );
      });
    }
  }
}
