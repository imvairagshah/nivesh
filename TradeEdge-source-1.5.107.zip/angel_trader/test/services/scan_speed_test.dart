// 1.5.95 — scan speed: parallel pool + delta fetch + split guard.
//
// Pin hota hai:
//   • pool order (results[i] ↔ items[i]) aur concurrency limit,
//   • cancel hone par aadha result (null slots) — crash nahi,
//   • delta merge (dedupe, naya jeetta hai),
//   • split/bonus guard: bada jump = poora window dobara (accuracy par
//     samjhauta nahi),
//   • loader: stale cache par sirf tail maangta hai, aur poore window par
//     fallback karta hai jab guard bole.

import 'package:angel_trader/core/utils/parallel_pool.dart';
import 'package:angel_trader/data/local/dao/candle_dao.dart';
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/services/bars_delta.dart';
import 'package:angel_trader/services/candle_source.dart';
import 'package:angel_trader/services/daily_bars_loader.dart';
import 'package:flutter_test/flutter_test.dart';

Candle bar(DateTime day, double close, {double? open}) => Candle(
  time: day,
  open: open ?? close,
  high: close,
  low: close,
  close: close,
  volume: 1000,
);

Scrip scrip(String symbol) =>
    Scrip(token: '1', symbol: symbol, name: symbol, exchange: Exchange.nse);

/// Network ka fake — kitni calls aur kaunse window maange gaye, sab record.
class FakeSource implements CandleSource {
  FakeSource(this.onFetch);

  final List<Candle> Function(DateTime from, DateTime to) onFetch;
  final List<DateTime> froms = [];

  int get calls => froms.length;

  @override
  Future<List<Candle>> fetchDailyCandles({
    required Scrip scrip,
    required DateTime from,
    required DateTime to,
    String interval = 'ONE_DAY',
  }) async {
    froms.add(from);
    return onFetch(from, to);
  }
}

/// CandleDao ka fake — sirf jo loader padhta/likhta hai.
class FakeCandles // ignore: must_be_immutable
    implements CandleDao {
  FakeCandles(this._bars);
  List<Candle> _bars;
  int saves = 0;

  @override
  Future<List<Candle>> barsFor({
    required String exchange,
    required String symbol,
    String interval = CandleDao.dailyInterval,
    DateTime? from,
    DateTime? to,
  }) async => [
    for (final b in _bars)
      if (b.time.isBefore(to ?? DateTime(2100))) b,
  ];

  @override
  Future<int> saveBars({
    required String exchange,
    required String symbol,
    required List<Candle> bars,
    String interval = CandleDao.dailyInterval,
    bool replaceWindow = false,
    DateTime? windowFrom,
    DateTime? windowTo,
  }) async {
    saves++;
    _bars = bars;
    return bars.length;
  }

  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

void main() {
  group('mapPool', () {
    test('order input ka rehta hai, chahe latencies ulti hon', () async {
      final out = await mapPool<int, int>(
        items: [0, 1, 2, 3, 4, 5],
        concurrency: 3,
        action: (i, v) async {
          await Future<void>.delayed(Duration(milliseconds: (6 - v) * 5));
          return v * 10;
        },
      );
      expect(out, [0, 10, 20, 30, 40, 50]);
    });

    test('concurrency limit kabhi cross nahi hota', () async {
      var live = 0;
      var peak = 0;
      await mapPool<int, int>(
        items: List.generate(20, (i) => i),
        concurrency: 3,
        action: (i, v) async {
          live++;
          peak = live > peak ? live : peak;
          await Future<void>.delayed(const Duration(milliseconds: 5));
          live--;
          return v;
        },
      );
      expect(peak, lessThanOrEqualTo(3));
      expect(peak, greaterThan(1)); // sach me parallel chala
    });

    test('cancel → jitne ho gaye, baaki null (crash nahi)', () async {
      var done = 0;
      final out = await mapPool<int, int>(
        items: List.generate(50, (i) => i),
        concurrency: 3,
        isCancelled: () => done >= 6,
        action: (i, v) async {
          done++;
          return v;
        },
      );
      expect(out.whereType<int>().length, lessThan(50));
      expect(out.length, 50);
    });

    test('khaali list → khaali', () async {
      expect(
        await mapPool<int, int>(
          items: const [],
          concurrency: 3,
          action: (i, v) async => v,
        ),
        isEmpty,
      );
    });
  });

  group('bars delta merge', () {
    final d1 = DateTime(2026, 11, 1);
    final d2 = DateTime(2026, 11, 2);
    final d3 = DateTime(2026, 11, 3);

    test('purane + naye jude, date se dedupe (naya jeetta)', () {
      final cached = [bar(d1, 100), bar(d2, 101)];
      final fresh = [bar(d2, 999), bar(d3, 102)]; // d2 update hua
      final m = mergeBars(cached: cached, fresh: fresh);
      expect(m.bars.map((b) => b.close).toList(), [100, 999, 102]);
      expect(m.added, 1); // sirf d3 naya
      expect(m.suspicious, isFalse);
    });

    test('split jaisa jump → suspicious (poora window dobara)', () {
      final cached = [bar(d1, 1000), bar(d2, 1000)];
      final fresh = [bar(d3, 200)]; // 1:5 split
      expect(
        isSplitSuspicious(cached: cached, fresh: fresh, limit: 0.25),
        isTrue,
      );
    });

    test('roz ka normal move suspicious nahi', () {
      final cached = [bar(d1, 1000)];
      final fresh = [bar(d2, 1050)]; // +5%
      expect(isSplitSuspicious(cached: cached, fresh: fresh), isFalse);
    });

    test('khaali inputs → crash nahi, suspicious false', () {
      expect(isSplitSuspicious(cached: const [], fresh: const []), isFalse);
      expect(mergeBars(cached: const [], fresh: const []).bars, isEmpty);
    });
  });

  group('DailyBarsLoader — delta fetch', () {
    final today = DateTime(2026, 11, 13);
    List<Candle> history(DateTime end, {double base = 100}) => [
      for (var i = 0; i < 260; i++)
        bar(
          DateTime(
            end.year,
            end.month,
            end.day,
          ).subtract(Duration(days: 260 - i)),
          base + i * 0.1,
        ),
    ];

    test('stale cache (10 din purana) → sirf tail maangta hai', () async {
      final candles = history(today.subtract(const Duration(days: 10)));
      final dao = FakeCandles(candles);
      final source = FakeSource(
        (from, to) => [bar(today.subtract(const Duration(days: 2)), 130)],
      );
      final loader = DailyBarsLoader(
        source: source,
        candles: dao,
        minimumBars: 205,
      );

      final bars = await loader.barsFor(scrip('TCS'), today);

      expect(source.calls, 1);
      // Poora 400-din window NAHI maanga — tail hi.
      final askedFrom = source.froms.single;
      expect(today.difference(askedFrom).inDays, lessThan(30));
      expect(bars.bars.length, greaterThan(255));
      expect(bars.usedCache, isTrue);
      expect(dao.saves, 1);
    });

    test('split jaisa jump → poora window dobara maangta hai', () async {
      final candles = history(today.subtract(const Duration(days: 10)));
      final dao = FakeCandles(candles);
      var call = 0;
      final source = FakeSource((from, to) {
        call++;
        if (call == 1) return [bar(today, 20)]; // 100 → 20 (split)
        return history(today, base: 20); // poora naya window
      });
      final loader = DailyBarsLoader(
        source: source,
        candles: dao,
        minimumBars: 205,
      );

      final bars = await loader.barsFor(scrip('TCS'), today);

      expect(source.calls, 2); // tail + full refetch
      expect(today.difference(source.froms.last).inDays, greaterThan(300));
      expect(bars.bars.last.close, closeTo(20 + 259 * 0.1, 0.001));
    });

    test('cache 60 din se purana → delta skip, poora window', () async {
      final candles = history(today.subtract(const Duration(days: 90)));
      final dao = FakeCandles(candles);
      final source = FakeSource((from, to) => history(today));
      final loader = DailyBarsLoader(
        source: source,
        candles: dao,
        minimumBars: 205,
      );

      await loader.barsFor(scrip('TCS'), today);

      expect(source.calls, 1);
      expect(today.difference(source.froms.single).inDays, greaterThan(300));
    });

    test('deltaFetch off → purana behaviour (poora window)', () async {
      final candles = history(today.subtract(const Duration(days: 10)));
      final dao = FakeCandles(candles);
      final source = FakeSource((from, to) => history(today));
      final loader = DailyBarsLoader(
        source: source,
        candles: dao,
        minimumBars: 205,
        deltaFetch: false,
      );

      await loader.barsFor(scrip('TCS'), today);
      expect(today.difference(source.froms.single).inDays, greaterThan(300));
    });
  });
}
