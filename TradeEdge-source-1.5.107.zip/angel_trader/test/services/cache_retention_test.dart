// ---------------------------------------------------------------------------
// cache_retention_test.dart — 1.5.107 \"cache/speed module ke baaki kaam\".
//
// Pin hota hai (jo pehle galat ya missing tha):
//   1. `scan_runs` delete nahi hote the — ab pruneRuns/sweep ka date cut hai,
//      aur aaj ka run kabhi nahi hatna chahiye.
//   2. `price_cache` sirf IPO likhta tha — ab writer `EXCHANGE:SYMBOL` par
//      close/quote dono likhta hai, 0/NaN kabhi nahi.
//   3. Retention ka ek hi source: 700 din par prune karna Builder ka
//      5-saal window uda deta tha (bug). Ab `CacheRetention.candleDays`.
//   4. IV Spike ka result cache: din-wise save + reload (fresh scan dobara
//      nahi), aur mode/threshold badalne par wahi din use hota hai.
//   5. Greeks cache: ek hi din me wahi underlying+expiry dobara nahi maanga
//      jaata, par **fail/khali** batch cache nahi hota.
//   6. F&O Scanner: 7 din se purana cache \"cached\" ban kar nahi dikhta.
//   7. Strategy Builder report cache: report + strategy wapas.
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/scan_cache_dao.dart';
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/data/remote/dto/quote.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/features/fno/iv_spike/iv_result_cache.dart';
import 'package:angel_trader/features/fno/iv_spike/iv_spike_engine.dart';
import 'package:angel_trader/features/fno/study/iv_sheet.dart';
import 'package:angel_trader/features/strategy_builder/strategy_engine.dart';
import 'package:angel_trader/features/strategy_builder/strategy_rules.dart';
import 'package:angel_trader/services/greeks_cache.dart';
import 'package:angel_trader/services/price_cache_writer.dart';
import 'package:angel_trader/services/study_market_data.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

Scrip scrip(String symbol, {Exchange exchange = Exchange.nse, String? token}) =>
    Scrip(
      token: token ?? '1',
      symbol: symbol,
      name: symbol,
      exchange: exchange,
    );

Candle bar(DateTime day, double close) => Candle(
  time: day,
  open: close,
  high: close,
  low: close,
  close: close,
  volume: 1000,
);

/// Greeks ka fake — kitni baar asli call lagi, wo count karta hai.
class FakeMarket implements StudyMarketData {
  FakeMarket({this.iv = 28.5, this.fail = false});

  double iv;
  bool fail;
  int greeksCalls = 0;

  @override
  Future<Map<String, MarketQuote>> fetchQuotesFull(List<Scrip> scrips) async =>
      const {};

  @override
  Future<OptionGreekBatch> fetchOptionGreeks({
    required String underlying,
    required String expiryLabel,
  }) async {
    greeksCalls++;
    if (fail) {
      return const OptionGreekBatch(byStrike: {}, error: 'endpoint down');
    }
    return OptionGreekBatch(
      byStrike: {
        '100.00|CE': iv,
        '100.00|PE': iv,
      },
    );
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;

  late AppDatabase db;
  late ScanCacheDao cache;

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close();
    db = AppDatabase.instance;
    cache = ScanCacheDao(db);
  });

  tearDown(() async {
    await AppDatabase.instance.close();
  });

  group('retention (ek hi source)', () {
    test('candleDays kabhi 700 se kam nahi (Builder ka 5-saal window)', () {
      expect(CacheRetention.candleDays, greaterThanOrEqualTo(700));
      expect(
        CacheRetention.candleDays,
        CacheRetention.builderYears * 365 + CacheRetention.builderWarmupDays,
      );
      // 700 par prune karna hi bug tha — 5 saal se chhota nahi hona chahiye.
      expect(CacheRetention.candleDays, greaterThan(700));
    });

    test('purane scan_runs hate hain, aaj ka nada', () async {
      final now = DateTime(2026, 10, 3);
      await cache.saveRun(kind: ScanKind.rsi, asOf: '2026-01-01', rows: []);
      await cache.saveRun(kind: ScanKind.rsi, asOf: '2026-09-30', rows: []);
      await cache.saveRun(kind: ScanKind.rsi, asOf: '2026-10-03', rows: []);

      final removed = await cache.pruneRuns(
        before: now.subtract(const Duration(days: CacheRetention.scanRunDays)),
      );
      expect(removed, 1); // sirf 2026-01-01
      expect(await cache.runCount(), 2);
      // 30 din ke andar wala run bacha rehta hai.
      expect((await cache.latestRun(ScanKind.rsi))?.asOf, '2026-10-03');
    });

    test('sweep purane prices bhi hata deta hai', () async {
      final now = DateTime(2026, 10, 3);
      await cache.savePrices({
        'NSE:OLD': PricedValue(
          value: 100,
          asOf: now.subtract(const Duration(days: 30)),
        ),
        'NSE:NEW': PricedValue(value: 200, asOf: now),
      });
      final result = await cache.sweep(now: now);
      expect(result.prices, 1);
      final prices = await cache.loadPrices();
      expect(prices.keys, ['NSE:NEW']);
    });
  });

  group('price cache (ab sab scanners)', () {
    test('close likhta hai — key EXCHANGE:SYMBOL, asOf us bar ka din', () async {
      final writer = PriceCacheWriter(cache);
      await writer.saveCloses([
        (scrip: scrip('SBIN'), last: bar(DateTime(2026, 10, 1), 812.4)),
        (scrip: scrip('TCS'), last: bar(DateTime(2026, 10, 1), 3450)),
      ]);
      final prices = await cache.loadPrices();
      expect(prices['NSE:SBIN']!.value, 812.4);
      expect(prices['NSE:TCS']!.value, 3450);
      expect(prices['NSE:SBIN']!.asOf, DateTime(2026, 10, 1));
      // Cache ka price hamesha cached hota hai — live nahi.
      expect(prices['NSE:SBIN']!.isLive, isFalse);
    });

    test('0 / NaN close cache nahi hota (jhooth nahi)', () async {
      final writer = PriceCacheWriter(cache);
      await writer.saveCloses([
        (scrip: scrip('ZERO'), last: bar(DateTime(2026, 10, 1), 0)),
        (
          scrip: scrip('NAN'),
          last: bar(DateTime(2026, 10, 1), double.nan),
        ),
      ]);
      expect(await cache.priceCount(), 0);
    });

    test('cached() purana price reject karta hai (7 din)', () async {
      final clock = DateTime(2026, 10, 3);
      final writer = PriceCacheWriter(cache, clock: () => clock);
      await cache.savePrices({
        'NSE:OLD': PricedValue(
          value: 500,
          asOf: clock.subtract(const Duration(days: 20)),
        ),
        'NSE:FRESH': PricedValue(value: 600, asOf: clock),
      });
      expect(await writer.cached('NSE', 'OLD'), isNull);
      expect((await writer.cached('NSE', 'FRESH'))!.value, 600);
    });
  });

  group('IV result cache', () {
    test('save → load: IV + source + strike wapas (guess nahi)', () async {
      final ivCache = IvResultCache(cache);
      await ivCache.save(
        asOf: DateTime(2026, 10, 2),
        today: {
          'SBIN': const TodayIv(
            symbol: 'SBIN',
            iv: 34.5,
            source: IvTodaySource.broker,
            strike: 800,
            expiryLabel: '30OCT2026',
            daysToExpiry: 27,
          ),
          'TCS': const TodayIv(
            symbol: 'TCS',
            source: IvTodaySource.none,
            note: 'expiry day — IV meaningless',
          ),
        },
      );

      final loaded = await ivCache.load();
      expect(loaded, isNotNull);
      expect(loaded!.asOf, DateTime(2026, 10, 2));
      expect(loaded.today['SBIN']!.iv, 34.5);
      expect(loaded.today['SBIN']!.source, IvTodaySource.broker);
      expect(loaded.today['SBIN']!.strike, 800);
      expect(loaded.today['SBIN']!.expiryLabel, '30OCT2026');
      // Na mile to null — 0 nahi.
      expect(loaded.today['TCS']!.iv, isNull);
      expect(loaded.today['TCS']!.source, IvTodaySource.none);
      expect(loaded.today['TCS']!.note, contains('expiry day'));
    });

    test('wahi din dobara save karne par replace (duplicate nahi)', () async {
      final ivCache = IvResultCache(cache);
      final day = DateTime(2026, 10, 2);
      await ivCache.save(
        asOf: day,
        today: {'SBIN': const TodayIv(symbol: 'SBIN', iv: 30)},
      );
      await ivCache.save(
        asOf: day,
        today: {'SBIN': const TodayIv(symbol: 'SBIN', iv: 33)},
      );
      expect(await cache.runCount(), 1);
      final loaded = await ivCache.load();
      expect(loaded!.today['SBIN']!.iv, 33);
    });

    test('cache se rows bante hain (screen turant kuch dikhaye)', () async {
      final ivCache = IvResultCache(cache);
      await ivCache.save(
        asOf: DateTime(2026, 10, 2),
        today: {
          'SBIN': const TodayIv(symbol: 'SBIN', iv: 36),
          'TCS': const TodayIv(symbol: 'TCS', iv: 20),
        },
      );
      final loaded = (await ivCache.load())!;
      final result = IvSpikeEngine.build(
        today: loaded.today,
        // Sheet ya snapshot me kal ka base na ho to engine row nahi banata —
        // isliye bootstrap tab fresh scan chalata hai (khaali table nahi).
        sheet: {
          'SBIN': const IvSheetRow(iv: 30, ivp: 70, ivr: 65),
          'TCS': const IvSheetRow(iv: 18, ivp: 40, ivr: 35),
        },
        snapshot: const {},
        asOf: loaded.asOf!,
        minChangePct: 0,
      );
      expect(result.rows.length, 2);
      expect(result.rows.every((r) => r.todayIv != null), isTrue);
      // SBIN 30 → 36 = +20% spike.
      final sbin = result.rows.firstWhere((r) => r.symbol == 'SBIN');
      expect(sbin.changePct, closeTo(20, 0.001));
    });
  });

  group('greeks cache (ek din)', () {
    test('same underlying+expiry doosri baar network par nahi jaata', () async {
      final inner = FakeMarket();
      final cached = GreeksCache(inner);
      final first = await cached.fetchOptionGreeks(
        underlying: 'SBIN',
        expiryLabel: '30OCT2026',
      );
      final second = await cached.fetchOptionGreeks(
        underlying: 'SBIN',
        expiryLabel: '30OCT2026',
      );
      expect(inner.greeksCalls, 1);
      expect(cached.hits, 1);
      expect(second.ivFor(100, 'CE'), first.ivFor(100, 'CE'));
    });

    test('fail hua batch cache nahi hota — agli baar phir koshish', () async {
      final inner = FakeMarket(fail: true);
      final cached = GreeksCache(inner);
      await cached.fetchOptionGreeks(
        underlying: 'SBIN',
        expiryLabel: '30OCT2026',
      );
      inner.fail = false;
      final second = await cached.fetchOptionGreeks(
        underlying: 'SBIN',
        expiryLabel: '30OCT2026',
      );
      expect(inner.greeksCalls, 2);
      expect(second.byStrike, isNotEmpty);
    });

    test('naya din = naya call (kal ka greek aaj use nahi hota)', () async {
      final inner = FakeMarket();
      var now = DateTime(2026, 10, 2, 10);
      final cached = GreeksCache(inner, clock: () => now);
      await cached.fetchOptionGreeks(
        underlying: 'SBIN',
        expiryLabel: '30OCT2026',
      );
      now = DateTime(2026, 10, 3, 10);
      await cached.fetchOptionGreeks(
        underlying: 'SBIN',
        expiryLabel: '30OCT2026',
      );
      expect(inner.greeksCalls, 2);
    });
  });

  group('strategy builder report cache', () {
    test('BacktestResult JSON round-trip (report wapas bane)', () {
      final result = BacktestResult(
        trades: [
          StrategyTrade(
            symbol: 'SBIN',
            entryIndex: 5,
            exitIndex: 9,
            entryDate: DateTime(2026, 1, 5),
            exitDate: DateTime(2026, 1, 15),
            entryPrice: 600,
            exitPrice: 630,
            returnPct: 5,
            netPct: 4.65,
            bars: 4,
            reason: 'target',
            maePct: -1.2,
            mfePct: 6.1,
          ),
        ],
        skips: [StrategySkip('XYZ', 'candles nahi mile')],
        equity: [1, 1.02, 1.05],
        equityDates: [
          DateTime(2026, 1, 1),
          DateTime(2026, 1, 2),
          DateTime(2026, 1, 3),
        ],
        benchmark: [1, 1.01, 1.03],
        benchmarkDates: [
          DateTime(2026, 1, 1),
          DateTime(2026, 1, 2),
          DateTime(2026, 1, 3),
        ],
        monthly: {'2026-01': 1.5},
        stats: const BacktestStats(
          trades: 1,
          winRate: 100,
          avgTrade: 4.65,
          medianTrade: 4.65,
          avgWin: 4.65,
          avgLoss: 0,
          profitFactor: 9,
          avgBars: 4,
          maxDrawdownPct: -1.2,
          totalReturnPct: 5,
          expectancyPct: 4.65,
          niftyReturnPct: 1.1,
        ),
        skippedTrades: 2,
        windowStart: DateTime(2021, 1, 1),
        windowEnd: DateTime(2026, 1, 1),
        symbolsScanned: 200,
      );

      final back = BacktestResult.fromJson(result.toJson());
      expect(back.trades.single.symbol, 'SBIN');
      expect(back.trades.single.entryDate, DateTime(2026, 1, 5));
      expect(back.trades.single.netPct, 4.65);
      expect(back.trades.single.reason, 'target');
      expect(back.skips.single.symbol, 'XYZ');
      expect(back.equity, [1, 1.02, 1.05]);
      expect(back.equityDates.length, 3);
      expect(back.stats.winRate, 100);
      expect(back.stats.niftyReturnPct, 1.1);
      expect(back.windowStart, DateTime(2021, 1, 1));
      expect(back.symbolsScanned, 200);
    });

    test('report + strategy scan_runs me jaate hain aur wapas aate hain', () async {
      final strategy = tripleRsiPreset().copyWith(name: 'Mera test');
      await cache.saveRun(
        kind: ScanKind.strategyBuilder,
        asOf: '2026-10-02',
        rows: [
          {
            'asOf': '2026-10-02',
            'strategy': strategy.toJson(),
            'result': {'stats': {'trades': 42, 'winRate': 55.5}},
          },
        ],
      );
      final run = await cache.latestRun(ScanKind.strategyBuilder);
      expect(run!.asOf, '2026-10-02');
      final payload = run.rows.first;
      final restored = Strategy.fromJson(
        Map<String, dynamic>.from(payload['strategy'] as Map),
      );
      expect(restored.name, 'Mera test');
      expect(restored.entry.length, strategy.entry.length);
      final result = BacktestResult.fromJson(
        Map<String, dynamic>.from(payload['result'] as Map),
      );
      expect(result.stats.trades, 42);
      expect(result.stats.winRate, 55.5);
    });
  });
}
