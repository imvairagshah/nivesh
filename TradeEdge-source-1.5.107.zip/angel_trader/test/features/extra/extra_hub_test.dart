// ---------------------------------------------------------------------------
// extra_hub_test.dart — EXTRA section (1.5.101) ka contract.
//
// User: *"Telegram channel wala option equity aur fno jaise ek alag section
// bana do, jisme aisi extra cheezein set kar sake."*
//
// Pin hota hai:
//   1. har extra tile ka FAQ entry hai (aur ek-ek hi) — 1.5.97 ka rule;
//   2. tiles barabar height ke hain aur description-free (icon + naam);
//   3. Telegram (Calls Board) ab Equity grid me nahi hai — sirf EXTRA me;
//   4. naye item add karne par test khud bata deta hai ki FAQ/section chhoot
//      raha hai.
// ---------------------------------------------------------------------------

import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/features/equity/equity_hub_screen.dart';
import 'package:angel_trader/features/extra/extra_hub_config.dart';
import 'package:angel_trader/features/extra/extra_hub_screen.dart';
import 'package:angel_trader/features/help/tool_faq.dart';
import 'package:angel_trader/features/settings/settings_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';

Widget host(Widget child) => ChangeNotifierProvider<SettingsProvider>(
  create: (_) => SettingsProvider(SettingsDao(AppDatabase.instance)),
  child: MaterialApp(home: child),
);

void main() {
  group('EXTRA config + FAQ', () {
    test('har extra tile ka FAQ entry hai (aur ek-ek hi)', () {
      final titles = kExtraFaq.map((e) => e.title).toList();
      for (final tool in kExtraTools) {
        expect(titles, contains(tool.title), reason: tool.title);
      }
      expect(
        titles.toSet(),
        hasLength(titles.length),
        reason: 'duplicate nahi',
      );
      expect(kExtraFaq, hasLength(kExtraTools.length));
    });

    test('Telegram Channels EXTRA me hai, Equity me nahi', () {
      expect(kExtraTools.map((t) => t.title), contains('Telegram Channels'));
      expect(kEquityTools.map((t) => t.title), isNot(contains('Calls Board')));
      // Purana FAQ entry bhi Equity list se hata — warna duplicate hota.
      expect(kEquityFaq.map((e) => e.title), isNot(contains('Calls Board')));
      expect(kExtraFaq.map((e) => e.title), contains('Telegram Channels'));
    });

    test('ids unique hain (route switch ke liye)', () {
      final ids = kExtraTools.map((t) => t.id).toList();
      expect(ids.toSet(), hasLength(ids.length));
    });
  });

  group('EXTRA hub screen', () {
    testWidgets('saare items dikhte hain', (tester) async {
      await tester.pumpWidget(host(const ExtraHubScreen()));
      await tester.pumpAndSettle();

      for (final tool in kExtraTools) {
        expect(find.text(tool.title), findsOneWidget, reason: tool.title);
      }
      // Har tile par uska icon.
      for (final tool in kExtraTools) {
        expect(find.byIcon(tool.icon), findsOneWidget, reason: tool.title);
      }
    });

    testWidgets('tiles barabar height ke (1.5.97 ka rule)', (tester) async {
      await tester.pumpWidget(host(const ExtraHubScreen()));
      await tester.pumpAndSettle();

      final heights = tester
          .widgetList<Container>(find.byType(Container))
          .where((c) => c.constraints?.maxHeight == 96)
          .map((c) => (c.constraints!.maxHeight))
          .toSet();
      expect(heights, hasLength(1));
      expect(heights.single, 96);
    });

    testWidgets('FAQ button se EXTRA ka FAQ khulta hai', (tester) async {
      await tester.pumpWidget(host(const ExtraHubScreen()));
      await tester.pumpAndSettle();

      await tester.tap(find.text('FAQ — har extra item ka brief').first);
      await tester.pumpAndSettle();

      expect(find.text('Extra · FAQ'), findsOneWidget);
      expect(find.text('Telegram Channels'), findsOneWidget);
    });
  });
}
