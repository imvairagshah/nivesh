// ---------------------------------------------------------------------------
// tool_faq_test.dart — 1.5.97 ka rule: jo tool grid me hai, uska FAQ entry
// zaroor hai (aur ulta bhi).
//
// User ne kaha tha: "tiles se chhoti description hata do, FAQ bana do jisme
// sabhi tools ka brief ho." Iska matlab ye bhi hai ki koi tool **bina
// bataye** nahi chhoot sakta — naya tool add ho aur FAQ me na aaye to ye test
// fail hoga.
// ---------------------------------------------------------------------------

import 'package:angel_trader/features/equity/equity_hub_screen.dart';
import 'package:angel_trader/features/fno/fno_hub_config.dart';
import 'package:angel_trader/features/help/tool_faq.dart';
import 'package:angel_trader/features/help/tool_faq_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

Widget host(Widget child) => MaterialApp(home: child);

void main() {
  group('FAQ coverage', () {
    test('har equity tool ka FAQ entry hai (aur ek-ek hi)', () {
      final titles = kEquityFaq.map((e) => e.title).toList();
      for (final tool in kEquityTools) {
        expect(titles, contains(tool.title), reason: tool.title);
      }
      expect(
        titles.toSet(),
        hasLength(titles.length),
        reason: 'duplicate FAQ entry nahi',
      );
      expect(kEquityFaq, hasLength(kEquityTools.length));
    });

    test('har F&O tool ka FAQ entry hai (aur ek-ek hi)', () {
      final titles = kFnoFaq.map((e) => e.title).toList();
      for (final tool in kHubTools) {
        expect(titles, contains(tool.title), reason: tool.title);
      }
      expect(titles.toSet(), hasLength(titles.length));
      expect(kFnoFaq, hasLength(kHubTools.length));
    });

    test('har entry me brief + kam se kam teen details hain', () {
      for (final entry in kAllFaq) {
        expect(entry.summary.trim(), isNotEmpty, reason: entry.title);
        expect(
          entry.summary.length,
          greaterThan(40),
          reason: '${entry.title}: brief thoda asli hona chahiye',
        );
        expect(
          entry.points.length,
          greaterThanOrEqualTo(3),
          reason: '${entry.title}: details',
        );
        for (final point in entry.points) {
          expect(point.trim(), isNotEmpty, reason: entry.title);
        }
      }
    });

    test('FAQ koi doosri language ka tukda nahi — sab Hinglish me hai', () {
      // Devanagari script galti se ghus jaye (jaise ek edit ki galti) to pakda
      // jaye; baaki text Hindi/Hinglish roman me hai.
      final devanagari = RegExp(r'[\u0900-\u097F]');
      for (final entry in kAllFaq) {
        expect(
          devanagari.hasMatch(entry.summary),
          isFalse,
          reason: entry.title,
        );
        for (final point in entry.points) {
          expect(devanagari.hasMatch(point), isFalse, reason: entry.title);
        }
      }
    });

    test('formula waale tools ke formulas FAQ me sahi hain', () {
      final magic = kEquityFaq.firstWhere((e) => e.title == 'Magic Formula');
      final text = magic.points.join(' ');
      expect(text, contains('EBIT ÷ (Total Assets − Current Liabilities)'));
      expect(text, contains('EBIT ÷ EV'));
      expect(text, contains('Market Cap + Total Debt − Cash'));
    });
  });

  group('FAQ screen', () {
    testWidgets('har entry ka naam, brief aur details dikhte hain', (
      tester,
    ) async {
      await tester.pumpWidget(
        host(const ToolFaqScreen(title: 'Equity · FAQ', entries: kEquityFaq)),
      );
      await tester.pumpAndSettle();

      for (final entry in kEquityFaq.take(3)) {
        expect(find.text(entry.title), findsOneWidget);
        expect(find.text(entry.summary), findsOneWidget);
      }
    });

    testWidgets('search se sirf matching tool rehta hai', (tester) async {
      await tester.pumpWidget(
        host(const ToolFaqScreen(title: 'F&O · FAQ', entries: kFnoFaq)),
      );
      await tester.pumpAndSettle();

      await tester.enterText(find.byType(TextField), 'dividend');
      await tester.pumpAndSettle();

      expect(find.text('52W · ATH · Dividend'), findsOneWidget);
      expect(find.text('AI Suggestion'), findsNothing);
    });

    testWidgets('kuch match na ho to saaf message', (tester) async {
      await tester.pumpWidget(
        host(const ToolFaqScreen(title: 'F&O · FAQ', entries: kFnoFaq)),
      );
      await tester.pumpAndSettle();

      await tester.enterText(find.byType(TextField), 'zzzz');
      await tester.pumpAndSettle();

      expect(find.text('Is naam ka koi tool nahi mila.'), findsOneWidget);
    });

    testWidgets('hub se FAQ khulta hai — equity', (tester) async {
      await tester.pumpWidget(host(const EquityHubScreen()));
      await tester.pumpAndSettle();

      await tester.tap(find.byIcon(Icons.help_outline_rounded).first);
      await tester.pumpAndSettle();

      expect(find.byType(ToolFaqScreen), findsOneWidget);
      expect(find.text('IPO Screener'), findsWidgets);
    });
  });

  group('1.5.97 — tiles uniform (no description)', () {
    testWidgets('equity tiles sab barabar aur description-free', (
      tester,
    ) async {
      await tester.pumpWidget(host(const EquityHubScreen()));
      await tester.pumpAndSettle();

      // Koi purana blurb text nahi bacha (titles ke alawa).
      final texts = tester
          .widgetList<Text>(find.byType(Text))
          .map((t) => t.data ?? '')
          .toList();
      expect(texts.where((t) => t.contains('listing-day high/low')), isEmpty);
      expect(texts.where((t) => t.contains('Overbought / oversold')), isEmpty);

      // Har tile (InkWell wala fixed-height box) ek hi height ka.
      final heights = tester
          .renderObjectList<RenderBox>(find.byType(InkWell))
          .map((r) => r.size.height.round())
          .where((h) => h >= 90 && h <= 100)
          .toSet();
      expect(
        heights,
        hasLength(1),
        reason: 'equity tiles ki height same honi chahiye',
      );
    });
  });
}
