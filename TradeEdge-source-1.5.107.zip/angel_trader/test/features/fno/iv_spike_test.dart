// ---------------------------------------------------------------------------
// iv_spike_test.dart — 1.5.105 engine + sheet parser.
//
// Pin hota hai (data honesty ke saath):
//   1. kal ka IV sheet ke `iv` column se aata hai, na ho to apne snapshot se,
//      aur source row par saaf likha hota hai;
//   2. spike = aaj − kal > 0 (threshold ke hisaab se), bade spike pehle;
//   3. sheet me `iv` column na ho to kal ka IV **null** rehta hai (guess nahi);
//   4. IVP/IVR sheet se, aur jo stock ka data hi nahi wo missing list me.
// ---------------------------------------------------------------------------

import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/features/fno/iv_spike/iv_spike_engine.dart';
import 'package:angel_trader/features/fno/study/iv_sheet.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

TodayIv today(
  String symbol,
  double? iv, {
  IvTodaySource src = IvTodaySource.broker,
}) => TodayIv(symbol: symbol, iv: iv, source: src);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;

  group('sheet parser (IV column)', () {
    test('iv column milta hai aur IVP/IVR ke saath judta hai', () {
      const csv = '''
symbol,ivp,ivr,iv
SBIN,72,68,34.5
RELIANCE,55,61,22.1
TCS,88,90,
''';
      final parsed = IvSpikeParsersForTest.parse(csv);
      expect(parsed.bySymbol['SBIN']!.iv, 34.5);
      expect(parsed.bySymbol['SBIN']!.ivp, 72);
      expect(parsed.bySymbol['SBIN']!.ivr, 68);
      // Khaali iv cell → null (zero nahi).
      expect(parsed.bySymbol['TCS']!.iv, isNull);
      expect(parsed.bySymbol['TCS']!.ivp, 88);
    });

    test('iv column na ho to base parser jaisa hi (ivp/ivr only)', () {
      const csv = 'symbol,ivp,ivr\nSBIN,72,68\n';
      final parsed = IvSpikeParsersForTest.parse(csv);
      expect(parsed.bySymbol['SBIN']!.iv, isNull);
      expect(parsed.bySymbol['SBIN']!.ivp, 72);
    });

    test('300 se upar ya negative IV kachra maan kar chhod diya jaata hai', () {
      const csv = 'symbol,ivp,ivr,iv\nA,10,10,450\nB,10,10,-5\nC,10,10,45\n';
      final parsed = IvSpikeParsersForTest.parse(csv);
      expect(parsed.bySymbol['A']!.iv, isNull);
      expect(parsed.bySymbol['B']!.iv, isNull);
      expect(parsed.bySymbol['C']!.iv, 45);
    });
  });

  group('engine', () {
    final asOf = DateTime(2026, 11, 18);

    test('spike rows: delta, order aur source label', () {
      final result = IvSpikeEngine.build(
        today: {
          'SBIN': today('SBIN', 40),
          'RELIANCE': today('RELIANCE', 22), // kal se neeche — spike nahi
          'TCS': today('TCS', 30, src: IvTodaySource.blackScholes),
        },
        sheet: {
          'SBIN': const IvSheetRow(ivp: 72, ivr: 68, iv: 30),
          'RELIANCE': const IvSheetRow(ivp: 55, ivr: 61, iv: 24),
        },
        snapshot: {'TCS': 26},
        snapshotAsOf: DateTime(2026, 11, 17),
        asOf: asOf,
      );

      expect(result.rows.map((r) => r.symbol), ['SBIN', 'TCS']);
      final sbin = result.rows.first;
      expect(sbin.change, closeTo(10, 1e-9));
      expect(sbin.changePct!, closeTo(33.33, 0.01));
      expect(sbin.baseline, IvBaselineSource.sheet);
      expect(sbin.ivp, 72);
      expect(sbin.ivr, 68);

      final tcs = result.rows.last;
      expect(tcs.baseline, IvBaselineSource.snapshot);
      expect(tcs.baselineAsOf, DateTime(2026, 11, 17));
      expect(tcs.todaySource, IvTodaySource.blackScholes);
      expect(tcs.change, closeTo(4, 1e-9));

      expect(result.baselineFromSheet, 2);
      expect(result.baselineFromSnapshot, 1);
      expect(result.spikeCount, 2);
    });

    test(
      'sheet me IV column nahi → kal ka IV null, delta null (guess nahi)',
      () {
        final result = IvSpikeEngine.build(
          today: {'SBIN': today('SBIN', 40)},
          sheet: {'SBIN': const IvSheetRow(ivp: 72, ivr: 68)},
          snapshot: const {},
          asOf: asOf,
        );
        final row = result.rows.single;
        expect(row.yesterdayIv, isNull);
        expect(row.change, isNull);
        expect(row.ivp, 72);
        expect(row.baseline, IvBaselineSource.none);
        expect(row.isSpike, isFalse);
      },
    );

    test('threshold: 0 = har badhotri, 5 = sirf 5pp se zyada', () {
      final base = {
        'A': today('A', 30),
        'B': today('B', 40),
        'C': today('C', 42),
      };
      final sheet = {
        'A': const IvSheetRow(iv: 28),
        'B': const IvSheetRow(iv: 30),
        'C': const IvSheetRow(iv: 40),
      };
      final all = IvSpikeEngine.build(
        today: base,
        sheet: sheet,
        snapshot: const {},
        asOf: asOf,
      );
      // Delta: A +2, B +10, C +2 — bada spike pehle, barabar par symbol.
      expect(all.rows.map((r) => r.symbol), ['B', 'A', 'C']);

      final big = IvSpikeEngine.build(
        today: base,
        sheet: sheet,
        snapshot: const {},
        asOf: asOf,
        minChangePct: 5,
      );
      // Threshold ab **%** me hai (1.5.106): A +7.1%, B +33.3%, C +5%.
      // 5% par teeno pass, 10% par sirf B.
      expect(big.rows.map((r) => r.symbol), ['B', 'A', 'C']);
      final strict = IvSpikeEngine.build(
        today: base,
        sheet: sheet,
        snapshot: const {},
        asOf: asOf,
        minChangePct: 10,
      );
      expect(strict.rows.map((r) => r.symbol), ['B']);
    });

    test('jis stock ka kuch bhi nahi, wo missing list me wajah ke saath', () {
      final result = IvSpikeEngine.build(
        today: {'AAA': const TodayIv(symbol: 'AAA', note: 'candles kam (12)')},
        sheet: const {},
        snapshot: const {},
        asOf: asOf,
      );
      expect(result.rows, isEmpty);
      expect(result.missing['AAA'], contains('candles kam'));
    });
  });

  group('1.5.106 — percentage + crush mode', () {
    final asOf = DateTime(2026, 11, 18);

    Map<String, TodayIv> todayMap() => {
      'UP': today('UP', 36), // +20%
      'BIGUP': today('BIGUP', 60), // +50%
      'DOWN': today('DOWN', 20), // −33.3%
      'BIGDOWN': today('BIGDOWN', 18), // −55%
      'FLAT': today('FLAT', 30), // 0%
    };

    Map<String, IvSheetRow> sheetMap() => {
      'UP': const IvSheetRow(iv: 30, ivp: 60, ivr: 55),
      'BIGUP': const IvSheetRow(iv: 40, ivp: 80, ivr: 75),
      'DOWN': const IvSheetRow(iv: 30, ivp: 40, ivr: 45),
      'BIGDOWN': const IvSheetRow(iv: 40, ivp: 30, ivr: 25),
      'FLAT': const IvSheetRow(iv: 30, ivp: 50, ivr: 50),
    };

    test('spike: sabse bada +% upar, sirf badhne wale', () {
      final r = IvSpikeEngine.build(
        today: todayMap(),
        sheet: sheetMap(),
        snapshot: const {},
        asOf: asOf,
      );
      expect(r.rows.map((x) => x.symbol), ['BIGUP', 'UP']);
      expect(r.rows.first.changePct!, closeTo(50, 1e-9));
      expect(r.rows.last.changePct!, closeTo(20, 1e-9));
    });

    test('crush: sabse tez girawat upar, sirf girne wale', () {
      final r = IvSpikeEngine.build(
        today: todayMap(),
        sheet: sheetMap(),
        snapshot: const {},
        asOf: asOf,
        mode: IvChangeMode.crush,
      );
      expect(r.rows.map((x) => x.symbol), ['BIGDOWN', 'DOWN']);
      expect(r.rows.first.changePct!, closeTo(-55, 1e-9));
      expect(r.rows.last.changePct!, closeTo(-33.333, 0.01));
      // Percentage points bhi saath (reference).
      expect(r.rows.first.change!, closeTo(-22, 1e-9));
    });

    test('threshold % me: 25 par sirf 25% se zyada movement', () {
      final spike = IvSpikeEngine.build(
        today: todayMap(),
        sheet: sheetMap(),
        snapshot: const {},
        asOf: asOf,
        minChangePct: 25,
      );
      expect(spike.rows.map((x) => x.symbol), ['BIGUP']);

      // Crush: BIGDOWN −55%, DOWN −33.3%. 25% par dono, 40% par sirf BIGDOWN.
      final crush = IvSpikeEngine.build(
        today: todayMap(),
        sheet: sheetMap(),
        snapshot: const {},
        asOf: asOf,
        mode: IvChangeMode.crush,
        minChangePct: 25,
      );
      expect(crush.rows.map((x) => x.symbol), ['BIGDOWN', 'DOWN']);

      final crushStrict = IvSpikeEngine.build(
        today: todayMap(),
        sheet: sheetMap(),
        snapshot: const {},
        asOf: asOf,
        mode: IvChangeMode.crush,
        minChangePct: 40,
      );
      expect(crushStrict.rows.map((x) => x.symbol), ['BIGDOWN']);
    });
  });

  group('snapshot store', () {
    test('save → previousBefore pichhla din deta hai (aaj nahi)', () async {
      final store = IvSnapshotStore(SettingsDao(AppDatabase.instance));
      final today = DateTime(2026, 11, 18);
      await store.save(today, {'A': 30.5});
      await store.save(DateTime(2026, 11, 17), {'A': 28});
      final prev = await store.previousBefore(today);
      expect(prev, isNotNull);
      expect(prev!.values['A'], 28);
      expect(prev.day, DateTime(2026, 11, 17));
    });
  });
}

/// Chhota alias taaki test me poora class path na likhna pade.
abstract final class IvSpikeParsersForTest {
  static ({Map<String, IvSheetRow> bySymbol, DateTime? asOf}) parse(
    String csv,
  ) => IvSpikeEngine.parseSheetWithIv(csv);
}
