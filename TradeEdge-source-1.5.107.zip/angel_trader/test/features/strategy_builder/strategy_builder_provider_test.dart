// ---------------------------------------------------------------------------
// strategy_builder_provider_test.dart — wiring ka test (engine test se alag).
//
// Yahan asli network nahi chalta: ek fake CandleSource sirf apne 3 stocks ke
// candles deta hai. Pin hota hai:
//   1. universe resolve + run → trades/equity/benchmark report ban jaati hai;
//   2. jo stock candles nahi deta wo **skip** list me wajah ke saath aata hai
//      (chupchaap gayab nahi hota);
//   3. cost 0 par warning aati hai (data honesty);
//   4. save → load round-trip settings table se hota hai;
//   5. share string wapas import hoti hai, galat string par crash nahi.
// ---------------------------------------------------------------------------

import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/candle_dao.dart';
import 'package:angel_trader/data/local/dao/ipo_dao.dart';
import 'package:angel_trader/data/local/dao/scrip_dao.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/features/strategy_builder/strategy_builder_provider.dart';
import 'package:angel_trader/core/utils/csv_io.dart';
import 'package:angel_trader/features/strategy_builder/strategy_export.dart';
import 'package:angel_trader/features/strategy_builder/strategy_rules.dart';
import 'package:angel_trader/services/candle_source.dart';
import 'package:angel_trader/services/universe_catalog.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

/// Teen stocks: do chalte hain, teesra throw karta hai (skip case).
class _FakeSource implements CandleSource {
  _FakeSource();

  final Set<String> failSymbols = const {'BAD-EQ'};
  int calls = 0;

  @override
  Future<List<Candle>> fetchDailyCandles({
    required Scrip scrip,
    required DateTime from,
    required DateTime to,
    String interval = 'ONE_DAY',
  }) async {
    calls++;
    if (failSymbols.contains(scrip.symbol)) {
      throw StateError('network down');
    }
    // 500 trading din (weekends skip), ~0.08% daily chadhai.
    final out = <Candle>[];
    var d = DateTime(2024, 1, 1);
    var i = 0;
    while (out.length < 520) {
      if (d.weekday != DateTime.saturday && d.weekday != DateTime.sunday) {
        final close = 100 * (1 + 0.0008 * i);
        out.add(
          Candle(
            time: DateTime(d.year, d.month, d.day, 15, 30),
            open: close * 0.999,
            high: close * 1.004,
            low: close * 0.996,
            close: close,
            volume: 100000 + i,
          ),
        );
        i++;
      }
      d = d.add(const Duration(days: 1));
    }
    return out;
  }
}

Scrip scrip(String symbol) => Scrip(
  token: symbol.hashCode.toString(),
  symbol: symbol,
  name: symbol.replaceAll('-EQ', ''),
  exchange: Exchange.nse,
);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;

  late AppDatabase db;
  late StrategyBuilderProvider provider;

  Future<void> seed(ScripDao dao) async {
    await dao.replaceAll([
      for (final s in ['AAA-EQ', 'BBB-EQ', 'BAD-EQ']) scrip(s),
    ]);
  }

  setUp(() async {
    db = AppDatabase.instance;
    final scripDao = ScripDao(db);
    await seed(scripDao);
    provider = StrategyBuilderProvider(
      source: _FakeSource(),
      candles: CandleDao(db),
      scripDao: scripDao,
      ipoDao: IpoDao(db),
      settingsDao: SettingsDao(db),
      clock: () => DateTime(2026, 10, 1),
    );
  });

  group('universe + run', () {
    test('nifty50 universe resolve hota hai aur report banti hai', () async {
      // Nifty 50 list me hamare fake naam nahi hote — isliye master_nse par
      // chalta hai (local scrip master se).
      provider.setUniverse(UniverseCatalog.masterNse);
      provider.loadPreset(
        tripleRsiPreset().copyWith(
          universeKey: UniverseCatalog.masterNse,
          entry: const [
            Rule(indicator: Indicator.price, op: RuleOp.gt, value: 0),
          ],
          settings: const StrategySettings(minBars: 60, costPct: 0),
        ),
      );

      final estimate = await provider.estimate();
      expect(estimate.symbols, greaterThanOrEqualTo(3));

      await provider.run();

      expect(provider.status, BuilderStatus.ready);
      final r = provider.result!;
      expect(r.equity, isNotEmpty);
      expect(r.benchmark.length, r.equity.length);
      expect(
        r.trades,
        isNotEmpty,
        reason: 'hamesha entry wala rule trades dega',
      );
      // Failing stock skip list me hai, chupchaap gayab nahi hua.
      expect(r.skips.map((s) => s.symbol), contains('BAD'));
      expect(r.skips.first.reason, contains('candles nahi mile'));
    });

    test('cost 0 par warning aati hai, cancel par run rukta hai', () async {
      provider.setUniverse(UniverseCatalog.masterNse);
      provider.update(
        provider.strategy.copyWith(
          universeKey: UniverseCatalog.masterNse,
          settings: const StrategySettings(minBars: 60, costPct: 0),
        ),
      );
      await provider.run();
      expect(provider.warnings().any((w) => w.contains('Cost 0%')), isTrue);

      provider.cancel(); // run ke baad cancel no-op hai — crash nahi hota
      expect(provider.status, BuilderStatus.ready);
    });
  });

  group('save / load / share', () {
    test('save hone ke baad loadSaved wapas laata hai', () async {
      provider.loadPreset(
        tripleRsiPreset()
            .copyWith(name: 'Meri Strategy')
            .copyWith(settings: const StrategySettings(maxPositions: 7)),
      );
      await provider.saveCurrent();

      final fresh = StrategyBuilderProvider(
        source: _FakeSource(),
        candles: CandleDao(db),
        scripDao: ScripDao(db),
        ipoDao: IpoDao(db),
        settingsDao: SettingsDao(db),
      );
      await fresh.loadSaved();
      expect(
        fresh.saved.map((s) => s.strategy.name),
        contains('Meri Strategy'),
      );
      expect(fresh.strategy.settings.maxPositions, 7);
    });

    test('share string import hoti hai, kachra crash nahi karta', () {
      provider.loadPreset(tripleRsiPreset().copyWith(name: 'Share Test'));
      final text = provider.exportCurrent();
      expect(provider.importFrom(text), isTrue);
      expect(provider.strategy.name, 'Share Test');
      expect(provider.importFrom('not json'), isFalse);
    });
  });

  test(
    'CSV report me header, settings, trades aur cost note hote hain',
    () async {
      provider.setUniverse(UniverseCatalog.masterNse);
      provider.update(
        provider.strategy.copyWith(
          universeKey: UniverseCatalog.masterNse,
          settings: const StrategySettings(minBars: 60, costPct: 0.35),
        ),
      );
      await provider.run();
      final csv = strategyCsvReport(provider.result!, provider.strategy);
      final rows = CsvCodec.parse(csv);

      expect(rows.first.first, contains('Strategy Builder'));
      expect(csv, contains('Cost % per trade,0.35'));
      expect(csv, contains('Profit factor'));
      expect(csv, contains('Entry date'));
      // Har trade ka ek row: symbol + 7 aur columns.
      final headerAt = rows.indexWhere(
        (r) => r.first == 'Symbol' && r.contains('Net %'),
      );
      expect(headerAt, greaterThan(0));
      final tradeRows = rows
          .skip(headerAt + 1)
          .takeWhile((r) => r.isNotEmpty && r.length >= 8)
          .toList();
      expect(tradeRows.length, provider.result!.trades.length);
      expect(csv, contains('include hai'));
    },
  );

  test('validate khaali entry par rokta hai', () {
    provider.update(provider.strategy.copyWith(entry: const []));
    expect(provider.validate(), contains('entry rule'));
  });
}
