// ---------------------------------------------------------------------------
// strategy_engine_test.dart — backtest engine ka contract.
//
// Sabse zaroori tests (inhi par poora report bharosa karta hai):
//   • no look-ahead: signal din ke close par entry, agle din se pehle exit nahi
//   • cost har trade se kata jaata hai
//   • stop/target **intraday** low/high par trigger, gap par open price fill
//   • slots model: ek din me 15 signal, 10 hi liye jaate hain (skip gine jaate)
//   • honest skip: kam data par trade nahi, wajah ke saath
//   • rules ka JSON round-trip (save/load/share)
// ---------------------------------------------------------------------------

import 'package:angel_trader/features/strategy_builder/strategy_engine.dart';
import 'package:angel_trader/features/strategy_builder/strategy_indicators.dart';
import 'package:angel_trader/features/strategy_builder/strategy_rules.dart';
import 'package:flutter_test/flutter_test.dart';

DateTime day(int i) => DateTime(2025, 1, 1).add(Duration(days: i));

Bar bar(int i, double close, {double? high, double? low, double? open}) => Bar(
  time: day(i),
  open: open ?? close,
  high: high ?? close,
  low: low ?? close,
  close: close,
  volume: 1000,
);

/// 300 flat bars, phir `tail` bars (close list). Indices 0..299 = warm-up.
List<Bar> barsWithTail(List<double> tail, {double base = 90}) => [
  for (var i = 0; i < 300; i++) bar(i, base),
  for (var j = 0; j < tail.length; j++) bar(300 + j, tail[j]),
];

const fast = StrategySettings(
  minBars: 50,
  costPct: 0.0,
  maxPositions: 10,
  years: 1,
);

void main() {
  group('no look-ahead + cost', () {
    test('entry signal wale din ke CLOSE par, exit rule ke baad wale din', () {
      // Rule: close > 100 par entry (index 300 par sach), close < 105 par exit.
      final bars = barsWithTail([110, 120, 104, 99, 99]);
      final strategy = Strategy(
        name: 't',
        universeKey: 'nifty50',
        entry: const [
          Rule(indicator: Indicator.price, op: RuleOp.gt, value: 100),
        ],
        exit: const [
          Rule(indicator: Indicator.price, op: RuleOp.lt, value: 105),
        ],
        settings: fast,
      );
      final r = runOnBars(
        symbol: 'X',
        bars: bars,
        windowStart: null,
        strategy: strategy,
      );
      expect(r.trades, hasLength(1));
      final t = r.trades.single;
      expect(t.entryIndex, 300, reason: 'signal bar ke close par entry');
      expect(t.entryPrice, 110);
      expect(t.exitIndex, 302, reason: '104 (<105) par exit');
      expect(t.exitPrice, 104);
      expect(t.netPct, closeTo((104 / 110 - 1) * 100, 1e-9));
      expect(t.reason, 'exit');
    });

    test('cost har trade se katta hai (0.35% default)', () {
      final bars = barsWithTail([110, 120, 104, 99, 99]);
      final strategy = Strategy(
        name: 't',
        universeKey: 'nifty50',
        entry: const [
          Rule(indicator: Indicator.price, op: RuleOp.gt, value: 100),
        ],
        exit: const [
          Rule(indicator: Indicator.price, op: RuleOp.lt, value: 105),
        ],
        settings: fast.copyWith(costPct: 0.35),
      );
      final t = runOnBars(
        windowStart: null,
        symbol: 'X',
        bars: bars,
        strategy: strategy,
      ).trades.single;
      expect(t.returnPct - t.netPct, closeTo(0.35, 1e-9));
    });

    test('ek hi bar par entry aur exit nahi hota (bar ke andar jhooth nahi)', () {
      // Entry par hi exit rule bhi sach ho — phir bhi exit agle bar se pehle nahi.
      final bars = barsWithTail([110, 111, 90, 90]);
      final strategy = Strategy(
        name: 't',
        universeKey: 'nifty50',
        entry: const [
          Rule(indicator: Indicator.price, op: RuleOp.gt, value: 100),
        ],
        exit: const [
          Rule(indicator: Indicator.price, op: RuleOp.gt, value: 50),
        ],
        settings: fast,
      );
      final t = runOnBars(
        windowStart: null,
        symbol: 'X',
        bars: bars,
        strategy: strategy,
      ).trades.single;
      expect(t.exitIndex, greaterThan(t.entryIndex));
    });
  });

  group('stop loss / target', () {
    Strategy stopTarget({double sl = 0, double tp = 0}) => Strategy(
      name: 't',
      universeKey: 'nifty50',
      entry: const [
        Rule(indicator: Indicator.price, op: RuleOp.gt, value: 100),
      ],
      exit: const [],
      settings: fast.copyWith(stopLossPct: sl, targetPct: tp),
    );

    test('8% stop low se trigger hota hai, exit price = stop', () {
      final bars = [
        ...barsWithTail([110]),
        bar(301, 103, high: 104, low: 100),
      ];
      // entry 110 par (index 300), stop = 101.2 → index 301 ka low 100 se trigger.
      final t = runOnBars(
        symbol: 'X',
        bars: bars,
        windowStart: null,
        strategy: stopTarget(sl: 8),
      ).trades.single;
      expect(t.reason, 'stop');
      expect(t.exitIndex, 301);
      expect(t.exitPrice, closeTo(101.2, 1e-9));
    });

    test('gap-down ho to fill OPEN par (stop price par nahi)', () {
      final bars = [
        ...barsWithTail([110]),
        bar(301, 95, high: 96, low: 94, open: 95),
      ];
      final t = runOnBars(
        symbol: 'X',
        bars: bars,
        windowStart: null,
        strategy: stopTarget(sl: 8),
      ).trades.single;
      expect(t.reason, 'stop');
      expect(t.exitPrice, 95, reason: 'gap ke through — open par fill');
      expect(t.netPct, closeTo((95 / 110 - 1) * 100, 1e-9));
    });

    test('target high se trigger hota hai', () {
      final bars = [
        ...barsWithTail([110]),
        bar(301, 112, high: 120, low: 111),
      ];
      final t = runOnBars(
        symbol: 'X',
        bars: bars,
        windowStart: null,
        strategy: stopTarget(tp: 5),
      ).trades.single;
      expect(t.reason, 'target');
      expect(t.exitPrice, closeTo(115.5, 1e-9));
    });

    test('time stop — N bars ke baad close par exit', () {
      final bars = barsWithTail(List.filled(6, 111.0));
      final t = runOnBars(
        windowStart: null,
        symbol: 'X',
        bars: bars,
        strategy: stopTarget().copyWith(
          settings: fast.copyWith(timeStopBars: 5),
        ),
      ).trades.single;
      expect(t.reason, 'time');
      expect(t.bars, 5);
    });
  });

  group('honest skips', () {
    test('kam bars par trade nahi, wajah ke saath skip', () {
      final bars = [for (var i = 0; i < 40; i++) bar(i, 100)];
      final r = runOnBars(
        symbol: 'TINY',
        bars: bars,
        windowStart: null,
        strategy: Strategy(
          name: 't',
          universeKey: 'nifty50',
          entry: const [
            Rule(indicator: Indicator.price, op: RuleOp.gt, value: 1),
          ],
          exit: const [],
          settings: fast,
        ),
      );
      expect(r.trades, isEmpty);
      expect(r.skip, isNotNull);
      expect(r.skip!.symbol, 'TINY');
      expect(r.skip!.reason, contains('data kam'));
    });

    test('indicator warm-up par entry nahi (SMA 200 ke liye 200 bars)', () {
      // 100 bars only — SMA200 kahin bhi ban hi nahi sakta.
      final bars = [for (var i = 0; i < 100; i++) bar(i, i == 99 ? 200 : 100)];
      final r = runOnBars(
        symbol: 'X',
        bars: bars,
        windowStart: null,
        strategy: Strategy(
          name: 't',
          universeKey: 'nifty50',
          entry: const [
            Rule(
              indicator: Indicator.price,
              op: RuleOp.gt,
              compareTo: Indicator.sma,
              against: {'period': 200},
            ),
          ],
          exit: const [],
          settings: fast.copyWith(minBars: 50),
        ),
      );
      expect(r.trades, isEmpty);
    });
  });

  group('portfolio (slots model)', () {
    test(
      'ek din me 15 signal par sirf 10 trades liye jaate hain (rest skip)',
      () {
        final bars = <String, List<Bar>>{};
        final results = <SymbolResult>[];
        // 15 stocks, sab ka signal index 300 par (wahi din).
        for (var s = 0; s < 15; s++) {
          const tail = <double>[110, 111, 112, 113, 114, 115, 116, 117];
          bars['S$s'] = barsWithTail(tail);
          results.add(
            runOnBars(
              windowStart: null,
              symbol: 'S$s',
              bars: bars['S$s']!,
              strategy: Strategy(
                name: 't',
                universeKey: 'nifty50',
                entry: const [
                  Rule(indicator: Indicator.price, op: RuleOp.gt, value: 100),
                ],
                exit: const [
                  Rule(indicator: Indicator.price, op: RuleOp.gt, value: 500),
                ],
                settings: fast.copyWith(maxPositions: 10),
              ),
            ),
          );
        }
        final portfolio = runPortfolio(
          results: results,
          settings: fast.copyWith(maxPositions: 10),
          windowStart: day(300),
          windowEnd: day(400),
          barsBySymbol: bars,
        );
        expect(portfolio.trades, hasLength(15), reason: 'per-trade list poori');
        expect(portfolio.skippedTrades, 5, reason: '10 slots bhar gaye');
        // Equity curve me sirf liye gaye trades ka asar.
        expect(portfolio.equity.last, greaterThan(1.0));
        expect(portfolio.equity.last, lessThan(1.2));
      },
    );

    test('equity + benchmark dates saath chalte hain, shuru 1.0', () {
      final bars = {
        'A': barsWithTail([110, 120, 100, 100]),
      };
      final results = [
        runOnBars(
          symbol: 'A',
          bars: bars['A']!,
          windowStart: null,
          strategy: Strategy(
            name: 't',
            universeKey: 'nifty50',
            entry: const [
              Rule(indicator: Indicator.price, op: RuleOp.gt, value: 105),
            ],
            exit: const [
              Rule(indicator: Indicator.price, op: RuleOp.lt, value: 105),
            ],
            settings: fast,
          ),
        ),
      ];
      final p = runPortfolio(
        results: results,
        settings: fast,
        windowStart: day(299),
        windowEnd: day(310),
        barsBySymbol: bars,
      );
      expect(p.equity.length, p.equityDates.length);
      expect(p.benchmark.length, p.equityDates.length);
      expect(p.equity.first, 1.0);
      expect(p.stats.trades, 1);
      expect(p.monthly, isNotEmpty);
    });
  });

  group('1.5.103 — nifty benchmark', () {
    test('niftyBars dene par stats me nifty return/drawdown aata hai', () {
      final bars = barsWithTail([100, 100, 100]);
      // Nifty: 100 → 90 (-10%), beech me 120 ka peak → dd 25%.
      final nifty = [
        ...barsWithTail([100]),
        bar(301, 120),
        bar(302, 90),
      ];
      final r = runPortfolio(
        results: [],
        settings: const StrategySettings(costPct: 0),
        windowStart: day(300),
        windowEnd: day(303),
        barsBySymbol: {'X': bars},
        niftyBars: nifty,
      );
      expect(r.stats.niftyReturnPct, isNotNull);
      // base = index 300 ka open (100), last close 90 → -10%.
      expect(r.stats.niftyReturnPct!, closeTo(-10, 0.001));
      expect(r.stats.niftyMaxDrawdownPct!, closeTo(25, 0.001));
    });

    test('bars na hon to nifty fields null rehte hain (jhooth nahi)', () {
      final r = runPortfolio(
        results: [],
        settings: const StrategySettings(costPct: 0),
        windowStart: day(300),
        windowEnd: day(302),
        barsBySymbol: {
          'X': barsWithTail([100, 110]),
        },
      );
      expect(r.stats.niftyReturnPct, isNull);
      expect(r.stats.niftyMaxDrawdownPct, isNull);
    });
  });

  group('rules JSON (save / load / share)', () {
    test('round-trip — params, cross, join sab wapas', () {
      final s = Strategy(
        name: 'My strategy',
        universeKey: 'master_nse',
        entry: const [
          Rule(
            indicator: Indicator.rsi,
            params: {'period': 5},
            op: RuleOp.lt,
            value: 30,
          ),
          Rule(
            indicator: Indicator.price,
            op: RuleOp.gt,
            compareTo: Indicator.sma,
            against: {'period': 200},
          ),
          Rule(
            indicator: Indicator.rsiRising,
            params: {'period': 5, 'days': 3},
          ),
        ],
        exit: const [Rule(indicator: Indicator.macdCrossBelowSignal)],
        entryJoin: RuleJoin.or,
        settings: const StrategySettings(
          stopLossPct: 8,
          costPct: 0.35,
          years: 3,
        ),
      );
      final back = Strategy.decode(s.encode());
      expect(back.name, 'My strategy');
      expect(back.universeKey, 'master_nse');
      expect(back.entry, hasLength(3));
      expect(back.entry[0].indicator, Indicator.rsi);
      expect(back.entry[0].param('period'), 5);
      expect(back.entry[1].compareTo, Indicator.sma);
      expect(back.entry[1].against!['period'], 200);
      expect(back.entryJoin, RuleJoin.or);
      expect(back.settings.stopLossPct, 8);
      expect(back.settings.years, 3);
      expect(back.exit.single.indicator, Indicator.macdCrossBelowSignal);
    });

    test('triple RSI preset valid hai aur engine par chalta hai', () {
      final preset = tripleRsiPreset();
      expect(preset.entry, hasLength(3));
      expect(preset.exit, hasLength(1));
      expect(preset.entry.map((e) => e.describe()).toList(), [
        'RSI(5) < 30',
        'RSI falling (n days)(5 , 3)',
        'Close price > SMA(200)',
      ]);
      final decoded = Strategy.decode(preset.encode());
      expect(decoded.entry.first.describe(), 'RSI(5) < 30');
    });
  });
}
