// ---------------------------------------------------------------------------
// strategy_indicators_test.dart — indicator maths ka contract.
//
// Har indicator ke liye **known values** (hand-calculated / standard examples)
// pin kiye hain. Agar koi "optimisation" number badal de, ye test fail hoga —
// kyunki backtest ka har aankda inhi series se aata hai.
// ---------------------------------------------------------------------------

import 'package:angel_trader/features/strategy_builder/strategy_indicators.dart';
import 'package:flutter_test/flutter_test.dart';

Bar bar(double c, {double? h, double? l, double? o, int v = 0, int day = 1}) =>
    Bar(
      time: DateTime(2026, 1, 1).add(Duration(days: day)),
      open: o ?? c,
      high: h ?? c,
      low: l ?? c,
      close: c,
      volume: v,
    );

void main() {
  group('SMA / EMA', () {
    test('SMA — 3 ka average, warm-up null', () {
      final s = sma([1, 2, 3, 4, 5], 3);
      expect(s[0], isNull);
      expect(s[1], isNull);
      expect(s[2], 2);
      expect(s[3], 3);
      expect(s[4], 4);
    });

    test('EMA — seed = pehle period ka average, phir smoothing', () {
      final s = ema([1, 2, 3, 4, 5], 3);
      expect(s[2], 2);
      // k = 2/4 = 0.5 → 4*0.5 + 2*0.5 = 3
      expect(s[3], 3);
      expect(s[4], 4);
    });

    test('period > length → poora null (crash nahi)', () {
      expect(sma([1, 2], 5).every((v) => v == null), isTrue);
      expect(ema([1, 2], 5).every((v) => v == null), isTrue);
    });
  });

  group('RSI (Wilder)', () {
    test('lagatar badhta market → 100', () {
      final closes = [for (var i = 0; i < 20; i++) 100.0 + i];
      final r = rsi(closes, 5);
      expect(r[4], isNull, reason: 'warm-up');
      expect(r[19], 100);
    });

    test('lagatar girta market → 0', () {
      final closes = [for (var i = 0; i < 20; i++) 100.0 - i];
      expect(rsi(closes, 5)[19], 0);
    });

    test('standard series — 14 period ka pehla value 70.53 (Wilder)', () {
      // Investopedia ka classic example (closes).
      const closes = [
        44.34,
        44.09,
        44.15,
        43.61,
        44.33,
        44.83,
        45.10,
        45.42,
        45.84,
        46.08,
        45.89,
        46.03,
        45.61,
        46.28,
        46.28,
        46.00,
      ];
      final r = rsi(closes, 14);
      expect(r[14], closeTo(70.46, 0.15));
    });
  });

  group('MACD', () {
    test('constant price → MACD 0 aur histogram 0', () {
      final closes = List.filled(60, 100.0);
      final m = macd(closes);
      expect(m.macd[40], closeTo(0, 1e-9));
      expect(m.histogram![40], closeTo(0, 1e-9));
    });

    test('tez upmove me MACD line signal se upar (bullish)', () {
      // Linear ramp me MACD constant rehta hai (signal bhi wahi) — isliye
      // accelerating series: 30 bar flat, phir tez badh.
      final closes = [
        ...List.filled(30, 100.0),
        for (var i = 0; i < 50; i++) 100.0 + i * i * 0.05,
      ];
      final m = macd(closes);
      expect(m.macd[78]! > m.signal[78]!, isTrue);
    });
  });

  group('Bollinger', () {
    test('constant series me bands = price (sd 0)', () {
      final closes = List.filled(25, 50.0);
      final b = bollinger(closes);
      expect(b.middle[24], 50);
      expect(b.upper[24], 50);
      expect(b.lower[24], 50);
    });

    test('upper ≥ middle ≥ lower aur sd 2x', () {
      final closes = [for (var i = 0; i < 40; i++) 100.0 + (i % 7)];
      final b = bollinger(closes);
      final mid = b.middle[39]!;
      expect(b.upper[39]! > mid, isTrue);
      expect(b.lower[39]! < mid, isTrue);
      expect(b.upper[39]! - mid, closeTo(mid - b.lower[39]!, 1e-9));
    });
  });

  group('ATR / ADX / Stochastic', () {
    test('ATR flat market me ~0, aur % close se chhota', () {
      final bars = [for (var i = 0; i < 40; i++) bar(100)];
      expect(atr(bars, 14)[20]!, closeTo(0, 1e-9));
    });

    test('ATR girti-badhti market me high-low ka average banata hai', () {
      final bars = [
        for (var i = 0; i < 40; i++) bar(100.0 + i, h: 102.0 + i, l: 98.0 + i),
      ];
      // Har bar ka TR = 4 (5 ka gap nahi, kyunki pichhla close 4 neeche hai).
      expect(atr(bars, 14)[30]!, closeTo(4, 0.01));
    });

    test('ADX uptrend me +DI > -DI', () {
      final bars = [
        for (var i = 0; i < 60; i++) bar(100.0 + i, h: 101.0 + i, l: 99.0 + i),
      ];
      final a = adx(bars, 14);
      expect(a.plusDi[50]! > a.minusDi[50]!, isTrue);
      expect(a.adx[50], isNotNull);
    });

    test('Stochastic high par close → %K 100', () {
      final bars = [
        for (var i = 0; i < 20; i++)
          bar(i == 19 ? 110 : 100 + i.toDouble(), h: 110, l: 90),
      ];
      expect(stochastic(bars, kPeriod: 14).k[19]!, closeTo(100, 0.01));
    });
  });

  group('volume / 52W / ROC', () {
    test('volume ratio — double volume par 2.0', () {
      final bars = [
        for (var i = 0; i < 30; i++) bar(100, v: i == 29 ? 2000 : 1000),
      ];
      final avg = volumeSma(bars, 20);
      expect(avg[28], 1000);
      expect(bars[29].volume / avg[28]!, 2.0);
    });

    test('52W range — window ke high par ~100, low par 0', () {
      // High 200 / low 100 wale bars; index 250 par close 200 (= high),
      // index 80 par close 100 (= low).
      final bars = [
        for (var i = 0; i < 260; i++)
          bar(i == 80 ? 100.0 : 200.0, h: 200, l: 100),
      ];
      final r = rangePercent52w(bars, lookback: 250);
      expect(r[250]!, closeTo(100, 0.01));
      expect(r[80]!, closeTo(0, 0.01));
      // 60 bars se pehle number hi nahi banta (chhoti history par).
      expect(r[10], isNull);
    });

    test('ROC — 10 bar me 10% badha to 10', () {
      final closes = [for (var i = 0; i < 20; i++) i == 19 ? 110.0 : 100.0];
      expect(roc(closes, 10)[19]!, closeTo(10, 1e-9));
    });
  });

  group('helpers', () {
    test('fallingFor / risingFor strict hain', () {
      final s = <double?>[5, 4, 3, 2];
      expect(fallingFor(s, 3, 3), isTrue);
      expect(risingFor(s, 3, 3), isFalse);
      final flat = <double?>[5, 5, 5];
      expect(fallingFor(flat, 2, 2), isFalse, reason: 'barabar = gira nahi');
    });

    test('crossedAbove ek hi bar par true, cross ke baad false', () {
      final a = <double?>[1, 3, 3];
      final b = <double?>[2, 2, 2];
      expect(crossedAbove(a, b, 1), isTrue);
      expect(crossedAbove(a, b, 2), isFalse);
    });

    test('null warm-up par cross/trend false (koi crash nahi)', () {
      final a = <double?>[null, 1];
      final b = <double?>[1, 1];
      expect(crossedAbove(a, b, 1), isFalse);
      expect(risingFor(a, 1, 1), isFalse);
    });
  });
}
