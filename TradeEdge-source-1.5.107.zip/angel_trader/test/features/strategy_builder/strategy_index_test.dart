// ---------------------------------------------------------------------------
// strategy_index_test.dart — 1.5.103 (index backtest + OOS + benchmark).
//
// Pin hota hai:
//   1. Index tokens wahi hain jo Angel ke scrip master (AMXIDX, NSE) me hain —
//      ek typo poore feature ko "data nahi mila" bana deta hai;
//   2. brokerage series aane par report "Angel One (broker)" likhti hai aur
//      benchmark **wahi index ka buy & hold** hota hai (equal-weight nahi);
//   3. broker fail → Yahoo fallback **saaf label** ke saath;
//   4. dono fail → error "index data available nahi" (fake scale nahi);
//   5. 70/30 out-of-sample block banta hai.
// ---------------------------------------------------------------------------

import 'dart:convert';

import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/candle_dao.dart';
import 'package:angel_trader/data/local/dao/ipo_dao.dart';
import 'package:angel_trader/data/local/dao/scrip_dao.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/features/strategy_builder/index_bar_source.dart';
import 'package:angel_trader/features/strategy_builder/index_catalog.dart';
import 'package:angel_trader/features/strategy_builder/strategy_builder_provider.dart';
import 'package:angel_trader/features/strategy_builder/strategy_rules.dart';
import 'package:angel_trader/services/candle_source.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

class _NoBars implements CandleSource {
  @override
  Future<List<Candle>> fetchDailyCandles({
    required Scrip scrip,
    required DateTime from,
    required DateTime to,
    String interval = 'ONE_DAY',
  }) async => const [];
}

List<Candle> syntheticBars({int n = 700, double daily = 0.0009}) {
  final out = <Candle>[];
  var d = DateTime(2023, 1, 2);
  var i = 0;
  while (out.length < n) {
    if (d.weekday != DateTime.saturday && d.weekday != DateTime.sunday) {
      final close = 18000 * (1 + daily * i) * (i % 37 == 0 ? 0.985 : 1);
      out.add(
        Candle(
          time: DateTime(d.year, d.month, d.day, 15, 30),
          open: close * 0.998,
          high: close * 1.005,
          low: close * 0.994,
          close: close,
          volume: 0,
        ),
      );
      i++;
    }
    d = d.add(const Duration(days: 1));
  }
  return out;
}

String yahooBody(List<Candle> bars) => jsonEncode({
  'chart': {
    'result': [
      {
        'timestamp': [
          for (final b in bars)
            b.time
                    .subtract(const Duration(minutes: 330))
                    .millisecondsSinceEpoch ~/
                1000,
        ],
        'indicators': {
          'quote': [
            {
              'open': [for (final b in bars) b.open],
              'high': [for (final b in bars) b.high],
              'low': [for (final b in bars) b.low],
              'close': [for (final b in bars) b.close],
              'volume': [for (final b in bars) b.volume],
            },
          ],
        },
      },
    ],
  },
});

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;

  group('catalog', () {
    test('tokens Angel scrip master (AMXIDX, NSE) ke hain', () {
      // Verified: 99926000 NIFTY, 99926009 BANKNIFTY, 99926037 FINNIFTY,
      // 99926074 MIDCPNIFTY.
      expect(IndexCatalog.bySymbol('NIFTY')!.token, '99926000');
      expect(IndexCatalog.bySymbol('BANKNIFTY')!.token, '99926009');
      expect(IndexCatalog.bySymbol('FINNIFTY')!.token, '99926037');
      expect(IndexCatalog.bySymbol('MIDCPNIFTY')!.token, '99926074');
      expect(IndexCatalog.all, hasLength(10));
      // Har token unique + cache symbol unique.
      expect(IndexCatalog.all.map((i) => i.token).toSet(), hasLength(10));
      expect(IndexCatalog.all.map((i) => i.cacheSymbol).toSet(), hasLength(10));
    });

    test('Yahoo symbols map hain (fallback)', () {
      final nifty = IndexCatalog.bySymbol('NIFTY')!;
      final bank = IndexCatalog.bySymbol('BANKNIFTY')!;
      expect(YahooIndexSource.yahooSymbolFor(nifty), '^NSEI');
      expect(YahooIndexSource.yahooSymbolFor(bank), '^NSEBANK');
    });
  });

  group('yahoo parser', () {
    test('chart JSON se candles banti hain, sorted, IST stamp', () {
      final src = syntheticBars(n: 5);
      final parsed = YahooIndexSource.parseYahooChart(yahooBody(src));
      expect(parsed, hasLength(5));
      expect(parsed.first.close, closeTo(src.first.close, 0.001));
      // 15:30 IST bar wapas 15:30 IST hi dikhna chahiye.
      expect(parsed.first.time.hour, 15);
      expect(parsed.first.time.minute, 30);
    });

    test('kachra JSON par crash nahi — khaali list', () {
      expect(YahooIndexSource.parseYahooChart('nope'), isEmpty);
      expect(
        YahooIndexSource.parseYahooChart('{"chart":{"result":[]}}'),
        isEmpty,
      );
    });
  });

  group('index run', () {
    late StrategyBuilderProvider provider;
    final nifty = IndexCatalog.bySymbol('NIFTY')!;

    StrategyBuilderProvider make({
      Future<List<Candle>> Function(BenchIndex, DateTime, DateTime)? broker,
      Future<String?> Function(Uri)? yahooGet,
    }) => StrategyBuilderProvider(
      source: _NoBars(),
      candles: CandleDao(AppDatabase.instance),
      scripDao: ScripDao(AppDatabase.instance),
      ipoDao: IpoDao(AppDatabase.instance),
      settingsDao: SettingsDao(AppDatabase.instance),
      indexBars: broker,
      yahoo: yahooGet == null ? null : YahooIndexSource(get: yahooGet),
      clock: () => DateTime(2026, 10, 1),
    );

    setUp(() async {
      // Har test saaf cache se — warna stale index bars cross-contaminate karte.
      await CandleDao(AppDatabase.instance).clear();
      provider = make();
    });

    test('broker data → report, benchmark = index ka B&H, OOS ready', () async {
      final bars = syntheticBars();
      provider = make(broker: (i, f, t) async => bars);
      provider.setUniverse(nifty.cacheSymbol);
      provider.loadPreset(
        tripleRsiPreset(universeKey: nifty.cacheSymbol).copyWith(
          name: 'Index test',
          entry: const [
            Rule(indicator: Indicator.rsi, params: {'period': 5}, value: 65),
            Rule(indicator: Indicator.price, op: RuleOp.gt, value: 0),
          ],
        ),
      );

      expect(provider.isIndex, isTrue);
      await provider.run();

      expect(provider.status, BuilderStatus.ready, reason: provider.error);
      expect(provider.indexSource, IndexSourceKind.broker);
      expect(provider.sourceLabel, contains('Angel One (broker)'));
      expect(provider.benchmarkLabel, 'Nifty 50 buy & hold');

      final r = provider.result!;
      // Benchmark index ka hi curve hai (0.5x se 2x ke beech sane range).
      expect(r.benchmark.last, greaterThan(0.5));
      expect(r.benchmark.length, r.equity.length);
      // OOS dono hisse bane.
      expect(provider.oosTrain, isNotNull);
      expect(provider.oosTest, isNotNull);
    });

    test('broker fail → Yahoo fallback, label + warning', () async {
      final bars = syntheticBars();
      provider = make(
        broker: (i, f, t) async => throw StateError('token reject'),
        yahooGet: (uri) async => yahooBody(bars),
      );
      provider.setUniverse(nifty.cacheSymbol);
      provider.loadPreset(
        tripleRsiPreset(universeKey: nifty.cacheSymbol).copyWith(
          entry: const [
            Rule(indicator: Indicator.price, op: RuleOp.gt, value: 0),
          ],
        ),
      );
      await provider.run();

      expect(provider.status, BuilderStatus.ready);
      expect(provider.indexSource, IndexSourceKind.yahoo);
      expect(provider.sourceLabel, contains('Yahoo'));
      expect(
        provider.warnings().any((w) => w.contains('Yahoo fallback')),
        isTrue,
      );
    });

    test(
      'dono fail → "index data available nahi", koi fake number nahi',
      () async {
        provider = make(
          broker: (i, f, t) async => throw StateError('no session'),
          yahooGet: (uri) async => null,
        );
        provider.setUniverse(nifty.cacheSymbol);
        provider.loadPreset(tripleRsiPreset(universeKey: nifty.cacheSymbol));
        await provider.run();

        expect(provider.status, BuilderStatus.error);
        expect(provider.error, contains('Index data available nahi'));
        expect(provider.result, isNull);
      },
    );
  });
}
