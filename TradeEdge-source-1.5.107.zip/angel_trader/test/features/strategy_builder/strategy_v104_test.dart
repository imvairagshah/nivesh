// ---------------------------------------------------------------------------
// strategy_v104_test.dart — 1.5.104: intraday, fundamentals, share/export.
//
// Pin hota hai:
//   1. Timeframe enum → Angel interval strings, aur strategy JSON me save;
//   2. fundamentals ratio maths (ROCE / D-E / earnings yield) aur filter ka
//      pass/fail + "data nahi" behaviour;
//   3. fundamentals filter run me **sirf allowed stocks** par backtest karta
//      hai aur blocked ki wajah rakhta hai;
//   4. Excel workbook (3 sheet) + recap me warnings + strategy file round-trip.
// ---------------------------------------------------------------------------

import 'dart:io';

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/candle_dao.dart';
import 'package:angel_trader/data/local/dao/ipo_dao.dart';
import 'package:angel_trader/data/local/dao/scrip_dao.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/features/strategy_builder/strategy_builder_provider.dart';
import 'package:angel_trader/features/strategy_builder/strategy_delivery.dart';
import 'package:angel_trader/features/strategy_builder/strategy_engine.dart';
import 'package:angel_trader/features/strategy_builder/strategy_fundamentals.dart';
import 'package:angel_trader/features/strategy_builder/strategy_indicators.dart';
import 'package:angel_trader/features/strategy_builder/strategy_rules.dart';
import 'package:angel_trader/services/candle_source.dart';
import 'package:angel_trader/services/universe_catalog.dart';
import 'package:excel/excel.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

class _FakeSource implements CandleSource {
  final List<String> intervals = [];

  @override
  Future<List<Candle>> fetchDailyCandles({
    required Scrip scrip,
    required DateTime from,
    required DateTime to,
    String interval = 'ONE_DAY',
  }) async {
    intervals.add(interval);
    final out = <Candle>[];
    var d = DateTime(2024, 1, 1);
    var i = 0;
    final step = interval == 'ONE_DAY' ? 1 : 1; // synthetic — sirf shape matter
    while (out.length < 520) {
      if (d.weekday != DateTime.saturday && d.weekday != DateTime.sunday) {
        final close = 100 * (1 + 0.0008 * i);
        out.add(
          Candle(
            time: DateTime(d.year, d.month, d.day, 15, 30),
            open: close * 0.999,
            high: close * 1.004,
            low: close * 0.996,
            close: close,
            volume: 1000 + i,
          ),
        );
        i += step;
      }
      d = d.add(const Duration(days: 1));
    }
    return out;
  }
}

Scrip scrip(String symbol) => Scrip(
  token: symbol.hashCode.toString(),
  symbol: symbol,
  name: symbol.replaceAll('-EQ', ''),
  exchange: Exchange.nse,
);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;

  group('timeframe', () {
    test('interval strings + intraday lookback + JSON round-trip', () {
      expect(Timeframe.daily.apiInterval, 'ONE_DAY');
      expect(Timeframe.m15.apiInterval, 'FIFTEEN_MINUTE');
      expect(Timeframe.m5.apiInterval, 'FIVE_MINUTE');
      expect(Timeframe.daily.isIntraday, isFalse);
      expect(Timeframe.m5.isIntraday, isTrue);
      expect(Timeframe.m5.maxLookbackDays, 100);

      final strategy = tripleRsiPreset().copyWith(
        settings: const StrategySettings(timeframe: Timeframe.m15),
      );
      final back = Strategy.decode(strategy.encode());
      expect(back.settings.timeframe, Timeframe.m15);
      // Purani file (timeframe key ke bina) daily hi rehti hai.
      final old = Strategy.fromJson({
        'name': 'old',
        'universeKey': 'fno',
        'entry': <Map<String, dynamic>>[],
        'exit': <Map<String, dynamic>>[],
        'settings': <String, dynamic>{'costPct': 0.35},
      });
      expect(old.settings.timeframe, Timeframe.daily);
    });
  });

  group('fundamentals', () {
    test('ratios filing ke numbers se bante hain (formula same)', () {
      final snap = FundamentalSnapshot.fromFiling(
        symbol: 'AAA',
        marketCapCr: 10000,
        ebitTtmCr: 1500,
        totalDebtCr: 2000,
        cashCr: 500,
        totalAssetsCr: 12000,
        currentLiabilitiesCr: 2000,
      );
      // ROCE = 1500 / (12000 - 2000) = 15%
      expect(snap.rocePct!, closeTo(15, 1e-9));
      // Equity = 10000 - 2000 = 8000 → D/E = 0.25
      expect(snap.debtEquity!, closeTo(0.25, 1e-9));
      // EV = 10000 + 2000 - 500 = 11500 → EY = 1500/11500 = 13.04%
      expect(snap.earningsYieldPct!, closeTo(13.04, 0.01));
    });

    test('missing input → ratio null (zero nahi)', () {
      final snap = FundamentalSnapshot.fromFiling(
        symbol: 'BBB',
        marketCapCr: 500,
        ebitTtmCr: 50,
      );
      expect(snap.rocePct, isNull);
      expect(snap.debtEquity, isNull);
      expect(snap.earningsYieldPct, isNull);
    });

    test('filter pass/fail + requireData ka farak', () {
      final filter = const FundamentalFilter(
        minMarketCapCr: 5000,
        minRocePct: 12,
      );
      final ok = FundamentalSnapshot.fromFiling(
        symbol: 'OK',
        marketCapCr: 8000,
        ebitTtmCr: 1500,
        totalDebtCr: 500,
        cashCr: 100,
        totalAssetsCr: 9000,
        currentLiabilitiesCr: 2000,
      );
      expect(filter.test(ok).pass, isTrue);

      final smallCap = FundamentalSnapshot.fromFiling(
        symbol: 'SMALL',
        marketCapCr: 100,
        ebitTtmCr: 10,
        totalDebtCr: 1,
        cashCr: 1,
        totalAssetsCr: 100,
        currentLiabilitiesCr: 10,
      );
      final verdict = filter.test(smallCap);
      expect(verdict.pass, isFalse);
      expect(verdict.reason, contains('MCap'));

      // Data hi nahi → default me pass (coverage chhoti ho to universe na ude),
      // requireData ke saath fail.
      expect(filter.test(null).pass, isTrue);
      expect(
        const FundamentalFilter(requireData: true).test(null).pass,
        isFalse,
      );
      expect(filter.describe(), contains('MCap'));
    });
  });

  group('run with fundamentals filter', () {
    late StrategyBuilderProvider provider;
    late ScripDao scripDao;

    setUp(() async {
      final db = AppDatabase.instance;
      scripDao = ScripDao(db);
      await scripDao.replaceAll([
        scrip('GOOD-EQ'),
        scrip('WEAK-EQ'),
        scrip('NODATA-EQ'),
      ]);
      await CandleDao(db).clear();

      provider = StrategyBuilderProvider(
        source: _FakeSource(),
        candles: CandleDao(db),
        scripDao: scripDao,
        ipoDao: IpoDao(db),
        settingsDao: SettingsDao(db),
        clock: () => DateTime(2026, 10, 1),
        fundamentals: (symbol) async => switch (symbol) {
          'GOOD' => FundamentalSnapshot.fromFiling(
            symbol: 'GOOD',
            marketCapCr: 9000,
            ebitTtmCr: 1500,
            totalDebtCr: 200,
            cashCr: 100,
            totalAssetsCr: 9000,
            currentLiabilitiesCr: 2000,
          ),
          'WEAK' => FundamentalSnapshot.fromFiling(
            symbol: 'WEAK',
            marketCapCr: 200,
            ebitTtmCr: 10,
            totalDebtCr: 500,
            cashCr: 10,
            totalAssetsCr: 1000,
            currentLiabilitiesCr: 200,
          ),
          _ => const FundamentalSnapshot(
            symbol: 'NODATA',
            missingReason: 'filing nahi mili',
          ),
        },
      );
    });

    test(
      'sirf pass hone wale stocks par run, blocked wajah ke saath',
      () async {
        provider.setUniverse(UniverseCatalog.masterNse);
        provider.update(
          provider.strategy.copyWith(
            universeKey: UniverseCatalog.masterNse,
            entry: const [
              Rule(indicator: Indicator.price, op: RuleOp.gt, value: 0),
            ],
            settings: const StrategySettings(minBars: 60, costPct: 0),
            fundamentals: const FundamentalFilter(
              minMarketCapCr: 5000,
              minRocePct: 12,
            ),
          ),
        );

        await provider.run();

        expect(provider.status, BuilderStatus.ready, reason: provider.error);
        expect(provider.result!.symbolsScanned, 2); // GOOD + NODATA (no data)
        expect(provider.fundamentalsBlocked.keys, contains('WEAK'));
        expect(provider.fundamentalsBlocked['WEAK'], contains('MCap'));
        expect(provider.fundamentalsMissing, contains('NODATA'));
        expect(
          provider.warnings().any((w) => w.contains('Fundamentals filter')),
          isTrue,
        );
      },
    );
  });

  group('export / share', () {
    late Directory tmp;

    setUp(() async {
      tmp = await Directory.systemTemp.createTemp('strategy_export_');
    });

    tearDown(() async {
      if (tmp.existsSync()) await tmp.delete(recursive: true);
    });

    BacktestResult sampleResult() {
      final bars = [
        for (var i = 0; i < 5; i++)
          Bar(
            time: DateTime(2025, 1, 1 + i),
            open: 100.0 + i,
            high: 101.0 + i,
            low: 99.0 + i,
            close: 100.5 + i,
            volume: 1000,
          ),
      ];
      return runPortfolio(
        results: [
          SymbolResult(
            symbol: 'AAA',
            trades: [
              StrategyTrade(
                symbol: 'AAA',
                entryIndex: 0,
                exitIndex: 2,
                entryDate: DateTime(2025, 1, 1),
                exitDate: DateTime(2025, 1, 3),
                entryPrice: 100,
                exitPrice: 105,
                bars: 2,
                reason: 'exit',
                returnPct: 5,
                netPct: 4.65,
              ),
            ],
          ),
          SymbolResult(
            symbol: 'BBB',
            trades: const [],
            skip: const StrategySkip('BBB', 'candles nahi mile'),
          ),
        ],
        settings: const StrategySettings(costPct: 0.35, maxPositions: 2),
        windowStart: DateTime(2025, 1, 1),
        windowEnd: DateTime(2025, 1, 31),
        barsBySymbol: {'AAA': bars},
      );
    }

    test('XLSX me 3 sheet aur asli numbers hote hain', () async {
      final strategy = tripleRsiPreset().copyWith(name: 'Excel Test');
      final file = await StrategyDeliveryService.writeXlsx(
        sampleResult(),
        strategy,
        warnings: const ['Sirf 1 trade — sample chhota'],
        directory: tmp,
      );
      expect(file.existsSync(), isTrue);
      expect(file.path.endsWith('.xlsx'), isTrue);

      final excel = Excel.decodeBytes(await file.readAsBytes());
      expect(excel.tables.keys, containsAll(['Report', 'Trades', 'Skipped']));
      final trades = excel.tables['Trades']!.rows;
      expect(trades.first.map((c) => c?.value.toString()), contains('Net %'));
      expect(trades, hasLength(2)); // header + 1 trade
      final skipped = excel.tables['Skipped']!.rows;
      expect(skipped, hasLength(2)); // header + BBB
    });

    test('recap me warnings aur rules saath chalte hain', () {
      final text = StrategyDeliveryService.recap(
        sampleResult(),
        tripleRsiPreset().copyWith(name: 'Recap Test'),
        sourceLabel: 'Angel One daily candles',
        warnings: const ['Cost 0% par run hua'],
      );
      expect(text, contains('Recap Test'));
      expect(text, contains('Win rate'));
      expect(text, contains('Rules:'));
      expect(text, contains('Cost 0% par run hua'));
      expect(text, contains('Data: Angel One daily candles'));
    });

    test('strategy file (.tradeedge) round-trip + kachra safe', () async {
      final strategy = tripleRsiPreset().copyWith(name: 'File Test');
      final delivery = StrategyDeliveryService();
      final outcome = await delivery.shareStrategyFile(
        strategy,
        directory: tmp,
      );
      // Desktop test par share helper Downloads me likhta hai — message kuch
      // bhi ho, asli file yahan check karte hain.
      expect(outcome.message, isNotEmpty);

      final file = File(tmp.path + '/file_test.tradeedge');
      expect(file.existsSync(), isTrue);
      final parsed = StrategyDeliveryService.parseStrategyFile(
        await file.readAsString(),
      );
      expect(parsed, isNotNull);
      expect(parsed!.name, 'File Test');

      expect(
        StrategyDeliveryService.parseStrategyFile('# comment\nnope'),
        isNull,
      );
      expect(StrategyDeliveryService.parseStrategyFile(''), isNull);
    });
  });
}
