// ---------------------------------------------------------------------------
// home_hub_test.dart — 1.5.96 ka naya flow, widget level par.
//
// User ka chuna hua flow:
//   Splash (app_boot_test) → Home → EQUITY / F&O → tools
//
// Yahan pin hota hai:
//   1. Home par sirf do bade choices hain, koi bottom navigation nahi;
//   2. koi **banaya hua** index number nahi dikhta (Nifty/Banknifty quotes is
//      app me nahi aate — isliye wo card hi nahi hai);
//   3. EQUITY tap → equity hub, jahan saare 7 tools icons ke saath hain
//      (1.5.101: Calls Board EXTRA hub me shift ho gaya);
//   4. equity hub me F&O ke tools nahi ghusse (aur ulta bhi).
// ---------------------------------------------------------------------------

import 'package:angel_trader/features/alerts/alerts_center.dart';
import 'package:angel_trader/features/equity/equity_hub_screen.dart';
import 'package:angel_trader/features/extra/extra_hub_config.dart';
import 'package:angel_trader/features/extra/extra_hub_screen.dart';
import 'package:angel_trader/features/fno/fno_hub_config.dart';
import 'package:angel_trader/features/settings/settings_provider.dart';
import 'package:angel_trader/features/shell/home_hub_screen.dart';
import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/services/auth_service.dart';
import 'package:angel_trader/services/secure_store.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';

Widget host(Widget child) => MultiProvider(
  providers: [
    ChangeNotifierProvider<AuthService>(
      create: (_) => AuthService(store: SecureStore()),
    ),
    ChangeNotifierProvider<AlertsCenter>.value(value: AlertsCenter.instance),
    // EXTRA hub apna setup card SettingsProvider se banata hai (1.5.101) —
    // tests me in-memory DB ka ek instance kaafi hai.
    ChangeNotifierProvider<SettingsProvider>(
      create: (_) => SettingsProvider(SettingsDao(AppDatabase.instance)),
    ),
  ],
  child: MaterialApp(home: child),
);

void main() {
  group('home hub', () {
    testWidgets('do choices dikhte hain — EQUITY aur F&O', (tester) async {
      await tester.pumpWidget(host(const HomeHubScreen()));
      await tester.pump(const Duration(milliseconds: 600));

      expect(find.text('EQUITY'), findsOneWidget);
      expect(find.text('F&O'), findsOneWidget);
      expect(find.text('Aaj kaam kis\nsegment pe?'), findsOneWidget);
    });

    testWidgets('koi bottom navigation nahi (user decision)', (tester) async {
      await tester.pumpWidget(host(const HomeHubScreen()));
      await tester.pump(const Duration(milliseconds: 600));

      expect(find.byType(NavigationBar), findsNothing);
      expect(find.byType(NavigationRail), findsNothing);
    });

    testWidgets('koi banaya hua index number nahi', (tester) async {
      await tester.pumpWidget(host(const HomeHubScreen()));
      await tester.pump(const Duration(milliseconds: 600));

      // Nifty/Banknifty quotes is app ke paas nahi hain, isliye home par wo
      // card hi nahi hona chahiye — galat number dikhane se behtar hai na
      // dikhana.
      expect(find.textContaining('NIFTY'), findsNothing);
      expect(find.textContaining('BANKNIFTY'), findsNothing);
      expect(find.textContaining('24,318'), findsNothing);
    });

    testWidgets('status honest hai — login hua ya nahi', (tester) async {
      await tester.pumpWidget(host(const HomeHubScreen()));
      await tester.pump(const Duration(milliseconds: 600));

      expect(find.textContaining('Login nahi hua'), findsOneWidget);
    });

    testWidgets('EQUITY tap → equity hub ke 7 tools', (tester) async {
      await tester.pumpWidget(host(const HomeHubScreen()));
      await tester.pump(const Duration(milliseconds: 600));

      await tester.tap(find.text('EQUITY'));
      await tester.pumpAndSettle();

      expect(find.byType(EquityHubScreen), findsOneWidget);
      for (final tool in kEquityTools) {
        expect(find.text(tool.title), findsWidgets, reason: tool.title);
      }
    });

    testWidgets('EXTRA tap → extra hub ke 6 items (1.5.101)', (tester) async {
      await tester.pumpWidget(host(const HomeHubScreen()));
      await tester.pump(const Duration(milliseconds: 600));

      // 1.5.102: chautha card (BUILDER) add hone se EXTRA neeche chala gaya —
      // test ko scroll karna padta hai (asli phone par bhi user scroll karta).
      await tester.ensureVisible(find.text('EXTRA'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('EXTRA'));
      await tester.pumpAndSettle();

      expect(find.byType(ExtraHubScreen), findsOneWidget);
      for (final tool in kExtraTools) {
        expect(find.text(tool.title), findsOneWidget, reason: tool.title);
      }
    });
  });

  group('equity hub', () {
    testWidgets('sirf equity tools — F&O ke tools yahan nahi', (tester) async {
      await tester.pumpWidget(host(const EquityHubScreen()));
      await tester.pumpAndSettle();

      expect(kEquityTools, hasLength(7));
      for (final tool in kEquityTools) {
        expect(find.text(tool.title), findsOneWidget, reason: tool.title);
      }
      for (final fnoTool in kHubTools) {
        expect(
          find.text(fnoTool.title),
          findsNothing,
          reason: '${fnoTool.title} F&O ka tool hai, equity grid me nahi',
        );
      }
    });

    testWidgets('har tile par ek icon hai', (tester) async {
      await tester.pumpWidget(host(const EquityHubScreen()));
      await tester.pumpAndSettle();

      for (final tool in kEquityTools) {
        expect(
          find.byIcon(tool.icon),
          findsOneWidget,
          reason: '${tool.title} ka icon',
        );
      }
    });
    testWidgets('1.5.102 — BUILDER card home par hai (chautha card)', (
      tester,
    ) async {
      await tester.pumpWidget(host(const HomeHubScreen()));
      await tester.pump(const Duration(milliseconds: 600));

      expect(find.text('BUILDER'), findsOneWidget);
      expect(
        find.text('Apni strategy · stocks + index backtest'),
        findsOneWidget,
      );
      // Chips se pata chale ki tool kya karta hai (1.5.97: description nahi,
      // chips hi).
      expect(find.text('Stocks + Index'), findsOneWidget);
    });
  });
}
