# TradeEdge 1.5.107 — cache / speed module: audit ke saare gaps band

Sabhi 6 gaps ek saath fix. Koi formula, threshold, table column ya
existing behaviour nahi badla — sirf cache ka bharosa (freshness label),
retention, aur dobara-scan ka kaam.

---

## 1. `scan_runs` kabhi delete nahi hote the → ab retention hai

- `ScanCacheDao.pruneRuns(before:)` — `as_of` date ke hisaab se purane run delete.
- `ScanCacheDao.sweep()` — ek call me runs + prices; app khulte hi chalta hai
  (`app.dart`) aur har scan ke baad bhi.
- **Retention:** scanner output **30 din** (`CacheRetention.scanRunDays`).
  Har kind ka aaj ka run kabhi nahi hatta (date-wise cut, kind-wise limit nahi).

## 2. IV Spike / IV Crush ka result cache (naya)

- Naya: `lib/features/fno/iv_spike/iv_result_cache.dart`
  (`scan_runs`, kind = `iv_spike`).
- Screen kholte hi **pichhla scan turant** dikhta hai, upar saaf likha hota hai
  “Ye pichhle scan ka result hai (DD/MM/YY) — fresh ke liye ↻”.
- Fresh scan sirf **Scan dabane par** (pehli baar cache khaali ho to khud chalta hai).
- Kal ka IV cache se **nahi** aata — wo hamesha Sheet ya snapshot se (ek hi din
  ka data do baar use na ho).
- Providers me `bootstrap()`, `cachedAsOf`, `fromCache`, aur `rebuild()` ab
  **cache wale din** par hisaab karta hai (aaj ka ban kar jhooth nahi bolta).

## 3. Strategy Builder report cache (naya)

- Report + strategy `scan_runs` (kind = `strategy_builder`) me save.
- App khulte hi `loadReport()` — report screen khaali nahi milti; report par
  label: “Ye pichhla saved report hai (DD/MM/YY)”.
- Report ke saath **strategy bhi wapas** load hoti hai (warna purana report nayi
  strategy ke naam ke neeche dikhta — jhooth).
- `BacktestResult` / `BacktestStats` / `StrategyTrade` me `fromJson` (round-trip
  test ke saath) — koi field guess nahi.

## 4. `price_cache` ab sab scanners likhte hain

- Naya: `lib/services/price_cache_writer.dart` — ek hi key shape
  `EXCHANGE:SYMBOL` (wahi jo IPO screener use karta hai).
- RSI aur Golden Cross ab har instrument ka **last close** likhte hain
  (`asOf` = us bar ka IST din, guess nahi).
- `0` / `NaN` price kabhi cache nahi hoti. Cache se padha price hamesha
  `isLive: false`.
- `PriceCacheWriter.cached(maxAgeDays: 7)` — 7 din se purana price “aaj ka bhav”
  nahi kahlata (reject).
- IPO screener ka behaviour bilkul waisa hi (no regression).

## 5. Same-day greeks cache (naya)

- Naya: `lib/services/greeks_cache.dart` — `StudyMarketData` ka wrapper,
  in-memory, **ek din** ke liye (`underlying|expiry`).
- IV Spike din me doosri baar chalane par ~213 greeks calls nahi, sirf jo naye
  hain.
- **Fail/khali batch cache nahi hota** — agli koshish asli call karti hai.
- Naya din = naya call (kal ka greek aaj use nahi hota).

## 6. Candle retention ka bug + WAL + index

- **Asli bug:** `retentionDays = 700` teen services me alag-alag tha, jabki
  Builder **5 saal + 400 din (~2225 din)** maangta hai → Builder ka purana data
  agle scan ke prune me ud jaata tha aur dobara download hota tha.
- Ab ek hi source: `CacheRetention` (`lib/core/utils/markets.dart`),
  `candleDays = 2225`. Teeno services usi par.
- `PRAGMA journal_mode = WAL` + `synchronous = NORMAL` (best-effort) — scan
  cache likhne par screens block nahi hoti.
- Schema **v17**: `candles(bar_time)` aur `candles(symbol, interval)` index —
  prune aur count sasta. Migration callback hai (v1 DB me `candles` table hi
  nahi hota — seedha CREATE INDEX chalane se **upgrade fail** ho jaata tha; wo
  bhi pakda gaya).

## 7. F&O Scanner ka stale cache

- `loadCached(maxAgeDays: 7)` — 7 din se purana trade date cache-hit nahi.
- `cacheIsStale()` + provider flag `staleCache`, screen par saaf: “Purana cache
  (7 din se zyada) — ↻ Rescan dabaiye, warna trade plan purane bhav ka hai.”

## 8. Settings → Local data

- Naya button **“Clear scanner cache”** (saare kinds ek saath).
- Cache retention ka sach likha hai: 30 din runs · 7 din prices · 2225 din candles.

---

## Verification

- `flutter analyze`: **0 errors**.
- Tests: **118 files / 1610 tests pass** (naya: `test/services/cache_retention_test.dart`, 14 tests).
  - Purane tests jo retention par the (cross_scan prune test) naye window par
    update hue — behaviour wahi, sirf window bada.
- Fix kiye gaye regression: v17 migration v1 DB par fail ho raha tha (3 DAO
  tests) — callback migration se theek.

## Build

- `TradeEdge-1.5.107.apk` — 29,768,794 B · versionCode **2120** · 1.5.107 ·
  arm64-v8a ·
  sha256 `78748ce82e13cca1e53a39d1e63270542650e60aed3f6a4d1aa87fde50c82e63`
  · cert `a82bdef7…0ce9b652` (wahi signing key).
- `TradeEdge-source.zip` (3.6 MB).

## Jo abhi bhi baaki hai (agle round ke liye, chhota)

1. **F&O study ka option-premium cache** — study panel ke quotes offline
   (“last known premium”) abhi nahi; price_cache me sirf spot close jaata hai.
2. **Greeks cache disk-par persist nahi** — app band hone par ek baar greeks
   phir maange jaate hain (per-day cache, best-effort hi rakha).
3. **`VACUUM` ka schedule** — prune ke baad file shrink tab hota hai jab user
   Storage → Compact dabaye (jaldi-jaldi VACUUM mehnga hai).
