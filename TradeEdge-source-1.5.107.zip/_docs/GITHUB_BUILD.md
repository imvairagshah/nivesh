# NiveshDesk `.exe` — GitHub se (sirf 1 zip upload)

Laptop par **kuch install nahi**. Sirf browser. ~15 min.

> **1.5.92 me build fail hone ki 2 wajah thi (ab fix):**
> 1. Zip ke andar `angel_trader/` folder nahi tha (files seedha root me) →
>    workflow ka check fail → **exit code 1**.
> 2. Zip me `linux/flutter/ephemeral/` (Linux build ke stale symlinks, 13 MB)
>    chala gaya tha → Windows build tootta hai.
> Ab zip me sahi folder structure hai aur ephemeral excluded hai (**1.8 MB**).

---

## Step 1 — GitHub repo (2 min)

1. https://github.com → **Sign up** (agar nahi hai) — free
2. Top-right **+** → **New repository**
3. Name: `niveshdesk` → **Private** → **Create repository**

## Step 2 — Workflow file (2 min)

1. Repo page → **Add file** → **Create new file**
2. File name box me ye poora path:
   ```
   .github/workflows/windows-build.yml
   ```
   (Purana workflow hai to usko **edit** karo — content neeche wala rakh do.)
3. Neeche bade box me ye **poora copy-paste** karo:

```yaml
name: NiveshDesk Windows .exe

on:
  workflow_dispatch:
  push:
    branches: [ main ]

jobs:
  build:
    runs-on: windows-latest
    steps:
      - uses: actions/checkout@v5

      - name: Source zip extract + project folder detect
        shell: pwsh
        run: |
          $zip = Get-ChildItem -Path . -Filter *.zip -File -Recurse |
            Where-Object { $_.FullName -notmatch '\\extracted\\' } |
            Select-Object -First 1
          if (-not $zip) { throw "Repo me koi .zip nahi mila." }
          Write-Host "Extracting: $($zip.FullName)"
          Expand-Archive -Path $zip.FullName -DestinationPath extracted -Force

          Get-ChildItem -Path extracted -Directory -Recurse -Filter ephemeral -ErrorAction SilentlyContinue |
            ForEach-Object { Remove-Item -Recurse -Force $_.FullName -ErrorAction SilentlyContinue }

          $pubspec = Get-ChildItem -Path extracted -Filter pubspec.yaml -File -Recurse |
            Where-Object { $_.FullName -notmatch '\\\.dart_tool\\' } |
            Select-Object -First 1
          if (-not $pubspec) { throw "Zip me pubspec.yaml nahi mila." }
          $proj = $pubspec.Directory.FullName
          Write-Host "Project folder: $proj"
          "PROJ=$proj" | Out-File -FilePath $env:GITHUB_ENV -Append -Encoding utf8
          if (-not (Test-Path "$proj\windows")) { throw "Project me 'windows' folder nahi hai." }

      - name: Flutter SDK (stable)
        uses: subosito/flutter-action@v2
        with:
          channel: stable
          cache: true

      - name: Flutter version + Windows desktop on
        shell: pwsh
        run: |
          flutter --version
          flutter config --enable-windows-desktop

      - name: Dependencies
        shell: pwsh
        working-directory: ${{ env.PROJ }}
        run: flutter pub get

      - name: Tests (non-blocking)
        continue-on-error: true
        shell: pwsh
        working-directory: ${{ env.PROJ }}
        run: flutter test

      - name: Windows .exe build
        shell: pwsh
        working-directory: ${{ env.PROJ }}
        run: flutter build windows --release

      - name: Artifact upload (download ke liye)
        uses: actions/upload-artifact@v4
        with:
          name: NiveshDesk-Windows
          path: ${{ env.PROJ }}/build/windows/x64/runner/Release/
          if-no-files-found: error
```

4. **Commit changes**

## Step 3 — Zip upload (2 min)

1. Repo page → **Add file** → **Upload files**
2. **Purana zip delete karo** (ya overwrite karo) — sirf **naya
   `NiveshDesk-source.zip` (1.8 MB)** drag-drop
3. **Commit changes**

## Step 4 — Build chalao (1 click)

1. **Actions** tab → left me **"NiveshDesk Windows .exe"** → click
2. **Run workflow** → green **Run workflow**

## Step 5 — Download (~10–15 min)

1. Run **green ✓** hone do (Tests peela ho to chalega — non-blocking)
2. **Artifacts** → **NiveshDesk-Windows** → **Download**
3. Extract → **`NiveshDesk.exe`** double-click ("More info → Run anyway" —
   pehli baar normal)

---

## Agar phir bhi red ✗ ho — error kahan dekhna hai

Actions → run → **build** job → **left me red step ka naam** + uske right me
error ki last 3 lines. Bas wahi 3 lines bhejo.

Sabse common:

| Step ka naam | Error text | Matlab / fix |
|---|---|---|
| Source zip extract | `Zip me pubspec.yaml nahi mila` | Galat/adhoora zip upload hua — naya 1.8 MB zip dobara upload karo |
| Dependencies | `version solving failed` / `SDK constraint` | Purana zip (jo Flutter purana maangta hai) — naya zip use karo |
| Windows .exe build | `CMake` / `MSVC` / `could not find Visual Studio` | Windows runner par VS hai; ye tab aata hai jab `windows/` folder missing ho — naya zip me wo hai |
| Artifact upload | `No files were found` | Build step hi fail hua hai — uski error dekho |
| koi bhi | `exit code 1` akela | Ye sirf summary hai; **upar wala step** dekho jo red hai |

> Note: `flutter test` step peela (⚠️) dikhe to koi dikkat nahi — wo
> non-blocking hai, `.exe` banega.

## Har naya version
Naya `NiveshDesk-source.zip` upload (Step 3) → Run workflow (Step 4) — 3 min.

## Data
`%APPDATA%\com.example.angel_trader\niveshdesk\angel_trader.db` — updates se safe.

## Note
- Artifact folder me `NiveshDesk.exe` + DLLs + `data\` — sab ek saath rakho
- Installer chahiye to zip ke andar `installer.iss` hai (Inno Setup — optional)
- Linux par seedha: `flutter build linux --release` (1.5.92 par verified)
