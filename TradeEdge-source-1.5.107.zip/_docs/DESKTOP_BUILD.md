# TRADE EDGE — Windows laptop par build & chalane ka guide (1.5.107)

> **Chhota raasta chahiye?** `docs/WINDOWS_BUILD.md` — GitHub Actions se `.exe`
> (laptop par kuch install nahi), ya laptop par 4-step build. **Code wahi hai**
> jo APK (1.5.107) me hai.

Aapke laptop par `.exe` banane ke liye — **pehli baar ~45–60 min setup**, uske
baad har update = **5 minute**. Sab kuch free hai.

---

## Step 1 — Tools install karo (sirf pehli baar)

1. **Visual Studio Build Tools** (free, Microsoft ka)
   - https://visualstudio.microsoft.com/visual-cpp-build-tools/
   - Installer khule → "Desktop development with C++" workload tick karo → Install
   (~3–5 GB)
2. **Flutter SDK**
   - https://docs.flutter.dev/get-started/install/windows/desktop → "Flutter SDK"
   - Zip download → `C:\flutter` me extract karo
3. **PATH** me add karo: `C:\flutter\bin`
   (Start menu → "env" → "Environment Variables" → Path → Edit → New)
4. Naya Command Prompt kholo, verify karo:
   ```bat
   flutter doctor
   ```
   "Visual Studio" line green dikhegi. Baaki ✗ chalta hai (Android se matlab nahi).

## Step 2 — Code copy karo

Project folder (`angel_trader`) laptop par daalo — ya GitHub se clone.

## Step 3 — Build

```bat
build_windows.bat
```

Ya seedha:

```bat
flutter pub get
flutter build windows --release
```

**Output:** `build\windows\x64\runner\Release\` → `TradeEdge.exe` double-click
→ app chalega. Poora Release folder hamesha saath rakho (exe + DLLs + data).

## Step 4 (optional) — Installer banao

1. **Inno Setup** (free) install karo: https://jrsoftware.org/isinfo.php
2. `installer.iss` ko open karo → **Compile (F9)**
3. `Output\TRADE EDGE-Setup-1.5.107.exe` — yahi sabko dena hai (Next-Next-Install
   → Start Menu icon).

> **Note:** bina code-signing certificate ke Windows pehli baar blue warning
> dikha sakta hai → "More info → **Run anyway**". Installer wali warning bhi
> same hai. (Code-signing certificate kharidne se ye hat jaata hai — optional.)

---

## App data kahan padta hai

Database + settings: `%APPDATA%\com.example.angel_trader\niveshdesk\angel_trader.db`
(safe rehta hai — app update karne par bhi data nahi mit-ta).

## Update kaise karein

Naya code → `build_windows.bat` dobara → naye Release folder se app replace.
Purana data wahi rehta hai. (Auto-updater baad me add ho sakta hai.)

## Requirements

- Windows 10/11 64-bit
- Angel One login (wahi OTP/TOTP flow — app ke andar)
- Internet (live quotes/news ke liye)
