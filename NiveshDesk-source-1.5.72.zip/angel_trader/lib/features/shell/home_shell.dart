// ---------------------------------------------------------------------------
// home_shell.dart — the bottom navigation:
//
//   IPO | Golden Cross | RSI | Paper Trading | Reports
//
// The RSI scanner tab (Feature 5) shares the candle cache with the Golden
// Cross tab, so whichever is scanned first makes the other's scan nearly free.
//
// The Golden Cross tab is told when it becomes the visible one: that is what
// triggers the automatic daily scan after 6 PM IST, instead of burning the
// user's API quota at app launch while the tab sits unopened in the stack.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_theme.dart';
import '../../core/widgets/brand.dart';
import '../../services/auth_service.dart';
import '../calls_board/calls_screen.dart';
import '../fno/fno_hub_screen.dart';
import '../golden_cross/golden_cross_screen.dart';
import '../ipo_screener/ipo_screener_screen.dart';
import '../magic_formula/magic_formula_screen.dart';
import '../magic_formula/fno_scanner/fno_scanner_screen.dart';
import '../paper_trading/paper_trading_screen.dart';
import '../reports/reports_screen.dart';
import '../rsi_scanner/rsi_scanner_screen.dart';
import '../settings/settings_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  static const List<String> _titles = [
    'IPO Screener',
    'Golden Cross',
    'RSI Scanner',
    'Paper Trading',
    'Reports',
  ];

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            const BrandMark(size: 26),
            const SizedBox(width: 10),
            Flexible(
              child: Text(_titles[_index], overflow: TextOverflow.ellipsis),
            ),
            if (!auth.isLoggedIn) ...[
              const SizedBox(width: 8),
              Tooltip(
                message: 'Not logged in — showing cached data',
                child: Icon(
                  Icons.cloud_off_rounded,
                  size: 17,
                  color: Theme.of(context).colorScheme.error,
                ),
              ),
            ],
          ],
        ),
        actions: [
          // Options Calls Board (1.5.71) — standalone module, apne aap.
          IconButton(
            tooltip: 'Calls Board — Telegram channels se buy/sell calls follow',
            icon: const Icon(Icons.cell_tower_rounded),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const CallsScreen()),
            ),
          ),
          IconButton(
            tooltip: 'Magic Formula screener',
            icon: const Icon(Icons.auto_graph_rounded),
            onPressed: () => _openMagicTools(context),
          ),
          // The F&O module lives behind its own hub instead of a sixth tab:
          // derivatives deserve their own screens, and the five equity tabs stay
          // exactly where they were.
          TextButton.icon(
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const FnoHubScreen()),
            ),
            icon: const Icon(Icons.candlestick_chart_rounded, size: 17),
            label: const Text('F&O', style: TextStyle(fontSize: 12.5)),
          ),
          IconButton(
            tooltip: 'Settings',
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const SettingsScreen()),
            ),
          ),
          const SizedBox(width: 4),
        ],
      ),
      // Every tab keeps its state (IndexedStack), but the switch itself fades
      // and lifts a few pixels — so changing tabs feels like a transition
      // rather than a repaint. The key restarts the tween on each change.
      body: TweenAnimationBuilder<double>(
        key: ValueKey<int>(_index),
        tween: Tween<double>(begin: 0, end: 1),
        duration: AppMotion.base,
        curve: AppMotion.enter,
        builder: (context, t, child) => Opacity(
          opacity: t,
          child: Transform.translate(
            offset: Offset(0, (1 - t) * 8),
            child: child,
          ),
        ),
        child: IndexedStack(
          index: _index,
          children: [
            const IpoScreenerScreen(),
            GoldenCrossScreen(active: _index == 1),
            RsiScannerScreen(active: _index == 2),
            const PaperTradingScreen(),
            const ReportsScreen(),
          ],
        ),
      ),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Divider(
            height: 1,
            color: Theme.of(
              context,
            ).colorScheme.outlineVariant.withValues(alpha: 0.5),
          ),
          NavigationBar(
            selectedIndex: _index,
            onDestinationSelected: (value) => setState(() => _index = value),
            destinations: const [
              NavigationDestination(
                icon: Icon(Icons.new_releases_outlined),
                selectedIcon: Icon(Icons.new_releases_rounded),
                label: 'IPO',
              ),
              NavigationDestination(
                icon: Icon(Icons.timeline_outlined),
                selectedIcon: Icon(Icons.timeline_rounded),
                label: 'Golden Cross',
              ),
              NavigationDestination(
                icon: Icon(Icons.speed_outlined),
                selectedIcon: Icon(Icons.speed_rounded),
                label: 'RSI',
              ),
              NavigationDestination(
                icon: Icon(Icons.account_balance_wallet_outlined),
                selectedIcon: Icon(Icons.account_balance_wallet_rounded),
                label: 'Paper Trade',
              ),
              NavigationDestination(
                icon: Icon(Icons.bar_chart_outlined),
                selectedIcon: Icon(Icons.bar_chart_rounded),
                label: 'Reports',
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// Magic Formula icon = do function (user-approved): the classic screener
  /// and the F&O Scanner. Ek chooser — dono ek tap door, app bar bhi saaf.
  void _openMagicTools(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Text('🧠', style: TextStyle(fontSize: 22)),
              title: const Text('Magic Formula'),
              subtitle: const Text('ROCE + Earnings Yield screener (equity)'),
              onTap: () {
                Navigator.of(sheetContext).pop();
                Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => const MagicFormulaScreen(),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Text('📡', style: TextStyle(fontSize: 22)),
              title: const Text('F&O Scanner'),
              subtitle: const Text(
                'Top gainers/losers · OI change · Narrow CPR · Volume ×2 '
                '— shortlist + trade plan',
              ),
              onTap: () {
                Navigator.of(sheetContext).pop();
                Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => const FnoScannerScreen(),
                  ),
                );
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}
