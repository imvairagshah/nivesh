// ---------------------------------------------------------------------------
// calls_screen.dart — Options Calls Board (1.5.71), standalone module.
//
// Three tabs: 📞 Calls (captured calls + live status), 🏆 Scoreboard
// (channel-wise accuracy), 📺 Channels (add/remove any public t.me link).
// Design: 1.5.58 rules — labelled chips, emoji + short labels, tooltips,
// honest '—' for missing values.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_theme.dart';
import '../../core/widgets/motion.dart';
import '../../core/widgets/ui.dart';
import 'calls_models.dart';
import 'calls_provider.dart';

class CallsScreen extends StatefulWidget {
  const CallsScreen({super.key});

  @override
  State<CallsScreen> createState() => _CallsScreenState();
}

class _CallsScreenState extends State<CallsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final p = context.read<CallsProvider>();
      p.init();
      p.startAuto();
    });
  }

  @override
  Widget build(BuildContext context) {
    final p = context.watch<CallsProvider>();
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Calls Board'),
          bottom: const TabBar(
            tabs: [
              Tab(icon: Text('📞', style: TextStyle(fontSize: 15)), text: 'Calls'),
              Tab(icon: Text('🏆', style: TextStyle(fontSize: 15)), text: 'Scoreboard'),
              Tab(icon: Text('📺', style: TextStyle(fontSize: 15)), text: 'Channels'),
            ],
          ),
          actions: [
            IconButton(
              tooltip: 'Channels scan — nayi calls capture karo',
              icon: p.scanning
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.radar_rounded),
              onPressed: p.scanning ? null : () => p.scanAll(),
            ),
            IconButton(
              tooltip: 'Track — open calls ke SL/target abhi ke rates pe check',
              icon: p.tracking
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.bolt_rounded),
              onPressed: p.tracking ? null : () => p.trackNow(),
            ),
          ],
        ),
        body: TabBarView(
          children: [
            _CallsTab(p: p),
            _ScoreboardTab(p: p),
            _ChannelsTab(p: p),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------

class _CallsTab extends StatelessWidget {
  const _CallsTab({required this.p});
  final CallsProvider p;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    if (p.calls.isEmpty && p.channels.isEmpty) {
      return const _Empty(
        emoji: '📞',
        text: 'Pehle Channels tab se Telegram channel add karo — '
            'phir yahan unki buy/sell calls aa jayengi aur SL/target '
            'khud track honge.',
      );
    }
    return FadeSlideIn(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 24),
        children: [
          Text(
            p.note ?? 'Calls channel messages se capture hoti hain — '
                'SL/target call ke apne numbers se.',
            style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
          ),
          const SizedBox(height: 8),
          if (p.calls.isEmpty)
            const _Empty(emoji: '📭', text: 'Abhi koi call capture nahi hui.')
          else
            for (final call in p.calls) _CallCard(call: call),
          const SizedBox(height: 10),
          const Text(
            'Ye PAPER FOLLOWING hai — app trade nahi lagata. Outcomes call ke '
            'apne SL/target se mechanical rules ke hisaab se lagte hain; '
            'guarantee nahi. Trading se pehle khud verify karo.',
            style: TextStyle(fontSize: 10.5, height: 1.5),
          ),
        ],
      ),
    );
  }
}

class _CallCard extends StatelessWidget {
  const _CallCard({required this.call});
  final CallRecord call;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final gain = MarketColors.of(context).gain;
    final loss = MarketColors.of(context).loss;
    final statusColor = call.status.isWin
        ? gain
        : call.status == CallStatus.sl
            ? loss
            : scheme.onSurfaceVariant;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: _Section(
        emoji: call.side.emoji,
        title:
            '${call.instrumentLabel} · ${call.side.label}  ·  @${call.channel}',
        tooltip: call.rawText,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Wrap(
              spacing: 6,
              runSpacing: 4,
              children: [
                _chip(context, 'Entry', call.entry?.toStringAsFixed(1) ?? '—',
                    tooltip: 'Call me likha entry price — nahi tha to capture '
                        'LTP (note dekho)'),
                _chip(context, 'SL', call.sl?.toStringAsFixed(1) ?? '—',
                    tooltip: 'Call ka stop-loss'),
                _chip(context, 'T1', call.target1?.toStringAsFixed(1) ?? '—',
                    tooltip: 'Target 1'),
                _chip(context, 'T2', call.target2?.toStringAsFixed(1) ?? '—',
                    tooltip: 'Target 2'),
                _chip(
                  context,
                  'LTP',
                  call.status == CallStatus.open
                      ? (call.lastLtp?.toStringAsFixed(1) ?? '—')
                      : (call.exitPrice?.toStringAsFixed(1) ?? '—'),
                  tooltip: call.status == CallStatus.open
                      ? 'Last tracked live price'
                      : 'Exit price (rule se)',
                ),
              ],
            ),
            const SizedBox(height: 5),
            Row(
              children: [
                Text(
                  '${call.status.emoji} ${call.status.label}',
                  style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w700,
                    color: statusColor,
                  ),
                ),
                const SizedBox(width: 8),
                if (call.points != null)
                  Text(
                    '${call.points! >= 0 ? '+' : ''}${call.points!.toStringAsFixed(1)} pts',
                    style: TextStyle(
                      fontSize: 11.5,
                      fontWeight: FontWeight.w700,
                      color: call.points! >= 0 ? gain : loss,
                    ),
                  ),
                const Spacer(),
                Text(
                  _when(call.ts),
                  style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant),
                ),
              ],
            ),
            if (call.note.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 3),
                child: Text(
                  'ℹ️ ${call.note}',
                  style:
                      TextStyle(fontSize: 10, color: scheme.onSurfaceVariant),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _chip(BuildContext context, String label, String value,
      {String? tooltip}) {
    return Tooltip(
      message: tooltip ?? label,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
        decoration: BoxDecoration(
          color: Theme.of(context)
              .colorScheme
              .surfaceContainerHighest
              .withOpacity(0.5),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(
          '$label $value',
          style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------

class _ScoreboardTab extends StatelessWidget {
  const _ScoreboardTab({required this.p});
  final CallsProvider p;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final gain = MarketColors.of(context).gain;
    if (p.stats.isEmpty) {
      return const _Empty(
        emoji: '🏆',
        text: 'Scoreboard tabhi banega jab calls track hon — pehle channel '
            'add karo.',
      );
    }
    return FadeSlideIn(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 24),
        children: [
          for (final s in p.stats) ...[
            _Section(
              emoji: '📺',
              title: '@${s.handle}',
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        s.winPct == null
                            ? 'Win % —'
                            : 'Win ${s.winPct!.toStringAsFixed(0)}%',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          color: s.winPct == null
                              ? scheme.onSurfaceVariant
                              : s.winPct! >= 50
                                  ? gain
                                  : scheme.onSurface,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Text(
                        '${s.wins}W · ${s.losses}L · ${s.expired}E · ${s.open} open',
                        style: TextStyle(
                            fontSize: 11, color: scheme.onSurfaceVariant),
                      ),
                    ],
                  ),
                  const SizedBox(height: 5),
                  Wrap(
                    spacing: 6,
                    runSpacing: 4,
                    children: [
                      _stat(context, 'Total calls', '${s.total}'),
                      _stat(context, 'Closed', '${s.closed}'),
                      _stat(
                          context,
                          'Avg pts',
                          s.closed == 0
                              ? '—'
                              : '${s.avgPoints >= 0 ? '+' : ''}${s.avgPoints.toStringAsFixed(1)}'),
                    ],
                  ),
                  if (s.smallSample)
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Text(
                        '⚠️ Sample chhota hai (${s.closed} closed) — '
                        'abhi ke % sirf ishint hain.',
                        style: TextStyle(
                            fontSize: 10, color: scheme.onSurfaceVariant),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 8),
          ],
          const Text(
            'Win % = closed calls me target-hit ka hissa. Avg pts = call ke '
            'apne SL/target numbers se (points rule), koi guess nahi. Sample '
            'bada hone par hi channel ranking meaningful hai.',
            style: TextStyle(fontSize: 10.5, height: 1.5),
          ),
        ],
      ),
    );
  }

  Widget _stat(BuildContext context, String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: Theme.of(context)
            .colorScheme
            .surfaceContainerHighest
            .withOpacity(0.5),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        '$label $value',
        style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600),
      ),
    );
  }
}

// ---------------------------------------------------------------------------

class _ChannelsTab extends StatefulWidget {
  const _ChannelsTab({required this.p});
  final CallsProvider p;

  @override
  State<_ChannelsTab> createState() => _ChannelsTabState();
}

class _ChannelsTabState extends State<_ChannelsTab> {
  final _controller = TextEditingController();
  String? _adding;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _add() async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    setState(() => _adding = 'Check ho raha hai…');
    final error = await context.read<CallsProvider>().addChannel(text);
    if (!mounted) return;
    setState(() => _adding = null);
    if (error != null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(error)));
    } else {
      _controller.clear();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Channel add ho gaya — backlog capture ho raha hai.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.p;
    final scheme = Theme.of(context).colorScheme;
    return FadeSlideIn(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 24),
        children: [
          _Section(
            emoji: '➕',
            title: 'Channel add karo',
            tooltip: 'Public Telegram channel ka link — jitne chahe add karo',
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: const InputDecoration(
                      hintText: 'https://t.me/channel_name ya @channel_name',
                      isDense: true,
                    ),
                    onSubmitted: (_) => _add(),
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton(
                  onPressed: _adding == null ? _add : null,
                  child: Text(_adding ?? 'Add'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          if (p.channels.isEmpty)
            const _Empty(
              emoji: '📺',
              text: 'Koi channel nahi — upar link daal ke add karo. '
                  'Jitne marzi channels add ho sakte hain.',
            )
          else
            for (final ch in p.channels) ...[
              _Section(
                emoji: '📺',
                title: ch.title,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          ch.enabled ? 'Active ✅' : 'Paused ⏸️',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: ch.enabled
                                ? MarketColors.of(context).gain
                                : scheme.onSurfaceVariant,
                          ),
                        ),
                        const Spacer(),
                        TextButton(
                          onPressed: () =>
                              context.read<CallsProvider>().setEnabled(
                                    ch.handle,
                                    !ch.enabled,
                                  ),
                          child: Text(ch.enabled ? 'Pause' : 'Resume'),
                        ),
                        TextButton(
                          onPressed: () =>
                              context.read<CallsProvider>().removeChannel(
                                    ch.handle,
                                  ),
                          child: const Text('Remove'),
                        ),
                      ],
                    ),
                    if (ch.lastError != null)
                      Text(
                        '⚠️ ${ch.lastError}',
                        style: TextStyle(fontSize: 10, color: scheme.error),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
            ],
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------

/// Single-child InfoSection sugar (1.5.58 sections, one widget inside).
class _Section extends StatelessWidget {
  const _Section({
    required this.title,
    required this.child,
    this.emoji = '',
    this.tooltip,
  });
  final String title;
  final String emoji;
  final String? tooltip;
  final Widget child;

  @override
  Widget build(BuildContext context) => InfoSection(
        title: title,
        emoji: emoji,
        tooltip: tooltip,
        children: [child],
      );
}

class _Empty extends StatelessWidget {
  const _Empty({required this.emoji, required this.text});
  final String emoji;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(emoji, style: const TextStyle(fontSize: 34)),
            const SizedBox(height: 12),
            Text(text, textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}

String _when(DateTime ts) {
  final d = ts.day.toString().padLeft(2, '0');
  final m = ts.month.toString().padLeft(2, '0');
  final h = ts.hour.toString().padLeft(2, '0');
  final mi = ts.minute.toString().padLeft(2, '0');
  return '$d/$m $h:$mi';
}
