// ---------------------------------------------------------------------------
// study_adv_screen.dart — "3 Month Study with Advance Filter".
//
// Two halves, and both are meant to be read rather than admired:
//
//   LIST      the corrected study, with the classic score next to it, a
//             turnover/DTE chip on every row and a "kaun chhoota" sheet that
//             names the gate that removed a stock.
//   MEASURE   does the score actually order outcomes? Bands of score vs what
//             happened next, for the new rules AND the old ones — because the
//             useful question is not "is the score magic?" but "did the
//             corrections help?".
//
// The classic 3-Month Study page is untouched by this screen; it simply runs
// the same engine with a different rule set (see StudyRules in study_engine).
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/utils/markets.dart';
import '../../../core/widgets/ui.dart';
import '../../../data/local/dao/candle_dao.dart';
import '../../../data/local/dao/trade_dao.dart';
import '../../../data/remote/dto/candle.dart';
import '../../../services/fno_study_service.dart';
import '../../../services/earnings_calendar_service.dart';
import '../../../services/live_feed_service.dart';
import '../../../services/market_data_service.dart';
import '../../settings/settings_provider.dart';
import '../../../services/scrip_master_service.dart';
import '../../../data/local/dao/ipo_dao.dart';
import '../../../data/local/dao/scrip_dao.dart';
import '../study/study_engine.dart';
import '../study/study_delivery.dart';
import '../study/study_export.dart';
import '../study/iv_sheet_link.dart';
import '../study/study_widgets.dart';
import 'study_adv_analysis.dart';
import 'study_adv_backtest.dart';
import 'study_adv_mytrades.dart';
import 'study_adv_plan.dart';
import 'study_adv_export.dart';
import 'study_adv_filters.dart';
import 'study_adv_provider.dart';
import 'study_adv_service.dart';

class StudyAdvScreen extends StatelessWidget {
  const StudyAdvScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<StudyAdvProvider>(
      create: (ctx) => StudyAdvProvider(
        service: StudyAdvService(
          study: ctx.read<FnoStudyService>(),
          source: ctx.read<MarketDataService>(),
          candles: ctx.read<CandleDao>(),
        ),
        scripDao: ctx.read<ScripDao>(),
        ipoDao: ctx.read<IpoDao>(),
        scripMaster: ctx.read<ScripMasterService>(),
        // Shared with the rest of the app: one WebSocket session, one settings
        // book, one results calendar.
        feed: ctx.read<LiveFeedService>(),
        settings: ctx.read<SettingsProvider>(),
        earnings: ctx.read<EarningsCalendarService>(),
        // Paper trades ka DAO — "Mera hisaab" tab isi se padhta hai.
        trades: ctx.read<TradeDao>(),
      )..bootstrap(),
      child: const _StudyAdvView(),
    );
  }
}

class _StudyAdvView extends StatefulWidget {
  const _StudyAdvView();

  @override
  State<_StudyAdvView> createState() => _StudyAdvViewState();
}

class _StudyAdvViewState extends State<_StudyAdvView> {
  int _tab = 0;

  @override
  void initState() {
    super.initState();
    // IVP/IVR sheet (1.5.57) — shared cache, Settings me save ki hui link.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      refreshIvSheetIfPossible(context);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('3M Study · Advance Filter'),
        actions: [
          IconButton(
            tooltip: 'Ye kya hai',
            icon: const Icon(Icons.help_outline_rounded),
            onPressed: () => _showReadMe(context),
          ),
          PopupMenuButton<StudyExportKind>(
            tooltip: 'Export',
            icon: const Icon(Icons.ios_share_rounded),
            onSelected: (kind) => _export(context, kind),
            itemBuilder: (_) => [
              for (final kind in StudyExportKind.values)
                PopupMenuItem<StudyExportKind>(
                  value: kind,
                  child: Text(kind.label),
                ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          _AdvControls(tab: _tab, onTab: (value) => setState(() => _tab = value)),
          const Divider(height: 1),
          Expanded(
            child: IndexedStack(
              index: _tab,
              children: [
                const _AdvListTab(),
                const _AdvMeasureTab(),
                _AdvAnalysisTab(active: _tab == 2),
                _AdvMyTradesTab(active: _tab == 3),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Controls (shared by both tabs)
// ---------------------------------------------------------------------------

/// Sends the current table out — the same four ways the classic study offers,
/// through the same delivery service, with both scores in the file.
Future<void> _export(BuildContext context, StudyExportKind kind) async {
  final provider = context.read<StudyAdvProvider>();
  final messenger = ScaffoldMessenger.of(context);
  final settings = context.read<SettingsProvider>();

  if (!provider.hasResult) {
    messenger.showSnackBar(
      const SnackBar(content: Text('Pehle scan chalao — table khaali hai.')),
    );
    return;
  }

  final rows = provider.rows;
  final meta = provider.exportMeta;
  final export = StudyAdvExportService();
  final delivery = StudyDeliveryService(export: StudyExportService());

  try {
    final StudyDeliveryOutcome outcome;
    switch (kind) {
      case StudyExportKind.whatsapp:
        outcome = await delivery.shareText(export.recap(rows, meta));
      case StudyExportKind.excel:
        outcome = await delivery.shareFile(
          await export.writeXlsx(rows: rows, meta: meta),
          'NiveshDesk — 3M Advance Filter',
        );
      case StudyExportKind.csv:
        outcome = await delivery.shareFile(
          await export.writeCsv(rows: rows, meta: meta),
          'NiveshDesk — 3M Advance Filter (CSV)',
        );
      case StudyExportKind.telegram:
        outcome = await delivery.sendTelegramFile(
          file: await export.writeXlsx(rows: rows, meta: meta),
          caption: export.recap(rows, meta),
          settings: settings.settings,
        );
    }
    if (!context.mounted) return;
    messenger.showSnackBar(
      SnackBar(
        content: Text(outcome.message),
        backgroundColor: outcome.ok ? null : Theme.of(context).colorScheme.error,
      ),
    );
  } catch (e) {
    if (!context.mounted) return;
    messenger.showSnackBar(SnackBar(content: Text('Export fail: $e')));
  }
}

class _AdvControls extends StatelessWidget {
  const _AdvControls({required this.tab, required this.onTab});

  final int tab;
  final ValueChanged<int> onTab;

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<StudyAdvProvider>();
    final scheme = Theme.of(context).colorScheme;

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: SegmentedButton<int>(
              showSelectedIcon: false,
              segments: const [
                ButtonSegment<int>(value: 0, label: Text('List')),
                ButtonSegment<int>(value: 1, label: Text('Score ka hisab')),
                ButtonSegment<int>(value: 2, label: Text('Analysis')),
                ButtonSegment<int>(value: 3, label: Text('Mera hisaab')),
              ],
              selected: {tab},
              onSelectionChanged: (value) => onTab(value.first),
            ),
          ),
          const SizedBox(height: 10),
          if (tab == 0) _listControls(context, provider, scheme)
          else _measureControls(context, provider, scheme),
          if (provider.running) ...[
            const SizedBox(height: 8),
            LinearProgressIndicator(value: provider.progressValue),
            const SizedBox(height: 5),
            Text(
              provider.progressLine,
              style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
            ),
          ],
          if (provider.error != null) ...[
            const SizedBox(height: 8),
            Text(
              provider.error!,
              style: TextStyle(fontSize: 12, color: scheme.error),
            ),
          ],
        ],
      ),
    );
  }

  Widget _listControls(
    BuildContext context,
    StudyAdvProvider provider,
    ColorScheme scheme,
  ) {
    final filters = provider.filters;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: provider.busy ? null : provider.scan,
                icon: const Icon(Icons.play_arrow_rounded, size: 18),
                label: Text(provider.hasResult ? 'Dobara scan karo' : 'Scan karo'),
              ),
            ),
            if (provider.running) ...[
              const SizedBox(width: 8),
              OutlinedButton(
                onPressed: provider.cancel,
                child: const Text('Roko'),
              ),
            ],
          ],
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 6,
          children: [
            _chip(
              context,
              label: filters.minTurnoverCrore > 0
                  ? 'turnover ≥ ${filters.minTurnoverCrore.toStringAsFixed(0)} cr'
                  : 'turnover: koi bar nahi',
              active: filters.minTurnoverCrore > 0,
              onTap: () => provider.setMinTurnover(
                  filters.minTurnoverCrore > 0 ? 0 : 10),
            ),
            _chip(
              context,
              label: 'aaj expiry chhod',
              active: filters.blockExpiryDay,
              onTap: () => provider.setBlockExpiryDay(!filters.blockExpiryDay),
            ),
            _chip(
              context,
              label: filters.blockNearExpiryDays > 0
                  ? 'expiry ≤ ${filters.blockNearExpiryDays} din chhod'
                  : 'expiry paas: koi rok nahi',
              active: filters.blockNearExpiryDays > 0,
              onTap: () => provider.setBlockNearExpiry(
                  filters.blockNearExpiryDays > 0 ? 0 : 3),
            ),
            // B3: results paas hone wale stock — gap risk, expiry jaisa.
            // Default OFF, aur chip hamesha dikhta hai (1.5.17).
            _chip(
              context,
              label: filters.blockResultsDays > 0
                  ? 'results ≤ ${filters.blockResultsDays} din chhod'
                  : 'results paas: koi rok nahi',
              active: filters.blockResultsDays > 0,
              onTap: () => provider.setBlockResults(
                  filters.blockResultsDays > 0 ? 0 : 5),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            const Text('Min score', style: TextStyle(fontSize: 11.5)),
            Expanded(
              child: Slider(
                value: filters.minScore,
                min: 0,
                max: 12,
                divisions: 12,
                label: filters.minScore.toStringAsFixed(0),
                onChanged: provider.busy ? null : provider.setMinScore,
              ),
            ),
            SizedBox(
              width: 34,
              child: Text(
                filters.minScore.toStringAsFixed(0),
                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ),
        Text(
          filters.line,
          style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
        ),
        if (provider.stale && !provider.busy)
          Text(
            'Filter badla hai — upar wale number abhi ke hisaab me nahi hain.',
            style: TextStyle(fontSize: 10.5, color: scheme.tertiary),
          ),
        if (provider.note != null && !provider.running)
          Padding(
            padding: const EdgeInsets.only(top: 5),
            child: Text(
              provider.note!,
              style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant),
            ),
          ),
      ],
    );
  }

  Widget _measureControls(
    BuildContext context,
    StudyAdvProvider provider,
    ColorScheme scheme,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: provider.busy ? null : provider.measure,
                icon: const Icon(Icons.query_stats_rounded, size: 18),
                label: Text(provider.backtest == null
                    ? 'Score napo (backtest)'
                    : 'Dobara napo'),
              ),
            ),
            if (provider.running) ...[
              const SizedBox(width: 8),
              OutlinedButton(
                onPressed: provider.cancel,
                child: const Text('Roko'),
              ),
            ],
          ],
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 10,
          runSpacing: 6,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            _chipRow(
              context: context,
              label: 'Itihaas',
              value: provider.years,
              options: const [1, 2, 3],
              labelFor: (v) => '$v saal',
              onChanged: provider.busy ? null : provider.setYears,
            ),
            _chipRow(
              context: context,
              label: 'Aage ka natija',
              value: provider.horizonBars,
              options: const [5, 10, 15],
              labelFor: (v) => '$v din',
              onChanged: provider.busy ? null : provider.setHorizon,
            ),
          ],
        ),
        const SizedBox(height: 6),
        Text(
          'Purane candles par study ka score nikal kar dekha jata hai: us score '
          'wale stock ne aage ke ${provider.horizonBars} din me kya kiya. Koi '
          'andaza nahi, sirf ginti.',
          style: TextStyle(fontSize: 10.5, height: 1.35, color: scheme.onSurfaceVariant),
        ),
        if (provider.note != null && !provider.running)
          Padding(
            padding: const EdgeInsets.only(top: 5),
            child: Text(
              provider.note!,
              style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant),
            ),
          ),
      ],
    );
  }

  Widget _chip(
    BuildContext context, {
    required String label,
    required bool active,
    required VoidCallback onTap,
  }) {
    final scheme = Theme.of(context).colorScheme;
    return ActionChip(
      label: Text(label, style: const TextStyle(fontSize: 11)),
      backgroundColor:
          active ? scheme.primaryContainer : scheme.surfaceContainerHighest,
      onPressed: onTap,
      visualDensity: VisualDensity.compact,
      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
    );
  }

  Widget _chipRow<T>({
    required BuildContext context,
    required String label,
    required T value,
    required List<T> options,
    required String Function(T) labelFor,
    required ValueChanged<T>? onChanged,
  }) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 11.5,
            color: Theme.of(context).colorScheme.onSurfaceVariant,
          ),
        ),
        const SizedBox(width: 6),
        for (final option in options)
          Padding(
            padding: const EdgeInsets.only(right: 5),
            child: ChoiceChip(
              label: Text(labelFor(option)),
              selected: option == value,
              onSelected: onChanged == null ? null : (_) => onChanged(option),
              visualDensity: VisualDensity.compact,
              materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
            ),
          ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Tab 1 — the list
// ---------------------------------------------------------------------------

class _AdvListTab extends StatelessWidget {
  const _AdvListTab();

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<StudyAdvProvider>();
    final scheme = Theme.of(context).colorScheme;
    final result = provider.result;

    if (result == null) {
      return _emptyState(context, scheme);
    }

    final rows = provider.rows;
    if (rows.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(
            'Is filter me koi stock nahi bacha. ${result.funnelLine}\n\n'
            'Min score ghata kar ya turnover bar hata kar dekho.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12.5, color: scheme.onSurfaceVariant),
          ),
        ),
      );
    }

    final expanded = provider.expandedSymbol;

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  result.funnelLine,
                  style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
                ),
              ),
              PopupMenuButton<StudyAdvSort>(
                tooltip: 'Sort',
                icon: const Icon(Icons.sort_rounded, size: 18),
                onSelected: provider.sortBy,
                itemBuilder: (_) => [
                  for (final column in StudyAdvSort.values)
                    PopupMenuItem<StudyAdvSort>(
                      value: column,
                      child: Row(
                        children: [
                          if (provider.sort == column)
                            Icon(Icons.check_rounded,
                                size: 16, color: scheme.primary)
                          else
                            const SizedBox(width: 16),
                          const SizedBox(width: 8),
                          Text(column.label),
                        ],
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView.separated(
            padding: const EdgeInsets.fromLTRB(10, 4, 10, 20),
            itemCount: rows.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (_, index) {
              final row = rows[index];
              final open = expanded == row.row.symbol;
              return Column(
                children: [
                  StudyAdvRowCard(
                    row: row,
                    filters: result.filters,
                    expanded: open,
                    livePremiums: open ? provider.livePremiums : null,
                    liveStrangle: open ? provider.liveStrangle : null,
                    onTap: () => context.read<StudyAdvProvider>().toggleExpanded(row),
                  ),
                  // The same 9-section panel the old page opens, driven by this
                  // page's row (naye niyam ke score ke saath).
                  if (open) StudyAdvDetail(row: row),
                ],
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _emptyState(BuildContext context, ColorScheme scheme) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 24),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Wahi study, sudhaare hue niyam ke saath',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Ye page purane “3-Month Study” ko chhota nahi karta — wo '
                  'waise hi chalega. Yahan wahi study sudhaare hue niyam ke '
                  'saath milti hai:',
                  style: TextStyle(fontSize: 12, height: 1.4),
                ),
                const SizedBox(height: 8),
                _bullet('🎯 Best Buy ab sirf “IV sasta” par nahi milta — '
                    'premium stock ki chal se mehenga ho to “Watch”.'),
                _bullet('High aur low se doori ab EK hi paimaane se naapi '
                    'jati hai (upar aur neeche ke score ab aapas me barabar).'),
                _bullet('Adhura mahina (2-3 session) poora mahina nahi gina '
                    'jata — 2 din ki chal se consistency nahi hilta.'),
                _bullet('Har row ke saath turnover (liquidity) aur expiry ke '
                    'din — jise bhar nahi sakte wo list me nahi.'),
                _bullet('Expiry ke 3 din ya kam bache hon to 🎯 khud hi '
                    '“Watch” ho jata hai (aaj expiry to kabhi nahi).'),
                _bullet('Sirf 2 mahine dikh rahe hon to consistency 3 point '
                    'nahi maangta — jitne mahine dekhe, utne point.'),
                const SizedBox(height: 8),
                Text(
                  'Aur har row par DO score: naya (sudhaar ke baad) aur '
                  'purana — taaki farq aapki aankh se dekha ja sake.',
                  style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _bullet(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 5),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('•  ', style: TextStyle(fontSize: 12)),
            Expanded(
              child: Text(text, style: const TextStyle(fontSize: 12, height: 1.35)),
            ),
          ],
        ),
      );
}

/// One row of the list — public so the numbers a user reads (both scores, the
/// delta, turnover, expiry) can be pinned by a widget test.
class StudyAdvRowCard extends StatelessWidget {
  const StudyAdvRowCard({
    super.key,
    required this.row,
    this.filters,
    this.expanded = false,
    this.onTap,
    this.livePremiums,
    this.liveStrangle,
  });

  final StudyAdvRow row;

  /// The open row's live premiums — the feed subscribes only to that row, so
  /// a closed card prints the frozen scan values. Live wins when it is there.
  final Map<String, double>? livePremiums;
  final Map<String, double>? liveStrangle;

  /// The filters in force when the list was built — a blocked row's line quotes
  /// the number that failed (`turnover 4.2 cr < 10 cr`), so the card needs them.
  final StudyAdvFilters? filters;

  final bool expanded;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final study = row.row;
    final classic = row.classic;

    return Card(
      color: row.blocked
          ? scheme.surfaceContainerLow
          : (expanded ? scheme.primaryContainer.withOpacity(0.18) : null),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  '#${study.rank}',
                  style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
                ),
                const SizedBox(width: 6),
                Text(
                  study.symbol,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                if (study.companyName.isNotEmpty)
                  Expanded(
                    child: Text(
                      '  ${study.companyName}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 10.5,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                  )
                else
                  const Spacer(),
                // Opstra IVP/IVR chip (1.5.57) — sheet values se, hide when
                // the sheet has no row for this symbol.
                IvSheetChip(symbol: study.symbol, fontSize: 9.5),
                Text(
                  '₹${_money(study.ltp)}',
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                ),
              ],
            ),
            const SizedBox(height: 5),
            Text(
              study.opportunityTag,
              style: TextStyle(
                fontSize: 11.5,
                fontWeight: FontWeight.w700,
                color: study.isBestBuy ? _gain(context) : scheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 7),
            // 1.5.58 — har metric apne box me (values kabhi judte nahi).
            MetricGrid(
              children: [
                MetricBox(
                  emoji: '⭐',
                  label: 'Score naya',
                  value: study.score.toStringAsFixed(1),
                  strong: true,
                  tooltip: 'Naya scoring model ka score',
                ),
                MetricBox(
                  label: 'purana',
                  value: classic == null ? '—' : classic.score.toStringAsFixed(1),
                  tooltip: 'Purane model ka score',
                ),
                MetricBox(
                  label: 'farq',
                  value: classic == null ? '—' : _signed(row.scoreDelta),
                  valueColor: classic == null
                      ? null
                      : (row.scoreDelta >= 0 ? _gain(context) : _loss(context)),
                  tooltip: 'Naye aur purane score ka farq',
                ),
                MetricBox(
                  emoji: '🎲',
                  label: 'edge',
                  value: study.edgePct == null
                      ? '—'
                      : '${_signed(study.edgePct!)}%',
                  tooltip: 'Jodi ka daam vs stock ka normal move',
                ),
                // IVP/IVR (1.5.69) — Opstra sheet se, card ke andar boxes.
                ...ivMetricBoxes(study.symbol),
              ],
            ),
            const SizedBox(height: 7),
            Wrap(
              spacing: 6,
              runSpacing: 5,
              children: [
                _tag(context, 'turnover ${row.turnoverCrore.toStringAsFixed(1)} cr',
                    emoji: '💧'),
                if (study.daysToExpiry != null)
                  _tag(context, 'expiry ${study.daysToExpiry} din', emoji: '⏳'),
                _tag(context, study.trend.label, emoji: '📊'),
                _tag(context, 'ATR ${study.atrPct.toStringAsFixed(1)}%', emoji: '⚡'),
                _tag(
                  context,
                  '${study.total3mPct >= 0 ? '+' : ''}${study.total3mPct.toStringAsFixed(1)}% 3M',
                  emoji: '📈',
                ),
              ],
            ),
            // The jodi, on the card itself: the two strikes, what the pair
            // costs, and what it would have done since yesterday. This is the
            // line the study is actually read for — a score without a price is
            // a number, not a trade.
            _jodiLine(context, study, scheme),
            // A held-back row must say why, on the row itself — a filter that
            // thins the list without explaining itself is a bug (1.5.17).
            if (row.blocked) ...[
              const SizedBox(height: 7),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 1),
                    child: Icon(
                      Icons.block_rounded,
                      size: 12,
                      color: scheme.error,
                    ),
                  ),
                  const SizedBox(width: 5),
                  Expanded(
                    child: Text(
                      'CHHOOTA — ${row.gateLine(filters ?? const StudyAdvFilters())}',
                      style: TextStyle(
                        fontSize: 10.5,
                        height: 1.3,
                        color: scheme.error,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
      ),
    );
  }

  /// `OTM jodi 24500 PE + 25500 CE = ₹13.40 · kal ₹12.10 (Profit 1.30 pts)`,
  /// or an honest line about what is missing.
  Widget _jodiLine(BuildContext context, StudyRow study, ColorScheme scheme) {
    // Live premium first (only the open row has one), the scan's own numbers
    // otherwise — the same helper the panel uses, so the two agree.
    final liveOtm = _pair(liveStrangle?['CE'], liveStrangle?['PE']);
    final liveAtm = _pair(livePremiums?['CE'], livePremiums?['PE']);
    final otmValue = liveOtm ?? study.strangleLtp;
    final atmValue = liveAtm ?? study.straddleLtp;
    final otmPct = premiumPctOfPrice(otmValue, study.ltp);
    final atmPct = premiumPctOfPrice(atmValue, study.ltp);

    final strangle = study.strangle;
    final pair = strangle?.ce != null || strangle?.pe != null ? strangle : null;

    String jodi;
    if (pair == null || !pair.isComplete) {
      jodi = 'OTM jodi: is stock ka option chain nahi mila';
    } else {
      final ce = pair.ce!;
      final pe = pair.pe!;
      final today = otmValue ?? pair.total;
      final yesterday = pair.hasYesterday ? pair.yesterday(study.lotSize) : null;
      jodi = 'OTM jodi ${_strike(pe.strike)} PE + ${_strike(ce.strike)} CE';
      if (today != null) {
        jodi = '$jodi = ₹${today.toStringAsFixed(2)}';
        if (otmPct != null) {
          jodi = '$jodi (${otmPct.toStringAsFixed(2)}% of price)';
        }
      }
      if (yesterday != null) {
        jodi = '$jodi · kal ₹${pair.buyCost!.toStringAsFixed(2)} → '
            '${StudyExportService.pointsWords(yesterday.points)}';
      }
    }

    final iv = study.avgIv;
    final bits = <String>[
      jodi,
      if (iv != null) 'IV ${iv.toStringAsFixed(1)}%',
      if (atmValue != null)
        'ATM jodi ₹${atmValue.toStringAsFixed(2)}'
            '${atmPct == null ? '' : ' (${atmPct.toStringAsFixed(2)}% of price)'}',
      if (study.daysToExpiry != null) '${study.daysToExpiry} din',
    ];

    return Padding(
      padding: const EdgeInsets.only(top: 7),
      child: Text(
        bits.join('  ·  '),
        style: TextStyle(
          fontSize: 10.5,
          height: 1.35,
          color: scheme.onSurfaceVariant,
        ),
      ),
    );
  }

  /// Two legs make a jodi — one leg alone is not a price.
  double? _pair(double? ce, double? pe) =>
      (ce == null || pe == null) ? null : ce + pe;

  String _strike(double strike) =>
      strike == strike.roundToDouble()
          ? strike.toStringAsFixed(0)
          : strike.toStringAsFixed(1);

  Widget _tag(BuildContext context, String text, {String emoji = ''}) {
    // 1.5.58 — press-feedback chip; emoji alag Text hai to labels exact
    // rehte hain (exports/tests pin them).
    return TapChip(
      emoji: emoji,
      label: text,
      color: Theme.of(context).colorScheme.onSurfaceVariant,
      filled: true,
    );
  }
}

// ---------------------------------------------------------------------------
// The open row — the old page's full panel, with this page's two scores on top
// ---------------------------------------------------------------------------

/// Wraps the study's 9-section detail panel: price/3M levels, ATR, monthly
/// moves, trend, ATM option + IV, **OTM jodi**, results, "agar kal jodi buy ki
/// hoti" and "agar kal OTM jodi buy ki hoti".
///
/// The panel itself is the old page's widget, reused unchanged — the numbers in
/// it come from this page's row, so they are the corrected run's numbers.
class StudyAdvDetail extends StatelessWidget {
  const StudyAdvDetail({super.key, required this.row});

  final StudyAdvRow row;

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<StudyAdvProvider>();
    final scheme = Theme.of(context).colorScheme;
    final study = row.row;
    final classic = row.classic;

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Both scores, so the point of this page is not lost inside a panel
          // that only ever printed one.
          Card(
            color: scheme.surfaceContainerHighest.withValues(alpha: 0.5),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 9, 12, 9),
              child: Row(
                children: [
                  Text(
                    'Naya ${study.score.toStringAsFixed(1)}',
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(width: 10),
                  if (classic != null)
                    Text(
                      'Purana ${classic.score.toStringAsFixed(1)}',
                      style: TextStyle(
                        fontSize: 12,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                  const SizedBox(width: 10),
                  if (classic != null)
                    Text(
                      _signed(row.scoreDelta),
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: row.scoreDelta >= 0 ? _gain(context) : _loss(context),
                      ),
                    ),
                  const Spacer(),
                  TextButton.icon(
                    onPressed: () => context.read<StudyAdvProvider>().collapse(),
                    icon: const Icon(Icons.keyboard_arrow_up_rounded, size: 16),
                    label: const Text('Band karo'),
                  ),
                ],
              ),
            ),
          ),
          StudyDetailPanel(
            row: study,
            livePremiums: provider.livePremiums,
            liveKalPremiums: provider.liveKalPremiums,
            liveStrangle: provider.liveStrangle,
            liveKalStrangle: provider.liveKalStrangle,
            liveFeedActive: provider.liveFeedActive,
            earnings: provider.earningsFor(study.symbol),
            earningsNote: provider.earningsNote,
            earningsLoading: provider.isLoadingEarnings,
            onClose: () => context.read<StudyAdvProvider>().collapse(),
          ),
          // B4: "aaj kya kare" — entry / stop / target, teenon raaste.
          StudyPlanCard(symbol: study.symbol),
        ],
      ),
    );
  }
}

/// "Aaj kya kare" wala card — entry, stop, target.
///
/// Poori tarah offline: CMP, ATR aur DP ke level phone ke purane candles se.
/// Teen raaste (stock / option kharido / option becho), aur har ek ke saath
/// likha hai ki hisaab kis cheez se bana — mechanical niyam hai, guarantee
/// nahi.
class StudyPlanCard extends StatelessWidget {
  const StudyPlanCard({super.key, required this.symbol});

  final String symbol;

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<StudyAdvProvider>();
    final scheme = Theme.of(context).colorScheme;
    final plan = provider.planFor(symbol);

    if (plan == null) {
      // Candles abhi padhe ja rahe hain ya mile hi nahi — dono me kuch likha
      // jana chahiye; khaali jagah bharosa todti hai.
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(13),
          child: Text(
            provider.planReady(symbol)
                ? 'Plan ke liye is stock ke kaafi candles nahi mile.'
                : 'Plan ban raha hai — phone ke candles padhe ja rahe hain…',
            style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant),
          ),
        ),
      );
    }

    return StudyPlanBody(plan: plan);
  }
}

/// Plan ka poora khaka — public isliye ki ise bina provider ke, seedhe banaye
/// gaye plan ke saath test kiya ja sake.
class StudyPlanBody extends StatelessWidget {
  const StudyPlanBody({super.key, required this.plan});

  final TradePlan plan;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(13, 11, 13, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.flag_outlined, size: 15),
                const SizedBox(width: 6),
                const Text(
                  'Aaj kya kare (plan)',
                  style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800),
                ),
                const Spacer(),
                Text(
                  'offline hisaab',
                  style:
                      TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
                ),
              ],
            ),
            const SizedBox(height: 10),
            if (plan.stock != null) _StockPlanBlock(plan: plan.stock!),
            if (plan.optionBuy != null) ...[
              if (plan.stock != null) const Divider(height: 16),
              _OptionBuyBlock(plan: plan.optionBuy!),
            ],
            if (plan.optionSell != null) ...[
              const Divider(height: 16),
              _OptionSellBlock(plan: plan.optionSell!),
            ],
            const SizedBox(height: 10),
            Text(
              plan.notes,
              style: TextStyle(fontSize: 10.5, height: 1.4,
                  color: scheme.onSurfaceVariant),
            ),
          ],
        ),
      ),
    );
  }
}

class _StockPlanBlock extends StatelessWidget {
  const _StockPlanBlock({required this.plan});

  final StockPlan plan;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Stock ${plan.side.label}',
          style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700,
              color: plan.side == PlanSide.sell ? _loss(context) : _gain(context)),
        ),
        const SizedBox(height: 4),
        _PlanLine(label: 'entry', value: '₹${plan.entry.toStringAsFixed(2)}'),
        _PlanLine(
          label: 'stop',
          value: '₹${plan.stop.toStringAsFixed(2)} (${plan.stopPctText})',
          color: _loss(context),
        ),
        _PlanLine(
          label: 'target',
          value: '₹${plan.target.toStringAsFixed(2)} (${plan.targetPctText})',
          color: _gain(context),
        ),
        const SizedBox(height: 3),
        Text(
          '${plan.basisNote} · ${plan.ratioText}',
          style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
        ),
        if (plan.sideNote.isNotEmpty)
          Text(
            '⚠ ${plan.sideNote}',
            style: TextStyle(fontSize: 10.5, color: scheme.error),
          ),
      ],
    );
  }
}

class _OptionBuyBlock extends StatelessWidget {
  const _OptionBuyBlock({required this.plan});

  final OptionBuyPlan plan;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '${plan.type} kharido (${plan.strike.toStringAsFixed(0)})',
          style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 4),
        _PlanLine(label: 'premium', value: '₹${plan.premium.toStringAsFixed(2)}'),
        _PlanLine(
          label: 'stop',
          value:
              '₹${plan.stopPremium.toStringAsFixed(2)} (${plan.stopPct.toStringAsFixed(0)}%)',
          color: _loss(context),
        ),
        _PlanLine(
          label: 'target',
          value:
              '₹${plan.targetPremium.toStringAsFixed(2)} (+${plan.targetPct.toStringAsFixed(0)}%)',
          color: _gain(context),
        ),
        const SizedBox(height: 3),
        Text(
          'spot ₹${plan.spotStop.toStringAsFixed(0)} / '
          '₹${plan.spotTarget.toStringAsFixed(0)} · ${plan.note}',
          style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
        ),
      ],
    );
  }
}

class _OptionSellBlock extends StatelessWidget {
  const _OptionSellBlock({required this.plan});

  final OptionSellPlan plan;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Jodi becho (strangle)',
          style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 4),
        _PlanLine(label: 'milega', value: '₹${plan.premium.toStringAsFixed(2)}'),
        _PlanLine(
          label: 'target',
          value: '₹${plan.targetPremium.toStringAsFixed(2)} (premium ka aadha)',
          color: _gain(context),
        ),
        _PlanLine(
          label: 'stop',
          value: '₹${plan.stopPremium.toStringAsFixed(2)} (premium ka 1.5×)',
          color: _loss(context),
        ),
        if (plan.bandNote.isNotEmpty) ...[
          const SizedBox(height: 3),
          Text(
            plan.bandNote,
            style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
          ),
        ],
      ],
    );
  }
}

class _PlanLine extends StatelessWidget {
  const _PlanLine({required this.label, required this.value, this.color});

  final String label;
  final String value;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 1),
      child: Row(
        children: [
          SizedBox(
            width: 52,
            child: Text(
              label,
              style: TextStyle(
                fontSize: 11,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 11.5,
              fontWeight: FontWeight.w600,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Tab 2 — does the score work?
// ---------------------------------------------------------------------------

class _AdvMeasureTab extends StatelessWidget {
  const _AdvMeasureTab();

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<StudyAdvProvider>();
    final result = provider.backtest;

    if (result == null) {
      return ListView(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 24),
        children: const [
          Card(
            child: Padding(
              padding: EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Kya score sach me kaam karta hai?',
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Study ke 12 point kisi ne naap kar nahi banaye — chaar '
                    'factor, soch ke weights. Yahan wo naape jate hain: purane '
                    'candles par score nikal kar dekha jata hai ki us score '
                    'wale stock ne aage ke 5/10/15 din me kya kiya.',
                    style: TextStyle(fontSize: 12, height: 1.4),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Natija chaar band me: 0–4 · 4–7 · 7–9 · 9–12. Agar score '
                    'matlab rakhta hai to upar wale band ka natija neeche wale '
                    'se behtar hona chahiye. Nahi hua to app yahi likh kar '
                    'bataega — chhupayega nahi.',
                    style: TextStyle(fontSize: 12, height: 1.4),
                  ),
                ],
              ),
            ),
          ),
        ],
      );
    }

    return StudyAdvMeasureReport(result: result);
  }

}

/// The measurement, as the user reads it — public so the bands and the honest
/// verdict can be pinned by a widget test.
class StudyAdvMeasureReport extends StatelessWidget {
  const StudyAdvMeasureReport({super.key, required this.result});

  final StudyScoreBacktest result;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    // Even a run that measured nothing must say so — a blank tab looks broken.
    if (result.isEmpty) {
      return ListView(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 24),
        children: [
          Card(
            color: scheme.tertiaryContainer.withValues(alpha: 0.4),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Text(
                result.verdict,
                style:
                    const TextStyle(fontSize: 13, fontWeight: FontWeight.w800),
              ),
            ),
          ),
          const SizedBox(height: 10),
          _finePrintCard(context, result),
        ],
      );
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 24),
      children: [
        Card(
          color: result.separates
              ? scheme.primaryContainer.withValues(alpha: 0.35)
              : scheme.tertiaryContainer.withValues(alpha: 0.4),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  result.verdict,
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 8),
                Text(
                  result.comparisonNote,
                  style: const TextStyle(fontSize: 11.5, height: 1.4),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        _bucketTable(
          context,
          title: 'Naye niyam (is page ke score)',
          buckets: result.advanced,
        ),
        const SizedBox(height: 10),
        _bucketTable(
          context,
          title: 'Purane niyam (classic study ke score)',
          buckets: result.classic,
        ),
        const SizedBox(height: 10),
        _finePrintCard(context, result),
      ],
    );
  }

  Widget _finePrintCard(BuildContext context, StudyScoreBacktest result) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Puri jankari',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 6),
            for (final line in _finePrint(result))
              Padding(
                padding: const EdgeInsets.only(bottom: 5),
                child: Text(
                  line,
                  style: TextStyle(
                    fontSize: 11,
                    height: 1.35,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  List<String> _finePrint(StudyScoreBacktest result) => [
        '${result.config.line} · ${result.symbols} stock · '
            '${result.evaluations} baar score nikala · ${result.trades} trade gina.',
        'Har stock ke itihaas me ausat ${result.barsUsed} session the.',
        if (result.skipped > 0)
          '${result.skipped} stock ka itihaas kam tha ya nahi mila — wo hisaab me nahi.',
        'Sideways (AVOID) wale din trade gine hi nahi gaye — study khud kehti '
            'hai “mat karo”.',
        'UP trend ko kharida hua (long) aur DOWN trend ko becha hua (short) '
            'maan kar naapa gaya — study ka apna suggestion, koi alag soch nahi.',
        'Ye stock (underlying) ka natija hai, option ka nahi. Kharcha '
            '(brokerage/slippage) shamil nahi hai.',
        'Ye bita hua hisaab hai, bhavishya ka vaada nahi — isse koi guarantee '
            'nahi hai.',
      ];

  Widget _bucketTable(
    BuildContext context, {
    required String title,
    required List<StudyBucket> buckets,
  }) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            for (final bucket in buckets)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 5),
                child: Row(
                  children: [
                    SizedBox(
                      width: 52,
                      child: Text(
                        bucket.label,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    Expanded(
                      child: Text(
                        bucket.line,
                        style: TextStyle(
                          fontSize: 11.5,
                          color: bucket.isEmpty
                              ? scheme.onSurfaceVariant
                              : (bucket.avgReturnPct >= 0
                                  ? _gain(context)
                                  : _loss(context)),
                        ),
                      ),
                    ),
                    if (!bucket.isEmpty && !bucket.enoughSamples)
                      Text(
                        bucket.confidenceLabel,
                        style: TextStyle(
                          fontSize: 9.5,
                          color: scheme.tertiary,
                        ),
                      ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Read Me
// ---------------------------------------------------------------------------

void _showReadMe(BuildContext context) {
  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) => DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.75,
      maxChildSize: 0.92,
      minChildSize: 0.4,
      builder: (_, controller) => ListView(
        controller: controller,
        padding: const EdgeInsets.fromLTRB(18, 6, 18, 24),
        children: const [
          Text(
            '3 Month Study with Advance Filter',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
          ),
          SizedBox(height: 12),
          Text(
            'Purana “3-Month Study” page bilkul waise hi hai — ek line bhi '
            'nahi badli. Ye naya page wahi study chaar sudhaar aur kuch naye '
            'filter ke saath chalata hai, taaki aap dono ko compare kar sakein.',
            style: TextStyle(fontSize: 12.5, height: 1.45),
          ),
          SizedBox(height: 12),
          Text('Chaaro sudhaar', style: TextStyle(fontWeight: FontWeight.w800)),
          SizedBox(height: 4),
          Text(
            '1. 🎯 Best Buy ab sirf “IV sasta” par nahi milta — premium stock '
            'ki chal se mehenga ho (edge < 0) to “Watch”.\n'
            '2. High aur low se doori ek hi paimaane se (CMP se) — upar aur '
            'neeche ke score ab barabar.\n'
            '3. Adhura mahina (2-3 session) poora mahina nahi gina jata.\n'
            '4. Kam mahine hon to consistency poore 3 point nahi leta.',
            style: TextStyle(fontSize: 12, height: 1.45),
          ),
          SizedBox(height: 12),
          Text('Naye filter', style: TextStyle(fontWeight: FontWeight.w800)),
          SizedBox(height: 4),
          Text(
            '• Turnover (20 din ka ausat, ₹ crore) — jise bhar nahi sakte wo '
            'bahar. Default ₹10 cr.\n'
            '• Aaj expiry wale stock bahar (theta + pin risk).\n'
            '• “expiry ≤ 3 din” — default band, aap chala sakte hain.\n'
            '• Min score slider (0-12) — default 0, matlab koi rok nahi.',
            style: TextStyle(fontSize: 12, height: 1.45),
          ),
          SizedBox(height: 12),
          Text('Do score kyun', style: TextStyle(fontWeight: FontWeight.w800)),
          SizedBox(height: 4),
          Text(
            'Har row par naya score ke saath purana score bhi likha hai. Farq '
            'dekh kar aap khud faisla karein ki sudhaar aapke kaam ka hai ya '
            'nahi. AI Suggestion abhi bhi PURANE score ko gate banata hai — '
            'wo is page se nahi badalta.',
            style: TextStyle(fontSize: 12, height: 1.45),
          ),
          SizedBox(height: 12),
          Text('Score ka hisab (doosra tab)',
              style: TextStyle(fontWeight: FontWeight.w800)),
          SizedBox(height: 4),
          Text(
            'Purane candles par score nikal kar aage ke dinon ka natija naapa '
            'jata hai, chaar band me. Ye koi guarantee nahi hai — sirf ginti. '
            'Agar score kaam nahi karta to app wahi likhega.',
            style: TextStyle(fontSize: 12, height: 1.45),
          ),
        ],
      ),
    ),
  );
}

// ---------------------------------------------------------------------------
// Tab 3 — Analysis (IVP/IVR · DP · trend)
//
// Poori tarah offline: jo candles scanner pahle hi download kar chuka hai,
// unhi se sab kuch banta hai. Koi naya request nahi, koi premium chahiye hi
// nahi — isliye ye tab scan ke bina bhi chalta hai.
//
// Ek hi baar me teenon nikalte hain (ek loop), phir upar wale control badalne
// par sirf dikhav badalta hai (hisab yaad rakha jata hai, dobara nahi ghuma).
// ---------------------------------------------------------------------------

class _AdvAnalysisTab extends StatefulWidget {
  const _AdvAnalysisTab({required this.active});

  /// IndexedStack har tab bana to deta hai, par dikhata ek ko hai — isliye
  /// candles tabhi padhe jate hain jab ye tab sach me khula ho.
  final bool active;

  @override
  State<_AdvAnalysisTab> createState() => _AdvAnalysisTabState();
}

/// Hisab ka nateeza yaad rakhne ke liye — window badalne par dobara na ghume.
class _AnalysisMemo {
  _AnalysisMemo(this.bars, this.ivpWindow, this.dpDays, this.trendWindow,
      this.analysis);

  final Map<String, List<Candle>> bars;
  final IvpWindow ivpWindow;
  final int dpDays;
  final TrendWindow trendWindow;
  final StudyAdvAnalysis analysis;

  bool matches(Map<String, List<Candle>> bars, IvpWindow ivpWindow, int dpDays,
          TrendWindow trendWindow) =>
      identical(this.bars, bars) &&
      this.ivpWindow == ivpWindow &&
      this.dpDays == dpDays &&
      this.trendWindow == trendWindow;
}

class _AdvAnalysisTabState extends State<_AdvAnalysisTab> {
  var _asked = false;

  @override
  void didUpdateWidget(_AdvAnalysisTab oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.active) _ask();
  }

  void _ask() {
    if (_asked) return;
    _asked = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      context.read<StudyAdvProvider>().analyse();
    });
  }

  IvpWindow _ivpWindow = IvpWindow.year1;
  int _dpDays = 60;
  TrendWindow _trendWindow = TrendWindow.months3;

  var _showAllIvp = false;
  var _showAllTrend = false;
  var _showAllDp = false;

  _AnalysisMemo? _memo;

  /// Kabhi bhi chalao / scan ke baad — dono jagah se kaam karta hai.
  static const int _previewRows = 20;

  StudyAdvAnalysis? _analysisFor(StudyAdvProvider provider) {
    final bars = provider.bars;
    if (bars.isEmpty) return null;
    final memo = _memo;
    if (memo != null &&
        memo.matches(bars, _ivpWindow, _dpDays, _trendWindow)) {
      return memo.analysis;
    }
    final analysis = buildStudyAdvAnalysis(
      bars: bars,
      asOf: MarketCalendar.nowIst(),
      ivpWindow: _ivpWindow,
      dpDays: _dpDays,
      trendWindow: _trendWindow,
    );
    _memo = _AnalysisMemo(bars, _ivpWindow, _dpDays, _trendWindow, analysis);
    return analysis;
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<StudyAdvProvider>();
    final scheme = Theme.of(context).colorScheme;
    final analysis = _analysisFor(provider);

    if (provider.analysisLoading) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 12),
              Text('Phone me maujood candles padhe ja rahe hain…'),
            ],
          ),
        ),
      );
    }

    if (analysis == null) {
      return ListView(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 24),
        children: [
          _noteCard(
            context,
            title: 'Analysis — bina internet ke',
            body:
                'Ye teen cheezein sirf phone me pahle se maujood daily candles '
                'se banti hain: IVP/IVR (apne hi itihaas se percentile), DP '
                '(support / resistance) aur trend (SMA + EMA). Koi naya data '
                'mangaya nahi jata, isliye scan chala ho ya nahi — yahan sab '
                'milega.',
          ),
          const SizedBox(height: 10),
          // Sachchai khaali halat me bhi dikhe — sikhne ka mauka chhodna nahi.
          _noteCard(
            context,
            title: 'Thoda sach — padh lijiye',
            body: _ivpCaveat,
          ),
          const SizedBox(height: 10),
          if (provider.analysisError != null)
            _noteCard(
              context,
              title: 'Analysis nahi ban paya',
              body: provider.analysisError!,
              tone: scheme.error,
            )
          else
            _noteCard(
              context,
              title: 'Abhi kuch nahi mila',
              body:
                  'Phone me kisi bhi stock ke daily candles nahi mile. Ek baar '
                  '3M Study chalao (usme history download hoti hai) — uske baad '
                  'ye tab hamesha offline kaam karega.',
            ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: () => provider.analyse(force: true),
            icon: const Icon(Icons.auto_graph_rounded),
            label: const Text('Analysis chalao (offline)'),
          ),
        ],
      );
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 24),
      children: [
        _noteCard(context, title: 'Analysis', body: analysis.summary),
        const SizedBox(height: 12),

        // ---- 1. IVP / IVR ------------------------------------------------
        _sectionHeader(
          context,
          'IVP / IVR — apne hi itihaas se mukabla',
          'IVP: pichle dinon me se kitne % din aaj se kam hilte the. '
              'IVR: (aaj − kam) / (zyada − kam).',
        ),
        const SizedBox(height: 6),
        _noteCard(
          context,
          title: 'Thoda sach — padh lijiye',
          body: _ivpCaveat,
        ),
        const SizedBox(height: 8),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: SegmentedButton<IvpWindow>(
            showSelectedIcon: false,
            segments: const [
              ButtonSegment(value: IvpWindow.months6, label: Text('6 mahine')),
              ButtonSegment(value: IvpWindow.year1, label: Text('1 saal')),
              ButtonSegment(value: IvpWindow.years3, label: Text('3 saal')),
            ],
            selected: {_ivpWindow},
            onSelectionChanged: (value) =>
                setState(() => _ivpWindow = value.first),
          ),
        ),
        const SizedBox(height: 8),
        ..._ivpRows(context, analysis.ivpRows),

        const SizedBox(height: 18),

        // ---- 2. DP -------------------------------------------------------
        _sectionHeader(
          context,
          'DP — kahan se kharide, kahan beche',
          'Pichle dinon ke swing high/low jinke aas-paas bhav baar baar aaya. '
              'Ye koi guarantee nahi — sirf bheed wali jagah.',
        ),
        const SizedBox(height: 8),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: SegmentedButton<int>(
            showSelectedIcon: false,
            segments: const [
              ButtonSegment(value: 20, label: Text('20 din')),
              ButtonSegment(value: 40, label: Text('40 din')),
              ButtonSegment(value: 60, label: Text('60 din')),
              ButtonSegment(value: 120, label: Text('120 din')),
            ],
            selected: {_dpDays},
            onSelectionChanged: (value) => setState(() => _dpDays = value.first),
          ),
        ),
        const SizedBox(height: 8),
        ..._dpRows(context, analysis.dpRows),

        const SizedBox(height: 18),

        // ---- 3. Trend ----------------------------------------------------
        _sectionHeader(
          context,
          'Trend — upar, neeche ya seedha',
          'SMA aur EMA dono ek hi taraf ho to trend pakka; ulte ho to "seedha".',
        ),
        const SizedBox(height: 8),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: SegmentedButton<TrendWindow>(
            showSelectedIcon: false,
            segments: const [
              ButtonSegment(value: TrendWindow.month1, label: Text('1 mahina')),
              ButtonSegment(value: TrendWindow.months3, label: Text('3 mahine')),
              ButtonSegment(value: TrendWindow.months6, label: Text('6 mahine')),
              ButtonSegment(value: TrendWindow.year1, label: Text('1 saal')),
            ],
            selected: {_trendWindow},
            onSelectionChanged: (value) =>
                setState(() => _trendWindow = value.first),
          ),
        ),
        const SizedBox(height: 8),
        ..._trendRows(context, analysis.trendRows),
      ],
    );
  }

  List<Widget> _ivpRows(BuildContext context, List<IvpRow> rows) {
    if (rows.isEmpty) {
      return [const EmptyLine('Is window me koi stock ka data nahi mila.')];
    }
    final shown = _showAllIvp ? rows : rows.take(_previewRows).toList();
    return [
      for (final row in shown) IvpTile(row: row),
      if (rows.length > _previewRows)
        TextButton.icon(
          onPressed: () => setState(() => _showAllIvp = !_showAllIvp),
          icon: Icon(_showAllIvp
              ? Icons.expand_less_rounded
              : Icons.expand_more_rounded),
          label: Text(_showAllIvp
              ? 'kam dikhao'
              : 'aur ${rows.length - _previewRows} stock dikhao'),
        ),
    ];
  }

  List<Widget> _dpRows(BuildContext context, List<DpRow> rows) {
    if (rows.isEmpty) {
      return [const EmptyLine('Is window me koi level nahi mila.')];
    }
    final shown = _showAllDp ? rows : rows.take(_previewRows).toList();
    return [
      for (final row in shown) DpTile(row: row),
      if (rows.length > _previewRows)
        TextButton.icon(
          onPressed: () => setState(() => _showAllDp = !_showAllDp),
          icon: Icon(_showAllDp
              ? Icons.expand_less_rounded
              : Icons.expand_more_rounded),
          label: Text(_showAllDp
              ? 'kam dikhao'
              : 'aur ${rows.length - _previewRows} stock dikhao'),
        ),
    ];
  }

  List<Widget> _trendRows(BuildContext context, List<TrendRow> rows) {
    if (rows.isEmpty) {
      return [const EmptyLine('Is window me koi stock ka data nahi mila.')];
    }
    final shown = _showAllTrend ? rows : rows.take(_previewRows).toList();
    return [
      for (final row in shown) TrendTile(row: row),
      if (rows.length > _previewRows)
        TextButton.icon(
          onPressed: () => setState(() => _showAllTrend = !_showAllTrend),
          icon: Icon(_showAllTrend
              ? Icons.expand_less_rounded
              : Icons.expand_more_rounded),
          label: Text(_showAllTrend
              ? 'kam dikhao'
              : 'aur ${rows.length - _previewRows} stock dikhao'),
        ),
    ];
  }
}

class IvpTile extends StatelessWidget {
  const IvpTile({super.key, required this.row});

  final IvpRow row;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final color = row.ivp >= 60
        ? _loss(context)
        : (row.ivp <= 30 ? _gain(context) : scheme.onSurfaceVariant);

    return Card(
      margin: const EdgeInsets.only(bottom: 6),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 9, 12, 9),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    row.symbol,
                    style: const TextStyle(
                        fontSize: 13, fontWeight: FontWeight.w700),
                  ),
                ),
                Text(
                  'IVP ${row.ivp.toStringAsFixed(0)}',
                  style: TextStyle(
                      fontSize: 13, fontWeight: FontWeight.w800, color: color),
                ),
                const SizedBox(width: 8),
                Text(
                  'IVR ${row.ivr.toStringAsFixed(0)}',
                  style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant),
                ),
              ],
            ),
            const SizedBox(height: 5),
            ClipRRect(
              borderRadius: BorderRadius.circular(3),
              child: LinearProgressIndicator(
                value: row.ivp / 100,
                minHeight: 5,
                color: color,
                backgroundColor: scheme.surfaceContainerHighest,
              ),
            ),
            const SizedBox(height: 5),
            Text(
              '${row.verdict} · aaj ${row.current.toStringAsFixed(1)}% · '
              'ausat ${row.average.toStringAsFixed(1)}% '
              '(${row.min.toStringAsFixed(1)}–${row.max.toStringAsFixed(1)}) · '
              '${row.days} din',
              style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
            ),
          ],
        ),
      ),
    );
  }
}

class DpTile extends StatelessWidget {
  const DpTile({super.key, required this.row});

  final DpRow row;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      margin: const EdgeInsets.only(bottom: 6),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 9, 12, 9),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    row.symbol,
                    style: const TextStyle(
                        fontSize: 13, fontWeight: FontWeight.w700),
                  ),
                ),
                Text(
                  '₹${row.cmp.toStringAsFixed(2)}',
                  style: const TextStyle(
                      fontSize: 13, fontWeight: FontWeight.w800),
                ),
              ],
            ),
            const SizedBox(height: 4),
            DpLine(
              label: 'upar',
              level: row.nearestUp,
              color: _loss(context),
              fallback: scheme.onSurfaceVariant,
            ),
            const SizedBox(height: 2),
            DpLine(
              label: 'neeche',
              level: row.nearestDown,
              color: _gain(context),
              fallback: scheme.onSurfaceVariant,
            ),
          ],
        ),
      ),
    );
  }
}

class DpLine extends StatelessWidget {
  const DpLine({
    super.key,
    required this.label,
    required this.level,
    required this.color,
    required this.fallback,
  });

  final String label;
  final DpLevel? level;
  final Color color;
  final Color fallback;

  @override
  Widget build(BuildContext context) {
    if (level == null) {
      return Text(
        '  $label: koi level nahi mila',
        style: TextStyle(fontSize: 11.5, color: fallback),
      );
    }
    return Text(
      '  $label: ₹${level!.price.toStringAsFixed(2)} '
      '(${level!.distancePct >= 0 ? '+' : '−'}'
      '${level!.distancePct.abs().toStringAsFixed(1)}%, '
      '${level!.touches} baar chhua)',
      style: TextStyle(fontSize: 11.5, color: color),
    );
  }
}

class TrendTile extends StatelessWidget {
  const TrendTile({super.key, required this.row});

  final TrendRow row;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final Color color;
    if (!row.sufficient) {
      color = scheme.onSurfaceVariant;
    } else if (row.direction == TrendDirection.up) {
      color = _gain(context);
    } else if (row.direction == TrendDirection.down) {
      color = _loss(context);
    } else {
      color = scheme.onSurfaceVariant;
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 6),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 9, 12, 9),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    row.symbol,
                    style: const TextStyle(
                        fontSize: 13, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    row.sufficient
                        ? '₹${row.cmp.toStringAsFixed(2)} · MA '
                            '₹${row.sma.toStringAsFixed(2)} '
                            '(${row.distanceFromMaPct >= 0 ? '+' : '−'}'
                            '${row.distanceFromMaPct.abs().toStringAsFixed(1)}%)'
                        : '₹${row.cmp.toStringAsFixed(2)} · '
                            'sirf ${row.days} din ka data',
                    style:
                        TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
                  ),
                ],
              ),
            ),
            Text(
              row.verdict,
              style: TextStyle(
                  fontSize: 12, fontWeight: FontWeight.w700, color: color),
            ),
          ],
        ),
      ),
    );
  }
}

class EmptyLine extends StatelessWidget {
  const EmptyLine(this.text, {super.key});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 12,
          color: Theme.of(context).colorScheme.onSurfaceVariant,
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Tab 4 — "Mera hisaab": kaunsa setup fayda deta hai
// ---------------------------------------------------------------------------

class _AdvMyTradesTab extends StatefulWidget {
  const _AdvMyTradesTab({required this.active});

  /// IndexedStack har tab ko bana to deta hai, par dikhata ek ko hai — isliye
  /// trade book tabhi padha jata hai jab ye tab sach me khula ho.
  final bool active;

  @override
  State<_AdvMyTradesTab> createState() => _AdvMyTradesTabState();
}

class _AdvMyTradesTabState extends State<_AdvMyTradesTab> {
  var _asked = false;

  @override
  void didUpdateWidget(_AdvMyTradesTab oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.active) _ask();
  }

  void _ask() {
    if (_asked) return;
    _asked = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      context.read<StudyAdvProvider>().loadMyTrades();
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<StudyAdvProvider>();
    final scheme = Theme.of(context).colorScheme;
    final report = provider.myTrades;

    if (provider.myTradesLoading && report == null) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 12),
              Text('Trade book padha ja raha hai…'),
            ],
          ),
        ),
      );
    }

    if (provider.myTradesError != null) {
      return ListView(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 24),
        children: [
          _noteCard(context,
              title: 'Mera hisaab — abhi nahi',
              body: provider.myTradesError!,
              tone: scheme.error),
        ],
      );
    }

    if (report == null || report.isEmpty) {
      return ListView(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 24),
        children: [
          _noteCard(
            context,
            title: 'Mera hisaab',
            body:
                'Yahan aapke apne band hue paper trades ka hisaab aata hai — '
                'kaunsa score, kaunsa trend aur kaunsi IV haalat me aapka '
                'paisa bana ya gira. Abhi tak koi trade band nahi hua, isliye '
                'yahan kuch nahi hai. Paper Trading me kuch lijiye, phir yahan '
                'aapka apna aaina dekhiye.',
          ),
        ],
      );
    }

    return MyTradesReportView(
      report: report,
      onRefresh: () => provider.loadMyTrades(),
    );
  }
}

/// "Mera hisaab" ka poora khaka — public isliye ki ise bina DB ke, seedhe
/// banaye gaye report ke saath test kiya ja sake.
class MyTradesReportView extends StatelessWidget {
  const MyTradesReportView({super.key, required this.report, this.onRefresh});

  final MyTradesReport report;
  final VoidCallback? onRefresh;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 24),
      children: [
        _noteCard(context, title: 'Mera hisaab', body: report.note),
        const SizedBox(height: 10),
        if (onRefresh != null)
          Align(
            alignment: AlignmentDirectional.centerStart,
            child: TextButton.icon(
              onPressed: onRefresh,
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('Phir se dekho'),
            ),
          ),

        _bucketSection(context, 'Score ke hisaab se', report.byScore),
        const SizedBox(height: 14),
        _bucketSection(context, 'Trend ke hisaab se', report.byTrend),
        const SizedBox(height: 14),
        _bucketSection(context, 'IV ke hisaab se', report.byIvRank),
        const SizedBox(height: 14),

        _noteCard(
          context,
          title: 'Ye kya hai (aur kya nahi)',
          body:
              'Har band hue trade ko us study se joda gaya hai jo us stock ka '
              'sabse kareeb thi. Ye batata hai ki AAPNE kya kiya — ki aage '
              'kya karna chahiye, nahi. 10 se kam trade wale bucket par likha '
              'hai "kuch pakka nahi", kyunki 3 trade ka 66% win rate koi '
              'pattern nahi hota.',
        ),
      ],
    );
  }

  Widget _bucketSection(
      BuildContext context, String title, List<SetupBucket> buckets) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionHeader(context, title, ''),
        const SizedBox(height: 6),
        for (final bucket in buckets) BucketTile(bucket: bucket),
      ],
    );
  }
}

class BucketTile extends StatelessWidget {
  const BucketTile({super.key, required this.bucket});

  final SetupBucket bucket;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final gain = _gain(context);
    final loss = _loss(context);
    final color = bucket.isEmpty
        ? scheme.onSurfaceVariant
        : (bucket.netPnl >= 0 ? gain : loss);

    return Card(
      margin: const EdgeInsets.only(bottom: 6),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 9, 12, 9),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    bucket.label,
                    style: const TextStyle(
                        fontSize: 13, fontWeight: FontWeight.w700),
                  ),
                ),
                Text(
                  bucket.isEmpty
                      ? '—'
                      : '${bucket.netPnl >= 0 ? '+' : '−'}'
                          '₹${bucket.netPnl.abs().toStringAsFixed(0)}',
                  style: TextStyle(
                      fontSize: 13, fontWeight: FontWeight.w800, color: color),
                ),
              ],
            ),
            const SizedBox(height: 3),
            Text(
              bucket.note,
              style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant),
            ),
            if (!bucket.isEmpty && bucket.worst < 0) ...[
              const SizedBox(height: 2),
              Text(
                'sabse bada nuksaan ${bucket.worstText}',
                style: TextStyle(fontSize: 11, color: loss),
              ),
            ],
            if (!bucket.isEmpty && !bucket.sufficient) ...[
              const SizedBox(height: 3),
              Text(
                '⚠ ${SetupBucket.minTrades} se kam trade — is par bharosa mat kijiye',
                style: TextStyle(fontSize: 11, color: scheme.error),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

/// IVP/IVR ka sach — do jagah padha jata hai, isliye ek hi jagah likha hai.
const String _ivpCaveat =
    'Asli IVP/IVR ke liye IV ka ITIHAAS chahiye, aur broker sirf "abhi" ki IV '
    'deta hai. Isliye yahan asli hilchal (realised volatility) ka percentile '
    'hai — matlab wahi ("premium mehnga hai ya sasta"), bas IV ki jagah sachi '
    'chal se. Jhootha IVP dikhane se behtar hai sachchi baat batana.';

/// Ek card jisme sirf likha hua samjhav — har naye tab ka pehla hissa.
Widget _noteCard(
  BuildContext context, {
  required String title,
  required String body,
  Color? tone,
}) {
  final scheme = Theme.of(context).colorScheme;
  return Card(
    child: Padding(
      padding: const EdgeInsets.all(13),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 12.5,
              fontWeight: FontWeight.w800,
              color: tone,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            body,
            style: TextStyle(
              fontSize: 11.5,
              height: 1.4,
              color: tone ?? scheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    ),
  );
}

Widget _sectionHeader(BuildContext context, String title, String subtitle) {
  final scheme = Theme.of(context).colorScheme;
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        title,
        style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w800),
      ),
      if (subtitle.isNotEmpty) ...[
        const SizedBox(height: 3),
        Text(
          subtitle,
          style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
        ),
      ],
    ],
  );
}

// ---------------------------------------------------------------------------
// Shared cards for the Analysis / Mera hisaab tabs
// ---------------------------------------------------------------------------

String _signed(double value) =>
    '${value >= 0 ? '+' : '−'}${value.abs().toStringAsFixed(1)}';

String _money(double value) => value == value.roundToDouble()
    ? value.toStringAsFixed(0)
    : value.toStringAsFixed(2);

Color _gain(BuildContext context) {
  final scheme = Theme.of(context).colorScheme;
  return scheme.brightness == Brightness.dark
      ? const Color(0xFF7BD88F)
      : const Color(0xFF0B7A3B);
}

Color _loss(BuildContext context) {
  final scheme = Theme.of(context).colorScheme;
  return scheme.brightness == Brightness.dark
      ? const Color(0xFFFF8A80)
      : const Color(0xFFB3261E);
}
