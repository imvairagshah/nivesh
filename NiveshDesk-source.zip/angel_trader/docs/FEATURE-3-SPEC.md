# Feature 3 spec — Paper trading (simulated) + **trade groups**

Status: **spec locked, schema + DAO already implemented** (see
`lib/data/local/dao/trade_group_dao.dart`, `test/data/trade_group_dao_test.dart`).
UI lands in Phase 3.

---

## 1. Original requirements (from the product brief)

| # | Requirement |
|---|---|
| 3.1 | Virtual capital, configurable starting amount (default ₹1,00,000) |
| 3.2 | Buy / Sell equity — quantity, MARKET or LIMIT price |
| 3.3 | Stop loss per position (SL price or SL %) |
| 3.4 | Live monitoring of open positions via the SmartAPI WebSocket feed; auto-exit at SL |
| 3.5 | Holdings view: avg buy price, qty, invested value, current value, live unrealised P&L |
| 3.6 | Trade book: entry/exit price, qty, realised P&L per trade |
| 3.7 | Monthly P&L report: month-wise realised P&L, trade count, win rate, biggest win/loss — bar chart |
| 3.8 | Live dashboard: portfolio value, overall realised P&L, open unrealised P&L |
| 3.9 | Everything persisted in local SQLite |
| 3.10 | **No real orders, ever** — pure simulation |

## 2. NEW requirement — trade groups (strategy / basket tags)

> "Jab bhi main paper trading me trade lu, usme ek group selection option ho —
> group pehle se add karke rakh saku, taaki ek hi group ka naam baar-baar use
> karna na pade. Aur P&L me group-wise P&L bhi dikhna chahiye."

### 2.1 Behaviour

* **G1 — Group picker on every paper trade.** The Buy/Sell sheet has a *Group*
  field (chips). Unselected = **Ungrouped** (allowed; no group is mandatory).
* **G2 — Pre-created, reusable groups.** Groups are created once and reused:
  * *Settings → Paper trading → Groups*: add / rename / recolour / archive / delete.
  * Inline **"+ New group"** right inside the trade sheet (creates and selects it).
  * Suggestions are ordered **by usage** (`TradeGroupDao.byUsage()`) so the
    frequently used baskets are always at the top of the picker.
* **G3 — Group travels with the position.** The entry trade's group is copied to
  the position; the exit trade inherits it. The group is visible on Holdings and
  in the Trade Book, and can be changed later (a group edit does not touch prices).
* **G4 — Group-wise P&L.** Reports gets a **"By group"** view (alongside Overall
  and Monthly):
  * realised P&L per group, trade count, win rate, average win/loss, profit factor,
    biggest win/loss;
  * **month-wise grouped bar chart** — one bar series per group, coloured from the
    group palette (`GroupMonthPnl`);
  * open exposure per group (invested value + position count), with live
    unrealised P&L once the WebSocket feed is connected;
  * the implicit **Ungrouped** bucket is reportable and can be filtered out.
* **G5 — Group filters.** Holdings, Trade Book, dashboard and Reports all accept a
  group filter, including "Ungrouped" and "All groups".
* **G6 — Deleting a group never destroys history.** The confirmation dialog says
  how many trades/positions are affected and lets the user pick a destination
  group or Ungrouped (`TradeGroupDao.delete(id, reassignTo:)`).
* **G7 — Archiving.** An archived group disappears from the picker but its P&L
  stays in the reports.

### 2.2 Data model (implemented — schema v2)

```sql
CREATE TABLE trade_groups (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT    NOT NULL,               -- unique, case-insensitive
  color_index INTEGER NOT NULL DEFAULT 0,     -- palette 0…7
  notes       TEXT    NOT NULL DEFAULT '',
  archived    INTEGER NOT NULL DEFAULT 0,
  created_at  INTEGER NOT NULL DEFAULT 0
);
CREATE UNIQUE INDEX idx_trade_groups_name ON trade_groups(name COLLATE NOCASE);

-- both already carry this column, added by migration v2:
trades.group_id     INTEGER   -- trade tag (NULL = Ungrouped)
positions.group_id  INTEGER   -- copied from the entry trade
```

* **Ungrouped is not a row.** `group_id = NULL` *is* Ungrouped — that is why the
  model reserves the name and why deleting a group can always fall back to it.
* Month buckets are computed in Dart against **IST** (`MarketCalendar.istFromUtc`),
  not with SQL `strftime`, so a trade at 02:00 IST on 1 Oct is reported in October.

### 2.3 API surface already available

```dart
final groups = TradeGroupDao(db);

await groups.createNamed('Momentum');            // G2 (inline "+ New group")
await groups.byUsage();                          // G2 picker order
await groups.update(group.copyWith(name: '…'));  // rename / recolour
await groups.archive(id);                        // G7
await groups.usageCount(id);                     // G6 dialog numbers
await groups.delete(id, reassignTo: otherId);    // G6

await groups.realizedByGroup(from: …, to: …);    // G4 table
await groups.monthlyByGroup();                   // G4 grouped bar chart
await groups.openExposureByGroup();              // G4 open baskets
```

`GroupPnlSummary` carries realised P&L, closed trades, wins/losses, win rate,
gross profit/loss, average win/loss, profit factor, best/worst trade and open
exposure — everything the group table and the chart need.

## 3. Remaining build work (Phase 3)

1. `PaperTradingService` — virtual capital, order simulation (MARKET fills at LTP,
   LIMIT fills when LTP crosses), charges (brokerage/STT/exchange/GST/stamp),
   position book-keeping, `realized_pnl` on closing legs, SL/Target watchers.
2. `LiveFeedService` — SmartAPI WebSocket 2.0 (`wss://smartapisocket.angelone.in/smart-stream`),
   binary little-endian packet decoding (mode 1 LTP), token → symbol routing,
   auto-reconnect, subscription diffing.
3. UI:
   * Paper Trading tab: dashboard tiles (portfolio value, realised, unrealised),
     Holdings list (with group chips + group filter), Trade Book (group column),
     order sheet (group picker + "+ New group", SL, MARKET/LIMIT).
   * Reports tab: Overall / Monthly / **By group** segmented control, `fl_chart`
     bars (stacked or grouped, coloured by group palette), CSV export.
   * Settings → Paper trading: starting capital, **Groups** manager.
4. Tests: order maths, SL trigger, charges, group inheritance on entry/exit,
   group-wise report totals vs. the raw trade book.

## 4. Decisions still open — see the questions asked alongside this file

1. Group on **both** legs (entry + exit) or entry only?
2. Group-wise P&L: realised + unrealised, or realised only?
3. Delete behaviour: reassign, block, or delete trades too?
4. Flat groups or nested (parent → sub-group)?
