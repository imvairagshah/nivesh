# NiveshDesk — setup guide (from zero to a running app)

This walks through everything a new user has to do: get Angel One SmartAPI
credentials, enable TOTP, build the app, and keep the data fresh afterwards.

Total time: ~20 minutes (most of it waiting for `flutter pub get` and the first
build).

---

## 1. Prerequisites

| Tool | Version | Check |
|---|---|---|
| Flutter SDK | 3.35 or newer (Dart 3.5+) | `flutter --version` |
| Android Studio + SDK, or Xcode | Android SDK 23+ / iOS 13+ | `flutter doctor` |
| Python 3 (optional) | only to regenerate the launcher icon | `python3 --version` |
| Angel One trading account | demat/trading account in your name | — |

```bash
flutter doctor          # resolve anything marked ✗ before continuing
```

---

## 2. Get your SmartAPI credentials

1. **Sign in to the SmartAPI portal** — <https://smartapi.angelbroking.com> —
   with the same credentials you use for Angel One (the portal uses your Angel
   One client code).

2. **Create an app**: *My Apps → Create App*.
   * **App name**: anything, e.g. `NiveshDesk local`
   * **Redirect URL**: any valid URL, e.g. `https://localhost` — this app never
     uses the OAuth redirect, it only needs the key.
   * Save. The portal now shows an **API key** (a short string like `AbCdEfGh`).
     This is the `X-PrivateKey` header on every request.

   > Treat it like a password. The app stores it in the device keystore, so you
   > never have to put it in source control.

3. **Enable TOTP** (mandatory — password-only login is not accepted):
   * In the SmartAPI portal: *My Profile → TOTP → Enable*, or in the Angel One
     mobile app: *Profile → Security → TOTP → Enable via API*.
   * You are shown a **QR code and a base32 secret** (letters and digits 2–7,
     e.g. `JBSWY3DPEHPK3PXP`).
   * **Copy the secret.** That is what this app needs — it generates the rotating
     6-digit code itself, so you do not need an authenticator app on the same
     phone.

4. **Have your client code and MPIN ready**:
   * *Client code*: e.g. `A123456` (shown top-right of the Angel One app).
   * *Password*: your login password, or the 4-digit MPIN you use in the app.

---

## 3. Build and run

```bash
git clone <your fork>            # or unzip the project
cd angel_trader

flutter pub get

# Launcher icons (the PNGs are committed, so this is optional)
python3 tool/generate_icon.py
dart run flutter_launcher_icons

# Run on a connected device / emulator
flutter run                                   # debug

# Android release APK — one file, 64-bit phones (2017 onwards), ~20 MB
flutter build apk --release --target-platform android-arm64
#  → build/app/outputs/flutter-apk/app-release.apk

# iOS (needs a signing team)
flutter build ipa --release
```

A prebuilt APK ships alongside this project as `NiveshDesk-1.5.31.apk` (including
the standalone Magic Formula screener and the F&O module's 3-Month Study and
stock-expiry selector) — install it with `adb install -r NiveshDesk-1.5.31.apk`,
or copy the file to the phone and tap it. One file only: it targets 64-bit
(`arm64-v8a`) devices, i.e. every phone from ~2017 onwards. It is
signed with the Android **debug** key: fine for sideloading, not for Google Play
(see [Release signing](#release-signing)).

### Android specifics

* `minSdk` must be **23+** (keystore-backed secure storage).
* To let the **Chart** button open a browser on Android 11+, add to
  `android/app/src/main/AndroidManifest.xml`, inside `<manifest>`:

  ```xml
  <queries>
    <intent>
      <action android:name="android.intent.action.VIEW" />
      <data android:scheme="https" />
    </intent>
  </queries>
  ```

* The app needs `INTERNET` permission — already declared in
  `android/app/src/main/AndroidManifest.xml` together with
  `ACCESS_NETWORK_STATE`.
* `android/gradle.properties` ships two settings that matter:
  * `org.gradle.jvmargs=-Xmx1100m` keeps Gradle inside ~1.5 GB of RAM so the
    build works on a small machine — raise it to `-Xmx4G` on a normal laptop.
  * `android.builtInKotlin=true` lets AGP 9 compile plugin Kotlin itself. If you
    flip it to `false`, `package_info_plus` / `android_file_picker` apply the
    Kotlin Gradle Plugin dynamically and their sources silently compile to
    nothing, ending in `error: cannot find symbol … PackageInfoPlugin`.
* Toolchain the shipped APK was built with: Flutter 3.47.6 (Dart 3.13.5),
  JDK 17, Android platform 36, build-tools 36.0.0.

### The F&O module (3-Month Study)

Nothing extra to configure to *use* it: the study reads Angel One's own scrip
master (no third-party site) and the local option book that the master refresh
fills in.

* **First run after updating:** just press Scan. The study checks how many of
  the 213 F&O names the local scrip master can resolve and how many option
  contracts the book holds; if either looks thin it downloads the daily master
  from Angel One first (progress shown under the scan bar, ~10 s) and then scans
  everything. You can also force it any time with **Master update karo** in the
  status banner. If the master download fails (offline), the study still runs on
  whatever resolved — degraded, and it says so.
* **Universe:** the study scans the **entire F&O list — all 213 names** — every
  time. There is no "stocks per scan" setting on purpose. Budget for one run:
  ~213 daily-candle downloads on the first scan (throttled to Angel's
  3 requests/second ≈ 75 s), ~5 batched quote calls (one per 50 ATM legs) and one
  option-greek call per stock (≈ 75 s). Warm scans skip the candles entirely, so
  a re-scan is mostly the greeks. Well inside SmartAPI's 3 req/s and 5000
  req/hour limits.
* **Telegram export (optional):** create a bot with [@BotFather](https://t.me/BotFather),
  paste the token and your chat id into the same Settings card. The study's
  export menu then uploads the 3-sheet XLSX as a **document** to that chat.
  Without credentials the menu item explains what is missing instead of failing
  silently.
* **API budget:** one full study ≈ 213 candle downloads (first time only),
  ~5 batched quote calls and ~213 greek calls — every request paced at 350 ms,
  and a failed quote is never retried in a loop.

---

## Release signing

The template signs release builds with `signingConfigs.getByName("debug")`, so
everything you build installs over the shipped APK but Google Play rejects it.
For a Play upload create your own key and wire it up:

```bash
keytool -genkey -v -keystore ~/angel-trader.jks -keyalg RSA -keysize 2048 \
        -validity 10000 -alias angeltrader
```

`android/key.properties` (not committed):

```properties
storeFile=/absolute/path/to/angel-trader.jks
storePassword=…
keyAlias=angeltrader
keyPassword=…
```

…then in `android/app/build.gradle.kts`:

```kotlin
val keystoreProperties = java.util.Properties().apply {
    val f = rootProject.file("key.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

android {
    signingConfigs {
        create("release") {
            storeFile = file(keystoreProperties.getProperty("storeFile"))
            storePassword = keystoreProperties.getProperty("storePassword")
            keyAlias = keystoreProperties.getProperty("keyAlias")
            keyPassword = keystoreProperties.getProperty("keyPassword")
        }
    }
    buildTypes {
        release { signingConfig = signingConfigs.getByName("release") }
    }
}
```


### iOS specifics

```bash
cd ios && pod install && cd ..
```

No extra entitlements are required — the app only makes outbound HTTPS calls and
opens `https://in.tradingview.com` links.

---

## 4. First run

1. **Login screen** — enter API key, client code, password/MPIN and the base32
   TOTP secret. A live TOTP preview with a countdown confirms the secret is
   valid before you submit. (If your phone clock drifts, switch to *6-digit* mode
   and type the code from your authenticator.)
2. On success the app stores the credentials in the keystore and shows the
   **IPO Screener** tab. It immediately:
   * seeds the local IPO database from the bundled master — **every mainboard
     IPO listed since 1 Jan 2015** (559 rows, 558 of them with their listing-day high/low built in). On a fresh install the whole file
     is loaded; after an app update the new rows are *merged in* without touching
     rows you added or edited,
   * resolves each IPO symbol to an Angel One instrument token,
   * paints the last cached result (none on the very first run),
   * fetches live LTPs in batches of 50,
   * and, in the background, starts downloading the full ~50 MB instrument
     master so every SEBI-listed symbol resolves (watch progress in
     *Settings → Instrument master*).
3. Every row already carries its listing-day high/low (pre-filled from NSE's
   bhavcopy when the master was built), so there is nothing to wait for. The
   handful of rows a bhavcopy could not answer (BSE-first listings) fill
   themselves in from the broker's daily candle, in small background batches
   (~25 per launch, throttled, cached in SQLite forever) — the scan bar shows
   *Listing levels 302/559 ready…* while that runs. A row whose symbol no longer
   exists (delisted / renamed) is marked instead of being retried forever.
4. New listings keep arriving on their own. At launch the app compares the
   broker's daily scrip master with its last snapshot: a symbol whose price
   history *starts now* is a new listing, and one candle call gives its listing
   date plus high/low. NSE's official equity master (`EQUITY_L.csv`, no login
   needed) is the date cross-check for anything the broker snapshot has not
   picked up yet. Discovered rows are written straight into the database and
   listed once in a banner — a rename or a demerger can look like a new listing,
   so deleting a wrong row is one tap on the database screen.
   Tap the ⟳ icon next to **Scan now** to check on demand.
   The same pass keeps **identity** honest: every row stores its ISIN, so if the
   exchange renames a company (and therefore its ticker) the row is corrected from
   the ISIN automatically — the listing date, levels and your notes stay put. The
   screener banner names any repair it made.

### RSI Scanner tab

1. Open the **RSI** tab (5th icon). If it never scanned before, the table is empty
   and one line tells you so.
2. Tap the **universe chip** → pick **F&O stocks** (213 names, ~80 s for a first
   fresh scan, seconds afterwards) or **All NSE equities** (hundreds of requests —
   the app asks before starting).
3. Tap **Scan now**. The bar shows `N/213 · RELIANCE`, the running hit counts and an
   ETA; **Cancel** stops after the current instrument and keeps what it fetched.
4. Read the two tables with the segmented control: **RSI > 67** (overbought) and
   **RSI < 33** (oversold). Columns are **stock (ticker + company name)**, **price**
   (last daily close and day change) and **RSI** (today's value, yesterday's beside
   it). A **NAYA** badge means the row crossed its level on the newest bar.
5. Tap the **settings chip** to change the period or the levels (default 14 · 67 ·
   33). The cached table is re-labelled instantly — no second scan.
6. `N instruments skip hue` opens the list of symbols that could not be scanned,
   each with its reason (too little history, no candles, broker error). Nothing is
   ever dropped silently.

*Where the numbers come from:* daily candles from Angel One (one `getCandleData`
request per instrument, 3/s, cached in SQLite) → Wilder's RSI. Prices in the table
are the closing prices those candles carry — the same bars the RSI was computed
from, not a live LTP.
5. Pull down to refresh prices. Cards appear only for IPOs within ±3 % of their
   listing-day high or low.

### Not ready to log in?

Tap **“Browse cached data without logging in”** on the login screen. You get the
full UI, the seeded database and any cached prices — just no live quotes.

---

## 5. Golden Cross / Death Cross tab

1. Open the **Golden Cross** tab. The first time it loads, it resolves the instrument
   list from the data already on the phone (no network) and shows *"No scan yet"*.
2. Press **Run scan**. The default universe is **Nifty 50** — roughly 20 seconds on
   a fresh session, a couple of seconds afterwards. A progress bar shows the symbol
   being processed, the hit count and an ETA; **Stop** ends the scan early and keeps
   everything already found.
3. The header gives you the controls:
   * **date chip** — screen an earlier session (walk back over weekends/holidays for you)
   * **universe chip** — Nifty 50 · IPO database · all NSE · NSE+BSE (with sizes before you start)
   * **window chip** — on the day · last 5 / 10 / 20 sessions
   * **Death cross** — adds 50-crossing-*below*-200 signals to the list
   * **Golden / Death / This session** tiles — tap to filter; the search icon filters by symbol or company
4. Each card's **Chart** button opens the TradingView chart for that symbol.

### Where the candles come from (and why the second scan is instant)

The first scan of a trading session downloads ~400 calendar days of daily candles per
instrument from `getCandleData` (Angel One allows 3 requests/second, so the scan runs
one symbol at a time) and stores them in SQLite. Later scans of the **same session**
read from that cache — no API calls at all. Results are cached per session too, so the
tab opens instantly and offline.

`Settings → Clear cached scan` empties the result list but keeps the candles;
`Clear candle cache` (Settings → Data) removes those as well.

### The 6 PM daily scan

The app has no server, so the "daily job" runs **in the app**: the first time you open
the Golden Cross tab after **18:00 IST on a trading day**, it scans that session
automatically (once per app launch, only while logged in). If you never open the app
that evening, nothing is lost — the next open scans the same session on demand.

To get told without opening the app, put a webhook URL in
**Settings → Golden Cross → Notify webhook** (ntfy, a Telegram bot, or your own
endpoint). It receives a JSON `POST` — title, counts and the top signals with
TradingView links — but only when the scan actually finds something. Leave it empty
to disable. Nothing is sent anywhere else, ever.

---

## 6. Keeping the data fresh

| Data | Refresh path | Cadence |
|---|---|---|
| Instrument master (symbol ➜ token) | *Settings → Download latest* (automatic on first login) | daily — Angel republishes it each morning |
| IPO rows | *IPO Screener → storage icon → Import CSV* | whenever you add IPOs |
| Listing-day high/low accuracy | Re-import a corrected CSV (see below) | once, or when you spot a bad row |
| Prices | Pull-to-refresh, or the auto-refresh timer while the market is open | user-defined (default 60 s) |

### Where to get correct listing-day high/low values

The bundled CSV's listing dates and tickers are real, but its listing-day
**high/low** numbers are compiled from public reports; rows that could not be
confirmed say so in the Notes column. To make a row authoritative, copy the two
numbers from either:

* **Exchange data** — NSE *Historical data* / bhavcopy for the listing date, or
  the BSE *Historical data* page for that date.
* **IPO aggregators** — Chittorgarh / Moneycontrol IPO pages carry a *“Listing Day
  Trading Information”* table with Open / High / Low / Last trade. That High and
  Low are exactly the two numbers this screener needs.

Then edit that single row in the app (**IPO database → tap the row**) or fix your
CSV and re-import it.

### CSV format

```csv
Symbol,Company Name,Exchange,Listing Date,Listing High,Listing Low,Sector,Notes
TATATECH,Tata Technologies Ltd,NSE,30-Nov-2023,1400.00,1200.00,Engineering,Day range confirmed
```

* `Symbol` must be the **current** NSE/BSE ticker, without `-EQ` and without an
  exchange prefix (`ETERNAL`, not `ZOMATO`; `AWL`, not `ADANIWILMAR` — both were
  renamed, and the screener needs the ticker that trades today).
* `Exchange` is `NSE` or `BSE`.
* `Listing Date` accepts `dd-MMM-yyyy`, `yyyy-MM-dd` or `dd/MM/yyyy`.
* Extra columns are ignored; missing optional ones are fine.
* Import is **idempotent** on `(symbol, exchange)` — re-importing updates rows
  instead of duplicating them.

---

## 7. Daily usage tips

* Prices only refresh while the market is open (09:15–15:30 IST) and you are
  signed in; the app skips polling on weekends and exchange holidays.
* Your session expires daily around 05:00 IST. Settings shows the remaining
  token lifetime and has a **Re-login with saved details** flow that regenerates
  the TOTP for you.
* Tap a card for the full numbers (exact % from both listing levels, instrument
  token, price timestamp, notes).
* **Chart** opens TradingView for `NSE:SYMBOL` / `BSE:SYMBOL` in your browser or
  the TradingView app.
* Everything works offline from cache; cached values are always labelled.

---

## 8. Troubleshooting

| Problem | Fix |
|---|---|
| `Invalid API key / client code (AB1004)` | Re-copy the API key from *My Apps*; the client code is not your email. |
| `Invalid TOTP (AB1050/1051)` | Sync the phone clock (Settings → Date & Time → automatic), or use 6-digit mode. |
| `Access denied because of exceeding access rate` | SmartAPI throttle. The app retries with backoff; if it persists, wait a minute, or raise the auto-refresh interval in Settings. |
| Most rows “not screened” with *token not found* | Download the full instrument master (Settings, or the footer sheet button) — the bundled starter map only covers the seeded IPOs. |
| No prices at all, banner says *cached* | Not logged in, or the market is closed (weekend/holiday). Check the session card in Settings. |
| Chart button does nothing | Add the Android `<queries>` block (above), or install a browser. |
| Build fails with `CardTheme`/`AppBarTheme` type errors | Your Flutter is older than 3.35 — see the note at the top of `lib/core/theme/app_theme.dart`. |
| Tests fail with `sqlite3 library not found` | Run `flutter test` (which brings the FFI binding) or install `libsqlite3` on the desktop machine. |

---

---

## 9. Paper trading & Reports tab

Everything in this tab is simulated. Orders are matched inside the app and stored
in SQLite; **nothing is sent to Angel One** (only read-only endpoints — login,
profile, quote, candles, WebSocket — are ever called).

### Your first paper trade

1. **Paper Trade** tab → the floating **Trade** button.
2. Type at least two characters of a symbol or company (**SBIN**, *Tata Motors*)
   and pick the row. The app asks SmartAPI for a **single REST quote** so a MARKET
   order can be priced immediately; if the live feed is already streaming that
   symbol, the price is instantly there.
3. Choose **BUY/SELL**, quantity (or **MAX**, which leaves room for charges),
   **Market** or **Limit** (±% chips help you place a limit away from the LTP).
4. Optionally switch on **Stop loss** — as a percentage of the entry or an exact
   price — and a **Target**. The preview shows the itemised charges, the cash
   needed, break-even exit, and the risk : reward ratio.
5. Optionally tap a **group chip** (or **+ New group**) to tag the trade.
6. **Place paper BUY.** Market orders fill immediately; a limit order rests in
   **Orders** until the market reaches it (you may also **Fill now** or **Cancel**).

### Looking after an open position (Holdings tab)

* The card shows quantity × average, invested, LTP (a green dot means it came off
  the WebSocket), unrealised P&L, and a bar marking where the price sits between
  the stop and the target.
* **⋮ menu** — exit at market, sell part of it (25/50/75 % chips), set/change the
  stop loss (₹ or %), set a target, change the group, or open the TradingView chart.
* A breached stop is squared off automatically on the incoming tick; the trade
  book records it as `Auto-exit: stop loss`. Targets are booked automatically only
  when you enable it in *Settings → Paper trading → Auto-exit on target*.

### Reports tab

* **Overall** — realised P&L, win rate, expectancy, profit factor, biggest
  win/loss, best month, and the 12-month realised P&L bar chart (tap a bar to see
  that month's wins/losses).
* **Monthly** — the same months as a table, including months with no trades.
* **By group** — month × group bars in the group colours, plus each basket's
  realised P&L, win rate and the **live unrealised P&L** of its open positions.
* **Export** copies the filtered trade book (12 columns) to the clipboard.

The group filter at the top is shared with the Paper Trading tab, so
"how is Momentum doing this quarter?" is two taps.

### Settings → Paper trading

| Control | What it does |
|---|---|
| Virtual capital (₹1L / ₹5L / ₹10L presets) | re-bases sizing and the portfolio-value tile |
| Charge mode: delivery / intraday | which brokerage, STT and stamp-duty rules each leg uses |
| Include DP charges | ₹13.50 + GST depository fee on delivery sells |
| Live WebSocket LTP feed | tick prices + instant stop monitoring; off ⇒ REST polling |
| Auto-exit on target | book the target automatically instead of showing it |
| Manage groups | create / rename / archive / delete-with-reassign |
| Reset account | wipes the simulated book, keeps the groups |

### Trade groups in one minute

A group is a reusable strategy tag (*Momentum*, *IPO base*, *Long term*). It is
inherited by the exit leg so a closed trade never splits across baskets, and it
can be changed later (the position and its legs move together). **Archiving**
hides a group from the trade sheet but keeps its P&L reportable; **deleting**
always asks where to move the trades — history is never destroyed.

### "Why did my P&L go negative when the price moved my way?"

Charges. A ₹10,000 round trip pays roughly ₹24 in delivery costs (brokerage is
zero but STT, exchange fees, GST and the DP charge are not) and about ₹8 intraday.
The order sheet shows the exact numbers before you commit, and every leg stores
what it paid.

## 10. What this app will never do

It never places, modifies or cancels a real order. The paper-trading module
(above) simulates fills against live prices in a local database. Only
**read-only** SmartAPI endpoints are used: login, profile, quotes, historical
candles and the market-data WebSocket.

---

## Rebuilding the workspace from scratch

The sandbox this project is developed in resets regularly: **the project files
survive, the toolchain does not** (`/usr/local/sdk` disappears, so `flutter`
stops being on `PATH`). To get back to a fully working state:

```bash
# 1. Toolchain: JDK 17 + Flutter 3.47.6 + Android SDK 35/36 + build-tools 36
#    + 4 GB swap (Gradle runs out of memory without it on a 2 GB box)
bash /home/user/install_all.sh

# 2. Environment for every later command
export PATH=/usr/local/sdk/flutter/bin:/usr/local/sdk/jdk17/bin:$PATH
export JAVA_HOME=/usr/local/sdk/jdk17 PUB_CACHE=/usr/local/sdk/pubcache \
       ANDROID_SDK_ROOT=/usr/local/sdk/android ANDROID_HOME=/usr/local/sdk/android \
       GRADLE_USER_HOME=/usr/local/sdk/gradle-home

# 3. Dependencies + the project's own checks
cd /home/user/angel_trader
flutter pub get
flutter analyze --no-pub        # expect 0 errors (info-level lints only)
flutter test                    # expect 653/653

# 4. The shippable APK (first build in a fresh sandbox also downloads the
#    Android NDK ~2.2 GB, so it takes ~9 minutes; later builds are faster)
flutter build apk --release --target-platform android-arm64
#  → build/app/outputs/flutter-apk/app-release.apk  (~21.6 MB)
#  → copy to /home/user/NiveshDesk-<version>.apk and delete the old one
```

Notes learned the hard way:

* `install_all.sh` must pipe `yes` into **sdkmanager** (not into `java`) — when
  the licenses are not accepted nothing installs and the build later fails with
  "No Android SDK found".
* The swap step is best-effort on purpose; if it fails silently, Gradle dies
  with `OutOfMemoryError` halfway through `assembleRelease`. Check with
  `grep SwapTotal /proc/meminfo` before building.
* A release build is not byte-reproducible (zip metadata), but the output size
  and version are stable — verify a rebuild with `apksigner verify` plus
  `aapt2 dump badging` rather than by hash.

### Workspace snapshot size (why a warning can appear)

The workspace is snapshotted with a budget of roughly **128 MB / 10,000 files**.
Only a few directory *names* are excluded automatically (`build`, `dist`,
`node_modules`, `__pycache__`, `.cache`, …). Everything else counts, and the
tooling itself leaves two big caches behind:

| Path | Typical size | What it is |
|---|---|---|
| `~/.dartServer` | ~95 MB | Dart analysis-server cache (regenerated on demand) |
| `angel_trader/.dart_tool/flutter_build` | ~56 MB | Flutter build cache |
| `angel_trader/.dart_tool/hooks_runner` | ~34 MB | native-assets hook builds |
| `angel_trader/build/` | ~90 MB | **excluded** from snapshots by name, never counted |

Together the first three are ~185 MB of *regenerable* data — enough to push the
snapshot over the cap and raise the size warning. Run:

```bash
bash /home/user/clean_workspace.sh     # 223 MB -> 40 MB, no source touched
```

It only deletes the three caches above (plus the already-excluded `build/`), and
prints the before/after size. Always do this after a release build.

**Never delete** (not regenerable):

* `~/.android/debug.keystore` — the debug signing key. Every shipped APK since
  1.0.0 is signed with this exact key, which is why a new build installs *over*
  the installed app and keeps its database. `openssl pkcs12 -in
  .android/debug.keystore -nodes -passin pass:android -nokeys | openssl x509
  -outform DER | sha256sum` should print
  `01273e4f2302e1b4a2b90311e96f0780170afb75bba4c64df7cb1ef238c0d579`.
* `NiveshDesk-*.apk` — the shipped build (kept at the workspace root so the file
  matches what is installed on the phone).
* project sources, `assets/`, `uploads/3_Month_Study_Prompt.md`, `design-kit/`.

> A release build is not byte-reproducible (zip metadata), so a rebuild has the
> same version/size but a different `sha256` than the shipped file. Verify a
> rebuild with `apksigner verify` + `aapt2 dump badging` (and the keystore hash
> above), not by comparing file hashes.
