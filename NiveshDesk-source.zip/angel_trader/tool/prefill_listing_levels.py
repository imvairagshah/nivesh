#!/usr/bin/env python3
"""Pre-fill listing-day HIGH/LOW for the bundled IPO master — straight from NSE bhavcopy.

Why this exists
---------------
`assets/data/ipos.csv` ships the whole post-2015 mainboard universe, but listing-day
high/low are exchange prints that no free API hands over one-by-one. Options were:

* leave them blank and let the **app** fetch each one from the broker at runtime
  (`ListingLevelsService` — already implemented, throttled, cached forever), or
* fill as many as possible **here**, offline, so the shipped database is complete
  on day one and the phone never has to make ~500 candle calls.

This script does the second. NSE publishes a *daily bhavcopy* — every traded
symbol's OHLC for that day — and the archive goes back decades. So for each IPO we
download the bhavcopy of its **listing date** and read that symbol's HIGH/LOW: by
definition the first session's range, i.e. the listing-day range we want.

Two file formats, chosen by date:

    >= 2020-01-01   https://archives.nseindia.com/products/content/sec_bhavdata_full_DDMMYYYY.csv
                    SYMBOL, SERIES, DATE1, PREV_CLOSE, OPEN_PRICE, HIGH_PRICE, LOW_PRICE, …
    <  2020-01-01   https://archives.nseindia.com/content/historical/EQUITIES/YYYY/MMM/cmDDMMMYYYYbhav.csv.zip
                    SYMBOL, SERIES, OPEN, HIGH, LOW, CLOSE, LAST, PREVCLOSE

Caveats the script prints instead of hiding
-------------------------------------------
* A company that listed on **BSE first** is absent from the NSE bhavcopy on its
  IPO date (it only shows up on the NSE migration date). Those rows stay blank and
  the app fills them from the broker at runtime — that path already exists.
* Renamed companies changed ticker, so the 2016 bhavcopy says `ZOMATO`, not
  `ETERNAL`. `RENAMED` below carries that mapping.
* Rows whose listing date falls on a non-trading date can't be resolved here.

Usage
-----
    python3 tool/prefill_listing_levels.py --workers 4          # fills in place
    python3 tool/prefill_listing_levels.py --dry-run            # report only
    python3 tool/prefill_listing_levels.py --cache /tmp/bhav    # resumable cache
"""

from __future__ import annotations

import argparse
import concurrent.futures as futures
import csv
import datetime as dt
import io
import json
import pathlib
import sys
import urllib.error
import urllib.request
import zipfile

BASE = pathlib.Path(__file__).resolve().parent.parent
CSV_PATH = BASE / "assets/data/ipos.csv"

NEW_URL = "https://archives.nseindia.com/products/content/sec_bhavdata_full_{ddmmyyyy}.csv"
OLD_URL = ("https://archives.nseindia.com/content/historical/EQUITIES/"
           "{yyyy}/{mon}/cm{dd}{mon}{yyyy}bhav.csv.zip")
NEW_FORMAT_FROM = dt.date(2020, 1, 1)

# ticker when it listed → ticker today (the bhavcopy of the listing day carries the old one)
RENAMED: dict[str, list[str]] = {
    "ETERNAL": ["ZOMATO"],
    "AWL": ["ADANIWILMAR"],
    "RBA": ["BURGERKING", "BURGERKINGINDIA"],
    "LTIM": ["LTI"],
    "GLAND": ["GLAND", "GLENMARKLIFE"],
    "HONASA": ["HONASA", "MAMAEARTH"],
    "JIOFIN": ["JIOFIN", "JFSL"],
    "SETL": ["SGLTL", "SGLT", "STANDARDGLASS"],
    "IKIO": ["IKIO", "IKIOLIGHTING"],
    "PIRAMALFIN": ["PIRAMALFIN", "PEL"],
    "NAM-INDIA": ["RNAM"],
    "ARIS": ["ARISINFRA", "ARIS"],
}


def bhavcopy_url(day: dt.date) -> str:
    if day >= NEW_FORMAT_FROM:
        return NEW_URL.format(ddmmyyyy=day.strftime("%d%m%Y"))
    return OLD_URL.format(yyyy=day.strftime("%Y"), mon=day.strftime("%b").upper(),
                          dd=day.strftime("%d"))


def download(url: str) -> bytes:
    # NSE's archive answers 403 to the old (pre-2020) zip folders unless a
    # same-site Referer rides along — measured: 403 without, 200 with.
    req = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (NiveshDesk data tool)",
        "Referer": "https://www.nseindia.com/",
    })
    with urllib.request.urlopen(req, timeout=60) as resp:  # noqa: S310 - fixed host
        return resp.read()


def parse_bhavcopy(day: dt.date, blob: bytes) -> dict[str, tuple[float, float]]:
    """{symbol: (high, low)} for one trading day."""
    if day >= NEW_FORMAT_FROM:
        text = blob.decode("utf-8", "replace")
    else:
        with zipfile.ZipFile(io.BytesIO(blob)) as zf:
            name = zf.namelist()[0]
            text = zf.read(name).decode("utf-8", "replace")

    # A symbol can appear MULTIPLE TIMES in one bhavcopy — once per series:
    # `EQ` for the cash market, plus debt/permitted series (`N5`, `N6`, `GB`…)
    # that quote completely different prices (SBIN's N6 row on 29-Jan-2021 says
    # 10881.15 while the share traded at 290.65). Only the equity series are
    # meaningful here, and `EQ` wins over the trade-for-trade variants.
    RANK = {"EQ": 0, "BE": 1, "BZ": 2}
    out: dict[str, tuple[float, float]] = {}
    best: dict[str, int] = {}
    for row in csv.DictReader(io.StringIO(text)):
        row = {(k or "").strip(): (v or "").strip() for k, v in row.items()}
        symbol = row.get("SYMBOL", "").upper()
        series = row.get("SERIES", "").upper()
        rank = RANK.get(series)
        if not symbol or rank is None:
            continue
        if symbol in best and best[symbol] <= rank:
            continue
        try:
            if day >= NEW_FORMAT_FROM:
                high, low = float(row["HIGH_PRICE"]), float(row["LOW_PRICE"])
            else:
                high, low = float(row["HIGH"]), float(row["LOW"])
        except (KeyError, ValueError):
            continue
        if high > 0 and low > 0:
            out[symbol] = (high, low)
            best[symbol] = rank
    return out


def day_table(day: dt.date, cache: pathlib.Path) -> dict[str, tuple[float, float]] | None:
    """Cached bhavcopy for one date; None when the archive has nothing for it."""
    cached = cache / f"{day.isoformat()}.json"
    if cached.exists():
        data = json.loads(cached.read_text())
        return None if data is None else {k: tuple(v) for k, v in data.items()}  # type: ignore[return-value]
    try:
        table = parse_bhavcopy(day, download(bhavcopy_url(day)))
    except (urllib.error.HTTPError, urllib.error.URLError, zipfile.BadZipFile, OSError) as exc:
        print(f"  ! {day}: {exc}", file=sys.stderr)
        cached.write_text("null")
        return None
    cache.mkdir(parents=True, exist_ok=True)
    cached.write_text(json.dumps(table))
    return table


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--csv", default=str(CSV_PATH))
    ap.add_argument("--cache", default="/tmp/bhavcopy")
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    csv_path = pathlib.Path(args.csv)
    cache = pathlib.Path(args.cache)
    cache.mkdir(parents=True, exist_ok=True)

    with csv_path.open() as fh:
        rows = list(csv.DictReader(fh))

    todo = [r for r in rows if not (r["Listing High"] and r["Listing Low"])]
    dates = sorted({dt.datetime.strptime(r["Listing Date"], "%d-%b-%Y").date() for r in todo})
    print(f"{len(rows)} rows · {len(todo)} without levels · {len(dates)} distinct listing dates")

    tables: dict[dt.date, dict[str, tuple[float, float]] | None] = {}
    with futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        for day, table in zip(dates, pool.map(lambda d: day_table(d, cache), dates)):
            tables[day] = table

    missing_dates = [d for d, t in tables.items() if t is None]
    filled = 0
    unresolved: list[str] = []
    for row in todo:
        day = dt.datetime.strptime(row["Listing Date"], "%d-%b-%Y").date()
        table = tables.get(day)
        if not table:
            unresolved.append(f"{row['Symbol']:12} {day}  (no NSE bhavcopy for that date)")
            continue
        candidates = [row["Symbol"]] + RENAMED.get(row["Symbol"], [])
        hit = next((table[c] for c in candidates if c in table), None)
        if hit is None:
            unresolved.append(f"{row['Symbol']:12} {day}  (symbol not traded on NSE that day — BSE-first listing)")
            continue
        high, low = hit
        row["Listing High"] = f"{high:.2f}"
        row["Listing Low"] = f"{low:.2f}"
        note = row["Notes"].strip()
        if "bhavcopy" not in note:
            row["Notes"] = f"{note}; listing-day H/L from NSE bhavcopy".strip("; ")
        filled += 1

    print(f"\nfilled {filled} rows · {len(unresolved)} left blank (app fetches these at runtime)")
    print(f"{len(missing_dates)} listing dates had no bhavcopy in the archive: "
          f"{', '.join(str(d) for d in missing_dates[:8])}"
          f"{' …' if len(missing_dates) > 8 else ''}")
    for line in unresolved:
        print("   ", line)

    if args.dry_run:
        print("\n(dry run — nothing written)")
        return 0

    with csv_path.open("w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=[
            "Symbol", "Company Name", "Exchange", "Listing Date",
            "Listing High", "Listing Low", "Sector", "Notes",
        ])
        writer.writeheader()
        writer.writerows(rows)
    levelled = sum(1 for r in rows if r["Listing High"])
    print(f"\nwrote {csv_path}: {len(rows)} rows, {levelled} with levels, {len(rows) - levelled} blank")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
