#!/usr/bin/env python3
"""Generate the launcher icons for NiveshDesk.

Run:  python3 tool/generate_icon.py
Then: dart run flutter_launcher_icons

It writes three 1024×1024 PNGs (all committed, so you only need this when the
branding changes):

    assets/icon/app_icon.png             1024², opaque  — iOS + legacy Android
    assets/icon/app_icon_foreground.png  1024², alpha   — Android adaptive foreground
    assets/icon/app_icon_monochrome.png  1024², alpha   — Android 13+ themed icon

The geometry is IDENTICAL to `BrandGeometry` / `BrandMarkPainter` in
lib/core/widgets/brand.dart — three ascending bars (the screener's candles)
crossed by a gold trend line that breaks out to the top-right. Keep the two in
sync if either changes: the home-screen icon and the in-app mark must match.

The mark: deep brand green plate, soft gold wash from the top-right, cream bars,
gold trend line ending in a dot (the "latest price").
"""

from __future__ import annotations

import pathlib

from PIL import Image, ImageDraw, ImageFilter

SIZE = 1024
OUT = pathlib.Path(__file__).resolve().parent.parent / "assets" / "icon"

# --- brand palette (mirrors Brand in app_theme.dart) -------------------------
GREEN_LIGHT = (18, 135, 106)   # #12876A
GREEN = (11, 107, 79)          # #0B6B4F
GREEN_DEEP = (10, 92, 69)      # #0A5C45
GOLD = (232, 178, 66)          # #E8B242
CREAM = (247, 251, 249)        # #F7FBF9

# --- geometry (mirrors BrandGeometry) ---------------------------------------
PLATE_RADIUS = 0.28
BAR_CENTERS = (0.300, 0.475, 0.650)
BAR_HEIGHTS = (0.220, 0.330, 0.440)
BAR_WIDTH = 0.105
BAR_BASELINE = 0.775
TREND_POINTS = ((0.205, 0.655), (0.375, 0.495), (0.505, 0.575), (0.775, 0.285))
TREND_WIDTH = 0.058
TIP_RADIUS = 0.052


def diagonal_gradient(size: int, stops) -> Image.Image:
    """A top-left → bottom-right gradient across `stops` ((position, rgb)…)."""
    img = Image.new("RGB", (size, size))
    px = img.load()
    for y in range(size):
        for x in range(size):
            t = (x + y) / (2 * (size - 1))
            # find the two stops this t sits between
            lower = stops[0]
            upper = stops[-1]
            for i in range(len(stops) - 1):
                if stops[i][0] <= t <= stops[i + 1][0]:
                    lower, upper = stops[i], stops[i + 1]
                    break
            span = (upper[0] - lower[0]) or 1
            f = (t - lower[0]) / span
            px[x, y] = tuple(
                int(lower[1][c] + (upper[1][c] - lower[1][c]) * f) for c in range(3)
            )
    return img


def rounded_mask(size: int, radius_frac: float) -> Image.Image:
    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).rounded_rectangle(
        (0, 0, size - 1, size - 1),
        radius=int(size * radius_frac),
        fill=255,
    )
    return mask


def gold_wash(size: int) -> Image.Image:
    """Soft gold glow in the top-right corner, for depth."""
    glow = Image.new("L", (size, size), 0)
    draw = ImageDraw.Draw(glow)
    cx, cy = size * 0.88, size * 0.10
    for i in range(60, 0, -1):
        r = size * 0.75 * i / 60
        alpha = int(70 * (1 - i / 60) ** 1.6)
        draw.ellipse((cx - r, cy - r, cx + r, cy + r), fill=alpha)
    wash = Image.new("RGBA", (size, size), GOLD + (0,))
    wash.putalpha(glow)
    return wash


def draw_mark(
    size: int,
    *,
    background: bool,
    monochrome: bool = False,
    content_scale: float = 1.0,
) -> Image.Image:
    """The mark itself. `content_scale` shrinks the artwork inside the plate
    (used for the adaptive-icon foreground, which needs a safe zone)."""
    if background:
        base = diagonal_gradient(
            size,
            ((0.0, GREEN), (0.45, GREEN_LIGHT), (1.0, GREEN_DEEP)),
        ).convert("RGBA")
        wash = gold_wash(size)
        base.alpha_composite(Image.composite(wash, Image.new("RGBA", (size, size), (0, 0, 0, 0)), rounded_mask(size, PLATE_RADIUS)))
        plate = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        plate.paste(base, (0, 0), rounded_mask(size, PLATE_RADIUS))
        canvas = plate
    else:
        canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))

    # Work on a scratch layer and scale it into place, so one set of geometry
    # numbers covers the full-bleed icon and the padded foreground.
    art = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(art)

    bar_fill = (255, 255, 255) if monochrome else CREAM
    bar_alphas = (0.55, 0.70, 0.85) if monochrome else (0.72, 0.81, 0.90)

    baseline = size * BAR_BASELINE
    bar_w = size * BAR_WIDTH
    for center_frac, height_frac, alpha in zip(BAR_CENTERS, BAR_HEIGHTS, bar_alphas):
        cx = size * center_frac
        height = size * height_frac
        draw.rounded_rectangle(
            (cx - bar_w / 2, baseline - height, cx + bar_w / 2, baseline),
            radius=bar_w / 2,
            fill=bar_fill + (int(255 * alpha),),
        )

    points = [(size * x, size * y) for x, y in TREND_POINTS]
    stroke = int(size * TREND_WIDTH)
    line_color = (255, 255, 255, 255) if monochrome else GOLD + (255,)
    # PIL has no round caps: draw the polyline, then a disc at every vertex.
    draw.line(points, fill=line_color, width=stroke, joint="curve")
    for x, y in points:
        draw.ellipse((x - stroke / 2, y - stroke / 2, x + stroke / 2, y + stroke / 2), fill=line_color)

    if not monochrome:
        tx, ty = points[-1]
        r = size * TIP_RADIUS
        draw.ellipse((tx - r, ty - r, tx + r, ty + r), fill=GOLD + (255,))

    if content_scale != 1.0:
        scaled = art.resize(
            (int(size * content_scale), int(size * content_scale)),
            Image.LANCZOS,
        )
        art = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        art.alpha_composite(
            scaled,
            ((size - scaled.width) // 2, (size - scaled.height) // 2),
        )

    canvas.alpha_composite(art)
    return canvas


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)

    full = draw_mark(SIZE, background=True)
    full.convert("RGB").save(OUT / "app_icon.png")

    # Adaptive foreground: transparent, artwork inside the 66% safe zone.
    foreground = draw_mark(SIZE, background=False, content_scale=0.66)
    foreground.save(OUT / "app_icon_foreground.png")

    monochrome = draw_mark(SIZE, background=False, monochrome=True, content_scale=0.66)
    monochrome.save(OUT / "app_icon_monochrome.png")

    for name in ("app_icon.png", "app_icon_foreground.png", "app_icon_monochrome.png"):
        path = OUT / name
        print(f"wrote {path.relative_to(OUT.parent.parent)}  ({path.stat().st_size // 1024} KB)")


if __name__ == "__main__":
    main()
