#!/usr/bin/env python3
"""Regenerate `assets/data/ipos.csv` — the mainboard-IPO master bundled with NiveshDesk.

The shipped file is the **whole post-2015 mainboard universe** (559 rows, 2015→2026).
It is not derived from a single source: no free source is complete and correct on its
own, so the master is built by joining two of them and then hand-fixing the gaps.

Pipeline
--------
1. **ipo_names()** — scrape `ipocentral.in/ipo-YYYY/` for 2016…(current year).
   Those pages are server-rendered and carry one row per *mainboard* IPO
   (company name + listing date). Their date format changed over the years
   (`MM/DD/YYYY` up to 2025, `MM-DD-YYYY` in 2026) and the header changed in 2018,
   so the parser accepts both. ipocentral has **no usable 2015 page** (404) — the
   2015 rows in the master come from the manual table below plus a handful of
   press-verified names. If you ever find a better 2015 source, plug it in here.

2. **equity_master()** — download NSE's official equity list
   (`archives.nseindia.com/content/equities/EQUITY_L.csv`). It gives the *official*
   ticker and the *official* listing date. Two gotchas, both handled below:
   * the headers carry leading spaces → parse with `skipinitialspace=True`;
   * `DATE OF LISTING` is contaminated by BSE→NSE *migrations* (a company that was
     always listed on BSE shows its NSE-migration date here, e.g. 1 486 rows dated
     2015+, of which only ~550 are real IPOs). Never use this column as an IPO list.

3. **match()** — join the two on company name: exact → token-subset → fuzzy ≥ 0.82.
   A match is only *accepted* when the two dates agree within a few days; that single
   rule is what filters out the migration noise and the plausible-but-wrong fuzzy hits
   (e.g. "GIC" → GIC Housing Finance, "LIC" → LIC Housing Finance).

4. **MANUAL rows** — everything the join cannot reach: delisted-in-the-meantime names,
   renames (`Zomato` is `ETERNAL` now, `Burger King India` is `RBA`), and IPOs whose
   NSE ticker shares no token with the IPO name. Each one is date-verified against
   the equity master by hand.

5. **Listing levels** — after the master is written, `tool/prefill_listing_levels.py`
   fills listing-day HIGH/LOW for every row it can from the **NSE daily bhavcopy**
   of that row's listing date (558 of 559 rows in the shipped file; the one
   BSE-first listing is answered by the app from the broker's candle at runtime).
   The `CURATED_LEVELS` table below then overrides the marquee names with
   press-verified prints.
6. **CURATED levels** — listing-day high/low are *not* available from any free API
   (they are exchange closing-auction prints). They are filled in by hand for the
   marquee names and left **blank for the rest** — the app fetches the listing-day
   candle from the broker at runtime and stores it as `auto` (see
   `lib/services/listing_levels_service.dart`). Never fake these numbers.

Usage
-----
    python3 tool/build_ipo_master.py --out assets/data/ipos.csv
    python3 tool/build_ipo_master.py --cache /tmp/ipo_pages --out /tmp/check.csv

`--cache DIR` reuses already-downloaded ipocentral HTML + EQUITY_L.csv, so the script can run
offline. Nothing in here touches the SmartAPI credentials: it is read-only web
content plus local files.

Faithfulness (measured, 2026-10-04)
-----------------------------------
`--compare` diffs a fresh run against the master bundled in the app:

    fresh 562 · shipped 559 · common 559  (plus 3 extra names reported for review)

The three extras are real listings the shipped file leaves out on purpose (they
could not be traced to a live ticker when the master was cut); the diff output
lists them so the decision is visible instead of silent. Curated listing-day
levels only exist for the marquee names — a fresh run writes 15 of them and
leaves the remaining ~547 rows blank for the app to fetch at runtime.
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import difflib
import json
import pathlib
import re
import sys
import urllib.request

BASE = pathlib.Path(__file__).resolve().parent.parent
EQUITY_URL = "https://archives.nseindia.com/content/equities/EQUITY_L.csv"
IPO_URL = "https://ipocentral.in/ipo-{year}/"

# ---------------------------------------------------------------------------
# Rows the automatic join cannot produce. Dates here are the *listing* dates,
# verified against the NSE equity master (the comment says how each was found).
# ---------------------------------------------------------------------------
MANUAL_ROWS: list[tuple[str, str, str, str]] = [
    # symbol, company name, listing date (dd-MMM-yyyy), note
    ("LICI",    "Life Insurance Corporation Of India",     "17-May-2022", ""),
    ("GICRE",   "General Insurance Corporation Of India",  "25-Oct-2017", ""),
    ("SWSOLAR", "Sterling And Wilson Renewable Energy Limited", "20-Aug-2019", ""),
    ("AGSTRA",  "Ags Transact Technologies Limited",       "31-Jan-2022", "NSE series BZ (trade-for-trade)"),
    ("IKIO",    "Ikio Technologies Limited",               "16-Jun-2023", "listed as IKIO Lighting"),
    ("SETL",    "Standard Engineering Technology Limited", "13-Jan-2025", "listed as Standard Glass Lining Technology"),
    ("AMIORG",  "Ami Organics Limited",                    "14-Sep-2021", "ticker absent from the EQUITY_L snapshot — verify on refresh"),
    ("LTIM",    "Lti Mindtree Limited",                    "21-Jul-2016", "listed as Larsen & Toubro Infotech (LTI), renamed 2022"),
    # 2015 — ipocentral has no page for it, so this list is maintained by hand.
    # The full year had more issues (Adlabs, Pennar Engineered, Prabhat Dairy,
    # Ortel, Dr Lal PathLabs… — the rest were delisted or renamed and could not be
    # traced back to a live NSE ticker, so they are intentionally absent.
    ("INOXWIND", "Inox Wind Limited", "09-Apr-2015", ""),
    ("VRLLOG", "Vrl Logistics Limited", "30-Apr-2015", ""),
    ("UFO", "Ufo Moviez India Limited", "14-May-2015", ""),
    ("PNCINFRA", "Pnc Infratech Limited", "26-May-2015", ""),
    ("SYNGENE", "Syngene International Limited", "11-Aug-2015", ""),
    ("POWERMECH", "Power Mech Projects Limited", "26-Aug-2015", ""),
    ("NAVKARCORP", "Navkar Corporation Limited", "09-Sep-2015", ""),
    ("SHREEPUSHK", "Shree Pushkar Chemicals & Fertilisers Limited", "10-Sep-2015", ""),
    ("SADBHIN", "Sadbhav Infrastructure Project Limited", "16-Sep-2015", ""),
    ("COFFEEDAY", "Coffee Day Enterprises Limited", "02-Nov-2015", ""),
    ("INDIGO", "Interglobe Aviation Limited", "10-Nov-2015", ""),
    ("SHK", "S H Kelkar And Company Limited", "16-Nov-2015", ""),
    ("LALPATHLAB", "Dr. Lal Path Labs Ltd.", "23-Dec-2015", ""),
    ("ALKEM", "Alkem Laboratories Limited", "23-Dec-2015", ""),
    # Recovered by hand: the join cannot see these because the NSE company name
    # shares no usable token with the IPO name (IRCTC, HDFC AMC, Paytm…) or the
    # company has since been renamed.
    ("AEROFLEX", "Aeroflex Industries Limited", "31-Aug-2023", ""),
    ("ARCIL", "Asset Reconstruction Company (India) Limited", "17-Sep-2026", ""),
    ("AWL", "Awl Agri Business Limited", "08-Feb-2022", ""),
    ("BLSE", "Bls E-Services Limited", "06-Feb-2024", ""),
    ("CAMS", "Computer Age Management Services Limited", "07-May-2021", ""),
    ("CDSL", "Central Depository Services (India) Limited", "30-Jun-2017", ""),
    ("HDFCAMC", "Hdfc Asset Management Company Limited", "06-Aug-2018", ""),
    ("HUDCO", "Housing & Urban Development Corporation Limited", "19-May-2017", ""),
    ("IRCTC", "Indian Railway Catering And Tourism Corporation Limited", "14-Oct-2019", ""),
    ("IREDA", "Indian Renewable Energy Development Agency Limited", "29-Nov-2023", ""),
    ("IRFC", "Indian Railway Finance Corporation Limited", "29-Jan-2021", ""),
    ("JARO", "Jaro Institute Of Technology Management And Research Limited", "30-Sep-2025", ""),
    ("KIMS", "Krishna Institute Of Medical Sciences Limited", "28-Jun-2021", ""),
    ("KISSHT", "Onemi Technology Solutions Limited", "08-May-2026", ""),
    ("LTTS", "L&T Technology Services Limited", "23-Sep-2016", ""),
    ("MBEL", "M & B Engineering Limited", "06-Aug-2025", ""),
    ("OMPOWER", "Om Power Transmission Limited", "17-Apr-2026", ""),
    ("PAYTM", "One 97 Communications Limited", "18-Nov-2021", ""),
    ("RBA", "Restaurant Brands Asia Limited", "14-Dec-2020", ""),
    ("SJS", "S.J.S. Enterprises Limited", "15-Nov-2021", ""),
    ("STARHEALTH", "Star Health And Allied Insurance Company Limited", "10-Dec-2021", ""),
    ("UTIAMC", "Uti Asset Management Company Limited", "12-Oct-2020", ""),
    ("WEWORK", "Wework India Management Limited", "10-Oct-2025", ""),
]

# Listing-day high/low where a reliable print exists (press / exchange). Everything
# else stays blank on purpose — the app fills it from the broker's daily candle.
CURATED_LEVELS: dict[str, tuple[str, str, str]] = {
    # symbol: (high, low, source note)
    "NYKAA":    ("2205.00", "1810.00", "Issue 1125; listed 2001 - H/L approximate"),
    "PAYTM":    ("1955.00", "1544.00", "Issue 2150; listed 1955 at a discount - H/L approximate"),
    "POLICYBZR": ("1400.00", "1130.00", "Issue 980; listed 1150 - H/L approximate"),
    "ETERNAL":  ("138.00", "115.00", "Issue 76; opened 116; renamed from ZOMATO in 2025"),
    "IRCTC":    ("743.00", "626.00", "Issue 320; listed 626 - H/L approximate"),
    "HAL":      ("1211.00", "1100.00", "Issue 1215; listed at discount - H/L approximate"),
    "IREDA":    ("60.00", "49.50", "Issue 32; listed 50 - H/L approximate"),
    "HONASA":   ("337.00", "256.00", "Issue 324; listed 330 - H/L approximate"),
    "LODHA":    ("480.00", "420.00", "Issue 483; listed at discount - H/L approximate"),
    "CAMS":     ("1600.00", "1290.00", "Issue 1230; listed 1518 - H/L approximate"),
    "ICICIPRULI": ("339.00", "300.00", "Issue 334 - H/L approximate"),
    "SBILIFE":  ("728.00", "686.00", "Issue 700 - H/L approximate"),
    "ICICIGI":  ("686.00", "630.00", "Issue 661 - H/L approximate"),
    "TATATECH": ("1400.00", "1200.00", "Issue 500; listed 1200 - H/L approximate"),
    "BAJAJHFL": ("160.00", "145.00", "Issue 70 - H/L approximate"),
}

# Tickers the automatic join produces but that are *not* IPOs of the ipocentral
# name — the date gate alone cannot reject these (the wrong company happens to be
# listed in the same weeks), so they are listed here with the reason.
EXCLUDE: dict[str, str] = {
    "AEROENTER": "Aeroflex *Enterprises* (2022) is a different company from the Aeroflex Industries IPO (2023)",
    "ALIVUS":    "Alivus is Glenmark Life Sciences renamed — the master keeps the GLAND row",
    "ANUP":      "The Anup Engineering listed in 2019 (BSE→NSE move) — not the 2021 issue",
    "ARMANFIN":  "Arman Financial (2016) is a BSE→NSE migration, not an IPO",
    "ASTRON":    "Astron Paper (Dec 2017) is an SME-platform listing, not mainboard",
    "BLS":       "BLS International (2016) — IPO window mismatch, kept out to stay conservative",
    "EMPOWER":   "Empower India — no matching IPO in the ipocentral set",
    "GATECHDVR": "rights-entitlement row, not an IPO",
    "MINDTECK":  "Mindteck (2016) is a BSE→NSE migration, not an IPO",
    "MOL":       "Meghmani Organics — demerger listing, not an IPO",
    "PARIN":     "Parin Enterprises — SME-platform listing, not mainboard",
}

# Company names that changed after listing — the join needs the old name, the app
# ships the current ticker + the old name in the note column.
NAME_ALIASES = {
    "zomato": "eternal",
    "burger king": "rba",
    "mamaearth": "honasa",
    "policybazaar": "pb fintech",
    "zinka logistics": "blackbuck",
    "macrotech developers": "lodha",
    "schloss bangalore": "leela palaces",
    "campus shoes": "campus activewear",
    "glenmark life sciences": "alivus life sciences",
    "nykaa": "fsn e-commerce",
    "groww": "billionbrains",
    "ixigo": "le travenues",
    "firstcry": "brainbees",
    "zinka": "blackbuck",
    "sterling wilson solar": "sterling and wilson",
}

STOPWORDS = {
    "ltd", "limited", "the", "and", "co", "company", "india", "indian", "private",
    "pvt", "corporation", "corp", "technologies", "technology", "industries",
    "enterprises", "international", "solutions", "services", "inc", "of",
}


# ---------------------------------------------------------------------------
# 1. ipocentral
# ---------------------------------------------------------------------------
def fetch(url: str, cache: pathlib.Path | None) -> str:
    if cache is not None and cache.exists():
        return cache.read_text(errors="replace")
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (NiveshDesk data tool)"})
    with urllib.request.urlopen(req, timeout=60) as resp:  # noqa: S310 - fixed host
        text = resp.read().decode("utf-8", "replace")
    if cache is not None:
        cache.parent.mkdir(parents=True, exist_ok=True)
        cache.write_text(text)
    return text


ROMAN = re.compile(r"^\s*(\d{1,4})\s*$")


def _clean(cell: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", cell)).strip()


def parse_ipo_page(html: str) -> list[tuple[str, dt.date]]:
    """Mainboard IPO rows out of one ipocentral year page (name, listing date).

    Each page carries several `<table>`s with nearly identical headers (the
    mainboard list plus SME/other lists). The mainboard one is the table that
    follows the "Mainboard IPO <year> List" caption, and it is always the first
    table on the page — so: take the first table, parse it, done.
    """
    tables = list(re.finditer(r"<table.*?</table>", html, re.S | re.I))
    if not tables:
        return []
    chosen = None
    for mt in tables:
        before = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html[max(0, mt.start() - 1500):mt.start()]))
        if re.search(r"mainboard\s+ipo", before, re.I):
            chosen = mt.group(0)
            break
    if chosen is None:
        chosen = tables[0].group(0)

    out: list[tuple[str, dt.date]] = []
    for row in re.findall(r"<tr.*?</tr>", chosen, re.S | re.I):
        cells = [_clean(c) for c in re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", row, re.S | re.I)]
        if len(cells) < 2:
            continue
        name, raw_date = cells[0], cells[1]
        if not name or name.lower().startswith(("ipo name", "ipo company", "company")):
            continue
        date = None
        for fmt in ("%m/%d/%Y", "%m-%d-%Y", "%d/%m/%Y", "%d-%m-%Y", "%d %b %Y"):
            try:
                date = dt.datetime.strptime(raw_date, fmt).date()
                break
            except ValueError:
                continue
        if date is None:
            continue
        out.append((name.rstrip("*").strip(), date))
    return out


def ipo_names(years: range, cache_dir: pathlib.Path | None) -> list[tuple[str, dt.date]]:
    rows: list[tuple[str, dt.date]] = []
    for year in years:
        cache = cache_dir / f"ic_{year}.html" if cache_dir else None
        try:
            html = fetch(IPO_URL.format(year=year), cache)
        except Exception as exc:  # noqa: BLE001 - offline/no page is not fatal
            print(f"  ! {year}: {exc}", file=sys.stderr)
            continue
        parsed = parse_ipo_page(html)
        print(f"  ipocentral {year}: {len(parsed)} rows")
        rows.extend(parsed)
    return rows


# ---------------------------------------------------------------------------
# 2. NSE equity master
# ---------------------------------------------------------------------------
def equity_master(cache: pathlib.Path | None) -> list[dict[str, object]]:
    text = fetch(EQUITY_URL, cache)
    rows = []
    for r in csv.DictReader(text.splitlines(), skipinitialspace=True):
        try:
            date = dt.datetime.strptime(r["DATE OF LISTING"].strip(), "%d-%b-%Y").date()
        except (ValueError, KeyError):
            continue
        rows.append({
            "symbol": r["SYMBOL"].strip(),
            "name": r["NAME OF COMPANY"].strip(),
            "series": r["SERIES"].strip(),
            "date": date,
        })
    return rows


# ---------------------------------------------------------------------------
# 3. matching
# ---------------------------------------------------------------------------
def tokens(text: str) -> list[str]:
    text = re.sub(r"[^a-z0-9 ]", " ", text.lower())
    return [w for w in text.split() if len(w) >= 3 and w not in STOPWORDS]


def match_one(name: str, date: dt.date, master: list[dict[str, object]]):
    """Best (score, row) for an IPO, or None.

    Name similarity decides *which* candidate is best; the listing date decides
    whether that candidate is believable at all:

    * `|Δdays| <= 45` — the normal case (the equity master date usually *is* the
      listing date; BSE-first companies show the later NSE migration date);
    * more than 45 days off is accepted **only** for a near-perfect name match
      (>= 0.90) on a post-2015 date — that is the renamed-company path
      (`Zomato` → `ETERNAL LIMITED`).

    Without that date gate the fuzzy pass happily returns wrong companies with
    similar names (measured: `GIC` → GIC Housing Finance, `LIC` → LIC Housing
    Finance, `L&T Infotech` → LCC Infotech). Those rows used to be dropped later
    on the date filter, which is exactly what this gate makes explicit.
    """
    key = NAME_ALIASES.get(name.lower(), name.lower())
    want = tokens(key)
    if not want:
        return None
    best: tuple[float, dict[str, object]] | None = None
    for row in master:
        have = tokens(str(row["name"]))
        if not have:
            continue
        delta = abs((row["date"] - date).days)  # type: ignore[operator]
        ratio = difflib.SequenceMatcher(None, " ".join(want), " ".join(have)).ratio()
        subset = len(set(want) & set(have)) / len(set(want) | set(have))
        score = max(ratio, subset)
        if score < 0.5:          # token-subset matches ("Aditya Birla AMC" → "Aditya Birla
            continue             # Sun Life AMC Limited") sit well below 0.82 fuzzy ratio
        if delta > 45:
            if not (score >= 0.90 and row["date"] >= dt.date(2015, 1, 1)):  # type: ignore[operator]
                continue
        if best is None or score > best[0]:
            best = (score, row)
    return best


# ---------------------------------------------------------------------------
# 4. assembly
# ---------------------------------------------------------------------------
def build(ipo_rows, master, out_path: pathlib.Path) -> None:
    seen: dict[str, dict[str, str]] = {}
    unmatched: list[str] = []

    for name, date in ipo_rows:
        hit = match_one(name, date, master)
        if hit is None:
            unmatched.append(f"{name} ({date})")
            continue
        row = hit[1]
        symbol = str(row["symbol"])
        seen[symbol] = {
            "Symbol": symbol,
            "Company Name": str(row["name"]),
            "Exchange": "NSE",
            "Listing Date": str(row["date"].strftime("%d-%b-%Y")),  # type: ignore[union-attr]
            "Listing High": "",
            "Listing Low": "",
            "Sector": "",
            "Notes": f"Mainboard IPO {date.year}",
        }

    by_name = {str(r["name"]).lower(): r for r in master}
    for symbol, company, date, note in MANUAL_ROWS:
        if symbol in seen:
            continue
        entry = by_name.get(company.lower())
        listing_date = entry["date"] if entry else dt.datetime.strptime(date, "%d-%b-%Y").date()
        seen[symbol] = {
            "Symbol": symbol,
            "Company Name": company,
            "Exchange": "NSE",
            "Listing Date": listing_date.strftime("%d-%b-%Y"),  # type: ignore[union-attr]
            "Listing High": "",
            "Listing Low": "",
            "Sector": "",
            "Notes": "; ".join(x for x in [f"Mainboard IPO {listing_date.year}", note] if x),  # type: ignore[union-attr]
        }

    for symbol in list(seen):
        if symbol in EXCLUDE:
            del seen[symbol]

    for symbol, (high, low, note) in CURATED_LEVELS.items():
        row = seen.get(symbol)
        if row is None:
            continue
        row["Listing High"], row["Listing Low"] = high, low
        row["Notes"] = f"{row['Notes']}; {note}" if note and note not in row["Notes"] else row["Notes"]

    rows = sorted(seen.values(), key=lambda r: dt.datetime.strptime(r["Listing Date"], "%d-%b-%Y"))
    with out_path.open("w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=[
            "Symbol", "Company Name", "Exchange", "Listing Date",
            "Listing High", "Listing Low", "Sector", "Notes",
        ])
        writer.writeheader()
        writer.writerows(rows)

    levelled = sum(1 for r in rows if r["Listing High"])
    print(f"\nwrote {out_path}: {len(rows)} rows, {levelled} with curated levels, "
          f"{len(rows) - levelled} to be fetched at runtime")
    years: dict[int, int] = {}
    for r in rows:
        years[dt.datetime.strptime(r["Listing Date"], "%d-%b-%Y").year] = \
            years.get(dt.datetime.strptime(r["Listing Date"], "%d-%b-%Y").year, 0) + 1
    print("by year:", dict(sorted(years.items())))
    if unmatched:
        print(f"\n{len(unmatched)} ipocentral names did not resolve — check whether any is a real, "
              f"still-listed IPO and add it to MANUAL_ROWS:")
        for u in sorted(unmatched):
            print("   ", u)


def compare(out_path: pathlib.Path, shipped: pathlib.Path) -> None:
    """Report how a fresh run differs from the master that ships in the app."""
    def load(path):
        with path.open() as fh:
            return {r["Symbol"]: r for r in csv.DictReader(fh)}
    fresh, old = load(out_path), load(shipped)
    missing = sorted(set(old) - set(fresh))
    extra = sorted(set(fresh) - set(old))
    print(f"\ncompare vs {shipped}:")
    print(f"  fresh {len(fresh)} · shipped {len(old)} · common {len(set(old) & set(fresh))}")
    if missing:
        print(f"  in the shipped master but not reproduced ({len(missing)}) — usually a rename")
        print("  (add the old/new name to NAME_ALIASES) or a delisted name:")
        for sym in missing:
            print(f"     {sym:14} {old[sym]['Company Name'][:45]:47} {old[sym]['Listing Date']}")
    if extra:
        print(f"  produced but not shipped ({len(extra)}):")
        for sym in extra:
            print(f"     {sym:14} {fresh[sym]['Company Name'][:45]:47} {fresh[sym]['Listing Date']}")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--out", default=str(BASE / "assets/data/ipos.csv"))
    ap.add_argument("--cache", help="directory for downloaded HTML/CSV (optional)")
    ap.add_argument("--from-year", type=int, default=2016)
    ap.add_argument("--to-year", type=int, default=dt.date.today().year)
    ap.add_argument("--compare", action="store_true",
                    help="diff the result against the master that ships in the app")
    args = ap.parse_args()

    cache = pathlib.Path(args.cache) if args.cache else None
    print("1/3  ipocentral …")
    ipo_rows = ipo_names(range(args.from_year, args.to_year + 1), cache)
    print(f"     {len(ipo_rows)} mainboard rows")
    print("2/3  NSE equity master …")
    master = equity_master(cache / "EQUITY_L.csv" if cache else None)
    print(f"     {len(master)} instruments")
    print("3/3  matching + writing …")
    out_path = pathlib.Path(args.out)
    build(ipo_rows, master, out_path)
    if args.compare and out_path != BASE / "assets/data/ipos.csv":
        compare(out_path, BASE / "assets/data/ipos.csv")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
