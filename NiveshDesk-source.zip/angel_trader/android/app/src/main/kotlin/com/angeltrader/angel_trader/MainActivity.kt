package com.angeltrader.angel_trader

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
