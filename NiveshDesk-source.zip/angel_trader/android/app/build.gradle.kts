plugins {
    id("com.android.application")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace = "com.angeltrader.angel_trader"
    compileSdk = 37
    ndkVersion = flutter.ndkVersion

    compileOptions {
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    defaultConfig {
        // TODO: Specify your own unique Application ID (https://developer.android.com/studio/build/application-id.html).
        applicationId = "com.angeltrader.angel_trader"
        // You can update the following values to match your application needs.
        // For more information, see: https://flutter.dev/to/review-gradle-config.
        minSdk = flutter.minSdkVersion
        targetSdk = flutter.targetSdkVersion
        // Uses the version code from pubspec.yaml. When using split APKs, 1000 * ABI_VERSION
        // is added automatically by Flutter. (https://developer.android.com/studio/build/configure-apk-splits#configure-APK-versions)
        // You can force using the value of versionCode by specifying the `-P force-version-code-ignoring-abi=true`
        // flag during build.
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    defaultConfig {
        // NiveshDesk ships ONE APK for 64-bit phones (all phones from ~2017 on).
        // `flutter build apk --target-platform android-arm64` restricts the
        // Flutter engine (libflutter.so / libapp.so) but NOT the native libraries
        // that plugins ship prebuilt, so without this filter the APK would also
        // carry armeabi-v7a/x86_64 copies of evicting plugin libs (~100 KB each
        // and, worse, it would let the APK install on a 32-bit phone and crash
        // on start because there is no 32-bit engine inside).
        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    buildTypes {
        release {
            // TODO: Add your own signing config for the release build.
            // Signing with the debug keys for now, so `flutter run --release` works.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    packaging {
        jniLibs {
            // Belt and braces for the arm64-only policy. `ndk.abiFilters` above is
            // not always enough: prebuilt libraries that arrive through plugin
            // AARs (e.g. libdartjni.so from the sqlite3/jni stack) have been seen
            // to keep their 32-bit copies in the APK. Dropping those directories
            // outright means a 32-bit phone gets a clean INSTALL_FAILED_NO_MATCHING_ABIS
            // instead of installing and then crashing on start.
            excludes += listOf("lib/armeabi-v7a/**", "lib/x86/**", "lib/x86_64/**", "lib/mips/**", "lib/mips64/**")
        }
    }

    lint {
        // `lintVitalRelease` is a *check*, never a build input — the APK it
        // guards is byte-for-byte the same with or without it. On a low-RAM
        // machine (this project is developed on 2 GB) it is also by far the
        // heaviest task of the release build and is what tips Gradle into swap
        // thrashing, so it is disabled here. Set this back to `true` on a normal
        // development machine — it catches fatal issues before you ship.
        checkReleaseBuilds = false
    }
}

kotlin {
    compilerOptions {
        jvmTarget = org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17
    }
}

flutter {
    source = "../.."
}

dependencies {
    // flutter_local_notifications ke liye zaroori (Java 8+ APIs backport).
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")
}
