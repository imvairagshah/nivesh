; ---------------------------------------------------------------------------
; NiveshDesk — Inno Setup installer script (optional, recommended).
; Kaise: Inno Setup (free) install karo → is file ko open karo → Compile (F9)
; → Output\NiveshDesk-Setup.exe ban jayega.
; ---------------------------------------------------------------------------
#define AppName "NiveshDesk"
#define AppVersion "1.5.72"
#define AppExeName "NiveshDesk.exe"

[Setup]
AppId={{8F3B2A61-5C4E-4D2A-9B7N-NIVESHDESK01}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher=NiveshDesk
DefaultDirName={autopf}\{#AppName}
DefaultGroupName={#AppName}
OutputBaseFilename=NiveshDesk-Setup-{#AppVersion}
OutputDir=Output
Compression=lzma2
SolidCompression=yes
ArchitecturesInstallIn64BitMode=x64
; unsigned exe hai — SmartScreen ek baar "More info → Run anyway" dikh sakta hai.
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Desktop icon"; GroupDescription: "Additional icons:"

[Files]
; flutter build windows --release ka poora Release folder yahan copy karo
; (ya is .iss ko Release folder ke upar rakho aur neeche ka path adjust karo).
Source: "build\windows\x64\runner\Release\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\{#AppName}"; Filename: "{app}\{#AppExeName}"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\{#AppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppExeName}"; Description: "Launch {#AppName}"; Flags: nowait postinstall skipifsilent
