@echo off
rem ---------------------------------------------------------------------------
rem  NiveshDesk — Windows .exe build (ek baar chalana kaafi; output ke niche)
rem  Zaroorat: Flutter SDK + Visual Studio Build Tools (C++ desktop workload)
rem  Poora guide: DESKTOP_BUILD.md
rem ---------------------------------------------------------------------------
cd /d "%~dp0"

echo [1/3] Dependencies...
call flutter pub get || goto :error

echo [2/3] Release build (5-10 min)...
call flutter build windows --release || goto :error

echo [3/3] Ho gaya! App yahan hai:
echo       build\windows\x64\runner\Release\NiveshDesk.exe
echo.
echo Installer banana ho to: is folder ko Inno Setup ke installer.iss se compile karo
echo (guide DESKTOP_BUILD.md me hai).
exit /b 0

:error
echo.
echo BUILD FAIL — upar ka error dekho. Agar "flutter" nahi mila to PATH check
echo karo; Agar C++ toolchain chahiye to Visual Studio Build Tools install karo
echo (DESKTOP_BUILD.md step 1).
exit /b 1
