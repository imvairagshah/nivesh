// ---------------------------------------------------------------------------
// app_providers_test.dart — the guard against the blank screen.
//
// Why this file exists (1.5.21): a screen read `FnoStudyService` out of the
// context, the app had never provided it, and every unit test was green — the
// provider tests inject their own fakes, so nothing ever exercised the real
// tree. On a phone the build threw, and a *release* build answers a build-time
// exception with an empty grey rectangle: "pura blank screen", no message,
// nothing to report.
//
// Two screens were hit by it: the new advance-filter page (FnoStudyService)
// and the Group Manager (TradeGroupDao, already broken before this release).
//
// So this test does what no unit test can: it reads `lib/` and checks that
// EVERY type some widget pulls out of the context with `read<T>()` is actually
// installed by `lib/app.dart`. It is a source check, not a widget test — that
// is the point. One missing provider, one red test, right here in CI.
// ---------------------------------------------------------------------------

import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

/// Every `read<Something>()` / `watch<Something>()` in [dir].
Set<String> typesReadFromContext(Directory dir) {
  final found = <String>{};
  final pattern = RegExp(r'\.(read|watch)<([A-Za-z0-9_]+)>\s*\(');

  for (final entity in dir.listSync(recursive: true)) {
    if (entity is! File || !entity.path.endsWith('.dart')) continue;
    for (final match in pattern.allMatches(entity.readAsStringSync())) {
      found.add(match.group(2)!);
    }
  }
  return found;
}

/// Every type some `Provider<Foo>` in the app installs.
///
/// Scanned across [dir], not just `lib/app.dart`: a screen may create its own
/// provider for the subtree it owns (`StudyAdvScreen` does), and reading that
/// type inside its own subtree is fine.
Set<String> typesProvidedBy(String dir) {
  final provided = <String>{};
  final pattern = RegExp(r'(ChangeNotifier|Value|Future|Stream)?Provider<([A-Za-z0-9_]+)>');

  for (final entity in Directory(dir).listSync(recursive: true)) {
    if (entity is! File || !entity.path.endsWith('.dart')) continue;
    for (final match in pattern.allMatches(entity.readAsStringSync())) {
      provided.add(match.group(2)!);
    }
  }
  return provided;
}

void main() {
  final root = Directory('${Directory.current.path}/lib');
  final appFile = '${Directory.current.path}/lib/app.dart';

  test('lib/ and lib/app.dart are where this test expects them', () {
    expect(root.existsSync(), isTrue, reason: 'run from the project root');
    expect(File(appFile).existsSync(), isTrue);
  });

  test('everything a widget reads from the context is provided somewhere', () {
    final read = typesReadFromContext(root);
    final provided = typesProvidedBy(root.path);

    // Keep the two lists honest: if the app stops reading anything, the test
    // below is not quietly passing on an empty set.
    expect(read, isNotEmpty);
    expect(provided, isNotEmpty);

    final missing = {...read}..removeAll(provided);
    expect(
      missing,
      isEmpty,
      reason: 'a widget reads ${missing.join(', ')} out of the context but no '
          'provider anywhere in lib/ installs it. On a phone that throws while '
          'the screen builds — and a release build shows a blank screen.',
    );
  });

  test('the services a whole page needs come from the root, not a screen', () {
    // Anything the ROOT tree installs is reachable from every route. A type
    // only provided by one screen is one refactor away from the same bug, so
    // the two that shipped broken are pinned here by name.
    final rootProvided = <String>{};
    for (final match in RegExp(r'(ChangeNotifier)?Provider<([A-Za-z0-9_]+)>')
        .allMatches(File(appFile).readAsStringSync())) {
      rootProvided.add(match.group(2)!);
    }

    expect(
      rootProvided,
      contains('FnoStudyService'),
      reason: 'the advance-filter page reads it (1.5.21 blank screen)',
    );
    expect(
      rootProvided,
      contains('TradeGroupDao'),
      reason: 'the Group Manager screen reads it (same bug, older)',
    );
  });

  test('both broken screens really do read those two from the context', () {
    // The read side, pinned to the files that ship the screens — so the fix
    // above cannot be "solved" by deleting the reader.
    final adv = File('${root.path}/features/fno/study_adv/study_adv_screen.dart')
        .readAsStringSync();
    expect(adv, contains('read<FnoStudyService>'));

    final groups =
        File('${root.path}/features/paper_trading/group_manager_screen.dart')
            .readAsStringSync();
    expect(groups, contains('read<TradeGroupDao>'));
  });

  test('a build-time failure is shown, not swallowed', () {
    // main.dart replaces Flutter's error widget; in a release build the
    // default one is an empty grey box — the blank screen the user saw.
    final source = File('${Directory.current.path}/lib/main.dart')
        .readAsStringSync();
    expect(source, contains('ErrorWidget.builder'));
  });
}
