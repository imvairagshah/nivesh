// ---------------------------------------------------------------------------
// app_boot_test.dart — the app must paint its FIRST FRAME.
//
// Why this exists (1.5.21, the black screen): the app installed fine, then
// opened to a *completely black* screen. The cause was the splash: it is built
// by the root `FutureBuilder`, i.e. ABOVE the app's own `MaterialApp` — which
// does not exist yet, because the services it needs are still being built. A
// `Text` with no `Directionality` ancestor throws, and a release build answers
// a build-time exception by painting NOTHING: the user gets the bare Android
// window background, which in dark mode is black, for as long as boot takes.
//
// Unit tests could not see it (they build screens, not the app) and neither
// could the provider guard (it checks wiring, not painting). This test builds
// the real `AngelTraderApp` and looks at the first frame.
//
// It stops at the first frame on purpose: the app's remaining boot steps talk
// to SQLite through sqflite/ffi, which deadlocks under the test harness's fake
// async clock. The black screen happened *before* any of that, and that is
// exactly what is pinned here.
// ---------------------------------------------------------------------------

import 'dart:io';

import 'package:angel_trader/app.dart';
import 'package:angel_trader/data/local/app_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close();
  });

  // No tearDownAll close: the first-frame smoke test intentionally unmounts
  // while asynchronous boot may still have sqflite_ffi work in flight. Closing
  // that connection from the fake-async widget harness can block indefinitely;
  // each following test already closes it in setUp, and this in-memory DB plus
  // its isolate are discarded when the suite exits.

  testWidgets('the first frame paints — no exception before the shell',
      (tester) async {
    await tester.pumpWidget(const AngelTraderApp());
    await tester.pump();
    // Let the splash's staggered entrance run — the animations are part of the
    // first second on screen, and an exception in one of them is the same
    // black screen as an exception in the build.
    await tester.pump(const Duration(milliseconds: 400));
    await tester.pump();

    // The regression, in one line: if this throws, the screen is black.
    expect(
      tester.takeException(),
      isNull,
      reason: 'the app threw while painting its first frame. In a release '
          'build that paints nothing at all — a black screen.',
    );

    // And something is really there: a tree that paints nothing is the same
    // black screen with no exception to point at.
    expect(find.byType(Scaffold), findsOneWidget);
    expect(find.text('Paper trading only · no real orders'), findsOneWidget);

    // Unmount, so the boot-budget timer does not outlive the test.
    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump();
  });

  testWidgets('the splash survives having no MaterialApp above it',
      (tester) async {
    // Reproduced deliberately: the splash as a plain root widget. This is the
    // position it occupies in the real app — no MaterialApp, no Directionality,
    // nothing it did not bring itself.
    await tester.pumpWidget(const MediaQuery(
      data: MediaQueryData(),
      child: Directionality(
        textDirection: TextDirection.ltr,
        child: AngelTraderApp(),
      ),
    ));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 400));

    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump(const Duration(milliseconds: 400));
  });

  test('the splash brings its own Directionality and Theme', () {
    final source = File('${Directory.current.path}/lib/app.dart').readAsStringSync();
    final splash = source.substring(source.indexOf('class _SplashScreen'));
    final body = splash.substring(0, splash.indexOf('\nclass '));

    expect(
      body,
      contains('Directionality'),
      reason: 'the splash is built above MaterialApp; without its own '
          'Directionality every Text in it throws',
    );
    expect(body, contains('Theme('), reason: 'it also has no Theme ancestor');
    // …and it says what boot is doing, so a slow start is never silent.
    expect(body, contains('Der ho rahi hai'));
  });

  test('boot has a budget, and a stuck boot offers a way out', () {
    final source = File('${Directory.current.path}/lib/app.dart').readAsStringSync();

    expect(source, contains('bootBudget'));
    expect(source, contains('Dobara koshish karo'));
    expect(
      source,
      contains('TimeoutException'),
      reason: 'an await that never returns must become a visible failure',
    );
  });

  test('the error widget can render where there is no MaterialApp', () {
    // main.dart replaces Flutter's error widget so a failure is never a blank
    // screen. It must not depend on a MaterialApp being above it — errors
    // happen most often exactly where there isn't one.
    final source = File('${Directory.current.path}/lib/main.dart')
        .readAsStringSync();

    expect(source, contains('ErrorWidget.builder'));
    expect(
      source,
      contains('Directionality'),
      reason: 'a Text without Directionality throws, so the error widget '
          'would throw while reporting the error — the black screen again',
    );
  });
}
