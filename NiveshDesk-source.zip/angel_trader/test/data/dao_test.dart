// DAO / SQL tests — these run the *real* schema and query strings.
//
// On a device or emulator `flutter test` uses the Flutter sqflite plugin; on a
// desktop VM the FFI binding (sqflite_common_ffi) is used, so the same test file
// works everywhere:
//     flutter test test/data/dao_test.dart

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/ipo_dao.dart';
import 'package:angel_trader/data/local/dao/scan_cache_dao.dart';
import 'package:angel_trader/data/local/dao/scrip_dao.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/data/local/models/app_settings.dart';
import 'package:angel_trader/data/local/models/ipo.dart';
import 'package:angel_trader/data/remote/dto/quote.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

const _seedCsv = '''
Symbol,Company Name,Exchange,Listing Date,Listing High,Listing Low,Sector
IDEA,Vodafone Idea Ltd,NSE,31-Jan-2018,24.60,14.05,Telecom
NYKAA,FSN E-Commerce Ventures Ltd,NSE,10-Nov-2021,2101.00,1712.05,Consumer
DELHIVERY,Delhivery Ltd,BSE,24-May-2022,537.00,455.00,Logistics
BADROW,Broken Row Ltd,NSE,,,,
''';

void main() {
  late IpoDao ipos;
  late SettingsDao settings;
  late ScripDao scrips;
  late ScanCacheDao cache;

  setUpAll(() {
    // Desktop/VM test setup. On a device this is a no-op because the plugin
    // factory is already installed.
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close(); // reopen fresh schema for each test
    final db = AppDatabase.instance;
    ipos = IpoDao(db);
    settings = SettingsDao(db);
    scrips = ScripDao(db);
    cache = ScanCacheDao(db);
  });

  tearDown(() async {
    await AppDatabase.instance.close();
  });

  // -------------------------------------------------------------------------
  group('IpoDao — CRUD', () {
    test('insert, read back and update a row', () async {
      final id = await ipos.insert(Ipo(
        symbol: 'IDEA',
        companyName: 'Vodafone Idea Ltd',
        exchange: Exchange.nse,
        listingDate: DateTime(2018, 1, 31),
        listingHigh: 24.6,
        listingLow: 14.05,
      ));

      expect(id, greaterThan(0));
      expect(await ipos.count(), 1);

      final loaded = (await ipos.byId(id))!;
      expect(loaded.symbol, 'IDEA');
      expect(loaded.listingHigh, closeTo(24.6, 1e-9));

      await ipos.update(loaded.copyWith(companyName: 'Vodafone Idea Limited', notes: 'edited'));
      final edited = (await ipos.byId(id))!;
      expect(edited.companyName, 'Vodafone Idea Limited');
      expect(edited.notes, 'edited');

      await ipos.delete(id);
      expect(await ipos.count(), 0);
    });

    test('a duplicate (symbol, exchange) pair is rejected by the index', () async {
      final ipo = Ipo(
        symbol: 'IDEA',
        companyName: 'Vodafone Idea Ltd',
        exchange: Exchange.nse,
        listingDate: DateTime(2018, 1, 31),
        listingHigh: 24.6,
        listingLow: 14.05,
      );
      await ipos.insert(ipo);
      expect(() => ipos.insert(ipo), throwsA(isA<Object>()));
      // …but the same ticker on the other exchange is a different instrument.
      await ipos.insert(ipo.copyWith(exchange: Exchange.bse));
      expect(await ipos.count(), 2);
    });

    test('upsert is idempotent and can overwrite', () async {
      final ipo = Ipo(
        symbol: 'NYKAA',
        companyName: 'FSN E-Commerce Ventures Ltd',
        exchange: Exchange.nse,
        listingDate: DateTime(2021, 11, 10),
        listingHigh: 2101,
        listingLow: 1712.05,
      );

      await ipos.upsert(ipo, overwrite: false);
      await ipos.upsert(ipo.copyWith(listingHigh: 9999), overwrite: false);
      expect(await ipos.count(), 1);
      expect((await ipos.all()).single.listingHigh, closeTo(2101, 1e-9),
          reason: 'overwrite:false must not clobber existing data');

      await ipos.upsert(ipo.copyWith(listingHigh: 9999), overwrite: true);
      expect(await ipos.count(), 1);
      expect((await ipos.all()).single.listingHigh, closeTo(9999, 1e-9));
    });

    test('deleteAll(keepUserAdded: true) keeps hand-entered rows', () async {
      await ipos.insert(Ipo(
        symbol: 'SEEDED',
        companyName: 'From CSV Ltd',
        exchange: Exchange.nse,
        listingDate: DateTime(2019, 1, 1),
        listingHigh: 100,
        listingLow: 90,
      ));
      await ipos.insert(Ipo(
        symbol: 'MINE',
        companyName: 'Typed by me',
        exchange: Exchange.nse,
        listingDate: DateTime(2020, 1, 1),
        listingHigh: 50,
        listingLow: 40,
        isCustom: true,
      ));

      final deleted = await ipos.deleteAll(keepUserAdded: true);
      expect(deleted, 1);
      expect((await ipos.all()).single.symbol, 'MINE');
    });
  });

  // -------------------------------------------------------------------------
  group('IpoDao — CSV seeding', () {
    test('seeds valid rows and reports the broken one', () async {
      final report = await ipos.seedFromCsv(_seedCsv);

      expect(report.inserted, 3);
      expect(report.failed, 1);
      expect(report.errors.single, contains('BADROW'));
      expect(await ipos.count(), 3);
    });

    test('re-seeding is idempotent (app updates must not duplicate rows)', () async {
      await ipos.seedFromCsv(_seedCsv);
      final second = await ipos.seedFromCsv(_seedCsv);
      expect(second.inserted, 0);
      expect(second.skipped, 3);
      expect(await ipos.count(), 3);
    });

    test('user edits survive a re-seed unless overwrite is requested', () async {
      await ipos.seedFromCsv(_seedCsv);
      final idea = (await ipos.all()).firstWhere((i) => i.symbol == 'IDEA');
      await ipos.update(idea.copyWith(listingHigh: 25.75, notes: 'my note'));

      await ipos.seedFromCsv(_seedCsv);
      final afterReseed = (await ipos.all()).firstWhere((i) => i.symbol == 'IDEA');
      expect(afterReseed.listingHigh, closeTo(25.75, 1e-9));
      expect(afterReseed.notes, 'my note');

      await ipos.seedFromCsv(_seedCsv, overwrite: true);
      final afterForce = (await ipos.all()).firstWhere((i) => i.symbol == 'IDEA');
      expect(afterForce.listingHigh, closeTo(24.6, 1e-9));
    });
  });

  // -------------------------------------------------------------------------
  group('IpoDao — filtering', () {
    setUp(() async {
      await ipos.seedFromCsv(_seedCsv);
    });

    test('filters by exchange, year and free text', () async {
      expect((await ipos.search(exchange: Exchange.bse)).single.symbol, 'DELHIVERY');
      expect((await ipos.search(listingYear: 2021)).single.symbol, 'NYKAA');
      expect((await ipos.search(query: 'vodafone')).single.symbol, 'IDEA');
      expect((await ipos.search(query: 'logistics')).single.symbol, 'DELHIVERY');
      expect(await ipos.search(query: 'nothing-matches'), isEmpty);
    });

    test('listingYears returns distinct years newest first', () async {
      expect(await ipos.listingYears(), [2022, 2021, 2018]);
    });

    test('all() is ordered by listing date, newest first', () async {
      final symbols = (await ipos.all()).map((i) => i.symbol).toList();
      expect(symbols, ['DELHIVERY', 'NYKAA', 'IDEA']);
    });
  });

  // -------------------------------------------------------------------------
  group('SettingsDao', () {
    test('returns defaults before anything is saved', () async {
      final loaded = await settings.load();
      expect(loaded.startingCapital, 100000);
      expect(loaded.proximityPct, 3);
      expect(loaded.deathCrossEnabled, isFalse);
      expect(loaded.themeMode, 'system');
    });

    test('round-trips a modified AppSettings', () async {
      await settings.save(const AppSettings(
        startingCapital: 250000,
        proximityPct: 5,
        deathCrossEnabled: true,
        autoRefreshSeconds: 120,
        themeMode: 'dark',
        keepScreenAwake: true,
      ));

      final loaded = await settings.load();
      expect(loaded.startingCapital, 250000);
      expect(loaded.proximityPct, 5);
      expect(loaded.deathCrossEnabled, isTrue);
      expect(loaded.autoRefreshSeconds, 120);
      expect(loaded.themeMode, 'dark');
      expect(loaded.keepScreenAwake, isTrue);
    });

    test('clamps out-of-range values instead of trusting the store', () async {
      await settings.put('proximity_pct', '900');
      await settings.put('auto_refresh_seconds', '1');
      final loaded = await settings.load();
      expect(loaded.proximityPct, lessThanOrEqualTo(25));
      expect(loaded.autoRefreshSeconds, greaterThanOrEqualTo(15));
    });

    test('scrip-master metadata is stored and read back', () async {
      expect(await settings.meta('master_rows'), isNull);
      await settings.putMeta('master_rows', '5231');
      expect(await settings.meta('master_rows'), '5231');
    });
  });

  // -------------------------------------------------------------------------
  group('ScripDao', () {
    final sample = [
      const Scrip(token: '3045', symbol: 'SBIN-EQ', name: 'STATE BANK OF INDIA', exchange: Exchange.nse),
      const Scrip(token: '1594', symbol: 'IDEA-EQ', name: 'VODAFONE IDEA LIMITED', exchange: Exchange.nse),
      const Scrip(token: '543529', symbol: 'DELHIVERY', name: 'DELHIVERY LIMITED', exchange: Exchange.bse),
    ];

    test('replaceAll caches the master (replacing previous contents)', () async {
      await scrips.replaceAll(sample, batchSize: 2);
      expect(await scrips.count(), 3);

      await scrips.replaceAll(sample.take(1).toList());
      expect(await scrips.count(), 1);
    });

    test('lookup by token and by symbol', () async {
      await scrips.replaceAll(sample);
      expect((await scrips.findByToken('1594'))!.symbol, 'IDEA-EQ');
      expect((await scrips.findBySymbol('SBIN-EQ'))!.token, '3045');
      expect((await scrips.findBySymbol('SBIN-EQ', exchange: 'BSE')), isNull);
      expect(await scrips.findByToken('does-not-exist'), isNull);
    });

    test('search matches name and symbol, shortest symbol first', () async {
      await scrips.replaceAll(sample);
      expect((await scrips.search('delhivery')).single.token, '543529');
      expect(await scrips.search('zzz'), isEmpty);
      expect((await scrips.search('idea')).single.name, 'VODAFONE IDEA LIMITED');
    });

    test('tick sizes survive the round trip (paise → rupees)', () async {
      await scrips.replaceAll([
        Scrip.fromScripMaster(const {
          'token': '3045',
          'symbol': 'SBIN-EQ',
          'name': 'STATE BANK OF INDIA',
          'exch_seg': 'NSE',
          'tick_size': '5.000000',
        }),
      ]);
      final scrip = (await scrips.allEquities()).single;
      expect(scrip.tickSize, closeTo(0.05, 1e-9));
    });
  });

  // -------------------------------------------------------------------------
  group('ScanCacheDao', () {
    test('saves and reloads a scan run for a given day', () async {
      await cache.saveRun(
        kind: ScanKind.ipoProximity,
        asOf: '2025-09-29',
        rows: [
          {'symbol': 'IDEA', 'ltp': 24.1, 'level': 'high'},
          {'symbol': 'NYKAA', 'ltp': 1730.5, 'level': 'low'},
        ],
      );

      final run = (await cache.latestRun(ScanKind.ipoProximity))!;
      expect(run.asOf, '2025-09-29');
      expect(run.rowCount, 2);
      expect(run.rows.first['symbol'], 'IDEA');
      expect(run.rows[1]['ltp'], 1730.5);
    });

    test('a re-run of the same day replaces the earlier snapshot', () async {
      await cache.saveRun(kind: ScanKind.ipoProximity, asOf: '2025-09-29', rows: [
        {'symbol': 'OLD'},
      ]);
      await cache.saveRun(kind: ScanKind.ipoProximity, asOf: '2025-09-29', rows: [
        {'symbol': 'NEW'},
      ]);
      expect((await cache.latestRun(ScanKind.ipoProximity))!.rows.single['symbol'], 'NEW');
    });

    test('kinds do not collide (IPO vs Golden Cross caches)', () async {
      await cache.saveRun(kind: ScanKind.ipoProximity, asOf: '2025-09-29', rows: [{'a': 1}]);
      await cache.saveRun(kind: ScanKind.goldenCross, asOf: '2025-09-29', rows: [{'b': 2}]);
      expect((await cache.latestRun(ScanKind.ipoProximity))!.rows.single['a'], 1);
      expect((await cache.latestRun(ScanKind.goldenCross))!.rows.single['b'], 2);
    });

    test('price cache round-trips and marks values as not-live', () async {
      final asOf = DateTime(2025, 9, 29, 15, 30);
      await cache.savePrices({
        'NSE:IDEA': PricedValue(value: 24.1, asOf: asOf, changePct: -1.2, isLive: true),
        'BSE:DELHIVERY': PricedValue(value: 500.25, asOf: asOf),
      });

      final loaded = await cache.loadPrices();
      expect(loaded.length, 2);
      expect(loaded['NSE:IDEA']!.value, closeTo(24.1, 1e-9));
      expect(loaded['NSE:IDEA']!.changePct, closeTo(-1.2, 1e-9));
      expect(loaded['NSE:IDEA']!.isLive, isFalse, reason: 'cache is never "live"');
      expect(await cache.lastPriceTimestamp(), asOf);
    });
  });
}
