import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/magic_basket_dao.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('MagicBasketDao', () {
    late AppDatabase db;
    late MagicBasketDao dao;

    setUpAll(() {
      sqfliteFfiInit();
      databaseFactory = databaseFactoryFfi;
    });

    setUp(() async {
      AppDatabase.overridePath = inMemoryDatabasePath;
      await AppDatabase.instance.close();
      db = AppDatabase.instance;
      dao = MagicBasketDao(db);
    });

    tearDown(() async {
      await AppDatabase.instance.close();
      AppDatabase.overridePath = null;
    });

    test('create/list/rename/delete baskets', () async {
      final a = await dao.createBasket('Long term');
      final b = await dao.createBasket('Banks');
      expect(a.id, isNot(b.id));

      var all = await dao.allBaskets();
      expect(all.map((e) => e.name), ['Long term', 'Banks']);

      await dao.renameBasket(a.id, 'Long term v2');
      all = await dao.allBaskets();
      expect(all.first.name, 'Long term v2');

      await dao.deleteBasket(a.id);
      all = await dao.allBaskets();
      expect(all.map((e) => e.name), ['Banks']);
    });

    test('items are unique per basket+exchange+symbol and cascade on delete', () async {
      final basket = await dao.createBasket('Mixed');
      final added = await dao.addItem(
        MagicBasketItem(
          id: 0,
          basketId: basket.id,
          symbol: 'SBILIFE',
          exchange: 'NSE',
          companyName: 'SBI Life Insurance Company Ltd',
          isin: 'INE123W01016',
          addedAt: 1,
        ),
      );
      expect(added, isTrue);

      // Duplicate is ignored, not double-added.
      final dup = await dao.addItem(
        MagicBasketItem(
          id: 0,
          basketId: basket.id,
          symbol: 'SBILIFE',
          exchange: 'NSE',
          companyName: 'SBI Life Insurance Company Ltd',
          addedAt: 2,
        ),
      );
      expect(dup, isFalse);

      // Same company on the other exchange is a separate row.
      final bse = await dao.addItem(
        MagicBasketItem(
          id: 0,
          basketId: basket.id,
          symbol: '540719',
          exchange: 'BSE',
          companyName: 'SBI Life Insurance Company Ltd',
          isin: 'INE123W01016',
          scripCode: '540719',
          addedAt: 3,
        ),
      );
      expect(bse, isTrue);

      var items = await dao.items(basket.id);
      expect(items.length, 2);

      final counted = await dao.basket(basket.id);
      expect(counted!.itemCount, 2);

      await dao.removeItem(items.first.id);
      items = await dao.items(basket.id);
      expect(items.length, 1);

      await dao.deleteBasket(basket.id);
      items = await dao.items(basket.id);
      expect(items, isEmpty);
    });

    test('toCandidate carries the identity the scan pipeline needs', () {
      final nse = const MagicBasketItem(
        id: 1,
        basketId: 1,
        symbol: 'SBILIFE',
        exchange: 'NSE',
        companyName: 'SBI Life Insurance Company Ltd',
        isin: 'INE123W01016',
        addedAt: 1,
      ).toCandidate();
      expect(nse.symbol, 'SBILIFE');
      expect(nse.dataSymbol, 'SBILIFE');
      expect(nse.isin, 'INE123W01016');
      expect(nse.exchange, 'NSE');

      final bse = const MagicBasketItem(
        id: 2,
        basketId: 1,
        symbol: '540719',
        exchange: 'BSE',
        companyName: 'SBI Life Insurance Company Ltd',
        isin: 'INE123W01016',
        scripCode: '540719',
        addedAt: 1,
      ).toCandidate();
      // BSE rows resolve through the scrip code carried in the data symbol.
      expect(bse.symbol, '540719');
      expect(bse.dataSymbol, '540719');
      expect(bse.exchange, 'BSE');

      // The shape that once broke every basket-added BSE row: the plain
      // ticker as symbol with the six-digit code in [scripCode] — the code
      // must still reach the pipeline.
      final tickerRow = const MagicBasketItem(
        id: 3,
        basketId: 1,
        symbol: 'SIEMENS',
        exchange: 'BSE',
        companyName: 'Siemens Limited',
        scripCode: '500550',
        addedAt: 1,
      ).toCandidate();
      expect(tickerRow.symbol, 'SIEMENS');
      expect(tickerRow.dataSymbol, '500550');
    });
  });
}
