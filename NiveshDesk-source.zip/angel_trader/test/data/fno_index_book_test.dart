// 1.5.84 — Data Sync card ka data layer: option book me index contracts
// (BANKNIFTY/BANKEX) ka count + expiries. In-memory SQLite par.

import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/fno_contract_dao.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

FnoContract c({
  required String underlying,
  required DateTime expiry,
  required double strike,
  required String type,
  required String token,
}) =>
    FnoContract(
      underlying: underlying,
      expiryLabel: '26NOV2026',
      expiryDate: expiry,
      strike: strike,
      optionType: type,
      token: token,
      symbol: '${underlying}26NOV${strike.toInt()}$type',
      lotSize: 30,
    );

void main() {
  late FnoContractDao dao;

  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close();
    dao = FnoContractDao(AppDatabase.instance);
  });

  tearDown(() async {
    await AppDatabase.instance.close();
  });

  test('countFor — index contracts ka count (Data Sync card isse dikhata hai)',
      () async {
    final expiry = DateTime(2026, 11, 26);
    await dao.replaceAll([
      c(underlying: 'BANKNIFTY', expiry: expiry, strike: 60100, type: 'CE', token: '1'),
      c(underlying: 'BANKNIFTY', expiry: expiry, strike: 60100, type: 'PE', token: '2'),
      c(underlying: 'BANKEX', expiry: expiry, strike: 62300, type: 'CE', token: '3'),
      c(underlying: 'RELIANCE', expiry: expiry, strike: 3000, type: 'CE', token: '4'),
    ]);

    expect(await dao.countFor('BANKNIFTY'), 2);
    expect(await dao.countFor('BANKEX'), 1);
    expect(await dao.countFor('RELIANCE'), 1);
    // Case-insensitive — screen uppercase bhejta hai, par safe rahe.
    expect(await dao.countFor('bankex'), 1);
  });

  test('countFor — book khaali ho to 0 (card "BOOK KHAALI" dikhata hai)',
      () async {
    expect(await dao.countFor('BANKNIFTY'), 0);
    expect(await dao.countFor('BANKEX'), 0);
  });

  test('replaceAll ke baad index expiries milti hain (loader ka pehla gate)',
      () async {
    await dao.replaceAll([
      c(underlying: 'BANKEX', expiry: DateTime(2026, 11, 26), strike: 62300, type: 'CE', token: '9'),
    ]);
    final expiries = await dao.expiries('BANKEX', from: DateTime(2026, 11, 1));
    expect(expiries, hasLength(1));
    expect(expiries.first, DateTime(2026, 11, 26));
  });
}
