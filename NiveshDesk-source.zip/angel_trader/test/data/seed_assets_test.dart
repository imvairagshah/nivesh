// Seed-asset integration tests.
//
// These read the two files that ship inside the app bundle and check them
// against the real Angel One instrument tokens:
//   assets/data/ipos.csv          — mainboard IPOs listed after 1 Jan 2015
//   assets/data/scrip_master.json — starter symbol ➜ token map
//
// They are the reason the app can resolve a ticker on first launch, before the
// ~50 MB daily master download finishes, so a typo here would break the screener
// for every new user.

import 'dart:convert';
import 'dart:io';

import 'package:angel_trader/core/utils/csv_io.dart';
import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/models/ipo.dart';
import 'package:angel_trader/services/token_resolver.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('assets/data/ipos.csv', () {
    late List<Ipo> rows;

    setUpAll(() {
      final file = File('assets/data/ipos.csv');
      expect(file.existsSync(), isTrue,
          reason: 'Seed CSV must be present at assets/data/ipos.csv');
      final records = CsvCodec.parseRecords(file.readAsStringSync());
      rows = [
        for (var i = 0; i < records.length; i++)
          Ipo.fromCsvRecord(records[i], lineNumber: i + 2),
      ];
    });

    test('carries every mainboard IPO since 2015, not just a starter set', () {
      // 2015-2026 saw ~550 mainboard listings; anything far below that means the
      // master shrank back to a hand-picked sample.
      expect(rows.length, greaterThanOrEqualTo(500));
      final years = rows.map((r) => r.listingDate.year).toSet();
      expect(years, containsAll([2015, 2016, 2020, 2021, 2024, 2025]));
    });

    test('every row parses and validates (levels are optional)', () {
      var withLevels = 0;
      for (final ipo in rows) {
        expect(ipo.validate(requireLevels: false), isEmpty,
            reason: 'Invalid row for ${ipo.symbol}');
        if (ipo.hasLevels) {
          withLevels++;
          expect(ipo.levelsSource, 'seed',
              reason: '${ipo.symbol}: shipped levels must be marked as verified');
        } else {
          expect(ipo.levelsSource, '',
              reason: '${ipo.symbol}: a level-less row must be pending, not seed');
        }
      }
      // The master ships complete: listing-day high/low for (almost) every row
      // were pre-filled from NSE's daily bhavcopy of each listing date, so the
      // app only ever has to fetch the handful that a bhavcopy could not answer
      // (BSE-first listings — the app fills those from the broker at runtime).
      expect(withLevels, greaterThanOrEqualTo(500),
          reason: 'the shipped master must carry listing levels, not blanks');
      expect(rows.length - withLevels, lessThanOrEqualTo(20),
          reason: 'only a small tail may depend on a runtime fetch');
    });

    test('every row carries a valid ISIN — the identity that survives a rename',
        () {
      // The ticker is only a label: the exchange can change it at any time
      // (LTIM → LTM, AMIORG → ACUTAAS). The ISIN cannot change, and it is what
      // the app uses to repair a renamed row automatically. So every shipped row
      // must have one, or that row becomes unfixable the day its company
      // renames itself.
      final missing = <String>[];
      final malformed = <String>[];
      for (final ipo in rows) {
        if (ipo.isin.isEmpty) {
          missing.add(ipo.symbol);
        } else if (!Ipo.isValidIsin(ipo.isin)) {
          malformed.add('${ipo.symbol}: ${ipo.isin}');
        }
      }
      expect(missing, isEmpty, reason: 'rows without an ISIN: $missing');
      expect(malformed, isEmpty, reason: 'rows with a malformed ISIN: $malformed');
    });

    test('every listing date is after 1 Jan 2015 (database scope)', () {
      for (final ipo in rows) {
        expect(
          ipo.listingDate.isAfter(DateTime(2015, 1, 1)),
          isTrue,
          reason: '${ipo.symbol} listed ${ipo.listingDate}',
        );
      }
    });

    test('no duplicate (symbol, exchange) rows — the DB has a unique index', () {
      final keys = rows.map((r) => '${r.exchange.code}:${r.symbol}').toList();
      expect(keys.toSet().length, keys.length);
    });

    test('listing low never exceeds listing high', () {
      for (final ipo in rows.where((r) => r.hasLevels)) {
        expect(ipo.listingLow, lessThanOrEqualTo(ipo.listingHigh),
            reason: '${ipo.symbol}');
      }
    });

    test('symbols look like NSE/BSE tickers (no -EQ suffix, no exchange prefix)', () {
      for (final ipo in rows) {
        expect(ipo.symbol, matches(RegExp(r'^[A-Z0-9&\-]{1,20}$')),
            reason: '${ipo.symbol} is not a clean ticker');
        expect(ipo.symbol.contains(':'), isFalse);
        expect(ipo.symbol.endsWith('-EQ'), isFalse);
      }
    });

    test('carries the honest verification note on approximate rows', () {
      // Rows whose listing-day range could not be confirmed from an exchange
      // source say so in Notes, and the app shows Notes in the detail sheet.
      final approximate = rows.where((r) => r.notes.contains('approximate'));
      expect(approximate, isNotEmpty,
          reason: 'Unverified rows must be labelled');
    });
  });

  group('assets/data/scrip_master.json', () {
    late TokenResolver resolver;
    late List<Map<String, dynamic>> rawRows;

    setUpAll(() {
      final file = File('assets/data/scrip_master.json');
      expect(file.existsSync(), isTrue);
      final decoded = jsonDecode(file.readAsStringSync());
      expect(decoded, isA<List<dynamic>>());
      rawRows = decoded.cast<Map<String, dynamic>>();
      resolver = TokenResolver.fromRows(rawRows);
    });

    test('holds real equity rows for both exchanges', () {
      expect(resolver.size, greaterThan(50));
      final exchanges =
          resolver.all.map((s) => s.exchange).toSet();
      expect(exchanges, containsAll([Exchange.nse, Exchange.bse]));
    });

    test('resolves well-known tokens that the SmartAPI docs publish', () {
      expect(resolver.resolve('SBIN').token, '3045');
      expect(resolver.resolve('RELIANCE').token, '2885');
    });

    test('the marquee rows resolve against the bundled starter master', () {
      // The master is a universe, so the bundled 122-token sample can only ever
      // resolve a slice of it — everything else arrives with the daily master
      // download. What must hold offline on first launch is that the marquee
      // names (the ones a new user checks first) already work.
      const mustResolveOffline = <String>[
        'NYKAA', 'PAYTM', 'POLICYBZR', 'ETERNAL', 'IRCTC', 'HAL', 'IREDA',
        'HONASA', 'LODHA', 'CAMS', 'ICICIPRULI', 'SBILIFE', 'ICICIGI',
        'TATATECH', 'BAJAJHFL', 'LICI', 'JIOFIN',
      ];
      final records = CsvCodec.parseRecords(
        File('assets/data/ipos.csv').readAsStringSync(),
      );
      final shipped = {
        for (final record in records) Ipo.fromCsvRecord(record).symbol.toUpperCase(),
      };
      final unresolved = <String>[];
      for (final symbol in mustResolveOffline) {
        if (!shipped.contains(symbol)) {
          unresolved.add('$symbol (missing from the master)');
          continue;
        }
        final resolution = resolver.resolve(symbol);
        if (!resolution.isResolved) unresolved.add(symbol);
      }
      expect(unresolved, isEmpty,
          reason: 'Marquee rows must resolve offline: $unresolved');
    });

    test('cross-exchange lookup works (BSE row for the same ticker)', () {
      final resolution =
          resolver.resolve('NYKAA', preferredExchange: Exchange.bse);
      expect(resolution.isResolved, isTrue);
      expect(resolution.scrip!.exchange, Exchange.bse);
    });

    test('tick sizes convert from paise to rupees sanely', () {
      for (final scrip in resolver.all) {
        expect(scrip.tickSize, greaterThanOrEqualTo(0.01));
        expect(scrip.tickSize, lessThanOrEqualTo(10));
      }
    });

    test('tokens are unique across the starter master', () {
      final tokens = resolver.all.map((s) => s.token).toList();
      expect(tokens.toSet().length, tokens.length);
    });
  });
}
