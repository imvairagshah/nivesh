// Trade-group tests — the "group selection + group-wise P&L" requirement.
//
// Runs the real schema and real SQL: create/rename/archive/delete groups, then
// check that realised P&L, win rate and monthly buckets aggregate correctly per
// group (including the implicit Ungrouped bucket).
//
// The monthly bucketing test deliberately uses an IST edge case: a trade at
// 02:00 IST on 1 Oct is 20:30 UTC on 30 Sep, and must be reported in October.

import 'dart:io';

import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/trade_group_dao.dart';
import 'package:angel_trader/data/local/models/ipo.dart';
import 'package:angel_trader/data/local/models/paper_trade.dart';
import 'package:angel_trader/data/local/models/trade_group.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

/// Inserts a closing-leg trade (one that carries realised P&L).
Future<void> _closingTrade(
  AppDatabase db, {
  required int? groupId,
  required double pnl,
  required DateTime executedAt,
  String symbol = 'SBIN',
}) async {
  final sqlite = await db.database;
  await sqlite.insert(AppDatabase.tableTrades, {
    'symbol': symbol,
    'exchange': 'NSE',
    'token': '3045',
    'side': 'SELL',
    'quantity': 10,
    'price': 100.0,
    'order_type': 'MARKET',
    'group_id': groupId,
    'realized_pnl': pnl,
    'charges': 0.0,
    'executed_at': executedAt.millisecondsSinceEpoch,
    'note': '',
  });
}

Future<void> _openPosition(
  AppDatabase db, {
  required int? groupId,
  int quantity = 10,
  double avgPrice = 100,
  String status = 'OPEN',
}) async {
  final sqlite = await db.database;
  await sqlite.insert(AppDatabase.tablePositions, {
    'symbol': 'SBIN',
    'exchange': 'NSE',
    'token': '3045',
    'quantity': quantity,
    'avg_price': avgPrice,
    'stop_loss': null,
    'target': null,
    'group_id': groupId,
    'opened_at': DateTime(2025, 9, 1).millisecondsSinceEpoch,
    'closed_at': null,
    'status': status,
  });
}

void main() {
  late AppDatabase db;
  late TradeGroupDao dao;

  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close();
    db = AppDatabase.instance;
    dao = TradeGroupDao(db);
  });

  tearDown(() async => db.close());

  // -------------------------------------------------------------------------
  group('creating and managing groups (pre-add so names are never retyped)', () {
    test('creates a group and reads it back alphabetically', () async {
      await dao.createNamed('Momentum');
      await dao.createNamed('IPO base');
      await dao.createNamed('Results play');

      final groups = await dao.all();
      expect(groups.map((g) => g.name).toList(),
          ['IPO base', 'Momentum', 'Results play']);
    });

    test('auto-assigns distinct palette colours to consecutive groups', () async {
      for (final name in ['A group', 'B group', 'C group']) {
        await dao.createNamed(name);
      }
      final colours = (await dao.all()).map((g) => g.colorIndex).toList();
      expect(colours, [0, 1, 2]);
    });

    test('duplicate names are rejected case-insensitively', () async {
      await dao.createNamed('Momentum');
      expect(
        () => dao.createNamed('momentum'),
        throwsA(isA<ArgumentError>()),
      );
      expect(await dao.all(), hasLength(1));
    });

    test('reserved and invalid names are rejected', () async {
      expect(() => dao.createNamed('Ungrouped'), throwsA(isA<ArgumentError>()));
      expect(() => dao.createNamed('   '), throwsA(isA<ArgumentError>()));
      expect(() => dao.createNamed('x' * 40), throwsA(isA<ArgumentError>()));
    });

    test('rename works, but not onto another group name', () async {
      final momentum = await dao.createNamed('Momentum');
      await dao.createNamed('Swing');

      await dao.update(momentum.copyWith(name: 'Momentum trades'));
      expect((await dao.byId(momentum.id!))!.name, 'Momentum trades');

      expect(
        () => dao.update(momentum.copyWith(name: 'swing')),
        throwsA(isA<ArgumentError>()),
      );
    });

    test('byUsage puts frequently used groups first (picker order)', () async {
      final rarely = await dao.createNamed('Rarely');
      final often = await dao.createNamed('Often');
      for (var i = 0; i < 3; i++) {
        await _closingTrade(db, groupId: often.id, pnl: 100, executedAt: DateTime(2025, 9, i + 1));
      }
      await _closingTrade(db, groupId: rarely.id, pnl: 10, executedAt: DateTime(2025, 9, 5));

      final ordered = await dao.byUsage();
      expect(ordered.first.name, 'Often');
      expect(ordered.last.name, 'Rarely');
    });

    test('archiving hides a group from the picker but keeps its history', () async {
      final group = await dao.createNamed('Old idea');
      await _closingTrade(db, groupId: group.id, pnl: 500, executedAt: DateTime(2025, 9, 10));

      await dao.archive(group.id!);

      expect(await dao.all(), isEmpty);
      expect((await dao.all(includeArchived: true)).single.archived, isTrue);
      // P&L is still reported.
      final summary = (await dao.realizedByGroup()).single;
      expect(summary.groupName, 'Old idea');
      expect(summary.realizedPnl, 500);
    });

    test('delete reassigns trades to another group instead of losing them', () async {
      final keeper = await dao.createNamed('Keeper');
      final doomed = await dao.createNamed('Doomed');
      await _closingTrade(db, groupId: doomed.id, pnl: 250, executedAt: DateTime(2025, 9, 10));
      await _openPosition(db, groupId: doomed.id);

      final moved = await dao.delete(doomed.id!, reassignTo: keeper.id);
      expect(moved.trades, 1);
      expect(moved.positions, 1);

      final summary = (await dao.realizedByGroup()).single;
      expect(summary.groupName, 'Keeper');
      expect(summary.realizedPnl, 250);
      expect(summary.openPositionCount, 1);
    });

    test('delete with no target moves history to Ungrouped', () async {
      final group = await dao.createNamed('Temporary');
      await _closingTrade(db, groupId: group.id, pnl: -120, executedAt: DateTime(2025, 9, 10));

      await dao.delete(group.id!);

      final summary = (await dao.realizedByGroup()).single;
      expect(summary.groupId, isNull);
      expect(summary.groupName, kUngroupedLabel);
      expect(summary.realizedPnl, -120);
    });

    test('usageCount reports what a delete would move', () async {
      final group = await dao.createNamed('Busy');
      await _closingTrade(db, groupId: group.id, pnl: 10, executedAt: DateTime(2025, 9, 1));
      await _closingTrade(db, groupId: group.id, pnl: 20, executedAt: DateTime(2025, 9, 2));
      await _openPosition(db, groupId: group.id);

      final usage = await dao.usageCount(group.id!);
      expect(usage.trades, 2);
      expect(usage.positions, 1);
    });
  });

  // -------------------------------------------------------------------------
  group('group-wise P&L (Reports → By group)', () {
    setUp(() async {
      // Momentum: two winners, one loser.
      final momentum = await dao.createNamed('Momentum');
      await _closingTrade(db, groupId: momentum.id, pnl: 1200, executedAt: DateTime(2025, 8, 5));
      await _closingTrade(db, groupId: momentum.id, pnl: 800, executedAt: DateTime(2025, 9, 8));
      await _closingTrade(db, groupId: momentum.id, pnl: -400, executedAt: DateTime(2025, 9, 9));
      await _openPosition(db, groupId: momentum.id, quantity: 50, avgPrice: 200);

      // IPO base: one loss, one open position.
      final ipo = await dao.createNamed('IPO base');
      await _closingTrade(db, groupId: ipo.id, pnl: -600, executedAt: DateTime(2025, 9, 12));
      await _openPosition(db, groupId: ipo.id, quantity: 10, avgPrice: 1000);

      // One trade with no group at all.
      await _closingTrade(db, groupId: null, pnl: 300, executedAt: DateTime(2025, 9, 15));
    });

    test('aggregates realised P&L, win rate and best/worst per group', () async {
      final summaries = await dao.realizedByGroup();
      final byName = {for (final s in summaries) s.groupName: s};

      final momentum = byName['Momentum']!;
      expect(momentum.realizedPnl, closeTo(1600, 1e-9)); // 1200 + 800 - 400
      expect(momentum.closedTrades, 3);
      expect(momentum.wins, 2);
      expect(momentum.losses, 1);
      expect(momentum.winRate, closeTo(66.67, 0.01));
      expect(momentum.biggestWin, 1200);
      expect(momentum.biggestLoss, -400);
      expect(momentum.averageWin, closeTo(1000, 1e-9)); // (1200+800)/2
      expect(momentum.averageLoss, closeTo(400, 1e-9));
      expect(momentum.profitFactor, closeTo(2000 / 400, 1e-9));
      expect(momentum.openPositionCount, 1);
      expect(momentum.openInvestedValue, closeTo(50 * 200, 1e-9));

      final ipo = byName['IPO base']!;
      expect(ipo.realizedPnl, closeTo(-600, 1e-9));
      expect(ipo.wins, 0);
      expect(ipo.winRate, 0);
      expect(ipo.openInvestedValue, closeTo(10000, 1e-9));

      final ungrouped = byName[kUngroupedLabel]!;
      expect(ungrouped.groupId, isNull);
      expect(ungrouped.realizedPnl, 300);

      // Sorted by realised P&L, best first.
      expect(summaries.first.groupName, 'Momentum');
    });

    test('a date window narrows the realised figures', () async {
      final august = await dao.realizedByGroup(
        from: DateTime(2025, 8, 1),
        to: DateTime(2025, 8, 31, 23, 59),
      );
      expect(august, hasLength(1));
      expect(august.single.groupName, 'Momentum');
      expect(august.single.realizedPnl, closeTo(1200, 1e-9));
    });

    test('openExposureByGroup lists baskets that have no realised P&L yet', () async {
      final fresh = await dao.createNamed('Fresh basket');
      await _openPosition(db, groupId: fresh.id, quantity: 5, avgPrice: 300);

      final exposure = await dao.openExposureByGroup();
      final freshRow = exposure.firstWhere((e) => e.groupName == 'Fresh basket');
      expect(freshRow.openInvestedValue, closeTo(1500, 1e-9));
      expect(freshRow.openPositionCount, 1);
      expect(freshRow.realizedPnl, 0);

      // Closed positions are not exposure.
      expect(
        exposure.map((e) => e.groupName).toSet(),
        isNot(contains('nothing')),
      );
    });

    test('monthlyByGroup splits months and keeps IST month boundaries', () async {
      // 1 Oct 2025, 02:00 IST == 30 Sep 2025, 20:30 UTC.
      // It must be reported in October, not September.
      final momentum = (await dao.all()).firstWhere((g) => g.name == 'Momentum');
      final istTwoAm = DateTime.utc(2025, 9, 30, 20, 30);
      await _closingTrade(db, groupId: momentum.id, pnl: 500, executedAt: istTwoAm);

      final rows = await dao.monthlyByGroup();
      final october = rows.where((r) => r.monthKey == '2025-10').toList();
      expect(october, hasLength(1));
      expect(october.single.groupName, 'Momentum');
      expect(october.single.realizedPnl, 500);

      // August holds only Momentum's 1200; September holds 800 - 400 - 600 + 300.
      final august = rows.firstWhere((r) => r.monthKey == '2025-08');
      expect(august.realizedPnl, closeTo(1200, 1e-9));

      final september = rows.where((r) => r.monthKey == '2025-09').toList();
      final septemberTotal =
          september.fold<double>(0, (sum, r) => sum + r.realizedPnl);
      expect(septemberTotal, closeTo(800 - 400 - 600 + 300, 1e-9));
      // …and September is split by group, not lumped together.
      expect(september.map((r) => r.groupName).toSet(),
          {'Momentum', 'IPO base', kUngroupedLabel});
    });

    test('monthlyByGroup can exclude the Ungrouped bucket', () async {
      final rows = await dao.monthlyByGroup(includeUngrouped: false);
      expect(rows.any((r) => r.groupName == kUngroupedLabel), isFalse);
    });
  });

  // -------------------------------------------------------------------------
  group('schema migration v1 → v5', () {
    test('adds group support, the order book and levels, keeping existing rows',
        () async {
      // Build a database exactly as the previous build (v1) would have left it:
      // paper-trading tables, but no group support at all.
      final dir = Directory('${await getDatabasesPath()}/migration')
        ..createSync(recursive: true);
      final path = '${dir.path}/v1.db';
      await databaseFactory.deleteDatabase(path);

      final v1 = await databaseFactory.openDatabase(
        path,
        options: OpenDatabaseOptions(
          version: 1,
          onCreate: (db, _) async {
            await db.execute('''
              CREATE TABLE trades (
                id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL,
                exchange TEXT NOT NULL DEFAULT 'NSE', token TEXT NOT NULL DEFAULT '',
                side TEXT NOT NULL, quantity INTEGER NOT NULL, price REAL NOT NULL,
                order_type TEXT NOT NULL DEFAULT 'MARKET', position_id INTEGER,
                realized_pnl REAL, charges REAL NOT NULL DEFAULT 0,
                executed_at INTEGER NOT NULL, note TEXT NOT NULL DEFAULT ''
              )''');
            await db.execute('''
              CREATE TABLE positions (
                id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL,
                exchange TEXT NOT NULL DEFAULT 'NSE', token TEXT NOT NULL DEFAULT '',
                quantity INTEGER NOT NULL, avg_price REAL NOT NULL,
                stop_loss REAL, target REAL, opened_at INTEGER NOT NULL,
                closed_at INTEGER, status TEXT NOT NULL DEFAULT 'OPEN'
              )''');
            // v1 also shipped the IPO database (Feature 1) — without the
            // levels_source column that v4 adds.
            await db.execute('''
              CREATE TABLE ipos (
                id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL,
                company_name TEXT NOT NULL DEFAULT '', exchange TEXT NOT NULL DEFAULT 'NSE',
                listing_date TEXT NOT NULL, listing_high REAL NOT NULL, listing_low REAL NOT NULL,
                sector TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '',
                is_custom INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL DEFAULT 0
              )''');
            await db.execute(
                'CREATE UNIQUE INDEX idx_ipos_symbol ON ipos(symbol, exchange)');
          },
        ),
      );
      await v1.insert('trades', {
        'symbol': 'SBIN',
        'side': 'SELL',
        'quantity': 5,
        'price': 100.0,
        'executed_at': DateTime(2025, 9, 1).millisecondsSinceEpoch,
      });
      await v1.insert('ipos', {
        'symbol': 'NYKAA',
        'company_name': 'FSN E Commerce Ventures Ltd',
        'listing_date': '2021-11-10',
        'listing_high': 2101.0,
        'listing_low': 1712.05,
      });
      await v1.close();

      // Now open the same file through the app database (current schema).
      AppDatabase.overridePath = path;
      await AppDatabase.instance.close();
      final upgraded = await AppDatabase.instance.database;

      expect(
        await upgraded.getVersion(),
        AppDatabase.schemaVersion,
        reason: 'schema must be upgraded to the current version',
      );

      // ---- v2 brought trade groups
      final tradeColumns = await upgraded.rawQuery('PRAGMA table_info(trades)');
      expect(tradeColumns.map((c) => c['name']), contains('group_id'));

      final positionColumns = await upgraded.rawQuery('PRAGMA table_info(positions)');
      expect(positionColumns.map((c) => c['name']), contains('group_id'));

      // ---- v3 brought the paper-order book and per-position opening charges
      expect(positionColumns.map((c) => c['name']), contains('charges_paid'));
      // ---- v4 lets a row live without listing-day levels
      final ipoColumns = await upgraded.rawQuery('PRAGMA table_info(ipos)');
      expect(
        ipoColumns.map((c) => c['name']),
        containsAll(['levels_source', 'isin']),
      );
      // v5 adds identity: a legacy row has no ISIN until a master supplies one,
      // and the column must default to an empty string rather than null.
      final legacyIdentity = Ipo.fromDb((await upgraded.query('ipos')).first);
      expect(legacyIdentity.isin, '');
      final legacyIpo = Ipo.fromDb((await upgraded.query('ipos')).first);
      expect(legacyIpo.hasLevels, isTrue);
      expect(legacyIpo.levelsSource, 'seed',
          reason: 'a pre-v4 row with levels is treated as verified data');
      final orderColumns = await upgraded.rawQuery('PRAGMA table_info(paper_orders)');
      expect(
        orderColumns.map((c) => c['name']),
        containsAll(['limit_price', 'status', 'filled_price', 'group_id']),
      );

      // ---- v8 brought the earnings calendar, v9 the long/short flag
      final sideColumns = await upgraded.rawQuery('PRAGMA table_info(positions)');
      expect(
        sideColumns.map((c) => c['name']),
        contains('side'),
        reason: 'v9 adds the long/short direction to the position book',
      );
      expect(await upgraded.query('earnings', limit: 1), isEmpty);

      // A trade written before the upgrade still reads back with sane defaults.
      final migrated = Trade.fromDb((await upgraded.query('trades')).first);
      expect(migrated.groupId, isNull); // → Ungrouped
      expect(migrated.orderType, PaperOrderType.market);

      // The old row survived and the new table is usable.
      expect(await upgraded.query('trades'), hasLength(1));
      final group = await TradeGroupDao(AppDatabase.instance).createNamed('Momentum');
      expect(group.id, isNotNull);
      expect(group.name, 'Momentum');

      await AppDatabase.instance.close();
      AppDatabase.overridePath = inMemoryDatabasePath;
    });
  });

  // -------------------------------------------------------------------------
  group('TradeGroup model', () {
    test('suggestColorIndex cycles the palette', () {
      expect(TradeGroup.suggestColorIndex(0), 0);
      expect(TradeGroup.suggestColorIndex(7), 7);
      expect(TradeGroup.suggestColorIndex(8), 0);
    });

    test('validateName catches empty, long and reserved names', () {
      expect(TradeGroup.validateName('Momentum'), isEmpty);
      expect(TradeGroup.validateName(''), isNotEmpty);
      expect(TradeGroup.validateName('  '), isNotEmpty);
      expect(TradeGroup.validateName('x' * 25), isNotEmpty);
      expect(TradeGroup.validateName('ungrouped'), isNotEmpty);
    });

    test('round-trips through SQLite', () async {
      final created = await dao.createNamed('Round trip', notes: 'note');
      final loaded = (await dao.byId(created.id!))!;
      expect(loaded.name, 'Round trip');
      expect(loaded.notes, 'note');
      expect(loaded.archived, isFalse);
      expect(loaded.createdAt.year, greaterThanOrEqualTo(2024));
    });
  });
}
