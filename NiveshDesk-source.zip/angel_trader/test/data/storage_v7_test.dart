// Storage diet (schema v7) — the drop-in columns, the derived expiry label and
// the migration from a version-6 database.
//
// Why this file exists: 1.5.4 removes three columns that cost ~0.8 MB on a full
// option book (`trading_symbol` — a byte-for-byte copy of `symbol`,
// `expiry_label` — a pure function of `expiry_date`, and the write-only
// `scrips.updated_at`). A migration that loses data would be much worse than
// the megabytes it saves, so the upgrade path is tested, not assumed.

import 'dart:io';

import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/fno_contract_dao.dart';
import 'package:angel_trader/data/local/dao/scrip_dao.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

/// The v6 table definitions, exactly as the shipped 1.5.3 build created them.
const _v6FnoContracts = '''
CREATE TABLE fno_contracts (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  underlying     TEXT    NOT NULL,
  expiry_label   TEXT    NOT NULL,
  expiry_date    TEXT    NOT NULL,
  strike         REAL    NOT NULL,
  option_type    TEXT    NOT NULL,
  token          TEXT    NOT NULL,
  symbol         TEXT    NOT NULL DEFAULT '',
  lot_size       INTEGER NOT NULL DEFAULT 0,
  trading_symbol TEXT    NOT NULL DEFAULT ''
)
''';

const _v6Scrips = '''
CREATE TABLE scrips (
  token      TEXT PRIMARY KEY,
  symbol     TEXT NOT NULL,
  name       TEXT NOT NULL DEFAULT '',
  exchange   TEXT NOT NULL,
  tick_size  REAL NOT NULL DEFAULT 0.05,
  updated_at INTEGER NOT NULL DEFAULT 0
)
''';

void main() {
  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  // ---------------------------------------------------------------------
  // Fresh install: the new schema
  // ---------------------------------------------------------------------
  group('v7 schema', () {
    setUp(() async {
      AppDatabase.overridePath = inMemoryDatabasePath;
      await AppDatabase.instance.close();
    });

    tearDown(() async {
      await AppDatabase.instance.close();
      AppDatabase.overridePath = null;
    });

    test('the dropped columns are gone and the useful ones are not', () async {
      final db = await AppDatabase.instance.database;

      final contractCols = (await db.rawQuery('PRAGMA table_info(fno_contracts)'))
          .map((row) => row['name'] as String)
          .toSet();
      expect(
        contractCols,
        containsAll([
          'id', 'underlying', 'expiry_date', 'strike',
          'option_type', 'token', 'symbol', 'lot_size',
        ]),
      );
      expect(contractCols, isNot(contains('expiry_label')));
      expect(contractCols, isNot(contains('trading_symbol')));

      final scripCols = (await db.rawQuery('PRAGMA table_info(scrips)'))
          .map((row) => row['name'] as String)
          .toSet();
      expect(scripCols, containsAll(['token', 'symbol', 'name', 'exchange']));
      expect(scripCols, isNot(contains('updated_at')));
    });

    test('a contract round-trips, label reassembled byte-for-byte', () async {
      final dao = FnoContractDao(AppDatabase.instance);
      await dao.replaceAll([
        FnoContract(
          underlying: 'RELIANCE',
          expiryLabel: '26JAN2026',
          expiryDate: DateTime(2026, 1, 26),
          strike: 2650,
          optionType: 'CE',
          token: '12345',
          symbol: 'RELIANCE26JAN2650CE',
          lotSize: 500,
        ),
      ]);

      final chain = await dao.chainOn('RELIANCE', DateTime(2026, 1, 26));
      expect(chain, hasLength(1));
      // The greeks endpoint gets this string as `expirydate` — it must match
      // the broker's own label, not merely look similar.
      expect(chain.single.expiryLabel, '26JAN2026');
      expect(chain.single.symbol, 'RELIANCE26JAN2650CE');
      expect(chain.single.strike, 2650);
      expect(chain.single.lotSize, 500);
    });

    test('the ATM pair still resolves from the trimmed table', () async {
      final dao = FnoContractDao(AppDatabase.instance);
      await dao.replaceAll([
        FnoContract(
          underlying: 'INFY',
          expiryLabel: '24FEB2026',
          expiryDate: DateTime(2026, 2, 24),
          strike: 1800,
          optionType: 'CE',
          token: '1',
          symbol: 'INFY24FEB1800CE',
          lotSize: 400,
        ),
        FnoContract(
          underlying: 'INFY',
          expiryLabel: '24FEB2026',
          expiryDate: DateTime(2026, 2, 24),
          strike: 1800,
          optionType: 'PE',
          token: '2',
          symbol: 'INFY24FEB1800PE',
          lotSize: 400,
        ),
      ]);

      final pair = await dao.atmPair(
        underlying: 'INFY',
        spot: 1798,
        asOf: DateTime(2026, 2, 1),
      );
      expect(pair, isNotNull);
      expect(pair!.strike, 1800);
      expect(pair.expiryLabel, '24FEB2026');
      expect(pair.isComplete, isTrue);
    });

    test('labelFor pads the day and upper-cases the month', () {
      expect(FnoContract.labelFor(DateTime(2026, 1, 6)), '06JAN2026');
      expect(FnoContract.labelFor(DateTime(2026, 11, 26)), '26NOV2026');
      expect(FnoContract.labelFor(DateTime(2026, 10, 7)), '07OCT2026');
    });

    test('vacuum reports the bytes it freed, never a negative', () async {
      final freed = await AppDatabase.instance.vacuum();
      expect(freed, greaterThanOrEqualTo(0));
    });
  });

  // ---------------------------------------------------------------------
  // Upgrade path: a real 1.5.3 database opening on 1.5.4
  // ---------------------------------------------------------------------
  group('migration v6 → v7', () {
    late Directory dir;
    late String path;

    setUp(() async {
      dir = await Directory.systemTemp.createTemp('niveshdesk_v7');
      path = p.join(dir.path, 'angel_trader.db');
      AppDatabase.overridePath = path;
      await AppDatabase.instance.close();
    });

    tearDown(() async {
      await AppDatabase.instance.close();
      AppDatabase.overridePath = null;
      await dir.delete(recursive: true);
    });

    test('an existing book and scrip cache survive the upgrade', () async {
      final v6 = await databaseFactory.openDatabase(
        path,
        options: OpenDatabaseOptions(
          version: 6,
          onCreate: (db, version) async {
            await db.execute(_v6FnoContracts);
            await db.execute(_v6Scrips);
          },
        ),
      );
      await v6.insert('fno_contracts', {
        'underlying': 'RELIANCE',
        'expiry_label': '26JAN2026',
        'expiry_date': '2026-01-26',
        'strike': 2650.0,
        'option_type': 'CE',
        'token': '12345',
        'symbol': 'RELIANCE26JAN2650CE',
        'lot_size': 500,
        'trading_symbol': 'RELIANCE26JAN2650CE',
      });
      await v6.insert('scrips', {
        'token': '3045',
        'symbol': 'SBIN-EQ',
        'name': 'SBIN',
        'exchange': 'NSE',
        'tick_size': 0.05,
        'updated_at': 123,
      });
      await v6.close();

      // Opening through the app runs the v7 migration.
      final contracts = FnoContractDao(AppDatabase.instance);
      expect(await contracts.count(), 1);
      final chain = await contracts.chainOn('RELIANCE', DateTime(2026, 1, 26));
      expect(chain.single.symbol, 'RELIANCE26JAN2650CE');
      expect(chain.single.expiryLabel, '26JAN2026');
      expect(chain.single.strike, 2650);
      expect(chain.single.lotSize, 500);

      final scrips = ScripDao(AppDatabase.instance);
      expect(await scrips.count(), 1);

      final cols = (await (await AppDatabase.instance.database)
              .rawQuery('PRAGMA table_info(fno_contracts)'))
          .map((row) => row['name'] as String)
          .toSet();
      expect(cols, isNot(contains('trading_symbol')));
      expect(cols, isNot(contains('expiry_label')));
    });

    test('pruning a big book and compacting shrinks the file', () async {
      final dao = FnoContractDao(AppDatabase.instance);
      await dao.replaceAll([
        for (var i = 0; i < 4000; i++)
          FnoContract(
            underlying: 'STOCK${i % 50}',
            expiryLabel: '26JAN2026',
            expiryDate: DateTime(2026, 1, 26),
            strike: 100 + i.toDouble(),
            optionType: i.isEven ? 'CE' : 'PE',
            token: '$i',
            symbol: 'STOCK${i % 50}26JAN${100 + i}${i.isEven ? 'CE' : 'PE'}',
            lotSize: 100,
          ),
      ]);
      final before = await AppDatabase.instance.sizeBytes();
      expect(before, greaterThan(200 * 1024));

      // Everything expires → the rows go, the pages stay behind until VACUUM.
      expect(await dao.pruneExpired(before: DateTime(2030)), 4000);
      final freed = await AppDatabase.instance.vacuum();
      final after = await AppDatabase.instance.sizeBytes();

      expect(freed, greaterThan(0));
      expect(after, lessThan(before));
    });

    test('the migrated table still enforces one contract per strike', () async {
      final v6 = await databaseFactory.openDatabase(
        path,
        options: OpenDatabaseOptions(
          version: 6,
          onCreate: (db, version) async {
            await db.execute(_v6FnoContracts);
            await db.execute(_v6Scrips);
            await db.execute(
              'CREATE UNIQUE INDEX idx_fno_contract ON '
              'fno_contracts(underlying, expiry_date, strike, option_type)',
            );
            await db.execute(
              'CREATE INDEX idx_fno_underlying ON fno_contracts(underlying, expiry_date)',
            );
          },
        ),
      );
      await v6.close();

      final dao = FnoContractDao(AppDatabase.instance);
      await dao.replaceAll([
        FnoContract(
          underlying: 'SBIN',
          expiryLabel: '26JAN2026',
          expiryDate: DateTime(2026, 1, 26),
          strike: 800,
          optionType: 'CE',
          token: '111',
          symbol: 'SBIN26JAN800CE',
        ),
        FnoContract(
          underlying: 'SBIN',
          expiryLabel: '26JAN2026',
          expiryDate: DateTime(2026, 1, 26),
          strike: 800,
          optionType: 'CE',
          token: '222',
          symbol: 'SBIN26JAN800CE',
        ),
      ]);

      expect(await dao.count(), 1);
      final chain = await dao.chainOn('SBIN', DateTime(2026, 1, 26));
      expect(chain.single.token, '222'); // replace semantics, newest wins
    });
  });
}
