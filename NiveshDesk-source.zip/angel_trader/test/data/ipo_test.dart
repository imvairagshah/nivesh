// IPO model tests — CSV import, validation, distance maths and TradingView links.

import 'package:angel_trader/core/utils/csv_io.dart';
import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/models/ipo.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Ipo.fromCsvRecord', () {
    test('parses a clean row (headers as they appear in ipos.csv)', () {
      final records = CsvCodec.parseRecords(
        'Symbol,Company Name,Exchange,Listing Date,Listing High,Listing Low,Sector,Notes\n'
        'IDEA,Vodafone Idea Ltd,NSE,31-Jan-2018,24.60,14.05,Telecom,Listed at a discount\n',
      );
      final ipo = Ipo.fromCsvRecord(records.first);

      expect(ipo.symbol, 'IDEA');
      expect(ipo.companyName, 'Vodafone Idea Ltd');
      expect(ipo.exchange, Exchange.nse);
      expect(ipo.listingDate, DateTime(2018, 1, 31));
      expect(ipo.listingHigh, 24.60);
      expect(ipo.listingLow, 14.05);
      expect(ipo.sector, 'Telecom');
      expect(ipo.isCustom, isTrue);
    });

    test('strips a TradingView-style exchange prefix from the symbol', () {
      final ipo = Ipo.fromCsvRecord({
        'symbol': 'BSE:IDEA',
        'companyname': 'Vodafone Idea Ltd',
        'listingdate': '2018-01-31',
        'listinghigh': '24.60',
        'listinglow': '14.05',
      });
      expect(ipo.symbol, 'IDEA');
      expect(ipo.exchange, Exchange.bse); // inferred from the prefix
    });

    test('reports every missing field at once with the line number', () {
      expect(
        () => Ipo.fromCsvRecord(
          {'symbol': 'IDEA', 'listingdate': '', 'listinghigh': 'abc', 'listinglow': '0'},
          lineNumber: 42,
        ),
        throwsA(isA<ArgumentError>()),
      );
    });
  });

  group('distance helpers used by the screener', () {
    final ipo = Ipo(
      symbol: 'NYKAA',
      companyName: 'FSN E-Commerce Ventures Ltd',
      exchange: Exchange.nse,
      listingDate: DateTime(2021, 11, 10),
      listingHigh: 2101,
      listingLow: 1712.05,
    );

    test('distanceFromHigh/Low are signed percentages', () {
      expect(ipo.distanceFromHigh(2101), closeTo(0, 1e-9));
      expect(ipo.distanceFromHigh(2050), closeTo(-2.4274, 1e-4));
      expect(ipo.distanceFromHigh(2200), closeTo(4.7120, 1e-4));
      expect(ipo.distanceFromLow(1712.05), closeTo(0, 1e-9));
      expect(ipo.distanceFromLow(1750), closeTo(2.2166, 1e-4));
    });

    test('listingRange and listingMid', () {
      expect(ipo.listingRange, closeTo(388.95, 1e-9));
      expect(ipo.listingMid, closeTo(1906.525, 1e-9));
    });
  });

  group('TradingView deep links', () {
    test('NSE and BSE symbols build the documented URL', () {
      final nse = Ipo(
        symbol: 'SBIN',
        companyName: 'State Bank of India',
        exchange: Exchange.nse,
        listingDate: DateTime(2015, 6, 1),
        listingHigh: 300,
        listingLow: 250,
      );
      expect(nse.tradingViewSymbol, 'NSE:SBIN');
      expect(nse.tradingViewUrl, 'https://in.tradingview.com/chart/?symbol=NSE%3ASBIN');

      final bse = nse.copyWith(exchange: Exchange.bse);
      expect(bse.tradingViewSymbol, 'BSE:SBIN');
    });
  });

  group('validation', () {
    Ipo build({double high = 100, double low = 90, DateTime? date, String symbol = 'ABC'}) => Ipo(
          symbol: symbol,
          companyName: 'ABC Ltd',
          exchange: Exchange.nse,
          listingDate: date ?? DateTime(2020, 1, 1),
          listingHigh: high,
          listingLow: low,
        );

    test('accepts a well-formed row', () {
      expect(build().validate(), isEmpty);
    });

    test('rejects low above high', () {
      expect(build(high: 90, low: 100).validate(), contains('Listing low cannot exceed listing high.'));
    });

    test('rejects pre-2015 listings (outside the database scope)', () {
      final errors = build(date: DateTime(2014, 12, 31)).validate();
      expect(errors.any((e) => e.contains('1 Jan 2015')), isTrue);
    });

    test('rejects an empty symbol', () {
      expect(build(symbol: '  ').validate(), contains('Symbol is required.'));
    });
  });

  group('SQLite mapping', () {
    test('round-trips through toDb/fromDb', () {
      final ipo = Ipo(
        id: 7,
        symbol: 'IDEA',
        companyName: 'Vodafone Idea Ltd',
        exchange: Exchange.nse,
        listingDate: DateTime(2018, 1, 31),
        listingHigh: 24.6,
        listingLow: 14.05,
        sector: 'Telecom',
        notes: 'n',
        isCustom: true,
      );
      final restored = Ipo.fromDb(ipo.toDb());
      expect(restored.id, 7);
      expect(restored.symbol, 'IDEA');
      expect(restored.exchange, Exchange.nse);
      expect(restored.listingDate, DateTime(2018, 1, 31));
      expect(restored.listingHigh, 24.6);
      expect(restored.isCustom, isTrue);
    });
  });
}
