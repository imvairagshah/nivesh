import 'dart:io';

import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/magic_formula_dao.dart';
import 'package:angel_trader/features/magic_formula/magic_formula_models.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close();
  });

  tearDown(() async {
    await AppDatabase.instance.close();
    AppDatabase.overridePath = null;
  });

  test('v12 database migration adds the market price date column', () async {
    final directory = await Directory.systemTemp.createTemp(
      'magic_formula_v12_',
    );
    addTearDown(() => directory.delete(recursive: true));
    final path = p.join(directory.path, 'legacy.db');
    final legacy = await databaseFactory.openDatabase(
      path,
      options: OpenDatabaseOptions(
        version: 12,
        onCreate: (db, _) async {
          await db.execute(
            'CREATE TABLE magic_formula_fundamentals '
            '(security_key TEXT PRIMARY KEY)',
          );
        },
      ),
    );
    await legacy.close();

    AppDatabase.overridePath = path;
    final db = await AppDatabase.instance.database;
    final columns = await db.rawQuery(
      'PRAGMA table_info(magic_formula_fundamentals)',
    );

    expect(
      columns.map((column) => column['name']),
      contains('market_price_as_of'),
    );
  });

  test(
    'SQLite v13 cache upserts fundamentals and round-trips price date',
    () async {
      final dao = MagicFormulaDao(AppDatabase.instance);
      final row = MagicFormulaFundamental(
        candidate: const MagicFormulaCandidate(
          symbol: 'ACME',
          companyName: 'Acme Example Limited',
          exchange: 'NSE',
          sector: 'IT',
          isin: 'INE000A01000',
          dataSymbol: 'ACME',
        ),
        marketCapCr: 1234.5,
        ebitTtmCr: 100.25,
        totalDebtCr: null,
        cashCr: 2.5,
        statementBasis: 'Consolidated',
        marketPriceAsOf: DateTime(2026, 10, 16),
        periodEnd: DateTime(2026, 3, 31),
        fetchedAt: DateTime(2026, 10, 17),
        missingReason: 'Missing official fields: Total Debt',
      );

      await dao.saveAll([row]);
      final read = await dao.find('ISIN:INE000A01000');

      expect(await dao.count(), 1);
      expect(read?.marketCapCr, 1234.5);
      expect(read?.totalDebtCr, isNull);
      expect(read?.statementBasis, 'Consolidated');
      expect(read?.marketPriceAsOf, DateTime(2026, 10, 16));
      expect(read?.missingReason, 'Missing official fields: Total Debt');
      expect(read?.candidate.dataSymbol, 'ACME');
      // Policy: a row with a missingReason is never served stale — a rescan
      // must retry it (the fix for 'same error aa rahi hai abhi bhi').
      expect(read?.isFresh(now: DateTime(2026, 10, 17)), isFalse);
    },
  );
}
