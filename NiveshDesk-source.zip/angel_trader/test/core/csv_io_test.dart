// CSV reader/writer tests — the bundled IPO seed file, user imports and trade
// exports all flow through CsvCodec.

import 'package:angel_trader/core/utils/csv_io.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('CsvCodec.parse', () {
    test('parses a simple table', () {
      final rows = CsvCodec.parse('a,b,c\n1,2,3\n');
      expect(rows, [
        ['a', 'b', 'c'],
        ['1', '2', '3'],
      ]);
    });

    test('handles CRLF, a trailing newline and a UTF-8 BOM', () {
      final rows = CsvCodec.parse('\uFEFFsymbol,name\r\nIDEA,Vodafone Idea\r\n');
      expect(rows.length, 2);
      expect(rows.first.first, 'symbol');
      expect(rows.last, ['IDEA', 'Vodafone Idea']);
    });

    test('handles quoted fields containing commas and quotes', () {
      final rows = CsvCodec.parse(
        'symbol,name\n'
        'FSL,"Firstsource Solutions, Ltd"\n'
        'XYZ,"He said ""buy"" today"\n',
      );
      expect(rows[1][1], 'Firstsource Solutions, Ltd');
      expect(rows[2][1], 'He said "buy" today');
    });

    test('handles a quoted field containing a newline', () {
      final rows = CsvCodec.parse('a,b\n"line1\nline2",z\n');
      expect(rows.length, 2);
      expect(rows[1][0], 'line1\nline2');
      expect(rows[1][1], 'z');
    });

    test('drops fully empty lines but keeps blank cells', () {
      final rows = CsvCodec.parse('a,b\n\n,,\n1,\n');
      expect(rows.length, 2);
      expect(rows[1], ['1', '']);
    });
  });

  group('CsvCodec.parseRecords', () {
    test('maps headers case-insensitively and strips separators', () {
      final records = CsvCodec.parseRecords(
        'Symbol,Company Name,Listing Date,Listing High,Listing Low,Exchange\n'
        'NYKAA,FSN E-Commerce Ventures Ltd,10-Nov-2021,2101.00,1712.05,NSE\n',
      );
      expect(records, hasLength(1));
      expect(records.first['symbol'], 'NYKAA');
      expect(records.first['companyname'], 'FSN E-Commerce Ventures Ltd');
      expect(records.first['listingdate'], '10-Nov-2021');
      expect(records.first['listinghigh'], '2101.00');
      expect(records.first['exchange'], 'NSE');
    });

    test('pads short rows with empty strings instead of throwing', () {
      final records = CsvCodec.parseRecords('a,b,c\n1,2\n');
      expect(records.first['c'], '');
    });
  });

  group('CsvCodec.encode', () {
    test('quotes only when needed and round-trips through parse', () {
      final encoded = CsvCodec.encode([
        ['symbol', 'name', 'notes'],
        ['IDEA', 'Vodafone Idea Ltd', 'listed flat, then fell 9%'],
        ['SBIN', 'State Bank of India', 'He said "buy"'],
      ]);
      expect(encoded, contains('"listed flat, then fell 9%"'));
      expect(encoded, contains('"He said ""buy"""'));

      final reparsed = CsvCodec.parse(encoded);
      expect(reparsed[1][2], 'listed flat, then fell 9%');
      expect(reparsed[2][2], 'He said "buy"');
    });
  });
}
