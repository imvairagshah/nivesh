// TOTP generator tests — verified against the official RFC 6238 / RFC 4226
// test vectors. If these pass, SmartAPI 2FA will accept the generated code
// (provided the phone clock is correct).

import 'package:angel_trader/core/utils/totp.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  // ASCII "12345678901234567890" in base32 (the RFC 6238 Appendix B secret).
  const rfcSecret = 'GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ';

  group('Totp.generate — RFC 6238 Appendix B vectors (SHA-1, 6 digits)', () {
    test('decodes the RFC secret to the expected 20 bytes', () {
      expect(Totp.decodeBase32(rfcSecret).length, 20);
      expect(Totp.decodeBase32(rfcSecret).first, 49); // '1'
    });

    test('T = 59s → 287082 (last 6 of 94287082)', () {
      expect(
        Totp.generate(rfcSecret, at: _utcSeconds(59)),
        '287082',
      );
    });

    test('T = 1111111109 → 081804 (last 6 of 07081804)', () {
      expect(Totp.generate(rfcSecret, at: _utcSeconds(1111111109)), '081804');
    });

    test('T = 1111111111 → 050471 (last 6 of 14050471)', () {
      expect(Totp.generate(rfcSecret, at: _utcSeconds(1111111111)), '050471');
    });

    test('T = 1234567890 → 005924 (last 6 of 89005924)', () {
      expect(Totp.generate(rfcSecret, at: _utcSeconds(1234567890)), '005924');
    });

    test('T = 2000000000 → 279037 (last 6 of 69279037)', () {
      expect(Totp.generate(rfcSecret, at: _utcSeconds(2000000000)), '279037');
    });

    test('T = 20000000000 → 353130 (last 6 of 65353130)', () {
      expect(Totp.generate(rfcSecret, at: _utcSeconds(20000000000)), '353130');
    });
  });

  group('Totp — format & robustness', () {
    test('always returns exactly 6 digits, zero padded', () {
      for (var t = 0; t < 500; t++) {
        final code = Totp.generate(rfcSecret, at: _utcSeconds(t * 30));
        expect(code.length, 6);
        expect(int.tryParse(code), isNotNull);
      }
    });

    test('code is stable inside a 30 second window and changes after it', () {
      // 1000–1019 s all fall in counter window 33; 1020 s starts window 34.
      final a = Totp.generate(rfcSecret, at: _utcSeconds(1000));
      final b = Totp.generate(rfcSecret, at: _utcSeconds(1019));
      final c = Totp.generate(rfcSecret, at: _utcSeconds(1020));
      expect(a, b, reason: 'same 30s window must give the same code');
      expect(a, isNot(c), reason: 'the next window must roll the code');
    });

    test('tolerates spaces, dashes and lower case in the secret', () {
      final lower = Totp.generate('gezdgnbvgy3tqojq gezdgnbvgy3tqojq', at: _utcSeconds(59));
      expect(lower, '287082');
    });

    test('throws on an empty secret', () {
      expect(() => Totp.generate('', at: _utcSeconds(59)), throwsFormatException);
    });

    test('secondsRemaining counts down within the window', () {
      expect(Totp.secondsRemaining(at: _utcSeconds(0)), 30);
      expect(Totp.secondsRemaining(at: _utcSeconds(59)), 1);
      expect(Totp.secondsRemaining(at: _utcSeconds(60)), 30);
    });

    test('isExpiringSoon guards against submitting a stale code', () {
      expect(Totp.isExpiringSoon(at: _utcSeconds(26)), isTrue); // 4s left
      expect(Totp.isExpiringSoon(at: _utcSeconds(10)), isFalse); // 20s left
    });

    test('isValidSecret rejects short/invalid secrets', () {
      expect(Totp.isValidSecret(rfcSecret), isTrue);
      expect(Totp.isValidSecret('ABC'), isFalse); // too short (<80 bits)
      expect(Totp.isValidSecret('!!!!'), isFalse); // no base32 characters
    });
  });
}

/// Helper: a UTC [DateTime] [seconds] after the Unix epoch.
DateTime _utcSeconds(int seconds) =>
    DateTime.fromMillisecondsSinceEpoch(seconds * 1000, isUtc: true);
