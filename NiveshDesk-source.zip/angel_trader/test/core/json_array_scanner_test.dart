// Streaming scrip-master parser tests.

import 'package:angel_trader/core/utils/json_array_scanner.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('JsonArrayScanner', () {
    test('emits each object of a flat array', () {
      final scanner = JsonArrayScanner();
      final objects = scanner.feed(
        '[{"token":"3045","symbol":"SBIN-EQ"},{"token":"1594","symbol":"IDEA-EQ"}]',
      );
      expect(objects, hasLength(2));
      expect(objects.first['symbol'], 'SBIN-EQ');
      expect(objects.last['token'], '1594');
      expect(scanner.objectCount, 2);
    });

    test('reassembles objects split across network chunks', () {
      final scanner = JsonArrayScanner();
      final chunk1 = scanner.feed('[{"token":"3045","sym');
      final chunk2 = scanner.feed('bol":"SBIN-EQ"},{"token":"15');
      final chunk3 = scanner.feed('94","symbol":"IDEA-EQ"}]');

      expect(chunk1, isEmpty);
      expect(chunk2, hasLength(1));
      expect(chunk2.single['token'], '3045');
      expect(chunk3, hasLength(1));
      expect(chunk3.single['symbol'], 'IDEA-EQ');
    });

    test('braces and commas inside strings do not confuse the depth counter', () {
      final scanner = JsonArrayScanner();
      final objects = scanner.feed(
        '[{"name":"A, B {C} Ltd","symbol":"ABC-EQ","notes":"he said \\"buy\\""}]',
      );
      expect(objects, hasLength(1));
      expect(objects.single['name'], 'A, B {C} Ltd');
      expect(objects.single['notes'], 'he said "buy"');
    });

    test('handles nested objects and arrays of objects', () {
      final scanner = JsonArrayScanner();
      final objects = scanner.feed(
        '[{"token":"1","depth":{"buy":[{"price":1,"qty":2},{"price":3,"qty":4}]}}]',
      );
      expect(objects, hasLength(1));
      expect((objects.single['depth'] as Map)['buy'], hasLength(2));
    });

    test('pretty-printed masters with newlines and indentation work', () {
      final scanner = JsonArrayScanner();
      final objects = scanner.feed(
        '[\n  {\n    "token": "3045",\n    "symbol": "SBIN-EQ"\n  },\n'
        '  {\n    "token": "1594",\n    "symbol": "IDEA-EQ"\n  }\n]\n',
      );
      expect(objects, hasLength(2));
    });

    test('a truncated final object stays buffered (and is reported)', () {
      final scanner = JsonArrayScanner();
      final objects = scanner.feed('[{"token":"3045"},{"token":"15');
      expect(objects, hasLength(1));
      expect(scanner.bufferedChars, greaterThan(0));
    });

    test(r'unicode \uXXXX escapes decode correctly', () {
      // \u0905 = Devanagari A, etc. — company names in the master use escapes
      // for non-ASCII characters, so the scanner must pass them through intact.
      final scanner = JsonArrayScanner();
      final objects = scanner
          .feed('[{"name":"Gujarat \\u0905\\u092e\\u0926\\u093e\\u0935\\u093e\\u0926"}]');
      expect(objects.single['name'], 'Gujarat अमदावाद');
    });

    test('non-object rows are skipped without crashing', () {
      final scanner = JsonArrayScanner();
      final objects = scanner.feed('[{"a":1}]');
      expect(objects, hasLength(1));
      // A malformed row increments decodeFailures rather than throwing.
      final bad = JsonArrayScanner();
      bad.feed('[{"a":}]');
      expect(bad.decodeFailures, 1);
      expect(bad.objectCount, 0);
    });
  });
}
