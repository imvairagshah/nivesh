// Tests for the shared design pieces (1.5.58): MetricBox, MetricGrid,
// TapChip, SmoothExpand — label/value separation is the core guarantee.
import 'package:angel_trader/core/widgets/ui.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

Widget _wrap(Widget child) => MaterialApp(
      home: Scaffold(
        body: SingleChildScrollView(child: child),
      ),
    );

void main() {
  testWidgets('MetricBox keeps emoji, label and value as separate texts',
      (tester) async {
    await tester.pumpWidget(_wrap(const MetricBox(
      emoji: '📈',
      label: '3M High',
      value: '128.30',
      sub: '2.4% neeche',
      tooltip: '3-mahine ka sabse ooncha bhav',
    )));
    expect(find.text('📈'), findsOneWidget);
    expect(find.text('3M High'), findsOneWidget);
    expect(find.text('128.30'), findsOneWidget);
    expect(find.text('2.4% neeche'), findsOneWidget);
    // Tooltip is attached (long-press message).
    expect(find.byType(Tooltip), findsWidgets);
  });

  testWidgets('MetricGrid wraps boxes side by side', (tester) async {
    await tester.pumpWidget(_wrap(const MetricGrid(children: [
      MetricBox(label: 'A', value: '1'),
      MetricBox(label: 'B', value: '2'),
    ])));
    expect(find.text('A'), findsOneWidget);
    expect(find.text('B'), findsOneWidget);
    expect(find.byType(MetricBox), findsNWidgets(2));
  });

  testWidgets('boxes in a row share the same height (1.5.59 fix)',
      (tester) async {
    await tester.pumpWidget(_wrap(const MetricGrid(children: [
      // The tall one: label + value + 2-line sub.
      MetricBox(
        label: 'Tall',
        value: '10',
        sub: 'do line wala sub text yahan aata hai, lamba wala',
      ),
      // The short one: label + value only.
      MetricBox(label: 'Short', value: '20'),
      MetricBox(label: 'Mid', value: '30'),
    ])));
    await tester.pumpAndSettle();
    final boxes = find.byType(MetricBox);
    final h1 = tester.getSize(boxes.at(0)).height;
    final h2 = tester.getSize(boxes.at(1)).height;
    final h3 = tester.getSize(boxes.at(2)).height;
    expect(h1, h2, reason: 'row ke sab boxes barabar height ke');
    expect(h2, h3);
  });

  testWidgets('TapChip label stays its own text next to the emoji',
      (tester) async {
    await tester.pumpWidget(_wrap(const TapChip(
      emoji: '⚡',
      label: 'ATR 1.5%',
      filled: true,
    )));
    expect(find.text('⚡'), findsOneWidget);
    expect(find.text('ATR 1.5%'), findsOneWidget);
  });

  testWidgets('SmoothExpand animates its child', (tester) async {
    await tester.pumpWidget(_wrap(const SmoothExpand(
      child: Text('content'),
    )));
    await tester.pumpAndSettle();
    expect(find.text('content'), findsOneWidget);
  });
}
