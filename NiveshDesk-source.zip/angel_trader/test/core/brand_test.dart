// ---------------------------------------------------------------------------
// brand_test.dart — the logo, drawn in code.
//
// The mark is a CustomPainter, so these tests render it for real (light AND
// dark, animated and static) and assert the things that would actually break a
// user's first impression: the wordmark, the tagline, the geometry invariants
// shared with the launcher icon, and that the entrance animation finishes.
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/theme/app_theme.dart';
import 'package:angel_trader/core/widgets/brand.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

Widget _host(Widget child, {Brightness brightness = Brightness.light}) =>
    MaterialApp(
      theme: brightness == Brightness.dark ? AppTheme.dark() : AppTheme.light(),
      home: Scaffold(body: Center(child: child)),
    );

void main() {
  // -------------------------------------------------------------------------
  group('Brand constants', () {
    test('the wordmark is two tones of the same name', () {
      expect(Brand.name, '${Brand.namePrefix}${Brand.nameSuffix}');
      expect(Brand.name, 'NiveshDesk');
    });

    test('the product does not trade on Angel One’s name', () {
      // The app reads Angel One data but is not theirs; the visible brand
      // must never suggest otherwise.
      expect(Brand.name.toLowerCase(), isNot(contains('angel')));
      expect(Brand.tagline.toLowerCase(), isNot(contains('angel')));
    });

    test('the hero gradient runs light → deep in both brightnesses', () {
      for (final dark in [false, true]) {
        final gradient = Brand.heroGradient(dark: dark);
        expect(gradient.colors.length, greaterThanOrEqualTo(2));
        expect(gradient.colors.first, isNot(gradient.colors.last));
      }
      // Gold is an accent, never the base colour.
      expect(Brand.goldGlow().colors.first.a, greaterThan(0));
      expect(Brand.goldGlow().colors.last.a, lessThan(0.1));
    });
  });

  // -------------------------------------------------------------------------
  group('BrandGeometry (shared with the launcher icon)', () {
    test('bars ascend, sit on one baseline and stay inside the plate', () {
      expect(BrandGeometry.barCenters.length, BrandGeometry.barHeights.length);
      for (var i = 1; i < BrandGeometry.barHeights.length; i++) {
        expect(
          BrandGeometry.barHeights[i],
          greaterThan(BrandGeometry.barHeights[i - 1]),
          reason: 'bar $i must be taller than the one before it',
        );
      }
      for (var i = 0; i < BrandGeometry.barCenters.length; i++) {
        final left = BrandGeometry.barCenters[i] - BrandGeometry.barWidth / 2;
        final right = BrandGeometry.barCenters[i] + BrandGeometry.barWidth / 2;
        final top =
            BrandGeometry.barBaseline - BrandGeometry.barHeights[i];
        expect(left, greaterThan(0.0));
        expect(right, lessThan(1.0));
        expect(top, greaterThan(0.0));
      }
    });

    test('the trend line ends higher than it started (the point of the mark)',
        () {
      final first = BrandGeometry.trendPoints.first;
      final last = BrandGeometry.trendPoints.last;
      expect(last.dy, lessThan(first.dy), reason: 'upward on screen');
      expect(last.dx, greaterThan(first.dx));
      expect(last.dx + BrandGeometry.tipDotRadius, lessThan(1.0));
    });
  });

  // -------------------------------------------------------------------------
  group('BrandMark', () {
    testWidgets('paints its geometry in light and dark', (tester) async {
      for (final brightness in [Brightness.light, Brightness.dark]) {
        // Give the widget a *distinct* size per pass: an identical const widget
        // would be diffed away, and MaterialApp animates theme changes over
        // 200 ms (AnimatedTheme), so one pump is not enough either.
        await tester.pumpWidget(_host(
          BrandMark(size: brightness == Brightness.dark ? 65 : 64),
          brightness: brightness,
        ));
        await tester.pump(const Duration(milliseconds: 250));
        expect(find.byType(CustomPaint), findsWidgets);
        final paint = tester.widget<CustomPaint>(
          find.descendant(
            of: find.byType(BrandMark),
            matching: find.byType(CustomPaint),
          ),
        );
        expect(paint.painter, isA<BrandMarkPainter>());
        final painter = paint.painter! as BrandMarkPainter;
        expect(painter.dark, brightness == Brightness.dark);
        expect(painter.progress, 1, reason: 'the static mark is fully drawn');
      }
    });

    testWidgets('is exposed to accessibility as a logo', (tester) async {
      await tester.pumpWidget(_host(const BrandMark()));
      expect(
        find.bySemanticsLabel('${Brand.name} logo'),
        findsOneWidget,
      );
    });

    test('shouldRepaint only for real changes', () {
      const a = BrandMarkPainter(dark: false);
      const b = BrandMarkPainter(dark: false);
      const c = BrandMarkPainter(dark: true);
      const half = BrandMarkPainter(dark: false, progress: 0.5);

      expect(a.shouldRepaint(b), isFalse);
      expect(a.shouldRepaint(c), isTrue);
      expect(a.shouldRepaint(half), isTrue);
      expect(a.shouldRepaint(const BrandMarkPainter(
        dark: false,
        monochrome: true,
      )), isTrue);
    });
  });

  // -------------------------------------------------------------------------
  group('AnimatedBrandMark', () {
    testWidgets('draws itself in and settles', (tester) async {
      await tester.pumpWidget(_host(const AnimatedBrandMark(size: 96)));

      BrandMarkPainter painter() => tester
          .widget<CustomPaint>(
            find.descendant(
              of: find.byType(AnimatedBrandMark),
              matching: find.byType(CustomPaint),
            ),
          )
          .painter! as BrandMarkPainter;

      expect(painter().progress, lessThan(0.2), reason: 'starts undrawn');

      await tester.pump(const Duration(milliseconds: 400));
      final mid = painter().progress;
      expect(mid, greaterThan(0.0));
      expect(mid, lessThan(1.0));

      // 1150 ms default plus the delay — comfortably settled by now.
      await tester.pump(const Duration(milliseconds: 1000));
      expect(painter().progress, 1);
    });

    testWidgets('a delayed mark still completes', (tester) async {
      await tester.pumpWidget(_host(const AnimatedBrandMark(
        size: 80,
        delay: Duration(milliseconds: 120),
        duration: Duration(milliseconds: 300),
      )));

      await tester.pump(const Duration(milliseconds: 60));
      expect(
        (tester.widget<CustomPaint>(
          find.descendant(
            of: find.byType(AnimatedBrandMark),
            matching: find.byType(CustomPaint),
          ),
        ).painter! as BrandMarkPainter).progress,
        0,
        reason: 'still inside the 120 ms delay',
      );
      // Cross the delay, then run the 300 ms draw-in to completion.
      await tester.pump(const Duration(milliseconds: 100));
      await tester.pump(const Duration(milliseconds: 400));
      final painter = tester
          .widget<CustomPaint>(
            find.descendant(
              of: find.byType(AnimatedBrandMark),
              matching: find.byType(CustomPaint),
            ),
          )
          .painter! as BrandMarkPainter;
      expect(painter.progress, 1);
    });
  });

  // -------------------------------------------------------------------------
  group('BrandLogo / wordmark', () {
    testWidgets('shows the two-tone name, and the tagline on request',
        (tester) async {
      await tester.pumpWidget(_host(const BrandLogo(markSize: 40)));
      expect(find.textContaining('Nivesh'), findsOneWidget);
      expect(find.textContaining('Desk'), findsWidgets);

      await tester.pumpWidget(_host(
        const BrandLogo(markSize: 40, showTagline: true),
      ));
      expect(find.text(Brand.tagline), findsOneWidget);
    });

    testWidgets('stacks vertically for the splash and login layouts',
        (tester) async {
      await tester.pumpWidget(_host(
        const BrandLogo(markSize: 54, axis: Axis.vertical, showTagline: true),
      ));
      // Mark above the wordmark: the mark's bottom edge is above the text's.
      final mark = tester.getRect(find.byType(BrandMark));
      final text = tester.getRect(find.textContaining('Nivesh'));
      expect(mark.bottom, lessThanOrEqualTo(text.top + 1));
    });

    testWidgets('the wordmark colours the two halves differently',
        (tester) async {
      await tester.pumpWidget(_host(const BrandLogo(markSize: 40)));
      final rich = tester.widget<Text>(find.textContaining('Nivesh'));
      final span = rich.textSpan! as TextSpan;
      final childSpans = span.children!.cast<TextSpan>();
      expect(childSpans, hasLength(2));
      expect(
        childSpans[0].style!.color,
        isNot(childSpans[1].style!.color),
        reason: 'prefix is neutral, suffix carries the brand colour',
      );
      expect(childSpans[1].style!.fontWeight, FontWeight.w800);
    });
  });

  // -------------------------------------------------------------------------
  group('BrandWatermark', () {
    testWidgets('is present but non-interactive', (tester) async {
      await tester.pumpWidget(_host(
        const BrandWatermark(size: 120, opacity: 0.06),
      ));
      expect(find.byType(BrandWatermark), findsOneWidget);
      expect(find.byType(IgnorePointer), findsWidgets);
      final opacity = tester.widget<Opacity>(
        find.descendant(
          of: find.byType(BrandWatermark),
          matching: find.byType(Opacity),
        ),
      );
      expect(opacity.opacity, closeTo(0.06, 0.001));
    });
  });
}
