// 1.5.92 — "ek page = ek scroll" (PC fix). Ye test pin karta hai ki PageScroll
// me sirf EK vertical Scrollable hota hai aur header + rows usi scroll ke
// andar hain (fixed header + nested list wala double-scroll nahi).

import 'package:angel_trader/core/widgets/page_scroll.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

Widget _wrap(Widget child) => MaterialApp(
      scrollBehavior: const AppScrollBehavior(),
      home: Scaffold(body: child),
    );

void main() {
  testWidgets('children variant — ek hi vertical Scrollable', (tester) async {
    await tester.pumpWidget(_wrap(PageScroll.children([
      const Text('Header'),
      const SizedBox(height: 1200),
      const Text('Footer'),
    ])));

    final scrollables = tester.widgetList<Scrollable>(find.byType(Scrollable));
    expect(scrollables, hasLength(1),
        reason: 'poori page ke liye sirf ek scroll');
    expect(find.text('Header'), findsOneWidget);
    expect(find.text('Footer'), findsOneWidget);
  });

  testWidgets('builder variant — header/footer usi scroll ke items', (tester) async {
    await tester.pumpWidget(_wrap(PageScroll.builder(
      header: const [Text('Table header')],
      footer: const [Text('Table footer')],
      itemCount: 30,
      itemBuilder: (context, i) => SizedBox(
        height: 40,
        child: Text('Row $i'),
      ),
    )));

    expect(tester.widgetList<Scrollable>(find.byType(Scrollable)), hasLength(1));
    expect(find.text('Table header'), findsOneWidget);
    expect(find.text('Row 0'), findsOneWidget);

    // Scroll karke footer tak jaana — sab ek hi scroll me hai.
    await tester.drag(find.byType(Scrollable), const Offset(0, -2000));
    await tester.pumpAndSettle();
    expect(find.text('Table footer'), findsOneWidget);
  });

  testWidgets('AppScrollBehavior — mouse se drag-scroll allowed (PC)', (tester) async {
    const behavior = AppScrollBehavior();
    expect(behavior.dragDevices.contains(PointerDeviceKind.mouse), isTrue);
    expect(behavior.dragDevices.contains(PointerDeviceKind.touch), isTrue);
  });
}
