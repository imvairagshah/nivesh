// ---------------------------------------------------------------------------
// motion_test.dart — the shared animation kit.
//
// These are widget tests, so they run against the real widget tree. House rule
// for the loops: never `pumpAndSettle()` on a widget that repeats forever —
// step time with `pump(duration)` instead, which is also how the entry
// animations are verified (start → mid → settled).
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/theme/app_theme.dart';
import 'package:angel_trader/core/widgets/motion.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

Widget _host(Widget child, {Brightness brightness = Brightness.light}) =>
    MaterialApp(
      theme: brightness == Brightness.dark ? AppTheme.dark() : AppTheme.light(),
      home: Scaffold(body: Center(child: child)),
    );

void main() {
  // -------------------------------------------------------------------------
  group('NumberTicker', () {
    testWidgets('counts up from zero and lands exactly on the value',
        (tester) async {
      await tester.pumpWidget(_host(
        const NumberTicker(value: 1234.5, format: _twoDp),
      ));

      // First frame: still at (or very near) zero.
      expect(tester.widget<Text>(find.byType(Text)).data, '0.00');

      // Mid-flight: moved, but not there yet.
      await tester.pump(const Duration(milliseconds: 200));
      final mid = double.parse(tester.widget<Text>(find.byType(Text)).data!);
      expect(mid, greaterThan(0));
      expect(mid, lessThan(1234.5));

      // Settled: exactly the value (no float dust in the string).
      await tester.pump(const Duration(milliseconds: 600));
      expect(tester.widget<Text>(find.byType(Text)).data, '1234.50');
    });

    testWidgets('re-rolls when the value changes', (tester) async {
      await tester.pumpWidget(_host(
        const NumberTicker(value: 100, format: _twoDp, countUpOnFirstBuild: false),
      ));
      await tester.pump(const Duration(milliseconds: 600));
      expect(tester.widget<Text>(find.byType(Text)).data, '100.00');

      await tester.pumpWidget(_host(
        const NumberTicker(value: -50, format: _twoDp, countUpOnFirstBuild: false),
      ));
      await tester.pump(const Duration(milliseconds: 200));
      final mid = double.parse(tester.widget<Text>(find.byType(Text)).data!);
      expect(mid, lessThan(100));
      expect(mid, greaterThan(-50));

      await tester.pump(const Duration(milliseconds: 600));
      expect(tester.widget<Text>(find.byType(Text)).data, '-50.00');
    });

    testWidgets('with countUp suppressed the first paint is final',
        (tester) async {
      await tester.pumpWidget(_host(
        const NumberTicker(
          value: 42,
          format: _twoDp,
          countUpOnFirstBuild: false,
        ),
      ));
      expect(tester.widget<Text>(find.byType(Text)).data, '42.00');
    });
  });

  /// The FadeTransition *inside* a FadeSlideIn — the app's own route
  /// transitions are FadeTransitions as well, so lookups must be scoped.
  FadeTransition fadeOf(WidgetTester tester) => tester.widget<FadeTransition>(
        find.descendant(
          of: find.byType(FadeSlideIn),
          matching: find.byType(FadeTransition),
        ),
      );

  // -------------------------------------------------------------------------
  group('FadeSlideIn', () {
    testWidgets('fades and lifts into place, then stops', (tester) async {
      await tester.pumpWidget(_host(
        const FadeSlideIn(index: 0, child: Text('row')),
      ));

      expect(fadeOf(tester).opacity.value, lessThan(0.2),
          reason: 'starts transparent');

      await tester.pump(const Duration(milliseconds: 500));
      expect(fadeOf(tester).opacity.value, closeTo(1, 0.001),
          reason: 'settles fully on');
      expect(find.text('row'), findsOneWidget);
    });

    testWidgets('honours the stagger delay', (tester) async {
      await tester.pumpWidget(_host(
        const FadeSlideIn(index: 4, child: Text('late row')),
      ));

      // AppMotion.stagger is 45 ms, so index 4 waits 180 ms: still dark here…
      await tester.pump(const Duration(milliseconds: 60));
      expect(fadeOf(tester).opacity.value, 0);

      // …then the delay fires (animation starts at 0) and it plays out.
      await tester.pump(const Duration(milliseconds: 200));
      await tester.pump(const Duration(milliseconds: 600));
      expect(fadeOf(tester).opacity.value, closeTo(1, 0.001));
    });

    testWidgets('disabled renders immediately', (tester) async {
      await tester.pumpWidget(_host(
        const FadeSlideIn(index: 6, enabled: false, child: Text('now')),
      ));
      expect(fadeOf(tester).opacity.value, 1);
    });

    testWidgets('the stagger is capped so long lists stay snappy',
        (tester) async {
      // Index 500 must behave like index AppMotion.maxStaggerIndex (8).
      await tester.pumpWidget(_host(
        const FadeSlideIn(index: 500, child: Text('deep row')),
      ));
      await tester.pump(const Duration(milliseconds: 60));
      expect(fadeOf(tester).opacity.value, 0,
          reason: 'always waits its delay, however deep it is');
      await tester.pump(const Duration(milliseconds: 600));
      await tester.pump(const Duration(milliseconds: 600));
      expect(fadeOf(tester).opacity.value, closeTo(1, 0.001));
    });
  });

  // -------------------------------------------------------------------------
  group('SwapFade', () {
    testWidgets('cross-fades between children', (tester) async {
      await tester.pumpWidget(_host(const SwapFade(child: Text('holdings'))));
      await tester.pump(const Duration(milliseconds: 400));
      expect(find.text('holdings'), findsOneWidget);

      await tester.pumpWidget(_host(const SwapFade(child: Text('orders'))));
      await tester.pump(const Duration(milliseconds: 400));
      expect(find.text('orders'), findsOneWidget);
      expect(find.text('holdings'), findsNothing);
    });
  });

  // -------------------------------------------------------------------------
  group('Loops', () {
    testWidgets('PulseDot runs a repeating ring and stays in the tree',
        (tester) async {
      await tester.pumpWidget(_host(
        const PulseDot(color: Colors.green),
      ));
      expect(find.byType(PulseDot), findsOneWidget);

      // Two full periods of stepping: the controller must never throw and must
      // keep the widget mounted (this is what would break in a list).
      for (var i = 0; i < 8; i++) {
        await tester.pump(const Duration(milliseconds: 200));
      }
      expect(find.byType(PulseDot), findsOneWidget);
    });

    testWidgets('ShimmerBox paints a moving gradient', (tester) async {
      await tester.pumpWidget(_host(
        const ShimmerBox(width: 120, height: 12),
      ));
      expect(find.byType(ShimmerBox), findsOneWidget);
      for (var i = 0; i < 5; i++) {
        await tester.pump(const Duration(milliseconds: 300));
      }
      expect(find.byType(ShimmerBox), findsOneWidget);
    });

    testWidgets('ShimmerCard renders its placeholder lines', (tester) async {
      await tester.pumpWidget(_host(const ShimmerCard(lines: 2)));
      // header (mark + title) + the requested body lines
      expect(find.byType(ShimmerBox), findsNWidgets(2 + 2));
      await tester.pump(const Duration(milliseconds: 300));
    });
  });

  // -------------------------------------------------------------------------
  group('Progress + touch', () {
    testWidgets('SmoothProgressBar animates to the new value', (tester) async {
      await tester.pumpWidget(_host(const SmoothProgressBar(value: 0.6)));
      await tester.pump(const Duration(milliseconds: 600));
      final bar = tester.widget<LinearProgressIndicator>(
        find.byType(LinearProgressIndicator),
      );
      expect(bar.value, closeTo(0.6, 0.001));
    });

    testWidgets('SmoothProgressBar clamps out-of-range values', (tester) async {
      await tester.pumpWidget(_host(const SmoothProgressBar(value: 1.7)));
      await tester.pump(const Duration(milliseconds: 600));
      expect(
        tester.widget<LinearProgressIndicator>(
          find.byType(LinearProgressIndicator),
        ).value,
        closeTo(1, 0.001),
      );
    });

    testWidgets('PressScale still lets taps through to the child',
        (tester) async {
      var taps = 0;
      await tester.pumpWidget(_host(
        PressScale(
          child: GestureDetector(
            onTap: () => taps++,
            child: const SizedBox(
              key: ValueKey<String>('press-target'),
              width: 80,
              height: 40,
              child: ColoredBox(color: Colors.grey),
            ),
          ),
        ),
      ));

      // Tap by key: the Scaffold has a ColoredBox of its own.
      await tester.tap(find.byKey(const ValueKey<String>('press-target')));
      await tester.pump(const Duration(milliseconds: 200));
      expect(taps, 1);
    });

    testWidgets('PressScale is a no-op when disabled', (tester) async {
      await tester.pumpWidget(_host(
        const PressScale(enabled: false, child: Text('flat')),
      ));
      expect(find.byType(AnimatedScale), findsNothing);
      expect(find.text('flat'), findsOneWidget);
    });
  });
}

/// Small formatter so the assertions can parse the rendered string directly.
String _twoDp(double value) => value.toStringAsFixed(2);
