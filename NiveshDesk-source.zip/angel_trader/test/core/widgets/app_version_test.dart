import 'package:angel_trader/core/widgets/app_version.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:package_info_plus/package_info_plus.dart';

void main() {
  testWidgets('shows the installed package version, not a hard-coded label', (
    tester,
  ) async {
    PackageInfo.setMockInitialValues(
      appName: 'NiveshDesk',
      packageName: 'com.angeltrader.angel_trader',
      version: '1.5.35',
      buildNumber: '2048',
      buildSignature: 'test',
    );

    await tester.pumpWidget(
      const MaterialApp(home: Scaffold(body: AppVersionLabel())),
    );
    await tester.pumpAndSettle();

    expect(find.text('1.5.35 (build 2048)'), findsOneWidget);
  });
}
