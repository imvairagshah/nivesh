// Trading-calendar tests: market hours, holidays and the "latest trading day"
// walk-back used by the Golden Cross screener's default scan date.

import 'package:angel_trader/core/utils/markets.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('MarketCalendar — weekends & holidays', () {
    test('Saturday and Sunday are not trading days', () {
      expect(MarketCalendar.isTradingDay(DateTime(2026, 10, 3)), isFalse); // Sat
      expect(MarketCalendar.isTradingDay(DateTime(2026, 10, 4)), isFalse); // Sun
    });

    test('a regular Monday is a trading day', () {
      expect(MarketCalendar.isTradingDay(DateTime(2025, 9, 29)), isTrue);
    });

    test('Republic Day 2026 (Mon 26 Jan) is a holiday', () {
      expect(MarketCalendar.isHoliday(DateTime(2026, 1, 26)), isTrue);
      expect(MarketCalendar.isTradingDay(DateTime(2026, 1, 26)), isFalse);
    });
  });

  group('MarketCalendar.latestTradingDay', () {
    test('walks back over the weekend and a holiday (Sat 3 Oct 2026)', () {
      // 3 Oct 2026 = Saturday, 2 Oct 2026 = Gandhi Jayanti (holiday),
      // so the most recent session is Thursday 1 Oct 2026.
      final day = MarketCalendar.latestTradingDay(from: DateTime(2026, 10, 3));
      expect(day, DateTime(2026, 10, 1));
    });

    test('returns the same day when it is itself a trading day', () {
      final day = MarketCalendar.latestTradingDay(from: DateTime(2025, 9, 29, 22));
      expect(day, DateTime(2025, 9, 29));
    });
  });

  group('MarketCalendar — session windows', () {
    test('market is open 09:15–15:30 IST on a trading day', () {
      expect(MarketCalendar.isMarketOpen(at: DateTime(2025, 9, 29, 9, 14)), isFalse);
      expect(MarketCalendar.isMarketOpen(at: DateTime(2025, 9, 29, 9, 15)), isTrue);
      expect(MarketCalendar.isMarketOpen(at: DateTime(2025, 9, 29, 15, 30)), isTrue);
      expect(MarketCalendar.isMarketOpen(at: DateTime(2025, 9, 29, 15, 31)), isFalse);
    });

    test('market is closed all day on a holiday', () {
      expect(MarketCalendar.isMarketOpen(at: DateTime(2026, 1, 26, 11, 0)), isFalse);
    });

    test('the daily scan window opens at 18:00 IST', () {
      expect(MarketCalendar.isDailyJobWindow(at: DateTime(2025, 9, 29, 17, 59)), isFalse);
      expect(MarketCalendar.isDailyJobWindow(at: DateTime(2025, 9, 29, 18, 0)), isTrue);
      expect(MarketCalendar.isDailyJobWindow(at: DateTime(2025, 9, 28, 18, 30)), isFalse);
    });
  });

  group('IST clock', () {
    test('nowIst() is UTC + 5:30, independent of the device timezone', () {
      final before = DateTime.now().toUtc();
      final ist = MarketCalendar.nowIst();
      final asUtc = ist.subtract(const Duration(hours: 5, minutes: 30));
      expect(asUtc.difference(before).inSeconds.abs() < 5, isTrue);
    });
  });

  group('Exchange codes', () {
    test('map to SmartAPI exchange strings and WebSocket exchange types', () {
      expect(Exchange.nse.code, 'NSE');
      expect(Exchange.nse.wsType, 1);
      expect(Exchange.bse.code, 'BSE');
      expect(Exchange.bse.wsType, 3);
      expect(Exchange.fromCode('bse'), Exchange.bse);
      expect(Exchange.fromCode('NSE'), Exchange.nse);
    });
  });
}
