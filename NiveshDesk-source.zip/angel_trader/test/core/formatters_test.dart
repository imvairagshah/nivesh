// Formatting tests — Indian digit grouping (lakh/crore) matters here: a wrong
// locale turns ₹1,00,000 into ₹100,000 and users notice immediately.

import 'package:angel_trader/core/utils/formatters.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('money', () {
    test('uses Indian lakh/crore grouping', () {
      expect(Fmt.money(100000), '₹1,00,000.00');
      expect(Fmt.money(1234.5), '₹1,234.50');
      expect(Fmt.money(12345678.9), '₹1,23,45,678.90');
    });

    test('renders null as an em dash instead of ₹0', () {
      expect(Fmt.money(null), '—');
    });
  });

  group('signed values', () {
    test('signedMoney prefixes + for gains and - for losses', () {
      expect(Fmt.signedMoney(4820.5), '+₹4,820.50');
      expect(Fmt.signedMoney(-2110), '-₹2,110.00');
    });

    test('signedPct formats with sign and two decimals', () {
      expect(Fmt.signedPct(3.456), '+3.46%');
      expect(Fmt.signedPct(-4.1), '-4.10%');
      expect(Fmt.signedPct(0), '0.00%');
    });
  });

  group('prices & quantities', () {
    test('price() keeps two decimals with grouping', () {
      expect(Fmt.price(1245.6), '1,245.60');
      expect(Fmt.price(87), '87.00');
    });

    test('qty() groups thousands', () {
      expect(Fmt.qty(1200), '1,200');
      expect(Fmt.qty(75), '75');
    });
  });

  group('dates', () {
    test('formats for display, storage and month buckets', () {
      final d = DateTime(2025, 9, 29, 15, 30);
      expect(Fmt.date(d), '29 Sep 2025');
      expect(Fmt.isoDate(d), '2025-09-29');
      expect(Fmt.monthLabel(d), 'Sep 2025');
      expect(Fmt.clock(d), '15:30:00');
    });

    test('parseDate accepts every format the app encounters', () {
      expect(Fmt.parseDate('2025-09-29'), DateTime(2025, 9, 29));
      expect(Fmt.parseDate('29-Sep-2025'), DateTime(2025, 9, 29));
      expect(Fmt.parseDate('10-Nov-2021'), DateTime(2021, 11, 10));
      expect(Fmt.parseDate('29/09/2025'), DateTime(2025, 9, 29));
      expect(Fmt.parseDate('2025-09-29T09:15:00+05:30'), isNotNull);
      expect(Fmt.parseDate('not a date'), isNull);
      expect(Fmt.parseDate(''), isNull);
      expect(Fmt.parseDate(null), isNull);
    });
  });

  group('relative freshness', () {
    final now = DateTime(2025, 9, 29, 12, 0);
    test('labels recent, minutes, hours and days', () {
      expect(Fmt.relative(now.subtract(const Duration(seconds: 10)), now: now), 'just now');
      expect(Fmt.relative(now.subtract(const Duration(minutes: 5)), now: now), '5m ago');
      expect(Fmt.relative(now.subtract(const Duration(hours: 3)), now: now), '3h ago');
      expect(Fmt.relative(now.subtract(const Duration(days: 4)), now: now), '4d ago');
      expect(Fmt.relative(null, now: now), 'never');
    });
  });
}
