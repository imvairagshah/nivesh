// ---------------------------------------------------------------------------
// paper_export_test.dart — Trade Book ka Export / Import.
//
// Asli SQLite (sqflite_common_ffi) ke saath chalaya jata hai, koi network nahi:
//   * TradeRange — "kaunse din" ka hisaab (default ALL)
//   * buildTradeLedger — kitaab ki chhantai
//   * Excel + PDF — asli file banti hai ya nahi
//   * DB export → import — **merge** hota hai, duplicate chhut jate hain,
//     purana data kabhi nahi mitta
//
//     flutter test test/features/paper_trading/paper_export_test.dart
// ---------------------------------------------------------------------------

import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/models/paper_trade.dart';
import 'package:angel_trader/data/local/models/trade_group.dart';
import 'package:angel_trader/features/paper_trading/paper_database_file.dart';
import 'package:angel_trader/features/paper_trading/paper_export.dart';
import 'package:angel_trader/features/paper_trading/trade_excel_export.dart';
import 'package:angel_trader/features/paper_trading/trade_ledger.dart';
import 'package:angel_trader/features/paper_trading/trade_pdf_export.dart';
import 'package:angel_trader/features/paper_trading/trade_range.dart';
import 'package:excel/excel.dart';
import 'package:pdf/pdf.dart' show TtfParser;
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

final DateTime _now = DateTime(2026, 10, 12, 15, 30);

Trade _trade({
  required String symbol,
  required DateTime at,
  int id = 0,
  String side = 'BUY',
  int qty = 10,
  double price = 100,
  double? pnl,
  double charges = 5,
  int? groupId,
  int? positionId,
}) =>
    Trade(
      id: id,
      symbol: symbol,
      exchange: Exchange.nse,
      token: '1001',
      side: side == 'BUY' ? OrderSide.buy : OrderSide.sell,
      quantity: qty,
      price: price,
      orderType: PaperOrderType.market,
      positionId: positionId,
      groupId: groupId,
      realizedPnl: pnl,
      charges: charges,
      executedAt: at,
      note: 'test',
    );

TradeGroup _group(int id, String name) => TradeGroup(
      id: id,
      name: name,
      colorIndex: id % 8,
      notes: '',
      createdAt: _now,
    );

/// Ek bilkul nayi, khaali DB file (asli schema ke saath).
Future<Database> _freshDb(String path) => openDatabase(
      path,
      version: AppDatabase.schemaVersion,
      onCreate: (db, version) => AppDatabase.createSchema(db),
    );

Future<int> _insertTrade(Database db, Map<String, Object?> row) =>
    db.insert(AppDatabase.tableTrades, row);

Map<String, Object?> _tradeRow({
  required String symbol,
  required int at,
  String side = 'BUY',
  int qty = 10,
  double price = 100,
  double? pnl,
  int? groupId,
  int? positionId,
}) =>
    {
      'symbol': symbol,
      'exchange': 'NSE',
      'token': '1001',
      'side': side,
      'quantity': qty,
      'price': price,
      'order_type': 'MARKET',
      'position_id': positionId,
      'group_id': groupId,
      'realized_pnl': pnl,
      'charges': 5.0,
      'executed_at': at,
      'note': 'test',
    };

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late Directory tmp;

  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() async {
    tmp = Directory.systemTemp.createTempSync('nd_export_test_');
  });

  tearDown(() async {
    if (await tmp.exists()) tmp.deleteSync(recursive: true);
  });

  // -------------------------------------------------------------------------
  group('TradeRange — kaunse din', () {
    test('default ALL hota hai — kuch bhi nahi chhanta', () {
      const range = TradeRange.all;
      expect(range.preset, TradeRangePreset.all);
      expect(range.isAll, isTrue);
      expect(range.resolveFrom(_now), isNull);
      expect(range.resolveTo(_now), isNull);
      expect(range.contains(DateTime(1999, 1, 1), _now), isTrue);
      expect(range.describe(_now), 'Sab (ALL)');
      expect(range.fileTag(_now), 'all');
    });

    test('aaj = sirf aaj ka din (subah se raat tak)', () {
      const range = TradeRange(preset: TradeRangePreset.today);
      final from = range.resolveFrom(_now)!;
      final to = range.resolveTo(_now)!;
      expect(from, DateTime(2026, 10, 12));
      expect(to, DateTime(2026, 10, 12, 23, 59, 59, 999));
      expect(range.contains(DateTime(2026, 10, 12, 9, 15), _now), isTrue);
      expect(range.contains(DateTime(2026, 10, 11, 23, 59), _now), isFalse);
    });

    test('1 mahina = aaj se 30 din pichhe (aaj samet 30 din)', () {
      const range = TradeRange(preset: TradeRangePreset.month1);
      final from = range.resolveFrom(_now)!;
      expect(from, DateTime(2026, 9, 13));
      expect(range.contains(DateTime(2026, 9, 13), _now), isTrue);
      expect(range.contains(DateTime(2026, 9, 12), _now), isFalse);
      expect(range.fileTag(_now), '30d');
    });

    test('custom me "se … tak" dono lagu hote hain', () {
      final range = TradeRange(
        preset: TradeRangePreset.custom,
        from: DateTime(2026, 1, 1),
        to: DateTime(2026, 3, 31),
      );
      expect(range.resolveFrom(_now), DateTime(2026, 1, 1));
      expect(range.resolveTo(_now), DateTime(2026, 3, 31, 23, 59, 59, 999));
      expect(range.describe(_now), '1 Jan 2026 – 31 Mar 2026');
      expect(range.fileTag(_now), '20260101-20260331');
      expect(range.contains(DateTime(2026, 3, 31, 22, 0), _now), isTrue);
      expect(range.contains(DateTime(2026, 4, 1), _now), isFalse);
    });

    test('sirf "se" chuna ho to "tak" usi din maan liya jata hai', () {
      final range = TradeRange(
        preset: TradeRangePreset.custom,
        from: DateTime(2026, 5, 4),
      );
      expect(range.resolveTo(_now), DateTime(2026, 5, 4, 23, 59, 59, 999));
    });
  });

  // -------------------------------------------------------------------------
  group('buildTradeLedger — kitaab ki chhantai', () {
    final trades = <Trade>[
      _trade(symbol: 'SBIN', at: DateTime(2026, 10, 12, 10), price: 100),
      _trade(
        symbol: 'SBIN',
        at: DateTime(2026, 10, 12, 11),
        side: 'SELL',
        price: 110,
        pnl: 95,
      ),
      _trade(symbol: 'TATA', at: DateTime(2026, 9, 1, 10), price: 200),
      _trade(
        symbol: 'TATA',
        at: DateTime(2026, 9, 2, 10),
        side: 'SELL',
        price: 190,
        pnl: -105,
        groupId: 7,
      ),
    ];

    test('ALL me sab kuch aata hai, naye se purane', () {
      final ledger = buildTradeLedger(
        trades: trades,
        groups: [_group(7, 'Momentum')],
        range: TradeRange.all,
        now: _now,
      );
      expect(ledger.rows.length, 4);
      // Naye se purane: 12 Oct 11:00 sabse upar, 1 Sep sabse niche.
      expect(ledger.rows.first.symbol, 'SBIN');
      expect(ledger.rows.first.executedAt, DateTime(2026, 10, 12, 11));
      expect(ledger.rows.last.executedAt, DateTime(2026, 9, 1, 10));
      expect(ledger.summary.legs, 4);
      expect(ledger.summary.closingLegs, 2);
      expect(ledger.summary.wins, 1);
      expect(ledger.summary.winRateText, '50%');
      expect(ledger.summary.realized, -10);
      expect(ledger.summary.charges, 20);
      expect(ledger.summary.net, -30);
    });

    test('range chhant-ta hai — sirf October', () {
      final ledger = buildTradeLedger(
        trades: trades,
        groups: const [],
        range: const TradeRange(preset: TradeRangePreset.month1),
        now: _now,
      );
      expect(ledger.rows.length, 2);
      expect(ledger.rows.every((r) => r.symbol == 'SBIN'), isTrue);
      expect(ledger.summary.closingLegs, 1);
      expect(ledger.summary.wins, 1);
      expect(ledger.summary.winRateText, '100%');
    });

    test('group ke hisaab se bhi chhanta hai', () {
      final ledger = buildTradeLedger(
        trades: trades,
        groups: [_group(7, 'Momentum')],
        range: TradeRange.all,
        now: _now,
        groupId: 7,
        groupLabel: 'Momentum',
      );
      expect(ledger.rows.length, 1);
      expect(ledger.rows.single.group, 'Momentum');
      expect(ledger.summary.groupLabel, 'Momentum');
    });

    test('khali ho to win rate "-" dikhta hai, 0 nahi', () {
      final ledger = buildTradeLedger(
        trades: const <Trade>[],
        groups: const [],
        range: TradeRange.all,
        now: _now,
      );
      expect(ledger.isEmpty, isTrue);
      expect(ledger.summary.winRateText, '—');
      expect(ledger.summary.legs, 0);
    });

    test('bina group wale trade ko "Ungrouped" likha jata hai', () {
      final ledger = buildTradeLedger(
        trades: trades,
        groups: const [],
        range: TradeRange.all,
        now: _now,
      );
      expect(ledger.rows.every((r) => r.group == 'Ungrouped'), isTrue);
    });
  });

  // -------------------------------------------------------------------------
  group('Excel', () {
    test('asli .xlsx banta hai — 3 sheet, har leg ki line', () async {
      final ledger = buildTradeLedger(
        trades: [
          _trade(symbol: 'SBIN', at: DateTime(2026, 10, 12, 10)),
          _trade(
            symbol: 'SBIN',
            at: DateTime(2026, 10, 12, 11),
            side: 'SELL',
            pnl: 95,
          ),
        ],
        groups: const [],
        range: TradeRange.all,
        now: _now,
      );

      final file = await TradeExcelExport(directory: tmp)
          .write(ledger: ledger, fileName: 'test.xlsx');

      expect(await file.exists(), isTrue);
      expect(file.path, endsWith('test.xlsx'));
      expect(await file.length(), greaterThan(3000));

      final book = Excel.decodeBytes(await file.readAsBytes());
      expect(book.sheets.keys, contains('Hisaab'));
      expect(book.sheets.keys, contains('Legs'));
      expect(book.sheets.keys, contains('Matlab'));

      final legs = book['Legs'];
      final header = legs.row(0).map((c) => c?.value?.toString()).toList();
      expect(header.first, 'Date');
      expect(header, contains('Realised P&L'));

      // header + 2 legs
      expect(legs.rows.length, 3);
      final first = legs.row(1).map((c) => c?.value?.toString()).toList();
      expect(first[2], 'SBIN'); // Symbol
      expect(first[3], 'SELL'); // Side (naye se purane, SELL upar)
      expect(first[8], '95'); // Realised P&L — Excel me number, text nahi
    });
  });

  // -------------------------------------------------------------------------
  group('PDF', () {
    test('asli PDF banta hai — bundle hue font ke saath', () async {
      Future<ByteData> loader(String path) async {
        final bytes = await File(path).readAsBytes();
        return ByteData.view(bytes.buffer);
      }

      final ledger = buildTradeLedger(
        trades: [
          _trade(symbol: 'SBIN', at: DateTime(2026, 10, 12, 10)),
          _trade(
            symbol: 'SBIN',
            at: DateTime(2026, 10, 12, 11),
            side: 'SELL',
            pnl: 95,
          ),
        ],
        groups: const [],
        range: TradeRange.all,
        now: _now,
      );

      final bytes = await TradePdfExport(loader: loader).build(ledger);

      expect(bytes.length, greaterThan(2000));
      expect(ascii.decode(bytes.sublist(0, 5)), '%PDF-');
      // Rupaye ka nishan aur symbol dono PDF me likhe jate hain (compressed
      // stream ke andar), par header aur footer turant dikh jate hain.
      final text = latin1.decode(bytes, allowInvalid: true);
      expect(text, contains('NiveshDesk'));
    });

    test('bundle hue font me rupee ka nishan hai (warna PDF me ₹ nahi dikhega)',
        () async {
      for (final path in [
        TradePdfExport.regularFontPath,
        TradePdfExport.boldFontPath,
      ]) {
        final bytes = await File(path).readAsBytes();
        final parser = TtfParser(ByteData.view(bytes.buffer));
        expect(
          parser.charToGlyphIndexMap.containsKey(0x20B9),
          isTrue,
          reason: '$path me ₹ (U+20B9) hona chahiye — PDF ka paisa isi se '
              'chhapta hai',
        );
      }
    });

    test('Hindi akshar wale group ka naam PDF me badal diya jata hai', () {
      expect(asciiSafe('Momentum'), 'Momentum');
      final hindi = asciiSafe('रिजल्ट प्ले');
      expect(hindi.codeUnits.every((u) => u < 128), isTrue);
      expect(hindi, '?????? ????');
      expect(asciiSafe('₹1,200'), '₹1,200');
    });
  });

  // -------------------------------------------------------------------------
  group('DB file — copy aur merge', () {
    test('range ke hisaab se copy hoti hai (custom me sirf chune hue din)',
        () async {
      final source = await _freshDb('${tmp.path}/source.db');
      final groupId =
          await source.insert(AppDatabase.tableTradeGroups, <String, Object?>{
        'name': 'Momentum',
        'color_index': 1,
        'notes': '',
        'archived': 0,
        'created_at': _now.millisecondsSinceEpoch,
      });
      await _insertTrade(
        source,
        _tradeRow(symbol: 'SBIN', at: DateTime(2026, 10, 12, 10).millisecondsSinceEpoch, groupId: groupId),
      );
      await _insertTrade(
        source,
        _tradeRow(symbol: 'OLD', at: DateTime(2025, 1, 2, 10).millisecondsSinceEpoch),
      );

      final target = await _freshDb('${tmp.path}/target.db');
      final stats = await copyTradingTables(
        source: source,
        target: target,
        from: DateTime(2026, 1, 1).millisecondsSinceEpoch,
        to: DateTime(2026, 12, 31).millisecondsSinceEpoch,
      );

      expect(stats.trades, 1);
      expect(stats.groups, 1, reason: 'istamal hua group bhi jana chahiye');

      final rows = await target.query(AppDatabase.tableTrades);
      expect(rows.single['symbol'], 'SBIN');
      // Group ki id badal sakti hai, par trade usi se juda rahe.
      final groups = await target.query(AppDatabase.tableTradeGroups);
      expect(groups.single['name'], 'Momentum');
      expect(rows.single['group_id'], groups.single['id']);

      await source.close();
      await target.close();
    });

    test('merge: do alag DB me naye trade judte hain, purane mit-te nahi',
        () async {
      final source = await _freshDb('${tmp.path}/src.db');
      final target = await _freshDb('${tmp.path}/dst.db');

      final srcGroup =
          await source.insert(AppDatabase.tableTradeGroups, <String, Object?>{
        'name': 'Momentum',
        'color_index': 1,
        'notes': '',
        'archived': 0,
        'created_at': _now.millisecondsSinceEpoch,
      });
      // Nayi id chahiye — target me 'Momentum' pehle se hai, to id alag hogi.
      await target.insert(AppDatabase.tableTradeGroups, <String, Object?>{
        'name': 'momentum', // case-insensitive milan
        'color_index': 3,
        'notes': '',
        'archived': 0,
        'created_at': _now.millisecondsSinceEpoch,
      });

      final srcPosition = await source.insert(
        AppDatabase.tablePositions,
        <String, Object?>{
          'symbol': 'SBIN',
          'exchange': 'NSE',
          'token': '1001',
          'quantity': 10,
          'side': 'long',
          'avg_price': 100.0,
          'group_id': srcGroup,
          'charges_paid': 5.0,
          'opened_at': DateTime(2026, 10, 12, 10).millisecondsSinceEpoch,
          'status': 'OPEN',
        },
      );
      await _insertTrade(
        source,
        _tradeRow(
          symbol: 'SBIN',
          at: DateTime(2026, 10, 12, 10).millisecondsSinceEpoch,
          groupId: srcGroup,
          positionId: srcPosition,
        ),
      );
      await _insertTrade(
        source,
        _tradeRow(
          symbol: 'TATA',
          at: DateTime(2026, 10, 12, 11).millisecondsSinceEpoch,
        ),
      );

      final report = await mergeTradingTables(source: source, target: target);

      expect(report.tradesAdded, 2);
      expect(report.tradesSkipped, 0);
      expect(report.positionsAdded, 1);
      expect(report.openPositionsAdded, 1);
      expect(report.groupsAdded, 0, reason: 'naam se milan — haseena ko dubara banana nahi');
      expect(report.groupsMatched, 1);
      expect(report.added, 3);
      expect(report.message, contains('Jod diya: 2 naye trade'));
      expect(report.message, contains('Holdings tab me ek baar dekh lo'));

      // Trade, target ke group se juda hona chahiye (source ki id se nahi).
      final dstGroups = await target.query(AppDatabase.tableTradeGroups);
      expect(dstGroups.length, 1);
      final saved = await target.query(
        AppDatabase.tableTrades,
        where: 'symbol = ?',
        whereArgs: ['SBIN'],
      );
      expect(saved.single['group_id'], dstGroups.single['id']);
      expect(saved.single['position_id'], isNotNull);

      // Doosri baar merge — sab duplicate, kuch nahi juda.
      final again = await mergeTradingTables(source: source, target: target);
      expect(again.tradesAdded, 0);
      expect(again.tradesSkipped, 2);
      expect(again.positionsAdded, 0);
      expect(again.positionsMatched, 1);
      expect(again.added, 0);
      expect(again.isEmpty, isTrue);
      expect(again.message, contains('Kuch naya nahi mila'));

      await source.close();
      await target.close();
    });

    test('merge me purana data kabhi nahi mitta', () async {
      final source = await _freshDb('${tmp.path}/s2.db');
      final target = await _freshDb('${tmp.path}/d2.db');

      await _insertTrade(
        target,
        _tradeRow(
          symbol: 'PURANA',
          at: DateTime(2026, 10, 1, 10).millisecondsSinceEpoch,
        ),
      );
      await _insertTrade(
        source,
        _tradeRow(
          symbol: 'NAYA',
          at: DateTime(2026, 10, 2, 10).millisecondsSinceEpoch,
        ),
      );

      await mergeTradingTables(source: source, target: target);

      final rows = await target.query(AppDatabase.tableTrades,
          columns: ['symbol'], orderBy: 'executed_at ASC');
      expect(rows.map((r) => r['symbol']).toList(), ['PURANA', 'NAYA']);

      await source.close();
      await target.close();
    });
  });

  // -------------------------------------------------------------------------
  group('PaperDatabaseFile — file ke saath', () {
    setUp(() async {
      AppDatabase.overridePath = inMemoryDatabasePath;
      await AppDatabase.instance.close();
    });

    tearDown(() async {
      await AppDatabase.instance.close();
      AppDatabase.overridePath = null;
    });

    Future<void> seedTwoTrades() async {
      final db = await AppDatabase.instance.database;
      await _insertTrade(
        db,
        _tradeRow(symbol: 'SBIN', at: DateTime(2026, 10, 12, 10).millisecondsSinceEpoch),
      );
      await _insertTrade(
        db,
        _tradeRow(
          symbol: 'TATA',
          at: DateTime(2026, 10, 12, 11).millisecondsSinceEpoch,
          side: 'SELL',
          pnl: 40,
        ),
      );
    }

    test('export → file asli SQLite hoti hai, andar wahi trades', () async {
      await seedTwoTrades();
      final files = PaperDatabaseFile(
        database: AppDatabase.instance,
        directory: tmp,
        now: () => _now,
      );

      final exported =
          await files.exportRange(range: TradeRange.all, now: _now);

      expect(await exported.exists(), isTrue);
      expect(exported.path, contains('niveshdesk-db-all-'));
      expect(exported.path, endsWith('.db'));
      expect(await PaperDatabaseFile.looksLikeSqlite(exported), isTrue);

      final copy = await openReadOnlyDatabase(exported.path);
      final rows = await copy.query(AppDatabase.tableTrades);
      expect(rows.length, 2);
      await copy.close();
    });

    test('ALL me poora DB (master + candles + settings) copy hota hai',
        () async {
      await seedTwoTrades();
      final files = PaperDatabaseFile(
        database: AppDatabase.instance,
        directory: tmp,
        now: () => _now,
      );

      final all = await files.exportAll();

      expect(await all.exists(), isTrue);
      expect(await PaperDatabaseFile.looksLikeSqlite(all), isTrue);
      final copy = await openReadOnlyDatabase(all.path);
      expect((await copy.query(AppDatabase.tableTrades)).length, 2);
      // Poore DB ki nishani: sabhi taalikayein andar hain.
      for (final table in const ['scrips', 'candles', 'settings', 'trades']) {
        final found = Sqflite.firstIntValue(await copy.rawQuery(
          "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=?",
          [table],
        ));
        expect(found, 1, reason: '$table taalika file me honi chahiye');
      }
      await copy.close();
    });

    test('custom date me sirf chune hue din jate hain', () async {
      await seedTwoTrades();
      final db = await AppDatabase.instance.database;
      await _insertTrade(
        db,
        _tradeRow(symbol: 'OLD', at: DateTime(2024, 3, 1, 9).millisecondsSinceEpoch),
      );

      final files = PaperDatabaseFile(
        database: AppDatabase.instance,
        directory: tmp,
        now: () => _now,
      );
      final exported = await files.exportRange(
        range: TradeRange(
          preset: TradeRangePreset.custom,
          from: DateTime(2026, 10, 1),
          to: DateTime(2026, 10, 31),
        ),
        now: _now,
      );

      final copy = await openReadOnlyDatabase(exported.path);
      final rows = await copy.query(AppDatabase.tableTrades, columns: ['symbol']);
      expect(rows.map((r) => r['symbol']).toSet(), {'SBIN', 'TATA'});
      await copy.close();
    });

    test('import: wahi file wapas lane par sab duplicate chhut jate hain',
        () async {
      await seedTwoTrades();
      final files = PaperDatabaseFile(
        database: AppDatabase.instance,
        directory: tmp,
        now: () => _now,
      );
      final exported =
          await files.exportRange(range: TradeRange.all, now: _now);

      final outcome = await PaperExportService(databaseFile: files)
          .importDatabase(file: exported);

      expect(outcome.ok, isTrue);
      expect(outcome.report!.tradesAdded, 0);
      expect(outcome.report!.tradesSkipped, 2);
      expect(outcome.message, contains('Kuch naya nahi mila'));

      // Aur DB me ab bhi 2 hi trade hain — koi double nahi hua.
      final db = await AppDatabase.instance.database;
      final rows = await db.query(AppDatabase.tableTrades);
      expect(rows.length, 2);
    });

    test('import: mita hua trade wapas jud jata hai', () async {
      await seedTwoTrades();
      final files = PaperDatabaseFile(
        database: AppDatabase.instance,
        directory: tmp,
        now: () => _now,
      );
      final exported =
          await files.exportRange(range: TradeRange.all, now: _now);

      final db = await AppDatabase.instance.database;
      await db.delete(
        AppDatabase.tableTrades,
        where: 'symbol = ?',
        whereArgs: ['TATA'],
      );
      expect((await db.query(AppDatabase.tableTrades)).length, 1);

      final outcome = await PaperExportService(databaseFile: files)
          .importDatabase(file: exported);

      expect(outcome.ok, isTrue);
      expect(outcome.report!.tradesAdded, 1);
      expect(outcome.report!.tradesSkipped, 1);
      expect((await db.query(AppDatabase.tableTrades)).length, 2);
    });

    test('galat schema wali file se kuch bhi nahi badalta', () async {
      await seedTwoTrades();
      // Purane app version wali DB: schema 3, aur trades taalika hi nahi.
      final junkPath = '${tmp.path}/puraani.db';
      final purani = await openDatabase(
        junkPath,
        version: 3,
        onCreate: (db, version) =>
            db.execute('CREATE TABLE purani (id INTEGER PRIMARY KEY)'),
      );
      await purani.close();
      final junk = File(junkPath);

      final files = PaperDatabaseFile(
        database: AppDatabase.instance,
        directory: tmp,
        now: () => _now,
      );
      final outcome = await PaperExportService(databaseFile: files)
          .importDatabase(file: junk);

      expect(outcome.ok, isFalse);
      expect(outcome.message, contains('match nahi karti'));
      expect(outcome.message, contains('Kuch bhi change nahi kiya gaya'));

      final db = await AppDatabase.instance.database;
      expect((await db.query(AppDatabase.tableTrades)).length, 2);
    });

    test('DB file na ho to saaf message, kuch chhue bina', () async {
      await seedTwoTrades();
      final junk = File('${tmp.path}/kachra.db')
        ..writeAsStringSync('ye koi database nahi hai');
      final outcome = await PaperExportService()
          .importDatabase(file: junk);
      expect(outcome.ok, isFalse);
      expect(outcome.message, contains('DB file nahi lagti'));
    });
  });

  // -------------------------------------------------------------------------
  group('PaperExportService — PDF / Excel', () {
    test('file ka naam format aur range ke hisaab se banta hai', () {
      expect(
        PaperExportService.fileName(PaperExportKind.pdf, TradeRange.all, _now),
        'niveshdesk-all-20261012-1530.pdf',
      );
      expect(
        PaperExportService.fileName(
          PaperExportKind.excel,
          TradeRange(
            preset: TradeRangePreset.custom,
            from: DateTime(2026, 1, 1),
            to: DateTime(2026, 3, 31),
          ),
          _now,
        ),
        'niveshdesk-20260101-20260331-20261012-1530.xlsx',
      );
    });

    test('khali daayra ho to export mana kar deta hai (khali file nahi banti)',
        () async {
      final outcome = await PaperExportService(
        excel: TradeExcelExport(directory: tmp),
        shareFile: (_, __) async {},
      ).exportLedger(
        kind: PaperExportKind.excel,
        trades: const <Trade>[],
        groups: const <TradeGroup>[],
        range: TradeRange.all,
        now: _now,
      );
      expect(outcome.ok, isFalse);
      expect(outcome.message, contains('koi leg nahi mili'));
    });

    test('Excel export: file banti hai aur share sheet khulta hai', () async {
      File? shared;
      final outcome = await PaperExportService(
        excel: TradeExcelExport(directory: tmp),
        shareFile: (file, subject) async {
          shared = file;
          expect(subject, 'NiveshDesk Paper Trading');
        },
      ).exportLedger(
        kind: PaperExportKind.excel,
        trades: [
          _trade(symbol: 'SBIN', at: DateTime(2026, 10, 12, 10)),
        ],
        groups: const [],
        range: TradeRange.all,
        now: _now,
        groupLabel: 'Sab group',
      );

      expect(outcome.ok, isTrue);
      expect(outcome.message, contains('1 leg, 0 band'));
      expect(shared, isNotNull);
      expect(await shared!.exists(), isTrue);
      expect(await shared!.length(), greaterThan(3000));
    });
  });
}
