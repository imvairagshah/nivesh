// ---------------------------------------------------------------------------
// order_engine_test.dart — fill rules, stop-loss resolution and the position
// book-keeping maths (the part that has to be right or the P&L lies).
//
// Charges are passed in as explicit numbers here so that a failure points at the
// book-keeping, not at charges.dart (which has its own test file).
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/models/paper_trade.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/features/paper_trading/charges.dart';
import 'package:angel_trader/features/paper_trading/order_engine.dart';
import 'package:flutter_test/flutter_test.dart';

const _sbin = Scrip(
  token: '3045',
  symbol: 'SBIN-EQ',
  name: 'SBIN',
  exchange: Exchange.nse,
);

/// An NFO option contract — the F&O cases below trade this, not `_sbin`.
const _option = Scrip(
  token: '7001',
  symbol: 'SBIN26OCT800CE',
  name: 'SBIN 800 CE',
  exchange: Exchange.nfo,
);

final _t0 = DateTime(2025, 9, 29, 10, 15);
final _t1 = DateTime(2025, 9, 30, 14, 30);

OrderDraft _draft({
  OrderSide side = OrderSide.buy,
  int quantity = 100,
  PaperOrderType orderType = PaperOrderType.market,
  double? limitPrice,
  double? stopLossPrice,
  double? stopLossPct,
  double? targetPrice,
  Scrip scrip = _sbin,
}) =>
    OrderDraft(
      scrip: scrip,
      side: side,
      quantity: quantity,
      orderType: orderType,
      limitPrice: limitPrice,
      stopLossPrice: stopLossPrice,
      stopLossPct: stopLossPct,
      targetPrice: targetPrice,
    );

void main() {
  group('fill rules', () {
    test('a MARKET order fills at the live LTP', () {
      expect(OrderEngine.marketFillPrice(1234.5), 1234.5);
    });

    test('a MARKET order cannot fill without a price', () {
      expect(OrderEngine.marketFillPrice(null), isNull);
      expect(OrderEngine.marketFillPrice(0), isNull);
    });

    test('a BUY limit above the market fills at the market (price improvement)',
        () {
      expect(
        OrderEngine.limitFillPrice(side: OrderSide.buy, limitPrice: 105, ltp: 100),
        100,
      );
      expect(
        OrderEngine.limitFillPrice(side: OrderSide.buy, limitPrice: 100, ltp: 100),
        100,
      );
    });

    test('a BUY limit below the market rests', () {
      expect(
        OrderEngine.limitFillPrice(side: OrderSide.buy, limitPrice: 95, ltp: 100),
        isNull,
      );
    });

    test('a SELL limit below the market fills, above it rests', () {
      expect(
        OrderEngine.limitFillPrice(side: OrderSide.sell, limitPrice: 95, ltp: 100),
        100,
      );
      expect(
        OrderEngine.limitFillPrice(side: OrderSide.sell, limitPrice: 105, ltp: 100),
        isNull,
      );
    });

    test('isMarketable reads the resting order, not a raw limit', () {
      final resting = PaperOrder(
        symbol: 'SBIN-EQ',
        exchange: Exchange.nse,
        side: OrderSide.buy,
        quantity: 10,
        orderType: PaperOrderType.limit,
        limitPrice: 90,
        createdAt: _t0,
      );
      expect(OrderEngine.isMarketable(resting, 100), isFalse);
      expect(OrderEngine.isMarketable(resting, 90), isTrue); // touched
      expect(OrderEngine.isMarketable(resting, 85), isTrue); // traded through
    });
  });

  group('tick rounding', () {
    test('rounds to the nearest tick in the requested direction', () {
      expect(OrderEngine.tickRound(1234.567, 0.05), 1234.60); // up
      expect(OrderEngine.tickRound(1234.567, 0.05, up: false), 1234.55);
      expect(OrderEngine.tickRound(1000, 0.05), 1000);
    });

    test('never leaves floating-point dust behind', () {
      expect(OrderEngine.tickRound(1234.05, 0.05), 1234.05);
      expect(OrderEngine.tickRound(99.99, 0.05), 100.00);
    });
  });

  group('stop-loss / target resolution', () {
    test('a percentage stop sits below the entry', () {
      expect(OrderEngine.resolveStopLoss(entry: 1000, stopLossPct: 5), 950);
      expect(OrderEngine.resolveStopLoss(entry: 1000, stopLossPct: 2.5), 975);
    });

    test('a price stop is used as given when it is below the entry', () {
      expect(OrderEngine.resolveStopLoss(entry: 1000, stopLossPrice: 940), 940);
    });

    test('a stop at or above the entry is clamped a tick below', () {
      expect(
        OrderEngine.resolveStopLoss(entry: 1000, stopLossPrice: 1010),
        999.95,
      );
    });

    test('an explicit price wins over a percentage', () {
      expect(
        OrderEngine.resolveStopLoss(
          entry: 1000,
          stopLossPrice: 980,
          stopLossPct: 5,
        ),
        980,
      );
    });

    test('no stop loss requested means no stop', () {
      expect(OrderEngine.resolveStopLoss(entry: 1000), isNull);
      expect(OrderEngine.resolveStopLoss(entry: 1000, stopLossPct: 0), isNull);
    });

    test('a target must be above the entry to count', () {
      expect(OrderEngine.resolveTarget(entry: 1000, targetPrice: 1200), 1200);
      expect(OrderEngine.resolveTarget(entry: 1000, targetPrice: 900), isNull);
      expect(OrderEngine.resolveTarget(entry: 1000), isNull);
    });

    test('stopPctFor is the inverse of a percentage stop', () {
      expect(OrderEngine.stopPctFor(entry: 1000, stopLoss: 950), 5);
      expect(OrderEngine.stopPctFor(entry: 1000, stopLoss: null), isNull);
    });
  });

  group('break-even price', () {
    test('sits a little above the entry, by roughly the round-trip cost', () {
      final be = OrderEngine.breakEvenPrice(
        entryPrice: 1000,
        quantity: 100,
        exchange: Exchange.nse,
      );
      expect(be, closeTo(1002.3842, 0.01));
    });

    test('selling exactly at break-even yields ~zero net P&L', () {
      const qty = 100;
      const entry = 1000.0;
      final be = OrderEngine.breakEvenPrice(
        entryPrice: entry,
        quantity: qty,
        exchange: Exchange.nse,
      );

      final openCharges = EquityCharges.compute(
        side: OrderSide.buy,
        price: entry,
        quantity: qty,
        exchange: Exchange.nse,
      ).total;
      final exitCharges = EquityCharges.compute(
        side: OrderSide.sell,
        price: be,
        quantity: qty,
        exchange: Exchange.nse,
      ).total;

      final net = (be - entry) * qty - openCharges - exitCharges;
      expect(net, closeTo(0, 0.05));
    });
  });

  group('applyBuy — opening and adding', () {
    test('opens a new long position with the entry group and stop', () {
      final update = OrderEngine.applyBuy(
        current: null,
        scrip: _sbin,
        quantity: 100,
        price: 1000,
        charges: 118.62,
        at: _t0,
        stopLoss: 950,
        target: 1200,
        groupId: 7,
      );

      final p = update.position;
      expect(update.realizedPnl, isNull); // opening legs book no P&L
      expect(p.quantity, 100);
      expect(p.avgPrice, 1000);
      expect(p.chargesPaid, 118.62);
      expect(p.stopLoss, 950);
      expect(p.target, 1200);
      expect(p.groupId, 7);
      expect(p.status, PositionStatus.open);
      expect(p.openedAt, _t0);
      expect(p.symbol, 'SBIN-EQ');
    });

    test('adding to a position re-averages the cost and accumulates charges', () {
      final first = OrderEngine.applyBuy(
        current: null,
        scrip: _sbin,
        quantity: 100,
        price: 1000,
        charges: 118.62,
        at: _t0,
      ).position;

      final second = OrderEngine.applyBuy(
        current: first,
        scrip: _sbin,
        quantity: 100,
        price: 1100,
        charges: 120.00,
        at: _t1,
      ).position;

      expect(second.quantity, 200);
      expect(second.avgPrice, 1050); // (1000×100 + 1100×100) / 200
      expect(second.chargesPaid, closeTo(238.62, 0.001));
      expect(second.openedAt, _t0); // the original entry time is kept
    });

    test('an add keeps the existing group when the new draft has none', () {
      final first = OrderEngine.applyBuy(
        current: null,
        scrip: _sbin,
        quantity: 10,
        price: 100,
        charges: 1,
        at: _t0,
        groupId: 3,
      ).position;

      final second = OrderEngine.applyBuy(
        current: first,
        scrip: _sbin,
        quantity: 10,
        price: 110,
        charges: 1,
        at: _t1,
        groupId: null,
      ).position;

      expect(second.groupId, 3);
    });
  });

  group('applySell — partial and full exits', () {
    Position heldPosition() => Position(
          id: 1,
          symbol: 'SBIN-EQ',
          exchange: Exchange.nse,
          token: '3045',
          quantity: 200,
          avgPrice: 1050,
          chargesPaid: 238.62,
          openedAt: _t0,
          groupId: 4,
        );

    test('a partial exit books P&L net of its share of the opening charges', () {
      final update = OrderEngine.applySell(
        current: heldPosition(),
        quantity: 100,
        price: 1120,
        charges: 130,
        at: _t1,
      );

      // gross = (1120 − 1050) × 100 = 7000
      // opening charges retired = 238.62 × 100/200 = 119.31
      // realised = 7000 − 119.31 − 130 = 6750.69
      expect(update.realizedPnl, closeTo(6750.69, 0.001));

      final p = update.position;
      expect(p.quantity, 100);
      expect(p.avgPrice, 1050); // a sale never changes the average cost
      expect(p.chargesPaid, closeTo(119.31, 0.001));
      expect(p.status, PositionStatus.open);
      expect(p.closedAt, isNull);
    });

    test('a full exit closes the position and clears its charges', () {
      final single = Position(
        id: 2,
        symbol: 'SBIN-EQ',
        exchange: Exchange.nse,
        quantity: 100,
        avgPrice: 1000,
        chargesPaid: 118.62,
        openedAt: _t0,
      );

      final update = OrderEngine.applySell(
        current: single,
        quantity: 100,
        price: 1100,
        charges: 119.55,
        at: _t1,
      );

      // gross = 10,000 − 118.62 opening − 119.55 exit = 9761.83
      expect(update.realizedPnl, closeTo(9761.83, 0.001));
      expect(update.position.quantity, 0);
      expect(update.position.status, PositionStatus.closed);
      expect(update.position.closedAt, _t1);
      expect(update.position.chargesPaid, 0);
    });

    test('a losing exit books a negative number', () {
      final update = OrderEngine.applySell(
        current: heldPosition(),
        quantity: 200,
        price: 900,
        charges: 120,
        at: _t1,
      );
      // (900 − 1050) × 200 = −30,000 − 238.62 − 120
      expect(update.realizedPnl, closeTo(-30358.62, 0.001));
      expect(update.position.status, PositionStatus.closed);
    });

    test('selling more than is held is clamped, never negative', () {
      final update = OrderEngine.applySell(
        current: heldPosition(),
        quantity: 500,
        price: 1100,
        charges: 100,
        at: _t1,
      );
      expect(update.position.quantity, 0);
      expect(update.position.status, PositionStatus.closed);
      expect(update.realizedPnl, isNotNull);
    });
  });

  group('validation', () {
    test('a market buy with enough cash passes (with a no-stop warning)', () {
      final check = OrderEngine.check(
        draft: _draft(),
        ltp: 1000,
        position: null,
        availableCash: 200000,
      );

      expect(check.isValid, isTrue);
      expect(check.warnings, contains(contains('No stop-loss')));
    });

    test('a market buy without cash is blocked and says how much is short', () {
      final check = OrderEngine.check(
        draft: _draft(),
        ltp: 1000,
        position: null,
        availableCash: 100000, // needs 1,00,118.62
      );

      expect(check.isValid, isFalse);
      expect(check.firstError, contains('Not enough virtual cash'));
      expect(check.firstError, contains('100119')); // rounded need
    });

    test('a market order without a live price is blocked', () {
      final check = OrderEngine.check(
        draft: _draft(),
        ltp: null,
        position: null,
        availableCash: 200000,
      );
      expect(check.isValid, isFalse);
      expect(check.firstError, contains('No live price'));
    });

    test('a limit order can be placed without a price, but needs a limit', () {
      final noPrice = OrderEngine.check(
        draft: _draft(
          orderType: PaperOrderType.limit,
          limitPrice: 900,
          stopLossPct: 3,
        ),
        ltp: null,
        position: null,
        availableCash: 200000,
      );
      expect(noPrice.isValid, isTrue);

      final noLimit = OrderEngine.check(
        draft: _draft(orderType: PaperOrderType.limit),
        ltp: 1000,
        position: null,
        availableCash: 200000,
      );
      expect(noLimit.isValid, isFalse);
      expect(noLimit.firstError, contains('limit price'));
    });

    test('selling without a position is refused (long-only)', () {
      final check = OrderEngine.check(
        draft: _draft(side: OrderSide.sell),
        ltp: 1000,
        position: null,
        availableCash: 0,
      );
      expect(check.isValid, isFalse);
      expect(check.firstError, contains('No open position'));
    });

    test('selling more shares than are held is refused, with the count', () {
      final position = Position(
        symbol: 'SBIN-EQ',
        exchange: Exchange.nse,
        quantity: 40,
        avgPrice: 1000,
        openedAt: _t0,
      );
      final check = OrderEngine.check(
        draft: _draft(side: OrderSide.sell, quantity: 100),
        ltp: 1000,
        position: position,
        availableCash: 0,
      );
      expect(check.isValid, isFalse);
      expect(check.firstError, contains('You hold 40 shares'));
    });

    test('a sell is not judged on cash', () {
      final position = Position(
        symbol: 'SBIN-EQ',
        exchange: Exchange.nse,
        quantity: 100,
        avgPrice: 1000,
        openedAt: _t0,
      );
      final check = OrderEngine.check(
        draft: _draft(side: OrderSide.sell),
        ltp: 1000,
        position: position,
        availableCash: 0, // broke, but selling is allowed
      );
      expect(check.isValid, isTrue);
    });

    test('quantity guards', () {
      expect(
        OrderEngine.check(
          draft: _draft(quantity: 0),
          ltp: 1000,
          position: null,
          availableCash: 1000000,
        ).firstError,
        contains('at least 1 share'),
      );
      expect(
        OrderEngine.check(
          draft: _draft(quantity: OrderEngine.maxQuantity + 1),
          ltp: 1000,
          position: null,
          availableCash: 100000000,
        ).firstError,
        contains('capped'),
      );
    });

    test('a too-tight or too-wide stop is a warning, not an error', () {
      final tight = OrderEngine.check(
        draft: _draft(stopLossPct: 0.2),
        ltp: 1000,
        position: null,
        availableCash: 200000,
      );
      expect(tight.isValid, isTrue);
      expect(tight.warnings, contains(contains('normal noise')));

      final wide = OrderEngine.check(
        draft: _draft(stopLossPct: 60),
        ltp: 1000,
        position: null,
        availableCash: 200000,
      );
      expect(wide.isValid, isTrue);
      expect(wide.warnings, contains(contains('half the position value')));
    });

    test('a limit far from the market warns about immediate fill', () {
      final check = OrderEngine.check(
        draft: _draft(
          orderType: PaperOrderType.limit,
          limitPrice: 1300, // 30% above a 1000 market
        ),
        ltp: 1000,
        position: null,
        availableCash: 200000,
      );
      expect(check.warnings, contains(contains('fill immediately')));
    });

    test('the pending-order cap is enforced', () {
      final check = OrderEngine.check(
        draft: _draft(orderType: PaperOrderType.limit, limitPrice: 900),
        ltp: 1000,
        position: null,
        availableCash: 200000,
        pendingOrderCount: OrderEngine.maxPendingOrders,
      );
      expect(check.isValid, isFalse);
      expect(check.firstError, contains('pending orders'));
    });
  });

  group('preview', () {
    test('a market buy reports cost, charges and break-even', () {
      final preview = OrderEngine.preview(draft: _draft(), ltp: 1000);

      expect(preview.referencePrice, 1000);
      expect(preview.turnover, 100000);
      expect(preview.charges.total, 118.62);
      expect(preview.cashRequired, 100118.62);
      expect(preview.cashReleased, 0);
      expect(preview.breakEvenPrice, closeTo(1002.3842, 0.01));
      expect(preview.roundTripCharges, closeTo(238.17, 0.01));
    });

    test('a buy with a % stop and a target reports risk, reward and R:R', () {
      final preview = OrderEngine.preview(
        draft: _draft(stopLossPct: 5, targetPrice: 1100),
        ltp: 1000,
      );

      expect(preview.stopLoss, 950);
      expect(preview.target, 1100);
      expect(preview.stopPct, closeTo(5, 0.001));
      expect(preview.riskAmount, 5000); // 50 × 100 shares
      expect(preview.rewardAmount, 10000); // 100 × 100 shares
      expect(preview.riskReward, closeTo(2.0, 0.001));
    });

    test('a sell previews the cash it releases', () {
      final preview = OrderEngine.preview(
        draft: _draft(side: OrderSide.sell),
        ltp: 1000,
      );
      expect(preview.cashRequired, 0);
      expect(preview.cashReleased, 100000 - 119.55);
    });

    test('preview never throws when there is no price at all', () {
      final preview = OrderEngine.preview(
        draft: _draft(orderType: PaperOrderType.limit),
        ltp: null,
      );
      expect(preview.referencePrice, 0);
      expect(preview.turnover, 0);
      expect(preview.charges.total, 0);
    });
  });
  // -------------------------------------------------------------------------
  // F&O options — BUY *and* SELL. A SELL with nothing held is a short (writing
  // the contract); a BUY against a short covers it. Equity must stay long-only.
  // -------------------------------------------------------------------------
  group('F&O options (long + short)', () {
    OrderDraft optionDraft({
      required OrderSide side,
      int quantity = 75,
      Scrip scrip = _option,
    }) =>
        OrderDraft(
          scrip: scrip,
          side: side,
          quantity: quantity,
          lotSize: 75,
          chargesMode: ChargesMode.intraday,
        );

    test('SELL on an option with nothing held is allowed (short open)', () {
      final check = OrderEngine.check(
        draft: optionDraft(side: OrderSide.sell),
        ltp: 120,
        position: null,
        availableCash: 100000,
      );
      expect(check.errors, isEmpty, reason: 'option writing must be allowed');
      expect(check.isValid, isTrue);
    });

    test('SELL on equity with nothing held is still refused (long-only cash)',
        () {
      final check = OrderEngine.check(
        draft: OrderDraft(
          scrip: _sbin,
          side: OrderSide.sell,
          quantity: 10,
        ),
        ltp: 100,
        position: null,
        availableCash: 100000,
      );
      expect(check.errors, isNotEmpty);
      expect(check.errors.first.toLowerCase(), contains('long-only'));
    });

    test('quantity must be a whole number of lots', () {
      final partial = OrderEngine.check(
        draft: optionDraft(side: OrderSide.sell, quantity: 100), // 1.33 lots
        ltp: 120,
        position: null,
        availableCash: 100000,
      );
      expect(partial.errors.any((e) => e.contains('lot')), isTrue);

      final whole = OrderEngine.check(
        draft: optionDraft(side: OrderSide.sell, quantity: 150), // 2 lots
        ltp: 120,
        position: null,
        availableCash: 100000,
      );
      expect(whole.errors, isEmpty);
    });

    test('a SELL with no position opens a short and books no P&L yet', () {
      final update = OrderEngine.applySell(
        current: null,
        scrip: _option,
        quantity: 75,
        price: 120,
        charges: 26,
        at: _t0,
      );

      final p = update.position;
      expect(update.openedShort, isTrue);
      expect(update.realizedPnl, isNull);
      expect(p.isShort, isTrue);
      expect(p.side, PositionSide.short);
      expect(p.quantity, 75);
      expect(p.avgPrice, 120);
      expect(p.status, PositionStatus.open);
      expect(p.isOpen, isTrue);
    });

    test('adding to a short re-averages the premium', () {
      final first = OrderEngine.applySell(
        current: null,
        scrip: _option,
        quantity: 75,
        price: 120,
        charges: 26,
        at: _t0,
      ).position;

      final second = OrderEngine.applySell(
        current: first,
        scrip: _option,
        quantity: 75,
        price: 100,
        charges: 24,
        at: _t0,
      );

      expect(second.realizedPnl, isNull, reason: 'adding books no P&L');
      expect(second.position.quantity, 150);
      expect(second.position.avgPrice, closeTo(110, 1e-9));
      expect(second.position.isShort, isTrue);
    });

    test('a BUY against a short covers it: P&L is (sold − bought) − charges',
        () {
      final short = OrderEngine.applySell(
        current: null,
        scrip: _option,
        quantity: 75,
        price: 120,
        charges: 26,
        at: _t0,
      ).position;

      final cover = OrderEngine.applyBuy(
        current: short,
        scrip: _option,
        quantity: 75,
        price: 90,
        charges: 18,
        at: _t1,
      );

      // Premium fell 120 → 90, so the writer keeps 30 × 75 = 2250, minus the
      // opening charges (26) and the cover leg's own charges (18).
      expect(cover.realizedPnl, closeTo(2250 - 26 - 18, 0.01));
      expect(cover.position.status, PositionStatus.closed);
      expect(cover.position.quantity, 0);
      expect(cover.position.isOpen, isFalse);
    });

    test('a partial cover keeps the rest of the short open', () {
      final short = OrderEngine.applySell(
        current: null,
        scrip: _option,
        quantity: 150,
        price: 120,
        charges: 40,
        at: _t0,
      ).position;

      final cover = OrderEngine.applyBuy(
        current: short,
        scrip: _option,
        quantity: 75,
        price: 100,
        charges: 18,
        at: _t1,
      );

      expect(cover.position.quantity, 75);
      expect(cover.position.isOpen, isTrue);
      expect(cover.position.isShort, isTrue);
      // Half the opening charges belong to the half that was covered.
      expect(cover.realizedPnl, closeTo((120 - 100) * 75 - 20 - 18, 0.01));
    });

    test('a losing cover (premium rose) books a loss', () {
      final short = OrderEngine.applySell(
        current: null,
        scrip: _option,
        quantity: 75,
        price: 100,
        charges: 20,
        at: _t0,
      ).position;

      final cover = OrderEngine.applyBuy(
        current: short,
        scrip: _option,
        quantity: 75,
        price: 160,
        charges: 20,
        at: _t1,
      );

      expect(cover.realizedPnl, isNegative);
      expect(cover.realizedPnl, closeTo(-(60 * 75) - 20 - 20, 0.01));
    });

    test('short P&L, stop and target point the other way', () {
      final short = OrderEngine.applySell(
        current: null,
        scrip: _option,
        quantity: 75,
        price: 100,
        charges: 0,
        at: _t0,
      ).position.copyWith(stopLoss: 130, target: 60);

      // Premium down → profit for the writer.
      expect(short.unrealizedAt(80), closeTo(20 * 75, 0.01));
      expect(short.unrealizedPctAt(80), closeTo(20, 0.01));
      // Premium up → loss.
      expect(short.unrealizedAt(120), closeTo(-20 * 75, 0.01));
      expect(short.unrealizedPctAt(120), closeTo(-20, 0.01));

      // Stop is above the entry, target below.
      expect(short.stopHit(130), isTrue);
      expect(short.stopHit(129.99), isFalse);
      expect(short.stopHit(90), isFalse);
      expect(short.targetHit(60), isTrue);
      expect(short.targetHit(60.01), isFalse);
    });

    test('a long option (BUY first) still exits by selling', () {
      final long = OrderEngine.applyBuy(
        current: null,
        scrip: _option,
        quantity: 75,
        price: 90,
        charges: 20,
        at: _t0,
      ).position;
      expect(long.isShort, isFalse);

      final exit = OrderEngine.applySell(
        current: long,
        quantity: 75,
        price: 120,
        charges: 30,
        at: _t1,
      );
      expect(exit.realizedPnl, closeTo(30 * 75 - 20 - 30, 0.01));
      expect(exit.position.status, PositionStatus.closed);
    });

    test('a short stop sits ABOVE the entry and its target BELOW', () {
      // 10% stop on a short entry of 100 must resolve to 110, not 90 — the
      // long-only mirror would trip on the very first tick.
      expect(
        OrderEngine.resolveStopLoss(entry: 100, stopLossPct: 10, short: true),
        110,
      );
      expect(
        OrderEngine.resolveStopLoss(
          entry: 100,
          stopLossPrice: 105,
          short: true,
        ),
        105,
      );
      // A "stop" below a short entry is nonsense → clamped one tick above.
      expect(
        OrderEngine.resolveStopLoss(
          entry: 100,
          stopLossPrice: 95,
          tickSize: 0.05,
          short: true,
        ),
        closeTo(100.05, 1e-9),
      );
      // Target for a short is the cheaper price.
      expect(
        OrderEngine.resolveTarget(entry: 100, targetPrice: 60, short: true),
        60,
      );
      expect(
        OrderEngine.resolveTarget(entry: 100, targetPrice: 120, short: true),
        isNull,
      );
    });

    test('selling more than the short is refused, exactly like a long', () {
      final short = OrderEngine.applySell(
        current: null,
        scrip: _option,
        quantity: 75,
        price: 120,
        charges: 26,
        at: _t0,
      ).position;

      final check = OrderEngine.check(
        draft: optionDraft(side: OrderSide.buy, quantity: 150), // cover > short
        ltp: 100,
        position: short,
        availableCash: 100000,
      );
      expect(check.errors, isNotEmpty);
      expect(check.errors.first.toLowerCase(), contains('cover'));
    });
  });


  group('max affordable quantity', () {
    test('leaves room for the charges (99 shares of ₹1,000 from ₹1,00,000)', () {
      final qty = OrderEngine.maxAffordableQuantity(
        availableCash: 100000,
        price: 1000,
        exchange: Exchange.nse,
      );
      expect(qty, 99); // 100 shares would cost 1,00,118.62
    });

    test('is zero when nothing is affordable', () {
      expect(
        OrderEngine.maxAffordableQuantity(
          availableCash: 500,
          price: 1000,
          exchange: Exchange.nse,
        ),
        0,
      );
    });

    test('the returned quantity really does fit in the cash', () {
      const cash = 50000.0;
      final qty = OrderEngine.maxAffordableQuantity(
        availableCash: cash,
        price: 333.25,
        exchange: Exchange.nse,
      );
      final cost = 333.25 * qty +
          EquityCharges.compute(
            side: OrderSide.buy,
            price: 333.25,
            quantity: qty,
            exchange: Exchange.nse,
          ).total;
      expect(cost, lessThanOrEqualTo(cash));
    });
  });
}
