// ---------------------------------------------------------------------------
// charges_test.dart — pins down the transaction-cost model.
//
// Every expected number below is the arithmetic of the published rates, worked
// out by hand in the comment above the assertion, so a change in either the
// code or the rates fails loudly and points at the exact line to re-check.
//
// Worked example (NSE, ₹1,000 × 100 = ₹1,00,000 turnover):
//   delivery buy   0 + 100.00 STT + 2.97 exch + 0.10 SEBI + 0.55 GST + 15.00 stamp = 118.62
//   delivery sell  0 + 100.00 STT + 2.97 exch + 0.10 SEBI + 0.55 GST +  0.00 stamp
//                  + 15.93 DP                                              = 119.55
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/models/paper_trade.dart';
import 'package:angel_trader/features/paper_trading/charges.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('delivery charges (₹1,000 × 100 shares = ₹1,00,000)', () {
    test('buy leg itemises STT, exchange, SEBI, GST and stamp duty', () {
      final c = EquityCharges.compute(
        side: OrderSide.buy,
        price: 1000,
        quantity: 100,
        exchange: Exchange.nse,
      );

      expect(c.turnover, 100000);
      expect(c.brokerage, 0); // Angel One charges nothing for delivery
      expect(c.stt, 100.00); // 0.1% of 1,00,000
      expect(c.exchangeTxn, 2.97); // 0.00297%
      expect(c.sebi, 0.10); // 0.0001%
      expect(c.gst, 0.55); // 18% of (0 + 2.97 + 0.10) = 0.5526
      expect(c.stampDuty, 15.00); // 0.015%, buy side only
      expect(c.dpCharge, 0); // buy legs are not charged DP
      expect(c.total, 118.62);
    });

    test('sell leg adds the ₹13.5 + GST DP charge and drops stamp duty', () {
      final c = EquityCharges.compute(
        side: OrderSide.sell,
        price: 1000,
        quantity: 100,
        exchange: Exchange.nse,
      );

      expect(c.stt, 100.00);
      expect(c.exchangeTxn, 2.97);
      expect(c.sebi, 0.10);
      expect(c.gst, 0.55);
      expect(c.stampDuty, 0);
      expect(c.dpCharge, 15.93); // 13.5 × 1.18
      expect(c.total, 119.55);
    });

    test('cash flow direction: a buy debits cost, a sell credits proceeds', () {
      final buy = EquityCharges.compute(
        side: OrderSide.buy,
        price: 1000,
        quantity: 100,
        exchange: Exchange.nse,
      );
      final sell = EquityCharges.compute(
        side: OrderSide.sell,
        price: 1000,
        quantity: 100,
        exchange: Exchange.nse,
      );

      expect(buy.cashFlow, -100118.62);
      expect(sell.cashFlow, 100000 - 119.55); // 99880.45
    });

    test('DP charge can be switched off for users who square off elsewhere', () {
      final c = EquityCharges.compute(
        side: OrderSide.sell,
        price: 1000,
        quantity: 100,
        exchange: Exchange.nse,
        includeDpCharge: false,
      );
      expect(c.dpCharge, 0);
      expect(c.total, 103.62); // 119.55 − 15.93
    });

    test('BSE pays a higher exchange transaction fee', () {
      final c = EquityCharges.compute(
        side: OrderSide.buy,
        price: 1000,
        quantity: 100,
        exchange: Exchange.bse,
      );
      expect(c.exchangeTxn, 3.75); // 0.00375% vs NSE 0.00297%
      expect(c.gst, 0.69); // (0 + 3.75 + 0.10) × 0.18 = 0.693
      expect(c.total, 119.54);
    });
  });

  group('intraday charges', () {
    test('buy leg: flat ₹20 brokerage, no STT, lower stamp duty', () {
      final c = EquityCharges.compute(
        side: OrderSide.buy,
        price: 1000,
        quantity: 100,
        exchange: Exchange.nse,
        mode: ChargesMode.intraday,
      );

      expect(c.brokerage, 20.00); // min(₹20, 0.25% of 1,00,000 = 250)
      expect(c.stt, 0); // intraday STT is charged on the sell side only
      expect(c.exchangeTxn, 2.97);
      expect(c.sebi, 0.10);
      expect(c.gst, 4.15); // 18% of (20 + 2.97 + 0.10) = 4.1526
      expect(c.stampDuty, 3.00); // 0.003%
      expect(c.dpCharge, 0); // no delivery charge for an intraday square-off
      expect(c.total, 30.22);
    });

    test('sell leg: 0.025% STT applies to the sell side', () {
      final c = EquityCharges.compute(
        side: OrderSide.sell,
        price: 1000,
        quantity: 100,
        exchange: Exchange.nse,
        mode: ChargesMode.intraday,
      );

      expect(c.brokerage, 20.00);
      expect(c.stt, 25.00); // 0.025% of 1,00,000
      expect(c.gst, 4.15);
      expect(c.stampDuty, 0);
      expect(c.total, 52.22);
    });

    test('brokerage is the lower of ₹20 or 0.25% on small orders', () {
      final c = EquityCharges.compute(
        side: OrderSide.buy,
        price: 50,
        quantity: 100, // ₹5,000 turnover → 0.25% = ₹12.50
        exchange: Exchange.nse,
        mode: ChargesMode.intraday,
      );
      expect(c.brokerage, 12.50);
    });
  });

  group('edges', () {
    test('zero quantity or price yields an empty breakdown, not a crash', () {
      final c = EquityCharges.compute(
        side: OrderSide.buy,
        price: 0,
        quantity: 0,
        exchange: Exchange.nse,
      );
      expect(c.total, 0);
      expect(c.isZero, isTrue);
      expect(c.cashFlow, 0);
      expect(c.totalPct, 0);
    });

    test('round-trip cost is the sum of both legs', () {
      final cost = EquityCharges.roundTripCost(
        buyPrice: 1000,
        sellPrice: 1000,
        quantity: 100,
        exchange: Exchange.nse,
      );
      expect(cost, closeTo(238.17, 0.001)); // 118.62 + 119.55
    });

    test('an intraday round trip is far cheaper than delivery', () {
      final intraday = EquityCharges.roundTripCost(
        buyPrice: 1000,
        sellPrice: 1000,
        quantity: 100,
        exchange: Exchange.nse,
        mode: ChargesMode.intraday,
      );
      expect(intraday, closeTo(82.44, 0.001)); // 30.22 + 52.22
    });

    test('totalPct expresses cost as a share of turnover', () {
      final c = EquityCharges.compute(
        side: OrderSide.buy,
        price: 1000,
        quantity: 100,
        exchange: Exchange.nse,
      );
      expect(c.totalPct, closeTo(0.1186, 0.001));
    });

    test('summary and CSV cells include the total', () {
      final c = EquityCharges.compute(
        side: OrderSide.sell,
        price: 1000,
        quantity: 100,
        exchange: Exchange.nse,
      );
      expect(c.summary, contains('STT ₹100.00'));
      expect(c.summary, contains('total ₹119.55'));
      expect(c.toCsvCells().length, 8);
      expect(c.toCsvCells().last, '119.55');
    });
  });

  group('ChargesMode', () {
    test('round-trips through its stored name, defaulting to delivery', () {
      expect(ChargesMode.fromName('intraday'), ChargesMode.intraday);
      expect(ChargesMode.fromName('delivery'), ChargesMode.delivery);
      expect(ChargesMode.fromName(null), ChargesMode.delivery);
      expect(ChargesMode.fromName('nonsense'), ChargesMode.delivery);
    });
  });
  // -------------------------------------------------------------------------
  // Options pay a different stack entirely (F&O, post-1-Oct-2024):
  //   buy   20 brokerage + 0 STT + exch + SEBI + GST + 0.003% stamp
  //   sell  20 brokerage + 0.1% STT + exch + SEBI + GST + 0 stamp
  // Worked example: 1 lot = 75 qty @ ₹200 → turnover ₹15,000
  //   exch   15000 × 0.0495%  = 7.43
  //   SEBI   15000 × 0.0001%  = 0.02
  //   GST    18% of (20 + 7.43 + 0.02) = 4.94
  //   buy    20 + 0 + 7.43 + 0.02 + 4.94 + 0.45 (stamp 0.003%) = 32.84
  //   sell   20 + 15.00 (STT 0.1%) + 7.43 + 0.02 + 4.94 + 0    = 47.39
  // -------------------------------------------------------------------------
  group('option charges (1 lot = 75 qty @ ₹200 = ₹15,000)', () {
    test('buy leg: flat ₹20 brokerage, no STT, stamp instead', () {
      final c = EquityCharges.compute(
        side: OrderSide.buy,
        price: 200,
        quantity: 75,
        exchange: Exchange.nfo,
        kind: InstrumentKind.option,
      );

      expect(c.turnover, 15000);
      expect(c.brokerage, 20.00);
      expect(c.stt, 0, reason: 'STT on options is sell-side only');
      expect(c.exchangeTxn, closeTo(7.43, 0.01)); // 0.0495%
      expect(c.sebi, closeTo(0.02, 0.01)); // 0.0001%
      expect(c.gst, closeTo(4.94, 0.01)); // 18% of (20 + 7.43 + 0.02)
      expect(c.stampDuty, closeTo(0.45, 0.01)); // 0.003%, buy only
      expect(c.dpCharge, 0, reason: 'nothing is delivered');
      expect(c.total, closeTo(32.84, 0.02));
      expect(c.kind, InstrumentKind.option);
      expect(c.summary, contains('F&O Option'));
    });

    test('sell leg: 0.1% STT on the premium, no stamp duty', () {
      final c = EquityCharges.compute(
        side: OrderSide.sell,
        price: 200,
        quantity: 75,
        exchange: Exchange.nfo,
        kind: InstrumentKind.option,
      );

      expect(c.stt, 15.00); // 0.1% of 15,000
      expect(c.stampDuty, 0);
      expect(c.total, closeTo(47.39, 0.02));
    });

    test('delivery/intraday mode does not change an option leg', () {
      double total(ChargesMode mode, OrderSide side) => EquityCharges.compute(
            side: side,
            price: 200,
            quantity: 75,
            exchange: Exchange.nfo,
            mode: mode,
            kind: InstrumentKind.option,
          ).total;

      expect(total(ChargesMode.delivery, OrderSide.buy),
          total(ChargesMode.intraday, OrderSide.buy));
      expect(total(ChargesMode.delivery, OrderSide.sell),
          total(ChargesMode.intraday, OrderSide.sell));
    });

    test('a round trip is the two legs added, buy then sell', () {
      final round = EquityCharges.roundTripCost(
        buyPrice: 200,
        sellPrice: 200,
        quantity: 75,
        exchange: Exchange.nfo,
        mode: ChargesMode.intraday,
        kind: InstrumentKind.option,
      );
      final buy = EquityCharges.compute(
        side: OrderSide.buy,
        price: 200,
        quantity: 75,
        exchange: Exchange.nfo,
        kind: InstrumentKind.option,
      ).total;
      final sell = EquityCharges.compute(
        side: OrderSide.sell,
        price: 200,
        quantity: 75,
        exchange: Exchange.nfo,
        kind: InstrumentKind.option,
      ).total;

      expect(round, closeTo(buy + sell, 0.02));
      expect(round, greaterThan(60), reason: '₹20 + ₹20 brokerage alone');
    });

    test('equity is untouched: the option stack needs the kind flag', () {
      final equity = EquityCharges.compute(
        side: OrderSide.buy,
        price: 200,
        quantity: 75,
        exchange: Exchange.nfo, // even on the NFO exchange
      );
      expect(equity.brokerage, 0, reason: 'no kind → equity rates');
    });
  });

}
