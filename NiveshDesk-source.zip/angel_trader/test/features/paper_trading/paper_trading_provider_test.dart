// ---------------------------------------------------------------------------
// paper_trading_provider_test.dart — the paper-trading orchestration, end to end.
//
// NO NETWORK IS TOUCHED. Three seams are injected:
//   * the real SQLite schema, on an in-memory FFI database (same DAOs as prod)
//   * a FakeSocket for the WebSocket feed, so a test can push a price *as if*
//     SmartAPI had sent it (51-byte little-endian LTP frame)
//   * a fixed clock, so timestamps are deterministic
//
// Covered here: the resting-LIMIT → tick → fill path, stop-loss auto-exit,
// partial exits, group tagging/re-tagging, the manual force-fill, reset, and the
// validation that stops a market order without a price.
// ---------------------------------------------------------------------------

import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/scrip_dao.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/data/local/dao/trade_dao.dart';
import 'package:angel_trader/data/local/dao/trade_group_dao.dart';
import 'package:angel_trader/data/local/models/paper_trade.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/data/remote/dto/session.dart';
import 'package:angel_trader/features/paper_trading/charges.dart';
import 'package:angel_trader/features/paper_trading/order_engine.dart';
import 'package:angel_trader/features/paper_trading/paper_trading_provider.dart';
import 'package:angel_trader/features/settings/settings_provider.dart';
import 'package:angel_trader/services/auth_service.dart';
import 'package:angel_trader/services/live_feed_service.dart';
import 'package:angel_trader/services/market_data_service.dart';
import 'package:angel_trader/services/secure_store.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

// ---------------------------------------------------------------------------
// Fakes
// ---------------------------------------------------------------------------

/// The same fake the feed tests use: records outgoing frames and lets the test
/// push server frames in.
class FakeSocket implements FeedSocket {
  final List<dynamic> sent = [];
  final StreamController<dynamic> _incoming = StreamController<dynamic>();
  bool closed = false;

  @override
  Stream<dynamic> get stream => _incoming.stream;

  @override
  Future<void> get ready => Future<void>.value();

  @override
  void send(String message) => sent.add(message);

  @override
  Future<void> close() async {
    closed = true;
    if (!_incoming.isClosed) await _incoming.close();
  }

  void emit(dynamic frame) {
    if (!_incoming.isClosed) _incoming.add(frame);
  }
}

/// A JWT that never expires (exp = 2099) so `restore()` performs no refresh call.
String _longLivedJwt() {
  String segment(Map<String, dynamic> payload) =>
      base64Url.encode(utf8.encode(jsonEncode(payload))).replaceAll('=', '');
  return '${segment({'alg': 'HS512'})}.${segment({'exp': 4070908800})}.sig';
}

Future<AuthService> _loggedInAuth() async {
  FlutterSecureStorage.setMockInitialValues({
    'angel_session_v1': jsonEncode(
      AngelSession(
        apiKey: 'test-api-key',
        clientCode: 'A123456',
        jwtToken: _longLivedJwt(),
        refreshToken: 'refresh-token',
        feedToken: 'feed-token-xyz',
        generatedAt: DateTime(2026, 10, 1, 9, 0),
      ).toJson(),
    ),
  });
  final auth = AuthService(store: SecureStore());
  await auth.restore();
  return auth;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  const token = '3045';
  const symbol = 'SBIN-EQ';
  final scrip = Scrip(
    token: token,
    symbol: symbol,
    name: 'State Bank of India',
    exchange: Exchange.nse,
  );

  // ---- an F&O option contract (NFO segment, 1 lot = 75)
  const optionToken = '7001';
  const optionLot = 75;
  final optionScrip = Scrip(
    token: optionToken,
    symbol: 'SBIN26OCT800CE',
    name: 'SBIN 800 CE',
    exchange: Exchange.nfo,
  );

  late AppDatabase db;
  late SettingsProvider settings;
  late PaperTradingProvider paper;
  late LiveFeedService feed;
  late FakeSocket socket;
  late DateTime fakeNow;

  /// Polls until [condition] holds — the provider works through async DB writes,
  /// so a fixed sleep would be flaky.
  Future<void> waitFor(
    bool Function() condition, {
    required String reason,
    int timeoutMs = 3000,
  }) async {
    final deadline = DateTime.now().add(Duration(milliseconds: timeoutMs));
    while (DateTime.now().isBefore(deadline)) {
      if (condition()) return;
      await Future<void>.delayed(const Duration(milliseconds: 10));
    }
    fail('Timed out waiting for: $reason');
  }

  /// A 51-byte SmartAPI LTP frame (little-endian), exactly what the socket
  /// delivers — the same layout the decoder test pins down.
  Uint8List ltpFrame(
    double price, {
    String tokenId = token,
    int sequence = 1,
    int exchangeType = 1, // 1 = nse_cm, 2 = nse_fo
  }) {
    final bytes = Uint8List(51);
    final view = ByteData.view(bytes.buffer);
    bytes[0] = 1; // LTP mode
    bytes[1] = exchangeType;
    bytes.setRange(2, 2 + tokenId.length, utf8.encode(tokenId));
    view.setInt64(27, sequence, Endian.little);
    view.setInt64(35, fakeNow.millisecondsSinceEpoch, Endian.little);
    view.setInt64(43, (price * 100).round(), Endian.little);
    return bytes;
  }

  /// Pushes a price as if it came off the live feed.
  Future<void> pushTick(
    double price, {
    String tokenId = token,
    int exchangeType = 1,
  }) async {
    socket.emit(
      ltpFrame(price, tokenId: tokenId, exchangeType: exchangeType),
    );
    await Future<void>.delayed(const Duration(milliseconds: 5));
  }

  /// Pushes an NFO option premium.
  Future<void> pushOptionTick(double premium) =>
      pushTick(premium, tokenId: optionToken, exchangeType: 2);

  /// A resting LIMIT sell of [lots] lots on the option.
  OrderDraft optionSell({
    required double limit,
    int lots = 1,
    OrderSide side = OrderSide.sell,
    double? stopLossPct,
    double? stopLossPrice,
    double? targetPrice,
  }) =>
      OrderDraft(
        scrip: optionScrip,
        side: side,
        quantity: lots * optionLot,
        orderType: PaperOrderType.limit,
        limitPrice: limit,
        lotSize: optionLot,
        stopLossPct: stopLossPct,
        stopLossPrice: stopLossPrice,
        targetPrice: targetPrice,
        note: 'test option',
        chargesMode: paper.chargesMode,
        includeDpCharge: paper.includeDpCharges,
      );

  OrderDraft limitBuy({
    required double limit,
    int quantity = 10,
    double? stopLossPct,
    int? groupId,
  }) =>
      OrderDraft(
        scrip: scrip,
        side: OrderSide.buy,
        quantity: quantity,
        orderType: PaperOrderType.limit,
        limitPrice: limit,
        stopLossPct: stopLossPct,
        groupId: groupId,
        note: 'test',
        chargesMode: paper.chargesMode,
        includeDpCharge: paper.includeDpCharges,
      );

  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close();
    db = AppDatabase.instance;

    fakeNow = DateTime(2026, 10, 1, 10, 5); // 01 Oct 2026, IST market hours

    final auth = await _loggedInAuth();
    expect(auth.isLoggedIn, isTrue, reason: 'logged-in fixture');

    settings = SettingsProvider(SettingsDao(db));
    await settings.load();
    await settings.setStartingCapital(100000);
    await settings.setChargesMode('delivery');
    await settings.setIncludeDpCharges(true);
    await settings.setLiveFeedEnabled(true);
    await settings.setAutoRefreshSeconds(900); // keep the REST timer quiet

    socket = FakeSocket();
    feed = LiveFeedService(
      auth: auth,
      pingInterval: const Duration(milliseconds: 80),
      reconnectBase: const Duration(milliseconds: 10),
      reconnectMax: const Duration(milliseconds: 20),
      socketFactory: (uri, headers) {
        socket = FakeSocket();
        return socket;
      },
    );

    paper = PaperTradingProvider(
      trades: TradeDao(db),
      groups: TradeGroupDao(db),
      settings: settings,
      auth: auth,
      marketData: MarketDataService(auth: auth),
      feed: feed,
      scripDao: ScripDao(db),
      clock: () => fakeNow,
      manageWakelock: false,
    );
    await paper.bootstrap();
  });

  tearDown(() async {
    paper.dispose();
    feed.dispose();
    await AppDatabase.instance.close();
  });

  // -------------------------------------------------------------------------
  group('Bootstrap', () {
    test('an empty account starts with the configured virtual capital', () {
      expect(paper.holdings, isEmpty);
      expect(paper.tradeBook, isEmpty);
      expect(paper.pendingOrders, isEmpty);
      expect(paper.snapshot.availableCash, 100000);
      expect(paper.error, isNull);
    });

    test('a market order without any known price is rejected, not filled',
        () async {
      final result = await paper.placeOrder(OrderDraft(
        scrip: scrip,
        side: OrderSide.buy,
        quantity: 5,
        note: 'no price',
      ));
      expect(result.isFailure, isTrue);
      expect(result.message.toLowerCase(), contains('live price'));
      expect(paper.holdings, isEmpty);
      expect(paper.tradeBook, isEmpty);
    });
  });

  // -------------------------------------------------------------------------
  group('LIMIT orders', () {
    test('rests, then fills on the first tick that reaches the limit', () async {
      final placed = await paper.placeOrder(limitBuy(limit: 99));
      expect(placed.isResting, isTrue, reason: 'no LTP yet, so it must rest');
      expect(paper.pendingOrders, hasLength(1));
      expect(paper.pendingOrders.single.status, OrderStatus.pending);

      // A tick above the limit must NOT fill a buy limit…
      await pushTick(101);
      await Future<void>.delayed(const Duration(milliseconds: 30));
      expect(paper.pendingOrders, hasLength(1),
          reason: '101 is above a buy limit of 99');

      // …a tick at the level must.
      await pushTick(99);
      // Wait for the *effect*, not just the position row: the provider reloads
      // its lists asynchronously (single-flight), so a half-finished pass would
      // hand the assertions stale caches.
      await waitFor(
        () => paper.holdings.isNotEmpty && paper.tradeBook.isNotEmpty,
        reason: 'the limit fill',
      );

      expect(paper.pendingOrders, isEmpty);
      final holding = paper.holdings.single;
      expect(holding.position.quantity, 10);
      expect(holding.position.avgPrice, closeTo(99, 0.001));
      expect(paper.tradeBook, hasLength(1));
      expect(paper.tradeBook.single.price, closeTo(99, 0.001));
      expect(paper.tradeBook.single.realizedPnl, isNull,
          reason: 'an opening leg has no result');
      expect(paper.tradeBook.single.charges, greaterThan(0),
          reason: 'charges are simulated on every fill');
      expect(paper.filledOrders, hasLength(1));
      expect(paper.filledOrders.single.status, OrderStatus.filled);
      expect(paper.filledOrders.single.filledPrice, closeTo(99, 0.001));
      expect(paper.notice.toLowerCase(), contains('bought'));
    });

    test('the manual force-fill uses the limit price for a resting order',
        () async {
      await paper.placeOrder(limitBuy(limit: 90));
      expect(paper.pendingOrders, hasLength(1));

      final result = await paper.forceFill(paper.pendingOrders.single);
      expect(result.isFilled, isTrue);
      await waitFor(
        () => paper.holdings.isNotEmpty && paper.pendingOrders.isEmpty,
        reason: 'the manual fill',
      );
      expect(paper.holdings.single.position.avgPrice, closeTo(90, 0.001));
    });

    test('cancel leaves nothing behind', () async {
      await paper.placeOrder(limitBuy(limit: 90));
      await paper.cancelOrder(paper.pendingOrders.single);
      await waitFor(
        () => paper.pendingOrders.isEmpty && paper.filledOrders.isNotEmpty,
        reason: 'the cancellation',
      );
      expect(paper.holdings, isEmpty);
      expect(paper.filledOrders.single.status, OrderStatus.cancelled);
    });
  });

  // -------------------------------------------------------------------------
  group('Stop loss', () {
    test('a breached stop auto-exits the whole position and books the loss',
        () async {
      // Fill a buy with a 5% stop → stop = 99 × 0.95 = 94.05.
      await paper.placeOrder(limitBuy(limit: 99, stopLossPct: 5));
      await pushTick(99);
      await waitFor(
        () => paper.holdings.isNotEmpty && paper.tradeBook.isNotEmpty,
        reason: 'the limit fill',
      );

      final position = paper.holdings.single.position;
      expect(position.stopLoss, closeTo(94.05, 0.001),
          reason: '5 % below a 99 entry, tick-rounded');

      // Tick through the stop.
      await pushTick(94);
      await waitFor(
        () => paper.holdings.isEmpty && paper.tradeBook.length == 2,
        reason: 'the auto-exit',
      );

      expect(paper.tradeBook, hasLength(2), reason: 'opening + closing leg');
      final closing = paper.tradeBook.firstWhere((t) => t.isClosingLeg);
      expect(closing.side, OrderSide.sell);
      expect(closing.positionId, position.id);
      expect(closing.realizedPnl, isNotNull);
      // (94 − 99) × 10 = −50 gross, minus the simulated charges on both legs.
      expect(closing.realizedPnl!, lessThan(-50));
      expect(closing.charges, greaterThan(0));
      expect(closing.note.toLowerCase(), contains('stop loss'));
      expect(paper.notice.toLowerCase(), contains('auto-exit'));
    });

    test('setStopLoss resolves a percentage against the average price',
        () async {
      await paper.placeOrder(limitBuy(limit: 100));
      await pushTick(100);
      await waitFor(() => paper.holdings.isNotEmpty, reason: 'the fill');

      final position = paper.holdings.single.position;
      expect(position.stopLoss, isNull, reason: 'none was requested');

      await paper.setStopLoss(position, pct: 8);
      await waitFor(
        () => paper.holdings.single.position.stopLoss != null,
        reason: 'the stop to be persisted',
      );
      expect(paper.holdings.single.position.stopLoss, closeTo(92, 0.001));

      await paper.setStopLoss(paper.holdings.single.position);
      await waitFor(
        () => paper.holdings.single.position.stopLoss == null,
        reason: 'the stop to be cleared',
      );
    });
  });

  // -------------------------------------------------------------------------
  group('Selling', () {
    test('a partial exit keeps the rest open and realises only the sold part',
        () async {
      await paper.placeOrder(limitBuy(limit: 100, quantity: 10));
      await pushTick(100);
      await waitFor(
        () => paper.holdings.isNotEmpty && paper.tradeBook.isNotEmpty,
        reason: 'the fill',
      );

      await pushTick(105);
      final result =
          await paper.exitPartial(paper.holdings.single.position, 4);
      expect(result.isFilled, isTrue);
      await waitFor(
        () => paper.holdings.isNotEmpty &&
            paper.holdings.single.position.quantity == 6,
        reason: 'the partial exit to be persisted',
      );

      final remaining = paper.holdings.single.position;
      expect(remaining.quantity, 6);
      expect(remaining.isOpen, isTrue);

      final closing = paper.tradeBook.firstWhere((t) => t.isClosingLeg);
      expect(closing.quantity, 4);
      expect(closing.price, closeTo(105, 0.001));
      // Gross gain 4 × ₹5 = ₹20, minus both legs' charges → still positive.
      expect(closing.realizedPnl!, greaterThan(0));
    });

    test('a full exit closes the position', () async {
      await paper.placeOrder(limitBuy(limit: 100, quantity: 5));
      await pushTick(100);
      await waitFor(
        () => paper.holdings.isNotEmpty && paper.tradeBook.isNotEmpty,
        reason: 'the fill',
      );

      await pushTick(110);
      final result = await paper.exitPosition(paper.holdings.single.position);
      expect(result.isFilled, isTrue);
      await waitFor(() => paper.holdings.isEmpty, reason: 'the exit');
      expect(paper.snapshot.openPositions, 0);
    });
  });

  // -------------------------------------------------------------------------
  group('Groups', () {
    test('a filled order carries its group into the position and the legs',
        () async {
      final group = await paper.createGroup('Momentum');
      expect(group.id, isNotNull);
      expect(paper.groups.map((g) => g.name), contains('Momentum'));

      await paper.placeOrder(limitBuy(limit: 100, groupId: group.id));
      await pushTick(100);
      await waitFor(
        () => paper.holdings.isNotEmpty && paper.tradeBook.isNotEmpty,
        reason: 'the fill',
      );

      expect(paper.holdings.single.position.groupId, group.id);
      expect(paper.tradeBook.single.groupId, group.id);
    });

    test('re-tagging moves the position and its history together', () async {
      final group = await paper.createGroup('Swing');
      await paper.placeOrder(limitBuy(limit: 100, groupId: group.id));
      await pushTick(100);
      await waitFor(() => paper.holdings.isNotEmpty, reason: 'the fill');

      await paper.setPositionGroup(paper.holdings.single.position, null);
      await waitFor(
        () =>
            paper.holdings.single.position.groupId == null &&
            paper.tradeBook.every((t) => t.groupId == null),
        reason: 'the re-tag',
      );
      expect(paper.notice, contains('Ungrouped'));
    });
  });

  // -------------------------------------------------------------------------
  group('F&O options (short open → cover)', () {
    test('a resting SELL with no position opens a short on the fill', () async {
      await paper.placeOrder(optionSell(limit: 120));
      await pushOptionTick(120);
      // Wait for the premium credit too: the position row lands a beat before
      // the account does, and asserting the cash straight after `holdings` was
      // a race that only showed up when the machine was busy.
      await waitFor(
        () => paper.holdings.isNotEmpty &&
            paper.snapshot.availableCash != 100000,
        reason: 'the option fill (premium credited)',
      );

      final position = paper.holdings.single.position;
      expect(position.isShort, isTrue);
      expect(position.side, PositionSide.short);
      expect(position.exchange, Exchange.nfo);
      expect(position.quantity, optionLot);
      expect(position.avgPrice, closeTo(120, 0.001));
      // Premium came in as cash: the writer is credited (net of charges).
      expect(paper.snapshot.availableCash, greaterThan(100000));
      expect(paper.notice, contains('Short khula'));
    });

    test('covering the short at a lower premium books a profit', () async {
      await paper.placeOrder(optionSell(limit: 120));
      await pushOptionTick(120);
      await waitFor(() => paper.holdings.isNotEmpty, reason: 'the short');

      // Premium halves — exactly what an option writer wants to see.
      await pushOptionTick(60);
      final result = await paper.exitPosition(paper.holdings.single.position);
      expect(result.isFilled, isTrue);
      await waitFor(() => paper.holdings.isEmpty, reason: 'the cover');
      await waitFor(
        () => paper.tradeBook.any((t) => t.isClosingLeg),
        reason: 'the cover leg in the book',
      );

      final closing = paper.tradeBook.firstWhere((t) => t.isClosingLeg);
      expect(closing.side, OrderSide.buy, reason: 'a cover is a BUY');
      // (120 − 60) × 75 = 4500 minus both legs' charges → still well positive.
      expect(closing.realizedPnl!, greaterThan(4000));
      expect(closing.realizedPnl!, lessThan(4500));
      expect(paper.notice, contains('Covered'));

      // Both legs are in the book: the write (sell) and the cover (buy).
      expect(paper.snapshot.openPositions, 0);
    });

    test('a partial cover leaves the rest of the short open', () async {
      await paper.placeOrder(optionSell(limit: 120, lots: 2));
      await pushOptionTick(120);
      await waitFor(
        () => paper.holdings.isNotEmpty &&
            paper.holdings.single.position.quantity == 2 * optionLot,
        reason: 'the 2-lot short',
      );

      await pushOptionTick(100);
      final result =
          await paper.exitPartial(paper.holdings.single.position, optionLot);
      expect(result.isFilled, isTrue);
      await waitFor(
        () => paper.holdings.isNotEmpty &&
            paper.holdings.single.position.quantity == optionLot,
        reason: 'the partial cover',
      );

      await waitFor(
        () => paper.tradeBook.any((t) => t.isClosingLeg),
        reason: 'the partial cover leg',
      );
      final remaining = paper.holdings.single.position;
      expect(remaining.isShort, isTrue);
      expect(remaining.isOpen, isTrue);
      final closing = paper.tradeBook.firstWhere((t) => t.isClosingLeg);
      expect(closing.side, OrderSide.buy);
      expect(closing.note, contains('cover'));
    });

    test('a bigger premium means the cover books a loss', () async {
      await paper.placeOrder(optionSell(limit: 100));
      await pushOptionTick(100);
      await waitFor(() => paper.holdings.isNotEmpty, reason: 'the short');

      await pushOptionTick(160);
      await paper.exitPosition(paper.holdings.single.position);
      await waitFor(() => paper.holdings.isEmpty, reason: 'the cover');
      await waitFor(
        () => paper.tradeBook.any((t) => t.isClosingLeg),
        reason: 'the losing cover leg',
      );

      final closing = paper.tradeBook.firstWhere((t) => t.isClosingLeg);
      expect(closing.realizedPnl!, isNegative);
      expect(closing.realizedPnl!, lessThan(-4000)); // −60 × 75 = −4500
    });

    test('a short stop (above the entry) auto-covers when it is hit',
        () async {
      // 10% stop above the sold premium: 120 → 132.
      await paper.placeOrder(optionSell(limit: 120, stopLossPct: 10));
      await pushOptionTick(120);
      await waitFor(() => paper.holdings.isNotEmpty, reason: 'the short');

      final position = paper.holdings.single.position;
      expect(position.stopLoss, closeTo(132, 0.01));
      expect(position.isShort, isTrue);

      await pushOptionTick(132);
      await waitFor(() => paper.holdings.isEmpty, reason: 'the auto-cover');
      await waitFor(
        () => paper.tradeBook.any((t) => t.isClosingLeg),
        reason: 'the auto-cover leg',
      );

      final closing = paper.tradeBook.firstWhere((t) => t.isClosingLeg);
      expect(closing.side, OrderSide.buy, reason: 'a cover is a BUY');
      expect(closing.note, contains('stop loss'));
      expect(closing.realizedPnl!, isNegative); // premium rose → writer loses
    });

    test('the short pays the F&O option cost stack, not equity rates',
        () async {
      await paper.placeOrder(optionSell(limit: 120));
      await pushOptionTick(120);
      await waitFor(() => paper.tradeBook.isNotEmpty, reason: 'the write');

      await pushOptionTick(120);
      await paper.exitPosition(paper.holdings.single.position);
      await waitFor(() => paper.holdings.isEmpty, reason: 'the cover');
      await waitFor(
        () => paper.tradeBook.length >= 2,
        reason: 'both legs of the round trip',
      );

      final opening = paper.tradeBook.lastWhere((t) => !t.isClosingLeg);
      final expected = EquityCharges.compute(
        side: OrderSide.sell,
        price: 120,
        quantity: optionLot,
        exchange: Exchange.nfo,
        mode: paper.chargesMode,
        includeDpCharge: paper.includeDpCharges,
        kind: InstrumentKind.option,
      ).total;
      expect(opening.charges, closeTo(expected, 0.01));
      // The flat ₹20 F&O brokerage is what makes this different from equity.
      expect(opening.charges, greaterThan(20));
    });
  });

  // -------------------------------------------------------------------------
  group('Reset', () {
    test('wipes orders, trades and positions and restores the capital',
        () async {
      await paper.placeOrder(limitBuy(limit: 100));
      await pushTick(100);
      await waitFor(
        () => paper.holdings.isNotEmpty && paper.tradeBook.isNotEmpty,
        reason: 'the fill',
      );
      await paper.placeOrder(limitBuy(limit: 80)); // a resting order too
      expect(paper.pendingOrders, hasLength(1));

      await paper.resetAccount();

      await waitFor(
        () =>
            paper.holdings.isEmpty &&
            paper.tradeBook.isEmpty &&
            paper.pendingOrders.isEmpty &&
            paper.filledOrders.isEmpty,
        reason: 'the reset',
      );
      expect(paper.snapshot.availableCash, 100000);
    });
  });
}
