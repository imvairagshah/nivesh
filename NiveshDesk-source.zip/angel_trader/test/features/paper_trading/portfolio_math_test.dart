// ---------------------------------------------------------------------------
// portfolio_math_test.dart — aggregate statistics, IST month bucketing and the
// cash identity that keeps the dashboard honest.
//
// The identity under test:
//   portfolioValue − startingCapital  ==  realised + unrealised − open-leg charges
//   (netTotalPnl)
// If that ever breaks, the dashboard is showing a number the ledger cannot
// explain, which is exactly the bug this file exists to catch.
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/models/paper_trade.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/features/paper_trading/charges.dart';
import 'package:angel_trader/features/paper_trading/order_engine.dart';
import 'package:angel_trader/features/paper_trading/portfolio_math.dart';
import 'package:flutter_test/flutter_test.dart';

const _sbin = Scrip(
  token: '3045',
  symbol: 'SBIN-EQ',
  name: 'SBIN',
  exchange: Exchange.nse,
);

final _t0 = DateTime(2025, 9, 29, 10, 15);
final _t1 = DateTime(2025, 9, 30, 14, 30);

/// A closing leg carrying [pnl].
Trade _closingLeg({
  required double pnl,
  DateTime? at,
  String symbol = 'SBIN-EQ',
  double charges = 10,
}) =>
    Trade(
      symbol: symbol,
      exchange: Exchange.nse,
      side: OrderSide.sell,
      quantity: 10,
      price: 100,
      realizedPnl: pnl,
      charges: charges,
      executedAt: at ?? _t1,
    );

Position _position({
  int quantity = 100,
  double avgPrice = 1000,
  double chargesPaid = 118.62,
  int? groupId,
}) =>
    Position(
      id: 1,
      symbol: 'SBIN-EQ',
      exchange: Exchange.nse,
      token: '3045',
      quantity: quantity,
      avgPrice: avgPrice,
      chargesPaid: chargesPaid,
      groupId: groupId,
      openedAt: _t0,
    );

void main() {
  group('PnlStats', () {
    test('splits wins, losses and flat trades', () {
      final stats = PortfolioMath.stats([
        _closingLeg(pnl: 500),
        _closingLeg(pnl: -200),
        _closingLeg(pnl: 0),
      ]);

      expect(stats.closedTrades, 3);
      expect(stats.realizedPnl, 300);
      expect(stats.wins, 1);
      expect(stats.losses, 1);
      expect(stats.winRate, closeTo(33.333, 0.01));
      expect(stats.grossProfit, 500);
      expect(stats.grossLoss, -200);
      expect(stats.averageWin, 500);
      expect(stats.averageLoss, 200); // reported as a positive number
      expect(stats.profitFactor, closeTo(2.5, 0.001));
      expect(stats.biggestWin, 500);
      expect(stats.biggestLoss, -200);
      expect(stats.averageTrade, closeTo(100, 0.001));
    });

    test('profit factor is null (not infinite) when there are no losses', () {
      final stats = PortfolioMath.stats([_closingLeg(pnl: 500)]);
      expect(stats.profitFactor, isNull);
      expect(stats.winRate, 100);
    });

    test('an empty book yields the empty stats object', () {
      final stats = PortfolioMath.stats(const []);
      expect(stats.isEmpty, isTrue);
      expect(stats.realizedPnl, 0);
      expect(stats.winRate, 0);
      expect(stats.averageWin, 0);
      expect(stats.profitFactor, isNull);
    });

    test('charges are totalled across every leg when the book is supplied', () {
      final stats = PortfolioMath.stats(
        [_closingLeg(pnl: 100, charges: 60)],
        allLegs: [
          _closingLeg(pnl: 100, charges: 60),
          Trade(
            symbol: 'SBIN-EQ',
            exchange: Exchange.nse,
            side: OrderSide.buy,
            quantity: 10,
            price: 100,
            charges: 40, // opening leg: no realised P&L, but real charges
            executedAt: _t0,
          ),
        ],
      );
      expect(stats.charges, 100);
    });
  });

  group('monthly bucketing (IST)', () {
    test('a trade at 02:00 IST on 1 Oct is reported in October', () {
      // 20:30 UTC on 30 Sep == 02:00 IST on 1 Oct.
      final rows = PortfolioMath.monthly([
        _closingLeg(pnl: 1000, at: DateTime.utc(2025, 9, 30, 20, 30)),
      ]);

      expect(rows, hasLength(1));
      expect(rows.first.month, DateTime(2025, 10));
      expect(rows.first.key, '2025-10');
      expect(rows.first.label, 'Oct 2025');
      expect(rows.first.shortLabel, 'Oct');
    });

    test('a trade earlier the same UTC day stays in September', () {
      // 06:00 UTC == 11:30 IST on 29 Sep.
      final rows = PortfolioMath.monthly([
        _closingLeg(pnl: 500, at: DateTime.utc(2025, 9, 29, 6, 0)),
      ]);
      expect(rows.first.month, DateTime(2025, 9));
    });

    test('months are aggregated and sorted oldest first', () {
      final rows = PortfolioMath.monthly([
        _closingLeg(pnl: 300, at: DateTime.utc(2025, 11, 5, 6)),
        _closingLeg(pnl: -100, at: DateTime.utc(2025, 11, 20, 6)),
        _closingLeg(pnl: 900, at: DateTime.utc(2025, 9, 10, 6)),
      ]);

      expect(rows.map((r) => r.key).toList(), ['2025-09', '2025-11']);
      expect(rows.first.realizedPnl, 900);
      expect(rows.last.realizedPnl, 200);
      expect(rows.last.trades, 2);
      expect(rows.last.wins, 1);
      expect(rows.last.losses, 1);
      expect(rows.last.biggestWin, 300);
      expect(rows.last.biggestLoss, -100);
      expect(rows.last.winRate, closeTo(50, 0.001));
    });
  });

  group('PortfolioSnapshot — the cash identity', () {
    test('an open position: value, unrealised P&L and the identity hold', () {
      final buyCharges = EquityCharges.compute(
        side: OrderSide.buy,
        price: 1000,
        quantity: 100,
        exchange: Exchange.nse,
      ).total; // 118.62

      final opened = OrderEngine.applyBuy(
        current: null,
        scrip: _sbin,
        quantity: 100,
        price: 1000,
        charges: buyCharges,
        at: _t0,
      );
      final position = opened.position.copyWith(id: 1);

      final buyLeg = Trade(
        symbol: 'SBIN-EQ',
        exchange: Exchange.nse,
        side: OrderSide.buy,
        quantity: 100,
        price: 1000,
        charges: buyCharges,
        positionId: 1,
        executedAt: _t0,
      );

      final snapshot = PortfolioMath.snapshot(
        startingCapital: 200000,
        trades: [buyLeg],
        holdings: [
          HoldingView(position: position, ltp: 1050, isLive: true),
        ],
      );

      expect(snapshot.availableCash, closeTo(200000 - 100118.62, 0.01));
      expect(snapshot.investedValue, 100000);
      expect(snapshot.marketValue, 105000);
      expect(snapshot.unrealizedPnl, 5000);
      expect(snapshot.realizedPnl, 0);
      expect(snapshot.portfolioValue, closeTo(204881.38, 0.01));
      expect(snapshot.totalPnl, closeTo(4881.38, 0.01));
      // 5000 unrealised − 118.62 of opening charges already paid
      expect(snapshot.netTotalPnl, closeTo(4881.38, 0.01));
      expect(snapshot.openPositions, 1);
      expect(snapshot.hasUnpricedPositions, isFalse);
      expect(snapshot.deployedPct, closeTo(105000 / 204881.38 * 100, 0.01));
    });

    test('a full round trip books exactly the realised P&L in cash', () {
      final buyCharges = EquityCharges.compute(
        side: OrderSide.buy,
        price: 1000,
        quantity: 100,
        exchange: Exchange.nse,
      ).total;
      final sellCharges = EquityCharges.compute(
        side: OrderSide.sell,
        price: 1100,
        quantity: 100,
        exchange: Exchange.nse,
      ).total; // 129.92

      final position = _position(chargesPaid: buyCharges);
      final closed = OrderEngine.applySell(
        current: position,
        quantity: 100,
        price: 1100,
        charges: sellCharges,
        at: _t1,
      );

      final legs = [
        Trade(
          symbol: 'SBIN-EQ',
          exchange: Exchange.nse,
          side: OrderSide.buy,
          quantity: 100,
          price: 1000,
          charges: buyCharges,
          positionId: 1,
          executedAt: _t0,
        ),
        Trade(
          symbol: 'SBIN-EQ',
          exchange: Exchange.nse,
          side: OrderSide.sell,
          quantity: 100,
          price: 1100,
          charges: sellCharges,
          realizedPnl: closed.realizedPnl,
          positionId: 1,
          executedAt: _t1,
        ),
      ];

      final snapshot = PortfolioMath.snapshot(
        startingCapital: 200000,
        trades: legs,
        holdings: const [],
      );

      // 10,000 gross − 118.62 opening − 129.92 exit = 9,751.46
      expect(snapshot.realizedPnl, closeTo(9751.46, 0.01));
      expect(snapshot.availableCash, closeTo(209751.46, 0.01));
      expect(snapshot.marketValue, 0);
      expect(snapshot.portfolioValue, closeTo(209751.46, 0.01));
      expect(snapshot.totalPnl, closeTo(9751.46, 0.01));
      expect(snapshot.closedTrades, 1);
      expect(snapshot.totalPnl, closeTo(snapshot.netTotalPnl, 0.001));
    });

    test('an unpriced holding is carried at book value, and flagged', () {
      final snapshot = PortfolioMath.snapshot(
        startingCapital: 200000,
        trades: const [],
        holdings: [HoldingView(position: _position())], // no ltp
      );

      expect(snapshot.marketValue, 100000); // not zero
      expect(snapshot.unrealizedPnl, 0);
      expect(snapshot.hasUnpricedPositions, isTrue);
      expect(snapshot.portfolioValue, closeTo(300000, 0.01));
    });

    test('pending orders are counted but never touch the cash', () {
      final snapshot = PortfolioMath.snapshot(
        startingCapital: 100000,
        trades: const [],
        holdings: const [],
        pendingOrders: 3,
      );
      expect(snapshot.pendingOrders, 3);
      expect(snapshot.availableCash, 100000);
      expect(snapshot.totalPnl, 0);
    });
  });

  group('HoldingView', () {
    test('reports gross and post-charge unrealised P&L', () {
      final view = HoldingView(
        position: _position(),
        ltp: 1100,
        isLive: true,
      );

      expect(view.invested, 100000);
      expect(view.marketValue, 110000);
      expect(view.unrealizedPnl, 10000);
      expect(view.unrealizedPct, closeTo(10, 0.001));

      // Exit charges at 1100 = 129.92 (see charges_test)
      expect(view.exitCharges(ChargesMode.delivery), closeTo(129.92, 0.01));
      expect(view.netUnrealized(ChargesMode.delivery), closeTo(9870.08, 0.01));
      expect(view.isPriced, isTrue);
    });

    test('exposes stop-loss and target breaches for the watcher', () {
      final position = _position().copyWith(stopLoss: 950, target: 1200);
      expect(HoldingView(position: position, ltp: 940).stopBreached, isTrue);
      expect(HoldingView(position: position, ltp: 960).stopBreached, isFalse);
      expect(HoldingView(position: position, ltp: 1210).targetReached, isTrue);
      expect(HoldingView(position: position, ltp: 1100).targetReached, isFalse);
    });

    test('an unpriced holding reports nulls rather than zeros', () {
      final view = HoldingView(position: _position());
      expect(view.marketValue, isNull);
      expect(view.unrealizedPnl, isNull);
      expect(view.unrealizedPct, isNull);
      expect(view.netUnrealized(ChargesMode.delivery), isNull);
      expect(view.isPriced, isFalse);
    });
  });

  group('PendingOrderView', () {
    PaperOrder resting({OrderSide side = OrderSide.buy, double limit = 950}) =>
        PaperOrder(
          symbol: 'SBIN-EQ',
          exchange: Exchange.nse,
          side: side,
          quantity: 10,
          orderType: PaperOrderType.limit,
          limitPrice: limit,
          createdAt: _t0,
        );

    test('shows how far the market is from the limit', () {
      final view = PendingOrderView(order: resting(), ltp: 1000);
      expect(view.distancePct, closeTo(-5, 0.001));
      expect(view.isMarketable, isFalse);
    });

    test('flags an order that is already marketable', () {
      final view = PendingOrderView(order: resting(limit: 1010), ltp: 1000);
      expect(view.isMarketable, isTrue);
    });

    test('a buy becomes marketable when the price falls to the limit', () {
      final view = PendingOrderView(order: resting(limit: 950), ltp: 949);
      expect(view.isMarketable, isTrue);
      expect(view.distancePct, closeTo(0.105, 0.01));
    });

    test('a sell becomes marketable when the price rises to the limit', () {
      final view = PendingOrderView(
        order: resting(side: OrderSide.sell, limit: 1050),
        ltp: 1060,
      );
      expect(view.isMarketable, isTrue);
    });
  });

  group('grouping helpers', () {
    test('byGroup buckets holdings by their strategy tag', () {
      final grouped = PortfolioMath.byGroup([
        HoldingView(position: _position(groupId: 1)),
        HoldingView(position: _position(groupId: null)),
        HoldingView(position: _position(groupId: 1)),
      ]);

      expect(grouped[1], hasLength(2));
      expect(grouped[null], hasLength(1));
    });
  });
  // -------------------------------------------------------------------------
  // A written option (short) is a liability: the premium is already in cash, so
  // the position must enter the market value with a minus sign — otherwise the
  // account would count the premium twice.
  // -------------------------------------------------------------------------
  group('short positions in the account value', () {
    Position shortOption({int qty = 75, double avg = 120, double charges = 26}) =>
        Position(
          symbol: 'SBIN26OCT800CE',
          exchange: Exchange.nfo,
          token: '7001',
          quantity: qty,
          side: PositionSide.short,
          avgPrice: avg,
          chargesPaid: charges,
          openedAt: DateTime(2026, 10, 1, 10, 5),
        );

    test('the premium is not counted twice while the short is open', () {
      // Sold 75 @ 120 → cash 100000 + 9000 − 26 charges = 108974.
      final trades = [
        Trade(
          symbol: 'SBIN26OCT800CE',
          exchange: Exchange.nfo,
          token: '7001',
          side: OrderSide.sell,
          quantity: 75,
          price: 120,
          charges: 26,
          executedAt: DateTime(2026, 10, 1, 10, 5),
        ),
      ];
      final snapshot = PortfolioMath.snapshot(
        startingCapital: 100000,
        trades: trades,
        // Premium fell to 90 → the writer is up (120 − 90) × 75 = 2250 gross.
        holdings: [
          HoldingView(position: shortOption(), ltp: 90),
        ],
      );

      expect(snapshot.availableCash, closeTo(108974, 0.01));
      expect(snapshot.marketValue, closeTo(-6750, 0.01)); // −90 × 75
      expect(snapshot.unrealizedPnl, closeTo(2250, 0.01));
      // 100000 + 2250 − 26 (open charges) = 102224.
      expect(snapshot.portfolioValue, closeTo(102224, 0.01));
      expect(snapshot.netTotalPnl, closeTo(2224, 0.01));
    });

    test('after a full cover the account is just cash + realised P&L', () {
      Trade leg(OrderSide side, double price, double charges, double? pnl) =>
          Trade(
            symbol: 'SBIN26OCT800CE',
            exchange: Exchange.nfo,
            token: '7001',
            side: side,
            quantity: 75,
            price: price,
            charges: charges,
            realizedPnl: pnl,
            executedAt: DateTime(2026, 10, 1, 10, 5),
          );

      final snapshot = PortfolioMath.snapshot(
        startingCapital: 100000,
        trades: [
          leg(OrderSide.sell, 120, 26, null),
          leg(OrderSide.buy, 90, 20, 2250 - 26 - 20),
        ],
        holdings: const [],
      );

      expect(snapshot.availableCash, closeTo(100000 + 2204, 0.01));
      expect(snapshot.marketValue, 0);
      expect(snapshot.realizedPnl, closeTo(2204, 0.01));
      expect(snapshot.portfolioValue, closeTo(102204, 0.01));
    });
  });

}
