// ---------------------------------------------------------------------------
// report_math_test.dart — the Reports tab's arithmetic.
//
// Pure functions over in-memory fixtures, so every number the Reports tab shows
// can be pinned down here: monthly buckets (including empty months), win/loss
// classification, the per-group roll-up with live open exposure, the headline
// stats and the chart's group cap.
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/models/paper_trade.dart';
import 'package:angel_trader/data/local/models/trade_group.dart';
import 'package:angel_trader/features/paper_trading/portfolio_math.dart';
import 'package:angel_trader/features/paper_trading/report_math.dart';
import 'package:flutter_test/flutter_test.dart';

/// A closing leg with a result.
Trade closed({
  required String symbol,
  required double pnl,
  required DateTime at,
  int? groupId,
  int quantity = 10,
  double price = 100,
  double charges = 20,
}) =>
    Trade(
      symbol: symbol,
      exchange: Exchange.nse,
      side: OrderSide.sell,
      quantity: quantity,
      price: price,
      positionId: 1,
      groupId: groupId,
      realizedPnl: pnl,
      charges: charges,
      executedAt: at,
      note: 'exit',
    );

/// An opening leg (no result yet) — must never be counted as a closed trade.
Trade opened({
  required String symbol,
  required DateTime at,
  int? groupId,
  int quantity = 10,
  double price = 100,
  double charges = 12,
}) =>
    Trade(
      symbol: symbol,
      exchange: Exchange.nse,
      side: OrderSide.buy,
      quantity: quantity,
      price: price,
      positionId: 1,
      groupId: groupId,
      charges: charges,
      executedAt: at,
      note: 'entry',
    );

Position position({
  required String symbol,
  required int quantity,
  required double avgPrice,
  int? groupId,
  double chargesPaid = 15,
}) =>
    Position(
      id: 1,
      symbol: symbol,
      exchange: Exchange.nse,
      quantity: quantity,
      avgPrice: avgPrice,
      groupId: groupId,
      chargesPaid: chargesPaid,
      openedAt: DateTime(2026, 9, 1),
    );

void main() {
  final now = DateTime(2026, 10, 15, 12, 0);

  // -------------------------------------------------------------------------
  group('monthly()', () {
    test('buckets by month, sums charges and keeps empty months', () {
      final trades = [
        closed(symbol: 'A', pnl: 1000, at: DateTime(2026, 10, 3), charges: 30),
        closed(symbol: 'B', pnl: -400, at: DateTime(2026, 10, 9), charges: 20),
        closed(symbol: 'C', pnl: 250, at: DateTime(2026, 8, 20), charges: 10),
        opened(symbol: 'D', at: DateTime(2026, 10, 11), charges: 5),
      ];

      final months = ReportMath.monthly(trades, now: now, months: 3);
      expect(months, hasLength(3));
      expect(months.map((m) => m.monthKey), ['2026-08', '2026-09', '2026-10']);

      final august = months.first;
      expect(august.realized, 250);
      expect(august.closedTrades, 1);
      expect(august.wins, 1);
      expect(august.label, 'Aug 26');

      final september = months[1];
      expect(september.isEmpty, isTrue, reason: 'no trades → kept as zeroes');
      expect(september.realized, 0);
      expect(september.winRate, 0);

      final october = months.last;
      expect(october.realized, 600, reason: '1000 − 400');
      expect(october.closedTrades, 2, reason: 'the opening leg is not a result');
      expect(october.wins, 1);
      expect(october.losses, 1);
      expect(october.winRate, 0.5);
      expect(october.charges, 55, reason: '30 + 20 + 5 across every leg');
      expect(october.biggestWin, 1000);
      expect(october.biggestLoss, -400);
    });

    test('the window slides with `now`, and older trades fall outside it', () {
      final trades = [
        closed(symbol: 'OLD', pnl: 5000, at: DateTime(2025, 1, 5)),
        closed(symbol: 'NEW', pnl: 100, at: DateTime(2026, 10, 3)),
      ];

      final months = ReportMath.monthly(trades, now: now, months: 12);
      expect(months, hasLength(12));
      expect(months.first.monthKey, '2025-11');
      expect(months.last.monthKey, '2026-10');
      expect(months.map((m) => m.realized).reduce((a, b) => a + b), 100,
          reason: 'the 2025 trade is outside the 12-month window');
    });

    test('a break-even leg counts as closed but not as a win', () {
      final months = ReportMath.monthly(
        [closed(symbol: 'X', pnl: 0, at: DateTime(2026, 10, 3))],
        now: now,
        months: 1,
      );
      expect(months.single.closedTrades, 1);
      expect(months.single.wins, 0);
      expect(months.single.losses, 1);
      expect(months.single.winRate, 0);
    });
  });

  // -------------------------------------------------------------------------
  group('byGroup()', () {
    final momentum = TradeGroup(
      id: 1,
      name: 'Momentum',
      colorIndex: 0,
      createdAt: DateTime(2026, 1, 1),
    );
    final swing = TradeGroup(
      id: 2,
      name: 'Swing',
      colorIndex: 1,
      createdAt: DateTime(2026, 1, 1),
      archived: true,
    );

    test('rolls realised P&L up per group, best first, with Ungrouped last',
        () {
      final trades = [
        closed(symbol: 'A', pnl: 1000, at: DateTime(2026, 10, 3), groupId: 1),
        closed(symbol: 'B', pnl: -300, at: DateTime(2026, 10, 4), groupId: 1),
        closed(symbol: 'C', pnl: 500, at: DateTime(2026, 10, 5), groupId: 2),
        closed(symbol: 'D', pnl: 2000, at: DateTime(2026, 10, 6), groupId: null),
        closed(symbol: 'E', pnl: 10, at: DateTime(2026, 10, 7), groupId: 1),
      ];

      final reports = ReportMath.byGroup(
        trades: trades,
        groups: [momentum, swing],
        holdings: const [],
      );

      // Ungrouped (+2000) is the best, then Momentum (+710), then Swing (+500).
      expect(reports.map((r) => r.name),
          [kUngroupedLabel, 'Momentum', 'Swing']);

      final momentumReport = reports[1];
      expect(momentumReport.groupId, 1);
      expect(momentumReport.realized, 710);
      expect(momentumReport.closedTrades, 3);
      expect(momentumReport.wins, 2);
      expect(momentumReport.losses, 1);
      expect(momentumReport.hasHistory, isTrue);
      expect(momentumReport.hasOpen, isFalse);
      expect(momentumReport.total, 710);

      final swingReport = reports[2];
      expect(swingReport.archived, isTrue,
          reason: 'archiving hides a group from the picker, not from Reports');
      expect(swingReport.realized, 500);
    });

    test('groups with only open positions are listed after groups with results',
        () {
      final trades = [
        closed(symbol: 'A', pnl: -100, at: DateTime(2026, 10, 3), groupId: 2),
      ];
      final holdings = [
        HoldingView(
          position: position(symbol: 'NEW', quantity: 100, avgPrice: 50, groupId: 1),
          ltp: 55,
          groupName: 'Momentum',
        ),
      ];

      final reports = ReportMath.byGroup(
        trades: trades,
        groups: [momentum, swing],
        holdings: holdings,
      );

      expect(reports, hasLength(2));
      expect(reports.first.name, 'Swing', reason: 'has realised history');
      final openOnly = reports.last;
      expect(openOnly.name, 'Momentum');
      expect(openOnly.hasHistory, isFalse);
      expect(openOnly.openCount, 1);
      expect(openOnly.openInvested, 5000);
      expect(openOnly.openUnrealized, 500, reason: '(55 − 50) × 100');
      expect(openOnly.openPriced, 1);
      expect(openOnly.total, 500, reason: 'realised 0 + unrealised 500');
    });

    test('an unpriced holding contributes exposure but no unrealised P&L', () {
      final holdings = [
        HoldingView(
          position: position(symbol: 'NO', quantity: 10, avgPrice: 100, groupId: 1),
        ),
        HoldingView(
          position: position(symbol: 'OK', quantity: 10, avgPrice: 100, groupId: 1),
          ltp: 110,
        ),
      ];

      final reports = ReportMath.byGroup(
        trades: const [],
        groups: [momentum],
        holdings: holdings,
      );

      final report = reports.single;
      expect(report.openCount, 2);
      expect(report.openInvested, 2000);
      expect(report.openUnrealized, 100, reason: 'only the priced one counts');
      expect(report.openPriced, 1);
    });

    test('groups appear only when they have history or exposure', () {
      final reports = ReportMath.byGroup(
        trades: [closed(symbol: 'A', pnl: 10, at: DateTime(2026, 10, 3), groupId: 1)],
        groups: [momentum, swing, TradeGroup(
          id: 3,
          name: 'Unused',
          createdAt: DateTime(2026, 1, 1),
        )],
        holdings: const [],
      );
      expect(reports.map((r) => r.name), ['Momentum']);
    });
  });

  // -------------------------------------------------------------------------
  group('overall()', () {
    test('headline stats, profit factor and best/worst month', () {
      final trades = [
        closed(symbol: 'A', pnl: 1000, at: DateTime(2026, 10, 3), charges: 30),
        closed(symbol: 'B', pnl: -400, at: DateTime(2026, 10, 4), charges: 20),
        closed(symbol: 'C', pnl: 600, at: DateTime(2026, 9, 20), charges: 10),
        closed(symbol: 'D', pnl: -100, at: DateTime(2026, 9, 21), charges: 5),
      ];

      final stats = ReportMath.overall(trades, now: now);
      expect(stats.realized, 1100);
      expect(stats.charges, 65);
      expect(stats.closedTrades, 4);
      expect(stats.wins, 2);
      expect(stats.losses, 2);
      expect(stats.winRate, 0.5);
      expect(stats.expectancy, 275);
      expect(stats.biggestWin, 1000);
      expect(stats.biggestLoss, -400);
      expect(stats.profitFactor, closeTo(1600 / 500, 1e-9));
      expect(stats.bestMonth?.monthKey, '2026-10');
      expect(stats.worstMonth?.monthKey, '2026-09');
    });

    test('profit factor is null until there is a losing trade', () {
      final winning = ReportMath.overall(
        [closed(symbol: 'A', pnl: 100, at: DateTime(2026, 10, 3))],
        now: now,
      );
      expect(winning.profitFactor, isNull);
      expect(winning.winRate, 1);

      final empty = ReportMath.overall(const [], now: now);
      expect(empty.profitFactor, isNull);
      expect(empty.winRate, 0);
      expect(empty.expectancy, 0);
      expect(empty.bestMonth, isNull);
      expect(empty.realized, 0);
    });

    test('best/worst month ignore the empty months of the window', () {
      final stats = ReportMath.overall(
        [closed(symbol: 'A', pnl: -50, at: DateTime(2026, 10, 3))],
        now: now,
      );
      expect(stats.bestMonth?.realized, -50,
          reason: 'an empty month is never "best"');
      expect(stats.worstMonth?.realized, -50);
    });
  });

  // -------------------------------------------------------------------------
  group('chartGroups()', () {
    test('caps the legend at the palette size, best performers first', () {
      final groups = [
        for (var i = 0; i < 10; i++)
          TradeGroup(
            id: i + 1,
            name: 'G$i',
            colorIndex: i % kTradeGroupPaletteSize,
            createdAt: DateTime(2026, 1, 1),
          ),
      ];
      final trades = [
        for (var i = 0; i < 10; i++)
          closed(
            symbol: 'S$i',
            pnl: (i + 1) * 100.0,
            at: DateTime(2026, 10, 3),
            groupId: i + 1,
          ),
      ];

      final reports = ReportMath.byGroup(
        trades: trades,
        groups: groups,
        holdings: const [],
      );
      final charted = ReportMath.chartGroups(reports);
      expect(charted, hasLength(kTradeGroupPaletteSize));
      expect(charted.first.realized, 1000, reason: 'best first');
      expect(charted.map((r) => r.groupId), isNot(contains(1)),
          reason: 'the two weakest groups are dropped');
    });
  });

  // -------------------------------------------------------------------------
  group('monthKeyOf()', () {
    test('zero-pads the month', () {
      expect(ReportMath.monthKeyOf(DateTime(2026, 1, 9)), '2026-01');
      expect(ReportMath.monthKeyOf(DateTime(2026, 12, 31)), '2026-12');
    });
  });
}
