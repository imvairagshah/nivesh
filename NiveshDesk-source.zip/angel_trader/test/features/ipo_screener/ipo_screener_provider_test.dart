// ---------------------------------------------------------------------------
// ipo_screener_provider_test.dart — regression tests for the "IPO screen shows
// nothing, and no scan ever seems to start" bug report.
//
// The screener used to fail silently: without a session (or when the broker
// returned no prices) every row was dropped, no message was shown, and the user
// was left staring at an empty list that looked like a broken app.
//
// What is pinned down here:
//   * every empty state carries a *reason* (ScreenerNotice) the UI can act on
//   * a completed scan is timestamped, so "did it start?" is answerable
//   * the "All screened" view lists rows outside the ±band (isInBand == false)
//     while the near-high / near-low counters keep counting only in-band rows
//
// NO NETWORK: real SQLite (FFI, in-memory) + real DAOs + the bundled starter
// scrip master; only MarketDataService is faked.
// ---------------------------------------------------------------------------

import 'dart:convert';

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/ipo_dao.dart';
import 'package:angel_trader/data/local/dao/scan_cache_dao.dart';
import 'package:angel_trader/data/local/dao/scrip_dao.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/data/local/models/ipo.dart';
import 'package:angel_trader/data/remote/api_client.dart';
import 'package:angel_trader/data/remote/dto/quote.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/data/remote/dto/session.dart';
import 'package:angel_trader/features/ipo_screener/ipo_screener_provider.dart';
import 'package:angel_trader/features/settings/settings_provider.dart';
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/services/auth_service.dart';
import 'package:angel_trader/services/candle_source.dart';
import 'package:angel_trader/services/ipo_discovery_service.dart';
import 'package:angel_trader/services/market_data_service.dart';
import 'package:angel_trader/services/scrip_master_service.dart';
import 'package:angel_trader/services/secure_store.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

/// Three rows that exercise both outcomes: two hug a level, one sits between
/// the levels (inside the listing range but far from both).
///
///   IDEA  high 20.00  low 15.00  → LTP 19.70 = 1.50 % below high   (in band)
///   SBIN  high 700.00 low 600.00 → LTP 684.00 = 2.29 % below high  (in band)
///   NYKAA high 100.00 low 80.00  → LTP 90.00  = 10 % / 12.5 % away (outside)
const String _csv = '''
Symbol,Company Name,Exchange,Listing Date,Listing High,Listing Low,Sector,Notes
IDEA,Vodafone Idea Ltd,NSE,01-Jan-2016,20.00,15.00,Telecom,test fixture
SBIN,State Bank of India,NSE,01-Jan-2015,700.00,600.00,Banking,test fixture
NYKAA,FSN E Commerce Ventures Ltd,NSE,10-Nov-2021,100.00,80.00,Consumer,test fixture
''';

/// Same idea, but the levels are unknown — the shape of the bundled 2015+
/// master, whose highs/lows the app fetches from the broker itself.
const String _csvWithoutLevels = '''
Symbol,Company Name,Exchange,Listing Date,Listing High,Listing Low,Sector,Notes
IDEA,Vodafone Idea Ltd,NSE,01-Jan-2016,,,,Mainboard IPO 2016
''';

const Map<String, double> _prices = {
  'NSE:IDEA': 19.70,
  'NSE:SBIN': 684.00,
  'NSE:NYKAA': 90.00,
};

Map<String, PricedValue> get _quoteMap => {
      for (final entry in _prices.entries)
        entry.key: PricedValue(
          value: entry.value,
          asOf: DateTime.now(),
          isLive: true,
        ),
    };

/// Stands in for the REST quote call: the tests decide what comes back.
class _FakeMarketData extends MarketDataService {
  _FakeMarketData({required super.auth});

  Map<String, PricedValue> next = const {};
  Object? failure;
  int calls = 0;

  @override
  Future<Map<String, PricedValue>> fetchLtp(List<Scrip> scrips) async {
    calls++;
    final error = failure;
    if (error != null) throw error;
    return next;
  }
}

String _longLivedJwt() {
  String segment(Map<String, dynamic> payload) =>
      base64Url.encode(utf8.encode(jsonEncode(payload))).replaceAll('=', '');
  return '${segment({'alg': 'HS512'})}.${segment({'exp': 4070908800})}.sig';
}

Future<AuthService> _auth({required bool loggedIn}) async {
  FlutterSecureStorage.setMockInitialValues(
    loggedIn
        ? {
            'angel_session_v1': jsonEncode(
              AngelSession(
                apiKey: 'test-api-key',
                clientCode: 'A123456',
                jwtToken: _longLivedJwt(),
                refreshToken: 'refresh-token',
                feedToken: 'feed-token-xyz',
                generatedAt: DateTime(2026, 10, 1, 9, 0),
              ).toJson(),
            ),
          }
        : const {},
  );
  final auth = AuthService(store: SecureStore());
  await auth.restore();
  return auth;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late AppDatabase db;
  late SettingsProvider settings;
  late ScripMasterService master;
  late _FakeMarketData marketData;

  /// Polls until [condition] holds — discovery is kicked off unawaited during
  /// `bootstrap()`, so a fixed sleep would be flaky.
  Future<void> waitFor(
    bool Function() condition, {
    required String reason,
    int timeoutMs = 3000,
  }) async {
    final deadline = DateTime.now().add(Duration(milliseconds: timeoutMs));
    while (DateTime.now().isBefore(deadline)) {
      if (condition()) return;
      await Future<void>.delayed(const Duration(milliseconds: 10));
    }
    fail('Timed out waiting for: $reason');
  }

  Future<IpoScreenerProvider> buildProvider({
    required bool loggedIn,
    IpoDiscoveryService? discovery,
  }) async {
    final auth = await _auth(loggedIn: loggedIn);
    expect(auth.isLoggedIn, loggedIn, reason: 'auth fixture');
    marketData = _FakeMarketData(auth: auth);
    final provider = IpoScreenerProvider(
      ipoDao: IpoDao(db),
      cacheDao: ScanCacheDao(db),
      scripMaster: master,
      marketData: marketData,
      auth: auth,
      settings: settings,
      settingsDao: SettingsDao(db),
      discovery: discovery,
    );
    return provider;
  }

  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close();
    db = AppDatabase.instance;

    settings = SettingsProvider(SettingsDao(db));
    await settings.load();

    // Bundled starter master — no download, same 122 rows that ship in the APK.
    master = ScripMasterService(
      scripDao: ScripDao(db),
      settingsDao: SettingsDao(db),
    );
    await master.initialise();

    await IpoDao(db).seedFromCsv(_csv);
    // Mark the bundled IPO master as already merged: without this, `bootstrap()`
    // would fold the real 550-row universe into every fixture (that behaviour
    // has its own tests in the group below).
    await SettingsDao(db).putMeta(
      IpoScreenerProvider.seedRevisionKey,
      IpoScreenerProvider.seedRevision,
    );
  });

  group('empty states always explain themselves', () {
    test('no session → loggedOut notice, rows counted, nothing silent', () async {
      final provider = await buildProvider(loggedIn: false);
      await provider.bootstrap();

      expect(provider.notice, ScreenerNotice.loggedOut);
      expect(provider.matches, isEmpty);
      expect(provider.totalRows, 3, reason: 'the database still has its rows');
      expect(provider.result.pricedCount, 0);
      expect(marketData.calls, 0, reason: 'never call the broker when logged out');
      expect(provider.scanSummary, contains('Not scanned'),
          reason: 'a scan that never ran must say so');
      expect(provider.error, isNull, reason: 'a reason is not an error');
    });

    test('broker answering empty → noPrices notice', () async {
      final provider = await buildProvider(loggedIn: true);
      marketData.next = const {};
      await provider.bootstrap();

      expect(provider.notice, ScreenerNotice.noPrices);
      expect(provider.matches, isEmpty);
      expect(marketData.calls, greaterThan(0));
      expect(provider.lastScanAt, isNotNull);
    });

    test('expired session → sessionExpired notice (offers a re-login)', () async {
      final provider = await buildProvider(loggedIn: true);
      marketData.failure = const ApiException(
        message: 'Invalid Token',
        errorCode: 'AG8001',
        isAuthError: true,
      );
      await provider.bootstrap();

      expect(provider.notice, ScreenerNotice.sessionExpired);
      expect(provider.matches, isEmpty);
    });
  });

  group('the bundled IPO master', () {
    test('is merged into an older install without touching user rows', () async {
      // Simulate a 1.3.1 install: one hand-added row, no seed marker.
      await SettingsDao(db).putMeta(IpoScreenerProvider.seedRevisionKey, '1');
      final dao = IpoDao(db);
      await dao.deleteAll();
      await dao.insert(Ipo(
        symbol: 'MYSTOCK',
        companyName: 'My Own Stock Ltd',
        exchange: Exchange.nse,
        listingDate: DateTime(2022, 5, 5),
        listingHigh: 100,
        listingLow: 90,
        isCustom: true,
      ));

      final provider = await buildProvider(loggedIn: true);
      await provider.bootstrap();

      final rows = await dao.all();
      // The custom row survived with its values…
      final mine = rows.firstWhere((r) => r.symbol == 'MYSTOCK');
      expect(mine.listingHigh, 100);
      expect(mine.isCustom, isTrue);
      // …and the whole bundled universe arrived alongside it.
      expect(rows.length, greaterThan(500));
      // The master ships with listing-day levels for (almost) every row, so
      // only a small tail still depends on a runtime fetch.
      final withLevels = rows.where((r) => r.hasLevels).length;
      expect(withLevels, greaterThan(500));
      expect(provider.levelsPending, lessThan(20));
    });

    test('fills blank levels on rows that shipped before the levels existed',
        () async {
      // A 1.3.2 install: the row exists with a listing date but no levels.
      final dao = IpoDao(db);
      await dao.insert(Ipo(
        symbol: 'LEVELCO',
        companyName: 'Level Co Limited',
        exchange: Exchange.nse,
        listingDate: DateTime(2021, 11, 10),
        listingHigh: 0,
        listingLow: 0,
      ));
      // …and one the user typed levels into: it must never be overwritten.
      final typed = await dao.insert(Ipo(
        symbol: 'MYSTOCK',
        companyName: 'My Own Stock Ltd',
        exchange: Exchange.nse,
        listingDate: DateTime(2022, 5, 5),
        listingHigh: 111,
        listingLow: 99,
        levelsSource: 'user',
        isCustom: true,
      ));

      await dao.backfillLevelsFromCsv(
        'Symbol,Company Name,Exchange,Listing Date,Listing High,Listing Low\n'
        'LEVELCO,Level Co Limited,NSE,10-Nov-2021,2205,1810\n'
        'MYSTOCK,My Own Stock Ltd,NSE,05-May-2022,555,444\n',
      );

      final rows = await dao.all();
      final levelco = rows.firstWhere((r) => r.symbol == 'LEVELCO');
      expect(levelco.listingHigh, 2205);
      expect(levelco.listingLow, 1810);
      expect(levelco.levelsSource, 'seed');

      final mine = rows.firstWhere((r) => r.id == typed);
      expect(mine.listingHigh, 111, reason: 'user-entered levels are untouched');
      expect(mine.levelsSource, 'user');
    });

    test('repairs a ticker that was renamed after the master was cut', () async {
      // An install from before the rename: the row carries the old ticker.
      await SettingsDao(db).putMeta(IpoScreenerProvider.seedRevisionKey, '3-bhavcopy-levels');
      final dao = IpoDao(db);
      await dao.deleteAll();
      await dao.insert(Ipo(
        symbol: 'LTIM',
        companyName: 'Lti Mindtree Limited',
        exchange: Exchange.nse,
        listingDate: DateTime(2016, 7, 21),
        listingHigh: 710,
        listingLow: 666,
        notes: 'Mainboard IPO 2016',
      ));

      final provider = await buildProvider(loggedIn: true);
      await provider.bootstrap();

      final rows = await dao.all();
      expect(rows.any((r) => r.symbol == 'LTIM'), isFalse,
          reason: 'the stale ticker must be gone');
      final repaired = rows.firstWhere((r) => r.symbol == 'LTM');
      expect(repaired.companyName, 'Ltm Limited');
      expect(repaired.listingDate, DateTime(2016, 7, 21));
      expect(repaired.listingHigh, 710, reason: 'levels survive the rename');
      expect(repaired.notes, contains('LTIM → LTM'));
    });

    test('a repaired ticker never duplicates the row the file already has',
        () async {
      await SettingsDao(db).putMeta(IpoScreenerProvider.seedRevisionKey, '3-bhavcopy-levels');
      final dao = IpoDao(db);
      await dao.deleteAll();
      // Both the stale ticker and the current one are present (the merge added
      // the new one first on some earlier run).
      await dao.insert(Ipo(
        symbol: 'AMIORG',
        companyName: 'Ami Organics Limited',
        exchange: Exchange.nse,
        listingDate: DateTime(2021, 9, 14),
        listingHigh: 966.70,
        listingLow: 841,
      ));
      await dao.insert(Ipo(
        symbol: 'ACUTAAS',
        companyName: 'Acutaas Chemicals Limited',
        exchange: Exchange.nse,
        listingDate: DateTime(2021, 9, 14),
        listingHigh: 966.70,
        listingLow: 841,
        levelsSource: 'seed',
      ));

      final provider = await buildProvider(loggedIn: true);
      await provider.bootstrap();

      final rows = await dao.all();
      expect(rows.where((r) => r.symbol == 'AMIORG'), isEmpty);
      expect(rows.where((r) => r.symbol == 'ACUTAAS').length, 1);
    });

    test('is not re-merged once the revision is recorded', () async {
      await SettingsDao(db).putMeta(IpoScreenerProvider.seedRevisionKey, '1');
      final dao = IpoDao(db);
      await dao.deleteAll();
      final first = await buildProvider(loggedIn: true);
      await first.bootstrap();
      final seeded = (await dao.all()).length;

      // A deliberate deletion must survive the next launch.
      final victim = (await dao.all()).first;
      await dao.delete(victim.id!);

      final second = await buildProvider(loggedIn: true);
      await second.bootstrap();

      expect((await dao.all()).length, seeded - 1);
    });
  });

  group('rows that still need their listing levels', () {
    test('are counted, and explained when they are why nothing matched',
        () async {
      await IpoDao(db).deleteAll();
      await IpoDao(db).seedFromCsv(_csvWithoutLevels);

      final provider = await buildProvider(loggedIn: true);
      marketData.next = _quoteMap;
      await provider.bootstrap();

      // A row without levels cannot be screened…
      expect(provider.matches, isEmpty);
      // …so the screen must not claim "nothing is near its level today"; it
      // explains that the levels are still being fetched.
      expect(provider.levelsPending, 1);
      expect(provider.notice, ScreenerNotice.levelsNeeded);
      expect(provider.levelsLabel, contains('1 IPO'));
      expect(provider.levelsComplete, isFalse);
      // The row is reported, not silently dropped.
      expect(provider.skipped, hasLength(1));
      expect(
        provider.skipped.single.reason,
        'Listing-day high/low not fetched yet.',
      );
    });

    test('complete levels report as complete', () async {
      final provider = await buildProvider(loggedIn: true);
      marketData.next = _quoteMap;
      await provider.bootstrap();

      expect(provider.levelsPending, 0);
      expect(provider.levelsComplete, isTrue);
      expect(provider.levelsLabel, 'Listing levels complete');
    });
  });

  group('a successful scan', () {
    test('reports live prices, matches and a scan timestamp', () async {
      final provider = await buildProvider(loggedIn: true);
      marketData.next = _quoteMap;
      await provider.bootstrap();

      expect(provider.notice, isNull);
      expect(provider.source, ScreenerSource.live);
      expect(provider.lastScanAt, isNotNull);
      expect(provider.scanSummary, contains('Scanned 3 of 3'));
      expect(provider.totalRows, 3);

      // Only the two rows hugging a level — NYKAA is 10 % away.
      expect(provider.matches, hasLength(2));
      expect(
        provider.matches.map((m) => m.ipo.symbol).toSet(),
        {'IDEA', 'SBIN'},
      );
      expect(provider.matches.every((m) => m.isInBand), isTrue);
      expect(provider.result.nearHighCount, 2);
      expect(provider.result.nearLowCount, 0);
    });

    test('"All screened" lists the rest, flagged as outside the band', () async {
      final provider = await buildProvider(loggedIn: true);
      marketData.next = _quoteMap;
      await provider.bootstrap();
      expect(provider.bandOnly, isTrue, reason: 'spec view by default');

      provider.setBandOnly(false);

      expect(provider.matches, hasLength(3));
      final nykaa = provider.matches.firstWhere((m) => m.ipo.symbol == 'NYKAA');
      expect(nykaa.isInBand, isFalse);
      expect(nykaa.proximityLabel, '10.00% below listing high');
      // Counters describe the spec rule, not the lifted view.
      expect(provider.result.nearHighCount, 2);
      expect(provider.result.nearLowCount, 0);
    });

    test('nearestOutsideBand returns the runners-up, closest first', () async {
      final provider = await buildProvider(loggedIn: true);
      marketData.next = _quoteMap;
      await provider.bootstrap();

      final nearby = provider.nearestOutsideBand();
      expect(nearby, hasLength(1));
      expect(nearby.single.ipo.symbol, 'NYKAA');
      expect(nearby.single.distancePct, closeTo(10, 1e-6));
    });

    test('clearFilters restores the ±band view', () async {
      final provider = await buildProvider(loggedIn: true);
      marketData.next = _quoteMap;
      await provider.bootstrap();
      provider.setBandOnly(false);
      expect(provider.bandOnly, isFalse);

      provider.clearFilters();

      expect(provider.bandOnly, isTrue);
      expect(provider.matches, hasLength(2));
    });
  });

  group('automatically discovered listings', () {
    test('a run that adds rows puts them in the database and shows the banner',
        () async {
      final dao = IpoDao(db);
      final discovered = Ipo(
        symbol: 'FRESHCO',
        companyName: 'Fresh Co Limited',
        exchange: Exchange.nse,
        listingDate: DateTime(2026, 10, 1),
        listingHigh: 150,
        listingLow: 120,
        notes: 'Auto-detected from NSE listing + broker data',
        levelsSource: 'auto',
      );
      final provider = await buildProvider(
        loggedIn: true,
        discovery: _StubDiscovery(
          dao: dao,
          scripMaster: master,
          report: DiscoveryReport(added: [discovered], probed: 1),
        ),
      );
      await provider.bootstrap();
      await waitFor(
        () => provider.discoveredRows.isNotEmpty,
        reason: 'the launch-time discovery run should surface its banner',
      );

      expect(provider.discoveredRows.single.symbol, 'FRESHCO');
      expect(provider.discoveryLabel, contains('FRESHCO'));
      // The row was written through the real DAO, so it is in the scan next pass.
      expect((await dao.all()).any((row) => row.symbol == 'FRESHCO'), isTrue);

      provider.dismissDiscovery();
      expect(provider.discoveryLabel, isNull);
    });

    test('a run that adds nothing leaves the screen untouched', () async {
      final provider = await buildProvider(
        loggedIn: true,
        discovery: _StubDiscovery(
          dao: IpoDao(db),
          scripMaster: master,
          report: const DiscoveryReport(),
        ),
      );
      await provider.bootstrap();
      await provider.discoverNewListings();

      expect(provider.discoveredRows, isEmpty);
      expect(provider.discoveryLabel, isNull);
    });
  });

    test('a row whose ticker no longer exists is reported, not silently stuck',
        () async {
      // The symptom this guards: the counter stops short of the total and the
      // user has no way to learn which rows are responsible.
      await IpoDao(db).insert(Ipo(
        symbol: 'GONECO',
        companyName: 'Gone Co Limited',
        exchange: Exchange.nse,
        listingDate: DateTime(2021, 5, 4),
        listingHigh: 100,
        listingLow: 90,
        levelsSource: 'seed',
      ));

      final provider = await buildProvider(loggedIn: true);
      await provider.bootstrap();

      expect(provider.attentionCount, greaterThanOrEqualTo(1));
      expect(provider.attentionLabel, contains('symbol exchange pe nahi'));
      final flagged = provider.attentionRows.map((row) => row.ipo.symbol);
      expect(flagged, contains('GONECO'));
      expect(
        provider.attentionRows
            .singleWhere((row) => row.ipo.symbol == 'GONECO')
            .needsAttention,
        isTrue,
      );
    });
}

/// Discovery double: the provider's job is only to react to a report, so the
/// network/candle machinery is replaced entirely (it has its own test file).
class _StubDiscovery extends IpoDiscoveryService {
  _StubDiscovery({
    required IpoDao dao,
    required super.scripMaster,
    required this.report,
  })  : _dao = dao,
        super(
          ipoDao: dao,
          candles: _NoCandles(),
          auth: AuthService(store: SecureStore()),
        );

  final IpoDao _dao;
  final DiscoveryReport report;
  bool _inserted = false;

  @override
  Future<DiscoveryReport> discoverNewListings({bool force = false}) async {
    // Once is enough — the provider may ask again (bootstrap + explicit call).
    if (!_inserted) {
      _inserted = true;
      for (final row in report.added) {
        await _dao.insert(row);
      }
    }
    return report;
  }
}

class _NoCandles implements CandleSource {
  @override
  Future<List<Candle>> fetchDailyCandles({
    required Scrip scrip,
    required DateTime from,
    required DateTime to,
    String interval = 'ONE_DAY',
  }) async =>
      const [];
}
