// Widget tests for the screener card — the spec's display requirement, verified
// as rendered output rather than as data:
//
//   "Display each stock as a card showing: Symbol & Company Name · Listing Date,
//    Listing High, Listing Low · Current Price · Which level it is near (High/Low)
//    and % difference. Each card has a 'Chart' button that opens TradingView."
//
// Also checks the two states that are easy to get wrong visually: a cached
// (stale) price and a price that has left the listing range entirely.

import 'package:angel_trader/core/theme/app_theme.dart';
import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/models/ipo.dart';
import 'package:angel_trader/features/ipo_screener/ipo_screener_engine.dart';
import 'package:angel_trader/features/ipo_screener/widgets/ipo_match_card.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

IpoMatch _match({
  String symbol = 'TATATECH',
  String company = 'Tata Technologies Ltd',
  Exchange exchange = Exchange.nse,
  double listingHigh = 1400,
  double listingLow = 1200,
  double ltp = 1382.25,
  LevelType level = LevelType.high,
  double diffPct = -1.27,
  double? changePct = 1.84,
  bool isStale = false,
  bool aboveRange = false,
}) =>
    IpoMatch(
      ipo: Ipo(
        symbol: symbol,
        companyName: company,
        exchange: exchange,
        listingDate: DateTime(2023, 11, 30),
        listingHigh: listingHigh,
        listingLow: listingLow,
      ),
      exchange: exchange,
      token: '20293',
      ltp: ltp,
      level: level,
      levelPrice: level == LevelType.high ? listingHigh : listingLow,
      diffPct: diffPct,
      distancePct: diffPct.abs(),
      band: level == LevelType.high ? PriceBand.nearHigh : PriceBand.nearLow,
      changePct: changePct,
      pricedAt: DateTime(2025, 9, 29, 15, 30),
      isStale: isStale,
      isAboveListingRange: aboveRange,
    );

Widget _wrap(Widget child, {Brightness brightness = Brightness.light}) => MaterialApp(
      theme: brightness == Brightness.dark ? AppTheme.dark() : AppTheme.light(),
      // Horizontal scroll gives the fixed-width table row its real width —
      // same as the screen's shared horizontal scroller (1.5.60).
      home: Scaffold(
        body: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: child,
        ),
      ),
    );

void main() {
  group('IpoMatchCard', () {
    testWidgets('shows symbol, company, listing levels, price and the level gap',
        (tester) async {
      await tester.pumpWidget(_wrap(IpoMatchCard(match: _match())));

      // Symbol & company name
      expect(find.text('TATATECH'), findsOneWidget);
      expect(find.text('Tata Technologies Ltd'), findsOneWidget);
      // Exchange tag
      expect(find.text('NSE'), findsOneWidget);
      // Current price (Indian grouping)
      expect(find.text('₹1,382.25'), findsOneWidget);
      // Listing date, high, low
      expect(find.text('30 Nov 23'), findsOneWidget);
      expect(find.text('1,400.00'), findsOneWidget);
      expect(find.text('1,200.00'), findsOneWidget);
      // Level + % difference
      expect(find.textContaining('Near High'), findsOneWidget);
      expect(find.textContaining('1.27%'), findsOneWidget);
      expect(find.textContaining('below'), findsOneWidget);
      // Day change
      expect(find.text('+1.84%'), findsOneWidget);
      // Chart button
      expect(find.widgetWithText(FilledButton, 'Chart'), findsOneWidget);
    });

    testWidgets('near-low cards say "above listing low"', (tester) async {
      await tester.pumpWidget(_wrap(IpoMatchCard(
        match: _match(
          symbol: 'NYKAA',
          level: LevelType.low,
          diffPct: 1.57,
          ltp: 1838.5,
        ),
      )));

      expect(find.textContaining('Near Low'), findsOneWidget);
      expect(find.textContaining('above'), findsOneWidget);
      // the chip reads "Near Low · 1.57% above" (no sign on a distance)
      expect(find.textContaining('1.57%'), findsOneWidget);
    });

    testWidgets('stale prices carry a "cached" badge', (tester) async {
      await tester.pumpWidget(_wrap(IpoMatchCard(match: _match(isStale: true))));
      expect(find.text('cached'), findsOneWidget);
    });

    testWidgets('a price that left the listing range still renders', (tester) async {
      // 5% above the listing high: the range marker must clamp, not overflow.
      await tester.pumpWidget(_wrap(IpoMatchCard(
        match: _match(ltp: 1470, diffPct: 5.0, aboveRange: true),
      )));
      expect(tester.takeException(), isNull);
      expect(find.text('₹1,470.00'), findsOneWidget);
      expect(find.textContaining('Near High'), findsOneWidget);
    });

    testWidgets('renders in dark mode too (MarketColors extension)', (tester) async {
      await tester.pumpWidget(_wrap(
        IpoMatchCard(match: _match()),
        brightness: Brightness.dark,
      ));
      expect(tester.takeException(), isNull);
      expect(find.text('TATATECH'), findsOneWidget);
    });

    testWidgets('BSE listings use the BSE trading symbol', (tester) async {
      await tester.pumpWidget(_wrap(IpoMatchCard(
        match: _match(
          symbol: 'DELHIVERY',
          exchange: Exchange.bse,
          listingHigh: 537,
          listingLow: 455,
          ltp: 458.4,
          level: LevelType.low,
          diffPct: 0.75,
        ),
      )));
      expect(find.text('BSE'), findsOneWidget);
      expect(find.text('DELHIVERY'), findsOneWidget);
    });
  });
}
