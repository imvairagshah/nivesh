// IPO screener engine tests — the money path of Feature 1.
//
// Covers the spec rule itself ("within ±3% of listing high OR listing low"),
// boundary behaviour, level labelling, filters, sorting, stale-price flags and
// the two ways a row can drop out (no token / no price).

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/models/ipo.dart';
import 'package:angel_trader/data/remote/dto/quote.dart';
import 'package:angel_trader/features/ipo_screener/ipo_screener_engine.dart';
import 'package:angel_trader/services/token_resolver.dart';
import 'package:flutter_test/flutter_test.dart';

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

const _masterRows = <Map<String, dynamic>>[
  {
    'token': '1594',
    'symbol': 'IDEA-EQ',
    'name': 'VODAFONE IDEA LIMITED',
    'expiry': '',
    'exch_seg': 'NSE',
    'instrumenttype': '',
    'tick_size': '5.000000',
  },
  {
    'token': '14366',
    'symbol': 'NYKAA-EQ',
    'name': 'FSN E COMMERCE VENTURES LIMITED',
    'expiry': '',
    'exch_seg': 'NSE',
    'instrumenttype': '',
    'tick_size': '5.000000',
  },
  {
    'token': '3045',
    'symbol': 'SBIN-EQ',
    'name': 'STATE BANK OF INDIA',
    'expiry': '',
    'exch_seg': 'NSE',
    'instrumenttype': '',
    'tick_size': '5.000000',
  },
  {
    'token': '543529',
    'symbol': 'DELHIVERY',
    'name': 'DELHIVERY LIMITED',
    'expiry': '',
    'exch_seg': 'BSE',
    'instrumenttype': '',
    'tick_size': '5.000000',
  },
  {
    'token': '9001',
    'symbol': 'EDGE-EQ',
    'name': 'EDGE CASES LIMITED',
    'expiry': '',
    'exch_seg': 'NSE',
    'instrumenttype': '',
    'tick_size': '5.000000',
  },
  {
    'token': '9002',
    'symbol': 'FARAWAY-EQ',
    'name': 'FARAWAY LIMITED',
    'expiry': '',
    'exch_seg': 'NSE',
    'instrumenttype': '',
    'tick_size': '5.000000',
  },
];

Ipo _ipo({
  required String symbol,
  Exchange exchange = Exchange.nse,
  double high = 100,
  double low = 80,
  DateTime? listed,
  String company = '',
  String sector = '',
}) =>
    Ipo(
      symbol: symbol,
      companyName: company.isEmpty ? '$symbol Ltd' : company,
      exchange: exchange,
      listingDate: listed ?? DateTime(2021, 5, 4),
      listingHigh: high,
      listingLow: low,
      sector: sector,
    );

/// Helper to build a price map the way the data layer does: `NSE:SYMBOL`.
Map<String, PricedValue> _prices(
  Map<String, double> byKey, {
  bool live = true,
  DateTime? asOf,
}) =>
    {
      for (final entry in byKey.entries)
        entry.key: PricedValue(
          value: entry.value,
          asOf: asOf ?? DateTime.now(),
          isLive: live,
        ),
    };

void main() {
  late IpoScreenerEngine engine;

  group('rows without a listing-day range', () {
    test('are skipped with a reason instead of crashing the band test', () {
      final result = engine.evaluate(
        items: engine.resolveAll([
          Ipo(
            symbol: 'IDEA',
            companyName: 'Vodafone Idea Ltd',
            exchange: Exchange.nse,
            listingDate: DateTime(2016, 1, 4),
            listingHigh: 0, // levels not fetched yet
            listingLow: 0,
          ),
        ]),
        prices: _prices({'NSE:IDEA': 20}),
      );

      expect(result.matches, isEmpty);
      expect(result.skipped, hasLength(1));
      expect(result.skipped.single.reason, 'Listing-day high/low not fetched yet.');
      expect(result.totalRows, 1);
    });

    test('say so when the levels could not be fetched at all', () {
      final result = engine.evaluate(
        items: engine.resolveAll([
          Ipo(
            symbol: 'IDEA',
            companyName: 'Vodafone Idea Ltd',
            exchange: Exchange.nse,
            listingDate: DateTime(2016, 1, 4),
            listingHigh: 0,
            listingLow: 0,
            levelsSource: 'missing',
          ),
        ]),
        prices: _prices({'NSE:IDEA': 20}),
      );

      expect(
        result.skipped.single.reason,
        'Listing-day high/low could not be fetched for this symbol '
        '(symbol not found on the exchange).',
      );
    });
  });

  setUpAll(() {
    engine = IpoScreenerEngine(TokenResolver.fromJson(_jsonArray(_masterRows)));
  });

  group('the ±3% rule', () {
    test('includes a stock inside the band below the listing high', () {
      // Listing high 100, LTP 98 → −2.00 % → match, labelled Near High.
      final result = engine.evaluate(
        items: engine.resolveAll([_ipo(symbol: 'IDEA', high: 100, low: 80)]),
        prices: _prices({'NSE:IDEA': 98}),
      );

      expect(result.matches, hasLength(1));
      final m = result.matches.single;
      expect(m.level, LevelType.high);
      expect(m.levelPrice, 100);
      expect(m.diffPct, closeTo(-2.0, 1e-9));
      expect(m.distancePct, closeTo(2.0, 1e-9));
      expect(m.band, PriceBand.nearHigh);
      expect(m.proximityLabel, '2.00% below listing high');
      expect(result.nearHighCount, 1);
      expect(result.nearLowCount, 0);
    });

    test('includes a stock inside the band above the listing low', () {
      final result = engine.evaluate(
        items: engine.resolveAll([_ipo(symbol: 'NYKAA', high: 100, low: 80)]),
        prices: _prices({'NSE:NYKAA': 81.5}),
      );
      final m = result.matches.single;
      expect(m.level, LevelType.low);
      expect(m.diffPct, closeTo(1.875, 1e-6));
      expect(m.proximityLabel, '1.88% above listing low');
    });

    test('includes a stock trading ABOVE the listing high within the band', () {
      final result = engine.evaluate(
        items: engine.resolveAll([_ipo(symbol: 'IDEA', high: 100, low: 80)]),
        prices: _prices({'NSE:IDEA': 102}),
      );
      final m = result.matches.single;
      expect(m.level, LevelType.high);
      expect(m.diffPct, closeTo(2.0, 1e-9));
      expect(m.isAboveListingRange, isTrue);
    });

    test('includes a price sitting exactly on the level', () {
      final result = engine.evaluate(
        items: engine.resolveAll([_ipo(symbol: 'IDEA', high: 100, low: 80)]),
        prices: _prices({'NSE:IDEA': 100}),
      );
      expect(result.matches, hasLength(1));
      expect(result.matches.single.distancePct, closeTo(0, 1e-9));
    });

    test('the 3.00 % boundary is inclusive, 3.01 % is not', () {
      final boundary = engine.evaluate(
        items: engine.resolveAll([_ipo(symbol: 'EDGE', high: 1000, low: 800)]),
        prices: _prices({'NSE:EDGE': 1030}),
      );
      expect(boundary.matches, hasLength(1), reason: '+3.00% must be included');

      final outside = engine.evaluate(
        items: engine.resolveAll([_ipo(symbol: 'EDGE', high: 1000, low: 800)]),
        prices: _prices({'NSE:EDGE': 1031}),
      );
      expect(outside.matches, isEmpty, reason: '+3.10% must be excluded');
    });

    test('excludes a stock that is mid-range (outside both bands)', () {
      final result = engine.evaluate(
        items: engine.resolveAll([_ipo(symbol: 'FARAWAY', high: 1000, low: 800)]),
        prices: _prices({'NSE:FARAWAY': 900}),
      );
      expect(result.matches, isEmpty);
      expect(result.considered, 1, reason: 'it was priced, just not a match');
      expect(result.skipped, isEmpty);
    });

    test('a custom band width is honoured', () {
      final items = engine.resolveAll([_ipo(symbol: 'FARAWAY', high: 1000, low: 800)]);
      final tight = engine.evaluate(
        items: items,
        prices: _prices({'NSE:FARAWAY': 900}),
        config: const IpoScreenerConfig(proximityPct: 6),
      );
      expect(tight.matches, isEmpty); // 900 is 10 % from both levels

      final wide = engine.evaluate(
        items: items,
        prices: _prices({'NSE:FARAWAY': 900}),
        config: const IpoScreenerConfig(proximityPct: 12),
      );
      expect(wide.matches, hasLength(1));
    });

    test('when both bands overlap the closer level wins', () {
      // Range ₹2 wide: high 102, low 100 → a ₹101 LTP is inside both bands.
      final result = engine.evaluate(
        items: engine.resolveAll([_ipo(symbol: 'EDGE', high: 102, low: 100)]),
        prices: _prices({'NSE:EDGE': 101}),
      );
      final m = result.matches.single;
      expect(m.distancePct, lessThanOrEqualTo(1.0));
      expect(m.level, LevelType.high); // default tie-break: high
    });
  });

  group('filters', () {
    final ipos = [
      _ipo(symbol: 'IDEA', high: 100, low: 80, listed: DateTime(2018, 1, 31), company: 'Vodafone Idea Ltd', sector: 'Telecom'),
      _ipo(symbol: 'NYKAA', high: 100, low: 80, listed: DateTime(2021, 11, 10), company: 'FSN E-Commerce Ventures Ltd', sector: 'Consumer'),
      _ipo(symbol: 'DELHIVERY', exchange: Exchange.bse, high: 100, low: 80, listed: DateTime(2022, 5, 24), company: 'Delhivery Ltd', sector: 'Logistics'),
    ];
    final prices = _prices({
      'NSE:IDEA': 98, // near high
      'NSE:NYKAA': 82, // near low
      'BSE:DELHIVERY': 81, // near low
    });

    test('exchange filter', () {
      final result = engine.evaluate(
        items: engine.resolveAll(ipos),
        prices: prices,
        filters: const IpoFilters(exchange: Exchange.bse),
      );
      expect(result.matches.map((m) => m.ipo.symbol), ['DELHIVERY']);
    });

    test('listing-year filter', () {
      final result = engine.evaluate(
        items: engine.resolveAll(ipos),
        prices: prices,
        filters: const IpoFilters(listingYear: 2021),
      );
      expect(result.matches.map((m) => m.ipo.symbol), ['NYKAA']);
    });

    test('near-high / near-low level filter', () {
      final nearLow = engine.evaluate(
        items: engine.resolveAll(ipos),
        prices: prices,
        filters: const IpoFilters(levels: {LevelType.low}),
      );
      expect(nearLow.matches.map((m) => m.ipo.symbol).toSet(), {'NYKAA', 'DELHIVERY'});
      expect(nearLow.nearHighCount, 0);
      expect(nearLow.nearLowCount, 2);
    });

    test('search matches symbol, company name and sector', () {
      List<String> run(String query) => engine
          .evaluate(
            items: engine.resolveAll(ipos),
            prices: prices,
            filters: IpoFilters(query: query),
          )
          .matches
          .map((m) => m.ipo.symbol)
          .toList();

      expect(run('vodafone'), ['IDEA']);
      expect(run('delhivery'), ['DELHIVERY']);
      expect(run('consumer'), ['NYKAA']);
      expect(run('zzz'), isEmpty);
    });

    test('combined filters intersect', () {
      final result = engine.evaluate(
        items: engine.resolveAll(ipos),
        prices: prices,
        filters: const IpoFilters(listingYear: 2018, levels: {LevelType.high}),
      );
      expect(result.matches.map((m) => m.ipo.symbol), ['IDEA']);
    });

    test('availableYears lists distinct years newest-first', () {
      expect(IpoScreenerEngine.availableYears(ipos), [2022, 2021, 2018]);
    });
  });

  group('sorting', () {
    final ipos = [
      _ipo(symbol: 'IDEA', high: 100, low: 80, listed: DateTime(2018, 1, 31)),
      _ipo(symbol: 'NYKAA', high: 100, low: 80, listed: DateTime(2021, 11, 10)),
      _ipo(symbol: 'EDGE', high: 100, low: 80, listed: DateTime(2020, 2, 2)),
    ];
    final prices = _prices({'NSE:IDEA': 99, 'NSE:NYKAA': 82, 'NSE:EDGE': 97});

    test('closest-to-level groups high before low and sorts by distance', () {
      final result = engine.evaluate(items: engine.resolveAll(ipos), prices: prices);
      expect(result.matches.map((m) => m.ipo.symbol), ['IDEA', 'EDGE', 'NYKAA']);
      // IDEA 1 % from high, EDGE 3 % from high, NYKAA 2.5 % from low
      expect(result.matches[2].level, LevelType.low);
    });

    test('symbol and newest-listing orderings', () {
      final alphabetical = engine.evaluate(
        items: engine.resolveAll(ipos),
        prices: prices,
        sort: IpoSortMode.symbol,
      );
      expect(alphabetical.matches.map((m) => m.ipo.symbol), ['EDGE', 'IDEA', 'NYKAA']);

      final newest = engine.evaluate(
        items: engine.resolveAll(ipos),
        prices: prices,
        sort: IpoSortMode.newestListing,
      );
      expect(newest.matches.first.ipo.symbol, 'NYKAA');
    });
  });

  group('skips, staleness and metadata', () {
    test('an unresolvable ticker is skipped with a reason, not silently dropped', () {
      final result = engine.evaluate(
        items: engine.resolveAll([_ipo(symbol: 'POLICYBZR', high: 100, low: 80)]),
        prices: _prices({'NSE:POLICYBZR': 99}),
      );
      expect(result.matches, isEmpty);
      expect(result.skipped, hasLength(1));
      expect(result.skipped.single.ipo.symbol, 'POLICYBZR');
      expect(result.skipped.single.reason, isNotEmpty);
      expect(result.resolvedCount, 0);
    });

    test('a resolvable ticker with no price yet is skipped (market closed / new token)', () {
      final result = engine.evaluate(
        items: engine.resolveAll([_ipo(symbol: 'SBIN', high: 100, low: 80)]),
        prices: const {},
      );
      expect(result.matches, isEmpty);
      expect(result.skipped.single.reason, contains('No price received'));
      expect(result.resolvedCount, 1);
      expect(result.pricedCount, 0);
    });

    test('stale prices are flagged when not live', () {
      final old = DateTime.now().subtract(const Duration(hours: 3));
      final result = engine.evaluate(
        items: engine.resolveAll([_ipo(symbol: 'IDEA', high: 100, low: 80)]),
        prices: _prices({'NSE:IDEA': 98}, live: false, asOf: old),
      );
      expect(result.matches.single.isStale, isTrue);
      expect(result.staleCount, 1);

      final fresh = engine.evaluate(
        items: engine.resolveAll([_ipo(symbol: 'IDEA', high: 100, low: 80)]),
        prices: _prices({'NSE:IDEA': 98}),
      );
      expect(fresh.matches.single.isStale, isFalse);
    });

    test('cache runs are marked isFromCache with their timestamp', () {
      final result = engine.evaluate(
        items: engine.resolveAll([_ipo(symbol: 'IDEA', high: 100, low: 80)]),
        prices: _prices({'NSE:IDEA': 98}),
        isFromCache: true,
        now: DateTime(2025, 9, 29, 16, 0),
      );
      expect(result.isFromCache, isTrue);
      expect(result.generatedAt, DateTime(2025, 9, 29, 16, 0));
    });

    test('counters describe the whole run', () {
      final result = engine.evaluate(
        items: engine.resolveAll([
          _ipo(symbol: 'IDEA', high: 100, low: 80), // match
          _ipo(symbol: 'NYKAA', high: 100, low: 80), // no price
          _ipo(symbol: 'NOPE', high: 100, low: 80), // unresolvable
          _ipo(symbol: 'FARAWAY', high: 1000, low: 800), // not near
        ]),
        prices: _prices({'NSE:IDEA': 98, 'NSE:FARAWAY': 900}),
      );
      expect(result.totalRows, 4);
      expect(result.resolvedCount, 3);
      expect(result.pricedCount, 2);
      expect(result.considered, 2);
      expect(result.matches, hasLength(1));
      expect(result.skipped, hasLength(2));
    });
  });

  group('tokens & price keys', () {
    test('tokensFor returns the distinct SmartAPI tokens to fetch', () {
      final items = engine.resolveAll([
        _ipo(symbol: 'IDEA'),
        _ipo(symbol: 'IDEA', listed: DateTime(2019, 1, 1)), // duplicate ticker
        _ipo(symbol: 'NYKAA'),
      ]);
      expect(engine.tokensFor(items).toSet(), {'1594', '14366'});
    });

    test('effective exchange follows the resolved instrument, not the IPO row', () {
      final item = engine
          .resolveAll([_ipo(symbol: 'DELHIVERY', exchange: Exchange.nse)])
          .single;
      expect(item.effectiveExchange, Exchange.bse);
      expect(item.token, '543529');
    });

    test('matches carry a TradingView link on the resolved exchange', () {
      final result = engine.evaluate(
        items: engine.resolveAll([_ipo(symbol: 'DELHIVERY', exchange: Exchange.nse, high: 100, low: 80)]),
        prices: _prices({'NSE:DELHIVERY': 81}),
      );
      expect(result.matches.single.tradingViewSymbol, 'BSE:DELHIVERY');
      expect(result.matches.single.tradingViewUrl, contains('BSE%3ADELHIVERY'));
    });
  });

  group('why a row was skipped', () {
    test('a lost ticker needs attention, a far-away price does not', () {
      final result = engine.evaluate(
        items: engine.resolveAll([
          _ipo(symbol: 'IDEA', high: 100, low: 90), // priced, right at the level
          _ipo(symbol: 'GONECO', high: 100, low: 90), // company renamed: no token
          _ipo(symbol: 'FARAWAY', high: 500, low: 400), // priced, far from levels
        ]),
        prices: _prices({'NSE:IDEA': 95, 'NSE:FARAWAY': 100}),
        config: const IpoScreenerConfig(inBandOnly: false),
      );

      final bySymbol = {for (final skip in result.skipped) skip.ipo.symbol: skip};
      expect(bySymbol['GONECO']!.kind, IpoSkipKind.notResolved);
      expect(bySymbol['GONECO']!.needsAttention, isTrue);
      // FARAWAY resolved and got a price: it is simply ~80 % away from its
      // listing range, which is the normal state of most rows, not a problem.
      expect(bySymbol.containsKey('FARAWAY'), isFalse);
      expect(result.skipped.where((s) => s.needsAttention), hasLength(1));
    });

    test('a resolved row the broker did not quote needs attention too', () {
      final result = engine.evaluate(
        items: engine.resolveAll([_ipo(symbol: 'SBIN')]),
        prices: const {}, // token is fine, the quote simply did not arrive
      );

      expect(result.skipped.single.kind, IpoSkipKind.noPrice);
      expect(result.skipped.single.needsAttention, isTrue);
    });

    test('levels waiting in the queue is not the same as levels never coming',
        () {
      final waiting = engine.evaluate(
        items: engine.resolveAll([
          Ipo(
            symbol: 'IDEA',
            companyName: 'Vodafone Idea Ltd',
            exchange: Exchange.nse,
            listingDate: DateTime(2016, 1, 4),
            listingHigh: 0,
            listingLow: 0,
          ),
        ]),
        prices: _prices({'NSE:IDEA': 20}),
      ).skipped.single;
      expect(waiting.kind, IpoSkipKind.levelsPending);
      // Still being fetched → the progress line already explains it, so it is
      // deliberately *not* pushed into the "needs attention" list.
      expect(waiting.needsAttention, isFalse);

      final gone = engine.evaluate(
        items: engine.resolveAll([
          Ipo(
            symbol: 'IDEA',
            companyName: 'Vodafone Idea Ltd',
            exchange: Exchange.nse,
            listingDate: DateTime(2016, 1, 4),
            listingHigh: 0,
            listingLow: 0,
            levelsSource: 'missing',
          ),
        ]),
        prices: _prices({'NSE:IDEA': 20}),
      ).skipped.single;
      expect(gone.kind, IpoSkipKind.levelsUnavailable);
      expect(gone.needsAttention, isTrue);
    });
  });
}

/// Encodes rows to a JSON array without importing dart:convert twice.
String _jsonArray(List<Map<String, dynamic>> rows) {
  final buffer = StringBuffer('[');
  for (var i = 0; i < rows.length; i++) {
    if (i > 0) buffer.write(',');
    buffer.write('{');
    var first = true;
    rows[i].forEach((key, value) {
      if (!first) buffer.write(',');
      first = false;
      buffer.write('"$key":"$value"');
    });
    buffer.write('}');
  }
  buffer.write(']');
  return buffer.toString();
}
