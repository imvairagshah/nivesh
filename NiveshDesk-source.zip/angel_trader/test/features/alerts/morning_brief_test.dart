// 1.5.75 — Morning brief: Top-20 selection (rank order), summary line,
// JSON round-trip, next-brief-time (trading-day skip). Pure logic — scan nahi.

import 'package:angel_trader/features/alerts/morning_brief.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('MorningBrief summaryLine — 5 naam + "+N aur"', () {
    final brief = MorningBrief(
      date: '2026-11-09',
      entries: [
        for (var i = 1; i <= 20; i++)
          (rank: i, symbol: 'S$i', score: 10 - i / 10),
      ],
    );
    expect(brief.summaryLine, 'S1, S2, S3, S4, S5 + 15 aur');
    expect(brief.symbols.length, 20);

    final small = MorningBrief(
      date: '2026-11-09',
      entries: [
        for (var i = 1; i <= 3; i++) (rank: i, symbol: 'X$i', score: 1),
      ],
    );
    expect(small.summaryLine, 'X1, X2, X3');
  });

  test('JSON round-trip entries preserve karata hai', () {
    final brief = MorningBrief(
      date: '2026-11-09',
      note: 'cached',
      entries: const [
        (rank: 1, symbol: 'AAA', score: 11.5),
        (rank: 2, symbol: 'BBB', score: 9.25),
      ],
    );
    final back = MorningBrief.fromJson(brief.toJson());
    expect(back, isNotNull);
    expect(back!.date, '2026-11-09');
    expect(back.note, 'cached');
    expect(back.entries.length, 2);
    expect(back.entries.first.symbol, 'AAA');
    expect(back.entries.last.score, 9.25);
  });

  test('nextBriefTime — aaj 8:30 pehle = aaj; baad me = agla trading day', () {
    // Monday 2026-11-09 07:00 → aaj 8:30.
    final monday7 = DateTime(2026, 11, 9, 7, 0);
    final at = MorningBriefScheduler.nextBriefTime(now: monday7);
    expect(at, DateTime(2026, 11, 9, 8, 30));

    // Monday 9:00 → agla trading day 8:30. (Exact date holiday-calendar pe
    // depend karti hai — isliye invariants: 8:30, aaj ke baad, 4 din ke andar,
    // trading day. Diwali-week fixtures se bachne ke liye.)
    final monday9 = DateTime(2026, 11, 9, 9, 0);
    final at2 = MorningBriefScheduler.nextBriefTime(now: monday9);
    expect((at2.hour, at2.minute), (8, 30));
    expect(at2.isAfter(monday9), true);
    expect(at2.difference(monday9).inHours, lessThan(24 * 4));
    expect(at2.isAtSameMomentAs(monday9), false);

    // Friday 9:00 → Saturday/Sunday skip → Monday 8:30.
    final friday9 = DateTime(2026, 11, 13, 9, 0);
    final at3 = MorningBriefScheduler.nextBriefTime(now: friday9);
    expect(at3, DateTime(2026, 11, 16, 8, 30));
  });
}
