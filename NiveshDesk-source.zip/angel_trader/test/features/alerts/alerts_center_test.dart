// 1.5.74 — AlertsCenter: log, price alerts (one-shot), signal dedupe.
// Pure logic tests — OS notification nahi, in-memory SettingsDao fake.

import 'package:angel_trader/features/alerts/alerts_center.dart';
import 'package:flutter_test/flutter_test.dart';

// AlertsCenter singleton hai — tests me log/price state saaf karke chalte hain.
Future<void> _reset(AlertsCenter c) async {
  await c.clearAll();
  for (final p in c.priceAlerts.toList()) {
    await c.removePriceAlert(p);
  }
}

void main() {
  final c = AlertsCenter.instance;

  test('raise alert log me jaata hai aur unread badge badalta hai', () async {
    await _reset(c);
    expect(c.unreadCount, 0);
    await c.raise(
        kind: AlertKind.price,
        title: '🎯 Test',
        body: 'Body',
        symbol: 'TCS');
    expect(c.alerts.length, 1);
    expect(c.unreadCount, 1);
    expect(c.alerts.first.kind, AlertKind.price);
    expect(c.alerts.first.symbol, 'TCS');

    await c.markAllRead();
    expect(c.unreadCount, 0);

    await c.clearAll();
    expect(c.alerts, isEmpty);
  });

  test('price alert add/remove + one-shot trigger', () async {
    await _reset(c);
    await c.addPriceAlert(
        symbol: 'reliance',
        direction: PriceDirection.above,
        value: 3000);
    await c.addPriceAlert(
        symbol: 'TCS', direction: PriceDirection.below, value: 2000);
    expect(c.priceAlerts.length, 2);
    expect(c.priceAlerts.first.symbol, 'RELIANCE'); // uppercase

    // Condition logic.
    final above = c.priceAlerts.first;
    expect(above.triggeredBy(2999.9), false);
    expect(above.triggeredBy(3000), true);
    final below = c.priceAlerts.last;
    expect(below.triggeredBy(2001), false);
    expect(below.triggeredBy(1999), true);

    // Checker: fetcher fake — 3050 = above trigger, TCS 2500 = no trigger.
    c.priceFetcher = (symbols) async =>
        {for (final s in symbols) s: s == 'RELIANCE' ? 3050 : 2500};
    await c.checkPriceAlerts();
    expect(c.priceAlerts.first.active, false); // one-shot: fire ke baad band
    expect(c.priceAlerts.last.active, true);
    expect(c.alerts.length, 1);
    expect(c.alerts.first.kind, AlertKind.price);
    expect(c.alerts.first.symbol, 'RELIANCE');

    await _reset(c);
  });

  test('IV extremes — sirf naye extremes alert karte hain (dedupe)', () async {
    await _reset(c);
    // Pehla scan: 2 extreme (1 rich, 1 cheap).
    await c.checkIvExtremes([
      ('ABC', 85, 60),
      ('XYZ', 15, 40),
      ('MID', 50, 50),
    ]);
    expect(c.alerts.length, 2);
    await c.clearAll();

    // Doosra scan: wahi extremes — koi naya alert nahi.
    await c.checkIvExtremes([
      ('ABC', 88, 60),
      ('XYZ', 12, 40),
      ('MID', 50, 50),
    ]);
    expect(c.alerts, isEmpty);

    // Teesra scan: MID ab rich.
    await c.checkIvExtremes([
      ('ABC', 88, 60),
      ('XYZ', 12, 40),
      ('MID', 82, 50),
    ]);
    expect(c.alerts.length, 1);
    expect(c.alerts.first.symbol, 'MID');

    await _reset(c);
  });

  test('shortlist signal — pehli baar + sirf naye symbols par', () async {
    await _reset(c);
    await c.checkShortlist(['AAA', 'BBB']);
    expect(c.alerts.length, 1);
    expect(c.alerts.first.kind, AlertKind.signal);
    await c.clearAll();

    // Wahi shortlist dobara — no alert.
    await c.checkShortlist(['AAA', 'BBB']);
    expect(c.alerts, isEmpty);

    // Naya symbol aaya — alert with new name.
    await c.checkShortlist(['AAA', 'BBB', 'CCC']);
    expect(c.alerts.length, 1);
    expect(c.alerts.first.body, contains('CCC'));

    await _reset(c);
  });
}
