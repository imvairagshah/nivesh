// Tests for the Opstra Google-Sheet IVP/IVR feed (1.5.56): CSV parsing with
// honest missing values + publish/export URL normalization.
import 'package:flutter_test/flutter_test.dart';
import 'package:angel_trader/features/fno/study/iv_sheet.dart';

void main() {
  group('IvSheetParsers.parseCsv', () {
    test('parses header variants and drops out-of-range values', () {
      const csv = 'SYMBOL,IV percentile,IV Rank,Date\n'
          'RELIANCE,32.5,28,2026-10-25\n'
          'SBIN,71,120,25-10-2026\n' // ivr 120 → dropped (out of 0–100)
          'TCS,abc,18,2026-10-25\n' // ivp junk → dropped
          ',10,10,2026-10-25\n'; // blank symbol → row dropped
      final parsed = IvSheetParsers.parseCsv(csv);
      expect(parsed.bySymbol['RELIANCE']?.ivp, 32.5);
      expect(parsed.bySymbol['RELIANCE']?.ivr, 28);
      expect(parsed.bySymbol['SBIN']?.ivp, 71);
      expect(parsed.bySymbol['SBIN']?.ivr, isNull, reason: '120 valid se bahar');
      expect(parsed.bySymbol['TCS']?.ivp, isNull);
      expect(parsed.bySymbol['TCS']?.ivr, 18);
      expect(parsed.bySymbol.containsKey(''), isFalse);
      expect(parsed.asOf, isNotNull);
    });

    test('asOf from dd-MMM-yyyy header; no date → null', () {
      final withDate = IvSheetParsers.parseCsv(
          'ticker,ivp,ivr,asof\nABC,10,20,25-Oct-2026\n');
      expect(withDate.asOf?.day, 25);
      expect(withDate.asOf?.month, 10);
      final noDate = IvSheetParsers.parseCsv('symbol,ivp,ivr\nABC,10,20\n');
      expect(noDate.asOf, isNull);
    });

    test('row with neither ivp nor ivr is dropped honestly', () {
      final parsed =
          IvSheetParsers.parseCsv('symbol,ivp,ivr\nABC,,\nDEF,12,\n');
      expect(parsed.bySymbol.containsKey('ABC'), isFalse);
      expect(parsed.bySymbol['DEF']?.ivp, 12);
    });

    test('empty/garbage csv → empty map, no throw', () {
      expect(IvSheetParsers.parseCsv('').bySymbol, isEmpty);
      expect(IvSheetParsers.parseCsv('a,b,c\n1,2,3\n').bySymbol, isEmpty);
    });

    test('wide sheet (14 columns) — sirf IVP/IVR, baaki sab ignore', () {
      // Real Opstra-style sheet (the user's 2026 sheet header verbatim).
      // 1.5.67 rule: sheet se sirf IVP/IVR — IV/price/PCR/etc. app ki apni
      // API/calculation se aate hain, isliye parse me bhi nahi liye jaate.
      const header =
          'Ticker,Price,Change %,CALL IV,PUT IV,IV,IV Change,IVP,IVR,Straddle,'
          'PCR,WPCR,WPCR Percentile,SECTOR';
      const nifty =
          'NIFTY,22771.6,0.02%,15.02,16.63,15.82,-7.81%,74.8,35.59,3.35%,'
          '1.06 (-5.85%),3.23,73.18,INDEX';
      const stock =
          'ABCAPITAL,354.9,1.85%,28.1,29.4,28.75,-2.5%,72.98,50.67,4.1%,'
          '0.92 (-1.2%),2.1,60.4,FINANCIAL SERVICES';
      final parsed = IvSheetParsers.parseCsv('$header\n$nifty\n$stock');
      final row = parsed.bySymbol['NIFTY']!;
      expect(row.ivp, closeTo(74.8, 1e-9));
      expect(row.ivr, closeTo(35.59, 1e-9));
      // WPCR/WPCR Percentile ke beech ke columns galat shift nahi karte —
      // ABCAPITAL ki IVP/IVR apni jagah se hi aaye.
      final ab = parsed.bySymbol['ABCAPITAL']!;
      expect(ab.ivp, closeTo(72.98, 1e-9));
      expect(ab.ivr, closeTo(50.67, 1e-9));
    });

    test('quoted cells with commas do not shift later columns', () {
      const csv = 'Ticker,IVP,IVR,SECTOR\n'
          'ABC,12,34,"FINANCIAL SERVICES, LTD"\n';
      final row = IvSheetParsers.parseCsv(csv).bySymbol['ABC']!;
      expect(row.ivp, closeTo(12, 1e-9));
      expect(row.ivr, closeTo(34, 1e-9));
    });

    test('extra-only rows (no ivp/ivr) still dropped honestly', () {
      const csv = 'Ticker,IVP,IVR,SECTOR\n'
          'ABC,,,INDEX\n';
      expect(IvSheetParsers.parseCsv(csv).bySymbol, isEmpty);
    });
  });

  group('IvSheetParsers.normalizeUrl', () {
    test('publish?output=csv link stays as-is', () {
      const url = 'https://docs.google.com/spreadsheets/d/e/2PACX-xyz/pub?'
          'output=csv&gid=7';
      expect(IvSheetParsers.normalizeUrl(url), url);
    });

    test('/d/<id>/edit link → export?format=csv with gid', () {
      final out = IvSheetParsers.normalizeUrl(
          'https://docs.google.com/spreadsheets/d/ABC123/edit?usp=sharing#gid=42');
      expect(out, contains('/spreadsheets/d/ABC123/export?format=csv'));
      expect(out, contains('gid=42'));
    });

    test('/d/e/<id>/pubhtml → pub?output=csv', () {
      final out = IvSheetParsers.normalizeUrl(
          'https://docs.google.com/spreadsheets/d/e/2PACX-xyz/pubhtml');
      expect(out, endsWith('/pub?output=csv'));
    });

    test('non-sheets link → null', () {
      expect(IvSheetParsers.normalizeUrl('https://example.com/a.csv'), isNull);
      expect(IvSheetParsers.normalizeUrl(''), isNull);
    });
  });
}
