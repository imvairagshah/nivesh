// ---------------------------------------------------------------------------
// study_row_tile_test.dart — the 3-Month Study card now carries the two
// percentages the user reads next to ATR: **ATM jodi** and **OTM jodi**, each
// as a share of the stock's own price.
//
// Why they are on the card at all: a ₹16 jodi is cheap on a ₹1,000 stock and
// expensive on a ₹130 one. The rupee figure cannot be compared across rows;
// the percentage can.
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/theme/app_theme.dart';
import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/features/fno/study/black_scholes.dart'
    show OptionType;
import 'package:angel_trader/features/fno/study/study_engine.dart';
import 'package:angel_trader/features/fno/study/study_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

/// ₹2,650 ka stock: ATM jodi 42.50 + 38.40 = 80.90 → 3.05%,
/// OTM jodi 20.00 + 18.00 = 38.00 → 1.43%.
StudyRow _row({bool options = true}) => StudyRow(
      symbol: 'RELIANCE',
      companyName: 'Reliance Industries Ltd',
      exchange: Exchange.nse,
      token: 'eq-RELIANCE',
      underlying: 'RELIANCE',
      ltp: 2650,
      high3m: 2900,
      low3m: 2400,
      rangePct: 20.8,
      atr: 53,
      atrPct: 2,
      distHiPct: 8.6,
      distLoPct: 10.4,
      distHiDays: 4.3,
      distLoDays: 5.2,
      months: const [
        MonthMove(label: 'Aug-25', key: '2025-08', pct: 3),
        MonthMove(label: 'Sep-25', key: '2025-09', pct: 4),
        MonthMove(label: 'Oct-25', key: '2025-10', pct: 2),
      ],
      total3mPct: 9.2,
      upMonths: 3,
      downMonths: 0,
      trend: Trend3M.up,
      atmStrike: 2650,
      expiryLabel: '26JAN2026',
      expiryDate: DateTime(2026, 1, 26),
      daysToExpiry: 12,
      lotSize: 500,
      ce: options
          ? const StudyOptionLeg(
              strike: 2650,
              type: OptionType.call,
              token: '12345',
              symbol: 'RELIANCE26JAN2650CE',
              ltp: 42.5,
              iv: 28.5,
            )
          : null,
      pe: options
          ? const StudyOptionLeg(
              strike: 2650,
              type: OptionType.put,
              token: '12346',
              symbol: 'RELIANCE26JAN2650PE',
              ltp: 38.4,
              iv: 30.1,
            )
          : null,
      strangle: options
          ? StudyStrangle(
            ce: const StudyOptionLeg(
              strike: 2700,
              type: OptionType.call,
              token: 'otm-ce',
              symbol: 'RELIANCE26JAN2700CE',
              ltp: 20,
            ),
            pe: const StudyOptionLeg(
              strike: 2600,
              type: OptionType.put,
              token: 'otm-pe',
              symbol: 'RELIANCE26JAN2600PE',
              ltp: 18,
            ),
            targetPremium: 40.45,
          )
          : null,
      avgIv: 29.3,
      ivSource: IvSource.broker,
      edgePct: 1.4,
      consistencyPoints: 3,
      magnitudePoints: 2,
      proximityPoints: 2.5,
      ivPoints: 2,
      score: 9.5,
      ivRank: IvRank.medium,
      opportunityTag: '🎯 Best Buy',
      rank: 1,
      reason: 'Test row.',
      bars: 63,
      asOf: DateTime(2025, 10, 6),
    );

Future<void> _pump(
  WidgetTester tester, {
  StudyRow? row,
  bool expanded = false,
  Map<String, double>? livePremiums,
  Map<String, double>? liveStrangle,
}) =>
    tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.light(),
        home: Scaffold(
          body: StudyRowTile(
            row: row ?? _row(),
            expanded: expanded,
            onTap: () {},
            livePremiums: livePremiums,
            liveStrangle: liveStrangle,
          ),
        ),
      ),
    );

void main() {
  group('the two jodis, as a share of the price', () {
    testWidgets('the card prints both percentages', (tester) async {
      await _pump(tester);

      // One chip per jodi (1.5.58 grid redesign) — values never run together.
      expect(find.text('ATM 3.05%'), findsOneWidget,
          reason: '80.90 of 2,650');
      expect(find.text('OTM 1.43%'), findsOneWidget,
          reason: '38.00 of 2,650');
      expect(find.text('of price'), findsOneWidget);
    });

    testWidgets('the open row uses the live premium', (tester) async {
      await _pump(
        tester,
        expanded: true,
        livePremiums: const {'CE': 50, 'PE': 40},
        liveStrangle: const {'CE': 30, 'PE': 25},
      );

      // Live wins: 90 → 3.40%, 55 → 2.08%.
      expect(find.text('ATM 3.40%'), findsOneWidget);
      expect(find.text('OTM 2.08%'), findsOneWidget);
      expect(find.text('ATM 3.05%'), findsNothing);
    });

    testWidgets('a half-priced jodi is not printed as a price',
        (tester) async {
      // One live leg alone is not a jodi — the pair falls back to the scan
      // value rather than printing a number nobody could buy.
      await _pump(
        tester,
        expanded: true,
        livePremiums: const {'CE': 50},
        liveStrangle: const {'PE': 25},
      );

      expect(find.text('ATM 3.05%'), findsOneWidget);
      expect(find.text('OTM 1.43%'), findsOneWidget);
    });

    testWidgets('a row with no options prints no percentage line',
        (tester) async {
      await _pump(tester, row: _row(options: false));

      expect(find.textContaining('of price'), findsNothing,
          reason: 'blank is honest — 0% would be a lie someone trades on');
      // …and the card itself is still there.
      expect(find.text('RELIANCE'), findsOneWidget);
    });

    test('the helper never invents a zero', () {
      expect(premiumPctOfPrice(80.90, 2650), closeTo(3.0528, 0.0001));
      expect(premiumPctOfPrice(null, 2650), isNull);
      expect(premiumPctOfPrice(80.90, 0), isNull, reason: 'no price, no share');
      expect(premiumPctOfPrice(80.90, -5), isNull);
    });

    test('the row exposes both, so the export and the card agree', () {
      final row = _row();
      expect(row.atmJodiPctOfPrice, closeTo(3.0528, 0.0001));
      expect(row.otmJodiPctOfPrice, closeTo(1.4339, 0.0001));

      expect(_row(options: false).atmJodiPctOfPrice, isNull);
      expect(_row(options: false).otmJodiPctOfPrice, isNull);
    });
  });
}
