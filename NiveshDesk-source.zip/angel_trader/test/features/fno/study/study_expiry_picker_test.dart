import 'package:angel_trader/core/utils/formatters.dart';
import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/candle_dao.dart';
import 'package:angel_trader/data/local/dao/earnings_dao.dart';
import 'package:angel_trader/data/local/dao/fno_contract_dao.dart';
import 'package:angel_trader/data/local/dao/ipo_dao.dart';
import 'package:angel_trader/data/local/dao/scan_cache_dao.dart';
import 'package:angel_trader/data/local/dao/scrip_dao.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/data/remote/dto/quote.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/features/fno/study/fno_study_provider.dart';
import 'package:angel_trader/features/fno/study/fno_study_screen.dart';
import 'package:angel_trader/features/settings/settings_provider.dart';
import 'package:angel_trader/services/auth_service.dart';
import 'package:angel_trader/services/candle_source.dart';
import 'package:angel_trader/services/earnings_calendar_service.dart';
import 'package:angel_trader/services/fno_study_service.dart';
import 'package:angel_trader/services/live_feed_service.dart';
import 'package:angel_trader/services/scrip_master_service.dart';
import 'package:angel_trader/services/secure_store.dart';
import 'package:angel_trader/services/study_market_data.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

class _NoopCandleSource implements CandleSource {
  @override
  Future<List<Candle>> fetchDailyCandles({
    required Scrip scrip,
    required DateTime from,
    required DateTime to,
    String interval = 'ONE_DAY',
  }) async => const [];
}

class _NoopMarketData implements StudyMarketData {
  @override
  Future<Map<String, MarketQuote>> fetchQuotesFull(List<Scrip> scrips) async =>
      {};

  @override
  Future<OptionGreekBatch> fetchOptionGreeks({
    required String underlying,
    required String expiryLabel,
  }) async => const OptionGreekBatch(byStrike: {});
}

class _PickerProvider extends FnoStudyProvider {
  _PickerProvider({
    required super.study,
    required super.settings,
    required super.scripDao,
    required super.ipoDao,
    required super.scripMaster,
    required super.feed,
    required super.earnings,
    required List<DateTime> initialExpiries,
    required this.refreshedExpiries,
  }) : _options = initialExpiries,
       _selected = initialExpiries.first;

  List<DateTime> _options;
  DateTime? _selected;
  final List<DateTime> refreshedExpiries;
  int prepareCalls = 0;

  @override
  List<DateTime> get expiryOptions => List.unmodifiable(_options);

  @override
  DateTime? get selectedExpiry => _selected;

  @override
  bool get isRunning => false;

  @override
  bool get isSyncingMaster => false;

  @override
  bool get isLoadingExpiries => false;

  @override
  String? get masterNote => null;

  @override
  Future<void> prepareExpiryPicker() async {
    prepareCalls++;
    _options = refreshedExpiries;
    _selected = refreshedExpiries.first;
  }

  @override
  void selectExpiry(DateTime? value) {
    if (value == null || !_options.contains(value)) return;
    _selected = value;
    notifyListeners();
  }
}

void main() {
  testWidgets('tapping the expiry field opens choices and updates selection', (
    tester,
  ) async {
    final today = MarketCalendar.nowIst();
    final dates = [
      for (var offset = 1; offset <= 3; offset++)
        DateTime(today.year, today.month + offset, 28),
    ];
    final db = AppDatabase.instance;
    final settingsDao = SettingsDao(db);
    final scripDao = ScripDao(db);
    final contracts = FnoContractDao(db);
    final settings = SettingsProvider(settingsDao);
    final feed = LiveFeedService(auth: AuthService(store: SecureStore()));
    final provider = _PickerProvider(
      study: FnoStudyService(
        source: _NoopCandleSource(),
        candles: CandleDao(db),
        cache: ScanCacheDao(db),
        contracts: contracts,
        marketData: _NoopMarketData(),
      ),
      settings: settings,
      scripDao: scripDao,
      ipoDao: IpoDao(db),
      scripMaster: ScripMasterService(
        scripDao: scripDao,
        settingsDao: settingsDao,
      ),
      feed: feed,
      earnings: EarningsCalendarService(
        dao: EarningsDao(db),
        settings: settingsDao,
        get: (_) async => '[]',
      ),
      initialExpiries: [dates.first],
      refreshedExpiries: dates,
    );
    addTearDown(() async {
      provider.dispose();
      await feed.stop();
    });

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: Padding(
            padding: const EdgeInsets.all(16),
            child: StudyExpiryPicker(provider: provider),
          ),
        ),
      ),
    );
    await tester.pump();

    await tester.tap(find.byKey(const Key('study-expiry-picker')));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 300));

    expect(provider.prepareCalls, 1);
    expect(find.text(Fmt.date(dates[1])), findsOneWidget);
    final secondExpiryOption = find.ancestor(
      of: find.text(Fmt.date(dates[1])),
      matching: find.byType(CheckedPopupMenuItem<DateTime>),
    );
    await tester.tap(secondExpiryOption);
    await tester.pump();
    expect(provider.selectedExpiry, dates[1]);
  });
}
