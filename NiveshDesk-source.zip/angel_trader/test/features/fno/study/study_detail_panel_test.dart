// Widget tests for the study detail panel — the three display requests the
// user made after using 1.5.4:
//
//   1. "CMP ni baju ma study day lakhiyu che ae nikali do"     → label is CMP
//   2. "ATM option ma CE/PE ni baju ma expiry ... khali CE and PE rakho"
//                                                                → legs read CE / PE
//   3. "add karo vala button ... baju me hi rakh lo"            → actions end-aligned
//
// These are UI-only changes, so they are pinned as rendered output (finding the
// exact strings / the Wrap alignment) rather than as data.

import 'package:angel_trader/core/theme/app_theme.dart';
import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/features/fno/study/black_scholes.dart' show OptionType;
import 'package:angel_trader/features/fno/study/study_engine.dart';
import 'package:angel_trader/features/fno/study/study_widgets.dart';
import 'package:angel_trader/services/earnings_calendar_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

/// A minimal row that has everything the panel reads, with ATM legs whose
/// broker symbols carry the expiry — exactly what the user asked to hide.
StudyRow _row() => StudyRow(
      symbol: 'RELIANCE',
      companyName: 'Reliance Industries Ltd',
      exchange: Exchange.nse,
      token: 'eq-RELIANCE',
      underlying: 'RELIANCE',
      ltp: 2650,
      high3m: 2900,
      low3m: 2400,
      rangePct: 20.8,
      atr: 53,
      atrPct: 2,
      distHiPct: 8.6,
      distLoPct: 10.4,
      distHiDays: 4.3,
      distLoDays: 5.2,
      months: const [
        MonthMove(label: 'Aug-25', key: '2025-08', pct: 3),
        MonthMove(label: 'Sep-25', key: '2025-09', pct: 4),
        MonthMove(label: 'Oct-25', key: '2025-10', pct: 2),
      ],
      total3mPct: 9.2,
      upMonths: 3,
      downMonths: 0,
      trend: Trend3M.up,
      atmStrike: 2650,
      expiryLabel: '26JAN2026',
      expiryDate: DateTime(2026, 1, 26),
      daysToExpiry: 12,
      lotSize: 500,
      ce: const StudyOptionLeg(
        strike: 2650,
        type: OptionType.call,
        token: '12345',
        symbol: 'RELIANCE26JAN2650CE',
        ltp: 42.5,
        iv: 28.5,
      ),
      pe: const StudyOptionLeg(
        strike: 2650,
        type: OptionType.put,
        token: '12346',
        symbol: 'RELIANCE26JAN2650PE',
        ltp: 38.4,
        iv: 30.1,
      ),
      avgIv: 29.3,
      ivSource: IvSource.broker,
      edgePct: 1.4,
      consistencyPoints: 3,
      magnitudePoints: 2,
      proximityPoints: 2.5,
      ivPoints: 2,
      score: 9.5,
      ivRank: IvRank.medium,
      opportunityTag: '🎯 Best Buy',
      rank: 1,
      reason: 'Test row.',
      bars: 63,
      asOf: DateTime(2025, 10, 6),
    );


/// The same row, but with the **kal wale** ATM pair (2,600) supplied — the case
/// the user reported: today's strike is 2,650, the jodi bought yesterday was
/// 2,600, and the P&L must be priced on that pair.
StudyRow _rowWithKalJodi() {
  final base = _row();
  return StudyRow(
    symbol: base.symbol,
    companyName: base.companyName,
    exchange: base.exchange,
    token: base.token,
    underlying: base.underlying,
    ltp: base.ltp,
    high3m: base.high3m,
    low3m: base.low3m,
    rangePct: base.rangePct,
    atr: base.atr,
    atrPct: base.atrPct,
    distHiPct: base.distHiPct,
    distLoPct: base.distLoPct,
    distHiDays: base.distHiDays,
    distLoDays: base.distLoDays,
    months: base.months,
    total3mPct: base.total3mPct,
    upMonths: base.upMonths,
    downMonths: base.downMonths,
    trend: base.trend,
    atmStrike: base.atmStrike,
    expiryLabel: base.expiryLabel,
    expiryDate: base.expiryDate,
    daysToExpiry: base.daysToExpiry,
    lotSize: base.lotSize,
    ce: base.ce,
    pe: base.pe,
    kalStrike: 2600,
    kalCe: const StudyOptionLeg(
      strike: 2600,
      type: OptionType.call,
      token: '12345',
      symbol: 'RELIANCE26JAN2600CE',
      ltp: 88,
      previousClose: 62.5,
    ),
    kalPe: const StudyOptionLeg(
      strike: 2600,
      type: OptionType.put,
      token: '12346',
      symbol: 'RELIANCE26JAN2600PE',
      ltp: 30,
      previousClose: 40,
    ),
    avgIv: base.avgIv,
    ivSource: base.ivSource,
    edgePct: base.edgePct,
    consistencyPoints: base.consistencyPoints,
    magnitudePoints: base.magnitudePoints,
    proximityPoints: base.proximityPoints,
    ivPoints: base.ivPoints,
    score: base.score,
    ivRank: base.ivRank,
    opportunityTag: base.opportunityTag,
    rank: base.rank,
    reason: base.reason,
    bars: base.bars,
    asOf: base.asOf,
  );
}

Future<void> _pumpPanel(
  WidgetTester tester, {
  VoidCallback? onClose,
  StudyRow? row,
}) async {
  await tester.pumpWidget(
    MaterialApp(
      theme: AppTheme.light(),
      home: Scaffold(
        body: SingleChildScrollView(
          child: StudyDetailPanel(
            row: row ?? _row(),
            livePremiums: const {},
            liveFeedActive: false,
            onClose: onClose ?? () {},
          ),
        ),
      ),
    ),
  );
  await tester.pumpAndSettle();
}

/// A degraded row: the scan found the stock but no ATM legs (no option data
/// for it). Nothing option-shaped may be printed for it — not even a dash.
StudyRow _degradedRow() => StudyRow(
      symbol: 'RELIANCE',
      companyName: 'Reliance Industries Ltd',
      exchange: Exchange.nse,
      token: 'eq-RELIANCE',
      underlying: 'RELIANCE',
      ltp: 2650,
      high3m: 2900,
      low3m: 2400,
      rangePct: 20.8,
      atr: 53,
      atrPct: 2,
      distHiPct: 8.6,
      distLoPct: 10.4,
      distHiDays: 4.3,
      distLoDays: 5.2,
      months: const [],
      total3mPct: 9.2,
      upMonths: 3,
      downMonths: 0,
      trend: Trend3M.up,
      lotSize: 500,
      consistencyPoints: 3,
      magnitudePoints: 2,
      proximityPoints: 2.5,
      ivPoints: 2,
      score: 9.5,
      ivRank: IvRank.medium,
      opportunityTag: 'Test',
      rank: 1,
      reason: 'Test row.',
      bars: 63,
      asOf: DateTime(2025, 10, 6),
    );

/// [_row] plus the OTM jodi: CE 2,700 (upar) and PE 2,600 (niche), bought at
/// ~half the ATM jodi's premium — 42.50 + 38.40 = 80.90, so the target is
/// 40.45. The kal wala pair cost 29.00 yesterday and is worth 38.00 today.
StudyRow _rowWithStrangle() => _row().copyWith(
      strangle: StudyStrangle(
        ce: const StudyOptionLeg(
          strike: 2700,
          type: OptionType.call,
          token: 'otm-ce',
          symbol: 'RELIANCE26JAN2700CE',
          ltp: 20.0,
          previousClose: 15.0,
        ),
        pe: const StudyOptionLeg(
          strike: 2600,
          type: OptionType.put,
          token: 'otm-pe',
          symbol: 'RELIANCE26JAN2600PE',
          ltp: 18.0,
          previousClose: 14.0,
        ),
        targetPremium: 40.45,
      ),
      kalStrangle: StudyStrangle(
        ce: const StudyOptionLeg(
          strike: 2700,
          type: OptionType.call,
          token: 'otm-ce',
          symbol: 'RELIANCE26JAN2700CE',
          ltp: 20.0,
          previousClose: 15.0,
        ),
        pe: const StudyOptionLeg(
          strike: 2600,
          type: OptionType.put,
          token: 'otm-pe',
          symbol: 'RELIANCE26JAN2600PE',
          ltp: 18.0,
          previousClose: 14.0,
        ),
        targetPremium: 40.45,
      ),
    );

Future<void> _pumpStranglePanel(WidgetTester tester) => tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.light(),
        home: Scaffold(
          body: SingleChildScrollView(
            child: StudyDetailPanel(
              row: _rowWithStrangle(),
              livePremiums: const {},
              liveFeedActive: false,
              onClose: () {},
            ),
          ),
        ),
      ),
    );

void main() {
  testWidgets('CMP label no longer says "(study day)"', (tester) async {
    await _pumpPanel(tester);

    expect(find.text('CMP'), findsOneWidget);
    expect(find.textContaining('study day'), findsNothing);
  });

  testWidgets('ATM legs read CE / PE — no broker symbol beside them',
      (tester) async {
    await _pumpPanel(tester);

    expect(find.text('CE'), findsOneWidget);
    expect(find.text('PE'), findsOneWidget);
    // The symbol (which carries the expiry: RELIANCE26JAN2650CE) must not
    // appear in the panel at all.
    expect(find.textContaining('RELIANCE26JAN2650CE'), findsNothing);
    expect(find.textContaining('RELIANCE26JAN2650PE'), findsNothing);
    // …while the leg data itself stays: price and IV.
    expect(find.textContaining('LTP 42.50'), findsOneWidget);
    expect(find.textContaining('IV 28.50%'), findsOneWidget);
  });

  testWidgets('the results block prints last and next result dates',
      (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.light(),
        home: Scaffold(
          body: SingleChildScrollView(
            child: StudyDetailPanel(
              row: _row(),
              livePremiums: const {},
              liveFeedActive: false,
              onClose: () {},
              earnings: EarningsInfo(
                lastDate: DateTime(2025, 10, 14),
                lastLabel: 'Q2 · quarter ended Sep 2025',
                nextDate: DateTime(2026, 1, 22),
                nextLabel: 'board meeting confirm',
                nextConfirmed: true,
              ),
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    // Section headers render upper-cased (see _Section).
    expect(find.text('7 · RESULTS (NSE)'), findsOneWidget);
    expect(find.text('Last result'), findsOneWidget);
    expect(find.textContaining('14 Oct 2025'), findsOneWidget);
    expect(find.textContaining('Q2 · quarter ended Sep 2025'), findsOneWidget);
    expect(find.text('Next result'), findsOneWidget);
    expect(find.textContaining('22 Jan 2026'), findsOneWidget);
    expect(find.textContaining('board meeting confirm'), findsOneWidget);
    // The estimate wording must NOT show for a confirmed meeting.
    expect(find.textContaining('anumanit'), findsNothing);
  });

  testWidgets('a guessed next date (an old cache) is never printed',
      (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.light(),
        home: Scaffold(
          body: SingleChildScrollView(
            child: StudyDetailPanel(
              row: _row(),
              livePremiums: const {},
              liveFeedActive: false,
              onClose: () {},
              earnings: EarningsInfo(
                lastDate: DateTime(2025, 11, 4),
                lastLabel: 'Q2 · quarter ended Sep 2025',
                nextDate: DateTime(2026, 2, 3),
                nextLabel: 'anumanit (pichle result se)',
                estimated: true,
              ),
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    // The last result is a fact and stays; the invented "next" is gone —
    // which is what an app updated from 1.5.12 must show, not anumanit.
    expect(find.text('Last result'), findsOneWidget);
    expect(find.textContaining('04 Nov 2025'), findsOneWidget);
    expect(find.text('Next result'), findsNothing);
    expect(find.textContaining('anumanit'), findsNothing);
    expect(find.textContaining('board meeting confirm'), findsNothing);
  });

  testWidgets('missing results data explains itself instead of showing blanks',
      (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.light(),
        home: Scaffold(
          body: SingleChildScrollView(
            child: StudyDetailPanel(
              row: _row(),
              livePremiums: const {},
              liveFeedActive: false,
              onClose: () {},
              earningsNote: 'NSE se results date nahi mili (timeout).',
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.textContaining('NSE se results date nahi mili'), findsOneWidget);
    expect(find.text('Last result'), findsNothing);
  });

  testWidgets('the jodi total sits right under ATR, above the ATM block',
      (tester) async {
    await _pumpPanel(tester);

    // The user reads ATR and the pair price together — so the line is printed
    // in the ATR section (and, unchanged, in the ATM option section below).
    final labels = tester
        .widgetList<Text>(find.byType(Text))
        .map((t) => t.data ?? '')
        .toList();
    final atr = labels.indexOf('ATR(14)');
    final jodi = labels.indexOf('Jodi total (CE+PE)');
    final strike = labels.indexOf('Strike');

    expect(atr, greaterThanOrEqualTo(0));
    expect(jodi, greaterThan(atr), reason: 'jodi total must come below ATR');
    expect(strike, greaterThan(jodi),
        reason: 'and before the ATM option section starts');
  });

  testWidgets('the jodi total (CE + PE) is the pair price', (tester) async {
    await _pumpPanel(tester);

    // 42.50 + 38.40 — the pair price, the number you pay to buy both legs.
    // Printed twice on purpose: under ATR, and in the ATM option section.
    expect(find.text('Jodi total (CE+PE)'), findsNWidgets(2));
    // Once in its own ATM section, once under ATR — now with the share of
    // the stock's own price next to it (1.5.58: value and % are separate
    // lines inside the box).
    expect(find.text('80.90'), findsNWidgets(2));
    expect(find.text('3.05% of price'), findsOneWidget);
  });

  testWidgets('a row with no option legs prints no jodi total', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.light(),
        home: Scaffold(
          body: SingleChildScrollView(
            child: StudyDetailPanel(
              row: _degradedRow(),
              livePremiums: const {},
              liveFeedActive: false,
              onClose: () {},
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('Jodi total (CE+PE)'), findsNothing);
    expect(find.text('ATR(14)'), findsOneWidget, reason: 'ATR is still there');
  });

  testWidgets('a live tick moves the jodi total, not just the legs',
      (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.light(),
        home: Scaffold(
          body: SingleChildScrollView(
            child: StudyDetailPanel(
              row: _row(),
              livePremiums: const {'CE': 50.0, 'PE': 40.0},
              liveFeedActive: true,
              onClose: () {},
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    // 50 + 40, not 42.50+38.40 — and, next to it, what that pair is as a
    // share of ₹2,650 (the stock's own price).
    expect(find.text('90.00'), findsNWidgets(2));
    expect(find.text('3.40% of price'), findsOneWidget);
  });

  testWidgets('ATR ke saath dono jodi ka % of price bhi likha hai',
      (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.light(),
        home: Scaffold(
          body: SingleChildScrollView(
            child: StudyDetailPanel(
              row: _rowWithStrangle(),
              livePremiums: const {},
              liveFeedActive: false,
              onClose: () {},
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    // 2650 ke stock par: ATM jodi 42.50 + 38.40 = 80.90 → 3.05%,
    // OTM jodi 20.00 + 18.00 = 38.00 → 1.43%.
    expect(find.text('3.05% of price'), findsOneWidget);
    expect(find.text('1.43% of price'), findsOneWidget);
    // The yardstick is spelled out — a number without its unit is a guess.
    expect(find.textContaining('2650.00 ke stock par'), findsOneWidget);
  });

  testWidgets('a row with no jodi prints no percentage either', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.light(),
        home: Scaffold(
          body: SingleChildScrollView(
            child: StudyDetailPanel(
              row: _degradedRow(),
              livePremiums: const {},
              liveFeedActive: false,
              onClose: () {},
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    // ATR still says "% of price" (it has a number); the two jodis print
    // nothing at all rather than a 0% someone could trade on.
    expect(find.textContaining('ATR(14)'), findsOneWidget);
    expect(find.textContaining('Jodi total'), findsNothing);
    expect(find.textContaining('OTM jodi total'), findsNothing);
  });

  testWidgets('live premium badle to % bhi badalta hai', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.light(),
        home: Scaffold(
          body: SingleChildScrollView(
            child: StudyDetailPanel(
              row: _rowWithStrangle(),
              livePremiums: const {'CE': 50.0, 'PE': 40.0},
              liveStrangle: const {'CE': 30.0, 'PE': 25.0},
              liveFeedActive: true,
              onClose: () {},
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    // Live wins over the frozen scan: 90 → 3.40%, 55 → 2.08%.
    expect(find.text('3.40% of price'), findsOneWidget);
    expect(find.text('2.08% of price'), findsOneWidget);
    expect(find.text('80.90'), findsNothing);
  });

  testWidgets('the IV source row is gone', (tester) async {
    await _pumpPanel(tester);

    expect(find.text('IV source'), findsNothing);
    expect(find.textContaining('Angel option chain'), findsNothing);
    expect(find.textContaining('Black-Scholes (premium se)'), findsNothing);
  });

  testWidgets('the "add karo" action sits at the side (end-aligned)',
      (tester) async {
    await _pumpPanel(tester);

    final add = find.text('Paper trade me add karo');
    expect(add, findsOneWidget);

    final wrap = tester.widget<Wrap>(
      find.ancestor(of: add, matching: find.byType(Wrap)).first,
    );
    expect(wrap.alignment, WrapAlignment.end);

    // The close action is still reachable from the same row.
    expect(find.text('Band karo'), findsOneWidget);
  });

  testWidgets('the OTM jodi gets its own section, with the rule it came from',
      (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.light(),
        home: Scaffold(
          body: SingleChildScrollView(
            child: StudyDetailPanel(
              row: _rowWithStrangle(),
              livePremiums: const {},
              liveFeedActive: false,
              onClose: () {},
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('6 · OTM JODI (STRANGLE)'), findsOneWidget);
    // 20.00 + 18.00 — printed under ATR as well as in its own section.
    expect(find.text('OTM jodi total'), findsNWidgets(2));
    // Under ATR it carries the "% of price" too; its own section prints the
    // rupee figure on its own (1.5.58: value and % are separate lines).
    expect(find.text('1.43% of price'), findsOneWidget);
    expect(find.text('38.00'), findsNWidgets(2));
    expect(find.textContaining('CE (upar)'), findsOneWidget);
    expect(find.textContaining('PE (niche)'), findsOneWidget);
    // How it compares with the ATM jodi, and the rule that picked it.
    expect(find.textContaining('-53.03% sasta'), findsOneWidget);
    expect(find.textContaining('(ATM 80.90)'), findsOneWidget);
    expect(find.textContaining('ATM jodi ka aadha (~40.45)'), findsOneWidget);
  });

  testWidgets('a live tick moves the OTM jodi total too', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.light(),
        home: Scaffold(
          body: SingleChildScrollView(
            child: StudyDetailPanel(
              row: _rowWithStrangle(),
              livePremiums: const {},
              liveFeedActive: true,
              onClose: () {},
              liveStrangle: const {'CE': 50.0, 'PE': 40.0},
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('3.40% of price'), findsOneWidget,
        reason: '50 + 40, live — as a share of ₹2,650');
    expect(find.text('90.00'), findsNWidgets(2), reason: 'the OTM section too');
    expect(find.text('38.00'), findsNothing);
  });

  testWidgets('"agar kal OTM jodi buy ki hoti" reads like the ATM line',
      (tester) async {
    await _pumpStranglePanel(tester);
    await tester.pumpAndSettle();

    expect(find.text('9 · AGAR KAL OTM JODI BUY KI HOTI'), findsOneWidget);
    // 29.00 → 38.00 = +9.00 pts × 500 = Profit ₹4,500.
    expect(find.text('Profit ₹4,500'), findsOneWidget);
    expect(
      find.textContaining('kal 29.00 thi, aaj 38.00 hai'),
      findsOneWidget,
    );
    expect(find.textContaining('× lot 500'), findsOneWidget);
  });

  testWidgets('a row with no OTM jodi says so instead of going blank',
      (tester) async {
    await _pumpPanel(tester);

    expect(find.text('6 · OTM JODI (STRANGLE)'), findsOneWidget);
    expect(
      find.textContaining('Is stock ki OTM jodi nahi ban payi'),
      findsOneWidget,
    );
    expect(find.text('OTM jodi total'), findsNothing);
  });

  testWidgets('the paper-trade sheet offers the OTM jodi as well',
      (tester) async {
    await _pumpStranglePanel(tester);
    await tester.pumpAndSettle();

    // The panel is long: bring the action into view before tapping it.
    await tester.ensureVisible(find.text('Paper trade me add karo'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Paper trade me add karo'));
    await tester.pumpAndSettle();

    expect(find.text('ATM jodi'), findsOneWidget);
    expect(find.text('OTM jodi (strangle)'), findsOneWidget);
    // Two legs per group → four BUY buttons.
    expect(find.text('BUY'), findsNWidgets(4));
  });

  testWidgets('tapping "Band karo" closes the panel', (tester) async {
    var closed = false;
    await _pumpPanel(tester, onClose: () => closed = true);

    final close = find.text('Band karo');
    await tester.ensureVisible(close);
    await tester.pumpAndSettle();
    await tester.tap(close);
    expect(closed, isTrue);
  });

  testWidgets('the kal jodi line is priced on the kal wale strike',
      (tester) async {
    await _pumpPanel(tester, row: _rowWithKalJodi());

    expect(find.text('8 · AGAR KAL JODI BUY KI HOTI'), findsOneWidget);
    // 62.50 + 40.00 = 102.50 kal, 88.00 + 30.00 = 118.00 aaj → Profit 15.50 pts.
    expect(
      find.textContaining('ATM 2600 jodi kal 62.50 + 40.00 = 102.50 thi, '
          'aaj 118.00 hai'),
      findsOneWidget,
    );
    expect(find.textContaining('Profit 15.50 pts'), findsOneWidget);
    expect(find.textContaining('Profit ₹'), findsOneWidget);
    // The wrong-strike version (today's 2,650 pair) must not appear anywhere.
    expect(find.textContaining('2650 jodi kal'), findsNothing);
  });

  testWidgets('an old snapshot says the kal data is missing instead of lying',
      (tester) async {
    final old = _row(); // no kal pair: pre-1.5.10 snapshot
    await _pumpPanel(tester, row: old);

    expect(
      find.textContaining('kal wale ATM strike ka data nahi hai'),
      findsOneWidget,
    );
  });
}
