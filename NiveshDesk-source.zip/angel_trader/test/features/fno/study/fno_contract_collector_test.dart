// ---------------------------------------------------------------------------
// fno_contract_collector_test.dart — the parser that turns the 100k-row Angel
// master into a small, usable option book.
//
// Three real-world traps are pinned here, because each one silently breaks the
// study if it regresses:
//
//   1. `expiry` has no separators (`26JAN2026`) — DateTime.parse cannot read it,
//   2. `strike` arrives in **paise** (`"2650000.000000"` = ₹26,500),
//   3. the master carries index options, futures and other segments that must
//      never end up in the book.
// ---------------------------------------------------------------------------

import 'package:angel_trader/services/fno_contract_collector.dart';
import 'package:flutter_test/flutter_test.dart';

Map<String, dynamic> row({
  String segment = 'NFO',
  String instrument = 'OPTSTK',
  String name = 'RELIANCE',
  String symbol = 'RELIANCE26JAN2650CE',
  String token = '12345',
  String expiry = '26JAN2026',
  dynamic strike = '2650000.000000',
  dynamic lotsize = '250',
}) => {
  'exch_seg': segment,
  'instrumenttype': instrument,
  'name': name,
  'symbol': symbol,
  'token': token,
  'expiry': expiry,
  'strike': strike,
  'lotsize': lotsize,
};

void main() {
  group('expiry parsing', () {
    test('reads the master format', () {
      expect(
        FnoContractCollector.parseExpiry('26JAN2026'),
        DateTime(2026, 1, 26),
      );
      expect(
        FnoContractCollector.parseExpiry('01DEC2025'),
        DateTime(2025, 12, 1),
      );
      expect(
        FnoContractCollector.parseExpiry('26-JAN-2026'),
        DateTime(2026, 1, 26),
      );
      expect(
        FnoContractCollector.parseExpiry(' 26jan2026 '),
        DateTime(2026, 1, 26),
      );
    });

    test('rejects junk instead of guessing', () {
      expect(FnoContractCollector.parseExpiry(''), isNull);
      expect(FnoContractCollector.parseExpiry('JAN2026'), isNull);
      expect(FnoContractCollector.parseExpiry('26XXX2026'), isNull);
      expect(FnoContractCollector.parseExpiry('99JAN2026'), isNull);
      expect(FnoContractCollector.parseExpiry('26JAN20'), isNull);
    });
  });

  group('strike parsing', () {
    test('converts paise to rupees', () {
      expect(
        FnoContractCollector.parseStrike('2650000.000000'),
        closeTo(26500, 1e-9),
      );
      expect(FnoContractCollector.parseStrike(129850), closeTo(1298.5, 1e-9));
      expect(FnoContractCollector.parseStrike('250000'), closeTo(2500, 1e-9));
    });

    test('a missing or zero strike is refused', () {
      expect(FnoContractCollector.parseStrike(''), 0);
      expect(FnoContractCollector.parseStrike(null), 0);
      expect(FnoContractCollector.parseStrike(0), 0);
      expect(FnoContractCollector.parseStrike(-100), 0);
    });
  });

  group('filtering', () {
    test('keeps NFO stock options', () {
      final collector = FnoContractCollector(today: DateTime(2026, 1, 1));
      expect(collector.addRow(row()), isTrue);
      expect(collector.contractCount, 1);
      expect(collector.underlyingCount, 1);
      expect(collector.rejected, 0);
    });

    test('drops everything that is not an NFO stock option', () {
      final collector = FnoContractCollector(today: DateTime(2026, 1, 1));
      expect(collector.addRow(row(segment: 'NSE')), isFalse); // cash equity
      expect(collector.addRow(row(segment: 'BSE')), isFalse);
      expect(collector.addRow(row(instrument: 'FUTSTK')), isFalse); // futures
      expect(
        collector.addRow(row(instrument: 'OPTIDX', name: 'NIFTY')),
        isFalse,
      );
      expect(collector.addRow(row(instrument: '')), isFalse);
      expect(collector.contractCount, 0);
      expect(collector.rejected, 5);
    });

    test('drops rows the study cannot use', () {
      final collector = FnoContractCollector(today: DateTime(2026, 1, 1));
      expect(collector.addRow(row(token: '')), isFalse);
      expect(collector.addRow(row(name: '')), isFalse);
      expect(
        collector.addRow(row(symbol: 'RELIANCE26JAN2650')),
        isFalse,
      ); // no CE/PE
      expect(collector.addRow(row(expiry: '')), isFalse);
      expect(collector.addRow(row(strike: '0')), isFalse);
      expect(collector.contractCount, 0);
    });

    test('lot size is read but may be missing', () {
      final collector = FnoContractCollector(today: DateTime(2026, 1, 1));
      collector.addRow(row(lotsize: '250'));
      expect(collector.build().single.lotSize, 250);

      final second = FnoContractCollector(today: DateTime(2026, 1, 1));
      second.addRow(row(lotsize: null, symbol: 'RELIANCE26JAN2650CE'));
      expect(second.build().single.lotSize, 0);
    });
  });

  group('book assembly', () {
    test('both legs of a strike land as separate contracts', () {
      final collector = FnoContractCollector(today: DateTime(2026, 1, 1))
        ..addRow(row(symbol: 'RELIANCE26JAN2650CE', token: '1'))
        ..addRow(row(symbol: 'RELIANCE26JAN2650PE', token: '2'));

      final contracts = collector.build();
      expect(contracts.length, 2);
      expect(contracts.map((c) => c.optionType).toSet(), {'CE', 'PE'});
      expect(contracts.every((c) => c.strike == 26500), isTrue);
      expect(contracts.every((c) => c.underlying == 'RELIANCE'), isTrue);
      expect(contracts.first.expiryDate, DateTime(2026, 1, 26));
    });

    test('a repeated token overwrites instead of duplicating', () {
      // The same token can appear twice inside one master snapshot (the file is
      // not de-duplicated); a duplicate row would break the UNIQUE index.
      final collector = FnoContractCollector(today: DateTime(2026, 1, 1))
        ..addRow(row(symbol: 'RELIANCE26JAN2650CE', token: '1'))
        ..addRow(row(symbol: 'RELIANCE26JAN2650CE', token: '1'));

      expect(collector.build().length, 1);
    });

    test('the strike keeps its two decimals (no float noise)', () {
      final collector = FnoContractCollector(today: DateTime(2026, 1, 1))
        ..addRow(row(strike: 129850, symbol: 'RELIANCE26JAN1298.5CE'));

      expect(collector.build().single.strike, closeTo(1298.5, 1e-9));
    });

    test('keeps exactly the nearest three monthly stock expiries', () {
      // The 3-Month Study offers current + next two expiries regardless of how
      // close the current contract is to expiry; the fourth is not retained.
      final collector = FnoContractCollector(today: DateTime(2026, 1, 1));
      for (final expiry in [
        '26JAN2026',
        '24FEB2026',
        '31MAR2026',
        '28APR2026',
      ]) {
        collector.addRow(
          row(expiry: expiry, token: expiry, symbol: 'RELIANCE${expiry}CE'),
        );
      }

      final expiries =
          collector.build().map((c) => c.expiryDate).toSet().toList()..sort();
      expect(expiries, [
        DateTime(2026, 1, 26),
        DateTime(2026, 2, 24),
        DateTime(2026, 3, 31),
      ]);
    });

    test(
      'expired contracts cannot crowd out the next three monthly expiries',
      () {
        final collector = FnoContractCollector(today: DateTime(2026, 1, 1));
        for (final expiry in [
          '25SEP2025',
          '28OCT2025',
          '25NOV2025',
          '26JAN2026',
          '24FEB2026',
          '31MAR2026',
          '28APR2026',
        ]) {
          collector.addRow(
            row(expiry: expiry, token: expiry, symbol: 'RELIANCE${expiry}CE'),
          );
        }

        final expiries =
            collector.build().map((c) => c.expiryDate).toSet().toList()..sort();
        expect(expiries, [
          DateTime(2026, 1, 26),
          DateTime(2026, 2, 24),
          DateTime(2026, 3, 31),
        ]);
      },
    );

    test('different underlyings keep their own expiries', () {
      final collector =
          FnoContractCollector(
              maxExpiriesPerUnderlying: 1,
              today: DateTime(2026, 1, 1),
            )
            ..addRow(row(name: 'RELIANCE', symbol: 'RELIANCE26JAN2650CE'))
            ..addRow(row(name: 'INFY', symbol: 'INFY26JAN1800CE', token: '9'))
            ..addRow(
              row(name: 'RELIANCE', symbol: 'RELIANCE24FEB2650CE', token: '7'),
            );

      expect(collector.underlyingCount, 2);
      expect(collector.contractCount, 2);
      final reliances = collector.build().where(
        (c) => c.underlying == 'RELIANCE',
      );
      expect(reliances.single.expiryDate, DateTime(2026, 1, 26));
    });

    test('reset empties the book and the counters', () {
      final collector = FnoContractCollector(today: DateTime(2026, 1, 1))
        ..addRow(row())
        ..addRow(row(segment: 'NSE'));
      collector.reset();
      expect(collector.build(), isEmpty);
      expect(collector.accepted, 0);
      expect(collector.rejected, 0);
    });
  });
}
