// ---------------------------------------------------------------------------
// study_export_test.dart — the file the study hands to Excel/CSV now carries
// the two columns the user asked for next to ATR:
//
//   **ATM jodi % of price** and **OTM jodi % of price**
//
// They are the sheet's own comparison tool: sort by the percentage and a ₹16
// jodi on a ₹130 stock stops looking like the same trade as ₹16 on ₹1,000.
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/features/fno/study/black_scholes.dart'
    show OptionType;
import 'package:angel_trader/features/fno/study/study_engine.dart';
import 'package:angel_trader/features/fno/study/study_export.dart';
import 'package:excel/excel.dart';
import 'package:flutter_test/flutter_test.dart';

/// ₹130 ka stock: ATM jodi 8.20 + 7.90 = 16.10 → 12.38%,
/// OTM jodi 3.40 + 3.10 = 6.50 → 5.00%.
StudyRow _row({bool options = true, double avgRange = 4, double avgRangePct = 3.08}) => StudyRow(
      symbol: 'RELIANCE',
      companyName: 'Reliance Industries Ltd',
      exchange: Exchange.nse,
      token: 'eq-RELIANCE',
      underlying: 'RELIANCE',
      ltp: 130,
      high3m: 132,
      low3m: 100,
      rangePct: 32,
      atr: 2,
      atrPct: 1.5,
      avgRange: avgRange,
      avgRangePct: avgRangePct,
      distHiPct: 1.5,
      distLoPct: 23,
      distHiDays: 1,
      distLoDays: 15,
      months: const [
        MonthMove(label: 'Aug-25', key: '2025-08', pct: 3),
        MonthMove(label: 'Sep-25', key: '2025-09', pct: 4),
        MonthMove(label: 'Oct-25', key: '2025-10', pct: 2),
      ],
      total3mPct: 30,
      upMonths: 3,
      downMonths: 0,
      trend: Trend3M.strongUp,
      atmStrike: 130,
      expiryLabel: '26JAN2026',
      expiryDate: DateTime(2026, 1, 26),
      daysToExpiry: 20,
      lotSize: 250,
      ce: options
          ? const StudyOptionLeg(
              strike: 130,
              type: OptionType.call,
              token: 'ce',
              symbol: 'RELIANCE26JAN130CE',
              ltp: 8.2,
            )
          : null,
      pe: options
          ? const StudyOptionLeg(
              strike: 130,
              type: OptionType.put,
              token: 'pe',
              symbol: 'RELIANCE26JAN130PE',
              ltp: 7.9,
            )
          : null,
      strangle: options
          ? StudyStrangle(
              ce: const StudyOptionLeg(
                strike: 136.5,
                type: OptionType.call,
                token: 'otm-ce',
                symbol: 'RELIANCE26JAN136CE',
                ltp: 3.4,
              ),
              pe: const StudyOptionLeg(
                strike: 123.5,
                type: OptionType.put,
                token: 'otm-pe',
                symbol: 'RELIANCE26JAN123PE',
                ltp: 3.1,
              ),
              targetPremium: 8.05,
            )
          : null,
      avgIv: 18.2,
      ivSource: IvSource.broker,
      edgePct: 0.4,
      consistencyPoints: 3,
      magnitudePoints: 3,
      proximityPoints: 3,
      ivPoints: 2,
      score: 10.5,
      ivRank: IvRank.low,
      opportunityTag: '🎯 Best Buy',
      rank: 1,
      reason: 'Test row.',
      bars: 400,
      asOf: DateTime(2025, 10, 6),
    );

String _text(ExportCell? cell) => switch (cell) {
      null => '',
      TextCellValue() => '${cell.value}',
      IntCellValue() => '${cell.value}',
      DoubleCellValue() => '${cell.value}',
      _ => '$cell',
    };

void main() {
  group('the two new columns', () {
    test('sit at the end of the header, in order', () {
      final headers = StudyExportService.headers;
      expect(headers.length, 44,
          reason: 'the classic 40, these two, plus the 1.5.62 range pair');
      expect(headers[40], 'ATM jodi % of price');
      expect(headers[41], 'OTM jodi % of price');
      // …and nothing that was there before moved.
      expect(headers[39], 'Kal ka OTM P&L');
    });

    test('carry the share of the stock price, one row at a time', () {
      final cells = StudyExportService.rowCells(_row());
      // 16.10 of 130 = 12.38% · 6.50 of 130 = 5.00%
      expect(_text(cells[40]), '12.38%');
      expect(_text(cells[41]), '5.00%');
      // Every row still has one cell per header — a short row would silently
      // shift every column after it.
      expect(cells.length, StudyExportService.headers.length);
    });

    test('are blank, not zero, when the jodi is missing', () {
      final cells = StudyExportService.rowCells(_row(options: false));
      expect(_text(cells[40]), '—');
      expect(_text(cells[41]), '—');
    });

    test('the sheet explains them, like every other column', () {
      final readMe = StudyExportService.readMeSheet(
        FnoStudyExportMeta(
          asOf: DateTime(2025, 10, 6),
          runAt: DateTime(2025, 10, 6),
          rowCount: 1,
          bestBuyCount: 1,
          withOptions: 1,
        ),
      );
      final flat = readMe.map((row) => row.map(_text).join(' ')).join('\n');
      expect(flat, contains('ATM jodi % of price'));
      expect(flat, contains('OTM jodi % of price'));
      expect(flat, contains('stock ke bhav ka kitna percent'));
    });
  });

  group('the two range columns (1.5.62)', () {
    test('sit at the very end of the header, in order', () {
      final headers = StudyExportService.headers;
      expect(headers[42], 'Avg Range (14)');
      expect(headers[43], 'Avg Range %');
    });

    test('carry ₹ range and its share of the price, one row at a time', () {
      final cells = StudyExportService.rowCells(_row());
      // ₹4.00 range on a ₹130 stock = 3.08%
      expect(_text(cells[42]), '4.00');
      expect(_text(cells[43]), '3.08%');
      expect(cells.length, StudyExportService.headers.length);
    });

    test('are blank, not zero, when the row predates the field', () {
      final cells = StudyExportService.rowCells(_row(avgRange: 0));
      expect(_text(cells[42]), '—');
      expect(_text(cells[43]), '—');
    });

    test('the sheet explains them, like every other column', () {
      final readMe = StudyExportService.readMeSheet(
        FnoStudyExportMeta(
          asOf: DateTime(2025, 10, 6),
          runAt: DateTime(2025, 10, 6),
          rowCount: 1,
          bestBuyCount: 1,
          withOptions: 1,
        ),
      );
      final flat = readMe.map((row) => row.map(_text).join(' ')).join('\n');
      expect(flat, contains('Avg Range (14)'));
      expect(flat, contains('High − Low'));
      expect(flat, contains('gap up/down chhod ke'));
    });
  });
}
