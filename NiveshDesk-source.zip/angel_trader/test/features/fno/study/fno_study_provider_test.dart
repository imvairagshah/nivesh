// ---------------------------------------------------------------------------
// fno_study_provider_test.dart — the screen's state machine.
//
// The provider is where the spec's presentation rules live, so those are what is
// pinned here:
//
//   • default order = 🎯 best buys first, then score (spec §4.1),
//   • a missing value (no IV, no P&L) sorts last in *both* directions instead of
//     pretending to be zero,
//   • search + filter chips narrow the same table the export sends,
//   • the stored snapshot is what the tab shows on open (no surprise scan),
//   • expanding a row subscribes its two ATM legs to the live feed, and closing
//     it releases them again.
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/candle_dao.dart';
import 'package:angel_trader/data/local/dao/fno_contract_dao.dart';
import 'package:angel_trader/data/local/dao/ipo_dao.dart';
import 'package:angel_trader/data/local/dao/scan_cache_dao.dart';
import 'package:angel_trader/data/local/dao/scrip_dao.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/data/remote/dto/quote.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/features/fno/study/black_scholes.dart'
    show OptionType;
import 'package:angel_trader/features/fno/study/fno_study_provider.dart';
import 'package:angel_trader/features/fno/study/study_engine.dart';
import 'package:angel_trader/features/settings/settings_provider.dart';
import 'package:angel_trader/data/local/dao/earnings_dao.dart';
import 'package:angel_trader/services/candle_source.dart';
import 'package:angel_trader/services/earnings_calendar_service.dart';
import 'package:angel_trader/services/fno_study_service.dart';
import 'package:angel_trader/services/fno_universe.dart';
import 'package:angel_trader/services/live_feed_service.dart';
import 'package:angel_trader/services/scrip_master_service.dart';
import 'package:angel_trader/services/secure_store.dart';
import 'package:angel_trader/services/auth_service.dart';
import 'package:angel_trader/services/study_market_data.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

class NoopSource implements CandleSource {
  @override
  Future<List<Candle>> fetchDailyCandles({
    required Scrip scrip,
    required DateTime from,
    required DateTime to,
    String interval = 'ONE_DAY',
  }) async => const [];
}

class NoopMarket implements StudyMarketData {
  @override
  Future<Map<String, MarketQuote>> fetchQuotesFull(List<Scrip> scrips) async =>
      {};

  @override
  Future<OptionGreekBatch> fetchOptionGreeks({
    required String underlying,
    required String expiryLabel,
  }) async => const OptionGreekBatch(byStrike: {});
}

class FakeExpiryMaster extends ScripMasterService {
  FakeExpiryMaster({
    required super.scripDao,
    required super.settingsDao,
    required FnoContractDao contracts,
    required this.expiries,
  }) : _contracts = contracts,
       super(fnoContracts: contracts);

  final FnoContractDao _contracts;
  final List<DateTime> expiries;
  int refreshCalls = 0;

  @override
  Future<int> refresh({bool force = false}) async {
    refreshCalls++;
    await _contracts.replaceAll([
      for (final expiry in expiries)
        for (final type in ['CE', 'PE'])
          FnoContract(
            underlying: 'ALPHA',
            expiryLabel: FnoContract.labelFor(expiry),
            expiryDate: expiry,
            strike: 100,
            optionType: type,
            token: '${expiry.toIso8601String()}-$type',
            symbol: 'ALPHA${FnoContract.labelFor(expiry)}100$type',
            lotSize: 75,
          ),
    ]);
    return 0;
  }
}

/// Builds a row directly, so the provider tests do not depend on candle maths.
StudyRow row({
  required String symbol,
  required double score,
  Trend3M trend = Trend3M.up,
  double? edgePct,
  double? avgIv,
  IvRank ivRank = IvRank.unknown,
  double? yesterdayPoints,
  String tag = '-',
  String? ceToken,
  String? peToken,
  double ltp = 100,
}) => StudyRow(
  symbol: symbol,
  companyName: '$symbol Limited',
  exchange: Exchange.nse,
  token: 'eq-$symbol',
  underlying: symbol,
  ltp: ltp,
  high3m: ltp * 1.2,
  low3m: ltp * 0.8,
  rangePct: 50,
  atr: ltp * 0.02,
  atrPct: 2,
  distHiPct: 20,
  distLoPct: 20,
  distHiDays: 10,
  distLoDays: 10,
  months: const [
    MonthMove(label: 'Jan-25', key: '2025-01', pct: 4),
    MonthMove(label: 'Feb-25', key: '2025-02', pct: 5),
    MonthMove(label: 'Mar-25', key: '2025-03', pct: 6),
  ],
  total3mPct: 15,
  upMonths: 3,
  downMonths: 0,
  trend: trend,
  atmStrike: ceToken == null ? null : ltp,
  expiryLabel: ceToken == null ? null : '24APR2025',
  expiryDate: ceToken == null ? null : DateTime(2025, 4, 24),
  daysToExpiry: ceToken == null ? null : 34,
  lotSize: 75,
  ce: ceToken == null
      ? null
      : StudyOptionLeg(
          strike: ltp,
          type: OptionType.call,
          token: ceToken,
          symbol: '$symbol-ATM-CE',
          ltp: 8,
          previousClose: 6,
          iv: avgIv,
          ivSource: avgIv == null ? IvSource.none : IvSource.broker,
        ),
  pe: peToken == null
      ? null
      : StudyOptionLeg(
          strike: ltp,
          type: OptionType.put,
          token: peToken,
          symbol: '$symbol-ATM-PE',
          ltp: 5,
          previousClose: 4,
          iv: avgIv,
          ivSource: avgIv == null ? IvSource.none : IvSource.broker,
        ),
  avgIv: avgIv,
  edgePct: edgePct,
  consistencyPoints: 3,
  magnitudePoints: 2,
  proximityPoints: 3,
  ivPoints: 2,
  score: score,
  ivRank: ivRank,
  opportunityTag: tag,
  rank: 1,
  reason: 'Test row',
  bars: 63,
  asOf: DateTime(2025, 3, 21),
);

void main() {
  late AppDatabase db;
  late ScanCacheDao cache;
  late FnoStudyProvider provider;
  late LiveFeedService feed;

  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close();
    db = AppDatabase.instance;

    final scripDao = ScripDao(db);
    final settingsDao = SettingsDao(db);
    cache = ScanCacheDao(db);
    final settings = SettingsProvider(settingsDao);
    await settings.load();

    final study = FnoStudyService(
      source: NoopSource(),
      candles: CandleDao(db),
      cache: cache,
      contracts: FnoContractDao(db),
      marketData: NoopMarket(),
    );

    feed = LiveFeedService(auth: AuthService(store: SecureStore()));
    provider = FnoStudyProvider(
      study: study,
      settings: settings,
      scripDao: scripDao,
      ipoDao: IpoDao(db),
      scripMaster: ScripMasterService(
        scripDao: scripDao,
        settingsDao: settingsDao,
      ),
      feed: feed,
      earnings: EarningsCalendarService(
        dao: EarningsDao(db),
        settings: settingsDao,
        get: (_) async => '[]',
      ),
    );
  });

  tearDown(() async {
    provider.dispose();
    await feed.stop();
  });

  tearDownAll(() async {
    await AppDatabase.instance.close();
  });

  /// Stores a run the way the service does, then lets the provider load it.
  Future<void> seedSnapshot(List<StudyRow> rows) async {
    await cache.saveRun(
      kind: FnoStudyService.cacheKind,
      asOf: '2025-03-21',
      rows: [
        {
          'rows': [for (final r in rows) r.toJson()],
        },
      ],
    );
    await provider.loadCached();
  }

  test('opening the tab loads the stored snapshot and never scans', () async {
    await seedSnapshot([row(symbol: 'ALPHA', score: 8)]);
    expect(provider.hasResult, isTrue);
    expect(provider.result!.fromCacheOnly, isTrue);
    expect(provider.rows.single.symbol, 'ALPHA');
    expect(provider.rows.single.companyName, 'ALPHA Limited');
  });

  test(
    'expiry picker offers three dates, defaults nearest, and stays idle on change',
    () async {
      final today = MarketCalendar.nowIst();
      final dates = [
        for (var offset = 1; offset <= 4; offset++)
          DateTime(today.year, today.month + offset, 28),
      ];
      await FnoContractDao(db).replaceAll([
        for (var i = 0; i < dates.length; i++)
          FnoContract(
            underlying: 'ALPHA',
            expiryLabel: FnoContract.labelFor(dates[i]),
            expiryDate: dates[i],
            strike: 100,
            optionType: 'CE',
            token: 'expiry-$i',
            symbol: 'ALPHA${FnoContract.labelFor(dates[i])}100CE',
            lotSize: 75,
          ),
      ]);

      await provider.refreshExpiryOptions();

      expect(provider.expiryOptions, dates.take(3).toList());
      expect(provider.selectedExpiry, dates.first);
      expect(provider.hasResult, isFalse);

      provider.selectExpiry(dates[1]);

      expect(provider.selectedExpiry, dates[1]);
      expect(provider.isRunning, isFalse);
      expect(provider.hasResult, isFalse);
    },
  );

  test(
    'opening a short expiry picker syncs the master without scanning',
    () async {
      final today = MarketCalendar.nowIst();
      final dates = [
        for (var offset = 1; offset <= 3; offset++)
          DateTime(today.year, today.month + offset, 28),
      ];
      final contractDao = FnoContractDao(db);
      await contractDao.replaceAll([
        FnoContract(
          underlying: 'ALPHA',
          expiryLabel: FnoContract.labelFor(dates.first),
          expiryDate: dates.first,
          strike: 100,
          optionType: 'CE',
          token: 'current-only',
          symbol: 'ALPHA${FnoContract.labelFor(dates.first)}100CE',
          lotSize: 75,
        ),
      ]);

      final scripDao = ScripDao(db);
      final settingsDao = SettingsDao(db);
      final settings = SettingsProvider(settingsDao);
      await settings.load();
      final master = FakeExpiryMaster(
        scripDao: scripDao,
        settingsDao: settingsDao,
        contracts: contractDao,
        expiries: dates,
      );
      final pickerProvider = FnoStudyProvider(
        study: FnoStudyService(
          source: NoopSource(),
          candles: CandleDao(db),
          cache: cache,
          contracts: contractDao,
          marketData: NoopMarket(),
        ),
        settings: settings,
        scripDao: scripDao,
        ipoDao: IpoDao(db),
        scripMaster: master,
        feed: feed,
        earnings: EarningsCalendarService(
          dao: EarningsDao(db),
          settings: settingsDao,
          get: (_) async => '[]',
        ),
        fnoUniverse: const FnoUniverse(symbols: ['ALPHA'], companyNames: {}),
      );
      addTearDown(pickerProvider.dispose);

      await pickerProvider.refreshExpiryOptions();
      expect(pickerProvider.expiryOptions, [dates.first]);

      await pickerProvider.prepareExpiryPicker();

      expect(master.refreshCalls, 1);
      expect(pickerProvider.expiryOptions, dates);
      expect(pickerProvider.isRunning, isFalse);
      expect(pickerProvider.hasResult, isFalse);

      // Reopening with a complete local list must not download the master again.
      await pickerProvider.prepareExpiryPicker();
      expect(master.refreshCalls, 1);
    },
  );

  test('default order is best buys first, then score', () async {
    await seedSnapshot([
      row(symbol: 'LOWSCORE', score: 4),
      row(
        symbol: 'WATCH',
        score: 11,
        tag: '⏸ Watch — BUY CE (IV high, thoda mehenga)',
      ),
      row(
        symbol: 'BEST',
        score: 7,
        tag: '🎯 Best Buy — BUY CE (IV sasta)',
        edgePct: 0.4,
      ),
    ]);

    expect(provider.rows.map((r) => r.symbol).toList(), [
      'BEST',
      'WATCH',
      'LOWSCORE',
    ]);
    expect(provider.result!.bestBuyCount, 1);
  });

  test(
    'sorting by a column keeps missing values last in both directions',
    () async {
      await seedSnapshot([
        row(symbol: 'HASIV', score: 5, avgIv: 30, edgePct: 1.0),
        row(symbol: 'NOIV', score: 9),
        row(symbol: 'THINIV', score: 6, avgIv: 12, edgePct: 0.2),
      ]);

      provider.sortBy(StudySort.iv);
      expect(provider.rows.first.symbol, 'HASIV'); // desc: biggest IV first
      expect(provider.rows.last.symbol, 'NOIV'); // unknown stays last

      provider.sortBy(StudySort.iv); // flip
      expect(provider.sortDescending, isFalse);
      expect(provider.rows.first.symbol, 'THINIV');
      expect(provider.rows.last.symbol, 'NOIV'); // still last
    },
  );

  test(
    'the user sort overrides the spec ranking, and reset brings it back',
    () async {
      await seedSnapshot([
        row(symbol: 'BEST', score: 7, tag: '🎯 Best Buy — BUY CE (IV sasta)'),
        row(symbol: 'STRONG', score: 11),
      ]);

      provider.sortBy(StudySort.score);
      expect(provider.rows.first.symbol, 'STRONG');
      expect(provider.sortIsUserChoice, isTrue);

      provider.resetSort();
      expect(provider.sortIsUserChoice, isFalse);
      expect(provider.rows.first.symbol, 'BEST');
    },
  );

  test('search matches symbol, company name and trend', () async {
    await seedSnapshot([
      row(symbol: 'ALPHA', score: 5),
      row(symbol: 'BETA', score: 6, trend: Trend3M.strongDown),
    ]);

    provider.setQuery('alpha');
    expect(provider.rows.map((r) => r.symbol).toList(), ['ALPHA']);

    provider.setQuery('limited');
    expect(provider.rows.length, 2);

    provider.setQuery('strong down');
    expect(provider.rows.map((r) => r.symbol).toList(), ['BETA']);

    provider.setQuery('');
    expect(provider.rows.length, 2);
  });

  test('filter chips narrow the table', () async {
    await seedSnapshot([
      row(symbol: 'BEST', score: 7, tag: '🎯 Best Buy — BUY CE (IV sasta)'),
      row(
        symbol: 'WATCH',
        score: 9,
        tag: '⏸ Watch — BUY CE (IV high, thoda mehenga)',
      ),
      row(symbol: 'SIDE', score: 3, trend: Trend3M.sideways, tag: '-'),
      row(symbol: 'FLAT', score: 4, trend: Trend3M.sideways, tag: '-'),
    ]);

    provider.setFilter(StudyFilter.bestBuy);
    expect(provider.rows.map((r) => r.symbol).toList(), ['BEST']);

    provider.setFilter(StudyFilter.watch);
    expect(provider.rows.map((r) => r.symbol).toList(), ['WATCH']);

    provider.setFilter(StudyFilter.avoid);
    // Both sideways, ordered by score (FLAT 4 before SIDE 3).
    expect(provider.rows.map((r) => r.symbol).toList(), ['FLAT', 'SIDE']);

    provider.setFilter(StudyFilter.degraded);
    expect(provider.rows.length, 4); // none of these rows has IV data

    provider.setFilter(StudyFilter.all);
    expect(provider.rows.length, 4);
  });

  test('export meta follows the filtered table', () async {
    await seedSnapshot([
      row(symbol: 'BEST', score: 7, tag: '🎯 Best Buy — BUY CE (IV sasta)'),
      row(
        symbol: 'WATCH',
        score: 9,
        tag: '⏸ Watch — BUY CE (IV high, thoda mehenga)',
      ),
    ]);

    provider.setFilter(StudyFilter.bestBuy);
    final meta = provider.exportMeta;
    expect(meta.rowCount, 1);
    expect(meta.bestBuyCount, 1);
    expect(meta.asOf, DateTime(2025, 3, 21));
  });

  test(
    'expanding a row subscribes its ATM legs and collapsing releases them',
    () async {
      await seedSnapshot([
        row(
          symbol: 'ALPHA',
          score: 7,
          tag: '🎯 Best Buy — BUY CE (IV sasta)',
          ceToken: '5001',
          peToken: '5002',
          avgIv: 20,
        ),
      ]);

      final target = provider.rows.single;
      provider.toggleExpanded(target);
      expect(provider.expandedSymbol, 'ALPHA');
      expect(feed.wantedTokenCount, 2); // both legs registered

      provider.collapse();
      expect(provider.expandedSymbol, isNull);
      expect(feed.wantedTokenCount, 0);
    },
  );

  test('a degraded row has no legs to subscribe and still expands', () async {
    await seedSnapshot([row(symbol: 'NOOPT', score: 5)]);
    provider.toggleExpanded(provider.rows.single);
    expect(provider.expandedSymbol, 'NOOPT');
    expect(feed.wantedTokenCount, 0);
  });

  test('clearing the snapshot empties the table and the cache', () async {
    await seedSnapshot([row(symbol: 'ALPHA', score: 5)]);
    await provider.clearSnapshot();
    expect(provider.rows, isEmpty);
    expect(provider.hasResult, isFalse);
    expect(await cache.latestRun(FnoStudyService.cacheKind), isNull);
  });

  test('a stale snapshot is recognised as stale', () async {
    await seedSnapshot([row(symbol: 'ALPHA', score: 5)]);
    expect(provider.result!.isStaleFor(DateTime(2025, 3, 22)), isTrue);
    expect(provider.result!.isStaleFor(DateTime(2025, 3, 21)), isFalse);
  });

  test(
    'a thin local master explains itself, and a full one scans everything',
    () async {
      // The bug: the F&O list is 213 names, but the local scrip master only held
      // instruments for 45 of them, so the study covered 45 stocks and said
      // nothing about the other 168. `universeLine` is what the banner prints.
      final fno = await FnoUniverse.load();
      if (fno.length > 200) {
        expect(
          fno.length,
          greaterThanOrEqualTo(213),
          reason: 'shipped F&O list',
        );
      }

      await provider.resolveUniverse();
      final resolved = provider.universeSize;
      final missing = provider.unresolvedCount;

      // On the test VM the scrip table is empty, so nothing resolves — exactly the
      // "thin universe" state, and it must be *visible* rather than silent.
      expect(resolved + missing, greaterThanOrEqualTo(fno.length));
      expect(provider.universeSize, lessThanOrEqualTo(fno.length));
      if (missing > 0) {
        expect(provider.universeLine, contains('resolve nahi hue'));
        expect(
          FnoStudyProvider.needsMasterSync(
            resolved: provider.universeSize,
            expected: fno.length,
            contracts: 0,
          ),
          isTrue,
          reason: 'this state must trigger the master download',
        );
      }
    },
  );

  group('headline counts', () {
    // The complaint: page open pe heading "poore 45 stocks" dikha rahi thi,
    // jabki F&O list me 213 hain. The heading must always carry the **list**
    // total — the scan repairs a thin local book by itself.
    FnoUniverse universe(int n) => FnoUniverse(
      symbols: [for (var i = 0; i < n; i++) 'STOCK$i'],
      companyNames: const {},
    );

    FnoStudyProvider build(FnoUniverse fno) {
      final scripDao = ScripDao(db);
      final settingsDao = SettingsDao(db);
      final settings = SettingsProvider(settingsDao);
      return FnoStudyProvider(
        study: FnoStudyService(
          source: NoopSource(),
          candles: CandleDao(db),
          cache: cache,
          contracts: FnoContractDao(db),
          marketData: NoopMarket(),
        ),
        settings: settings,
        scripDao: scripDao,
        ipoDao: IpoDao(db),
        scripMaster: ScripMasterService(
          scripDao: scripDao,
          settingsDao: settingsDao,
        ),
        feed: feed,
        earnings: EarningsCalendarService(
          dao: EarningsDao(db),
          settings: settingsDao,
          get: (_) async => '[]',
        ),
        fnoUniverse: fno,
      );
    }

    test(
      'the button promises the F&O list total, not the local subset',
      () async {
        final p = build(universe(213));
        addTearDown(p.dispose);

        await p.resolveUniverse();
        expect(p.universe.size, 0, reason: 'this VM has an empty scrip table');
        // `universeSize` falls back to the list length when nothing resolved —
        // the raw resolved count is what must not leak into the heading.
        expect(p.universeSize, 213);

        expect(p.universeTotal, 213);
        expect(p.scanTargetCount, 213);
        expect(p.scanButtonLabel, 'Scan chalao (poore 213 F&O stocks)');
        // The resolved subset must never leak into the heading.
        expect(p.scanButtonLabel, isNot(contains('poore 0')));

        await cache.saveRun(
          kind: FnoStudyService.cacheKind,
          asOf: '2025-03-21',
          rows: [
            {
              'rows': [row(symbol: 'ALPHA', score: 5).toJson()],
            },
          ],
        );
        await p.loadCached();
        expect(p.scanButtonLabel, 'Dobara scan (poore 213 F&O stocks)');
      },
    );

    test('a partly-resolved book keeps the total in the heading', () async {
      // The reported state, reproduced for real: 45 of the 213 names exist in
      // the local scrip table (a device that has not synced the broker master).
      await ScripDao(db).replaceAll([
        for (var i = 0; i < 45; i++)
          Scrip(
            token: '$i',
            symbol: 'STOCK$i-EQ',
            name: 'STOCK$i',
            exchange: Exchange.nse,
          ),
      ]);

      final p = build(universe(213));
      addTearDown(p.dispose);
      await p.resolveUniverse();

      expect(p.universeSize, 45, reason: 'only 45 names resolve locally');
      expect(p.universeTotal, 213);
      expect(p.scanTargetCount, 213, reason: 'heading shows the whole list');
      expect(p.scanButtonLabel, 'Scan chalao (poore 213 F&O stocks)');
      expect(
        FnoStudyProvider.needsMasterSync(
          resolved: p.universeSize,
          expected: p.universeTotal,
          contracts: 900,
        ),
        isTrue,
        reason: 'the scan must repair the master before it runs',
      );
    });
  });

  group('results calendar', () {
    test('ensureEarnings fills the map and the panel lookup', () async {
      // Dates are relative to *now*: a stale fixture would silently fall into
      // the "estimate" branch once the meeting date passed (which it did).
      const months = [
        'Jan',
        'Feb',
        'Mar',
        'Apr',
        'May',
        'Jun',
        'Jul',
        'Aug',
        'Sep',
        'Oct',
        'Nov',
        'Dec',
      ];
      String nseDate(DateTime d) =>
          '${d.day.toString().padLeft(2, '0')}-${months[d.month - 1]}-${d.year}';

      final now = DateTime.now();
      final nextMeeting = now.add(const Duration(days: 20));
      final lastFiling = now.subtract(const Duration(days: 30));

      final scripDao = ScripDao(db);
      final settingsDao = SettingsDao(db);
      final settings = SettingsProvider(settingsDao);
      final p = FnoStudyProvider(
        study: FnoStudyService(
          source: NoopSource(),
          candles: CandleDao(db),
          cache: cache,
          contracts: FnoContractDao(db),
          marketData: NoopMarket(),
        ),
        settings: settings,
        scripDao: scripDao,
        ipoDao: IpoDao(db),
        scripMaster: ScripMasterService(
          scripDao: scripDao,
          settingsDao: settingsDao,
        ),
        feed: feed,
        earnings: EarningsCalendarService(
          dao: EarningsDao(db),
          settings: settingsDao,
          get: (uri) async {
            if (uri.path.contains('board-meetings')) {
              return '[{"bm_symbol":"RELIANCE","bm_date":"${nseDate(nextMeeting)}",'
                  '"bm_purpose":"to consider and approve the quarterly '
                  'financial results"}]';
            }
            if (uri.path.contains('financial-results')) {
              return '[{"symbol":"RELIANCE",'
                  '"exchdisstime":"${nseDate(lastFiling)} 21:05:11",'
                  '"relatingTo":"Second Quarter","toDate":"30-Sep-2025"}]';
            }
            return '<html>home</html>';
          },
        ),
      );
      addTearDown(p.dispose);

      expect(p.earningsFor('RELIANCE'), isNull, reason: 'nothing loaded yet');

      await p.ensureEarnings();

      DateTime day(DateTime d) => DateTime(d.year, d.month, d.day);

      final info = p.earningsFor('reliance'); // case-insensitive on purpose
      expect(info, isNotNull);
      expect(info!.lastDate, day(lastFiling));
      expect(info.lastLabel, contains('Q2'));
      expect(info.nextDate, day(nextMeeting));
      expect(info.nextConfirmed, isTrue);
      expect(info.estimated, isFalse);
      expect(p.earningsNote, contains('NSE'));
    });
  });

  group('scrip-master sync gate', () {
    test('a thin universe triggers a master sync', () {
      // This is exactly the bug the user hit: a 213-name F&O list resolving to
      // 45 stocks because the local master was still the bundled seed.
      expect(
        FnoStudyProvider.needsMasterSync(
          resolved: 45,
          expected: 213,
          contracts: 900,
        ),
        isTrue,
      );
      expect(
        FnoStudyProvider.needsMasterSync(
          resolved: 120,
          expected: 213,
          contracts: 900,
        ),
        isTrue,
      );
    });

    test('a healthy universe does not', () {
      expect(
        FnoStudyProvider.needsMasterSync(
          resolved: 210,
          expected: 213,
          contracts: 900,
        ),
        isFalse,
      );
      expect(
        FnoStudyProvider.needsMasterSync(
          resolved: 213,
          expected: 213,
          contracts: 1,
        ),
        isFalse,
      );
    });

    test('an empty option book always triggers one', () {
      // Without contracts every stock would land in degraded mode; that is worth
      // one master download even when the universe itself looks fine.
      expect(
        FnoStudyProvider.needsMasterSync(
          resolved: 213,
          expected: 213,
          contracts: 0,
        ),
        isTrue,
      );
    });

    test('an unknown list length cannot block the scan', () {
      expect(
        FnoStudyProvider.needsMasterSync(
          resolved: 0,
          expected: 0,
          contracts: 5,
        ),
        isFalse,
      );
    });

    test(
      'fewer than three monthly stock expiries refreshes the local book',
      () {
        expect(
          FnoStudyProvider.needsMasterSync(
            resolved: 213,
            expected: 213,
            contracts: 1200,
            expiryCount: 2,
          ),
          isTrue,
        );
        expect(
          FnoStudyProvider.needsMasterSync(
            resolved: 213,
            expected: 213,
            contracts: 1200,
            expiryCount: 3,
          ),
          isFalse,
        );
      },
    );
  });

  test('status line carries the counts the banner shows', () async {
    await seedSnapshot([
      row(symbol: 'BEST', score: 7, tag: '🎯 Best Buy — BUY CE (IV sasta)'),
      row(symbol: 'NOIV', score: 5),
    ]);

    final line = provider.statusLine;
    expect(line, contains('2 stocks'));
    expect(line, contains('1 best-buy'));
    expect(line, contains('2 degraded')); // neither row could be priced
  });
}
