// ---------------------------------------------------------------------------
// study_engine_test.dart — the 3-Month Study maths, pinned to fixtures whose
// answers can be worked out by hand.
//
// The fixtures are ramps, not random walks, so every expectation below is exact:
//
//   • a clean 1-rupee-per-day ramp has ATR = 1.0 exactly (every true range is 1)
//   • with 63 bars from 100 → 162, the 3M move is +62 % and the low is 62 ATR
//     away, while the high sits on top of the price (0 ATR)
//   • sideways = flat series: ATR 0, no direction, the AVOID tag
//
// If a constant here ever changes, the numbers below change with it — that is
// the point (spec §2 is a contract with the user, not an implementation detail).
// ---------------------------------------------------------------------------

import 'dart:math' as math;

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/features/fno/study/black_scholes.dart';
import 'package:angel_trader/features/fno/study/study_engine.dart';
import 'package:flutter_test/flutter_test.dart';

/// The last bar of every fixture — 63 bars back from here = 2025-01-18.
final DateTime kEnd = DateTime(2025, 3, 21);

/// `count` daily bars whose price walks by [step] from [base]; high = low =
/// close = price, so the true range of bar *i* is exactly |step|.
List<Candle> ramp(int count, {double base = 100, double step = 1}) {
  final bars = <Candle>[];
  for (var i = 0; i < count; i++) {
    final price = base + step * i;
    bars.add(Candle(
      time: kEnd.subtract(Duration(days: count - 1 - i)),
      open: price,
      high: price,
      low: price,
      close: price,
      volume: 1000,
    ));
  }
  return bars;
}

Scrip scrip(String symbol, {String token = '1'}) => Scrip(
      token: token,
      symbol: '$symbol-EQ',
      name: '$symbol Limited',
      exchange: Exchange.nse,
    );

StudyRow computeOrFail({
  required List<Candle> bars,
  String symbol = 'TEST',
  StudyOptionInput? options,
  StudyOptionInput? yesterdayOptions,
  DateTime? asOf,
}) {
  final row = computeStudy(
    scrip: scrip(symbol),
    candles: bars,
    asOf: asOf ?? kEnd,
    options: options,
    yesterdayOptions: yesterdayOptions,
    companyName: '$symbol Limited',
  );
  expect(row, isNotNull, reason: 'computeStudy returned null for $symbol');
  return row!;
}

void main() {
  // Shared fixtures (hoisted out of the groups so every group — including
  // the time-base guards below — can build the same ATM/kal pairs).
  StudyOptionInput atmInput({
    double ceIv = 18,
    double peIv = 22,
    double ceLtp = 8,
    double cePrev = 6.5,
    double peLtp = 5,
    double pePrev = 4,
  }) =>
      StudyOptionInput(
        strike: 160,
        expiryLabel: '24APR2025',
        expiryDate: DateTime(2025, 4, 24),
        lotSize: 75,
        ce: StudyOptionLeg(
          strike: 160,
          type: OptionType.call,
          token: '111',
          symbol: 'TEST24APR160CE',
          ltp: ceLtp,
          previousClose: cePrev,
          iv: ceIv,
          ivSource: IvSource.broker,
        ),
        pe: StudyOptionLeg(
          strike: 160,
          type: OptionType.put,
          token: '112',
          symbol: 'TEST24APR160PE',
          ltp: peLtp,
          previousClose: pePrev,
          iv: peIv,
          ivSource: IvSource.broker,
        ),
      );

  StudyOptionInput kalInput({
    double ceLtp = 21,
    double cePrev = 6,
    double peLtp = 4,
    double pePrev = 9,
  }) =>
      StudyOptionInput(
        strike: 150,
        expiryLabel: '24APR2025',
        expiryDate: DateTime(2025, 4, 24),
        lotSize: 75,
        ce: StudyOptionLeg(
          strike: 150,
          type: OptionType.call,
          token: '101',
          symbol: 'TEST24APR150CE',
          ltp: ceLtp,
          previousClose: cePrev,
        ),
        pe: StudyOptionLeg(
          strike: 150,
          type: OptionType.put,
          token: '102',
          symbol: 'TEST24APR150PE',
          ltp: peLtp,
          previousClose: pePrev,
        ),
      );

  group('window, levels and ATR', () {
    test('up ramp: exact levels, ATR and distances', () {
      final row = computeOrFail(bars: ramp(63));

      expect(row.symbol, 'TEST');
      expect(row.companyName, 'TEST Limited');
      expect(row.bars, 63);
      expect(row.ltp, closeTo(162, 0));
      expect(row.high3m, closeTo(162, 0));
      expect(row.low3m, closeTo(100, 0));
      expect(row.rangePct, closeTo(62, 1e-9));

      // Every true range is exactly 1 → Wilder ATR = 1, with no decay.
      expect(row.atr, closeTo(1, 1e-9));
      expect(row.atrPct, closeTo(100 / 162, 1e-9));

      expect(row.distHiPct, closeTo(0, 1e-9));
      expect(row.distHiDays, closeTo(0, 1e-9));
      expect(row.distLoPct, closeTo(38.2716049382716, 1e-9));
      expect(row.distLoDays, closeTo(62, 1e-9));
    });

    test('window is the last 63 bars, not the whole history', () {
      final row = computeOrFail(bars: ramp(120, base: 100, step: 1));

      // 120 bars from 100 → 219; the 63-bar window starts at 157.
      expect(row.bars, 120);
      expect(row.ltp, closeTo(219, 0));
      expect(row.low3m, closeTo(157, 0));
      expect(row.high3m, closeTo(219, 0));
      expect(row.rangePct, closeTo((219 - 157) / 157 * 100, 1e-9));
    });

    test('fewer than 60 bars is skipped, 60 is enough', () {
      expect(
        computeStudy(scrip: scrip('SHORT'), candles: ramp(59), asOf: kEnd),
        isNull,
      );
      final row = computeStudy(scrip: scrip('OK'), candles: ramp(60), asOf: kEnd);
      expect(row, isNotNull);
      expect(row!.bars, 60);
    });

    test('as-of date cuts the series (cached bars never leak into the future)',
        () {
      final bars = ramp(80);
      final asOf = kEnd.subtract(const Duration(days: 10));
      final row = computeOrFail(bars: bars, asOf: asOf);

      // 80 bars ending 2025-03-21, cut at 2025-03-11 → 70 bars, last = 169.
      expect(row.bars, 70);
      expect(row.ltp, closeTo(169, 0));
      expect(row.asOf, DateTime(2025, 3, 11));
    });

    test('a flat series has zero ATR and no direction', () {
      final row = computeOrFail(bars: ramp(63, base: 100, step: 0));

      expect(row.atr, 0);
      expect(row.atrPct, 0);
      expect(row.total3mPct, 0);
      expect(row.trend, Trend3M.sideways);
      expect(row.trend.suggested, 'AVOID');
      expect(row.rangePct, 0);
    });
  });

  group('month-wise movement', () {
    test('three months, oldest first, with exact percentages', () {
      final row = computeOrFail(bars: ramp(63));

      expect(row.months.length, 3);
      expect(row.months.map((m) => m.key).toList(),
          ['2025-01', '2025-02', '2025-03']);
      expect(row.months.map((m) => m.label).toList(),
          ['Jan-25', 'Feb-25', 'Mar-25']);

      expect(row.months[0].pct, closeTo(13, 1e-9)); // 100 → 113
      expect(row.months[1].pct, closeTo(23.6842105263158, 1e-9)); // 114 → 141
      expect(row.months[2].pct, closeTo(14.0845070422535, 1e-9)); // 142 → 162

      expect(row.upMonths, 3);
      expect(row.downMonths, 0);
      expect(row.total3mPct, closeTo(62, 1e-9));
    });

    test('down ramp counts down months and classifies STRONG DOWN', () {
      final row = computeOrFail(bars: ramp(63, base: 200, step: -1), symbol: 'FALL');

      expect(row.ltp, closeTo(138, 0));
      expect(row.high3m, closeTo(200, 0));
      expect(row.low3m, closeTo(138, 0));
      expect(row.total3mPct, closeTo(-31, 1e-9));
      expect(row.downMonths, 3);
      expect(row.upMonths, 0);
      expect(row.trend, Trend3M.strongDown);
      expect(row.trend.suggested, 'BUY PE');
      expect(row.distLoPct, closeTo(0, 1e-9));
      expect(row.distHiPct, closeTo(31, 1e-9));
    });
  });

  group('trend classification', () {
    test('thresholds and the 2-month requirement', () {
      expect(
        classifyTrend(total3mPct: 6.0, upMonths: 2, downMonths: 1),
        Trend3M.strongUp,
      );
      expect(
        classifyTrend(total3mPct: 6.0, upMonths: 1, downMonths: 2),
        Trend3M.sideways, // big move, but the months disagree
      );
      expect(
        classifyTrend(total3mPct: 1.5, upMonths: 2, downMonths: 0),
        Trend3M.up,
      );
      expect(
        classifyTrend(total3mPct: 1.49, upMonths: 3, downMonths: 0),
        Trend3M.sideways,
      );
      expect(
        classifyTrend(total3mPct: -6.0, downMonths: 2, upMonths: 1),
        Trend3M.strongDown,
      );
      expect(
        classifyTrend(total3mPct: -1.5, downMonths: 2, upMonths: 0),
        Trend3M.down,
      );
      expect(
        classifyTrend(total3mPct: -1.49, downMonths: 3, upMonths: 0),
        Trend3M.sideways,
      );
    });
  });

  group('score', () {
    test('a clean up ramp with no option data scores 10.5', () {
      final row = computeOrFail(bars: ramp(63));

      expect(row.consistencyPoints, 3);
      expect(row.magnitudePoints, 3); // 62 / 8 is capped at 3
      expect(row.proximityPoints, 3); // price is on the 3M high
      expect(row.ivPoints, 1.5); // neutral: no IV data
      expect(row.score, closeTo(10.5, 1e-9));
      expect(row.edgePct, isNull);
      expect(row.avgIv, isNull);
    });

    test('consistency drops when a month disagrees', () {
      expect(consistencyPoints(Trend3M.strongUp, 3, 0), 3);
      expect(consistencyPoints(Trend3M.strongUp, 2, 1), 2);
      expect(consistencyPoints(Trend3M.strongUp, 1, 2), 1);
      expect(consistencyPoints(Trend3M.sideways, 2, 1), 1);
    });

    test('proximity bands', () {
      expect(proximityPoints(trend: Trend3M.up, distHiPct: 1.9, distLoPct: 30), 3);
      expect(proximityPoints(trend: Trend3M.up, distHiPct: 4.9, distLoPct: 30), 2);
      expect(proximityPoints(trend: Trend3M.up, distHiPct: 9.9, distLoPct: 30), 1);
      expect(proximityPoints(trend: Trend3M.up, distHiPct: 25, distLoPct: 30), 0.5);
      // Down trends measure against the low instead.
      expect(proximityPoints(trend: Trend3M.down, distHiPct: 40, distLoPct: 1), 3);
      expect(proximityPoints(trend: Trend3M.sideways, distHiPct: 1, distLoPct: 1), 0.5);
    });

    test('IV points follow the edge, with the expensive-IV penalty', () {
      expect(ivPointsFor(edgePct: null, avgIv: null, hasIv: false), 1.5);
      expect(ivPointsFor(edgePct: 1.4, avgIv: 20, hasIv: true), 3);
      expect(ivPointsFor(edgePct: 0.6, avgIv: 20, hasIv: true), 2.5);
      expect(ivPointsFor(edgePct: 0.1, avgIv: 20, hasIv: true), 2);
      expect(ivPointsFor(edgePct: -0.2, avgIv: 20, hasIv: true), 1);
      expect(ivPointsFor(edgePct: -0.9, avgIv: 20, hasIv: true), 0.5);
      // Above 55 % IV the option is expensive no matter how good the edge looks.
      expect(ivPointsFor(edgePct: 1.4, avgIv: 56, hasIv: true), 2);
      expect(ivPointsFor(edgePct: 0.6, avgIv: 60, hasIv: true), 1.5);
      expect(ivPointsFor(edgePct: -0.9, avgIv: 90, hasIv: true), 0);
    });

    test('score is clamped to 0–12', () {
      expect(
        (consistencyPoints(Trend3M.strongUp, 3, 0) +
                magnitudePoints(200) +
                proximityPoints(trend: Trend3M.strongUp, distHiPct: 0, distLoPct: 60) +
                ivPointsFor(edgePct: 5, avgIv: 10, hasIv: true))
            .clamp(0.0, 12.0),
        12,
      );
    });
  });

  group('options: IV, edge and the ATM pair', () {

    /// The pair that was ATM **kal** — strike 150, i.e. the stock has moved up
    /// since the previous close (the user's ALKEM case).

    test('avg IV feeds the edge, which feeds the score', () {
      final row = computeOrFail(bars: ramp(63), options: atmInput());

      expect(row.atmStrike, 160);
      expect(row.expiryLabel, '24APR2025');
      expect(row.daysToExpiry, 34); // 21 Mar → 24 Apr
      expect(row.lotSize, 75);
      expect(row.avgIv, closeTo(20, 1e-9));
      expect(row.implied1dPct, closeTo(20 / math.sqrt(252), 1e-9));

      // ATR % 0.617 is *below* IV's daily share (1.26) → negative edge.
      expect(
        row.edgePct,
        closeTo(row.atrPct - 20 / math.sqrt(252), 1e-9),
      );
      expect(row.edgePct!, lessThan(0));
      expect(row.ivSource, IvSource.broker);
      expect(row.score, closeTo(9.5, 1e-9)); // 3 + 3 + 3 + 0.5
      expect(row.hasTradeablePair, isTrue);
    });

    test('straddle: LTP sum and "agar kal jodi buy ki hoti"', () {
      final input = atmInput();
      final row = computeOrFail(
        bars: ramp(63),
        options: input,
        yesterdayOptions: input, // strike did not move: same pair
      );

      expect(row.straddleLtp, closeTo(13, 1e-9)); // 8 + 5 today
      final pnl = row.straddleYesterday!;
      expect(pnl.points, closeTo(2.5, 1e-9)); // 13 − (6.5 + 4)
      expect(pnl.rupees, closeTo(187.5, 1e-9)); // × 75 lot
      expect(pnl.complete, isTrue);
    });

    test('the kal jodi is priced on the kal wale strike, not today\'s', () {
      // Stock moved 150 → 160 since the last close: today's ATM is 160, but the
      // jodi a trader could have bought yesterday was 150.
      final row = computeOrFail(
        bars: ramp(63),
        options: atmInput(), // 160, ltp 8/5, close 6.5/4
        yesterdayOptions: kalInput(), // 150, ltp 21/4, close 6/9
      );

      expect(row.atmStrike, 160);
      expect(row.kalStrike, 150, reason: 'kal ka ATM strike');
      expect(row.kalJodiBase, closeTo(15, 1e-9)); // 6 + 9 (kal ka buy value)
      expect(row.kalJodiNow, closeTo(25, 1e-9)); // 21 + 4 (aaj ki value)
      final pnl = row.straddleYesterday!;
      expect(pnl.points, closeTo(10, 1e-9), reason: '25 − 15, NOT today\'s pair');
      expect(pnl.rupees, closeTo(750, 1e-9)); // × 75

      // …and the today's-pair numbers stay what they are.
      expect(row.straddleLtp, closeTo(13, 1e-9));
    });

    test('without the kal pair there is no yesterday line (never a wrong one)',
        () {
      final row = computeOrFail(
        bars: ramp(63),
        options: atmInput(cePrev: 6.5, pePrev: 4),
      );

      expect(row.kalStrike, isNull);
      expect(row.hasKalJodi, isFalse);
      expect(row.straddleYesterday, isNull);
      expect(row.straddleLtp, closeTo(13, 1e-9)); // today's data untouched
    });

    test('no previous close → no yesterday P&L, but the row survives', () {
      final row = computeOrFail(
        bars: ramp(63),
        options: atmInput(),
        yesterdayOptions: atmInput(cePrev: 0, pePrev: 0),
      );

      expect(row.straddleLtp, closeTo(13, 1e-9));
      expect(row.straddleYesterday, isNull);
      expect(row.isBestBuy, isFalse); // tag not applied yet — rankStudy does it
      expect(row.avgIv, closeTo(20, 1e-9)); // IV still present: degraded only
    });

    test('one missing leg keeps the IV that did arrive', () {
      final row = computeOrFail(
        bars: ramp(63),
        options: StudyOptionInput(
          strike: 160,
          expiryLabel: '24APR2025',
          expiryDate: DateTime(2025, 4, 24),
          lotSize: 75,
          ce: StudyOptionLeg(
            strike: 160,
            type: OptionType.call,
            token: '111',
            symbol: 'TEST24APR160CE',
            ltp: 8,
            previousClose: 6.5,
            iv: 30,
            ivSource: IvSource.blackScholes,
          ),
        ),
      );

      expect(row.avgIv, closeTo(30, 1e-9));
      expect(row.ivSource, IvSource.blackScholes);
      expect(row.pe, isNull);
      expect(row.hasTradeablePair, isFalse);
    });

    test('no option data at all → degraded, not dropped', () {
      final row = computeOrFail(bars: ramp(63));

      expect(row.atmStrike, isNull);
      expect(row.avgIv, isNull);
      expect(row.edgePct, isNull);
      expect(row.lotSize, 0);
      expect(row.score, closeTo(10.5, 1e-9)); // trend maths intact
    });
  });

  group('universe pass: IV rank, tags, ranking', () {
    test('IV rank splits the universe into thirds', () {
      final rows = [
        computeOrFail(bars: ramp(63), symbol: 'CHEAP')
            .copyWith(avgIv: 12),
        computeOrFail(bars: ramp(63), symbol: 'MIDDLE')
            .copyWith(avgIv: 24),
        computeOrFail(bars: ramp(63), symbol: 'RICH')
            .copyWith(avgIv: 40),
      ];

      final ranked = assignIvRank(rows);
      expect(ranked[0].ivRank, IvRank.low);
      expect(ranked[1].ivRank, IvRank.medium);
      expect(ranked[2].ivRank, IvRank.high);
    });

    test('rows without IV get the unknown rank and are not dropped', () {
      final rows = [
        computeOrFail(bars: ramp(63), symbol: 'NOIV'),
        computeOrFail(bars: ramp(63), symbol: 'HASIV').copyWith(avgIv: 20),
      ];
      final ranked = assignIvRank(rows);
      expect(ranked.firstWhere((r) => r.symbol == 'NOIV').ivRank,
          IvRank.unknown);
      expect(ranked.length, 2);
    });

    test('tags: best buy on cheap IV, watch when expensive, dash sideways', () {
      final up = computeOrFail(bars: ramp(63), symbol: 'UP');
      final flat = computeOrFail(bars: ramp(63, step: 0), symbol: 'FLAT');

      // Cheap IV with a non-negative edge → Best Buy.
      final best = applyOpportunity(
        up.copyWith(ivRank: IvRank.low, avgIv: 12, edgePct: 0.4, score: 11),
      );
      expect(best.isBestBuy, isTrue);
      expect(best.opportunityTag, contains('BUY CE'));
      expect(best.opportunityTag, contains('IV sasta'));
      expect(best.reason, isNotEmpty);

      // Expensive IV → Watch, and the tag says why.
      final watch = applyOpportunity(
        up.copyWith(ivRank: IvRank.high, avgIv: 60, score: 6),
      );
      expect(watch.isBestBuy, isFalse);
      expect(watch.opportunityTag, startsWith('⏸ Watch'));
      expect(watch.opportunityTag, contains('mehenga'));

      // Sideways → no trade suggestion at all.
      final sideways = applyOpportunity(flat.copyWith(score: 3));
      expect(sideways.opportunityTag, '-');
      expect(sideways.trend, Trend3M.sideways);
    });

    test('ranking puts best buys first, then score, and numbers the rows', () {
      final a = computeOrFail(bars: ramp(63), symbol: 'ALPHA') // strong up
          .copyWith(score: 9.0);
      final b = computeOrFail(bars: ramp(63, base: 200, step: -1), symbol: 'BETA')
          .copyWith(score: 10.5);
      final c = computeOrFail(bars: ramp(63, step: 0), symbol: 'GAMMA')
          .copyWith(score: 2.0);

      final ranked = rankStudy([a, b, c]);

      expect(ranked.map((r) => r.symbol).toList(), ['BETA', 'ALPHA', 'GAMMA']);
      expect(ranked.map((r) => r.rank).toList(), [1, 2, 3]);
    });

    test('a best buy outranks a higher score', () {
      // IV rank is computed across the universe, so three priced rows are
      // needed before the cheapest one counts as "low IV".
      final cheap = computeOrFail(bars: ramp(63), symbol: 'CHEAP')
          .copyWith(avgIv: 10, edgePct: 1.0, score: 6);
      final mid = computeOrFail(bars: ramp(63), symbol: 'MID')
          .copyWith(avgIv: 20, edgePct: 0.2, score: 6);
      final rich = computeOrFail(bars: ramp(63), symbol: 'RICH')
          .copyWith(avgIv: 40, edgePct: -1.0, score: 6);
      final strong = computeOrFail(bars: ramp(63), symbol: 'STRONG')
          .copyWith(score: 11);

      final ranked = rankStudy([strong, rich, mid, cheap]);

      expect(ranked.first.symbol, 'CHEAP');
      expect(ranked.first.isBestBuy, isTrue);
      expect(ranked.first.rank, 1);
      // Then score order: the highest score next, and the two tied rows by
      // symbol (stable — a scan never shuffles equal rows).
      expect(ranked.map((r) => r.symbol).toList(),
          ['CHEAP', 'STRONG', 'MID', 'RICH']);
    });

    test('empty input is safe', () {
      expect(rankStudy(const []), isEmpty);
    });
  });

  // -------------------------------------------------------------------
  group('time base (guard against the wrong-strike class of bug)', () {
    // The jodi bug was a *time-base* mix-up: a number from one day compared
    // against a number from another. These tests pin the invariant for every
    // other quantity, so the same class cannot sneak back in silently.

    test('edge is built from the same row\'s ATR% and IV — nothing else', () {
      final row = computeOrFail(bars: ramp(63), options: atmInput());

      expect(row.avgIv, isNotNull);
      expect(
        row.implied1dPct,
        closeTo(row.avgIv! / math.sqrt(kTradingDaysPerYear), 1e-9),
      );
      expect(
        row.edgePct,
        closeTo(row.atrPct - row.implied1dPct!, 1e-9),
        reason: 'edge = today\'s ATR% − today\'s IV/√252; if either side ever '
            'came from a different day this identity breaks',
      );
      expect(row.atrPct, closeTo(row.atr / row.ltp * 100, 1e-9));
    });

    test('buy/sell suggestion never touches option data', () {
      final bars = ramp(63);
      final withOptions = computeOrFail(
        bars: bars,
        options: atmInput(),
        yesterdayOptions: kalInput(),
      );
      final without = computeOrFail(bars: bars);

      // The recommendation is price-only (spec §2.5) — a broken option leg can
      // never change it.
      expect(without.trend, withOptions.trend);
      expect(without.suggested, withOptions.suggested);
      expect(without.total3mPct, withOptions.total3mPct);
      expect(without.upMonths, withOptions.upMonths);
      expect(without.consistencyPoints, withOptions.consistencyPoints);
      expect(without.magnitudePoints, withOptions.magnitudePoints);
      expect(without.proximityPoints, withOptions.proximityPoints);

      // …and the option-only factor (ivPoints) is the only one that differs.
      expect(without.ivPoints, 1.5, reason: 'neutral when IV is missing');
      expect(withOptions.ivPoints, isNot(1.5));
    });

    test('CMP and both strikes come from their own day\'s close', () {
      // Bars end at 162 (ramp 100…162). "Today" is that bar, "kal" is 161.
      final row = computeOrFail(
        bars: ramp(63), // 100 … 162
        options: atmInput(), // 160 (nearest to 162)
        yesterdayOptions: StudyOptionInput(
          strike: 150, // nearest to kal ka close, far from today's
          expiryLabel: '24APR2025',
          expiryDate: DateTime(2025, 4, 24),
          lotSize: 75,
          ce: StudyOptionLeg(
            strike: 150,
            type: OptionType.call,
            token: '201',
            symbol: 'TEST24APR150CE',
            ltp: 21,
            previousClose: 6,
          ),
          pe: StudyOptionLeg(
            strike: 150,
            type: OptionType.put,
            token: '202',
            symbol: 'TEST24APR150PE',
            ltp: 4,
            previousClose: 9,
          ),
        ),
      );

      expect(row.ltp, closeTo(162, 1e-9), reason: 'CMP = last bar close');
      expect(row.atmStrike, 160, reason: 'aaj ka ATM, aaj ke CMP se');
      expect(row.kalStrike, 150, reason: 'kal ka ATM, kal ke close se');
      expect(row.ce!.strike, 160);
      expect(row.kalCe!.strike, 150);
    });

    test('the old (wrong) formula can never come back', () {
      final row = computeOrFail(
        bars: ramp(63),
        options: atmInput(ceLtp: 8, cePrev: 6.5, peLtp: 5, pePrev: 4),
        yesterdayOptions: kalInput(ceLtp: 21, cePrev: 6, peLtp: 4, pePrev: 9),
      );

      final right = row.straddleYesterday!.points; // 25 − 15
      final oldWrong = row.straddleLtp! - row.kalJodiBase!; // 13 − 15

      expect(right, closeTo(10, 1e-9));
      expect(oldWrong, closeTo(-2, 1e-9),
          reason: 'this is the loss-everywhere number users were seeing');
      expect(right, isNot(closeTo(oldWrong, 1e-9)));

      // The invariants that make it right:
      expect(row.straddleYesterday!.points,
          closeTo(row.kalJodiNow! - row.kalJodiBase!, 1e-9));
      expect(row.hasKalJodi, isTrue);
      expect(row.kalCe!.token, '101', reason: 'kal wali legs, not today\'s');
    });
  });

  group('snapshot JSON', () {
    test('a ranked row survives a round trip', () {
      final row = rankStudy([
        computeOrFail(
          bars: ramp(63),
          symbol: 'RELIANCE',
          options: StudyOptionInput(
            strike: 160,
            expiryLabel: '24APR2025',
            expiryDate: DateTime(2025, 4, 24),
            lotSize: 75,
            ce: StudyOptionLeg(
              strike: 160,
              type: OptionType.call,
              token: '111',
              symbol: 'RELIANCE24APR160CE',
              ltp: 8,
              previousClose: 6.5,
              iv: 18,
              ivSource: IvSource.broker,
            ),
            pe: StudyOptionLeg(
              strike: 160,
              type: OptionType.put,
              token: '112',
              symbol: 'RELIANCE24APR160PE',
              ltp: 5,
              previousClose: 4,
              iv: 22,
              ivSource: IvSource.blackScholes,
            ),
          ),
          yesterdayOptions: StudyOptionInput(
            strike: 150,
            expiryLabel: '24APR2025',
            expiryDate: DateTime(2025, 4, 24),
            lotSize: 75,
            ce: StudyOptionLeg(
              strike: 150,
              type: OptionType.call,
              token: '101',
              symbol: 'RELIANCE24APR150CE',
              ltp: 21,
              previousClose: 6,
            ),
            pe: StudyOptionLeg(
              strike: 150,
              type: OptionType.put,
              token: '102',
              symbol: 'RELIANCE24APR150PE',
              ltp: 4,
              previousClose: 9,
            ),
          ),
        ),
      ]).single;

      final restored = StudyRow.fromJson(row.toJson());

      expect(restored.symbol, row.symbol);
      expect(restored.companyName, row.companyName);
      expect(restored.ltp, row.ltp);
      expect(restored.atr, row.atr);
      expect(restored.high3m, row.high3m);
      expect(restored.low3m, row.low3m);
      expect(restored.trend, row.trend);
      expect(restored.total3mPct, row.total3mPct);
      expect(restored.months.length, row.months.length);
      expect(restored.months.last.key, row.months.last.key);
      expect(restored.atmStrike, row.atmStrike);
      expect(restored.lotSize, row.lotSize);
      expect(restored.avgIv, row.avgIv);
      expect(restored.ivRank, row.ivRank);
      expect(restored.edgePct, row.edgePct);
      expect(restored.opportunityTag, row.opportunityTag);
      expect(restored.rank, row.rank);
      expect(restored.reason, row.reason);
      expect(restored.ce!.ivSource, row.ce!.ivSource);
      expect(restored.ce!.iv, row.ce!.iv);
      expect(restored.pe!.ivSource, row.pe!.ivSource);
      expect(restored.ivSource, row.ivSource);
      expect(restored.straddleYesterday!.rupees,
          closeTo(row.straddleYesterday!.rupees, 1e-9));
      // The kal wale strike survives the snapshot too — without it a reopened
      // app would fall back to "kal ka data nahi" and the wrong-strike bug
      // would come back on every reload.
      expect(restored.kalStrike, 150);
      expect(restored.kalJodiBase, closeTo(15, 1e-9));
      expect(restored.kalJodiNow, closeTo(25, 1e-9));
      expect(restored.straddleYesterday!.points, closeTo(10, 1e-9));
    });
  });

  group('avg range (High − Low)', () {
    List<Candle> rangedBars(int count, double Function(int) rangeAt) {
      final bars = <Candle>[];
      for (var i = 0; i < count; i++) {
        final r = rangeAt(i);
        bars.add(Candle(
          time: kEnd.subtract(Duration(days: count - 1 - i)),
          open: 100,
          high: 100 + r / 2,
          low: 100 - r / 2,
          close: 100,
          volume: 1000,
        ));
      }
      return bars;
    }

    test('simple mean of the last 14 (High − Low); gaps never counted', () {
      // 20 bars with ranges 1..20 — only the last 14 (7..20) count: 13.5.
      final bars = rangedBars(20, (i) => (i + 1).toDouble());
      expect(avgHighLow(bars), closeTo(13.5, 1e-9));
    });

    test('fewer than 14 bars is an honest 0, never a fake average', () {
      expect(avgHighLow(rangedBars(13, (i) => 5)), 0);
    });

    test('computeStudy carries it and the frozen snapshot keeps it', () {
      // Every session exactly ₹4 wide, close ₹100 → ₹4.00 / 4.00%.
      final row = computeOrFail(bars: rangedBars(63, (i) => 4));
      expect(row.avgRange, closeTo(4, 1e-9));
      expect(row.avgRangePct, closeTo(4, 1e-9));

      final restored = StudyRow.fromJson(row.toJson());
      expect(restored.avgRange, closeTo(4, 1e-9));
      expect(restored.avgRangePct, closeTo(4, 1e-9));
    });
  });
}
