// ---------------------------------------------------------------------------
// black_scholes_test.dart — the option maths underneath the F&O study.
//
// Three things must hold before any IV number reaches the table:
//
//   1. put-call parity (C − P = S − K·e^(−rT)) — a closed-form check on the
//      pricing function that needs no reference table,
//   2. solving IV from a premium reproduces the volatility it was priced with,
//   3. impossible premiums are *refused* with a reason instead of producing a
//      made-up volatility (spec §2.6: price data can be junk, the study must
//      not print nonsense because of it).
// ---------------------------------------------------------------------------

import 'dart:math' as math;

import 'package:angel_trader/features/fno/study/black_scholes.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  const spot = 1500.0;
  const strike = 1500.0;
  const days = 30;
  final t = days / 365;
  const rate = kRiskFreeRate;

  group('pricing', () {
    test('put-call parity holds to 1e-6', () {
      const vol = 0.28;
      final call = blackScholesPrice(
        OptionType.call,
        BsInput(spot: spot, strike: strike, timeToExpiryYears: t, volatility: vol),
      );
      final put = blackScholesPrice(
        OptionType.put,
        BsInput(spot: spot, strike: strike, timeToExpiryYears: t, volatility: vol),
      );
      final parity = spot - strike * math.exp(-rate * t);
      expect((call - put) - parity, closeTo(0, 1e-6));
    });

    test('expiry-day pricing is intrinsic value', () {
      expect(
        blackScholesPrice(
          OptionType.call,
          const BsInput(spot: 120, strike: 100, timeToExpiryYears: 0, volatility: 0.3),
        ),
        20,
      );
      expect(
        blackScholesPrice(
          OptionType.put,
          const BsInput(spot: 120, strike: 100, timeToExpiryYears: 0, volatility: 0.3),
        ),
        0,
      );
    });

    test('normalCdf is a distribution', () {
      expect(normalCdf(0), closeTo(0.5, 1e-9));
      expect(normalCdf(1.96), closeTo(0.975, 5e-4));
      expect(normalCdf(-10), closeTo(0, 1e-9));
      expect(normalCdf(10), closeTo(1, 1e-9));
    });

    test('greeks obey their identities', () {
      const vol = 0.3;
      const input = BsInput(
        spot: 1500,
        strike: 1500,
        timeToExpiryYears: 30 / 365,
        volatility: vol,
      );
      final call = blackScholesGreeks(OptionType.call, input);
      final put = blackScholesGreeks(OptionType.put, input);

      expect(call.delta - put.delta, closeTo(1.0, 1e-9)); // ΔC − ΔP = 1
      expect(call.gamma, closeTo(put.gamma, 1e-12));
      expect(call.delta, inInclusiveRange(0, 1));
      expect(put.delta, inInclusiveRange(-1, 0));
      expect(call.vegaPerPct, greaterThan(0));
    });
  });

  group('implied volatility', () {
    test('round-trips the volatility a premium was priced with', () {
      // ATM and near-OTM strikes where vega is large enough for the volatility to
      // be a real answer rather than a coincidence. (A deep-OTM 30-day call is
      // worth a few rupees here — under the junk-quote guard — so those cases
      // are covered by the test below instead.)
      for (final vol in [0.2, 0.35, 0.5, 0.75]) {
        for (final k in [1500.0, 1550.0, 1600.0]) {
          final premium = blackScholesPrice(
            OptionType.call,
            BsInput(spot: spot, strike: k, timeToExpiryYears: t, volatility: vol),
          );
          expect(premium, greaterThan(spot * 0.002));
          final solved = impliedVolatility(
            type: OptionType.call,
            premium: premium,
            spot: spot,
            strike: k,
            daysToExpiry: days,
          );
          expect(solved.isSolved, isTrue, reason: 'vol $vol strike $k');
          expect(solved.iv, closeTo(vol, 1e-4), reason: 'vol $vol strike $k');
        }
      }
    });

    test('every solved IV reprices the premium it was solved from', () {
      // This is the invariant that matters in production: whatever number comes
      // back, feeding it through the pricer must return the traded premium.
      // Deep ITM options fail to identify vol from price alone (vega ≈ 0), so
      // the contract is "reproduces the premium", not "recovers the true vol".
      for (final k in [1000.0, 1200.0, 1350.0, 1500.0, 1650.0, 1800.0, 2200.0]) {
        final premium = blackScholesPrice(
          OptionType.call,
          BsInput(spot: spot, strike: k, timeToExpiryYears: t, volatility: 0.3),
        );
        final solved = impliedVolatility(
          type: OptionType.call,
          premium: premium,
          spot: spot,
          strike: k,
          daysToExpiry: days,
        );
        if (premium < spot * 0.002) {
          // Far-OTM premium is junk by the spec's own definition — the study
          // must say "nahi mili", not solve a 300 % volatility out of noise.
          expect(solved.failure, IvFailure.tinyPremium, reason: 'strike \$k');
          continue;
        }
        expect(solved.isSolved, isTrue, reason: 'strike \$k');
        final repriced = blackScholesPrice(
          OptionType.call,
          BsInput(
            spot: spot,
            strike: k,
            timeToExpiryYears: t,
            volatility: solved.iv!,
          ),
        );
        expect(repriced, closeTo(premium, 1e-6 * premium + 1e-6),
            reason: 'strike $k');
      }
    });

    test('works for puts as well', () {
      const vol = 0.35;
      final premium = blackScholesPrice(
        OptionType.put,
        const BsInput(
          spot: 1500,
          strike: 1600,
          timeToExpiryYears: 45 / 365,
          volatility: vol,
        ),
      );
      final solved = impliedVolatility(
        type: OptionType.put,
        premium: premium,
        spot: 1500,
        strike: 1600,
        daysToExpiry: 45,
      );
      expect(solved.iv, closeTo(vol, 1e-4));
    });

    test('refuses bad inputs with a reason', () {
      // Expiry day: IV has no meaning (spec says skip).
      final expired = impliedVolatility(
        type: OptionType.call,
        premium: 12,
        spot: 1500,
        strike: 1500,
        daysToExpiry: 0,
      );
      expect(expired.isSolved, isFalse);
      expect(expired.failure, IvFailure.badInput);

      // Junk quote: under 0.2 % of spot.
      final tiny = impliedVolatility(
        type: OptionType.call,
        premium: 1.5,
        spot: 1500,
        strike: 1500,
        daysToExpiry: 20,
      );
      expect(tiny.failure, IvFailure.tinyPremium);

      // Below the discounted intrinsic: an impossible price for a 1500/1300
      // call (intrinsic ≈ 204.6 at r = 6.5 %).
      final arbitrage = impliedVolatility(
        type: OptionType.call,
        premium: 180,
        spot: 1500,
        strike: 1300,
        daysToExpiry: 20,
      );
      expect(arbitrage.failure, IvFailure.belowIntrinsic);

      // A premium no volatility up to 500 % can explain.
      final absurd = impliedVolatility(
        type: OptionType.put,
        premium: 480,
        spot: 1500,
        strike: 500,
        daysToExpiry: 20,
      );
      expect(absurd.isSolved, isFalse);
      expect(
        absurd.failure,
        anyOf(IvFailure.aboveRange, IvFailure.belowIntrinsic),
      );
    });

    test('never invents a confident volatility for an unidentifiable price', () {
      // Priced exactly at intrinsic → the honest outcomes are "outside the
      // accepted band" or a solved vol that reprices the premium. A confident
      // 20 % would be a lie.
      final premium = discountedIntrinsic(
        OptionType.call,
        const BsInput(
          spot: 1500,
          strike: 1000,
          timeToExpiryYears: 20 / 365,
          volatility: 0.2,
        ),
      );
      final solved = impliedVolatility(
        type: OptionType.call,
        premium: premium,
        spot: 1500,
        strike: 1000,
        daysToExpiry: 20,
      );
      if (solved.isSolved) {
        final repriced = blackScholesPrice(
          OptionType.call,
          BsInput(
            spot: 1500,
            strike: 1000,
            timeToExpiryYears: 20 / 365,
            volatility: solved.iv!,
          ),
        );
        expect(repriced, closeTo(premium, 1e-6 * premium + 1e-6));
      } else {
        expect(solved.failure, IvFailure.outOfAcceptedRange);
      }
    });
  });
}
