// Tests for the shared IVP/IVR chip model (1.5.57) — pure label + bucket.
// 1.5.69: ivMetricBoxes widget pins.
import 'package:angel_trader/features/fno/study/iv_sheet.dart';
import 'package:angel_trader/features/fno/study/iv_sheet_link.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('ivChip', () {
    test('both values missing → hidden (kind.none)', () {
      final (:label, :kind) = ivChip(null, null);
      expect(kind, IvChipKind.none);
      expect(label, isEmpty);
    });

    test('cheap (≤40) bucket', () {
      final (:label, :kind) = ivChip(32, 28);
      expect(kind, IvChipKind.cheap);
      expect(label, 'IVP 32 · IVR 28');
    });

    test('rich (≥70) bucket — warning only', () {
      expect(ivChip(72, 20).kind, IvChipKind.rich);
      expect(ivChip(10, 95).kind, IvChipKind.rich);
    });

    test('mid (41–69) bucket', () {
      final (:label, :kind) = ivChip(55, 60);
      expect(kind, IvChipKind.mid);
      expect(label, 'IVP 55 · IVR 60');
    });

    test('ek value missing to doosri decide karti hai, dash dikhta hai', () {
      final (:label, :kind) = ivChip(80, null);
      expect(kind, IvChipKind.rich);
      expect(label, 'IVP 80 · IVR —');
      expect(ivChip(null, 25).kind, IvChipKind.cheap);
    });

    test('boundary: 40 cheap, 70 rich', () {
      expect(ivChip(40, 40).kind, IvChipKind.cheap);
      expect(ivChip(70, 70).kind, IvChipKind.rich);
    });
  });

  group('ivMetricBoxes (1.5.69 — study cards ke andar)', () {
    tearDown(() => IvSheetStore.instance.bySymbol = const {});

    testWidgets('sheet values → labelled IVP + IVR boxes (rounded)', (tester) async {
      IvSheetStore.instance.bySymbol = {
        'TEST': const IvSheetRow(ivp: 32, ivr: 28.4),
      };
      await tester.pumpWidget(MaterialApp(
        home: Scaffold(
          body: Row(
            children: [for (final w in ivMetricBoxes('TEST')) Expanded(child: w)],
          ),
        ),
      ));
      expect(find.text('IVP'), findsOneWidget);
      expect(find.text('IVR'), findsOneWidget);
      expect(find.text('32'), findsOneWidget);
      expect(find.text('28'), findsOneWidget);
    });

    testWidgets('sheet me value na ho to — (boxes hide nahi hote)', (tester) async {
      IvSheetStore.instance.bySymbol = const {};
      await tester.pumpWidget(MaterialApp(
        home: Scaffold(
          body: Row(
            children: [for (final w in ivMetricBoxes('MISSING')) Expanded(child: w)],
          ),
        ),
      ));
      expect(find.text('IVP'), findsOneWidget);
      expect(find.text('IVR'), findsOneWidget);
      expect(find.text('—'), findsNWidgets(2));
    });
  });
}
