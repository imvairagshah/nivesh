import 'package:angel_trader/features/fno/study/ai_jodi_engine.dart';
import 'package:angel_trader/features/fno/study/study_engine.dart' show IvRank;
import 'package:flutter_test/flutter_test.dart';

/// The AI Jodi Study rules, pinned exactly as decided with the user
/// (25 Oct 2026): 15-din average-daily-move > ATR, month me 20%+ range
/// "mostly" (≥2/3), movement jodi ke daam se zyada, and the 2×-cover verdict
/// (ATM preferred while ample, else OTM, else skip). Long pairs only.
void main() {
  AiJodiInput input({
    double ltp = 1000,
    double atr = 20,
    double avgDailyMove15 = 30,
    List<double> monthlyRangePcts = const [25, 22, 21],
    double? atmJodiPrice = 60,
    double? otmJodiPrice = 30,
    bool isManual = false,
  }) => AiJodiInput(
        symbol: 'TECH',
        companyName: 'Tech Example Limited',
        ltp: ltp,
        atr: atr,
        avgDailyMove15: avgDailyMove15,
        monthlyRangePcts: monthlyRangePcts,
        atmJodiPrice: atmJodiPrice,
        otmJodiPrice: otmJodiPrice,
        isManual: isManual,
      );

  group('AiJodiEngine gates', () {
    test('gate 1: 15-din average daily move must beat ATR', () {
      final fast = AiJodiEngine.analyze(input(avgDailyMove15: 31, atr: 30));
      expect(fast.gate15, isTrue);

      final slow = AiJodiEngine.analyze(input(avgDailyMove15: 29, atr: 30));
      expect(slow.gate15, isFalse);

      // Equal is not "zyada" — strictly greater.
      final equal = AiJodiEngine.analyze(input(avgDailyMove15: 30, atr: 30));
      expect(equal.gate15, isFalse);
    });

    test('gate 2: 20%+ monthly range in most months (≥2 of 3)', () {
      final mostly = AiJodiEngine.analyze(
        input(monthlyRangePcts: [21, 20, 5]),
      );
      expect(mostly.gateMonth, isTrue);
      expect(mostly.monthsMeeting20, 2);

      final once = AiJodiEngine.analyze(
        input(monthlyRangePcts: [30, 6, 4]),
      );
      expect(once.gateMonth, isFalse);

      // A 19.9% month does not count — the floor is 20.
      final near = AiJodiEngine.analyze(
        input(monthlyRangePcts: [19.9, 20, 20]),
      );
      expect(near.monthsMeeting20, 2);
      expect(near.gateMonth, isTrue);
    });

    test('gate 3: typical monthly ₹ move must beat the jodi price', () {
      // ltp 1000, median range 22% → move ≈ ₹220 — beats both prices.
      final cheap = AiJodiEngine.analyze(input());
      expect(cheap.gateJodi, isTrue);
      expect(cheap.typicalMoveRupee, closeTo(220, 0.1));

      // Jodi mehngi: move ₹220 < ₹300.
      final dear = AiJodiEngine.analyze(
        input(atmJodiPrice: 300, otmJodiPrice: 300),
      );
      expect(dear.gateJodi, isFalse);
    });

    test('unpriced jodi is honest: no price, never a guess', () {
      final none = AiJodiEngine.analyze(
        input(atmJodiPrice: null, otmJodiPrice: null),
      );
      expect(none.verdict, AiJodiVerdict.noPrice);
      expect(none.gateJodi, isFalse);
    });
  });

  group('AiJodiEngine verdict', () {
    test('ample movement → ATM jodi (straddle) preferred', () {
      // move ₹220 covers ATM ₹60 ≈ 3.7× ≥ 2 → ATM.
      final result = AiJodiEngine.analyze(input());
      expect(result.verdict, AiJodiVerdict.atmBuy);
    });

    test('moderate movement → OTM jodi (strangle)', () {
      // move ₹220 vs ATM ₹130 ≈ 1.7× (below 2), OTM ₹90 ≈ 2.4× → OTM.
      final result = AiJodiEngine.analyze(
        input(atmJodiPrice: 130, otmJodiPrice: 90),
      );
      expect(result.verdict, AiJodiVerdict.otmBuy);
    });

    test('movement below 2× either pair → skip', () {
      final result = AiJodiEngine.analyze(
        input(atmJodiPrice: 130, otmJodiPrice: 130),
      );
      expect(result.verdict, AiJodiVerdict.skip);
    });
  });

  group('AiJodiEngine.rank', () {
    test('auto list keeps only all-gate passers; manual rows always show', () {
      final rows = [
        // Passes everything (ATM 3.7×).
        input(),
        // Fails gate 1.
        input(avgDailyMove15: 5, monthlyRangePcts: [1, 1, 1], atmJodiPrice: 10, otmJodiPrice: 5),
        // Manual — fails gates but the user pinned it.
        input(isManual: true, avgDailyMove15: 5, monthlyRangePcts: [1, 1, 1], atmJodiPrice: 10, otmJodiPrice: 5),
      ];
      // Make the symbols distinct so the test reads clearly.
      final named = [
        for (var i = 0; i < rows.length; i++)
          AiJodiInput(
            symbol: 'S$i',
            companyName: rows[i].companyName,
            ltp: rows[i].ltp,
            atr: rows[i].atr,
            avgDailyMove15: rows[i].avgDailyMove15,
            monthlyRangePcts: rows[i].monthlyRangePcts,
            atmJodiPrice: rows[i].atmJodiPrice,
            otmJodiPrice: rows[i].otmJodiPrice,
            isManual: rows[i].isManual,
          ),
      ];
      final listed = AiJodiEngine.rank(named);
      expect(listed, hasLength(2));
      expect(listed.map((r) => r.input.symbol), containsAll(['S0', 'S2']));
    });

    test('better coverage ranks first', () {
      final listed = AiJodiEngine.rank([
        // move 220 / ATM 110 = 2×
        input(atmJodiPrice: 110, otmJodiPrice: 55),
        // move 220 / ATM 55 = 4×
        input(atmJodiPrice: 55, otmJodiPrice: 27),
      ]);
      expect(listed.first.result.coverAtm, closeTo(4, 0.1));
    });
  });

  group('AiJodiEngine.topList — the "20 best" output', () {
    AiJodiInput named(
      String symbol, {
      double ltp = 1000,
      double atr = 20,
      double avgDailyMove15 = 30,
      List<double> monthlyRangePcts = const [25, 22, 21],
      double? atmJodiPrice = 60,
      double? otmJodiPrice = 30,
      bool isManual = false,
    }) => AiJodiInput(
          symbol: symbol,
          companyName: '$symbol Ltd',
          ltp: ltp,
          atr: atr,
          avgDailyMove15: avgDailyMove15,
          monthlyRangePcts: monthlyRangePcts,
          atmJodiPrice: atmJodiPrice,
          otmJodiPrice: otmJodiPrice,
          isManual: isManual,
        );

    test('gate-passers lead, priced near-misses fill up to the limit', () {
      final listed = AiJodiEngine.topList(
        [
          // Passes everything, cover 220/60 ≈ 3.7×.
          named('PASS'),
          // Fails gate 1 but is priced: fill candidate (cover 220/110 = 2×).
          named('FILL', avgDailyMove15: 5),
          // No jodi price at all — never listed.
          named('NOPRICE', atmJodiPrice: null, otmJodiPrice: null),
        ],
        limit: 20,
      );
      expect(listed.map((r) => r.input.symbol).toList(), ['PASS', 'FILL']);
    });

    test('auto rows are capped at 20; manual rows survive the cap', () {
      final inputs = [
        for (var i = 0; i < 25; i++)
          named('A$i', atmJodiPrice: 50 + i.toDouble(), otmJodiPrice: 25),
        named('MINE', avgDailyMove15: 5, monthlyRangePcts: [1, 1, 1], isManual: true),
      ];
      final listed = AiJodiEngine.topList(inputs);
      final autos = listed.where((r) => !r.input.isManual).toList();
      expect(autos, hasLength(20));
      expect(listed.any((r) => r.input.symbol == 'MINE'), isTrue);
    });

    test('the best coverage is first in the output too', () {
      final listed = AiJodiEngine.topList([
        named('SLOW', atmJodiPrice: 110, otmJodiPrice: 55),
        named('FAST', atmJodiPrice: 55, otmJodiPrice: 27),
      ]);
      expect(listed.first.input.symbol, 'FAST');
    });
  });

  group('AiJodiEngine detail helpers', () {
    test('straddle break-evens: strike ± total premium', () {
      // ATM ₹1000, pair premium ₹60 → BE 940 / 1060.
      final be = AiJodiEngine.jodiBreakEvens(
        lowerStrike: 1000,
        upperStrike: 1000,
        totalPremium: 60,
      );
      expect(be.lower, 940);
      expect(be.upper, 1060);
    });

    test('strangle break-evens: PE strike − and CE strike + premium', () {
      // PE 950 / CE 1050, pair ₹40 → BE 910 / 1090.
      final be = AiJodiEngine.jodiBreakEvens(
        lowerStrike: 950,
        upperStrike: 1050,
        totalPremium: 40,
      );
      expect(be.lower, 910);
      expect(be.upper, 1090);
    });

    test('kal jodi P&L: now − buy cost, in ₹ and %', () {
      final pnl = AiJodiEngine.kalJodiPnl(buyCost: 100, nowValue: 112.5);
      expect(pnl, isNotNull);
      expect(pnl!.rupees, closeTo(12.5, 0.01));
      expect(pnl.pct, closeTo(12.5, 0.01));

      final loss = AiJodiEngine.kalJodiPnl(buyCost: 100, nowValue: 90);
      expect(loss!.rupees, closeTo(-10, 0.01));

      // Missing numbers stay missing — never a guess.
      expect(AiJodiEngine.kalJodiPnl(buyCost: null, nowValue: 50), isNull);
      expect(AiJodiEngine.kalJodiPnl(buyCost: 100, nowValue: null), isNull);
      expect(AiJodiEngine.kalJodiPnl(buyCost: 0, nowValue: 50), isNull);
    });

    test('IV star: cheap IV is the star, dear IV is the warning', () {
      expect(
        AiJodiEngine.ivStarLabel(IvRank.low),
        contains('⭐'),
      );
      expect(
        AiJodiEngine.ivStarLabel(IvRank.high),
        contains('⚠️'),
      );
      expect(AiJodiEngine.ivStarLabel(IvRank.unknown), contains('nahi'));
    });
  });

  group('JodiTableOps (1.5.55 table controls)', () {
    AiJodiInput input(String symbol, double ltp) => AiJodiInput(
          symbol: symbol,
          companyName: symbol,
          ltp: ltp,
          atr: 1,
          avgDailyMove15: 5,
          monthlyRangePcts: const [25, 25, 25],
          atmJodiPrice: 2,
          otmJodiPrice: 1.5,
        );

    JodiRow row(String symbol, double ltp, {double? coverAtm, double? coverOtm}) {
      JodiRow make(AiJodiVerdict verdict) => (
            input: input(symbol, ltp),
            result: AiJodiResult(
              gate15: true,
              gateMonth: true,
              gateJodi: true,
              monthsMeeting20: 3,
              typicalMoveRupee: 10,
              coverAtm: coverAtm,
              coverOtm: coverOtm,
              verdict: verdict,
            ),
          );
      // cover > 2 → buy verdict, else skip — mirrors the engine's banding
      // closely enough for filter/sort behaviour.
      final bestCover = [
        if (coverAtm != null) coverAtm,
        if (coverOtm != null) coverOtm,
      ];
      final verdict = bestCover.isEmpty || bestCover.every((c) => c < 2)
          ? AiJodiVerdict.skip
          : (coverAtm != null && coverAtm >= (coverOtm ?? 0))
              ? AiJodiVerdict.atmBuy
              : AiJodiVerdict.otmBuy;
      return make(verdict);
    }

    test('filter keeps only the requested verdict', () {
      final rows = [
        row('A', 100, coverAtm: 3, coverOtm: 2),
        row('B', 100, coverAtm: 1, coverOtm: 1),
      ];
      expect(JodiTableOps.filter(rows, JodiVerdictFilter.all), hasLength(2));
      expect(
        JodiTableOps.filter(rows, JodiVerdictFilter.atmBuy)
            .map((r) => r.input.symbol),
        ['A'],
      );
      expect(JodiTableOps.filter(rows, JodiVerdictFilter.skip).map((r) => r.input.symbol),
          ['B']);
    });

    test('sort by cover, price and kal change', () {
      final rows = [
        row('LOW', 50, coverAtm: 1.2),
        row('HIGH', 500, coverAtm: 3.5),
        row('MID', 200, coverAtm: 2.5),
      ];
      final byCover = JodiTableOps.sort(rows, JodiSortKey.coverPct);
      expect(byCover.map((r) => r.input.symbol), ['HIGH', 'MID', 'LOW']);
      final byPrice = JodiTableOps.sort(rows, JodiSortKey.price);
      expect(byPrice.map((r) => r.input.symbol), ['LOW', 'MID', 'HIGH']);
      final kal = {'LOW': 5.0, 'HIGH': -1.0};
      final byKal = JodiTableOps.sort(rows, JodiSortKey.kalChange,
          kalChangeOf: (s) => kal[s]);
      // 5.0 first, -1.0 next, null (MID) last.
      expect(byKal.map((r) => r.input.symbol), ['LOW', 'HIGH', 'MID']);
      final byRank = JodiTableOps.sort(rows, JodiSortKey.rank);
      expect(byRank.map((r) => r.input.symbol), ['LOW', 'HIGH', 'MID']);
    });
  });

  group('IVP/IVR Gate 4 (1.5.56)', () {
    AiJodiInput inp({
      String symbol = 'ABC',
      double? ivp,
      double? ivr,
      bool isManual = false,
      double atr = 20,
      double avgDailyMove15 = 22,
      List<double> monthlyRangePcts = const [45, 44, 43],
      double? atmJodiPrice = 10,
      double? otmJodiPrice = 12,
    }) =>
        AiJodiInput(
          symbol: symbol,
          companyName: '$symbol Ltd',
          ltp: 500,
          atr: atr,
          avgDailyMove15: avgDailyMove15,
          monthlyRangePcts: monthlyRangePcts,
          atmJodiPrice: atmJodiPrice,
          otmJodiPrice: otmJodiPrice,
          isManual: isManual,
          ivp: ivp,
          ivr: ivr,
        );

    test('input: effectiveIv = max present, null when both missing', () {
      expect(inp(ivp: 32, ivr: 55).effectiveIv, 55);
      expect(inp(ivp: 32).effectiveIv, 32);
      expect(inp(ivp: 32).ivCheap, isTrue);
      final none = inp();
      expect(none.effectiveIv, isNull);
      expect(none.ivCheap, isFalse);
      // cheap = har available value ≤ 40
      expect(inp(ivp: 32, ivr: 55).ivCheap, isFalse);
      expect(inp(ivp: 40, ivr: 40).ivCheap, isTrue);
    });

    test('rich IV (≥70) demotes non-manual buys to ivRich', () {
      final res = AiJodiEngine.analyze(inp(ivp: 72));
      expect(res.verdict, AiJodiVerdict.ivRich);
      expect(res.gateIv, isFalse);
      expect(res.passes, isFalse);
      expect(res.detail, contains('IV'));
      // doosre gates pass hue tabhi demote hota hai
      expect(res.gate15, isTrue);
      expect(res.gateMonth, isTrue);
    });

    test('rich IV sirf non-manual ko gate karta hai', () {
      final manual = AiJodiEngine.analyze(inp(ivp: 72, isManual: true));
      expect(manual.verdict, AiJodiVerdict.atmBuy);
      expect(manual.gateIv, isTrue);
      expect(manual.passes, isTrue);
      expect(manual.detail, contains('khud add'));
    });

    test('medium IV (41–69) buy nahi todta', () {
      final res = AiJodiEngine.analyze(inp(ivp: 55));
      expect(res.verdict, AiJodiVerdict.atmBuy);
      expect(res.gateIv, isTrue);
    });

    test('rich IV par skip verdict nahi badalta', () {
      final res = AiJodiEngine.analyze(
          inp(ivp: 90, atmJodiPrice: 500, otmJodiPrice: 500));
      expect(res.verdict, AiJodiVerdict.skip);
      expect(res.gateIv, isFalse);
    });

    test('cheap IV (≤40) topList me +0.5 score bonus deta hai', () {
      final rows = [
        for (var i = 0; i < 12; i++)
          inp(
            symbol: 'STK$i',
            // Sab passers hain (medium IV); STK8 hi cheap hai → bonus usse
            // cover-peer STK7 se upar laata hai (2.12+0.5 = 2.62 > 2.29).
            ivp: i == 8 ? 25 : 55,
            otmJodiPrice: 20 + i * 4, // cover 5.5, 5.0, … 2.29, 2.12, 1.96
          ),
      ];
      final top = AiJodiEngine.topList(rows);
      final idx8 = top.indexWhere((r) => r.input.symbol == 'STK8');
      final idx7 = top.indexWhere((r) => r.input.symbol == 'STK7');
      expect(idx8, isNot(-1));
      expect(idx8, lessThan(idx7),
          reason: 'cheap IV ko +0.5 score milta hai');
    });

    test('ivStarFromValues labels', () {
      expect(AiJodiEngine.ivStarFromValues(ivp: 30, ivr: 20), contains('⭐'));
      expect(AiJodiEngine.ivStarFromValues(ivp: 30, ivr: 20),
          contains('IVP 30 · IVR 20'));
      expect(AiJodiEngine.ivStarFromValues(ivp: 72, ivr: 20), contains('⚠️'));
      expect(AiJodiEngine.ivStarFromValues(ivp: 32, ivr: 55),
          startsWith('IV medium'));
      expect(AiJodiEngine.ivStarFromValues(ivp: 32), contains('IVP 32 · IVR —'));
      expect(AiJodiEngine.ivStarFromValues(), 'IV data nahi');
    });
  });
}
