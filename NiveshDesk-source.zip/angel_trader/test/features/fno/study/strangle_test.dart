// ---------------------------------------------------------------------------
// strangle_test.dart — the OTM jodi (strangle) picker.
//
// The user's rule, pinned here as code: "ATM CE+PE/2 ki sabse najdik jo strike
// hai wo wali" — the CE above the money and the PE below it whose *combined*
// premium is closest to half the ATM jodi's.
//
// Pinned on purpose:
//   • OTM only (a CE at or below spot, or a PE at or above it, is not a leg),
//   • symmetric pairing (the k-th strike up pairs with the k-th strike down),
//   • nearest-to-target wins, and the estimate is only used for ranking,
//   • no answer (null) when the chain/IV/expiry cannot support one — a null is
//     a fact, not a failure, and the UI says so.
// ---------------------------------------------------------------------------

import 'package:angel_trader/data/local/dao/fno_contract_dao.dart';
import 'package:angel_trader/features/fno/study/strangle.dart';
import 'package:flutter_test/flutter_test.dart';

/// A tiny chain around a 2,650 spot: strikes 2,500 … 2,800 in steps of 50,
/// both CE and PE at every strike.
List<FnoContract> _chain({
  double from = 2500,
  double to = 2800,
  double step = 50,
}) {
  final out = <FnoContract>[];
  for (var strike = from; strike <= to; strike += step) {
    out.add(_contract(strike, 'CE'));
    out.add(_contract(strike, 'PE'));
  }
  return out;
}

FnoContract _contract(double strike, String type) => FnoContract(
      id: strike.toInt() + (type == 'CE' ? 1 : 2),
      underlying: 'RELIANCE',
      expiryLabel: '26JAN2026',
      expiryDate: DateTime(2026, 1, 26),
      strike: strike,
      optionType: type,
      token: '${strike.toInt()}$type',
      symbol: 'RELIANCE26JAN${strike.toInt()}$type',
      lotSize: 500,
    );

void main() {
  const spot = 2650.0;
  const days = 30;

  test('both legs are OTM: CE above the money, PE below it', () {
    final pick = pickStrangle(
      chain: _chain(),
      spot: spot,
      ivPercent: 20,
      daysToExpiry: days,
      targetPremium: 60,
    );

    expect(pick, isNotNull);
    expect(pick!.ce.optionType, 'CE');
    expect(pick.pe.optionType, 'PE');
    expect(pick.ceStrike, greaterThan(spot));
    expect(pick.peStrike, lessThan(spot));
  });

  test('the pair is symmetric — the k-th strike up with the k-th strike down',
      () {
    // One strike away must be 2700 CE + 2600 PE; two strikes away 2750 + 2550.
    final near = pickStrangle(
      chain: _chain(),
      spot: spot,
      ivPercent: 20,
      daysToExpiry: days,
      targetPremium: 90,
    )!;
    expect(near.ceStrike - spot, spot - near.peStrike,
        reason: 'a strangle is quoted symmetrically around the money');
  });

  test('a cheaper target walks outward — OTM premiums fall as strikes widen',
      () {
    final chain = _chain();

    // An unreachable target pulls the picker to the richest pair it can build
    // (the strikes closest to the money)…
    final richest = pickStrangle(
      chain: chain,
      spot: spot,
      ivPercent: 20,
      daysToExpiry: days,
      targetPremium: 1e6,
    )!;
    // …and a near-zero target to the cheapest one (the deepest OTM pair).
    final cheapest = pickStrangle(
      chain: chain,
      spot: spot,
      ivPercent: 20,
      daysToExpiry: days,
      targetPremium: 1,
    )!;

    expect(cheapest.ceStrike, greaterThan(richest.ceStrike));
    expect(cheapest.peStrike, lessThan(richest.peStrike));
    expect(cheapest.estimatedPremium, lessThan(richest.estimatedPremium));
  });

  test('the pair whose premium is nearest the target wins', () {
    final chain = _chain();
    // The real-world case: half of the ATM jodi in the panel (42.50 + 38.40).
    const target = 40.45;

    final pick = pickStrangle(
      chain: chain,
      spot: spot,
      ivPercent: 20,
      daysToExpiry: days,
      targetPremium: target,
    )!;

    // Deepening the search can only bring the pick closer to the target, so the
    // full search (all three pairs in this chain) is the best of them all.
    var previousGap = double.infinity;
    for (var k = 1; k <= 3; k++) {
      final candidate = pickStrangle(
        chain: chain,
        spot: spot,
        ivPercent: 20,
        daysToExpiry: days,
        targetPremium: target,
        maxSteps: k,
      )!;
      final gap = (candidate.estimatedPremium - target).abs();
      expect(gap, lessThanOrEqualTo(previousGap + 1e-9),
          reason: 'depth $k must not do worse than depth ${k - 1}');
      previousGap = gap;
    }
    expect((pick.estimatedPremium - target).abs(),
        lessThanOrEqualTo(previousGap + 1e-9));
  });

  test('an estimate is only a ranking aid — it is not what gets displayed', () {
    // The picker returns contracts, not prices: the premium the user sees is
    // quoted from the broker afterwards. Nothing here invents a traded price.
    final pick = pickStrangle(
      chain: _chain(),
      spot: spot,
      ivPercent: 20,
      daysToExpiry: days,
      targetPremium: 40,
    )!;
    expect(pick.ce.lotSize, 500, reason: 'a real contract from the book');
    expect(pick.ce.token, isNotEmpty);
    expect(pick.estimatedPremium, greaterThan(0));
    expect(pick.targetPremium, 40);
  });

  test('no answer when the chain, the inputs or the expiry say so', () {
    // Nothing OTM on one side.
    final onlyCalls = [
      _contract(2700, 'CE'),
      _contract(2750, 'CE'),
    ];
    expect(
      pickStrangle(
        chain: onlyCalls,
        spot: spot,
        ivPercent: 20,
        daysToExpiry: days,
        targetPremium: 40,
      ),
      isNull,
      reason: 'a strangle needs both sides',
    );

    // Expiry today: premiums cannot be modelled, so no pair is offered.
    expect(
      pickStrangle(
        chain: _chain(),
        spot: spot,
        ivPercent: 20,
        daysToExpiry: 0,
        targetPremium: 40,
      ),
      isNull,
    );

    // No IV, or no ATM premium to halve.
    expect(
      pickStrangle(
        chain: _chain(),
        spot: spot,
        ivPercent: 0,
        daysToExpiry: days,
        targetPremium: 40,
      ),
      isNull,
    );
    expect(
      pickStrangle(
        chain: _chain(),
        spot: spot,
        ivPercent: 20,
        daysToExpiry: days,
        targetPremium: 0,
      ),
      isNull,
    );
  });
}
