// 1.5.86 — Stock OI Build–Unwind engine: UDiFF bhavcopy parsing, price×OI
// signal matrix, filters aur ranking. Sab pure functions — network nahi.

import 'package:angel_trader/features/fno/stock_oi/stock_oi_engine.dart';
import 'package:flutter_test/flutter_test.dart';

/// Real UDiFF FO header (jo NSE ki bhavcopy me hota hai).
const _header = 'TradDt,BizDt,Sgmt,Src,FinInstrmTp,FinInstrmAIS12,ISIN,'
    'TckrSymb,SctySrs,XpryDt,FininstrmActlXpryDt,StrkPric,OptnTp,FinInstrmNm,'
    'OpnPric,HghPric,LwPric,ClsPric,LastPric,PrvsClsgPric,UndrlygPric,'
    'SttlmPric,OpnIntrst,ChngInOpnIntrst,TtlTradgVol,TtlTrfVal,TtlNbOfTxsExctd,'
    'SsnId,NewBrdLotQty,Rmks,Rsvd01';

String row({
  required String symbol,
  required String type,
  required String opt,
  required double strike,
  required double oi,
  required double chg,
  required double close,
  required double prev,
  String expiry = '2026-11-26',
}) =>
    '2026-11-11,2026-11-11,FO,NSE,$type,${symbol}EQ,INE002A01018,$symbol,BE,'
    '$expiry,$expiry,$strike,$opt,$symbol${strike.toInt()}$opt,10,20,5,$close,'
    '$close,$prev,1500,0,$oi,$chg,1000,100,10,F1,250,,0';

String csv(List<String> rows) => [_header, ...rows].join('\n');

void main() {
  group('parser — UDiFF F&O bhavcopy', () {
    test('stock options parse hote hain, index/futures reject', () {
      final book = parseStockOptionOi(
        csv([
          // RELIANCE CE: price up + OI up → long buildup
          row(
              symbol: 'RELIANCE',
              type: 'STO',
              opt: 'CE',
              strike: 3000,
              oi: 120000,
              chg: 20000,
              close: 42,
              prev: 35),
          // RELIANCE PE: price down + OI down → long unwinding
          row(
              symbol: 'RELIANCE',
              type: 'STO',
              opt: 'PE',
              strike: 3000,
              oi: 90000,
              chg: -30000,
              close: 30,
              prev: 38),
          // Index option — reject
          row(
              symbol: 'BANKNIFTY',
              type: 'IDO',
              opt: 'CE',
              strike: 60100,
              oi: 500000,
              chg: 100000,
              close: 200,
              prev: 150),
          // Stock FUTURE — reject (options nahi)
          row(
              symbol: 'INFY',
              type: 'STF',
              opt: '',
              strike: 0,
              oi: 100000,
              chg: 5000,
              close: 1500,
              prev: 1490),
        ]),
        DateTime(2026, 11, 11),
      );

      expect(book.rowCount, 2);
      expect(book.symbols, ['RELIANCE']);
      expect(book.bySymbol['RELIANCE']!.legs, hasLength(2));

      final ce = book.bySymbol['RELIANCE']!
          .legs
          .firstWhere((l) => l.optionType == 'CE');
      expect(ce.strike, 3000);
      expect(ce.oi, 120000);
      expect(ce.oiChange, 20000);
      expect(ce.expiry, DateTime(2026, 11, 26));
      expect(ce.lotSize, 250);
      expect(ce.previousOi, 100000);
      expect(ce.oiChangePct, closeTo(20, 0.001));
      expect(ce.priceChangePct, closeTo(20, 0.001)); // 35 → 42
      expect(ce.signal, OiSignal.longBuildup);
    });

    test('khaali / galat CSV = khaali book (crash nahi)', () {
      expect(parseStockOptionOi('', DateTime(2026, 11, 11)).rowCount, 0);
      expect(
          parseStockOptionOi('a,b,c\n1,2,3', DateTime(2026, 11, 11)).rowCount, 0);
    });

    test('expiry formats — ISO aur 26NOV2026 dono', () {
      expect(parseOiDate('2026-11-26'), DateTime(2026, 11, 26));
      expect(parseOiDate('26-NOV-2026'), DateTime(2026, 11, 26));
      expect(parseOiDate('26NOV2026'), DateTime(2026, 11, 26));
      expect(parseOiDate('garbage'), isNull);
    });
  });

  group('signal matrix — price × OI', () {
    test('chaar quadrants + flat', () {
      // price up + OI up
      expect(classifySignal(priceChangePct: 2, oiChangePct: 15),
          OiSignal.longBuildup);
      // price down + OI up
      expect(classifySignal(priceChangePct: -2, oiChangePct: 15),
          OiSignal.shortBuildup);
      // price up + OI down
      expect(classifySignal(priceChangePct: 2, oiChangePct: -15),
          OiSignal.shortCovering);
      // price down + OI down
      expect(classifySignal(priceChangePct: -2, oiChangePct: -15),
          OiSignal.longUnwinding);
      // OI barely moved → flat
      expect(classifySignal(priceChangePct: 2, oiChangePct: 0.2), OiSignal.flat);
      // price barely moved, OI badha → flat (direction unknown)
      expect(classifySignal(priceChangePct: 0.01, oiChangePct: 40), OiSignal.flat);
    });

    test('build vs unwind helpers', () {
      expect(OiSignal.longBuildup.isBuild, isTrue);
      expect(OiSignal.shortBuildup.isBuild, isTrue);
      expect(OiSignal.shortCovering.isUnwind, isTrue);
      expect(OiSignal.longUnwinding.isUnwind, isTrue);
      expect(OiSignal.flat.isBuild, isFalse);
      expect(OiSignal.flat.isUnwind, isFalse);
    });
  });

  group('filters + ranking', () {
    StockOiSnapshot snap() {
      final exp = DateTime(2026, 11, 26);
      StockOiLeg leg(double strike, String type, double oi, double chg,
              double close, double prev) =>
          StockOiLeg(
            symbol: 'X',
            expiry: exp,
            strike: strike,
            optionType: type,
            oi: oi,
            oiChange: chg,
            close: close,
            previousClose: prev,
            lotSize: 100,
          );
      return StockOiSnapshot(
        symbol: 'X',
        tradeDate: DateTime(2026, 11, 11),
        legs: [
          // Bada qty build, chhota %
          leg(100, 'CE', 205000, 100000, 50, 40),
          // Chhota qty build, bada %
          leg(110, 'PE', 6000, 5000, 40, 50),
          // Unwind (OI ghata), bada qty
          leg(120, 'CE', 20000, -80000, 40, 50),
          // Noise — filter se bahar (OI chhota)
          leg(130, 'PE', 900, 400, 40, 39),
        ],
      );
    }

    test('Balanced filter — OI≥5000 aur |ΔOI%|≥10', () {
      final l = snap().forExpiry(DateTime(2026, 11, 26));
      final passed = l.where(OiFilter.balanced.passes).toList();
      expect(passed, hasLength(3)); // 900-OI noise bahar
      expect(OiFilter.all.passes(l.last), isTrue);
      expect(OiFilter.strict.passes(l.last), isFalse);
    });

    test('topBuilds — qty aur % sort dono', () {
      final s = snap();
      final exp = DateTime(2026, 11, 26);
      final byQty = s.topBuilds(
          expiry: exp, filter: OiFilter.balanced, sort: OiSort.byQty);
      expect(byQty.first.strike, 100); // +100000 qty
      final byPct = s.topBuilds(
          expiry: exp, filter: OiFilter.balanced, sort: OiSort.byPct);
      // 6000/1000 = 500% (prevOi 1000) → bahut bada %; 205000/105000 ≈ 95%
      expect(byPct.first.strike, 110);
    });

    test('topUnwinds — OI ghata wale strike', () {
      final s = snap();
      final unwinds = s.topUnwinds(
          expiry: DateTime(2026, 11, 26),
          filter: OiFilter.balanced,
          sort: OiSort.byQty);
      expect(unwinds, hasLength(1));
      expect(unwinds.first.strike, 120);
      expect(unwinds.first.oiChange, -80000);
    });

    test('summary — builds/unwinds count + net OI change', () {
      final s = snap();
      final sum = s.summary(DateTime(2026, 11, 26), OiFilter.balanced);
      expect(sum.builds, 2);
      expect(sum.unwinds, 1);
      expect(sum.netOiChange, 100000 + 5000 - 80000);
    });

    test('expiries + strikes sorted (dropdown ke liye)', () {
      final exp = DateTime(2026, 11, 26);
      final s = StockOiSnapshot(symbol: 'X', tradeDate: exp, legs: [
        StockOiLeg(
            symbol: 'X', expiry: DateTime(2026, 12, 24), strike: 100,
            optionType: 'CE', oi: 1, oiChange: 1, close: 1, previousClose: 1),
        StockOiLeg(
            symbol: 'X', expiry: exp, strike: 200, optionType: 'CE',
            oi: 1, oiChange: 1, close: 1, previousClose: 1),
        StockOiLeg(
            symbol: 'X', expiry: exp, strike: 100, optionType: 'PE',
            oi: 1, oiChange: 1, close: 1, previousClose: 1),
      ]);
      expect(s.expiries, [exp, DateTime(2026, 12, 24)]);
      expect(s.strikesFor(exp), [100, 200]);
    });
  });
}
