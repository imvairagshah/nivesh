// 1.5.90 — 52W / ATH / Dividend engine: pure maths + NSE JSON parsing +
// 5% proximity rule (user's spec). Koi network nahi.

import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/features/fno/extremes/extremes_engine.dart';
import 'package:flutter_test/flutter_test.dart';

Candle bar(DateTime day, double o, double h, double l, double c) => Candle(
  // Bars broker se IST stamp ke saath aate hain.
  time: day,
  open: o,
  high: h,
  low: l,
  close: c,
  volume: 1000,
);

void main() {
  final today = DateTime(2026, 11, 12);

  group('52W — pichhle 365 din se high/low', () {
    test('purane bars (>365 din) ignore, window ke andar wale count', () {
      final bars = [
        bar(DateTime(2024, 1, 1), 100, 500, 10, 100), // purana — ignore
        bar(DateTime(2026, 1, 5), 100, 320, 90, 300),
        bar(DateTime(2026, 6, 1), 300, 400, 250, 350),
        bar(DateTime(2026, 11, 11), 350, 360, 340, 355),
      ];
      final r = Extremes.week52(bars, asOf: today)!;
      expect(r.high, 400); // 500 nahi (wo 52W ke bahar)
      expect(r.low, 90);
      expect(r.highDate, DateTime(2026, 6, 1));
    });

    test('khaali bars = null (crash nahi)', () {
      expect(Extremes.week52(const [], asOf: today), isNull);
      expect(Extremes.allTime(const []), isNull);
    });
  });

  group('All-time — poore itihaas se', () {
    test('ATH/ATL + dates', () {
      final bars = [
        bar(DateTime(2019, 3, 1), 100, 900, 95, 880),
        bar(DateTime(2026, 6, 1), 300, 400, 250, 350),
        bar(DateTime(2026, 11, 11), 350, 360, 80, 355),
      ];
      final r = Extremes.allTime(bars)!;
      expect(r.high, 900);
      expect(r.highDate, DateTime(2019, 3, 1));
      expect(r.low, 80);
      expect(r.lowDate, DateTime(2026, 11, 11));
    });
  });

  group('5% proximity rule (user spec)', () {
    StockExtreme e(double close, double high52, double low52) =>
        StockExtreme(symbol: 'X', close: close, high52: high52, low52: low52);

    test('distance % sahi — high se aur low se', () {
      final s = e(990, 1000, 700);
      expect(s.distToHigh52Pct, closeTo(1.0, 0.001)); // 1000-990 /1000
      expect(s.distToLow52Pct, closeTo(41.43, 0.01)); // (990-700)/700
      expect(s.nearHigh52(5), isTrue);
      expect(s.nearLow52(5), isFalse);
      expect(s.nearAny52(5), isTrue);
    });

    test('filter — sirf high/low ke 5% ke andar wale stocks', () {
      final all = [
        e(990, 1000, 500), // high se 1% → andar
        e(520, 1000, 500), // low se 4% → andar
        e(700, 1000, 500), // high se 30%, low se 40% → bahar
      ];
      final near = Extremes.near52(all, withinPct: 5);
      expect(near, hasLength(2));
      // Sabse nazdeek pehle: 990 (1%) → 520 (4%)
      expect(near.first.close, 990);
    });

    test('filter 3% pe sakht ho jaata hai', () {
      final all = [e(990, 1000, 500), e(520, 1000, 500)];
      expect(Extremes.near52(all, withinPct: 3), hasLength(1));
      expect(Extremes.near52(all, withinPct: 10), hasLength(2));
    });

    test('close 0 / high null par distance null (kabhi NaN nahi)', () {
      final s = StockExtreme(symbol: 'X', close: 0, high52: 100, low52: 50);
      expect(s.distToHigh52Pct, isNull);
      const missing = StockExtreme(symbol: 'Y', close: 100);
      expect(missing.distToHigh52Pct, isNull);
      expect(missing.nearAny52(5), isFalse);
    });
  });

  group('Dividend — NSE parsing', () {
    test('amount parse — "Rs 5 Per Share" aur "5 per share"', () {
      expect(Extremes.parseDividendAmount('AGM/Dividend - Rs 5 Per Share'), 5);
      expect(
        Extremes.parseDividendAmount('Dividend - Rs.12.50 Per Share'),
        12.5,
      );
      expect(Extremes.parseDividendAmount('Dividend - 3 Per Share'), 3);
      expect(Extremes.parseDividendAmount('Buyback'), 0);
    });

    test('event calendar JSON → dividend events (sirf dividend rows)', () {
      const json = '''
[{"symbol":"ITC","purpose":"Annual General Meeting/Dividend - Rs 13.50 Per Share",
  "exDate":"20-Nov-2026","recDate":"21-Nov-2026"},
 {"symbol":"TCS","purpose":"Interim Dividend - Rs 11 Per Share",
  "exDate":"05-Dec-2026"},
 {"symbol":"INFY","purpose":"Buyback","exDate":"10-Dec-2026"}]
''';
      final events = Extremes.parseEventCalendar(json);
      expect(events, hasLength(2));
      expect(events.first.symbol, 'ITC');
      expect(events.first.amountPerShare, 13.5);
      expect(events.first.exDate, DateTime(2026, 11, 20));
    });

    test('announcements JSON → declaration date', () {
      const json = '''
[{"symbol":"HDFCBANK","subject":"Dividend","an_dt":"10-Nov-2026 18:30:00"},
 {"symbol":"SBIN","subject":"Board Meeting","an_dt":"11-Nov-2026"}]
''';
      final list = Extremes.parseDividendAnnouncements(json);
      expect(list, hasLength(1));
      expect(list.first.symbol, 'HDFCBANK');
      expect(list.first.announcedDate, DateTime(2026, 11, 10));
    });

    test('merge — amount/ex-date event se, declaration announcement se', () {
      final events = Extremes.parseEventCalendar(
        '[{"symbol":"ITC","purpose":"Dividend - Rs 13.5 Per Share","exDate":"20-Nov-2026"}]',
      );
      final ann = Extremes.parseDividendAnnouncements(
        '[{"symbol":"ITC","subject":"Dividend","an_dt":"10-Nov-2026"}]',
      );
      final merged = Extremes.mergeDividends(
        events: events,
        announcements: ann,
        universe: {'ITC', 'X'},
        asOf: DateTime(2026, 11, 12),
      );
      final itc = merged['ITC']!;
      expect(itc.amountPerShare, 13.5);
      expect(itc.exDate, DateTime(2026, 11, 20));
      expect(itc.announcedDate, DateTime(2026, 11, 10));
    });

    test(
      'merge — purani khabar (>45 din) chhod di jaati hai (past history nahi)',
      () {
        final events = Extremes.parseEventCalendar(
          '[{"symbol":"OLD","purpose":"Dividend - Rs 5 Per Share","exDate":"01-Aug-2026"}]',
        );
        final merged = Extremes.mergeDividends(
          events: events,
          announcements: const [],
          asOf: DateTime(2026, 11, 12),
        );
        expect(merged.containsKey('OLD'), isFalse);
      },
    );

    test('dividend % of price (user ask)', () {
      const d = DividendEvent(symbol: 'ITC', amountPerShare: 13.5);
      expect(d.pctOfPrice(450), closeTo(3.0, 0.001));
      expect(d.pctOfPrice(0), isNull);
    });

    test('galat/khaali JSON = khaali list (crash nahi)', () {
      expect(Extremes.parseEventCalendar(''), isEmpty);
      expect(Extremes.parseEventCalendar('not json'), isEmpty);
      expect(Extremes.parseDividendAnnouncements('{}'), isEmpty);
    });
  });

  group('Dividend rows (1.5.91)', _dividendRowsTests);
}

// ---- 1.5.91: dividend rows (saare F&O stocks) ----

void _dividendRowsTests() {
  test('sortedDividends — saare F&O stocks, ex-date se sort', () {
    final map = {
      'ITC': const DividendEvent(
        symbol: 'ITC',
        amountPerShare: 13.5,
        exDate: null,
      ),
      'TCS': DividendEvent(
        symbol: 'TCS',
        amountPerShare: 11,
        exDate: DateTime(2026, 12, 5),
      ),
      'HDFCBANK': DividendEvent(
        symbol: 'HDFCBANK',
        amountPerShare: 20,
        exDate: DateTime(2026, 11, 20),
      ),
    };
    final rows = Extremes.sortedDividends(map);
    expect(rows.map((e) => e.key).toList(), ['HDFCBANK', 'TCS', 'ITC']);
  });

  test('sortedDividends — proximity filter optional', () {
    final map = {
      'ITC': DividendEvent(
        symbol: 'ITC',
        amountPerShare: 13.5,
        exDate: DateTime(2026, 11, 20),
      ),
      'TCS': DividendEvent(
        symbol: 'TCS',
        amountPerShare: 11,
        exDate: DateTime(2026, 12, 5),
      ),
    };
    expect(Extremes.sortedDividends(map, onlySymbols: {'TCS'}), hasLength(1));
    expect(Extremes.sortedDividends(map).length, 2);
  });

  test(
    'sortedDividends — unseen symbol ka close unknown → % null (guess nahi)',
    () {
      final map = {
        'XYZ': DividendEvent(
          symbol: 'XYZ',
          amountPerShare: 5,
          exDate: DateTime(2026, 12, 1),
        ),
      };
      final rows = Extremes.sortedDividends(map);
      expect(rows.first.value.pctOfPrice(0), isNull);
      expect(rows.first.value.pctOfPrice(100), closeTo(5, 0.001));
    },
  );

  // 1.5.94 — user rule: 52W aur ATH dono me **default sirf 5% ke andar**,
  // "Sabhi stocks" chip se poora universe. Dividend me sirf aane wale.
  group('1.5.94 — scope (5% by default, sabhi optional)', () {
    StockExtreme e(
      String symbol,
      double close, {
      double? h52,
      double? l52,
      double? ath,
      double? atl,
    }) => StockExtreme(
      symbol: symbol,
      close: close,
      high52: h52,
      low52: l52,
      ath: ath,
      atl: atl,
    );

    test('nearAth — ATH ya ATL ke 5% me wale hi, sabse nazdeek pehle', () {
      final all = [
        e('NEARATH', 960, ath: 1000, atl: 400), // 4% below ATH → andar
        e('NEARATL', 408, ath: 1000, atl: 400), // 2% above ATL → andar
        e('MIDDLE', 700, ath: 1000, atl: 400), // 30% / 75% door → bahar
        e('NOATH', 500), // ATH hi nahi → bahar
      ];
      final rows = Extremes.nearAth(all, withinPct: 5);
      expect(rows.map((x) => x.symbol).toList(), ['NEARATL', 'NEARATH']);
    });

    test('nearAth — 10% chip se zyada stocks aate hain', () {
      final all = [
        e('A', 930, ath: 1000), // 7% door
        e('B', 880, ath: 1000), // 12% door
      ];
      expect(Extremes.nearAth(all, withinPct: 5), isEmpty);
      expect(Extremes.nearAth(all, withinPct: 10).map((x) => x.symbol), ['A']);
    });

    test('byProximity52 — "sabhi" me saare stocks, tarteeb nazdeek se', () {
      final all = [
        e('FAR', 500, h52: 1000, l52: 400),
        e('NEAR', 990, h52: 1000, l52: 400),
        e('MID', 950, h52: 1000, l52: 400),
      ];
      final rows = Extremes.byProximity52(all);
      expect(rows.map((x) => x.symbol).toList(), ['NEAR', 'MID', 'FAR']);
      expect(rows, hasLength(3));
    });

    test('byProximityAth — sirf jinka ATH/ATL load hua', () {
      final all = [e('A', 980, ath: 1000), e('B', 500), e('C', 405, atl: 400)];
      final rows = Extremes.byProximityAth(all);
      expect(rows.map((x) => x.symbol).toList(), ['C', 'A']);
    });
  });

  group('1.5.94 — dividend: sirf aane wale (naam hi nahi dikhna)', () {
    final asOf = DateTime(2026, 11, 14);

    test('beet chuka ex-date hata, aane wala rakho', () {
      final map = {
        'PAST': DividendEvent(
          symbol: 'PAST',
          amountPerShare: 5,
          exDate: DateTime(2026, 10, 1),
        ),
        'SOON': DividendEvent(
          symbol: 'SOON',
          amountPerShare: 12,
          exDate: DateTime(2026, 11, 20),
        ),
        'TODAY': DividendEvent(
          symbol: 'TODAY',
          amountPerShare: 3,
          exDate: DateTime(2026, 11, 14),
        ),
      };
      final out = Extremes.upcomingDividends(map, asOf: asOf);
      expect(out.keys.toSet(), {'SOON', 'TODAY'});
    });

    test('ex-date pata nahi par naya elaan (7 din) → rakho', () {
      final map = {
        'NEW': DividendEvent(
          symbol: 'NEW',
          amountPerShare: 8,
          announcedDate: DateTime(2026, 11, 10),
        ),
        'OLD': DividendEvent(
          symbol: 'OLD',
          amountPerShare: 8,
          announcedDate: DateTime(2026, 9, 1),
        ),
        'NODATE': DividendEvent(symbol: 'NODATE', amountPerShare: 8),
      };
      final out = Extremes.upcomingDividends(map, asOf: asOf);
      expect(out.keys.toSet(), {'NEW'});
    });

    test('khaali map → khaali (crash nahi)', () {
      expect(Extremes.upcomingDividends(const {}, asOf: asOf), isEmpty);
    });
  });
}
