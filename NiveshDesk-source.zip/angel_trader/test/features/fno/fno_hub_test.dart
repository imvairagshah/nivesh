// 1.5.93 — F&O hub (design B: category rows + long-press drag reorder).
//
// Yahan teen cheezein pin hoti hain:
//   1. saved order merge logic (naya tool aaye to user ka order na toote),
//   2. hub render — section order + har row me sirf naam + ek line,
//   3. long-press drag se row ka upar-neeche jaana + save call.

import 'package:angel_trader/features/fno/fno_hub_config.dart';
import 'package:angel_trader/features/fno/fno_hub_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

class _FakeStore implements FnoHubOrderStore {
  _FakeStore([this._saved]);

  Map<String, List<String>>? _saved;
  int saves = 0;

  @override
  Future<Map<String, List<String>>> load() async =>
      mergeHubOrder(_saved ?? defaultHubOrder());

  @override
  Future<void> save(Map<String, List<String>> order) async {
    _saved = order;
    saves++;
  }
}

void main() {
  group('hub order merge', () {
    test('default order — har tool apne section me, section ke andar config order',
        () {
      final order = defaultHubOrder();
      expect(order['study'], ['study', 'adv']);
      expect(order['index'], ['bankex']);
      expect(order['options'], ['stock_oi', 'extremes']);
      expect(order['calendar'], ['results', 'ai']);
      expect(order.values.fold<int>(0, (a, b) => a + b.length),
          kHubTools.length);
    });

    test('saved order barqarar rehta hai', () {
      final merged = mergeHubOrder({
        'study': ['adv', 'study'],
        'options': ['extremes', 'stock_oi'],
        'calendar': ['ai', 'results'],
        'index': ['bankex'],
      });
      expect(merged['study'], ['adv', 'study']);
      expect(merged['options'], ['extremes', 'stock_oi']);
      expect(merged['calendar'], ['ai', 'results']);
    });

    test('naya tool apne section ke aakhir me judta hai (order nahi tootta)', () {
      // Purana saved order jisme 'extremes' hi nahi tha.
      final merged = mergeHubOrder({
        'study': ['adv', 'study'],
        'options': ['stock_oi'],
      });
      expect(merged['study'], ['adv', 'study']);
      expect(merged['options'], ['stock_oi', 'extremes']);
    });

    test('kharab / adhoora JSON → default order (crash nahi)', () {
      expect(mergeHubOrder(null)['study'], ['study', 'adv']);
      expect(mergeHubOrder('garbage')['study'], ['study', 'adv']);
      expect(mergeHubOrder(<String, dynamic>{'study': 'not-a-list'})['study'],
          ['study', 'adv']);
    });

    test('unknown id chhoot jata hai, duplicate nahi aata', () {
      final merged = mergeHubOrder({
        'study': ['ghost', 'study', 'study', 'adv'],
      });
      expect(merged['study'], ['study', 'adv']);
    });

    test('moveInSection — neeche aur upar dono', () {
      expect(moveInSection(['a', 'b', 'c'], 'a', 2), ['b', 'c', 'a']);
      expect(moveInSection(['a', 'b', 'c'], 'c', 0), ['c', 'a', 'b']);
      expect(moveInSection(['a', 'b'], 'zz', 0), ['a', 'b']);
      expect(moveInSection(['a', 'b'], 'a', 99), ['b', 'a']);
    });
  });

  group('hub screen', () {
    Widget wrap(Widget child) => MaterialApp(home: child);

    testWidgets('section order + compact rows (naam + ek line)',
        (tester) async {
      await tester.pumpWidget(wrap(FnoHubScreen(orderStore: _FakeStore())));
      await tester.pumpAndSettle();

      // Section headings config ke order me.
      final headings = [
        'SCREENER & STUDY',
        'INDEX STRATEGIES',
        'OPTIONS DATA',
        'CALENDAR & AI',
      ];
      final positions = [
        for (final h in headings) tester.getTopLeft(find.text(h)).dy,
      ];
      for (var i = 1; i < positions.length; i++) {
        expect(positions[i], greaterThan(positions[i - 1]),
            reason: '${headings[i]} ${headings[i - 1]} ke neeche hona chahiye');
      }

      // Saare live tools ek hi page par.
      for (final tool in kHubTools) {
        expect(find.text(tool.title), findsOneWidget, reason: tool.title);
        expect(find.text(tool.blurb), findsOneWidget,
            reason: '${tool.id} ki ek-line description');
      }
    });

    testWidgets('long-press drag se row neeche jaata hai aur save hota hai',
        (tester) async {
      final store = _FakeStore();
      await tester.pumpWidget(wrap(FnoHubScreen(orderStore: store)));
      await tester.pumpAndSettle();

      // Study section me pehla row '3-Month Study' hai.
      final first = find.text('3-Month Study');
      final second = find.text('3-Month Study · Advance Filter');
      expect(tester.getTopLeft(first).dy, lessThan(tester.getTopLeft(second).dy));

      final gesture = await tester.startGesture(tester.getCenter(first));
      await tester.pump(const Duration(milliseconds: 400)); // long-press delay
      await gesture.moveBy(const Offset(0, 80));
      await tester.pump(const Duration(milliseconds: 200));
      await gesture.up();
      await tester.pumpAndSettle();

      // Model me order badal gaya + store.save call hua.
      expect(store.saves, greaterThan(0));
      final saved = await store.load();
      expect(saved['study'], ['adv', 'study']);
    });
  });
}
