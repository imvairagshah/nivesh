// 1.5.78 — Bankex–Bank Nifty rule engines: regime classification + strategy
// economics (PDF rules ke against spot-checks). Pure logic, sample chain se.

import 'package:angel_trader/features/fno/bankex/bankex_models.dart';
import 'package:angel_trader/features/fno/bankex/regime_engine.dart';
import 'package:angel_trader/features/fno/bankex/sample_data.dart';
import 'package:angel_trader/features/fno/bankex/strategy_backtest.dart';
import 'package:angel_trader/features/fno/bankex/strategy_engine.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  final m = SampleData.snapshot();

  test('RegimeEngine — sample data par consistent classification', () {
    final r = RegimeEngine.classify(m);
    // Sample: BN +0.57% (mild up), VIX 13.4/rank 28 (depressed), PCR 1.12.
    expect(r.primary, anyOf('MILDLY BULLISH', 'RANGEBOUND'));
    expect(r.confidence, anyOf('HIGH', 'MEDIUM', 'LOW'));
    expect(r.recommended, isNotEmpty);
    expect(r.trendLine, contains('trend='));
  });

  test('pickStrike — %OTM ke sabse paas ka strike', () {
    final ce = StrategyEngine.pickStrike(m.bankNifty, 'CE', 1.25);
    expect(ce, isNotNull);
    expect(ce!.strike, greaterThan(m.bankNifty.spot));
    expect((ce.strike - m.bankNifty.spot * 1.0125).abs(), lessThan(150));
    final pe = StrategyEngine.pickStrike(m.bankNifty, 'PE', 1.25);
    expect(pe!.strike, lessThan(m.bankNifty.spot));
  });

  test('P2.6 Long Straddle — debit = premium sum × 30 × lots', () {
    final r = StrategyEngine.longStraddle(m, 3, true);
    expect(r.legs.length, 2);
    final units = StrategyEngine.lotSize * 3;
    final debit = (r.legs[0].premium + r.legs[1].premium) * units;
    final debitLine =
        r.economics.firstWhere((e) => e.startsWith('Net Debit'));
    final reported = double.parse(
        debitLine.replaceAll(RegExp(r'[^0-9.]'), '').split('.').first);
    expect((reported - debit.round()).abs(), lessThanOrEqualTo(2));
  });

  test('P2.8 — side rule (1.5.81): earlier expiry SHORT, later expiry LONG', () {
    // Sample: BN dte 14 (pehle expiry) vs Bankex dte 16 (baad me) → BN short.
    expect(m.bankNifty.expiryDate.isBefore(m.bankex.expiryDate), isTrue);
    final r = StrategyEngine.diagonalRatioBackspread(m, 2, true);
    expect(r.legs.length, 2);
    expect(r.legs[0].action, 'Sell');
    expect(r.legs[0].instrument, 'BN CE (ATM)');
    expect(r.legs[1].action, 'Buy');
    expect(r.legs[1].instrument, 'BANKEX CE (OTM)');
    expect(r.entryRules.first, contains('expiry pehle'));
  });

  test('P2.8 — tie (same expiry) me IV fallback: higher-IV index short', () {
    final exp = m.bankNifty.expiryDate;
    IndexSnapshot clone(IndexSnapshot i) => IndexSnapshot(
          name: i.name,
          spot: i.spot,
          previousClose: i.previousClose,
          intradayHigh: i.intradayHigh,
          intradayLow: i.intradayLow,
          atmIv: i.atmIv,
          ivRank30d: i.ivRank30d,
          pcr: i.pcr,
          maxPain: i.maxPain,
          expiryDate: exp,
          dte: 14,
          chain: i.chain,
          totalCallOi: i.totalCallOi,
          totalPutOi: i.totalPutOi,
        );
    final tied = MarketSnapshot(
      bankNifty: clone(m.bankNifty),
      bankex: clone(m.bankex),
      indiaVix: m.indiaVix,
      vixRank30d: m.vixRank30d,
      advances: m.advances,
      declines: m.declines,
      capitalAvailable: m.capitalAvailable,
      isDemo: true,
    );
    // Sample IVs: Bankex 16.1 > BN 14.2 → fallback me BANKEX short, BN long.
    final r = StrategyEngine.diagonalRatioBackspread(tied, 2, true);
    expect(r.legs[0].action, 'Sell');
    expect(r.legs[0].instrument, 'BANKEX CE (ATM)');
    expect(r.legs[1].action, 'Buy');
    expect(r.legs[1].instrument, 'BN CE (OTM)');
    expect(r.entryRules.first, contains('same expiry'));
  });


  test('side rule (1.5.82) — P2.3/P2.7/P2.10 sab me earlier expiry SHORT', () {
    // Sample: BN dte 14 (pehle) → BN sell side; Bankex dte 16 (baad) → buy side.
    final expectRule = (StrategyReport r, String sellLabel, String buyLabel) {
      final sells = r.legs.where((l) => l.action == 'Sell').toList();
      final buys = r.legs.where((l) => l.action == 'Buy').toList();
      expect(sells, isNotEmpty, reason: '${r.id} sell legs');
      expect(buys, isNotEmpty, reason: '${r.id} buy legs');
      for (final l in sells) {
        expect(l.instrument, contains(sellLabel), reason: '${r.id} sell');
      }
      for (final l in buys) {
        expect(l.instrument, contains(buyLabel), reason: '${r.id} buy');
      }
      expect(r.entryRules.first, contains('expiry pehle'), reason: r.id);
    };

    expectRule(StrategyEngine.crossExpiryCalendar(m, 2), 'BN', 'BANKEX');
    expectRule(StrategyEngine.shortStrangleHedged(m, 2), 'BN', 'BANKEX');
    expectRule(StrategyEngine.deltaNeutralPair(m, 2), 'BN', 'BANKEX');
    // P2.8 pehle se expiry rule par hai (1.5.81).
    expectRule(StrategyEngine.diagonalRatioBackspread(m, 2, true), 'BN', 'BANKEX');
  });

  test('side rule — expiry invert hone par sides khud flip', () {
    IndexSnapshot withExpiry(IndexSnapshot i, DateTime exp, int dte) =>
        IndexSnapshot(
          name: i.name,
          spot: i.spot,
          previousClose: i.previousClose,
          intradayHigh: i.intradayHigh,
          intradayLow: i.intradayLow,
          atmIv: i.atmIv,
          ivRank30d: i.ivRank30d,
          pcr: i.pcr,
          maxPain: i.maxPain,
          expiryDate: exp,
          dte: dte,
          chain: i.chain,
          totalCallOi: i.totalCallOi,
          totalPutOi: i.totalPutOi,
        );
    // Bankex expiry ab BN se PEHLE → Bankex short, BN long.
    final flipped = MarketSnapshot(
      bankNifty: withExpiry(m.bankNifty, DateTime(2026, 11, 26), 23),
      bankex: withExpiry(m.bankex, DateTime(2026, 11, 19), 16),
      indiaVix: m.indiaVix,
      vixRank30d: m.vixRank30d,
      advances: m.advances,
      declines: m.declines,
      capitalAvailable: m.capitalAvailable,
      isDemo: true,
    );
    final r = StrategyEngine.crossExpiryCalendar(flipped, 2);
    expect(r.legs.where((l) => l.action == 'Sell').map((l) => l.instrument),
        everyElement(contains('BANKEX')));
    expect(r.legs.where((l) => l.action == 'Buy').map((l) => l.instrument),
        everyElement(contains('BN')));
    expect(r.underlying, contains('BANKEX short'));
  });

  test('backtest — leg P&L maths (buy/sell sign, units × lot size)', () {
    // Buy: premium 100 → 130, 2 lots → +30 × 60 = +1800.
    final buy = StrategyBacktestService.computeLeg(
      instrument: 'BN CE (ATM)',
      action: 'Buy',
      lots: 2,
      entryPremium: 100,
      currentPremium: 130,
    );
    expect(buy.units, 60);
    expect(buy.pnl, 1800);
    expect(buy.changePct, closeTo(30, 0.001));

    // Sell: premium 100 → 70, 2 lots → +30 × 60 = +1800 (short profit).
    final sell = StrategyBacktestService.computeLeg(
      instrument: 'BANKEX PE (OTM)',
      action: 'Sell',
      lots: 2,
      entryPremium: 100,
      currentPremium: 70,
    );
    expect(sell.pnl, 1800);

    // Sell aur premium badha → loss.
    final badSell = StrategyBacktestService.computeLeg(
      instrument: 'BANKEX PE (OTM)',
      action: 'Sell',
      lots: 1,
      entryPremium: 100,
      currentPremium: 140,
    );
    expect(badSell.pnl, -1200);
  });

  test('backtest — total sirf complete hone par, missing legs flag', () {
    final a = StrategyBacktestService.computeLeg(
        instrument: 'BN CE', action: 'Sell', lots: 1,
        entryPremium: 100, currentPremium: 80);
    final b = StrategyBacktestService.computeLeg(
        instrument: 'BANKEX CE', action: 'Buy', lots: 1,
        entryPremium: 200, currentPremium: 260);

    final complete = StrategyBacktest(id: 'P2.8', legs: [a, b]);
    expect(complete.complete, isTrue);
    expect(complete.totalPnl, 600 + 1800);
    expect(complete.winners, 2);
    expect(complete.losers, 0);

    final partial = StrategyBacktest(
        id: 'P2.8', legs: [a], missing: const ['BANKEX CE — kal ka candle nahi mila']);
    expect(partial.complete, isFalse);
    expect(partial.missing, hasLength(1));

    const empty = StrategyBacktest(id: 'P2.8', note: 'data nahi');
    expect(empty.hasData, isFalse);
    expect(empty.complete, isFalse);
  });

  test('backtest — leg label parse (BN/BANKEX × CE/PE)', () {
    expect(StrategyBacktestService.parseInstrument('BN CE (ATM)')!.bankex,
        isFalse);
    expect(StrategyBacktestService.parseInstrument('BN CE (ATM)')!.side, 'CE');
    expect(StrategyBacktestService.parseInstrument('BANKEX PE (wing)')!.bankex,
        isTrue);
    expect(StrategyBacktestService.parseInstrument('BANKEX PE (wing)')!.side,
        'PE');
    expect(StrategyBacktestService.parseInstrument('BN CE (near expiry)')!.side,
        'CE');
  });

  test('buildAll — 6 strategies (1.5.80 set), sabme legs + disclaimer', () {
    final all = StrategyEngine.buildAll(m, 3);
    expect(all.length, 7); // P2.6 straddle + strangle alag-alag
    for (final r in all) {
      expect(r.warnings.last, contains('DISCLAIMER'));
      if (r.valid) expect(r.legs, isNotEmpty);
    }
    // P2.10 sample me IV diff 1.9 (≤2.5) → invalid hona chahiye (honest gate).
    final pair = all.firstWhere((r) => r.id == 'P2.10');
    expect(pair.valid, false);
    expect(pair.validationNote, contains('IV differential'));
  });
}
