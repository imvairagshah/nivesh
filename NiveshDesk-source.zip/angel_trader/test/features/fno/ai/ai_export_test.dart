// ---------------------------------------------------------------------------
// ai_export_test.dart — the file/list that leaves the phone must carry the
// trade AND its risk, in the same column order every time.
//
// These are the pure parts (no path_provider in a unit test): the column list,
// the cells, the Hinglish recap. If a column is added to one and not the other
// this file fails — which is the whole point.
// ---------------------------------------------------------------------------

import 'package:angel_trader/features/fno/ai/ai_export.dart';
import 'package:angel_trader/features/fno/ai/ai_indicators.dart';
import 'package:angel_trader/features/fno/ai/ai_suggestion.dart';
import 'package:flutter_test/flutter_test.dart';

final DateTime kDay = DateTime(2026, 10, 9);

AiSnapshot _snap() => const AiSnapshot(
      ltp: 1482.30,
      rsi: 61.4,
      ema9: 1470,
      ema21: 1440,
      sma50: 1390,
      high52w: 1500,
      low52w: 1100,
      atr: 27,
      atrPct: 1.8,
      volumeRatio: 2.1,
      return3m: 8.4,
      turnoverCrore: 42.5,
      bars: 70,
    );

AiSuggestion _row() => AiSuggestion(
      symbol: 'RELIANCE',
      name: 'Reliance Industries Ltd',
      rank: 1,
      score: 72.4,
      studyScore: 9.5,
      snapshot: _snap(),
      pattern: AiPattern.breakout,
      direction: AiDirection.bullish,
      move: AiMove.breakout,
      rationale: const ['RSI 61', '+8.4% 3 mahine me'],
      strategy: const AiStrategy(
        action: 'Buy',
        name: 'Directional Buy',
        strikeType: 'ATM',
        pair: 'CE 1480',
        why: 'Uptrend + RSI 61 · seedha CE kharidna sabse simple hai.',
      ),
      options: const AiOptionContext(
        atmStrike: 1480,
        avgIv: 19.6,
        straddleTotal: 31.5,
        lotSize: 250,
      ),
      resultDate: kDay.add(const Duration(days: 12)),
      resultConfirmed: true,
    );

AiExportMeta _meta() => AiExportMeta(
      asOf: kDay,
      runAt: kDay,
      rowCount: 1,
      withOptions: 1,
      filters: AiFilters.defaults,
      funnel: '213 scan hue · 180 liquidity paar · 12 list me',
    );

void main() {
  test('every header has a cell — XLSX and CSV can never drift apart', () {
    final cells = AiExportService.rowCells(_row(), kDay);
    expect(cells.length, AiExportService.headers.length);
  });

  test('the columns every trader needs are present, in a readable order', () {
    final headers = AiExportService.headers;
    expect(headers.first, 'Rank');
    expect(headers, contains('Technical rationale'));
    expect(headers, contains('Result date'));
    expect(headers, contains('Turnover (Rs cr)'));
    for (final required in [
      'Action',
      'Strategy',
      'Strike type',
      'Suggested jodi',
      'Kyu (strategy)',
    ]) {
      expect(headers, contains(required));
    }
    // The risk column comes before the trade columns: read the date first.
    expect(headers.indexOf('Result date'),
        lessThan(headers.indexOf('Suggested jodi')));
  });

  test('cells carry the numbers, not placeholders', () {
    final cells = AiExportService.rowCells(_row(), kDay);
    final byName = Map<String, String>.fromIterables(
      AiExportService.headers,
      cells,
    );

    expect(byName['Rank'], '1');
    expect(byName['Symbol'], 'RELIANCE');
    expect(byName['CMP'], '1482.30');
    expect(byName['Turnover (Rs cr)'], '42.5');
    expect(byName['Result in days'], '12');
    expect(byName['Result date'], '2026-10-21');
    expect(byName['Suggested jodi'], 'CE 1480');
    expect(byName['IV %'], '19.6');
    expect(byName['Lot size'], '250');
    expect(byName['Technical rationale'], 'RSI 61 · +8.4% 3 mahine me');
  });

  test('a row the scan could not price exports dashes, never a fake number',
      () {
    final row = AiSuggestion(
      symbol: 'THIN',
      name: '',
      rank: 2,
      score: 50,
      studyScore: 5.5,
      snapshot: _snap(),
      pattern: AiPattern.range,
      direction: AiDirection.sideways,
      move: AiMove.consolidation,
      rationale: const ['RSI 50'],
      strategy: AiStrategy.none,
    );
    final byName = Map<String, String>.fromIterables(
      AiExportService.headers,
      AiExportService.rowCells(row, kDay),
    );

    expect(byName['Suggested jodi'], '—');
    expect(byName['IV %'], '—');
    expect(byName['Jodi total (Rs)'], '—');
    expect(byName['Lot size'], '—');
    expect(byName['Result date'], '—');
  });

  test('the recap reads like a message, with the result date on it', () {
    final text = AiExportService.recap([_row()], _meta());
    expect(text, contains('RELIANCE'));
    expect(text, contains('Buy Directional Buy — CE 1480 (ATM)'));
    expect(text, contains('Result: 12 din me'));
    expect(text, contains(AiExportService.disclaimer));
  });

  test('the Read Me spells out the filters the list obeys', () {
    final lines = AiExportService().readMeSheet(_meta());
    final flat = lines.map((l) => l.join(' ')).join('\n');
    expect(flat, contains('Min turnover'));
    expect(flat, contains('Result ki chhutti'));
    expect(flat, contains('213 scan hue'));
    expect(flat, contains(AiExportService.disclaimer));
  });
}
