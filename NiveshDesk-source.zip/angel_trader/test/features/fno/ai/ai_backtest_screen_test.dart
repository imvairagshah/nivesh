// ---------------------------------------------------------------------------
// ai_backtest_screen_test.dart — the report, as the user reads it.
//
// A backtest screen can lie by layout: bury the sample size, colour a loss like
// a win, drop the disclaimer. So this file pins the rendered text: the headline
// in the shape it was asked for, every number with its sample, and the
// "ye kya nahi hai" card that must never disappear.
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/theme/app_theme.dart';
import 'package:angel_trader/features/fno/ai/ai_backtest.dart';
import 'package:angel_trader/features/fno/ai/ai_backtest_screen.dart';
import 'package:angel_trader/features/fno/ai/ai_indicators.dart'
    show AiPattern;
import 'package:angel_trader/features/fno/ai/ai_suggestion.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

final DateTime kDay = DateTime(2025, 6, 2);

BtTrade trade(
  String symbol,
  double r, {
  AiPattern pattern = AiPattern.breakout,
  BtExit exit = BtExit.target,
  int dayOffset = 0,
}) =>
    BtTrade(
      symbol: symbol,
      date: kDay.add(Duration(days: dayOffset)),
      pattern: pattern,
      direction: r >= 0 || exit == BtExit.target
          ? AiDirection.bullish
          : AiDirection.bullish,
      entry: 100,
      stop: 98,
      target: 104,
      risk: 2,
      exitPrice: 100 + r * 2,
      exit: exit,
      barsHeld: 3,
    );

BtResult resultOf(List<BtTrade> trades, {int years = 2}) => BtResult(
      config: const BtConfig(),
      trades: trades,
      symbolsScanned: 198,
      skipped: const {'GHOST': 'Is stock ka koi candle data nahi mila.'},
      mixedSignals: 37,
      shortHistory: 15,
      downloads: 0,
      years: years,
      from: DateTime(2023, 6, 2),
      to: DateTime(2025, 6, 2),
      duration: const Duration(seconds: 4),
      cancelled: false,
    );

/// Scrolls a widget into view (the report is a long list; a card that has not
/// been built yet cannot be found, and a card that is never seen is useless).
Future<void> show(WidgetTester tester, Finder finder) =>
    tester.scrollUntilVisible(finder, 400,
        scrollable: find.byType(Scrollable).first);

Future<void> pump(WidgetTester tester, BtResult result) async {
  await tester.pumpWidget(
    MaterialApp(
      theme: AppTheme.light(),
      home: Scaffold(body: AiBacktestReport(result: result)),
    ),
  );
  await tester.pumpAndSettle();
}

void main() {
  testWidgets('the headline reads like a count, not a promise', (tester) async {
    // 10 winners (+2R = +4 %) and 5 losers (−1R = −2 %): 67 % right, +2 % avg.
    final trades = <BtTrade>[
      for (var i = 0; i < 10; i++) trade('ALPHA', 2),
      for (var i = 0; i < 5; i++) trade('BETA', -1, exit: BtExit.stop),
    ];
    await pump(tester, resultOf(trades));

    expect(find.text('15 baar aaya · 67% sahi disha · ausat +2.0%'),
        findsOneWidget);
    // Coverage: how many stocks, how many trades, over what period.
    expect(find.textContaining('198 stock · 15 trade · 2 saal'), findsOneWidget);
    // The sample is small and the screen says so instead of dressing it up.
    expect(find.text('kam sample — is par bharosa nahi'), findsOneWidget);
  });

  testWidgets('a losing report is not coloured into a winning one',
      (tester) async {
    await pump(tester, resultOf([for (var i = 0; i < 40; i++) trade('X', -1, exit: BtExit.stop)]));

    expect(find.textContaining('ausat −2.0%'), findsOneWidget);
    expect(find.textContaining('0% sahi disha'), findsOneWidget);
    expect(find.text('Stop laga'), findsOneWidget);
    expect(find.text('100%'), findsOneWidget); // the stop column
  });

  testWidgets('every number carries the sample it came from', (tester) async {
    await pump(tester, resultOf([
      for (var i = 0; i < 20; i++) trade('ALPHA', 2),
      for (var i = 0; i < 6; i++) trade('BETA', -1, exit: BtExit.stop),
    ]));

    // The stat grid spells each figure out rather than leaving it to be read.
    expect(find.text('26'), findsOneWidget); // samples
    expect(find.text('20 trade me 1 : 2 poora hua'), findsOneWidget);
    expect(find.text('6 trade me stop chala'), findsOneWidget);
    expect(find.text('20 trade sahi disha me band'), findsOneWidget);
  });

  testWidgets('each rule is scored on its own', (tester) async {
    await pump(tester, resultOf([
      trade('ALPHA', 2),
      trade('ALPHA', 2, dayOffset: 1),
      trade('BETA', -1, exit: BtExit.stop, pattern: AiPattern.breakdown),
    ]));

    await show(tester, find.text('Kaunsa rule kitna sahi'));
    expect(find.text('Kaunsa rule kitna sahi'), findsOneWidget);
    expect(find.text('Breakout'), findsWidgets);
    expect(find.text('Breakdown'), findsWidgets);
    expect(find.textContaining('2 baar'), findsOneWidget);
    expect(find.textContaining('1 baar'), findsOneWidget);
  });

  testWidgets('the limits are on the screen, always', (tester) async {
    await pump(tester, resultOf([for (var i = 0; i < 40; i++) trade('X', 1)]));

    await show(tester, find.text('Ye kya nahi hai — pehle ye padh lo'));
    expect(find.text('Ye kya nahi hai — pehle ye padh lo'), findsOneWidget);
    expect(find.textContaining('koi guarantee nahi hai'), findsOneWidget);
    expect(find.textContaining('option ka nahi'), findsOneWidget);
    expect(find.textContaining('brokerage, STT/GST, slippage'), findsOneWidget);
  });

  testWidgets('the fine print says where the data came from and what was left out',
      (tester) async {
    await pump(tester, resultOf([trade('X', 1)]));

    await show(tester, find.text('Puri jankari'));
    expect(find.text('Puri jankari'), findsOneWidget);
    // Offline claim.
    expect(
      find.text('Pura run phone ke cache se hua — ek bhi internet call nahi gayi.'),
      findsOneWidget,
    );
    expect(find.textContaining('15 stock ke paas poore 2 saal ka itihaas'),
        findsOneWidget);
    expect(find.textContaining('37 baar pattern aur direction'), findsOneWidget);
    expect(find.textContaining('1 stock ka data nahi mila'), findsOneWidget);
  });

  testWidgets('an empty report says so instead of showing zeroes', (tester) async {
    await pump(tester, resultOf(const <BtTrade>[]));

    expect(find.text('Is niyam par koi trade hi nahi bana.'), findsOneWidget);
    expect(find.textContaining('0 trade'), findsWidgets); // every grid row says it
    expect(find.textContaining('198 stock · 0 trade'), findsOneWidget);
  });
}
