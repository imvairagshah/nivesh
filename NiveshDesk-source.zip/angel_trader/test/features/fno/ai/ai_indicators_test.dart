// ---------------------------------------------------------------------------
// ai_indicators_test.dart — the numbers behind "AI Suggestion".
//
// Every expectation here is hand-checked arithmetic, not a snapshot of whatever
// the code happened to produce. The point of a local rule engine is that the
// same candles always give the same answer — so these tests pin the arithmetic
// and the filter thresholds.
// ---------------------------------------------------------------------------

import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/features/fno/ai/ai_indicators.dart';
import 'package:flutter_test/flutter_test.dart';

final DateTime kEnd = DateTime(2025, 3, 21);

Candle bar(int i, double close, {double? high, double? low, int volume = 1000}) =>
    Candle(
      time: kEnd.subtract(Duration(days: 200 - i)),
      open: close,
      high: high ?? close,
      low: low ?? close,
      close: close,
      volume: volume,
    );

/// `count` bars whose closes follow [closeOf], oldest → newest.
List<Candle> series(int count, double Function(int i) closeOf,
    {int Function(int i)? volumeOf}) => [
      for (var i = 0; i < count; i++)
        bar(i, closeOf(i), volume: volumeOf?.call(i) ?? 1000),
    ];

/// A straight ramp: 70 sessions, one rupee a day.
List<Candle> ramp({int count = 70, double base = 100}) =>
    series(count, (i) => base + i);

void main() {
  group('wilderRsi', () {
    test('a flat line is 50 — an unknown RSI is not an extreme RSI', () {
      expect(wilderRsi(series(40, (_) => 100)), 50);
    });

    test('too few bars → 50 rather than a wild number', () {
      expect(wilderRsi(series(10, (i) => 100 + i.toDouble())), 50);
    });

    test('only gains → 100, only losses → 0', () {
      expect(wilderRsi(series(40, (i) => 100 + i.toDouble())), 100);
      expect(wilderRsi(series(40, (i) => 200 - i.toDouble())), 0);
    });

    test('equal gains and losses settle near the middle, never at an extreme',
        () {
      // +2, −2, +2, −2 … from bar 1 onwards. Wilder's smoothing lags, so a
      // perfectly balanced series lands just under 50 (≈48) rather than exactly
      // on it — the point is that it is nowhere near 0 or 100.
      final bars = series(201, (i) => i % 2 == 0 ? 100.0 : 102.0);
      final rsi = wilderRsi(bars);
      expect(rsi, inInclusiveRange(45, 55));
      expect(rsi, closeTo(48.15, 0.05));
    });
  });

  group('emaLast / smaLast', () {
    test('EMA seeded with the plain average of the first period', () {
      // k = 2/3 for period 2 → 1.5, 2.5, 3.5, 4.5 over 1…5.
      final values = [1.0, 2.0, 3.0, 4.0, 5.0];
      expect(emaLast(values, 2), closeTo(4.5, 1e-9));
    });

    test('EMA returns null when the series is shorter than the period', () {
      expect(emaLast([1.0, 2.0], 5), isNull);
    });

    test('SMA is the plain mean of the last period', () {
      expect(smaLast([1.0, 2.0, 3.0, 4.0, 10.0], 2), closeTo(7, 1e-9));
      expect(smaLast([1.0, 2.0], 5), isNull);
    });
  });

  group('buildSnapshot', () {
    test('reads the ramp correctly', () {
      final snap = buildSnapshot(ramp());

      expect(snap.bars, 70);
      expect(snap.ltp, closeTo(169, 1e-9)); // 100 + 69
      expect(snap.high52w, closeTo(169, 1e-9));
      expect(snap.low52w, closeTo(100, 1e-9));
      expect(snap.ema9, greaterThan(snap.ema21));
      expect(snap.ema21, greaterThan(snap.sma50));
      expect(snap.stackUp, isTrue);
      expect(snap.stackDown, isFalse);
      expect(snap.rsi, closeTo(100, 1e-9));
      expect(snap.atr, closeTo(1, 1e-6)); // one rupee a day
      expect(snap.atrPct, closeTo(1 / 169 * 100, 1e-9));
      expect(snap.volumeRatio, closeTo(1, 1e-9)); // no spike
      expect(snap.fromHighPct, closeTo(0, 1e-9)); // it *is* the high
    });

    test('3-month return uses the study window (63 sessions back)', () {
      // 70 bars: the close 64 sessions back is bar 6 → 106.
      final snap = buildSnapshot(ramp());
      expect(snap.return3m, closeTo((169 / 106 - 1) * 100, 1e-9));
    });

    test('volume ratio is today against the 20 sessions before it', () {
      final bars = ramp();
      final spiked = <Candle>[
        ...bars.take(69),
        bar(69, 169, volume: 5000),
      ];
      expect(buildSnapshot(spiked).volumeRatio, closeTo(5, 1e-9));
    });

    test('turnover is the 20-session average of close × volume, in ₹ crore',
        () {
      final bars = series(25, (i) => 100.0 + i.toDouble()); // closes 100…124
      // Window = last 20 bars: closes 105…124, mean 114.5; volume 1,000.
      // 114.5 × 1,000 = 114,500 → 0.01145 cr.
      final snap = buildSnapshot(bars);
      expect(snap.turnoverCrore, closeTo(0.01145, 1e-9));

      // One lakh shares a day at ₹200 → 2 crore.
      final heavy = series(25, (_) => 200.0).map((b) => Candle(
            time: b.time,
            open: 200,
            high: 200,
            low: 200,
            close: 200,
            volume: 100000,
          )).toList();
      expect(buildSnapshot(heavy).turnoverCrore, closeTo(2, 1e-9));
    });

    test('52-week window is capped at 250 sessions', () {
      // 300 bars: the high is the last close, the low is bar 50 (300 − 250).
      final snap = buildSnapshot(ramp(count: 300));
      expect(snap.low52w, closeTo(150, 1e-9)); // 100 + 50
      expect(snap.high52w, closeTo(399, 1e-9));
    });
  });

  group('detectPattern', () {
    /// 60 quiet sessions at [level], then one session at [lastClose].
    List<Candle> quietThen(double level, double lastClose, int volume) => [
          ...series(60, (_) => level),
          bar(60, lastClose, high: lastClose, low: lastClose, volume: volume),
        ];

    test('a close above the 20-day high with volume is a breakout', () {
      final bars = quietThen(100, 120, 5000); // volume 5x
      expect(detectPattern(bars, buildSnapshot(bars)), AiPattern.breakout);
    });

    test('the same close without volume is NOT a breakout', () {
      final bars = quietThen(100, 120, 1000); // volume 1x
      expect(detectPattern(bars, buildSnapshot(bars)), isNot(AiPattern.breakout));
    });

    test('a close below the 20-day low with volume is a breakdown', () {
      final bars = quietThen(100, 80, 5000);
      expect(detectPattern(bars, buildSnapshot(bars)), AiPattern.breakdown);
    });

    test('overbought / oversold obey the thresholds the user set', () {
      // 40 flat sessions then a slow grind up ending below the 20-day high, so
      // the only thing left to report is the RSI zone.
      final bars = <Candle>[
        ...series(40, (_) => 100.0),
        ...series(20, (i) => 100 + (i + 1) * 0.5),
        bar(60, 109.5, high: 110, low: 109),
      ];
      final snap = buildSnapshot(bars);

      // Default overbought = 65: the grind leaves RSI comfortably above it.
      expect(snap.rsi, greaterThan(65));
      expect(detectPattern(bars, snap), AiPattern.extendedUp);

      // Raise the threshold past the reading → the RSI zone stops qualifying.
      expect(
        detectPattern(bars, snap, overbought: snap.rsi + 1),
        isNot(AiPattern.extendedUp),
      );
    });

    test('too few bars to judge → range, never a guess', () {
      final bars = series(15, (i) => 100 + i.toDouble());
      expect(detectPattern(bars, buildSnapshot(bars)), AiPattern.range);
    });

    test('an orderly uptrend drifting under EMA9 is a pullback', () {
      // The snapshot is passed in by hand so the rule is judged on the moving
      // averages themselves, not on whatever a fixture happens to produce.
      final bars = series(
        60,
        (_) => 100.0,
      ).map((b) => Candle(
            time: b.time,
            open: 100,
            high: 101,
            low: 99,
            close: 100,
            volume: 1000,
          )).toList();

      const snap = AiSnapshot(
        ltp: 100,
        rsi: 55,
        ema9: 102,
        ema21: 98,
        sma50: 90,
        high52w: 101,
        low52w: 99,
        atr: 1,
        atrPct: 1,
        volumeRatio: 1,
        return3m: 8,
        turnoverCrore: 25,
        bars: 60,
      );

      expect(snap.stackUp, isTrue); // ema9 > ema21 > sma50
      expect(detectPattern(bars, snap), AiPattern.pullback);

      // The mirror image: a downtrend bouncing above EMA9.
      const downSnap = AiSnapshot(
        ltp: 100,
        rsi: 55,
        ema9: 98,
        ema21: 102,
        sma50: 110,
        high52w: 101,
        low52w: 99,
        atr: 1,
        atrPct: 1,
        volumeRatio: 1,
        return3m: -8,
        turnoverCrore: 25,
        bars: 60,
      );
      expect(downSnap.stackDown, isTrue);
      expect(detectPattern(bars, downSnap), AiPattern.bounce);
    });

    test('nothing to report → range, and the card says so plainly', () {
      final bars = series(60, (i) => 100.0 + (i % 3).toDouble());
      final snap = AiSnapshot(
        ltp: bars.last.close,
        rsi: 50,
        ema9: 100,
        ema21: 100,
        sma50: 100,
        high52w: 102,
        low52w: 100,
        atr: 1,
        atrPct: 1,
        volumeRatio: 1,
        return3m: 0,
        turnoverCrore: 25,
        bars: 60,
      );
      expect(detectPattern(bars, snap), AiPattern.range);
    });
  });

  group('isHigherHigh / greenShare', () {
    test('higher high needs a higher low too', () {
      final up = [bar(0, 100, high: 100, low: 99), bar(1, 101, high: 101, low: 100)];
      expect(isHigherHigh(up), isTrue);

      final mixed = [bar(0, 100, high: 100, low: 98), bar(1, 101, high: 101, low: 97)];
      expect(isHigherHigh(mixed), isFalse);

      expect(isHigherHigh([bar(0, 100)]), isFalse);
    });

    test('greenShare counts green closes in the window', () {
      final bars = series(5, (i) => 100.0 + i.toDouble()); // 4 green closes
      expect(greenShare(bars), closeTo(1, 1e-9));

      final down = series(5, (i) => 100.0 - i.toDouble());
      expect(greenShare(down), closeTo(0, 1e-9));

      final mixed = series(5, (i) => [100.0, 101, 100, 101, 100][i].toDouble());
      expect(greenShare(mixed), closeTo(0.5, 1e-9));
    });
  });

  group('momentumScore', () {
    AiSnapshot snapOf({
      double ltp = 100,
      double rsi = 60,
      double return3m = 10,
      double volumeRatio = 1,
      double high52w = 100,
    }) =>
        AiSnapshot(
          ltp: ltp,
          rsi: rsi,
          ema9: 0,
          ema21: 0,
          sma50: 0,
          high52w: high52w,
          low52w: 0,
          atr: 0,
          atrPct: 0,
          volumeRatio: volumeRatio,
          return3m: return3m,
          turnoverCrore: 30,
          bars: 70,
        );

    double score(AiSnapshot snap, {double volumeSpike = 1.5}) => momentumScore(
          snap,
          oversold: 35,
          overbought: 65,
          volumeSpike: volumeSpike,
          nearHighPct: 5,
          greenRatio: 0.5,
          upMonths: 2,
        );

    test('stays inside 0…100', () {
      expect(score(snapOf(rsi: 90, return3m: -80, volumeRatio: 0.1)),
          inInclusiveRange(0, 100));
      expect(score(snapOf(rsi: 10, return3m: 80, volumeRatio: 9)),
          inInclusiveRange(0, 100));
    });

    test('a stronger 3-month trend scores higher', () {
      expect(score(snapOf(return3m: 20)), greaterThan(score(snapOf(return3m: 5))));
    });

    test('nearer the 52-week high scores higher', () {
      final near = snapOf(ltp: 99, high52w: 100); // 1 % below
      final far = snapOf(ltp: 80, high52w: 100); // 20 % below
      expect(score(near), greaterThan(score(far)));
    });

    test('stocks 8 % and 30 % below the high do NOT tie at zero', () {
      // Regression: the position term used to be scaled by the user's 5 %
      // "near high" band, so anything more than 5 % below the high scored 0 of
      // 20 — the list collapsed to the two or three names sitting AT their
      // highs. It is now scored over a fixed 25 % band.
      final just = snapOf(ltp: 92, high52w: 100); // 8 % below
      final deep = snapOf(ltp: 70, high52w: 100); // 30 % below
      expect(score(just), greaterThan(score(deep)));
      expect(score(just) - score(deep), greaterThan(5));

      // And the user's band still does what it says for the *label*: changing
      // it must not move the score any more.
      expect(
        momentumScore(just,
            oversold: 35,
            overbought: 65,
            volumeSpike: 1.5,
            nearHighPct: 1,
            greenRatio: 0.5,
            upMonths: 2),
        closeTo(score(just), 1e-9),
      );
    });

    test('volume above the user threshold scores higher — and the threshold is '
        'the user\'s', () {
      final quiet = snapOf(volumeRatio: 1);
      final loud = snapOf(volumeRatio: 3);
      expect(score(loud), greaterThan(score(quiet)));

      // Raising the bar to 5x makes that same 3x volume worth less.
      expect(score(loud, volumeSpike: 5), lessThan(score(loud, volumeSpike: 1.5)));
    });

    test('the RSI the user calls overbought changes the score', () {
      final hot = snapOf(rsi: 70);

      // 70 is overbought at the default 65 → the score fades it…
      final asOverbought = momentumScore(hot,
          oversold: 35,
          overbought: 65,
          volumeSpike: 1.5,
          nearHighPct: 5,
          greenRatio: 0.5,
          upMonths: 2);

      // …and is not overbought at all once the user moves the line to 75.
      final asNormal = momentumScore(hot,
          oversold: 35,
          overbought: 75,
          volumeSpike: 1.5,
          nearHighPct: 5,
          greenRatio: 0.5,
          upMonths: 2);

      expect(asNormal, greaterThan(asOverbought));
    });

    test('one freak move cannot own the list (trend capped at ±40 %)', () {
      final huge = snapOf(return3m: 400);
      final big = snapOf(return3m: 40);
      expect(score(huge), closeTo(score(big), 1e-9));
    });
  });
}
