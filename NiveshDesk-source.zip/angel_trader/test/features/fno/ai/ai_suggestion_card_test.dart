// ---------------------------------------------------------------------------
// ai_suggestion_card_test.dart — the card is the deliverable, so it is pinned
// here as rendered output.
//
// The brief lists the fields in a fixed order (Rank, Stock, Direction, Expected
// Movement, Technical Rationale, Options Strategy → Action / Strategy / Strike
// Type / Pair). A UI change that drops or reorders one of them fails this file.
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/theme/app_theme.dart';
import 'package:angel_trader/features/fno/ai/ai_indicators.dart';
import 'package:angel_trader/features/fno/ai/ai_plan.dart';
import 'package:angel_trader/features/fno/ai/ai_suggestion.dart';
import 'package:angel_trader/features/fno/ai/ai_suggestion_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

AiSnapshot _snap() => const AiSnapshot(
      ltp: 1482.30,
      rsi: 61.4,
      ema9: 1470,
      ema21: 1440,
      sma50: 1390,
      high52w: 1600, // above the plan's target, so the target is not capped
      low52w: 1100,
      atr: 27,
      atrPct: 1.8,
      volumeRatio: 2.1,
      return3m: 8.4,
      turnoverCrore: 42.5,
      bars: 70,
    );

AiSuggestion _row({
  AiDirection direction = AiDirection.bullish,
  AiStrategy? strategy,
  AiOptionContext? options,

  /// `false` builds a row the scan could not price — no premium, no lot.
  bool withOptions = true,
  DateTime? resultDate,
  bool resultConfirmed = false,
  AiTradePlan? plan,
}) =>
    AiSuggestion(
      symbol: 'RELIANCE',
      name: 'Reliance Industries Ltd',
      rank: 1,
      score: 72.4,
      studyScore: 9.5,
      snapshot: _snap(),
      pattern: AiPattern.breakout,
      direction: direction,
      move: AiMove.breakout,
      rationale: const [
        'RSI 61',
        '+8.4% 3 mahine me',
        'volume 2.1x',
      ],
      strategy: strategy ??
          const AiStrategy(
            action: 'Buy',
            name: 'Directional Buy',
            strikeType: 'ATM',
            pair: 'CE 1480',
            why: 'Uptrend + RSI 61 · seedha CE kharidna sabse simple hai.',
          ),
      options: withOptions
          ? (options ??
              const AiOptionContext(
                atmStrike: 1480,
                otmCeStrike: 1520,
                otmPeStrike: 1440,
                avgIv: 19.6,
                straddleTotal: 31.5,
                lotSize: 250,
              ))
          : null,
      resultDate: resultDate,
      resultConfirmed: resultConfirmed,
      plan: plan,
    );

Future<void> _pumpCard(
  WidgetTester tester,
  AiSuggestion row, {
  DateTime? today,
}) async {
  await tester.pumpWidget(
    MaterialApp(
      theme: AppTheme.light(),
      home: Scaffold(
        body: SingleChildScrollView(
          child: AiSuggestionCard(row: row, today: today),
        ),
      ),
    ),
  );
  await tester.pumpAndSettle();
}

void main() {
  testWidgets('every field the brief asks for is on the card', (tester) async {
    await _pumpCard(tester, _row());

    // 1 + 2: rank and stock (ticker plus company name).
    expect(find.text('1'), findsOneWidget);
    expect(find.text('RELIANCE'), findsOneWidget);
    expect(find.text('Reliance Industries Ltd'), findsOneWidget);

    // 3: direction, in both languages.
    expect(find.text('Direction'), findsOneWidget);
    expect(find.text('Bullish (upar)'), findsOneWidget);

    // 4: expected movement.
    expect(find.text('Expected movement'), findsOneWidget);
    expect(find.text('Strong Breakout'), findsOneWidget);

    // 5: the technical reason, with its numbers.
    expect(find.text('Technical rationale'), findsOneWidget);
    expect(
      find.text('RSI 61 · +8.4% 3 mahine me · volume 2.1x'),
      findsOneWidget,
    );

    // 6: the option trade — four labelled lines.
    expect(find.text('OPTIONS STRATEGY'), findsOneWidget);
    expect(find.text('Action'), findsOneWidget);
    expect(find.text('Buy'), findsWidgets);
    expect(find.text('Strategy'), findsOneWidget);
    expect(find.text('Directional Buy'), findsOneWidget);
    expect(find.text('Strike type'), findsOneWidget);
    expect(find.text('ATM'), findsOneWidget);
    expect(find.text('Suggested jodi'), findsOneWidget);
    expect(find.text('CE 1480'), findsOneWidget);

    // The premium and the lot, because that is what the trade costs.
    expect(find.text('IV 20% · jodi ₹31.50'), findsOneWidget);
    expect(find.text('lot 250'), findsOneWidget);
  });

  testWidgets('a sell idea carries the risk warning', (tester) async {
    await _pumpCard(
      tester,
      _row(
        direction: AiDirection.sideways,
        strategy: const AiStrategy(
          action: 'Sell',
          name: 'Strangle (OTM jodi)',
          strikeType: 'OTM',
          pair: 'CE 1520 + PE 1440 becho',
          why: 'Range + premium mehengi — premium likhne ka mauka.',
        ),
      ),
    );

    expect(find.text('Sell'), findsWidgets);
    expect(find.text('CE 1520 + PE 1440 becho'), findsOneWidget);
    expect(
      find.text(
        'Ye premium likhne (sell) wali strategy hai — nuksan bada ho sakta '
        'hai. Pehle paper trade me azmao.',
      ),
      findsOneWidget,
    );
  });

  testWidgets('"wait" is shown as a decision, not a blank card', (tester) async {
    await _pumpCard(
      tester,
      _row(
        strategy: AiStrategy.none,
        withOptions: false,
      ),
    );

    expect(find.text('Wait'), findsWidgets);
    expect(find.text('Koi trade nahi'), findsOneWidget);
    expect(find.text('—'), findsWidgets);
    // No premium/lot chips when nothing was priced.
    expect(find.text('lot 250'), findsNothing);
  });

  testWidgets('turnover and the upcoming result are on the card', (tester) async {
    final today = DateTime(2026, 10, 9);
    const options = AiOptionContext(
      atmStrike: 1480,
      avgIv: 19.6,
      straddleTotal: 31.5,
      lotSize: 250,
      daysToExpiry: 20,
      daysToResult: 3,
    );
    // The engine's answer for a row whose result is 3 days out — the card just
    // has to show it.
    final strategy = resolveStrategy(
      direction: AiDirection.bullish,
      pattern: AiPattern.breakout,
      snap: _snap(),
      options: options,
    );

    await _pumpCard(
      tester,
      _row(
        options: options,
        strategy: strategy,
        resultDate: today.add(const Duration(days: 3)),
        resultConfirmed: true,
      ),
      today: today,
    );

    // Liquidity, because a thin stock's breakout is not a trade.
    expect(find.text('turnover ₹42.5 cr'), findsOneWidget);
    // The event, because it is the one thing that can make a right direction
    // lose money.
    expect(find.text('Result: 3 din me'), findsOneWidget);
    // …and the trade is refused while the result is that close.
    expect(find.text('Wait'), findsWidgets);
    expect(
      find.textContaining('Result 3 din me hai'),
      findsOneWidget,
    );
  });

  testWidgets('the trade plan is on the card: entry, stop, target, size',
      (tester) async {
    await _pumpCard(
      tester,
      _row(
        plan: buildTradePlan(
          snap: _snap(),
          direction: AiDirection.bullish,
          pattern: AiPattern.breakout,
          premium: 31.5,
          lotSize: 250,
          capital: 1000000,
          riskPct: 1.5,
        ),
      ),
    );

    expect(find.text('TRADE PLAN'), findsOneWidget);
    // CMP 1482.30, ATR 27 → breakout entry 1489.05, stop 1462.05, target
    // 1543.05 (risk 27, reward 54 → 1 : 2).
    expect(find.text('₹1489.05 ke upar (CMP ₹1482.30)'), findsOneWidget);
    expect(find.text('₹1462.05 (-1.8%)'), findsOneWidget);
    expect(find.text('₹1543.05 (+3.6%)'), findsOneWidget); // a stop is never "+"
    expect(find.text('₹1462.05 (+1.8%)'), findsNothing);
    expect(find.text('1 : 2.0'), findsOneWidget);
    // Premium 31.5 → stop 18.90, target 56.70; lot 250 = ₹7,875.
    expect(find.text('₹18.90 / ₹56.70'), findsOneWidget);
    expect(find.text('250 qty · ₹7875'), findsOneWidget);
    expect(
      find.text('₹3150 = capital ka 0.3%'), // no floating-point dust
      findsOneWidget,
    );
    // 1.5 % of ₹10,00,000 = ₹15,000 ÷ ₹3,150 a lot → 4 lots.
    expect(find.text('4 lot (1.5% niyam)'), findsOneWidget);
  });

  testWidgets('a plan that breaks the risk budget says so', (tester) async {
    await _pumpCard(
      tester,
      _row(
        plan: buildTradePlan(
          snap: _snap(),
          direction: AiDirection.bullish,
          pattern: AiPattern.breakout,
          premium: 31.5,
          lotSize: 250,
          capital: 100000, // small account: one lot is 7.9 % of it
          riskPct: 1.5,
        ),
      ),
    );

    expect(
      find.text('1 lot bhi limit se upar — chhod do ya filter dhila karo'),
      findsOneWidget,
    );
  });

  testWidgets('a bearish card points at puts', (tester) async {
    await _pumpCard(
      tester,
      _row(
        direction: AiDirection.bearish,
        strategy: const AiStrategy(
          action: 'Buy',
          name: 'Directional Buy',
          strikeType: 'ATM',
          pair: 'PE 1480',
          why: 'Downtrend — seedha PE kharidna sabse simple hai.',
        ),
      ),
    );

    expect(find.text('Bearish (neeche)'), findsOneWidget);
    expect(find.text('PE 1480'), findsOneWidget);
  });
}
