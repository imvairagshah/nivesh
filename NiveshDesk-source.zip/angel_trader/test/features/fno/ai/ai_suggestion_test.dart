// ---------------------------------------------------------------------------
// ai_suggestion_test.dart — the rules that turn a read into a trade.
//
// The whole point of a rule engine is that the rules can be argued with, so
// they live in one file and are pinned here case by case: which direction, which
// phrase, and — the part that costs money — which option trade.
// ---------------------------------------------------------------------------

import 'package:angel_trader/features/fno/ai/ai_indicators.dart';
import 'package:angel_trader/features/fno/ai/ai_suggestion.dart';
import 'package:flutter_test/flutter_test.dart';

AiSnapshot snap({
  double ltp = 100,
  double rsi = 60,
  double atrPct = 2,
  double atr = 2,
  double ema9 = 101,
  double ema21 = 99,
  double sma50 = 95,
  double high52w = 105,
  double low52w = 80,
  double volumeRatio = 1.2,
  double return3m = 8,
  int bars = 70,
}) =>
    AiSnapshot(
      ltp: ltp,
      rsi: rsi,
      ema9: ema9,
      ema21: ema21,
      sma50: sma50,
      high52w: high52w,
      low52w: low52w,
      atr: atr,
      atrPct: atrPct,
      volumeRatio: volumeRatio,
      return3m: return3m,
      turnoverCrore: 25,
      bars: bars,
    );

/// An option book where the 100 strike is ATM and the 110/90 strikes are OTM.
AiOptionContext options({
  double atmStrike = 100,
  double? otmCe,
  double? otmPe,
  double? avgIv = 20,
  double? straddleTotal = 8,
  bool expensive = false,
  int lotSize = 75,

  /// 20 days by default: long enough for a buyer, short enough for a seller.
  int daysToExpiry = 20,
}) =>
    AiOptionContext(
      atmStrike: atmStrike,
      otmCeStrike: otmCe,
      otmPeStrike: otmPe,
      avgIv: avgIv,
      straddleTotal: straddleTotal,
      ivExpensive: expensive,
      lotSize: lotSize,
      daysToExpiry: daysToExpiry,
    );

void main() {
  group('AiFilters', () {
    test('defaults are the ones Settings ships with', () {
      const f = AiFilters.defaults;
      expect(f.rsiOversold, 35);
      expect(f.rsiOverbought, 65);
      expect(f.volumeSpike, 1.5);
      expect(f.nearHighPct, 5);
      expect(f.minStudyScore, 5);
      expect(f.minScore, 45);
      expect(f.topN, 20);
    });

    test('copyWith changes only what it is told to', () {
      final moved = AiFilters.defaults.copyWith(rsiOversold: 45, topN: 5);
      expect(moved.rsiOversold, 45);
      expect(moved.topN, 5);
      expect(moved.rsiOverbought, 65); // untouched
      expect(moved.minScore, 45); // untouched
    });
  });

  group('resolveDirection', () {
    test('a rising stack with a rising 3-month return is bullish', () {
      final s = snap(return3m: 12);
      expect(s.stackUp, isTrue);
      expect(resolveDirection(s, s.return3m, true), AiDirection.bullish);
    });

    test('a falling stack with a falling return is bearish', () {
      final s = snap(
        return3m: -12,
        ema9: 90,
        ema21: 95,
        sma50: 100,
      );
      expect(s.stackDown, isTrue);
      expect(resolveDirection(s, s.return3m, false), AiDirection.bearish);
    });

    test('a flat market is sideways, not a coin flip', () {
      final s = snap(return3m: 0.4, ema9: 100, ema21: 100, sma50: 100);
      expect(resolveDirection(s, s.return3m, false), AiDirection.sideways);
    });

    test('an uptrend whose averages have rolled over is not called bullish', () {
      // The quarter is still (just) up, but the 9/21/50 stack has turned down —
      // the averages are the fresher signal, so they get the last word.
      final s = snap(return3m: 0.5, ema9: 90, ema21: 95, sma50: 100);
      expect(s.stackDown, isTrue);
      expect(resolveDirection(s, s.return3m, true), AiDirection.sideways);
    });

    test('…but a quarter that is strongly up still beats a fresh roll-over', () {
      final s = snap(return3m: 14, ema9: 90, ema21: 95, sma50: 100);
      expect(resolveDirection(s, s.return3m, true), AiDirection.bullish);
    });
  });

  group('resolveMove', () {
    test('each pattern gets its own plain phrase', () {
      expect(resolveMove(AiPattern.breakout, AiDirection.bullish),
          AiMove.breakout);
      expect(resolveMove(AiPattern.breakdown, AiDirection.bearish),
          AiMove.breakdown);
      expect(resolveMove(AiPattern.pullback, AiDirection.bullish),
          AiMove.pullback);
      expect(resolveMove(AiPattern.bounce, AiDirection.bearish), AiMove.bounce);
      expect(resolveMove(AiPattern.extendedUp, AiDirection.bullish),
          AiMove.cooling);
      expect(resolveMove(AiPattern.range, AiDirection.sideways),
          AiMove.consolidation);
    });

    test('an oversold stock in an uptrend is read as a bounce, not a breakdown',
        () {
      expect(resolveMove(AiPattern.extendedDown, AiDirection.bullish),
          AiMove.gapUp);
      expect(resolveMove(AiPattern.extendedDown, AiDirection.bearish),
          AiMove.bounce);
    });
  });

  group('resolveStrategy', () {
    test('no option data → no trade, and it says why', () {
      final strategy = resolveStrategy(
        direction: AiDirection.bullish,
        pattern: AiPattern.breakout,
        snap: snap(),
        options: const AiOptionContext(),
      );
      expect(strategy, same(AiStrategy.none));
      expect(strategy.wait, isTrue);
      expect(strategy.why, contains('data nahi mila'));
    });

    test('bullish + reasonably priced premium → buy the ATM call', () {
      final strategy = resolveStrategy(
        direction: AiDirection.bullish,
        pattern: AiPattern.pullback,
        snap: snap(),
        options: options(otmCe: 110, otmPe: 90, expensive: false),
      );
      expect(strategy.action, 'Buy');
      expect(strategy.name, 'Directional Buy');
      expect(strategy.strikeType, 'ATM');
      expect(strategy.pair, 'CE 100');
      expect(strategy.wait, isFalse);
    });

    test('bullish + dear premium → bull call spread (ATM buy, OTM sell)', () {
      final strategy = resolveStrategy(
        direction: AiDirection.bullish,
        pattern: AiPattern.pullback,
        snap: snap(),
        options: options(otmCe: 110, otmPe: 90, expensive: true),
      );
      expect(strategy.action, 'Buy');
      expect(strategy.name, 'Bull Call Spread');
      expect(strategy.strikeType, 'ATM + OTM');
      expect(strategy.pair, 'CE 100 kharido · CE 110 becho');
    });

    test('a breakout on a big ATR → straddle (both sides)', () {
      final strategy = resolveStrategy(
        direction: AiDirection.bullish,
        pattern: AiPattern.breakout,
        snap: snap(atrPct: 3.2),
        options: options(expensive: true),
      );
      expect(strategy.action, 'Buy');
      expect(strategy.name, 'Straddle (ATM jodi)');
      expect(strategy.pair, 'CE 100 + PE 100');
      // The ATR is quoted back, so the reason can be checked.
      expect(strategy.why, contains('3.2%'));
    });

    test('a breakout on a small ATR is NOT a straddle', () {
      final strategy = resolveStrategy(
        direction: AiDirection.bullish,
        pattern: AiPattern.breakout,
        snap: snap(atrPct: 1.1),
        options: options(expensive: true),
      );
      expect(strategy.name, isNot('Straddle (ATM jodi)'));
    });

    test('bearish mirrors with puts', () {
      final cheap = resolveStrategy(
        direction: AiDirection.bearish,
        pattern: AiPattern.pullback,
        snap: snap(),
        options: options(otmCe: 110, otmPe: 90, expensive: false),
      );
      expect(cheap.name, 'Directional Buy');
      expect(cheap.pair, 'PE 100');

      final rich = resolveStrategy(
        direction: AiDirection.bearish,
        pattern: AiPattern.pullback,
        snap: snap(),
        options: options(otmCe: 110, otmPe: 90, expensive: true),
      );
      expect(rich.name, 'Bear Put Spread');
      expect(rich.pair, 'PE 100 kharido · PE 90 becho');

      final crash = resolveStrategy(
        direction: AiDirection.bearish,
        pattern: AiPattern.breakdown,
        snap: snap(atrPct: 4),
        options: options(expensive: true),
      );
      expect(crash.name, 'Straddle (ATM jodi)');
    });

    test('sideways + dear premium → sell the OTM strangle', () {
      final strategy = resolveStrategy(
        direction: AiDirection.sideways,
        pattern: AiPattern.range,
        snap: snap(),
        options: options(otmCe: 110, otmPe: 90, expensive: true),
      );
      expect(strategy.action, 'Sell');
      expect(strategy.name, 'Strangle (OTM jodi)');
      expect(strategy.strikeType, 'OTM');
      expect(strategy.pair, 'CE 110 + PE 90 becho');
      expect(strategy.why, contains('Risk bada'));
    });

    test('sideways + cheap premium → wait, not a forced trade', () {
      final strategy = resolveStrategy(
        direction: AiDirection.sideways,
        pattern: AiPattern.range,
        snap: snap(),
        options: options(otmCe: 110, otmPe: 90, expensive: false),
      );
      expect(strategy.action, 'Wait');
      expect(strategy.wait, isTrue);
      expect(strategy.pair, '—');
    });

    test('the lot size is spelled out, because that is what the trade costs',
        () {
      final strategy = resolveStrategy(
        direction: AiDirection.bullish,
        pattern: AiPattern.pullback,
        snap: snap(),
        options: options(expensive: false, lotSize: 1425),
      );
      expect(strategy.why, contains('1 lot = 1425 qty'));
    });

    test('without an OTM pick the spread falls back to the ATM strike', () {
      final strategy = resolveStrategy(
        direction: AiDirection.bullish,
        pattern: AiPattern.pullback,
        snap: snap(),
        options: options(expensive: true), // no otm strikes resolved
      );
      expect(strategy.pair, 'CE 100 kharido · CE 100 becho');
    });
  });

  group('event and liquidity rules', () {
    test('a confirmed result inside the window stops both buys and sells',
        () {
      const soon = AiOptionContext(
        atmStrike: 100,
        otmCeStrike: 110,
        otmPeStrike: 90,
        lotSize: 75,
        daysToExpiry: 20,
        daysToResult: 3,
      );

      final buy = resolveStrategy(
        direction: AiDirection.bullish,
        pattern: AiPattern.pullback,
        snap: snap(),
        options: soon,
      );
      expect(buy.action, 'Wait');
      expect(buy.pair, '—');
      expect(buy.why, contains('Result 3 din me'));
      expect(buy.why, contains('IV crush'));

      final sell = resolveStrategy(
        direction: AiDirection.sideways,
        pattern: AiPattern.range,
        snap: snap(),
        options: const AiOptionContext(
          atmStrike: 100,
          otmCeStrike: 110,
          otmPeStrike: 90,
          lotSize: 75,
          daysToExpiry: 20,
          daysToResult: 3,
          ivExpensive: true,
        ),
      );
      expect(sell.action, 'Wait');
      expect(sell.why, contains('gap'));
    });

    test('a result beyond the window does not stop the trade', () {
      const later = AiOptionContext(
        atmStrike: 100,
        lotSize: 75,
        daysToExpiry: 20,
        daysToResult: 12,
      );
      final buy = resolveStrategy(
        direction: AiDirection.bullish,
        pattern: AiPattern.pullback,
        snap: snap(),
        options: later,
      );
      expect(buy.action, 'Buy');
    });

    test('a result AFTER expiry is no reason to wait — the option is gone',
        () {
      // Option expires in 10 days, result is 12 days out: no crush, no gap.
      const afterExpiry = AiOptionContext(
        atmStrike: 100,
        lotSize: 75,
        daysToExpiry: 10,
        daysToResult: 12,
      );
      final buy = resolveStrategy(
        direction: AiDirection.bullish,
        pattern: AiPattern.pullback,
        snap: snap(),
        options: afterExpiry,
      );
      expect(buy.action, 'Buy');
      expect(buy.pair, 'CE 100');
    });

    test('the window the user sets is the window that applies', () {
      const fourDays = AiOptionContext(
        atmStrike: 100,
        lotSize: 75,
        daysToExpiry: 30,
        daysToResult: 4,
      );
      final strict = resolveStrategy(
        direction: AiDirection.bullish,
        pattern: AiPattern.pullback,
        snap: snap(),
        options: fourDays,
        filters: AiFilters.defaults.copyWith(eventBlockDays: 1),
      );
      expect(strict.action, 'Buy'); // 4 din door hai, 1 din ki chhutti

      final loose = resolveStrategy(
        direction: AiDirection.bullish,
        pattern: AiPattern.pullback,
        snap: snap(),
        options: fourDays,
        filters: AiFilters.defaults.copyWith(eventBlockDays: 5),
      );
      expect(loose.action, 'Wait');
    });

    test('a premium too thin to fill is refused', () {
      const thin = AiOptionContext(
        atmStrike: 100,
        lotSize: 75,
        daysToExpiry: 12,
        thin: true,
      );
      final buy = resolveStrategy(
        direction: AiDirection.bullish,
        pattern: AiPattern.pullback,
        snap: snap(),
        options: thin,
      );
      expect(buy.action, 'Wait');
      expect(buy.why, contains('patla'));
    });

    test('the result line is plain, and silent when nothing is announced', () {
      final today = DateTime(2026, 10, 9);

      AiSuggestion rowWith(DateTime? date, bool confirmed) => AiSuggestion(
            symbol: 'RELIANCE',
            name: '',
            rank: 1,
            score: 70,
            studyScore: 8,
            snapshot: snap(),
            pattern: AiPattern.range,
            direction: AiDirection.bullish,
            move: AiMove.consolidation,
            rationale: const ['RSI 60'],
            strategy: AiStrategy.none,
            resultDate: date,
            resultConfirmed: confirmed,
          );

      expect(rowWith(today, true).resultLine(today), 'Result: aaj');
      expect(rowWith(today.add(const Duration(days: 1)), true).resultLine(today),
          'Result: kal');
      expect(rowWith(today.add(const Duration(days: 12)), true).resultLine(today),
          'Result: 12 din me');
      // An unconfirmed (guessed) date is never shown.
      expect(rowWith(today.add(const Duration(days: 3)), false).resultLine(today),
          '');
      expect(rowWith(null, false).resultLine(today), '');
    });

    test('defaults carry the liquidity bar and the event window', () {
      expect(AiFilters.defaults.minTurnoverCrore, 10);
      expect(AiFilters.defaults.eventBlockDays, 5);
    });
  });

  group('days-to-expiry rules', () {
    test('a buy with too few days left is refused — theta is heavier', () {
      final buy = resolveStrategy(
        direction: AiDirection.bullish,
        pattern: AiPattern.pullback,
        snap: snap(),
        options: options(daysToExpiry: 3),
      );
      expect(buy.action, 'Wait');
      expect(buy.why, contains('theta'));
      expect(buy.why, contains('3 din'));
    });

    test("the bar is exactly the user's bar", () {
      final atTheLine = resolveStrategy(
        direction: AiDirection.bullish,
        pattern: AiPattern.pullback,
        snap: snap(),
        options: options(daysToExpiry: 7),
      );
      expect(atTheLine.action, 'Buy'); // 7 ≥ 7

      final stricter = resolveStrategy(
        direction: AiDirection.bullish,
        pattern: AiPattern.pullback,
        snap: snap(),
        options: options(daysToExpiry: 7),
        filters: AiFilters.defaults.copyWith(buyMinDte: 15),
      );
      expect(stricter.action, 'Wait');
    });

    test('expiry day itself: nothing new is opened', () {
      final buy = resolveStrategy(
        direction: AiDirection.bullish,
        pattern: AiPattern.breakout,
        snap: snap(atrPct: 3.5),
        options: options(daysToExpiry: 0, expensive: true),
      );
      expect(buy.action, 'Wait');
      expect(buy.why, contains('Aaj expiry'));
    });

    test('a sell needs the clock running, but not for too long', () {
      final tooFar = resolveStrategy(
        direction: AiDirection.sideways,
        pattern: AiPattern.range,
        snap: snap(),
        options: options(daysToExpiry: 45, expensive: true),
      );
      expect(tooFar.action, 'Wait');
      expect(tooFar.why, contains('theta'));

      final tooClose = resolveStrategy(
        direction: AiDirection.sideways,
        pattern: AiPattern.range,
        snap: snap(),
        options: options(daysToExpiry: 2, expensive: true),
      );
      expect(tooClose.action, 'Wait');
      expect(tooClose.why, contains('gap'));

      final right = resolveStrategy(
        direction: AiDirection.sideways,
        pattern: AiPattern.range,
        snap: snap(),
        options: options(
          daysToExpiry: 12,
          expensive: true,
          otmCe: 110,
          otmPe: 90,
        ),
      );
      expect(right.action, 'Sell');
      expect(right.name, 'Strangle (OTM jodi)');
    });

    test("the sell window is the user's too", () {
      final wide = resolveStrategy(
        direction: AiDirection.sideways,
        pattern: AiPattern.range,
        snap: snap(),
        options: options(daysToExpiry: 30, expensive: true, otmCe: 110, otmPe: 90),
        filters: AiFilters.defaults.copyWith(sellMaxDte: 40),
      );
      expect(wide.action, 'Sell');
    });

    test('defaults: 7 days for a buy, 20 for a sell, 1.5 % risk', () {
      expect(AiFilters.defaults.buyMinDte, 7);
      expect(AiFilters.defaults.sellMaxDte, 20);
      expect(AiFilters.defaults.riskPct, 1.5);
    });
  });

  group('buildRationale', () {
    const filters = AiFilters.defaults;

    test('always leads with RSI and the 3-month return', () {
      final lines = buildRationale(
        snap: snap(rsi: 61, return3m: 8.42),
        pattern: AiPattern.range,
        direction: AiDirection.bullish,
        return3m: 8.42,
        upMonths: 0,
        filters: filters,
      );
      expect(lines.first, 'RSI 61');
      expect(lines[1], '+8.4% 3 mahine me');
    });

    test('a fall is signed, never shown as a positive move', () {
      final lines = buildRationale(
        snap: snap(return3m: -6.2),
        pattern: AiPattern.range,
        direction: AiDirection.bearish,
        return3m: -6.2,
        upMonths: 0,
        filters: filters,
      );
      expect(lines[1], '-6.2% 3 mahine me');
    });

    test('volume and near-high lines appear only when the user\'s thresholds '
        'say so', () {
      final quiet = buildRationale(
        snap: snap(volumeRatio: 1.1), // below the 1.5x bar
        pattern: AiPattern.range,
        direction: AiDirection.bullish,
        return3m: 3,
        upMonths: 0,
        filters: filters,
      );
      expect(quiet.join(' '), isNot(contains('volume')));

      final loud = buildRationale(
        snap: snap(volumeRatio: 2.4),
        pattern: AiPattern.range,
        direction: AiDirection.bullish,
        return3m: 3,
        upMonths: 0,
        filters: filters,
      );
      expect(loud.join(' '), contains('volume 2.4x'));

      // Move the bar to 3x and the same 2.4x stops qualifying.
      final stricter = buildRationale(
        snap: snap(volumeRatio: 2.4),
        pattern: AiPattern.range,
        direction: AiDirection.bullish,
        return3m: 3,
        upMonths: 0,
        filters: filters.copyWith(volumeSpike: 3),
      );
      expect(stricter.join(' '), isNot(contains('volume')));
    });

    test('“near the 52-week high” obeys the user’s band', () {
      // 3 % below the high: inside the default 5 % band.
      final near = buildRationale(
        snap: snap(ltp: 100, high52w: 103),
        pattern: AiPattern.range,
        direction: AiDirection.bullish,
        return3m: 3,
        upMonths: 0,
        filters: filters,
      );
      expect(near.join(' '), contains('52w high se 2.9% neeche'));

      final tight = buildRationale(
        snap: snap(ltp: 100, high52w: 103),
        pattern: AiPattern.range,
        direction: AiDirection.bullish,
        return3m: 3,
        upMonths: 0,
        filters: filters.copyWith(nearHighPct: 1),
      );
      expect(tight.join(' '), isNot(contains('52w high')));
    });

    test('a sideways row carries its ATR so the range has a size', () {
      final lines = buildRationale(
        snap: snap(atrPct: 1.8),
        pattern: AiPattern.range,
        direction: AiDirection.sideways,
        return3m: 0.5,
        upMonths: 0,
        filters: filters,
      );
      expect(lines.join(' '), contains('ATR 1.8%'));
    });
  });

  group('AiSuggestion', () {
    test('copyWithRank keeps everything but the rank', () {
      final row = AiSuggestion(
        symbol: 'RELIANCE',
        name: 'Reliance Industries',
        rank: 7,
        score: 71.5,
        studyScore: 9,
        snapshot: snap(),
        pattern: AiPattern.breakout,
        direction: AiDirection.bullish,
        move: AiMove.breakout,
        rationale: const ['RSI 61'],
        strategy: AiStrategy.none,
      );
      final moved = row.copyWithRank(1);
      expect(moved.rank, 1);
      expect(moved.symbol, 'RELIANCE');
      expect(moved.score, 71.5);
      expect(moved.direction, AiDirection.bullish);
      expect(moved.rationaleLine, 'RSI 61');
    });
  });
}
