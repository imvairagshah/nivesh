// ---------------------------------------------------------------------------
// ai_backtest_test.dart — the hit-rate engine, checked by hand.
//
// The report is only worth anything if the arithmetic can be checked on a
// napkin, so every fixture here is a series whose outcome you can read off the
// numbers: entry 100, ATR 2 → stop 98, target 104. Nothing is "approximately
// fine" — the whole point of the file is that a rule can be counted.
//
// It also pins the one optimisation in the engine (the rolling gate): a gate
// that silently skipped signal bars would quietly shrink the sample, and a
// report with a hidden filter is worse than no report.
// ---------------------------------------------------------------------------

import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/features/fno/ai/ai_backtest.dart';
import 'package:angel_trader/features/fno/ai/ai_indicators.dart';
import 'package:angel_trader/features/fno/ai/ai_suggestion.dart';
import 'package:flutter_test/flutter_test.dart';

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

final DateTime kDay = DateTime(2025, 1, 1);

/// One bar. [volume] defaults to a quiet 10 lakh shares.
Candle bar(
  int dayIndex, {
  required double open,
  required double high,
  required double low,
  required double close,
  int volume = 1000000,
}) =>
    Candle(
      time: kDay.add(Duration(days: dayIndex)),
      open: open,
      high: high,
      low: low,
      close: close,
      volume: volume,
    );

/// A flat run at [price] — the canvas the signal bars are painted on.
List<Candle> flat(int count, {double price = 100, int volume = 1000000}) => [
      for (var i = 0; i < count; i++)
        bar(i, open: price, high: price, low: price, close: price, volume: volume),
    ];

/// ATR is the yardstick for every stop, so it is fixed by hand: a ±0.5 body on
/// every bar gives a true range of 1.0 → ATR 1.0 (not 2 — Wilder's ATR is the
/// average true range including the previous close).
List<Candle> flatWithAtr(
  int count, {
  double price = 100,
  int volume = 1000000,
}) =>
    [
      for (var i = 0; i < count; i++)
        bar(
          i,
          open: price - 0.5,
          high: price + 0.5,
          low: price - 0.5,
          close: price + (i % 2 == 0 ? 0.5 : -0.5),
          volume: volume,
        ),
    ];

const BtConfig kCfg = BtConfig(horizonBars: 10, atrMultiple: 1, rewardMultiple: 2);

/// A breakout signal with a fixed ATR of 2 — no dependence on the series.
BtSignal signal({
  AiPattern pattern = AiPattern.breakout,
  AiDirection direction = AiDirection.bullish,
  double atr = 2,
}) =>
    BtSignal(pattern: pattern, direction: direction, atr: atr);

void main() {
  // -------------------------------------------------------------------------
  // The trade itself
  // -------------------------------------------------------------------------
  group('trade outcome', () {
    test('a clean winner runs to the target: +2R', () {
      // Signal bar closes at 100; entry is the NEXT open (100); ATR 2 →
      // stop 98, target 104. Bar 2 runs straight through 104.
      final bars = <Candle>[
        ...flat(2),
        bar(2, open: 100, high: 106, low: 99, close: 105),
        ...flat(9, price: 105),
      ];

      final trade = evaluateAt(bars, 0, signal(), config: kCfg, symbol: 'X')!;

      expect(trade.entry, 100);
      expect(trade.stop, 98);
      expect(trade.target, 104);
      expect(trade.exit, BtExit.target);
      expect(trade.exitPrice, 104);
      expect(trade.rMultiple, closeTo(2, 1e-9));
      expect(trade.returnPct, closeTo(4, 1e-9)); // +4 % on a 100 entry
      expect(trade.barsHeld, 2);
      expect(trade.rightDirection, isTrue);
    });

    test('a loser hits the stop: −1R', () {
      final bars = <Candle>[
        ...flat(2),
        bar(2, open: 100, high: 100.5, low: 95, close: 96),
        ...flat(9, price: 96),
      ];

      final trade = evaluateAt(bars, 0, signal(), config: kCfg, symbol: 'X')!;

      expect(trade.exit, BtExit.stop);
      expect(trade.exitPrice, 98);
      expect(trade.rMultiple, closeTo(-1, 1e-9));
      expect(trade.rightDirection, isFalse);
    });

    test('nothing happens: the trade is marked at the horizon', () {
      final bars = <Candle>[
        ...flat(2), // entry bar
        ...flat(10, price: 101), // drifts +1, no level touched
      ];

      final trade = evaluateAt(bars, 0, signal(), config: kCfg, symbol: 'X')!;

      expect(trade.exit, BtExit.horizon);
      expect(trade.exitPrice, 101);
      expect(trade.rMultiple, closeTo(0.5, 1e-9)); // +1 on a risk of 2
      expect(trade.returnPct, closeTo(1, 1e-9));
      expect(trade.barsHeld, 10);
    });

    test('a bearish trade is the mirror image', () {
      final bars = <Candle>[
        ...flat(2),
        bar(2, open: 100, high: 100.5, low: 94, close: 94.5),
        ...flat(9, price: 94),
      ];

      final trade = evaluateAt(
        bars,
        0,
        signal(pattern: AiPattern.breakdown, direction: AiDirection.bearish),
        config: kCfg,
        symbol: 'X',
      )!;

      expect(trade.stop, 102);
      expect(trade.target, 96);
      expect(trade.exit, BtExit.target);
      expect(trade.exitPrice, 96);
      expect(trade.rMultiple, closeTo(2, 1e-9));
      expect(trade.returnPct, closeTo(4, 1e-9)); // −4 % of price = +4 % for a short
    });

    test('a gap through the stop is counted at the open, not at the stop', () {
      // Honesty test: a gap-down opens at 90, well below the 98 stop. The loss
      // is −5R, and the report must not pretend the stop "protected" it.
      final bars = <Candle>[
        ...flat(2),
        bar(2, open: 90, high: 92, low: 88, close: 89),
        ...flat(9, price: 89),
      ];

      final trade = evaluateAt(bars, 0, signal(), config: kCfg, symbol: 'X')!;

      expect(trade.exit, BtExit.stop);
      expect(trade.exitPrice, 90); // the gap, not the level
      expect(trade.rMultiple, closeTo(-5, 1e-9));
    });

    test('a bar that could be both is read as a stop — the pessimistic read',
        () {
      final bars = <Candle>[
        ...flat(2),
        bar(2, open: 100, high: 110, low: 90, close: 100), // both levels inside
        ...flat(9, price: 100),
      ];

      final trade = evaluateAt(bars, 0, signal(), config: kCfg, symbol: 'X')!;

      expect(trade.exit, BtExit.stop);
      expect(trade.rMultiple, closeTo(-1, 1e-9));
    });

    test('the target must arrive inside the horizon to count', () {
      // The target is touched on bar 12 — two sessions after the 10-day window.
      final bars = <Candle>[
        ...flat(11, price: 100),
        bar(11, open: 100, high: 104, low: 99, close: 103),
        bar(12, open: 103, high: 104, low: 99, close: 103),
      ];

      final trade = evaluateAt(bars, 0, signal(), config: kCfg, symbol: 'X')!;

      expect(trade.exit, BtExit.horizon);
      expect(trade.hitTarget, isFalse);
    });

    test('a signal with no room left is not counted at all', () {
      final bars = flat(5); // horizon is 10 — nowhere near enough forward bars

      final trade = evaluateAt(bars, 0, signal(), config: kCfg, symbol: 'X');

      expect(trade, isNull); // an unfinished trade is not a trade
    });

    test('the entry is the next open, never the signal bar itself', () {
      // The signal bar closes at 115; entering at the close would be cheating.
      final bars = <Candle>[
        bar(0, open: 100, high: 100, low: 100, close: 115),
        bar(1, open: 110, high: 111, low: 109, close: 110),
        ...flat(10, price: 110),
      ];

      final trade = evaluateAt(bars, 0, signal(), config: kCfg, symbol: 'X')!;

      expect(trade.entry, 110); // the next session's open
      expect(trade.date, kDay); // …but the signal is dated to its own bar
    });
  });

  // -------------------------------------------------------------------------
  // The signal
  // -------------------------------------------------------------------------
  group('signal', () {
    test('a volume breakout in an uptrend is a bullish trade', () {
      // 60 flat-ish bars (slightly up), then a 3× volume close above the
      // 20-session high → breakout, and the averages agree it is up.
      final bars = <Candle>[
        for (var i = 0; i < 60; i++)
          bar(i,
              open: 100 + i * 0.02,
              high: 100 + i * 0.02,
              low: 99 + i * 0.02,
              close: 100 + i * 0.02),
        bar(60, open: 101, high: 104, low: 100.5, close: 103, volume: 3000000),
      ];

      final window = bars.sublist(0, bars.length);
      final snap = buildSnapshot(window);
      final check = signalAt(window, snap, config: kCfg);

      expect(check.mixed, isFalse);
      expect(check.signal, isNotNull);
      expect(check.signal!.pattern, AiPattern.breakout);
      expect(check.signal!.direction, AiDirection.bullish);
      expect(check.signal!.atr, greaterThan(0));
    });

    test('the same breakout without participation is not a signal', () {
      final bars = <Candle>[
        for (var i = 0; i < 60; i++)
          bar(i,
              open: 100 + i * 0.02,
              high: 100 + i * 0.02,
              low: 99 + i * 0.02,
              close: 100 + i * 0.02),
        // A new high, but on ordinary volume — a drift, not a breakout.
        bar(60, open: 101, high: 104, low: 100.5, close: 103, volume: 1000000),
      ];

      final snap = buildSnapshot(bars);
      final check = signalAt(bars, snap, config: kCfg);

      expect(check.signal, isNull);
    });

    test('a pattern the moving averages contradict is reported as mixed', () {
      // A strong uptrend (stack up, 3-month return positive) that then gaps
      // below its 20-session low on huge volume: the pattern says "down", the
      // engine's direction read says "up" — so it is thrown away, and counted.
      final bars = <Candle>[
        for (var i = 0; i < 60; i++)
          bar(i,
              open: 100 + i.toDouble(),
              high: 101 + i.toDouble(),
              low: 99 + i.toDouble(),
              close: 100 + i.toDouble()),
        bar(60, open: 120, high: 121, low: 80, close: 85, volume: 5000000),
      ];

      final snap = buildSnapshot(bars);
      final check = signalAt(bars, snap, config: kCfg);

      expect(check.signal, isNull);
      expect(check.mixed, isTrue);
    });

    test('a quiet range is not a trade', () {
      final bars = flatWithAtr(80);

      final check = signalAt(bars, buildSnapshot(bars), config: kCfg);

      expect(check.signal, isNull);
      expect(check.mixed, isFalse);
    });
  });

  // -------------------------------------------------------------------------
  // Stats
  // -------------------------------------------------------------------------
  group('stats', () {
    BtTrade trade(double r, {BtExit exit = BtExit.horizon}) => BtTrade(
          symbol: 'X',
          date: kDay,
          pattern: AiPattern.breakout,
          direction: AiDirection.bullish,
          entry: 100,
          stop: 100 - r.abs() * 2,
          target: 100,
          risk: 2,
          exitPrice: 100 + r * 2,
          exit: exit,
          barsHeld: 1,
        );

    test('counts, averages, median and the worst run', () {
      final stats = BtStats.of([
        trade(2, exit: BtExit.target), // +4 %
        trade(-1, exit: BtExit.stop), // −2 %
        trade(0.5), // +1 %
        trade(-1, exit: BtExit.stop), // −2 %
      ]);

      expect(stats.samples, 4);
      expect(stats.wins, 1);
      expect(stats.losses, 2);
      expect(stats.timeouts, 1);
      expect(stats.directionHits, 2); // +2R and +0.5R
      expect(stats.directionPct, closeTo(50, 1e-9));
      expect(stats.targetRatePct, closeTo(25, 1e-9));
      expect(stats.avgR, closeTo(0.125, 1e-9)); // (2 − 1 + 0.5 − 1) / 4
      expect(stats.best, closeTo(4, 1e-9));
      expect(stats.worst, closeTo(-2, 1e-9));
      expect(stats.medianReturnPct, closeTo(-0.5, 1e-9)); // (−2 % + 1 %) / 2
      // Equity: +2, +1, +1.5, +0.5 → the peak is +2, the trough after it is
      // +0.5, so the worst stretch is 1.5R.
      expect(stats.maxDrawdownR, closeTo(1.5, 1e-9));
    });

    test('an empty set is empty, not zero-percent-confident', () {
      final stats = BtStats.of(const <BtTrade>[]);

      expect(stats.samples, 0);
      expect(stats.isEmpty, isTrue);
      expect(stats.directionPct, 0);
      expect(stats.headline, contains('koi trade hi nahi bana'));
    });

    test('a small sample is called noise, not a result', () {
      expect(BtStats.of(List.generate(5, (_) => trade(1))).enoughSamples, isFalse);
      expect(BtStats.of(List.generate(30, (_) => trade(1))).enoughSamples, isTrue);
      expect(
        BtStats.of(List.generate(9, (_) => trade(1))).confidenceLabel,
        contains('bahut kam'),
      );
    });

    test('the headline reads the way a person says it', () {
      final stats = BtStats.of(List.generate(
        120,
        (i) => i < 70 ? trade(1.8) : trade(-1),
      ));

      // 58 % of 120 is 70 → "70/120 = 58%".
      expect(stats.headline, startsWith('120 baar aaya · 58% sahi disha'));
      expect(stats.headline, contains('ausat +'));
      expect(BtStats.signed(-0.42), '−0.4'); // a stop is never printed as "+"
    });
  });

  // -------------------------------------------------------------------------
  // The run
  // -------------------------------------------------------------------------
  group('run', () {
    test('a series too short to judge is skipped, with its bar count', () {
      final run = runSymbol('X', flat(30), config: kCfg);

      expect(run.short, isTrue);
      expect(run.trades, isEmpty);
    });

    test('a designed breakout in the middle is found and measured', () {
      // 80 quiet bars, then a 3× volume breakout that runs for three days and
      // is then flat — one trade, and it reaches the target.
      final bars = <Candle>[
        for (var i = 0; i < 80; i++)
          bar(i,
              open: 100 + i * 0.01,
              high: 100.5 + i * 0.01,
              low: 99.5 + i * 0.01,
              close: 100 + i * 0.01),
        bar(80, open: 101, high: 103, low: 100.5, close: 102.5, volume: 4000000),
        bar(81, open: 102.5, high: 106, low: 102, close: 105.5),
        ...flat(12, price: 105.5),
      ];

      final run = runSymbol('X', bars, config: kCfg);

      expect(run.short, isFalse);
      expect(run.trades.length, 1);
      expect(run.trades.single.pattern, AiPattern.breakout);
      expect(run.trades.single.entry, 102.5);
      expect(run.trades.single.exit, BtExit.target);
    });

    test('the whole universe is aggregated and dated oldest-first', () {
      final series = <String, List<Candle>>{
        'A': [
          for (var i = 0; i < 80; i++)
            bar(i,
                open: 100 + i * 0.01,
                high: 100.5 + i * 0.01,
                low: 99.5 + i * 0.01,
                close: 100 + i * 0.01),
          bar(80, open: 101, high: 103, low: 100.5, close: 102.5, volume: 4000000),
          bar(81, open: 102.5, high: 106, low: 102, close: 105.5),
          ...flat(12, price: 105.5),
        ],
        'B': flat(20), // too short → skipped with a reason
      };

      final result = runBacktest(series, config: kCfg, years: 1);

      expect(result.symbolsScanned, 1);
      expect(result.skipped.keys, ['B']);
      expect(result.skipped['B'], contains('kam se kam'));
      expect(result.trades.length, 1);
      expect(result.trades.single.symbol, 'A');
      expect(result.overall.samples, 1);
      expect(result.byPattern.single.pattern, AiPattern.breakout);
      expect(result.networkNote, contains('cache se hua')); // no download
    });

    test('the same candles always give the same report', () {
      // Determinism is the whole claim behind "local rule engine".
      final series = <String, List<Candle>>{
        'A': [
          for (var i = 0; i < 120; i++)
            bar(
              i,
              open: 100 + (i % 7) * 0.6,
              high: 101 + (i % 7) * 0.6,
              low: 99 + (i % 7) * 0.6,
              close: 100 + (i % 5) * 0.8,
              volume: 1000000 + (i % 4) * 900000,
            ),
        ],
      };

      final first = runBacktest(series, config: kCfg, years: 1);
      final second = runBacktest(series, config: kCfg, years: 1);

      expect(second.trades.length, first.trades.length);
      for (var i = 0; i < first.trades.length; i++) {
        expect(second.trades[i].date, first.trades[i].date);
        expect(second.trades[i].rMultiple, first.trades[i].rMultiple);
      }
      expect(second.overall.avgR, first.overall.avgR);
    });

    test('a longer horizon gives the trade more room', () {
      final bars = <Candle>[
        for (var i = 0; i < 80; i++)
          bar(i,
              open: 100 + i * 0.01,
              high: 100.5 + i * 0.01,
              low: 99.5 + i * 0.01,
              close: 100 + i * 0.01),
        bar(80, open: 101, high: 103, low: 100.5, close: 102.5, volume: 4000000),
        bar(81, open: 102.5, high: 102.8, low: 102, close: 102.6),
        // The target (entry + 2 ATR) is only reached on day 10.
        ...flat(6, price: 102.6),
        bar(88, open: 102.6, high: 107, low: 102, close: 106.5),
        ...flat(4, price: 106.5),
      ];

      final tight = runSymbol('X', bars, config: const BtConfig(horizonBars: 5));
      final roomy = runSymbol('X', bars, config: const BtConfig(horizonBars: 10));

      expect(tight.trades.single.exit, BtExit.horizon);
      expect(roomy.trades.single.exit, BtExit.target);
    });
  });

  // -------------------------------------------------------------------------
  // The gate
  // -------------------------------------------------------------------------
  //
  // The engine builds a full snapshot only on bars a cheap rolling gate lets
  // through. If that gate ever disagreed with the real indicators it would
  // silently delete trades — so these two tests hold it to the real thing.
  // -------------------------------------------------------------------------
  group('the rolling gate', () {
    /// A jagged, non-repeating series — the kind a gate would slip on.
    List<Candle> jagged(int count) => [
          for (var i = 0; i < count; i++)
            bar(
              i,
              open: 100 + ((i * 37) % 11) - 5,
              high: 101 + ((i * 37) % 13) - 6,
              low: 99 + ((i * 37) % 7) - 3,
              close: 100 + ((i * 53) % 17) - 8,
              volume: 1000000 + ((i * 7919) % 5) * 700000,
            ),
        ];

    test('its rolling indicators equal a full snapshot, bar for bar', () {
      final bars = jagged(160);
      final gate = BtGate(bars, kCfg);

      for (var i = 0; i < bars.length; i++) {
        gate.advance(i);
        if (i + 1 < 60) continue; // the engine never judges before the warm-up

        final window = bars.sublist(0, i + 1);
        final snap = buildSnapshot(window);

        expect(gate.ema9, closeTo(snap.ema9, 1e-9), reason: 'ema9 at bar $i');
        expect(gate.ema21, closeTo(snap.ema21, 1e-9), reason: 'ema21 at bar $i');
        expect(gate.sma50, closeTo(snap.sma50, 1e-9), reason: 'sma50 at bar $i');
        expect(gate.volumeRatio, closeTo(snap.volumeRatio, 1e-9),
            reason: 'volumeRatio at bar $i');
      }
    });

    test('it never skips a bar the real engine would call a trade', () {
      final bars = jagged(160);
      final gate = BtGate(bars, kCfg);

      for (var i = 0; i < bars.length; i++) {
        gate.advance(i);
        if (i + 1 < 60) continue;

        // What the real engine says about this bar.
        final window = bars.sublist(0, i + 1);
        final snap = buildSnapshot(window);
        final check = signalAt(window, snap, config: kCfg);

        if (check.signal != null || check.mixed) {
          expect(gate.fires(), isTrue,
              reason: 'bar $i held a ${check.signal?.pattern} signal');
        }
      }
    });
  });
}
