// ---------------------------------------------------------------------------
// ai_plan_test.dart — the arithmetic behind "kahan kharidna, kahan katna".
//
// A plan is only useful if its numbers add up, so every expectation here is
// hand-computed: risk first (1 ATR), reward twice that, and size from the risk
// budget — never from enthusiasm.
// ---------------------------------------------------------------------------

import 'package:angel_trader/features/fno/ai/ai_indicators.dart';
import 'package:angel_trader/features/fno/ai/ai_plan.dart';
import 'package:angel_trader/features/fno/ai/ai_suggestion.dart';
import 'package:flutter_test/flutter_test.dart';

AiSnapshot snap({
  double ltp = 1000,
  double atr = 20,
  double high52w = 1400,
  double low52w = 600,
}) =>
    AiSnapshot(
      ltp: ltp,
      rsi: 60,
      ema9: 990,
      ema21: 970,
      sma50: 900,
      high52w: high52w,
      low52w: low52w,
      atr: atr,
      atrPct: atr / ltp * 100,
      volumeRatio: 1.2,
      return3m: 8,
      turnoverCrore: 30,
      bars: 70,
    );

void main() {
  group('underlying levels', () {
    test('a trend entry is at CMP: risk 1 ATR, reward 2 ATR', () {
      final plan = buildTradePlan(
        snap: snap(),
        direction: AiDirection.bullish,
        pattern: AiPattern.pullback,
      );

      expect(plan.entry, closeTo(1000, 1e-9));
      expect(plan.stop, closeTo(980, 1e-9));
      expect(plan.target, closeTo(1040, 1e-9));
      expect(plan.risk, closeTo(20, 1e-9));
      expect(plan.reward, closeTo(40, 1e-9));
      expect(plan.rr, closeTo(2, 1e-9));
      expect(plan.worthIt, isTrue);
      expect(plan.entryNote, contains('1000'));
    });

    test('a breakout waits for the level instead of chasing CMP', () {
      final plan = buildTradePlan(
        snap: snap(),
        direction: AiDirection.bullish,
        pattern: AiPattern.breakout,
      );

      // 0.25 ATR above CMP is the trigger; risk and reward hang off that.
      expect(plan.entry, closeTo(1005, 1e-9));
      expect(plan.entryNote, contains('ke upar'));
      expect(plan.entryNote, contains('CMP'));
      expect(plan.stop, closeTo(985, 1e-9));
      expect(plan.target, closeTo(1045, 1e-9));
    });

    test('a bearish plan is the mirror image', () {
      final plan = buildTradePlan(
        snap: snap(),
        direction: AiDirection.bearish,
        pattern: AiPattern.pullback,
      );

      expect(plan.stop, closeTo(1020, 1e-9));
      expect(plan.target, closeTo(960, 1e-9));
      expect(plan.risk, closeTo(20, 1e-9));
      expect(plan.reward, closeTo(40, 1e-9));
    });

    test('the target never plans through the 52-week high', () {
      // 1000 + 2×20 = 1040, but the high is at 1010 → the plan stops there and
      // says so with a worse (honest) R:R.
      final plan = buildTradePlan(
        snap: snap(high52w: 1010),
        direction: AiDirection.bullish,
        pattern: AiPattern.pullback,
      );

      expect(plan.target, closeTo(1010, 1e-9));
      expect(plan.reward, closeTo(10, 1e-9));
      expect(plan.rr, closeTo(0.5, 1e-9));
      expect(plan.worthIt, isFalse); // half a unit of reward is not a trade
    });

    test('a bearish target never plans through the 52-week low', () {
      final plan = buildTradePlan(
        snap: snap(low52w: 990),
        direction: AiDirection.bearish,
        pattern: AiPattern.pullback,
      );
      expect(plan.target, closeTo(990, 1e-9));
      expect(plan.reward, closeTo(10, 1e-9));
    });
  });

  group('option sizing', () {
    test('premium stop is −40 %, target +80 % (a 1 : 2 plan)', () {
      final plan = buildTradePlan(
        snap: snap(),
        direction: AiDirection.bullish,
        pattern: AiPattern.pullback,
        premium: 10,
        lotSize: 250,
        capital: 100000,
        riskPct: 1.5,
      );

      expect(plan.premiumStop, closeTo(6, 1e-9));
      expect(plan.premiumTarget, closeTo(18, 1e-9));
      expect(plan.lotCost, closeTo(2500, 1e-9));
      expect(plan.riskPerLot, closeTo(1000, 1e-9));
    });

    test('size comes from the risk budget, not from the cash in hand', () {
      // Budget = 1.5 % of ₹1,00,000 = ₹1,500; risk per lot ₹1,000 → 1 lot.
      final oneLot = buildTradePlan(
        snap: snap(),
        direction: AiDirection.bullish,
        pattern: AiPattern.pullback,
        premium: 10,
        lotSize: 250,
        capital: 100000,
        riskPct: 1.5,
      );
      expect(oneLot.lots, 1);
      expect(oneLot.capitalAtRiskPct, closeTo(1.0, 1e-9));

      // A ₹4 premium risks ₹40,000 a lot — far past the budget, so the honest
      // answer is zero lots, not "buy one and hope".
      final expensive = buildTradePlan(
        snap: snap(),
        direction: AiDirection.bullish,
        pattern: AiPattern.pullback,
        premium: 400,
        lotSize: 250,
        capital: 100000,
        riskPct: 1.5,
      );
      expect(expensive.lots, 0);
      expect(expensive.tooBig, isTrue);
      expect(expensive.capitalAtRiskPct, closeTo(40, 1e-9));
    });

    test('a bigger budget buys more lots', () {
      final plan = buildTradePlan(
        snap: snap(),
        direction: AiDirection.bullish,
        pattern: AiPattern.pullback,
        premium: 10,
        lotSize: 250,
        capital: 1000000,
        riskPct: 1.5,
      );
      expect(plan.lots, 15); // ₹15,000 budget ÷ ₹1,000 a lot
    });

    test('a plan without a premium is still a plan — just not sized', () {
      final plan = buildTradePlan(
        snap: snap(),
        direction: AiDirection.bullish,
        pattern: AiPattern.pullback,
      );
      expect(plan.premium, isNull);
      expect(plan.lots, 0);
      expect(plan.tooBig, isFalse); // nothing to size ≠ too big
      expect(plan.stop, closeTo(980, 1e-9));
    });
  });
}
