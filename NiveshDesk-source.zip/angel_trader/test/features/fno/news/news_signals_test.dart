// ---------------------------------------------------------------------------
// news_signals_test.dart — the News→AI Jodi bridge (1.5.55).
// ---------------------------------------------------------------------------

import 'package:angel_trader/features/fno/news/news_models.dart';
import 'package:angel_trader/features/fno/news/news_signals.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('NewsSignals', () {
    NewsItem item({
      required String title,
      required DateTime published,
      required List<AffectedStock> affected,
    }) =>
        NewsItem(
          id: title,
          publishedAt: published,
          title: title,
          body: '',
          kind: NewsKind.headline,
          sourceLabel: 'test',
          affected: affected,
        );

    AffectedStock stock(String symbol, int impact) => AffectedStock(
          symbol: symbol,
          companyName: symbol,
          sector: '',
          direction: EffectDirection.positive,
          reason: 'test',
          isFno: true,
          impactScore: impact,
        );

    test('keeps only high-impact symbols inside the 48h window', () {
      final store = NewsSignals.instance..clear();
      final now = DateTime(2026, 10, 26, 12);
      store.updateFrom(
        [
          item(
            title: 'Fresh strong news',
            published: now.subtract(const Duration(hours: 1)),
            affected: [stock('SBIN', 6), stock('TCS', 2)],
          ),
          item(
            title: 'Old strong news',
            published: now.subtract(const Duration(hours: 72)),
            affected: [stock('INFY', 8)],
          ),
        ],
        now: now,
      );
      expect(store.forSymbol('SBIN')?.highImpactCount, 1);
      expect(store.forSymbol('SBIN')?.topHeadline, 'Fresh strong news');
      expect(store.forSymbol('TCS'), isNull); // impact < 4
      expect(store.forSymbol('INFY'), isNull); // too old
      expect(store.updatedAt, now);
    });

    test('counts stack across items and clear empties the map', () {
      final store = NewsSignals.instance..clear();
      final now = DateTime(2026, 10, 26, 12);
      store.updateFrom(
        [
          item(
            title: 'One',
            published: now.subtract(const Duration(hours: 2)),
            affected: [stock('SBIN', 5)],
          ),
          item(
            title: 'Two',
            published: now.subtract(const Duration(hours: 1)),
            affected: [stock('SBIN', 5)],
          ),
        ],
        now: now,
      );
      expect(store.forSymbol('SBIN')?.highImpactCount, 2);
      store.clear();
      expect(store.bySymbol, isEmpty);
      expect(store.updatedAt, isNull);
    });
  });
}
