// ---------------------------------------------------------------------------
// news_parsers_test.dart — parser tests on injected fixtures (1.5.52).
// The fixture XML/HTML/CSV below are synthetic samples shaped like the real
// feeds (Google News RSS, NSE RSS, t.me/s/ preview, NSE CM bhavcopy).
// Tests never touch the network.
// ---------------------------------------------------------------------------

import 'package:angel_trader/features/fno/news/news_parsers.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('NewsParsers.parseRssFeed', () {
    test('Google News style — CDATA, source tag, RFC822 pubDate', () {
      const xml = '''
<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0"><channel>
<title>test</title>
<item>
  <title><![CDATA[Senco Gold acquires Melorra]]></title>
  <link>https://news.google.com/rss/articles/abc</link>
  <pubDate>Sat, 25 Oct 2026 07:20:00 +0530</pubDate>
  <source url="https://www.moneycontrol.com">Moneycontrol</source>
  <description><![CDATA[<a href="x">Senco Gold</a> buys 68%]]></description>
</item>
<item>
  <title>PM Modi inaugurates RBI data centre</title>
  <pubDate>25 Oct 2026 11:15:00 GMT</pubDate>
</item>
</channel></rss>
''';
      final items = NewsParsers.parseRssFeed(xml, fallbackSource: 'Google News');
      expect(items, hasLength(2));
      expect(items.first.title, 'Senco Gold acquires Melorra');
      expect(items.first.description, contains('buys 68%'));
      expect(items.first.description, isNot(contains('<a')));
      expect(items.first.sourceLabel, 'Moneycontrol');
      expect(items.last.sourceLabel, 'Google News');
      expect(items.first.published, isNotNull);
    });

    test('NSE RSS style — dd-MMM-yyyy date', () {
      const xml = '''
<rss><channel>
<item>
  <title>SENCO | Acquisition of August Jewellery Private Limited</title>
  <description>SERIES:EQ |SUB:ACQUISITION</description>
  <pubDate>25-Oct-2026 07:20:00</pubDate>
</item>
</channel></rss>
''';
      final items = NewsParsers.parseRssFeed(xml, fallbackSource: 'NSE announcement');
      expect(items, hasLength(1));
      expect(items.first.sourceLabel, 'NSE announcement');
      expect(items.first.published, DateTime(2026, 10, 25, 7, 20));
    });
  });

  group('NewsParsers.parseFlexibleDate', () {
    test('handles all three formats and honest misses', () {
      expect(NewsParsers.parseFlexibleDate('25-Oct-2026 07:20:00'),
          DateTime(2026, 10, 25, 7, 20));
      expect(NewsParsers.parseFlexibleDate('2026-10-25T06:05:41+00:00'),
          DateTime.utc(2026, 10, 25, 6, 5, 41));
      expect(NewsParsers.parseFlexibleDate('not a date'), isNull);
      expect(NewsParsers.parseFlexibleDate(null), isNull);
    });
  });

  group('NewsParsers.parseFoSecBan', () {
    test('symbols + trade date from the official CSV', () {
      const csv = 'Securities in Ban For Trade Date 03-SEP-2026:\n'
          '1,LICHSGFIN\n'
          '2,SAIL\n';
      final parsed = NewsParsers.parseFoSecBan(csv);
      expect(parsed.symbols, ['LICHSGFIN', 'SAIL']);
      expect(parsed.tradeDate, DateTime(2026, 9, 3));
    });

    test('empty file is honest', () {
      final parsed = NewsParsers.parseFoSecBan('');
      expect(parsed.symbols, isEmpty);
      expect(parsed.tradeDate, isNull);
    });
  });

  group('NewsParsers.parseTelegramPreview', () {
    test('extracts posts from the t.me/s/ preview HTML', () {
      const html = '''
<div class="tgme_widget_message_wrap">
 <div class="tgme_widget_message js-widget_message" data-post="Stock_aaj_or_kal/268441">
  <div class="tgme_widget_message_text js-message_text" dir="auto"><b>Arvind Ltd</b> – Greenfield garment facility<div>Investment of approximately INR 150 Cr</div></div>
  <time class="tgme_widget_message_date" datetime="2026-10-25T06:05:41+00:00"><span>06:05</span></time>
 </div>
 <div class="tgme_widget_message js-widget_message" data-post="Stock_aaj_or_kal/268442">
  <div class="tgme_widget_message_text js-message_text" dir="auto">Senco Gold Ltd – Acquisition update</div>
  <time class="tgme_widget_message_date" datetime="2026-10-25T07:20:00+00:00"><span>07:20</span></time>
 </div>
</div>
''';
      final posts = NewsParsers.parseTelegramPreview(html);
      expect(posts, hasLength(2));
      expect(posts.first.messageId, '268441');
      expect(posts.first.text, contains('Arvind Ltd'));
      expect(posts.first.text, contains('150 Cr'));
      expect(posts.first.link, 'https://t.me/Stock_aaj_or_kal/268441');
      expect(posts.first.published, DateTime.utc(2026, 10, 25, 6, 5, 41));
      expect(posts.last.text, contains('Senco Gold'));
    });

    test('page without posts is an empty list', () {
      expect(NewsParsers.parseTelegramPreview('<html></html>'), isEmpty);
    });
  });

  group('NewsParsers.parseBhavcopyOhlc', () {
    test('UDiFF header (the app\'s live format)', () {
      const csv = 'TradDt,TckrSymb,FinInstrmId,ISIN,SctySrs,OpnPric,HghPric,LwPric,ClsPric\n'
          '2026-10-23,SENCO,12345,INE000000001,EQ,99.0,101.5,97.25,100.4\n'
          '2026-10-23,TATAMOTORS,23456,INE000000002,EQ,700.0,712.0,698.0,710.0\n'
          '2026-10-23,JUNK,34567,INE000000003,SM,10.0,11.0,9.0,10.5\n';
      final bars = NewsParsers.parseBhavcopyOhlc(csv);
      expect(bars.keys, containsAll(['SENCO', 'TATAMOTORS']));
      expect(bars.containsKey('JUNK'), isFalse); // SME series out
      expect(bars['SENCO']!.high, 101.5);
      expect(bars['SENCO']!.low, 97.25);
      expect(bars['SENCO']!.close, 100.4);
      expect(bars['TATAMOTORS']!.open, 700.0);
    });

    test('classic header + malformed rows', () {
      const csv = 'SYMBOL,SERIES,OPEN,HIGH,LOW,CLOSE\n'
          'SBIN,EQ,800,812,795,810\n'
          'BADROW,EQ,xx,yy,zz,ww\n';
      final bars = NewsParsers.parseBhavcopyOhlc(csv);
      expect(bars.keys, ['SBIN']);
      expect(bars['SBIN']!.range, closeTo(17, 0.001));
    });
  });
}
