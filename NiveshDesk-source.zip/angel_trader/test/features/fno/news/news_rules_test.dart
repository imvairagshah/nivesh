// ---------------------------------------------------------------------------
// news_rules_test.dart — pure rule-engine tests for the News module (1.5.52).
// No network: everything is exercised on injected text and numbers.
// ---------------------------------------------------------------------------

import 'package:angel_trader/features/fno/news/news_models.dart';
import 'package:angel_trader/features/fno/news/news_rules.dart';
import 'package:angel_trader/features/fno/news/news_sector_map.dart';
import 'package:angel_trader/features/fno/study/study_engine.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('NewsRules.normalizeName', () {
    test('strips punctuation and corporate suffixes', () {
      expect(NewsRules.normalizeName('Senco Gold Ltd.'), 'SENCO GOLD');
      expect(NewsRules.normalizeName('Arvind Limited'), 'ARVIND');
      expect(NewsRules.normalizeName('  DCB Bank  Ltd. '), 'DCB BANK');
      expect(NewsRules.normalizeName('Mahindra & Mahindra'), 'MAHINDRA MAHINDRA');
    });
  });

  group('NewsRules.classifyDirection', () {
    test('positive keywords', () {
      expect(
        NewsRules.classifyDirection(
            'Arvind Ltd inaugurates greenfield garment facility'),
        EffectDirection.positive,
      );
      expect(
        NewsRules.classifyDirection('TCS order win from European client'),
        EffectDirection.positive,
      );
    });

    test('negative keywords', () {
      expect(
        NewsRules.classifyDirection('SEBI probe announced at ABC Ltd'),
        EffectDirection.negative,
      );
      expect(
        NewsRules.classifyDirection('XYZ posts loss in Q2, profit declines'),
        EffectDirection.negative,
      );
    });

    test('mixed and unknown', () {
      expect(
        NewsRules.classifyDirection('Senco Gold acquisition of Melorra'),
        EffectDirection.mixed,
      );
      expect(
        NewsRules.classifyDirection('PM Modi addresses the nation in Odisha'),
        EffectDirection.unknown,
      );
      expect(
        NewsRules.classifyDirection('Dividend declared but profit declines'),
        EffectDirection.mixed,
      );
    });
  });

  group('NewsRules.matchAffected', () {
    const universe = [
      StockRef(symbol: 'SENCO', companyName: 'Senco Gold Ltd', sector: 'Consumer', isFno: false),
      StockRef(symbol: 'TATAMOTORS', companyName: 'Tata Motors Ltd', sector: 'Auto', isFno: true),
      StockRef(symbol: 'ADANIPOWER', companyName: 'Adani Power Ltd', sector: 'Power', isFno: true),
      StockRef(symbol: 'TATACONS', companyName: 'Tata', sector: '', isFno: false),
    ];

    test('matches by company name when the symbol is absent', () {
      final hits = NewsRules.matchAffected(
        text: 'Tata Motors Ltd Q2 presentation shows strong demand',
        universe: universe,
      );
      final motors = hits.firstWhere((h) => h.symbol == 'TATAMOTORS');
      expect(motors.reason, 'News me company naam');
    });

    test('matches by symbol token with word boundaries', () {
      final hits = NewsRules.matchAffected(
        text: 'TATAMOTORS reports strong sales; TATAELXSI is unrelated',
        universe: universe,
      );
      expect(hits.map((h) => h.symbol), contains('TATAMOTORS'));
    });

    test('short names do not fire inside longer names', () {
      // "Tata" alone (4 chars) must not catch "Tata Motors" text.
      final hits = NewsRules.matchAffected(
        text: 'Tata Motors Ltd Q2 presentation',
        universe: universe,
      );
      final symbols = hits.map((h) => h.symbol).toList();
      expect(symbols, contains('TATAMOTORS'));
      expect(symbols, isNot(contains('TATACONS')));
    });

    test('no match stays empty', () {
      final hits = NewsRules.matchAffected(
        text: 'Trump to Fox News: monitoring the situation',
        universe: universe,
      );
      expect(hits, isEmpty);
    });
  });

  group('NewsRules.rankAffected', () {
    test('symbol in title and F&O membership win', () {
      final matched = [
        const AffectedStock(
          symbol: 'ADANIPOWER',
          companyName: 'Adani Power Ltd',
          sector: 'Power',
          direction: EffectDirection.positive,
          reason: 'News me company naam',
          isFno: true,
          impactScore: 0,
        ),
        const AffectedStock(
          symbol: 'SENCO',
          companyName: 'Senco Gold Ltd',
          sector: 'Consumer',
          direction: EffectDirection.mixed,
          reason: 'News me company naam',
          isFno: false,
          impactScore: 0,
        ),
      ];
      final ranked = NewsRules.rankAffected(
        title: 'Adani Power Ltd – Q2 FY27 earnings presentation',
        matched: matched,
      );
      expect(ranked.first.symbol, 'ADANIPOWER');
      expect(ranked.first.impactScore, greaterThan(ranked.last.impactScore));
    });
  });

  group('NewsRules.buildLevelsPlan', () {
    test('positive news → breakout long above the high', () {
      final plan = NewsRules.buildLevelsPlan(
        direction: EffectDirection.positive,
        lastHigh: 100,
        lastLow: 95,
        atr: 4,
      )!;
      expect(plan.entry, 100);
      expect(plan.stop, 95);
      expect(plan.target, closeTo(106, 0.001)); // 100 + 1.5×4
      expect(plan.basis, contains('ATR'));
    });

    test('negative news → short below the low', () {
      final plan = NewsRules.buildLevelsPlan(
        direction: EffectDirection.negative,
        lastHigh: 100,
        lastLow: 95,
        atr: 4,
      )!;
      expect(plan.entry, 95);
      expect(plan.stop, 100);
      expect(plan.target, closeTo(89, 0.001)); // 95 − 1.5×4
    });

    test('missing ATR falls back to the session range, labeled', () {
      final plan = NewsRules.buildLevelsPlan(
        direction: EffectDirection.positive,
        lastHigh: 100,
        lastLow: 95,
        atr: null,
      )!;
      expect(plan.target, closeTo(107.5, 0.001)); // 100 + 1.5×5
      expect(plan.basis, contains('session range'));
    });

    test('missing prices → no numbers, mixed news → no plan', () {
      final plan = NewsRules.buildLevelsPlan(
        direction: EffectDirection.positive,
        lastHigh: null,
        lastLow: null,
        atr: null,
      )!;
      expect(plan.hasLevels, isFalse);
      expect(plan.target, isNull);
      expect(
        NewsRules.buildLevelsPlan(
          direction: EffectDirection.mixed,
          lastHigh: 100,
          lastLow: 95,
          atr: 4,
        ),
        isNull,
      );
    });
  });

  group('NewsRules.buildJodiIdea', () {
    test('ATM straddle long for high-impact F&O news', () {
      final jodi = NewsRules.buildJodiIdea(
        isFno: true,
        highImpact: true,
        atmStrike: 2650,
        ceLtp: 60,
        peLtp: 55,
        stranglePeStrike: null,
        strangleCeStrike: null,
        strangleTotal: null,
        ivRank: IvRank.low,
      )!;
      expect(jodi.label, contains('straddle'));
      expect(jodi.premium, closeTo(115, 0.001));
      expect(jodi.breakEvenLower, closeTo(2535, 0.001));
      expect(jodi.breakEvenUpper, closeTo(2765, 0.001));
      expect(jodi.ivStar, contains('IV sasta'));
    });

    test('OTM strangle fallback + honest skips', () {
      final jodi = NewsRules.buildJodiIdea(
        isFno: true,
        highImpact: true,
        atmStrike: null,
        ceLtp: null,
        peLtp: null,
        stranglePeStrike: 2600,
        strangleCeStrike: 2700,
        strangleTotal: 70,
        ivRank: IvRank.unknown,
      )!;
      expect(jodi.label, contains('strangle'));
      expect(jodi.breakEvenLower, closeTo(2530, 0.001));
      expect(jodi.breakEvenUpper, closeTo(2770, 0.001));

      expect(
        NewsRules.buildJodiIdea(
          isFno: false,
          highImpact: true,
          atmStrike: 100,
          ceLtp: 5,
          peLtp: 5,
          stranglePeStrike: null,
          strangleCeStrike: null,
          strangleTotal: null,
          ivRank: IvRank.unknown,
        ),
        isNull,
      );
      expect(
        NewsRules.buildJodiIdea(
          isFno: true,
          highImpact: false,
          atmStrike: 100,
          ceLtp: 5,
          peLtp: 5,
          stranglePeStrike: null,
          strangleCeStrike: null,
          strangleTotal: null,
          ivRank: IvRank.unknown,
        ),
        isNull,
      );
    });
  });

  group('NewsRules.buildResearch', () {
    test('wires suggestion, levels, jodi and most-affected', () {
      final ranked = [
        const AffectedStock(
          symbol: 'SENCO',
          companyName: 'Senco Gold Ltd',
          sector: 'Consumer',
          direction: EffectDirection.mixed,
          reason: 'News me company naam',
          isFno: false,
          impactScore: 6,
        ),
      ];
      final research = NewsRules.buildResearch(
        title: 'Senco Gold acquisition of Melorra',
        ranked: ranked,
        levelsBySymbol: const {
          'SENCO': (high: 100, low: 95, atr: null),
        },
        jodiBySymbol: const {'SENCO': null},
        dataNotes: const {'SENCO': 'Levels: bhavcopy H/L + session-range proxy'},
      );
      expect(research.mostAffectedSymbol, 'SENCO');
      expect(research.mostAffectedReason, contains('SENCO'));
      expect(research.stocks, hasLength(1));
      final stock = research.stocks.first;
      expect(stock.suggestion, contains('do-tarah ka'));
      // Mixed direction → the rules refuse to invent a level plan.
      expect(stock.levels, isNull);
      expect(research.disclaimer, NewsRules.disclaimer);
    });
  });

  group('sector map', () {
    test('known and unknown resolve honestly', () {
      expect(sectorFor('SBIN'), 'Banking');
      expect(sectorFor('JSWSTEEL'), 'Steel');
      expect(sectorFor('SOMENEWTICKER'), '');
    });
  });

  group('NewsMatcher performance (crash regression, 1.5.53)', () {
    test('3,000-stock universe × 60 news items stays fast', () {
      final universe = [
        for (var i = 0; i < 3000; i++)
          StockRef(
            symbol: 'STOCK$i',
            companyName: 'Company Number $i Limited',
            sector: '',
            isFno: i.isEven,
          ),
        const StockRef(
          symbol: 'SENCO',
          companyName: 'Senco Gold Ltd',
          sector: 'Consumer',
          isFno: false,
        ),
        const StockRef(
          symbol: 'M&M',
          companyName: 'Mahindra & Mahindra Ltd',
          sector: 'Auto',
          isFno: true,
        ),
      ];
      final sw = Stopwatch()..start();
      final matcher = NewsMatcher(universe);
      final news = [
        for (var i = 0; i < 60; i++)
          'Senco Gold Ltd acquisition update $i — Company Number 2999 '
              'reports results. M&M sales rise.',
      ];
      for (final text in news) {
        final hits = matcher.match(text);
        expect(hits, isNotEmpty);
      }
      sw.stop();
      // Pehle yeh path phone par freeze/OOM karta tha (RegExp per pair).
      // Ab ek hi precompute + token lookup — kaafi tez hona chahiye.
      expect(sw.elapsedMilliseconds, lessThan(2000));
    });

    test('odd symbols (M&M) still match with word boundaries', () {
      final matcher = NewsMatcher(const [
        StockRef(symbol: 'M&M', companyName: 'Mahindra & Mahindra Ltd'),
      ]);
      expect(matcher.match('M&M reports strong quarterly numbers'),
          hasLength(1));
      expect(matcher.match('SUMM reports numbers'), isEmpty);
    });
  });

  group('NewsSignalsRules (1.5.55)', () {
    test('digestScore — impact dominates, freshness breaks ties', () {
      final now = DateTime(2026, 10, 26, 12);
      final freshBan = NewsSignalsRules.digestScore(
        maxImpact: 3,
        kind: NewsKind.foBan,
        published: now.subtract(const Duration(hours: 2)),
        now: now,
      );
      final staleHeadline = NewsSignalsRules.digestScore(
        maxImpact: 3,
        kind: NewsKind.headline,
        published: now.subtract(const Duration(hours: 30)),
        now: now,
      );
      final lowImpact = NewsSignalsRules.digestScore(
        maxImpact: 1,
        kind: NewsKind.announcement,
        published: now.subtract(const Duration(hours: 1)),
        now: now,
      );
      expect(freshBan, greaterThan(staleHeadline));
      expect(freshBan, greaterThan(lowImpact));
    });

    test('jodiSignal — agree only on buy verdicts, honest otherwise', () {
      // Strong move + cheap jodi → gates pass with 2× cover → agrees.
      final agree = NewsSignalsRules.jodiSignal(
        isFno: true,
        ltp: 100,
        atr: 1,
        avgDailyMove15: 5,
        monthlyRangePcts: const [25, 25, 25],
        atmJodiPrice: 2,
        otmJodiPrice: 1.5,
      );
      expect(agree.agrees, isTrue);
      expect(agree.label, contains('News + Jodi'));

      // Tiny move + expensive jodi → skip → no agreement.
      final skip = NewsSignalsRules.jodiSignal(
        isFno: true,
        ltp: 100,
        atr: 10,
        avgDailyMove15: 1,
        monthlyRangePcts: const [5, 5, 5],
        atmJodiPrice: 20,
        otmJodiPrice: 18,
      );
      expect(skip.agrees, isFalse);
      expect(skip.label, contains('Jodi:'));

      // Non-F&O → no signal at all (empty label).
      final none = NewsSignalsRules.jodiSignal(
        isFno: false,
        ltp: 100,
        atr: 1,
        avgDailyMove15: 5,
        monthlyRangePcts: const [25, 25, 25],
        atmJodiPrice: 2,
        otmJodiPrice: 1.5,
      );
      expect(none.agrees, isFalse);
      expect(none.label, isEmpty);
    });
  });
}
