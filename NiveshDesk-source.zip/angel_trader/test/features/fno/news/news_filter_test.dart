// Tests for the three News feed filters (1.5.68): Sabhi / Mere stocks
// (basket) / F&O stocks — pure [visibleNewsFor], no widgets.
import 'package:angel_trader/features/fno/news/news_models.dart';
import 'package:angel_trader/features/fno/news/news_provider.dart';
import 'package:flutter_test/flutter_test.dart';

NewsItem item(String id, List<String> symbols) => NewsItem(
      id: id,
      publishedAt: null,
      title: id,
      body: '',
      kind: NewsKind.announcement,
      sourceLabel: 'test',
      affected: [
        for (final s in symbols)
          AffectedStock(
            symbol: s,
            companyName: s,
            sector: '',
            direction: EffectDirection.mixed,
            reason: '',
            isFno: true,
            impactScore: 1,
          ),
      ],
    );

void main() {
  final items = [
    item('fno-only', ['RELIANCE', 'TCS']),
    item('basket-only', ['SMALLCO']),
    item('both', ['RELIANCE', 'SMALLCO']),
    item('no-match', ['OTHER']),
  ];
  const basket = {'SMALLCO'};
  const fno = {'RELIANCE', 'TCS'};

  List<String> ids(NewsFeedScope scope) => [
        for (final i in visibleNewsFor(items, scope, basket, fno)) i.id,
      ];

  group('visibleNewsFor', () {
    test('Sabhi = sab kuch', () {
      expect(ids(NewsFeedScope.all),
          ['fno-only', 'basket-only', 'both', 'no-match']);
    });

    test('Basket = sirf basket-stock news', () {
      expect(ids(NewsFeedScope.basket), ['basket-only', 'both']);
    });

    test('F&O = sirf F&O-stock news', () {
      expect(ids(NewsFeedScope.fno), ['fno-only', 'both']);
    });

    test('symbol sets empty → filter list honestly empty', () {
      expect(
        visibleNewsFor(items, NewsFeedScope.fno, basket, const {}),
        isEmpty,
      );
      expect(
        visibleNewsFor(items, NewsFeedScope.basket, const {}, fno),
        isEmpty,
      );
    });

    test('symbol match case-insensitive (sheet/master dono upper)', () {
      final lower = [item('x', ['reliance'])];
      expect(visibleNewsFor(lower, NewsFeedScope.fno, const {}, fno), hasLength(1));
    });
  });
}
