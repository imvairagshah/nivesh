// ---------------------------------------------------------------------------
// results_calendar_screen_test.dart — what the Results Calendar page renders.
//
// UI-only contract, pinned as rendered strings: the NAYA label and broadcast
// timestamp, the confirm / "NSE me nahi" wording, the "Pichla result: …" line
// that replaces every guessed date, countdown, whole-list counts and filters.
// The page is its own tool — these tests never
// touch the 3-Month Study.
//
// These tests drive a *fake* [EarningsCalendarService]: sqflite runs in a real
// isolate, which a widget test's fake-async clock cannot wait for. The SQLite
// path (cache write/read, staleness) is covered by the provider test and by
// test/services/earnings_calendar_test.dart.
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/theme/app_theme.dart';
import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/earnings_dao.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/features/fno/results/results_calendar_provider.dart';
import 'package:angel_trader/features/fno/results/results_calendar_screen.dart';
import 'package:angel_trader/services/earnings_calendar_service.dart';
import 'package:angel_trader/services/fno_universe.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';

/// The shipped F&O list, trimmed to five names for the test.
const _universe = FnoUniverse(
  symbols: ['ABCAPITAL', 'RELIANCE', 'SBIN', 'SIYSIL', 'TATAMOTORS'],
  companyNames: {
    'ABCAPITAL': 'Aditya Birla Capital Ltd',
    'RELIANCE': 'Reliance Industries Ltd',
    'SBIN': 'State Bank of India',
    'SIYSIL': 'Siyaram Silk Mills Ltd',
    'TATAMOTORS': 'Tata Motors Ltd',
  },
);

/// Stand-in for the day-cached NSE calendar. ABCAPITAL and TATAMOTORS are
/// deliberately absent — they must still get a row, marked "NSE me nahi".
EarningsCalendar _calendar({DateTime? siysilNext}) => EarningsCalendar(
  bySymbol: {
    'RELIANCE': EarningsInfo(
      lastDate: DateTime(2025, 10, 14),
      lastLabel: 'Q2 · quarter ended Sep 2025',
      nextDate: DateTime(2026, 1, 22),
      nextLabel: 'board meeting confirm',
      nextConfirmed: true,
    ),
    'SIYSIL': EarningsInfo(
      lastDate: DateTime(2025, 11, 10),
      lastLabel: 'Q2 · quarter ended Sep 2025',
      nextDate: siysilNext ?? DateTime(2026, 1, 30),
      nextLabel: 'board meeting confirm',
      nextConfirmed: true,
    ),
    // Announced nothing — so it carries only its last result.
    'SBIN': EarningsInfo(
      lastDate: DateTime(2025, 11, 4),
      lastLabel: 'Q2 · quarter ended Sep 2025',
    ),
  },
  fetchedAt: DateTime(2026, 1, 5, 9, 30),
);

/// Fakes out [EarningsCalendarService.load] so the page can be driven without
/// SQLite or the network. A forced load (pull-to-refresh / refresh button)
/// hands back the "newer" calendar, exactly like a real re-fetch would.
class _FakeEarnings extends EarningsCalendarService {
  _FakeEarnings({
    DateTime? siysilAfterRefresh,
    this.failWith,
    this.showNaya = false,
  }) : _siysilAfterRefresh = siysilAfterRefresh,
       super(
         dao: EarningsDao(AppDatabase.instance),
         settings: SettingsDao(AppDatabase.instance),
         get: (uri) async => '[]',
       );

  final DateTime? _siysilAfterRefresh;
  final String? failWith;
  final bool showNaya;

  int loads = 0;
  int forcedLoads = 0;

  @override
  Future<EarningsCalendar> load({bool force = false}) async {
    loads++;
    if (force) {
      forcedLoads++;
      if (failWith != null) throw Exception(failWith);
    }
    return _calendar(
      siysilNext: force ? _siysilAfterRefresh ?? DateTime(2026, 2, 2) : null,
    );
  }

  @override
  DateTime? newlyDeclaredAt(String symbol, DateTime? meetingDate) =>
      showNaya && symbol == 'RELIANCE' && meetingDate == DateTime(2026, 1, 22)
      ? DateTime(2026, 1, 4, 10, 15)
      : null;

  @override
  String? get note =>
      failWith == null ? null : 'NSE se results date nahi mili ($failWith).';

  @override
  bool get lastFetchFailed => failWith != null;
}

void main() {
  late _FakeEarnings earnings;
  late ResultsCalendarProvider provider;

  ResultsCalendarProvider buildProvider(
    _FakeEarnings service, {
    DateTime? now,
  }) => ResultsCalendarProvider(
    earnings: service,
    fnoUniverse: _universe,
    now: () => now ?? DateTime(2026, 1, 5, 9, 30),
  );

  Future<void> pump(
    WidgetTester tester, {
    _FakeEarnings? service,
    DateTime? now,
  }) async {
    // A tall viewport so all five rows are built at once — the assertions
    // below count widgets, and a lazy ListView would drop off-screen rows.
    tester.view.physicalSize = const Size(1000, 2200);
    tester.view.devicePixelRatio = 1.0;
    addTearDown(tester.view.reset);

    earnings = service ?? _FakeEarnings();
    provider = buildProvider(earnings, now: now);

    await tester.pumpWidget(
      ChangeNotifierProvider<ResultsCalendarProvider>.value(
        value: provider,
        child: MaterialApp(
          theme: AppTheme.light(),
          home: const ResultsCalendarScreen(),
        ),
      ),
    );
    // The screen loads in a post-frame callback — pure Dart async, so a plain
    // pumpAndSettle is enough here.
    await tester.pumpAndSettle();
  }

  testWidgets('the header counts the whole F&O list', (tester) async {
    await pump(tester);

    expect(find.text('Results Calendar'), findsOneWidget);
    expect(find.text('Next results — saari F&O companies'), findsOneWidget);
    expect(find.textContaining('5 F&O companies'), findsOneWidget);
    // One header stat + the two row chips (RELIANCE & SIYSIL announced).
    expect(find.text('confirm'), findsNWidgets(3));
    // The stat that replaced "anumanit": how many last results are known.
    expect(
      find.text('pichla result'),
      findsOneWidget,
      reason: 'how many last results are on record',
    );
    expect(
      find.text('anumanit'),
      findsNothing,
      reason: 'no guessed date is printed anywhere',
    );
    // One header stat + one filter chip; the three no-date rows are hidden
    // because the page opens on Confirm.
    expect(find.text('NSE me nahi'), findsNWidgets(2));
    expect(
      find.text('Dikhaye ja rahe: 2 / 5'),
      findsOneWidget,
      reason: 'the page opens on Confirm, counting against all 5',
    );
    expect(
      find.textContaining('NSE se aakhri baar: 05 Jan 2026, 09:30'),
      findsOneWidget,
    );
  });

  testWidgets('Naya badge and top filter show the NSE broadcast timestamp', (
    tester,
  ) async {
    await pump(
      tester,
      service: _FakeEarnings(showNaya: true),
      now: DateTime(2026, 1, 7), // marker has expired: no wall-clock timer
    );

    expect(find.text('NAYA'), findsOneWidget);
    expect(find.textContaining('NSE broadcast:'), findsOneWidget);
    expect(find.widgetWithText(ChoiceChip, 'Naya declared'), findsOneWidget);

    await tester.tap(find.widgetWithText(ChoiceChip, 'Naya declared'));
    await tester.pumpAndSettle();

    expect(find.text('Dikhaye ja rahe: 1 / 5'), findsOneWidget);
    expect(find.text('RELIANCE'), findsOneWidget);
    expect(find.text('SIYSIL'), findsNothing);
  });

  testWidgets('a confirmed date line reads date + countdown + last result', (
    tester,
  ) async {
    await pump(tester);

    expect(find.text('RELIANCE'), findsOneWidget);
    expect(find.text('Reliance Industries Ltd'), findsOneWidget);
    expect(
      find.text('22 Jan 2026 · 17 din baaki · pichla result 14 Oct 2025'),
      findsOneWidget,
    );
  });

  testWidgets('no announced date → the line is the last result, in full', (
    tester,
  ) async {
    await pump(tester);
    // SBIN has announced nothing, so Confirm (the default) hides it.
    await tester.tap(find.widgetWithText(ChoiceChip, 'Sab'));
    await tester.pumpAndSettle();

    // SBIN intimated nothing, so it gets no invented date — just the facts
    // about its last result: kab aaya, kaunsa quarter, kitne din hue.
    expect(
      find.text(
        'Pichla result: 04 Nov 2025 · Q2 · quarter ended Sep 2025 '
        '· 62 din hue',
      ),
      findsOneWidget,
    );
    expect(find.textContaining('anumanit'), findsNothing);
    expect(find.textContaining('03 Feb 2026'), findsNothing);
  });

  testWidgets('companies NSE never mentioned still get an honest line', (
    tester,
  ) async {
    await pump(tester);
    await tester.tap(find.widgetWithText(ChoiceChip, 'Sab'));
    await tester.pumpAndSettle();

    expect(find.text('TATAMOTORS'), findsOneWidget);
    expect(find.text('ABCAPITAL'), findsOneWidget);
    expect(
      find.text('NSE ke results feed me abhi nahi mila'),
      findsNWidgets(2),
    );
  });

  testWidgets('filter chips narrow the list, headline counts stay put', (
    tester,
  ) async {
    await pump(tester);

    // Tapped by widget type: the same words also appear as header stat and
    // as a row chip, so a plain find.text would be ambiguous.
    expect(
      find.text('Dikhaye ja rahe: 2 / 5'),
      findsOneWidget,
      reason: 'page opens on Confirm',
    );

    await tester.tap(find.widgetWithText(ChoiceChip, 'NSE me nahi'));
    await tester.pumpAndSettle();

    expect(find.text('Dikhaye ja rahe: 3 / 5'), findsOneWidget);
    expect(find.text('SBIN'), findsOneWidget);
    expect(find.text('RELIANCE'), findsNothing);

    await tester.tap(find.widgetWithText(ChoiceChip, 'Sab'));
    await tester.pumpAndSettle();
    expect(find.text('Dikhaye ja rahe: 5 / 5'), findsOneWidget);
  });

  testWidgets('har row ke aage chevron hai — tap karne layak nazar aata hai', (
    tester,
  ) async {
    await pump(tester);
    // Confirm filter me 2 row dikh rahi hain (RELIANCE, SIYSIL).
    expect(
      find.byIcon(Icons.chevron_right_rounded),
      findsNWidgets(2),
      reason: 'tap karne ka ishara har row par hona chahiye',
    );
  });

  testWidgets('row tap karne par pichle result ka hisaab khulta hai', (
    tester,
  ) async {
    await pump(tester);

    // Sheet pehle band hai.
    expect(find.text('Band karo'), findsNothing);

    await tester.tap(find.text('RELIANCE'));
    await tester.pumpAndSettle();

    // Sheet khul gayi: stock ka naam, aur **wajah** (is test me candles
    // nahi hain, isliye wahi likha hai — chhupaya nahi gaya).
    expect(find.text('Band karo'), findsOneWidget);
    expect(find.text('Reliance Industries Ltd'), findsWidgets);
    expect(
      find.textContaining('candles phone me nahi hain'),
      findsOneWidget,
      reason: 'khali sheet ke bajay wajah batani chahiye',
    );
    expect(
      find.textContaining('Ye itihaas hai, bhavishya nahi'),
      findsOneWidget,
      reason: 'imaandaari wali line hamesha',
    );
  });

  testWidgets('sheet band karne par list wapas aa jati hai', (tester) async {
    await pump(tester);

    await tester.tap(find.text('RELIANCE'));
    await tester.pumpAndSettle();
    expect(find.text('Band karo'), findsOneWidget);

    await tester.tap(find.text('Band karo'));
    await tester.pumpAndSettle();

    expect(find.text('Band karo'), findsNothing);
    expect(find.text('Results Calendar'), findsOneWidget);
  });

  testWidgets('search matches symbol and company name', (tester) async {
    await pump(tester);

    await tester.tap(find.widgetWithText(ChoiceChip, 'Sab'));
    await tester.pumpAndSettle();

    await tester.enterText(find.byType(TextField), 'bank');
    await tester.pumpAndSettle();

    expect(find.text('Dikhaye ja rahe: 1 / 5'), findsOneWidget);
    expect(find.text('SBIN'), findsOneWidget);
    expect(find.text('RELIANCE'), findsNothing);
  });

  testWidgets('an empty result explains itself instead of going blank', (
    tester,
  ) async {
    await pump(tester);

    await tester.enterText(find.byType(TextField), 'zzzz');
    await tester.pumpAndSettle();

    // The page opens on Confirm, so the empty state names both reasons.
    expect(
      find.textContaining(
        'Is search + "Confirm" filter me koi company nahi hai.',
      ),
      findsOneWidget,
    );
  });

  testWidgets('the refresh button re-reads NSE and shows the new date', (
    tester,
  ) async {
    await pump(tester);
    expect(earnings.forcedLoads, 0, reason: 'opening the page uses the cache');
    expect(find.textContaining('30 Jan 2026'), findsOneWidget);

    await tester.tap(find.byIcon(Icons.refresh_rounded));
    await tester.pumpAndSettle();

    expect(earnings.forcedLoads, 1);
    expect(find.textContaining('02 Feb 2026'), findsOneWidget);
    expect(find.textContaining('30 Jan 2026'), findsNothing);
  });

  testWidgets('a failed refresh keeps the old list and warns', (tester) async {
    await pump(tester, service: _FakeEarnings(failWith: 'NSE down'));

    await tester.tap(find.byIcon(Icons.refresh_rounded));
    await tester.pumpAndSettle();

    expect(
      find.textContaining('NSE se refresh nahi hua'),
      findsOneWidget,
      reason: 'the header must own up to the failure',
    );
    expect(
      find.text('Dikhaye ja rahe: 2 / 5'),
      findsOneWidget,
      reason: 'the Confirm filter still applies after a failed refresh',
    );
  });

  testWidgets('Read Me says no date is ever guessed', (tester) async {
    await pump(tester);

    await tester.tap(find.byIcon(Icons.help_outline_rounded));
    await tester.pumpAndSettle();

    expect(find.text('Results Calendar — Read Me'), findsOneWidget);
    expect(
      find.textContaining('sirf wahi date jo NSE ne khud batayi ho'),
      findsOneWidget,
    );
    expect(
      find.textContaining('Kisi bhi date ka andaza nahi lagaya jaata'),
      findsOneWidget,
    );

    await tester.tap(find.text('Samajh gaya'));
    await tester.pumpAndSettle();
    expect(find.text('Results Calendar — Read Me'), findsNothing);
  });

  testWidgets('the footer spells out that nothing is guessed', (tester) async {
    await pump(tester);

    expect(
      find.textContaining('Koi bhi date andaze se nahi banayi jaati'),
      findsOneWidget,
    );
    expect(find.textContaining('sirf PICHLA RESULT'), findsOneWidget);
  });
}
