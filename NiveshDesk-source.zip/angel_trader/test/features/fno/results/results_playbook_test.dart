// ---------------------------------------------------------------------------
// results_playbook_test.dart — "is stock ke pichle result din me kya hua tha?"
//
// Teen tareeke se chalaya jata hai:
//   * **pure** — buildPlaybook ka hisaab (koi DB, koi network nahi)
//   * **asli SQLite** (sqflite_common_ffi) — result_history taalika aur
//     provider ka playbook, candles ke saath
//   * **parse** — NSE ke filings jawab se poora itihaas nikalna
//
// Jo baat yahan pin hai: **koi andaza nahi**. Dates sirf NSE ki announced
// dates hain; jin dinon ke candles nahi hain unhe chhod diya jata hai aur
// chhodne ki ginti bhi dikhayi jati hai ("chhupaya nahi gaya").
//
//     flutter test test/features/fno/results/results_playbook_test.dart
// ---------------------------------------------------------------------------

import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/candle_dao.dart';
import 'package:angel_trader/data/local/dao/earnings_dao.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/data/local/dao/result_history_dao.dart';
import 'package:angel_trader/data/local/models/result_stamp.dart';
import 'package:angel_trader/core/utils/markets.dart' show Exchange;
import 'package:angel_trader/data/remote/api_client.dart' show ApiException;
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/features/fno/results/results_calendar_provider.dart';
import 'package:angel_trader/features/fno/results/results_playbook.dart';
import 'package:angel_trader/services/candle_source.dart';
import 'package:angel_trader/services/earnings_calendar_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

/// Har din ka ek candle — [day] se shuru hokar [count] session.
///
/// Result ke din (resultDays) par bhaav khul kar girta/uth-ta hai, taaki gap
/// aur din ka move alag-alag nazar aayen.
List<Candle> bars({
  required DateTime from,
  required int count,
  double start = 100,
  Map<int, double> openJumpAt = const {},
}) {
  final out = <Candle>[];
  for (var i = 0; i < count; i++) {
    final day = from.add(Duration(days: i));
    if (day.weekday == DateTime.saturday || day.weekday == DateTime.sunday) {
      continue; // weekend ka candle nahi hota
    }
    final close = start + i;
    final open = close + (openJumpAt[i] ?? 0);
    out.add(
      Candle(
        time: DateTime(day.year, day.month, day.day, 9, 15),
        open: open,
        high: open + 2,
        low: open - 2,
        close: close,
        volume: 1000,
      ),
    );
  }
  return out;
}

class _FakeCandleSource implements CandleSource {
  _FakeCandleSource({this.result = const [], this.error});

  final List<Candle> result;
  final Object? error;
  int calls = 0;
  Scrip? askedScrip;
  DateTime? askedFrom;
  DateTime? askedTo;

  @override
  Future<List<Candle>> fetchDailyCandles({
    required Scrip scrip,
    required DateTime from,
    required DateTime to,
    String interval = 'ONE_DAY',
  }) async {
    calls++;
    askedScrip = scrip;
    askedFrom = from;
    askedTo = to;
    if (error != null) throw error!;
    return result;
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  // -------------------------------------------------------------------------
  group('buildPlaybook — hisaab (pure)', () {
    final from = DateTime(2026, 1, 5); // Monday

    test('gap, result din aur agla din alag-alag nikalte hain', () {
      final series = bars(
        from: from,
        count: 30,
        start: 100,
        openJumpAt: {10: 5}, // 10th session: +5 ka gap
      );
      // 10th session (index 10) = 19 Jan 2026 (weekends chhod kar).
      final resultDay = series[10];
      final playbook = buildPlaybook(
        symbol: 'SBIN',
        bars: series,
        dates: [ResultStamp(date: resultDay.time, period: 'Q3')],
      );

      expect(playbook.samples, 1);
      final episode = playbook.episodes.single;
      expect(episode.period, 'Q3');

      // Gap = (open - pichla close) / pichla close
      final prevClose = series[9].close;
      expect(
        episode.gapPct,
        closeTo((resultDay.open - prevClose) / prevClose * 100, 0.001),
      );
      // Result din = (close - pichla close) / pichla close
      expect(
        episode.dayPct,
        closeTo((resultDay.close - prevClose) / prevClose * 100, 0.001),
      );
      // Agla din = (agli close - aaj ki close) / aaj ki close
      expect(
        episode.nextDayPct,
        closeTo(
          (series[11].close - resultDay.close) / resultDay.close * 100,
          0.001,
        ),
      );
      // Run-up = pichli close / 5 session pahle ki close
      expect(
        episode.runUpPct,
        closeTo((series[9].close / series[4].close - 1) * 100, 0.001),
      );
    });

    test('after-close result ka move agle session se banta hai', () {
      final series = bars(
        from: from,
        count: 20,
        start: 100,
        openJumpAt: {1: 5}, // Tuesday opening jump, after Monday result
      );
      final officialDate = series[0].time; // Monday, 05 Jan
      final reactionDay = series[1]; // Tuesday, 06 Jan

      final playbook = buildPlaybook(
        symbol: 'SBIN',
        bars: series,
        dates: [
          ResultStamp(
            date: officialDate,
            period: 'Q3',
            reactionDate: DateTime(2026, 1, 6),
          ),
        ],
      );

      final episode = playbook.episodes.single;
      expect(
        episode.date,
        officialDate,
        reason: 'UI me NSE ka asli filing din dikhna chahiye',
      );
      expect(
        episode.gapPct,
        closeTo(
          (reactionDay.open - series[0].close) / series[0].close * 100,
          0.001,
        ),
        reason: 'move us subah se ginna hai jo filing ke baad aayi',
      );
    });

    test('ek hi din do baar file hua to ek hi episode banta hai', () {
      final series = bars(from: from, count: 20);
      final day = series[5].time;
      final playbook = buildPlaybook(
        symbol: 'SBIN',
        bars: series,
        dates: [
          ResultStamp(date: day, period: 'Q3'),
          ResultStamp(date: day, period: 'Q3 (revised)'),
        ],
      );
      expect(playbook.samples, 1);
    });

    test('6 se jyada result nahi dikhaye jate (naye se purane)', () {
      final series = bars(from: from, count: 400);
      final dates = <ResultStamp>[
        for (var i = 10; i < 200; i += 20)
          ResultStamp(date: series[i].time, period: 'Q$i'),
      ];
      final playbook = buildPlaybook(
        symbol: 'SBIN',
        bars: series,
        dates: dates,
      );
      expect(playbook.samples, kPlaybookEpisodes);
      // Naya sabse upar.
      expect(
        playbook.episodes.first.date.isAfter(playbook.episodes.last.date),
        isTrue,
      );
    });

    test('jo result candles se purane hain, wo ginti me dikhaye jate hain', () {
      // Candles sirf 2026 ke hain; do dates 2024 ki hain → chhootengi.
      final series = bars(from: from, count: 200);
      final playbook = buildPlaybook(
        symbol: 'SBIN',
        bars: series,
        dates: [
          ResultStamp(date: DateTime(2024, 5, 2), period: 'Q1 FY24'),
          ResultStamp(date: DateTime(2024, 8, 1), period: 'Q2 FY24'),
          ResultStamp(date: series[20].time, period: 'Q3 FY26'),
        ],
        candleFrom: series.first.istDate,
        candleTo: series.last.istDate,
      );
      expect(playbook.samples, 1, reason: 'sirf candle range wala result');
      expect(
        playbook.olderThanCache,
        2,
        reason: 'baaki do chhute, par chhupaye nahi gaye',
      );
      expect(playbook.rangeNote, contains('2 aur purane result'));
      expect(playbook.rangeNote, contains('candles phone me nahi'));
    });

    test('candles hi na hon to wajah likhi jati hai, khaali note nahi', () {
      final playbook = buildPlaybook(
        symbol: 'SBIN',
        bars: const [],
        dates: [ResultStamp(date: DateTime(2026, 2, 2), period: 'Q3')],
      );
      expect(playbook.isEmpty, isTrue);
      expect(playbook.noCandles, isTrue);
      expect(playbook.note, contains('candles phone me nahi hain'));
      expect(playbook.note, isNot(contains('itihaas nahi mila')));
    });

    test('dates hi na hon to alag wajah', () {
      final playbook = buildPlaybook(
        symbol: 'SBIN',
        bars: bars(from: from, count: 20),
        dates: const [],
      );
      expect(playbook.isEmpty, isTrue);
      expect(playbook.note, contains('koi announced result itihaas nahi mila'));
    });

    test('up / down aur aam move sahi ginti se bante hain', () {
      // Do result: pehla +10%, doosra -5% (close ke hisaab se).
      final series = bars(from: from, count: 40, start: 100);
      final first = series[8];
      final second = series[20];

      // Seedhe close ko todh kar do alag moves banate hain.
      final tweaked = <Candle>[...series];
      tweaked[8] = Candle(
        time: first.time,
        open: first.open,
        high: first.high,
        low: first.low,
        close: series[7].close * 1.10, // +10%
        volume: 1,
      );
      tweaked[20] = Candle(
        time: second.time,
        open: second.open,
        high: second.high,
        low: second.low,
        close: series[19].close * 0.95, // -5%
        volume: 1,
      );

      final playbook = buildPlaybook(
        symbol: 'SBIN',
        bars: tweaked,
        dates: [
          ResultStamp(date: first.time, period: 'Q1'),
          ResultStamp(date: second.time, period: 'Q2'),
        ],
      );

      expect(playbook.samples, 2);
      expect(playbook.up, 1);
      expect(playbook.down, 1);
      expect(playbook.avgAbsDayPct, closeTo(7.5, 0.05));
      expect(playbook.maxAbsDayPct, closeTo(10, 0.05));
      expect(playbook.sufficient, isFalse, reason: '3 se kam = aadat nahi');
      expect(playbook.note, contains('Sirf 2 result mile'));
      expect(playbook.tileText, contains('pichle 2 result'));
    });
  });

  // -------------------------------------------------------------------------
  group('parseFinancialResultsHistory — NSE ke jawab se itihaas', () {
    const body = '''
    [{"symbol":"SBIN","exchdisstime":"04-Nov-2025 18:30","relatingTo":"Quarterly","toDate":"30-Sep-2025"},
     {"symbol":"SBIN","exchdisstime":"04-Aug-2025 19:00","relatingTo":"Quarterly","toDate":"30-Jun-2025"},
     {"symbol":"SBIN","exchdisstime":"04-Nov-2025 19:40","relatingTo":"Quarterly","toDate":"30-Sep-2025"},
     {"symbol":"RELIANCE","exchdisstime":"14-Oct-2025 17:30","relatingTo":"Quarterly","toDate":"30-Sep-2025"},
     {"symbol":"","exchdisstime":"14-Oct-2025 17:30"},
     {"symbol":"JUNK","broadCastDate":"not a date"}]
    ''';

    test('har symbol ke results naye se purane, duplicate din ek hi baar', () {
      final history = EarningsCalendarService.parseFinancialResultsHistory(
        body,
      );

      expect(history.keys.toSet(), {'SBIN', 'RELIANCE'});
      final sbin = history['SBIN']!;
      expect(sbin.length, 2, reason: 'ek din do filing = ek result');
      expect(sbin.first.date, DateTime(2025, 11, 4));
      expect(sbin.last.date, DateTime(2025, 8, 4));
      expect(sbin.first.period, isNotEmpty, reason: 'quarter ka label');
      expect(
        sbin.first.reactionDate,
        DateTime(2025, 11, 5),
        reason: 'filing 18:30 par hui: agla market session 5 Nov',
      );
      expect(
        sbin.last.reactionDate,
        DateTime(2025, 8, 5),
        reason: 'filing 19:00 par hui: agla market session 5 Aug',
      );
      expect(history['RELIANCE']!.single.date, DateTime(2025, 10, 14));
    });

    test('binu symbol ya kharaab date wali line chhod di jati hai', () {
      final history = EarningsCalendarService.parseFinancialResultsHistory(
        body,
      );
      expect(history.containsKey(''), isFalse);
      expect(history.containsKey('JUNK'), isFalse);
    });

    test('ek stock ke liye 8 se jyada purane result nahi rakhe jate', () {
      final many = StringBuffer('[');
      for (var i = 0; i < 12; i++) {
        if (i > 0) many.write(',');
        many.write(
          '{"symbol":"SBIN","exchdisstime":"0${(i % 9) + 1}-Jan-202'
          '${i % 2} 18:30"}',
        );
      }
      many.write(']');
      final history = EarningsCalendarService.parseFinancialResultsHistory(
        many.toString(),
      );
      expect(
        history['SBIN']!.length,
        lessThanOrEqualTo(EarningsCalendarService.historyPerSymbol),
      );
    });
  });

  // -------------------------------------------------------------------------
  group('refresh — NSE ke jawab se itihaas likha jata hai', () {
    const boardMeetings = """
[{"bm_symbol":"RELIANCE","bm_date":"22-Jan-2026","bm_purpose":"Board Meeting to consider and approve the Quarterly Financial results"}]
""";

    // RELIANCE ke do filing (Jan 2025 aur Oct 2025), SBIN ka ek.
    const filings = """
[{"symbol":"RELIANCE","exchdisstime":"16-Jan-2025 20:20:54","relatingTo":"Third Quarter","toDate":"31-Dec-2024","period":"Quarterly"},
 {"symbol":"RELIANCE","exchdisstime":"14-Oct-2025 21:05:11","relatingTo":"Second Quarter","toDate":"30-Sep-2025","period":"Quarterly"},
 {"symbol":"SBIN","exchdisstime":"04-Nov-2025 18:02:00","relatingTo":"Second Quarter","toDate":"30-Sep-2025","period":"Quarterly"}]
""";

    setUp(() async {
      AppDatabase.overridePath = inMemoryDatabasePath;
      await AppDatabase.instance.close();
    });

    tearDown(() async {
      await AppDatabase.instance.close();
      AppDatabase.overridePath = null;
    });

    test(
      'refresh ke baad result_history me dono filing aa jati hain',
      () async {
        final history = ResultHistoryDao(AppDatabase.instance);
        final svc = EarningsCalendarService(
          dao: EarningsDao(AppDatabase.instance),
          settings: SettingsDao(AppDatabase.instance),
          history: history,
          now: () => DateTime(2026, 1, 5),
          get: (uri) async {
            if (uri.toString() == EarningsCalendarService.warmUpUrl) {
              return '<html>home</html>';
            }
            return uri.path.contains('board-meetings')
                ? boardMeetings
                : filings;
          },
        );

        await svc.refresh();

        final reliance = await history.forSymbol('RELIANCE');
        expect(
          reliance.length,
          2,
          reason: 'poora itihaas — sirf aakhiri result nahi',
        );
        expect(reliance.first.date, DateTime(2025, 10, 14));
        expect(reliance.last.date, DateTime(2025, 1, 16));
        expect(
          (await history.forSymbol('SBIN')).single.date,
          DateTime(2025, 11, 4),
        );

        // Calendar ka purana kaam bhi waisa hi chalta rahe — aakhiri result.
        final earnings = await EarningsDao(AppDatabase.instance).all();
        expect(earnings['RELIANCE']!.lastDate, DateTime(2025, 10, 14));
        expect(earnings['RELIANCE']!.nextDate, DateTime(2026, 1, 22));
      },
    );

    test('itihaas khaali ho to taaza cache ke baawajood ek baar dobara padha '
        'jata hai', () async {
      final history = ResultHistoryDao(AppDatabase.instance);
      final settings = SettingsDao(AppDatabase.instance);
      var calls = 0;

      EarningsCalendarService service() => EarningsCalendarService(
        dao: EarningsDao(AppDatabase.instance),
        settings: settings,
        history: history,
        now: () => DateTime(2026, 1, 5),
        get: (uri) async {
          if (uri.toString() == EarningsCalendarService.warmUpUrl) {
            return '<html>home</html>';
          }
          if (uri.path.contains('financial-results')) calls++;
          return uri.path.contains('board-meetings') ? boardMeetings : filings;
        },
      );

      // Pehli baar: itihaas khaali → fetch.
      await service().refresh();
      expect(calls, 1);
      expect(await history.forSymbol('RELIANCE'), hasLength(2));

      // Ab stamp likha ja chuka hai → dubara load par koi network nahi.
      final second = service();
      await second.load();
      expect(calls, 1, reason: 'itihaas mil chuka — dobara NSE nahi bulana');

      // Stamp hata do (jaise kisi purane build ka data) → ek baar phir.
      await settings.putMeta(EarningsCalendarService.metaResultHistoryAt, '');
      final third = service();
      await third.load();
      expect(calls, 2, reason: 'itihaas ka stamp mit gaya to ek baar phir');
    });

    test(
      'history ka DAO na ho to refresh chalta rahta hai (purana rasta)',
      () async {
        final svc = EarningsCalendarService(
          dao: EarningsDao(AppDatabase.instance),
          settings: SettingsDao(AppDatabase.instance),
          now: () => DateTime(2026, 1, 5),
          get: (uri) async {
            if (uri.toString() == EarningsCalendarService.warmUpUrl) {
              return '<html>home</html>';
            }
            return uri.path.contains('board-meetings')
                ? boardMeetings
                : filings;
          },
        );

        await svc.refresh();
        final earnings = await EarningsDao(AppDatabase.instance).all();
        expect(earnings['RELIANCE']!.nextDate, DateTime(2026, 1, 22));
        expect(svc.lastFetchFailed, isFalse);
      },
    );
  });

  // -------------------------------------------------------------------------
  group('ResultHistoryDao + provider (asli SQLite)', () {
    setUp(() async {
      AppDatabase.overridePath = inMemoryDatabasePath;
      await AppDatabase.instance.close();
    });

    tearDown(() async {
      await AppDatabase.instance.close();
      AppDatabase.overridePath = null;
    });

    test('itihaas likha aur naye se purane padha jata hai', () async {
      final dao = ResultHistoryDao(AppDatabase.instance);
      await dao.replaceFor('SBIN', [
        ResultStamp(
          date: DateTime(2025, 8, 4),
          period: 'Q1',
          reactionDate: DateTime(2025, 8, 5),
        ),
        ResultStamp(date: DateTime(2025, 11, 4), period: 'Q2'),
        ResultStamp(date: DateTime(2026, 2, 3), period: 'Q3'),
      ]);

      final read = await dao.forSymbol('sbin'); // case-insensitive
      expect(read.map((e) => e.date), [
        DateTime(2026, 2, 3),
        DateTime(2025, 11, 4),
        DateTime(2025, 8, 4),
      ]);
      expect(read.first.period, 'Q3');
      expect(
        read.last.reactionDate,
        DateTime(2025, 8, 5),
        reason: 'after-close reaction day DB me bhi bachi rahe',
      );
      expect(await dao.countSymbols(), 1);

      // Dobara likhne par purana mit jata hai ( replace = replace, merge nahi).
      await dao.replaceFor('SBIN', [
        ResultStamp(date: DateTime(2026, 5, 4), period: 'Q4'),
      ]);
      final again = await dao.forSymbol('SBIN');
      expect(again.single.date, DateTime(2026, 5, 4));
    });

    test('replaceAll purani taalika saaf karta hai', () async {
      final dao = ResultHistoryDao(AppDatabase.instance);
      await dao.replaceAll({
        'SBIN': [ResultStamp(date: DateTime(2025, 11, 4), period: 'Q2')],
      });
      await dao.replaceAll({
        'RELIANCE': [ResultStamp(date: DateTime(2025, 10, 14), period: 'Q2')],
      });
      expect(
        await dao.forSymbol('SBIN'),
        isEmpty,
        reason: 'NSE se hatne par purani line nahi rehni chahiye',
      );
      expect(await dao.forSymbol('RELIANCE'), hasLength(1));
    });

    test('provider: candles + itihaas se playbook banta hai', () async {
      final candles = CandleDao(AppDatabase.instance);
      final history = ResultHistoryDao(AppDatabase.instance);

      final series = bars(from: DateTime(2025, 9, 1), count: 200, start: 100);
      await candles.saveBars(exchange: 'NSE', symbol: 'SBIN-EQ', bars: series);
      await history.replaceFor('SBIN', [
        ResultStamp(date: series[20].time, period: 'Q2'),
        ResultStamp(date: series[60].time, period: 'Q3'),
        ResultStamp(date: series[100].time, period: 'Q4'),
      ]);

      final fetcher = _FakeCandleSource();
      final provider = ResultsCalendarProvider(
        earnings: EarningsCalendarService(
          dao: EarningsDao(AppDatabase.instance),
          settings: SettingsDao(AppDatabase.instance),
        ),
        candles: candles,
        history: history,
        candleSource: fetcher,
        resolveScrip: (_) async => const Scrip(
          token: '123',
          symbol: 'SBIN-EQ',
          name: 'State Bank of India',
          exchange: Exchange.nse,
        ),
        now: () => DateTime(2026, 3, 1),
      );

      final playbook = await provider.playbookFor(
        const ResultRow(symbol: 'SBIN', name: 'State Bank of India'),
      );

      expect(playbook.samples, 3);
      expect(playbook.episodes.map((e) => e.period), ['Q4', 'Q3', 'Q2']);
      expect(playbook.noCandles, isFalse);
      expect(playbook.olderThanCache, 0);
      expect(playbook.rangeNote, contains('Candles phone me'));
      expect(
        fetcher.calls,
        0,
        reason: 'broker-suffix cache was already complete',
      );

      // Doosri baar wahi object (cache) — DB dobara nahi padha jata.
      final again = await provider.playbookFor(
        const ResultRow(symbol: 'SBIN', name: 'State Bank of India'),
      );
      expect(identical(again, playbook), isTrue);
    });

    test(
      'provider: cache miss par ek stock ke candles khud fetch aur save hote hain',
      () async {
        final candles = CandleDao(AppDatabase.instance);
        final history = ResultHistoryDao(AppDatabase.instance);
        final series = bars(from: DateTime(2025, 1, 1), count: 260, start: 100);
        final eventDates = [
          ResultStamp(date: series[20].time, period: 'Q1'),
          ResultStamp(date: series[80].time, period: 'Q2'),
          ResultStamp(date: series[140].time, period: 'Q3'),
        ];
        await history.replaceFor('SBIN', eventDates);

        final fetcher = _FakeCandleSource(result: series);
        const scrip = Scrip(
          token: '123',
          symbol: 'SBIN-EQ',
          name: 'State Bank of India',
          exchange: Exchange.nse,
        );
        final provider = ResultsCalendarProvider(
          earnings: EarningsCalendarService(
            dao: EarningsDao(AppDatabase.instance),
            settings: SettingsDao(AppDatabase.instance),
          ),
          candles: candles,
          history: history,
          candleSource: fetcher,
          resolveScrip: (_) async => scrip,
          now: () => DateTime(2025, 10, 1),
        );

        final playbook = await provider.playbookFor(
          const ResultRow(symbol: 'SBIN', name: 'State Bank of India'),
        );

        expect(
          fetcher.calls,
          1,
          reason: 'one row tap → one daily candle request for that stock',
        );
        expect(fetcher.askedScrip?.symbol, 'SBIN-EQ');
        expect(fetcher.askedFrom, isNotNull);
        expect(fetcher.askedTo, isNotNull);
        expect(playbook.samples, 3);
        expect(
          await candles.barsFor(exchange: 'NSE', symbol: 'SBIN-EQ'),
          hasLength(series.length),
          reason: 'download is saved in the normal shared candle cache',
        );

        // Second tap reuses the playbook and saved candles.
        await provider.playbookFor(
          const ResultRow(symbol: 'SBIN', name: 'State Bank of India'),
        );
        expect(fetcher.calls, 1);
      },
    );

    test('provider: login na ho to saaf actionable error mile', () async {
      final candles = CandleDao(AppDatabase.instance);
      final history = ResultHistoryDao(AppDatabase.instance);
      final series = bars(from: DateTime(2025, 1, 1), count: 120);
      await history.replaceFor('SBIN', [
        ResultStamp(date: series[20].time, period: 'Q1'),
      ]);

      final fetcher = _FakeCandleSource(
        error: const ApiException(
          message: 'Not logged in to Angel One.',
          isAuthError: true,
        ),
      );
      final provider = ResultsCalendarProvider(
        earnings: EarningsCalendarService(
          dao: EarningsDao(AppDatabase.instance),
          settings: SettingsDao(AppDatabase.instance),
        ),
        candles: candles,
        history: history,
        candleSource: fetcher,
        resolveScrip: (_) async => const Scrip(
          token: '123',
          symbol: 'SBIN-EQ',
          name: 'State Bank of India',
          exchange: Exchange.nse,
        ),
        now: () => DateTime(2025, 5, 1),
      );

      await expectLater(
        provider.playbookFor(
          const ResultRow(symbol: 'SBIN', name: 'State Bank of India'),
        ),
        throwsA(
          isA<ResultPlaybookLoadException>().having(
            (error) => error.message,
            'message',
            contains('Angel One me login zaroori hai'),
          ),
        ),
      );
    });

    test(
      'provider: itihaas na ho to sirf aakhiri result se ek episode',
      () async {
        final candles = CandleDao(AppDatabase.instance);
        final series = bars(from: DateTime(2025, 9, 1), count: 120);
        await candles.saveBars(exchange: 'NSE', symbol: 'TATA', bars: series);

        final provider = ResultsCalendarProvider(
          earnings: EarningsCalendarService(
            dao: EarningsDao(AppDatabase.instance),
            settings: SettingsDao(AppDatabase.instance),
          ),
          candles: candles,
          history: ResultHistoryDao(AppDatabase.instance),
        );

        final playbook = await provider.playbookFor(
          ResultRow(
            symbol: 'TATA',
            name: 'Tata',
            lastDate: series[30].time,
            lastLabel: 'Q2',
          ),
        );

        expect(
          playbook.samples,
          1,
          reason: 'andaza nahi — bas itna hi pata hai jo NSE ne bataya',
        );
        expect(playbook.episodes.single.period, 'Q2');
        expect(playbook.note, contains('Sirf 1 result mile'));
      },
    );
  });
}
