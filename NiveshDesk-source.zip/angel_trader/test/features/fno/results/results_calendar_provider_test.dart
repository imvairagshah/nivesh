// ---------------------------------------------------------------------------
// results_calendar_provider_test.dart — the standalone Results Calendar page.
//
// Pinned here:
//   • every F&O company gets a row — NSE me row na ho to bhi (honest line),
//   • list order: nearest date first, no-date rows last,
//   • counts describe the *whole* list and never move with the filter,
//   • confirm vs "no date" stay two different things, and nothing is guessed,
//   • one NSE fetch a day feeds both this page and the study panel.
// ---------------------------------------------------------------------------

import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/earnings_dao.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/features/fno/results/results_calendar_provider.dart';
import 'package:angel_trader/services/earnings_calendar_service.dart';
import 'package:angel_trader/services/fno_universe.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

/// RELIANCE + SIYSIL have board-meeting intimations; TATAMOTORS only a
/// dividend meeting (must not look like a results date).
const _boardMeetings = '''
[
  {"bm_symbol":"RELIANCE","bm_date":"22-Jan-2026","bm_purpose":"to consider and approve the Quarterly Unaudited Financial results","bm_timestamp":"04-Jan-2026 10:15:00"},
  {"bm_symbol":"SIYSIL","bm_date":"30-Jan-2026","bm_purpose":"to consider and approve the Quarterly Unaudited Financial results","bm_timestamp":"02-Jan-2026 10:00:00"},
  {"bm_symbol":"TATAMOTORS","bm_date":"05-Feb-2026","bm_purpose":"to consider a dividend on equity shares"}
]
''';

/// RELIANCE and SBIN filed; the rest did not.
const _financialResults = '''
[
  {"symbol":"RELIANCE","exchdisstime":"14-Oct-2025 21:05:11","relatingTo":"Second Quarter","toDate":"30-Sep-2025"},
  {"symbol":"SBIN","exchdisstime":"04-Nov-2025 18:02:00","relatingTo":"Second Quarter","toDate":"30-Sep-2025"}
]
''';

/// The shipped F&O list, trimmed to five names for the test.
const _universe = FnoUniverse(
  symbols: ['ABCAPITAL', 'RELIANCE', 'SBIN', 'SIYSIL', 'TATAMOTORS'],
  companyNames: {
    'ABCAPITAL': 'Aditya Birla Capital Ltd',
    'RELIANCE': 'Reliance Industries Ltd',
    'SBIN': 'State Bank of India',
    'SIYSIL': 'Siyaram Silk Mills Ltd',
    'TATAMOTORS': 'Tata Motors Ltd',
  },
);

void main() {
  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  late EarningsCalendarService service;
  late int calls;

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close();
    calls = 0;
    service = EarningsCalendarService(
      dao: EarningsDao(AppDatabase.instance),
      settings: SettingsDao(AppDatabase.instance),
      now: () => DateTime(2026, 1, 5),
      get: (uri) async {
        calls++;
        if (uri.toString() == EarningsCalendarService.warmUpUrl) {
          return '<html>home</html>';
        }
        if (uri.path.contains('board-meetings')) return _boardMeetings;
        return _financialResults;
      },
    );
  });

  tearDown(() async {
    await AppDatabase.instance.close();
    AppDatabase.overridePath = null;
  });

  ResultsCalendarProvider provider({FnoUniverse? universe}) =>
      ResultsCalendarProvider(
        earnings: service,
        fnoUniverse: universe ?? _universe,
        now: () => DateTime(2026, 1, 5, 9, 30),
      );

  // ---------------------------------------------------------------------
  group('rows', () {
    test('every F&O company gets a line, nearest date first', () async {
      final p = provider();
      await p.bootstrap();

      expect(p.total, 5, reason: 'the whole F&O list, not just NSE rows');
      expect(
        p.allRows.map((r) => r.symbol).toList(),
        ['RELIANCE', 'SIYSIL', 'ABCAPITAL', 'SBIN', 'TATAMOTORS'],
        reason:
            'announced dates first (22 & 30 Jan), then every company '
            'without one — in symbol order',
      );
    });

    test(
      'a company NSE never mentioned still shows, as "NSE me nahi"',
      () async {
        final p = provider();
        await p.bootstrap();

        final tatamotors = p.allRows.firstWhere(
          (r) => r.symbol == 'TATAMOTORS',
        );
        expect(
          tatamotors.hasDate,
          isFalse,
          reason: 'a dividend board meeting is not a results date',
        );
        expect(tatamotors.tagLabel, 'NSE me nahi');
        expect(tatamotors.lastDate, isNull);
      },
    );

    test('no announcement → no next date, only the last-result line', () async {
      final p = provider();
      await p.bootstrap();

      final sbin = p.allRows.firstWhere((r) => r.symbol == 'SBIN');
      expect(
        sbin.nextDate,
        isNull,
        reason:
            'nothing is estimated — 04 Nov 2025 filing + 91 din is a '
            'guess, and a guess reads as a fact',
      );
      expect(sbin.hasDate, isFalse);
      expect(sbin.nextConfirmed, isFalse);
      expect(sbin.tagLabel, 'NSE me nahi');
      // What the row *does* carry: the last result, in one readable line.
      expect(sbin.lastDate, DateTime(2025, 11, 4));
      expect(sbin.lastLabel, contains('Q2'));
      expect(
        sbin.lastResultLine(p.today),
        '04 Nov 2025 · Q2 · quarter ended Sep 2025 · 62 din hue',
      );
    });

    test(
      'a company whose last result is unknown has no line to print',
      () async {
        final p = provider();
        await p.bootstrap();

        final tatamotors = p.allRows.firstWhere(
          (r) => r.symbol == 'TATAMOTORS',
        );
        expect(tatamotors.nextDate, isNull);
        expect(tatamotors.lastDate, isNull);
        expect(tatamotors.lastResultLine(p.today), '');
      },
    );

    test(
      'a legacy guessed row from an older cache shows no date either',
      () async {
        // What build 1.5.12 left in the table: a next date nobody announced.
        final dao = EarningsDao(AppDatabase.instance);
        await dao.replaceAll({
          'SBIN': EarningsInfo(
            lastDate: DateTime(2025, 11, 4),
            lastLabel: 'Q2 · quarter ended Sep 2025',
            nextDate: DateTime(2026, 2, 3),
            nextLabel: 'anumanit (pichle result se)',
            estimated: true,
          ),
        });
        // Marked fresh so the page reads the cache — which is where a phone that
        // just updated from 1.5.12 would find the old guessed dates.
        await SettingsDao(AppDatabase.instance).putMeta(
          EarningsCalendarService.metaFetchedAt,
          DateTime(2026, 1, 5).toIso8601String(),
        );

        final p = provider();
        await p.bootstrap();
        expect(calls, 0, reason: 'no NSE trip — this is the cache path');

        final sbin = p.allRows.firstWhere((r) => r.symbol == 'SBIN');
        expect(
          sbin.nextDate,
          isNull,
          reason: 'an old guess must not resurface',
        );
        expect(sbin.hasDate, isFalse);
        expect(sbin.lastDate, DateTime(2025, 11, 4));
      },
    );

    test('the page opens on Confirm — announced dates only', () async {
      final p = provider();
      await p.bootstrap();

      expect(p.filter, ResultsFilter.confirmed);
      expect(p.rows.map((r) => r.symbol), [
        'RELIANCE',
        'SIYSIL',
      ], reason: 'sirf wahi companies jinke board meeting ka notice hai');
      // …par headline counts hamesha poori list ke hote hain (1.5.6 rule).
      expect(p.total, 5);
      expect(p.confirmedCount, 2);
      expect(p.missingCount, 3);
    });

    test(
      'Naya declared comes only from the official NSE broadcast date',
      () async {
        final p = provider();
        await p.bootstrap();

        final reliance = p.allRows.firstWhere((r) => r.symbol == 'RELIANCE');
        final siysil = p.allRows.firstWhere((r) => r.symbol == 'SIYSIL');
        expect(reliance.newlyDeclared, isTrue);
        expect(reliance.newlyDeclaredAt, DateTime(2026, 1, 4, 10, 15));
        expect(siysil.newlyDeclared, isFalse);

        p.setFilter(ResultsFilter.newlyDeclared);
        expect(p.rows.map((r) => r.symbol), ['RELIANCE']);
        expect(p.newlyDeclaredCount, 1);
      },
    );

    test('countdown reads like the panel: aaj / kal / N din baaki', () async {
      final p = provider();
      await p.bootstrap();

      final reliance = p.allRows.firstWhere((r) => r.symbol == 'RELIANCE');
      expect(reliance.daysAway(p.today), 17);
      expect(ResultRow.countdown(reliance.daysAway(p.today)!), '17 din baaki');
      expect(ResultRow.countdown(1), 'kal');
      expect(ResultRow.countdown(0), 'aaj');
      expect(ResultRow.countdown(-2), 'ho gaya');
    });

    test('headline counts describe the whole list', () async {
      final p = provider();
      await p.bootstrap();

      expect(p.confirmedCount, 2, reason: 'RELIANCE + SIYSIL announced');
      expect(p.lastKnownCount, 2, reason: 'RELIANCE + SBIN filed a result');
      expect(p.missingCount, 3, reason: 'no announced date for the rest');
      expect(p.total, 5);

      // …aur filter badalne par bhi yeh counts nahi hilte (1.5.6 rule).
      p.setFilter(ResultsFilter.missing);
      expect(p.rows.length, 3);
      expect(p.total, 5);
      expect(p.confirmedCount, 2);
    });
  });

  // ---------------------------------------------------------------------
  group('filter + search', () {
    test('filters split the three kinds of date', () async {
      final p = provider();
      await p.bootstrap();

      p.setFilter(ResultsFilter.confirmed);
      expect(p.rows.map((r) => r.symbol), ['RELIANCE', 'SIYSIL']);

      p.setFilter(ResultsFilter.missing);
      expect(p.rows.map((r) => r.symbol), ['ABCAPITAL', 'SBIN', 'TATAMOTORS']);

      p.setFilter(ResultsFilter.all);
      expect(p.rows.length, 5);
    });

    test('search matches the symbol and the company name', () async {
      final p = provider();
      await p.bootstrap();
      p.setFilter(ResultsFilter.all); // search across the whole list

      p.setQuery('reli');
      expect(p.rows.map((r) => r.symbol), ['RELIANCE']);

      p.setQuery('bank of india');
      expect(p.rows.map((r) => r.symbol), ['SBIN']);

      p.setQuery('zzzz');
      expect(p.rows, isEmpty);
      expect(p.emptyReason, contains('search'));

      p.setQuery('');
      expect(p.rows.length, 5);
    });

    test('an empty filter has its own explanation', () async {
      final p = provider();
      await p.bootstrap();

      p.setFilter(ResultsFilter.missing);
      p.setQuery('reliance');
      expect(p.rows, isEmpty);
      expect(p.emptyReason, contains('NSE me nahi'));
    });
  });

  // ---------------------------------------------------------------------
  group('NSE traffic', () {
    test(
      'bootstrap uses the day cache — one fetch serves both screens',
      () async {
        final p = provider();
        await p.bootstrap();
        final afterFirst = calls;
        expect(afterFirst, 3, reason: 'warm-up + two NSE feeds');

        final second = provider(); // e.g. page reopened
        await second.bootstrap();
        expect(calls, afterFirst, reason: 'cache is still fresh (20 h window)');
        expect(second.total, 5);
        expect(second.rows.first.symbol, 'RELIANCE');
      },
    );

    test('refresh asks NSE again', () async {
      final p = provider();
      await p.bootstrap();
      final afterFirst = calls;

      await p.refresh();
      expect(calls, afterFirst + 3);
      expect(p.hasLoaded, isTrue);
    });

    test('a failed fetch keeps the last list and says so', () async {
      final p = provider();
      await p.bootstrap();
      expect(p.note, isNull);

      final offline = ResultsCalendarProvider(
        earnings: EarningsCalendarService(
          dao: EarningsDao(AppDatabase.instance),
          settings: SettingsDao(AppDatabase.instance),
          now: () => DateTime(2026, 1, 9),
          get: (uri) async => throw Exception('NSE down'),
        ),
        fnoUniverse: _universe,
        now: () => DateTime(2026, 1, 9),
      );
      await offline.bootstrap();

      expect(offline.note, isNotNull);
      expect(offline.allRows.length, 5, reason: 'cached list survives');
      expect(
        offline.allRows.firstWhere((r) => r.symbol == 'RELIANCE').nextDate,
        DateTime(2026, 1, 22),
      );
    });

    test('board-meeting request carries an explicit date window', () async {
      final uris = <Uri>[];
      final svc = EarningsCalendarService(
        dao: EarningsDao(AppDatabase.instance),
        settings: SettingsDao(AppDatabase.instance),
        now: () => DateTime(2026, 1, 5),
        get: (uri) async {
          uris.add(uri);
          return uri.path.contains('board-meetings') ? '[]' : '[]';
        },
      );
      await svc.refresh();

      final meetings = uris.firstWhere(
        (u) => u.path.contains('board-meetings'),
      );
      expect(
        meetings.queryParameters['from_date'],
        '27-09-2025',
        reason:
            '~100 din peeche — isse pata chalta hai kaunse results '
            'declare ho chuke hain, chahe filings feed der se aaye',
      );
      expect(
        meetings.queryParameters['to_date'],
        '05-05-2026',
        reason: '~120 din aage, warna agle quarter ka notice miss ho jaata',
      );
    });
  });

  // ---------------------------------------------------------------------
  group('broken universe', () {
    test('missing F&O CSV falls back to the symbols NSE gave', () async {
      final p = provider(universe: FnoUniverse.empty);
      await p.bootstrap();

      expect(p.usingFallbackUniverse, isTrue);
      expect(
        p.total,
        3,
        reason: 'RELIANCE + SIYSIL + SBIN — the companies NSE mentioned',
      );
    });
  });
  // ---------------------------------------------------------------------
  group('no data (the blank-page guard)', () {
    test(
      'an NSE that answers nothing is reported, not shown as empty',
      () async {
        // A service whose every answer is empty — the page must not sit blank.
        final dead = EarningsCalendarService(
          dao: EarningsDao(AppDatabase.instance),
          settings: SettingsDao(AppDatabase.instance),
          now: () => DateTime(2026, 1, 5),
          get: (uri) async => '[]',
        );
        final p = ResultsCalendarProvider(
          earnings: dead,
          fnoUniverse: _universe,
          now: () => DateTime(2026, 1, 5, 9, 30),
        );
        await p.bootstrap();

        expect(p.total, 5, reason: 'the F&O list still renders');
        expect(p.hasAnyData, isFalse);
        expect(p.fetchFailed, isTrue);
        expect(p.note, isNotNull, reason: 'the user must be told why');
        expect(p.attemptedAt, isNotNull, reason: 'an attempt did happen');
      },
    );

    test('dates coming in clears the warning and marks hasAnyData', () async {
      final p = provider();
      await p.bootstrap();

      expect(p.hasAnyData, isTrue);
      expect(p.fetchFailed, isFalse);
      expect(p.note, isNull, reason: 'a success remark is not a warning');
    });
  });
}
