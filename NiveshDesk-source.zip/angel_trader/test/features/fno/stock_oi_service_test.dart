// 1.5.86 — Stock OI service: URL shape, memory cache, aur "file nahi mili to
// peeche walk" behaviour. Network injected fake se (koi real call nahi).

import 'dart:convert';

import 'package:angel_trader/features/fno/stock_oi/stock_oi_service.dart';
import 'package:archive/archive.dart';
import 'package:flutter_test/flutter_test.dart';

const _header = 'TradDt,BizDt,Sgmt,Src,FinInstrmTp,FinInstrmAIS12,ISIN,'
    'TckrSymb,SctySrs,XpryDt,FininstrmActlXpryDt,StrkPric,OptnTp,FinInstrmNm,'
    'OpnPric,HghPric,LwPric,ClsPric,LastPric,PrvsClsgPric,UndrlygPric,'
    'SttlmPric,OpnIntrst,ChngInOpnIntrst,TtlTradgVol,TtlTrfVal,TtlNbOfTxsExctd,'
    'SsnId,NewBrdLotQty,Rmks,Rsvd01';

String _row(String symbol, double strike, double oi, double chg) =>
    '2026-11-11,2026-11-11,FO,NSE,STO,${symbol}EQ,INE002A01018,$symbol,BE,'
    '2026-11-26,2026-11-26,$strike,CE,${symbol}${strike.toInt()}CE,10,20,5,'
    '50,50,45,1500,0,$oi,$chg,1000,100,10,F1,250,,0';

List<int> _zipWithCsv(String csv) {
  final archive = Archive()
    ..addFile(ArchiveFile(
        'BhavCopy_NSE_FO.csv', utf8.encode(csv).length, utf8.encode(csv)));
  return ZipEncoder().encode(archive)!;
}

void main() {
  test('foBhavcopyUrl — official UDiFF path + zero-padded date', () {
    final url = StockOiService.foBhavcopyUrl(DateTime(2026, 11, 5));
    expect(url.host, 'nsearchives.nseindia.com');
    expect(url.path,
        '/content/fo/BhavCopy_NSE_FO_0_0_0_20261105_F_0000.csv.zip');
  });

  test('load — CSV parse ho kar book banti hai (fetch ek hi baar)', () async {
    var calls = 0;
    final service = StockOiService(
      clock: () => DateTime(2026, 11, 11, 19),
      getBytes: (uri, {refererPath}) async {
        calls++;
        return _zipWithCsv('$_header\n${_row('RELIANCE', 3000, 120000, 20000)}');
      },
    );

    final res = await service.load();
    expect(res.tradeDate, DateTime(2026, 11, 11));
    expect(res.book.rowCount, 1);
    expect(res.book.bySymbol.containsKey('RELIANCE'), isTrue);

    // Dobara load → cache (koi naya download nahi)
    await service.load();
    expect(calls, 1);

    // force → dobara download
    await service.load(force: true);
    expect(calls, 2);
  });

  test('load — file 404 to pichhla din try hota hai (walk-back)', () async {
    final requested = <String>[];
    final service = StockOiService(
      clock: () => DateTime(2026, 11, 11, 19),
      getBytes: (uri, {refererPath}) async {
        requested.add(uri.path);
        if (uri.path.contains('20261111')) {
          throw Exception('404');
        }
        return _zipWithCsv('$_header\n${_row('INFY', 1500, 80000, -10000)}');
      },
    );

    final res = await service.load();
    expect(res.tradeDate, DateTime(2026, 11, 10));
    expect(requested.first, contains('20261111'));
    expect(requested[1], contains('20261110'));
  });

  test('load — sab din fail to honest exception', () async {
    final service = StockOiService(
      clock: () => DateTime(2026, 11, 11, 19),
      getBytes: (uri, {refererPath}) async => throw Exception('network down'),
    );
    expect(
      () => service.load(maxWalkBack: 3),
      throwsA(isA<StockOiFetchException>()),
    );
  });
}
