// ---------------------------------------------------------------------------
// study_adv_plan_test.dart — "aaj kya kare": entry / stop / target.
//
// Yahan do cheezein pakki ki jati hain:
//
//   1. HISAAB SAHI HAI — stock ka plan charhte/girte bazaar me ulta na ho,
//      rukawat (DP) ke paas ho to wahi stop chune, aur option bechne me
//      premium ka aadha target / 1.5× stop ho.
//   2. SACH BOLNA — delta na mile to wahi likha jaye; seedha bazaar ho to
//      "koi plan nahi" likha jaye; aur har plan ke saath "mechanical niyam,
//      guarantee nahi" likha ho.
// ---------------------------------------------------------------------------

import 'package:angel_trader/features/fno/study/black_scholes.dart'
    show OptionType;
import 'package:angel_trader/features/fno/study/study_engine.dart';
import 'package:angel_trader/features/fno/study_adv/study_adv_analysis.dart';
import 'package:angel_trader/features/fno/study_adv/study_adv_plan.dart';
import 'package:flutter_test/flutter_test.dart';

StudyOptionLeg leg(double strike, OptionType type, double ltp) =>
    StudyOptionLeg(
      strike: strike,
      type: type,
      token: '$strike-${type.name}',
      symbol: '$strike-${type.name}',
      ltp: ltp,
      previousClose: ltp * 0.9,
    );

DpRow dpRow({required double cmp, double? down, double? up}) => DpRow(
      symbol: 'AAA',
      cmp: cmp,
      nearestUp: up == null
          ? null
          : DpLevel(
              price: up,
              touches: 2,
              kind: 'upar',
              isNearestUp: true,
              isNearestDown: false,
              distancePct: (up - cmp) / cmp * 100,
            ),
      nearestDown: down == null
          ? null
          : DpLevel(
              price: down,
              touches: 2,
              kind: 'neeche',
              isNearestUp: false,
              isNearestDown: true,
              distancePct: (down - cmp) / cmp * 100,
            ),
      days: 60,
    );

void main() {
  const cmp = 1000.0;
  const atr = 20.0;

  group('stock ka plan', () {
    test('charhte bazaar me kharidna — stop 1 ATR neeche, target 2 ATR upar',
        () {
      final plan = buildStockPlan(
        cmp: cmp,
        atr: atr,
        trend: Trend3M.up,
      )!;

      expect(plan.side, PlanSide.buy);
      expect(plan.entry, 1000);
      expect(plan.stop, 980); // 1×ATR
      expect(plan.target, 1040); // 2×ATR
      expect(plan.rewardRatio, closeTo(2.0, 0.001));
      expect(plan.basis, StopBasis.atr);
    });

    test('support kareeb ho to wahi stop chuna jata hai (chhota nuksaan)', () {
      // 1 ATR wala stop 980, support 995 ke thoda neeche ~990 → 990 kareeb hai.
      final plan = buildStockPlan(
        cmp: cmp,
        atr: atr,
        trend: Trend3M.up,
        dp: dpRow(cmp: cmp, down: 995),
      )!;

      expect(plan.basis, StopBasis.dp);
      expect(plan.stop, closeTo(990.02, 0.5)); // 995 × 0.995
      expect(plan.stop, greaterThan(980));
    });

    test('support door ho to 1 ATR wala stop hi rahta hai', () {
      final plan = buildStockPlan(
        cmp: cmp,
        atr: atr,
        trend: Trend3M.up,
        dp: dpRow(cmp: cmp, down: 940), // 1 ATR se door
      )!;

      expect(plan.basis, StopBasis.atr);
      expect(plan.stop, 980);
    });

    test('girte bazaar me bechna — stop upar, target neeche, aur chetavni', () {
      final plan = buildStockPlan(
        cmp: cmp,
        atr: atr,
        trend: Trend3M.down,
      )!;

      expect(plan.side, PlanSide.sell);
      expect(plan.stop, 1020);
      expect(plan.target, 960);
      expect(plan.sideNote, contains('short')); // delivery me nahi hota
    });

    test('girte bazaar me resistance kareeb ho to wahi stop', () {
      final plan = buildStockPlan(
        cmp: cmp,
        atr: atr,
        trend: Trend3M.down,
        dp: dpRow(cmp: cmp, up: 1005),
      )!;

      expect(plan.basis, StopBasis.dpResistance);
      expect(plan.stop, closeTo(1010.03, 0.5)); // 1005 × 1.005
    });

    test('seedha bazaar — koi plan nahi, aur wahi likha jata hai', () {
      expect(
        buildStockPlan(cmp: cmp, atr: atr, trend: Trend3M.sideways),
        isNull,
      );

      final plan = buildTradePlan(
        symbol: 'AAA',
        cmp: cmp,
        atr: atr,
        trend: Trend3M.sideways,
      );
      expect(plan.stock, isNull);
      expect(plan.notes, contains('koi pakka plan nahi'));
    });

    test('ATR hi na mile to plan banta hi nahi (khaali number nahi)', () {
      expect(
        buildStockPlan(cmp: cmp, atr: 0, trend: Trend3M.up),
        isNull,
      );
    });

    test('strong up / strong down bhi waise hi chalate hain', () {
      expect(
        buildStockPlan(cmp: cmp, atr: atr, trend: Trend3M.strongUp)!.side,
        PlanSide.buy,
      );
      expect(
        buildStockPlan(cmp: cmp, atr: atr, trend: Trend3M.strongDown)!.side,
        PlanSide.sell,
      );
    });
  });

  group('option kharidne ka plan', () {
    test('charhte bazaar me CE, girte me PE', () {
      final up = buildTradePlan(
        symbol: 'AAA',
        cmp: cmp,
        atr: atr,
        trend: Trend3M.up,
        ce: leg(1000, OptionType.call, 30),
        pe: leg(1000, OptionType.put, 28),
      );
      expect(up.optionBuy!.type, 'CE');

      final down = buildTradePlan(
        symbol: 'AAA',
        cmp: cmp,
        atr: atr,
        trend: Trend3M.down,
        ce: leg(1000, OptionType.call, 30),
        pe: leg(1000, OptionType.put, 28),
      );
      expect(down.optionBuy!.type, 'PE');
    });

    test('delta mile to premium ka stop/target spot ke hisaab se', () {
      final plan = buildTradePlan(
        symbol: 'AAA',
        cmp: cmp,
        atr: atr,
        trend: Trend3M.up,
        ce: leg(1000, OptionType.call, 30),
        ceDelta: 0.5,
      ).optionBuy!;

      expect(plan.usedDelta, isTrue);
      // Spot 20 neeche → premium ~10 kam (0.5 × 20).
      expect(plan.stopPremium, closeTo(20, 0.01));
      // Spot 40 upar → premium ~20 zyada.
      expect(plan.targetPremium, closeTo(50, 0.01));
      expect(plan.note, contains('delta se'));
    });

    test('delta NA mile to 40/80% ka convention — aur wahi likha jata hai', () {
      final plan = buildTradePlan(
        symbol: 'AAA',
        cmp: cmp,
        atr: atr,
        trend: Trend3M.up,
        ce: leg(1000, OptionType.call, 30),
      ).optionBuy!;

      expect(plan.usedDelta, isFalse);
      expect(plan.stopPremium, closeTo(18, 0.01)); // −40%
      expect(plan.targetPremium, closeTo(54, 0.01)); // +80%
      expect(plan.note, contains('convention'));
      expect(plan.stopPct, closeTo(-40, 0.01));
    });

    test('delta se premium kabhi zero se neeche nahi jata', () {
      final plan = buildTradePlan(
        symbol: 'AAA',
        cmp: cmp,
        atr: atr,
        trend: Trend3M.up,
        ce: leg(1000, OptionType.call, 2),
        ceDelta: 0.9,
      ).optionBuy!;

      expect(plan.stopPremium, greaterThan(0));
    });
  });

  group('jodi bechne ka plan', () {
    test('premium ka aadha target, 1.5× stop, aur surakshit band', () {
      final plan = buildTradePlan(
        symbol: 'AAA',
        cmp: cmp,
        atr: atr,
        trend: Trend3M.sideways,
        jodi: (total: 18.0, ceStrike: 1060.0, peStrike: 940.0),
      ).optionSell!;

      expect(plan.premium, 18);
      expect(plan.targetPremium, 9); // aadha
      expect(plan.stopPremium, 27); // 1.5×
      // Strikes ke aas-paas aadha ATR ki gunjaaish.
      expect(plan.safeLow, 930);
      expect(plan.safeHigh, 1070);
      expect(plan.bandNote, contains('₹930 – ₹1070'));
    });

    test('premium na mile to jodi ka plan banta hi nahi', () {
      final plan = buildTradePlan(
        symbol: 'AAA',
        cmp: cmp,
        atr: atr,
        trend: Trend3M.sideways,
        jodi: (total: 0, ceStrike: 1060.0, peStrike: 940.0),
      );
      expect(plan.optionSell, isNull);
    });
  });

  group('imaandaari', () {
    test('har plan ke saath "mechanical niyam, guarantee nahi" likha hai', () {
      final plan = buildTradePlan(
        symbol: 'AAA',
        cmp: cmp,
        atr: atr,
        trend: Trend3M.up,
        ce: leg(1000, OptionType.call, 30),
        jodi: (total: 18.0, ceStrike: 1060.0, peStrike: 940.0),
      );
      expect(plan.notes, contains('MECHANICAL'));
      expect(plan.notes, contains('guarantee nahi'));
      expect(plan.isEmpty, isFalse);
    });

    test('kuch hi na ban sake to bhi plan khaali nahi — notes hain', () {
      final plan = buildTradePlan(
        symbol: 'AAA',
        cmp: cmp,
        atr: atr,
        trend: Trend3M.sideways,
      );
      expect(plan.stock, isNull);
      expect(plan.optionBuy, isNull);
      expect(plan.optionSell, isNull);
      expect(plan.isEmpty, isTrue);
      expect(plan.notes, isNotEmpty);
    });

    test('stock ke bechne wale plan par delivery wali chetavni', () {
      final plan = buildTradePlan(
        symbol: 'AAA',
        cmp: cmp,
        atr: atr,
        trend: Trend3M.down,
      );
      expect(plan.stock!.sideNote, contains('delivery me nahi'));
    });
  });
}
