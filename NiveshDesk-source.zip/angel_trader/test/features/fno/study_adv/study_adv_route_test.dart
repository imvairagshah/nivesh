// ---------------------------------------------------------------------------
// study_adv_route_test.dart — the page must OPEN.
//
// This file exists because of a bug that reached a shipped APK: the new page
// read `FnoStudyService` out of the context, the app never provided it, and a
// release build answers a build-time exception with an EMPTY GREY SCREEN — no
// message, nothing to report. Every unit test was green; the screen was blank.
//
// So this test does the one thing unit tests cannot: it builds the real
// `StudyAdvScreen` inside the same provider tree `lib/app.dart` installs, and
// looks at it. A missing provider now fails here, in CI, not on a phone.
// ---------------------------------------------------------------------------

import 'dart:async';

import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/candle_dao.dart';
import 'package:angel_trader/data/local/dao/earnings_dao.dart';
import 'package:angel_trader/data/local/dao/fno_contract_dao.dart';
import 'package:angel_trader/data/local/dao/ipo_dao.dart';
import 'package:angel_trader/data/local/dao/scan_cache_dao.dart';
import 'package:angel_trader/data/local/dao/trade_dao.dart';
import 'package:angel_trader/data/local/dao/scrip_dao.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/data/remote/dto/quote.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/features/fno/study_adv/study_adv_screen.dart';
import 'package:angel_trader/services/auth_service.dart';
import 'package:angel_trader/services/earnings_calendar_service.dart';
import 'package:angel_trader/services/fno_study_service.dart';
import 'package:angel_trader/services/live_feed_service.dart';
import 'package:angel_trader/services/market_data_service.dart';
import 'package:angel_trader/features/settings/settings_provider.dart';
import 'package:angel_trader/services/scrip_master_service.dart';
import 'package:angel_trader/services/secure_store.dart';
import 'package:angel_trader/services/study_market_data.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';


/// Stands in for the broker's quote/greeks calls — the page never reaches the
/// network on open.
class NoopMarket implements StudyMarketData {
  const NoopMarket();

  @override
  Future<Map<String, MarketQuote>> fetchQuotesFull(List<Scrip> scrips) async =>
      {};

  @override
  Future<OptionGreekBatch> fetchOptionGreeks({
    required String underlying,
    required String expiryLabel,
  }) async =>
      const OptionGreekBatch(byStrike: {});
}

void main() {
  late AppDatabase db;

  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close();
    db = AppDatabase.instance;
  });

  tearDownAll(() async {
    await AppDatabase.instance.close();
  });

  /// Mirrors `lib/app.dart`'s MultiProvider for everything the new page reads.
  ///
  /// If the page starts asking for something the app does not install, this
  /// builder is the place that has to change — and the test fails until the
  /// app provides it too. That coupling is the point.
  Widget wrap(Widget child) {
    final scripDao = ScripDao(db);
    final settingsDao = SettingsDao(db);
    final candleDao = CandleDao(db);
    final auth = AuthService(store: SecureStore());
    final marketData = MarketDataService(auth: auth);
    final fnoStudy = FnoStudyService(
      source: marketData,
      candles: candleDao,
      cache: ScanCacheDao(db),
      contracts: FnoContractDao(db),
      marketData: const NoopMarket(),
    );

    return MultiProvider(
      providers: [
        Provider<AppDatabase>.value(value: db),
        Provider<IpoDao>.value(value: IpoDao(db)),
        Provider<ScripDao>.value(value: scripDao),
        Provider<CandleDao>.value(value: candleDao),
        // "Mera hisaab" tab: paper trades ka DAO (1.5.24).
        Provider<TradeDao>.value(value: TradeDao(db)),
        Provider<MarketDataService>.value(value: marketData),
        // The one that was missing in 1.5.21.
        Provider<FnoStudyService>.value(value: fnoStudy),
        // …and the three the detail panel needs: live premiums, the
        // "live feed" switch, and the results calendar.
        ChangeNotifierProvider<LiveFeedService>.value(
          value: LiveFeedService(auth: auth),
        ),
        Provider<EarningsCalendarService>.value(
          value: EarningsCalendarService(
            dao: EarningsDao(db),
            settings: settingsDao,
            get: (_) async => '[]',
          ),
        ),
        ChangeNotifierProvider<ScripMasterService>.value(
          value: ScripMasterService(
            scripDao: scripDao,
            settingsDao: settingsDao,
          ),
        ),
        ChangeNotifierProvider<SettingsProvider>.value(
          value: SettingsProvider(settingsDao)..load(),
        ),
      ],
      child: MaterialApp(home: child),
    );
  }

  testWidgets('the page opens — every provider it reads is installed',
      (tester) async {
    await tester.pumpWidget(wrap(const StudyAdvScreen()));
    await tester.pumpAndSettle(const Duration(milliseconds: 200));

    // A missing provider throws during build; in a release build that is a
    // blank screen, so the test asserts on what the user would have seen.
    expect(tester.takeException(), isNull);

    expect(find.text('3M Study · Advance Filter'), findsOneWidget);
    expect(find.text('List'), findsOneWidget);
    expect(find.text('Score ka hisab'), findsOneWidget);
    // The list tab's own controls.
    expect(find.text('Scan karo'), findsOneWidget);
    expect(find.textContaining('turnover ≥ 10 cr'), findsOneWidget);
    // once as the chip, once in the one-line summary of what is on
    expect(find.textContaining('aaj expiry chhod'), findsWidgets);

    // No phantom rows before the first scan.
    expect(find.textContaining('CHHOOTA'), findsNothing);
  });

  testWidgets('the second tab opens too, and explains itself', (tester) async {
    await tester.pumpWidget(wrap(const StudyAdvScreen()));
    await tester.pumpAndSettle(const Duration(milliseconds: 200));

    await tester.tap(find.text('Score ka hisab'));
    await tester.pumpAndSettle();

    expect(tester.takeException(), isNull);
    expect(find.text('Kya score sach me kaam karta hai?'), findsOneWidget);
    expect(find.text('Score napo (backtest)'), findsOneWidget);
  });

  testWidgets('the analysis tab opens and reads only what is already on the phone',
      (tester) async {
    await tester.pumpWidget(wrap(const StudyAdvScreen()));
    await tester.pumpAndSettle(const Duration(milliseconds: 200));

    await tester.tap(find.text('Analysis'));
    // Candles SQLite se padhe jate hain — asli I/O, jo widget test ke fake
    // async me kabhi nahi aata. Isliye yahan sirf itna dekha jata hai: tab
    // bana, phata nahi, aur chup nahi baitha.
    for (var i = 0; i < 5; i++) {
      await tester.pump(const Duration(milliseconds: 100));
    }

    expect(tester.takeException(), isNull);
    // Khaali screen nahi — ya to hisaab dikhega, ya ye line.
    expect(
      find.text('Phone me maujood candles padhe ja rahe hain…'),
      findsOneWidget,
    );
    // Bharosa karne layak hisaab (IVP bar, DP level, trend line, aur "IV ka
    // itihaas nahi milta" wali sachchai) alag test me pakka kiya gaya hai —
    // `study_adv_new_tabs_test.dart`, bina DB ke.
  });

  testWidgets('the mera hisaab tab opens without a trade book', (tester) async {
    await tester.pumpWidget(wrap(const StudyAdvScreen()));
    await tester.pumpAndSettle(const Duration(milliseconds: 200));

    await tester.tap(find.text('Mera hisaab'));
    // Trade book SQLite se padha jata hai — asli I/O, jo test ke fake async me
    // kabhi nahi aata. Isliye yahan pumpAndSettle nahi, gitni ke kuch frame
    // chalaye jate hain: dekhna hai ki tab banta hai ya phat ta hai.
    for (var i = 0; i < 5; i++) {
      await tester.pump(const Duration(milliseconds: 100));
    }

    expect(tester.takeException(), isNull);
    expect(find.text('Mera hisaab'), findsOneWidget);
    // Load ho ya na ho, screen khaali nahi rehni chahiye.
    expect(
      find.textContaining('Trade book padha ja raha hai'),
      findsOneWidget,
    );
    // Bharosa karne layak hisaab (buckets, chetavni) alag test me pakka kiya
    // gaya hai — `study_adv_new_tabs_test.dart`, bina DB ke.
  });

  testWidgets('a missing provider is reported, not swallowed', (tester) async {
    // The regression, reproduced: the page under a tree that has everything
    // EXCEPT the study service — which is what shipped in 1.5.21.
    final errors = <Object?>[];
    final previous = FlutterError.onError;
    FlutterError.onError = (details) => errors.add(details.exception);
    addTearDown(() => FlutterError.onError = previous);

    final scripDao = ScripDao(db);
    await tester.pumpWidget(MultiProvider(
      providers: [
        Provider<IpoDao>.value(value: IpoDao(db)),
        Provider<ScripDao>.value(value: scripDao),
        Provider<CandleDao>.value(value: CandleDao(db)),
        Provider<MarketDataService>.value(
          value: MarketDataService(auth: AuthService(store: SecureStore())),
        ),
      ],
      child: const MaterialApp(home: StudyAdvScreen()),
    ));

    final report = errors.map((e) => '$e').join('\n');
    expect(errors, isNotEmpty, reason: 'a missing service must not be silent');
    expect(report, contains('FnoStudyService'));

    // …and the body never comes up: the app bar survives (it is a plain
    // title) but the page under it is empty. That is exactly the 1.5.21
    // symptom — "screen khul gayi par andar kuch nahi" — with no message
    // anywhere in a release build. So the app now installs every provider
    // this page reads (app.dart) and prints the exception when one is ever
    // missing (main.dart) instead of showing nothing.
    expect(find.text('Scan karo'), findsNothing);
    expect(find.text('Score ka hisab'), findsNothing);
  });
}
