// ---------------------------------------------------------------------------
// study_adv_mytrades_test.dart — "Mera hisaab": kaunsa setup fayda deta hai.
//
// Ye screen aapke apne trades ko study ke natije se jodti hai. Do khatre hain
// jinse bachna hai, aur dono yahan pakke kiye gaye hain:
//
//   1. CHHOTI GINTI PAR BHAROSA — 3 trade ka 66 % win rate koi pattern nahi.
//      Isliye 10 se kam trade wale bucket par "kuch pakka nahi" likha jana
//      chahiye, chahe natija kitna bhi sundar kyun na ho.
//   2. ADHOORA JOD CHHUPANA — jin trades ka study snapshot mila hi nahi, wo
//      gine jane chahiye (matched/unmatched), na ki khamoshi se hata diye jayein.
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/models/paper_trade.dart';
import 'package:angel_trader/data/local/models/study_snapshot.dart';
import 'package:angel_trader/features/fno/study_adv/study_adv_mytrades.dart';
import 'package:flutter_test/flutter_test.dart';

final DateTime _day = DateTime(2025, 6, 2);

Trade closed(String symbol, double pnl, {DateTime? at}) => Trade(
      symbol: symbol,
      exchange: Exchange.nse,
      side: OrderSide.sell,
      quantity: 100,
      price: 250,
      executedAt: at ?? _day,
      realizedPnl: pnl,
    );

Trade open(String symbol) => Trade(
      symbol: symbol,
      exchange: Exchange.nse,
      side: OrderSide.buy,
      quantity: 100,
      price: 240,
      executedAt: _day,
    );

StudySnapshotRow snapshot(
  String symbol, {
  double score = 6,
  String trend = 'SIDEWAYS',
  String ivRank = 'MEDIUM',
  DateTime? at,
}) =>
    StudySnapshotRow(
      symbol: symbol,
      savedAt: at ?? _day,
      score: score,
      trend: trend,
      ivRank: ivRank,
    );

void main() {
  group('jod (matching)', () {
    test('sirf band hue trade gine jate hain — khule trade kahani nahi', () {
      final report = buildMyTradesReport(
        trades: [open('AAA'), closed('AAA', 100)],
        snapshots: {'AAA': snapshot('AAA')},
      );
      expect(report.closedTrades, 1);
      expect(report.matched, 1);
    });

    test('broker wala symbol (-EQ) bhi plain symbol se mil jata hai', () {
      final report = buildMyTradesReport(
        trades: [closed('RELIANCE-EQ', 50)],
        snapshots: {'RELIANCE': snapshot('RELIANCE')},
      );
      expect(report.matched, 1);
      expect(report.unmatched, 0);
    });

    test('jiska snapshot nahi mila, wo chhupaya nahi jata', () {
      final report = buildMyTradesReport(
        trades: [closed('AAA', 100), closed('BBB', -50)],
        snapshots: {'AAA': snapshot('AAA')},
      );
      expect(report.matched, 1);
      expect(report.unmatched, 1);
      expect(report.note, contains('1 ka nahi mila'));
    });

    test('purani study se joda gaya trade alag se gina jata hai', () {
      final report = buildMyTradesReport(
        trades: [closed('AAA', 10, at: DateTime(2025, 6, 2))],
        snapshots: {'AAA': snapshot('AAA', at: DateTime(2025, 1, 1))},
      );
      expect(report.matched, 1);
      expect(report.stale, 1);
      expect(report.note, contains('purani study'));
    });

    test('trade ke baad wali study bhi purani hai — tab study ne kuch kaha hi nahi tha', () {
      final report = buildMyTradesReport(
        trades: [closed('AAA', 10, at: DateTime(2025, 6, 2))],
        snapshots: {'AAA': snapshot('AAA', at: DateTime(2025, 7, 1))},
      );
      expect(report.stale, 1);
    });
  });

  group('buckets', () {
    test('score ke hisaab se teen bucket, aur sahi jagah paisa', () {
      final report = buildMyTradesReport(
        trades: [
          closed('AAA', 100), // top
          closed('BBB', 50), // theek
          closed('CCC', -40), // kam
        ],
        snapshots: {
          'AAA': snapshot('AAA', score: 9),
          'BBB': snapshot('BBB', score: 6),
          'CCC': snapshot('CCC', score: 2),
        },
      );

      final byKey = {for (final b in report.byScore) b.key: b};
      expect(byKey['score_top']!.closed, 1);
      expect(byKey['score_top']!.netPnl, 100);
      expect(byKey['score_mid']!.closed, 1);
      expect(byKey['score_low']!.closed, 1);
      expect(byKey['score_low']!.netPnl, -40);
    });

    test('trend ke hisaab se — STRONG UP bhi upar wale bucket me', () {
      final report = buildMyTradesReport(
        trades: [closed('AAA', 10), closed('BBB', 10), closed('CCC', 10)],
        snapshots: {
          'AAA': snapshot('AAA', trend: 'STRONG UP'),
          'BBB': snapshot('BBB', trend: 'SIDEWAYS'),
          'CCC': snapshot('CCC', trend: 'STRONG DOWN'),
        },
      );
      final byKey = {for (final b in report.byTrend) b.key: b};
      expect(byKey['trend_up']!.closed, 1);
      expect(byKey['trend_flat']!.closed, 1);
      expect(byKey['trend_down']!.closed, 1);
    });

    test('IV ke hisaab se — low / medium / high alag', () {
      final report = buildMyTradesReport(
        trades: [closed('AAA', 10), closed('BBB', 10), closed('CCC', 10)],
        snapshots: {
          'AAA': snapshot('AAA', ivRank: 'LOW'),
          'BBB': snapshot('BBB', ivRank: 'MEDIUM'),
          'CCC': snapshot('CCC', ivRank: 'HIGH'),
        },
      );
      final byKey = {for (final b in report.byIvRank) b.key: b};
      expect(byKey['iv_low']!.closed, 1);
      expect(byKey['iv_mid']!.closed, 1);
      expect(byKey['iv_high']!.closed, 1);
    });

    test('khaali bucket sabse neeche — naye aadmi ko zero ki deewar nahi', () {
      final report = buildMyTradesReport(
        trades: [closed('AAA', 100)],
        snapshots: {'AAA': snapshot('AAA', score: 9)},
      );
      // Paise wala bucket sabse upar; jisme kuch hua hi nahi wo neeche.
      expect(report.byScore.first.key, 'score_top');
      expect(report.byScore.last.isEmpty, isTrue);
    });
  });

  group('imaandaari (kam ginti par bharosa nahi)', () {
    test('10 se kam trade wala bucket "pakka" nahi kehlata', () {
      final report = buildMyTradesReport(
        trades: [for (var i = 0; i < 9; i++) closed('AAA', 100)],
        snapshots: {'AAA': snapshot('AAA')},
      );
      final bucket = report.byScore.firstWhere((b) => !b.isEmpty);
      expect(bucket.closed, 9);
      expect(bucket.sufficient, isFalse);
      expect(bucket.winRate, 1.0); // 9/9 — phir bhi "pakka nahi"
      expect(bucket.note, contains('kuch pakka nahi'));
    });

    test('10 trade ke saath hi "pakka" ka darja milta hai', () {
      final report = buildMyTradesReport(
        trades: [for (var i = 0; i < 10; i++) closed('AAA', 100)],
        snapshots: {'AAA': snapshot('AAA')},
      );
      final bucket = report.byScore.firstWhere((b) => !b.isEmpty);
      expect(bucket.sufficient, isTrue);
      expect(bucket.note, contains('har trade par'));
    });

    test('note me ginti khuli rahe — chhoti bucket ki chetavni ke saath', () {
      final report = buildMyTradesReport(
        trades: [closed('AAA', 100), closed('BBB', -20), closed('CCC', 30)],
        snapshots: {'AAA': snapshot('AAA')},
      );
      expect(report.note, contains('3 band hue trade'));
      expect(report.note, contains('1 ka study se joda mila'));
      expect(report.note, contains('2 ka nahi mila'));
      expect(report.note, contains('kuch pakka nahi'));
    });

    test('ek bhi trade na ho to khaali screen nahi, ek line milti hai', () {
      final report = buildMyTradesReport(trades: [], snapshots: {});
      expect(report.isEmpty, isTrue);
      expect(report.note, contains('Paper Trading'));
      expect(report.bestBucket, isNull);
      expect(report.worstBucket, isNull);
    });
  });

  group('hisab', () {
    test('expectancy = kul paisa / trade, aur win rate sahi', () {
      final report = buildMyTradesReport(
        trades: [closed('AAA', 300), closed('AAA', -100), closed('AAA', 200)],
        snapshots: {'AAA': snapshot('AAA')},
      );
      final bucket = report.byScore.firstWhere((b) => !b.isEmpty);
      expect(bucket.closed, 3);
      expect(bucket.wins, 2);
      expect(bucket.netPnl, 400);
      expect(bucket.expectancy, closeTo(133.33, 0.01));
      expect(bucket.winRateText, '67%');
      expect(bucket.worst, -100);
    });

    test('nuksaan wala bucket sabse pehle dikhta hai (best/worst)', () {
      final report = buildMyTradesReport(
        trades: [closed('AAA', 500), closed('BBB', -300)],
        snapshots: {
          'AAA': snapshot('AAA', score: 9),
          'BBB': snapshot('BBB', score: 2),
        },
      );
      expect(report.worstBucket!.key, 'score_low');
      expect(report.bestBucket, isNull); // dono bucket me 1-1 trade = pakka nahi
    });

    test('rupees ka sign likha jata hai — kahin "0" chhupa nahi', () {
      final report = buildMyTradesReport(
        trades: [closed('AAA', -250)],
        snapshots: {'AAA': snapshot('AAA')},
      );
      final bucket = report.byScore.firstWhere((b) => !b.isEmpty);
      expect(bucket.expectancyText, '−₹250');
      expect(bucket.worstText, '−₹250');
    });
  });
}
