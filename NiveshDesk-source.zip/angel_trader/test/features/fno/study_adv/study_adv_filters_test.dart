// ---------------------------------------------------------------------------
// study_adv_filters_test.dart — the advance-filter page's rules.
//
// A filter that hides rows without saying why is how a study stops being
// trusted, so these tests pin three things: which gate fires (and in what
// order), what the gate's line says, and the fact that a blocked row is still
// KEPT — it is never silently dropped.
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/features/fno/study/study_engine.dart';
import 'package:angel_trader/features/fno/study_adv/study_adv_filters.dart';
import 'package:flutter_test/flutter_test.dart';

final DateTime kDay = DateTime(2025, 6, 2);

/// A steady climb — unambiguous STRONG UP with every month green.
List<Candle> climb(int count, {double base = 100, double step = 0.5}) => [
      for (var i = 0; i < count; i++)
        Candle(
          time: kDay.subtract(Duration(days: count - 1 - i)),
          open: base + step * i,
          high: base + step * i,
          low: base + step * i,
          close: base + step * i,
          volume: 2000000, // ₹20 cr+ a day at these prices
        ),
    ];

Scrip scrip(String symbol) => Scrip(
      token: symbol,
      symbol: '$symbol-EQ',
      name: '$symbol Limited',
      exchange: Exchange.nse,
    );

StudyRow studyRow({
  double score = 8,
  double turnoverCrore = 25,
  int? daysToExpiry = 20,
}) =>
    StudyRow(
      symbol: 'ALPHA',
      companyName: 'Alpha Limited',
      exchange: Exchange.nse,
      token: '1',
      underlying: 'ALPHA',
      ltp: 130,
      high3m: 132,
      low3m: 100,
      rangePct: 32,
      atr: 2,
      atrPct: 1.5,
      distHiPct: 1.5,
      distLoPct: 23,
      distHiDays: 1,
      distLoDays: 15,
      months: const [],
      total3mPct: 30,
      upMonths: 3,
      downMonths: 0,
      trend: Trend3M.strongUp,
      lotSize: 250,
      consistencyPoints: 3,
      magnitudePoints: 3,
      proximityPoints: 3,
      ivPoints: 2,
      score: score,
      ivRank: IvRank.low,
      opportunityTag: '🎯 Best Buy — BUY CE (IV sasta)',
      rank: 1,
      reason: '',
      bars: 400,
      asOf: kDay,
      turnoverCrore: turnoverCrore,
      daysToExpiry: daysToExpiry,
    );

void main() {
  group('gates', () {
    test('no filter, no gate', () {
      expect(gateFor(studyRow(), StudyAdvFilters.defaults), isNull);
    });

    test('a thin stock is stopped at the turnover gate, with its number', () {
      final row = studyRow(turnoverCrore: 4.2);
      const filters = StudyAdvFilters.defaults;

      expect(gateFor(row, filters), AdvGate.turnover);
      expect(
        StudyAdvRow(row: row, gate: AdvGate.turnover).gateLine(filters),
        'turnover 4.2 cr < 10 cr',
      );
    });

    test('expiry day is stopped even when everything else is perfect', () {
      final row = studyRow(daysToExpiry: 0);

      expect(gateFor(row, StudyAdvFilters.defaults), AdvGate.expiryDay);
      expect(
        StudyAdvRow(row: row, gate: AdvGate.expiryDay).gateLine(StudyAdvFilters()),
        'aaj expiry hai',
      );
    });

    test('the near-expiry block is opt-in and reports the days left', () {
      final row = studyRow(daysToExpiry: 2);

      // Off by default: two days left is still allowed.
      expect(gateFor(row, StudyAdvFilters.defaults), isNull);

      final strict =
          StudyAdvFilters.defaults.copyWith(blockNearExpiryDays: 3);
      expect(gateFor(row, strict), AdvGate.nearExpiry);
      expect(
        StudyAdvRow(row: row, gate: AdvGate.nearExpiry).gateLine(strict),
        'expiry 2 din baad (≤ 3)',
      );
    });

    test('a low score is stopped last — after the trade-ability gates', () {
      // Score low AND thin: the turnover gate is the one a trader cares about.
      expect(
        gateFor(studyRow(score: 2, turnoverCrore: 1), StudyAdvFilters.defaults),
        AdvGate.turnover,
      );
      expect(
        gateFor(
          studyRow(score: 2),
          StudyAdvFilters.defaults.copyWith(minScore: 6),
        ),
        AdvGate.score,
      );
    });

    test('a stock with no expiry data is not punished for it', () {
      expect(gateFor(studyRow(daysToExpiry: null), StudyAdvFilters.defaults),
          isNull);
    });
  });

  // ---- B3: results paas hone wala stock ----------------------------------

  group('the results gate', () {
    final row = studyRow();

    test('is opt-in — off by default, like every gate that shrinks a list',
        () {
      // Results in two days, gate off → nothing is blocked. (1.5.17: a new
      // gate must never quietly thin the list.)
      expect(
        gateFor(row, StudyAdvFilters.defaults, daysToResults: 2),
        isNull,
      );
    });

    test('stops a stock whose results are inside the window', () {
      final filters = StudyAdvFilters.defaults.copyWith(blockResultsDays: 5);

      expect(gateFor(row, filters, daysToResults: 4), AdvGate.results);
      expect(gateFor(row, filters, daysToResults: 5), AdvGate.results,
          reason: 'the window edge is inside');
      expect(gateFor(row, filters, daysToResults: 6), isNull,
          reason: 'one day outside is outside');
    });

    test('results aaj hain to bhi roko — sabse bada gap risk', () {
      final filters = StudyAdvFilters.defaults.copyWith(blockResultsDays: 5);
      expect(gateFor(row, filters, daysToResults: 0), AdvGate.results);
    });

    test('a stock with no announced date is never blocked', () {
      final filters = StudyAdvFilters.defaults.copyWith(blockResultsDays: 5);
      expect(gateFor(row, filters, daysToResults: null), isNull);
      expect(gateFor(row, filters), isNull);
    });

    test('a result that already happened does not block', () {
      final filters = StudyAdvFilters.defaults.copyWith(blockResultsDays: 5);
      expect(gateFor(row, filters, daysToResults: -1), isNull,
          reason: 'kal ka result aaj ka risk nahi');
    });

    test('the gate line says when, and that the date is NSE ki', () {
      final filters = StudyAdvFilters.defaults.copyWith(blockResultsDays: 5);
      expect(
        StudyAdvRow(row: row, gate: AdvGate.results, daysToResults: 2)
            .gateLine(filters),
        'results 2 din me (≤ 5 din — NSE ki date)',
      );
    });

    test('expiry is still reported before results — both are gap risk', () {
      final filters = StudyAdvFilters.defaults.copyWith(
        blockResultsDays: 5,
        blockNearExpiryDays: 3,
      );
      expect(
        gateFor(studyRow(daysToExpiry: 2), filters, daysToResults: 1),
        AdvGate.nearExpiry,
      );
    });

    test('the filter line names the gate, so the chip is never a mystery',
        () {
      expect(
        StudyAdvFilters.defaults.copyWith(blockResultsDays: 5).line,
        contains('results ≤ 5 din chhod'),
      );
      expect(StudyAdvFilters.defaults.line, isNot(contains('results')));
    });
  });

  group('buildAdvRows with results dates', () {
    final row = studyRow();

    test('counts the days from the as-of day, not from now', () {
      final rows = buildAdvRows(
        [row],
        {'ALPHA': row},
        StudyAdvFilters.defaults.copyWith(blockResultsDays: 5),
        resultsDates: {'ALPHA': kDay.add(const Duration(days: 3))},
        asOf: kDay,
      );

      expect(rows.single.daysToResults, 3);
      expect(rows.single.gate, AdvGate.results);
    });

    test('keeps the countdown even when the gate is off', () {
      final rows = buildAdvRows(
        [row],
        {'ALPHA': row},
        StudyAdvFilters.defaults,
        resultsDates: {'ALPHA': kDay.add(const Duration(days: 2))},
        asOf: kDay,
      );

      expect(rows.single.daysToResults, 2);
      expect(rows.single.blocked, isFalse,
          reason: 'a number the user is trading into should not wait');
    });

    test('lower-case symbols in the calendar still match', () {
      final rows = buildAdvRows(
        [row],
        {'ALPHA': row},
        StudyAdvFilters.defaults,
        resultsDates: {'alpha': kDay.add(const Duration(days: 9))},
        asOf: kDay,
      );

      expect(rows.single.daysToResults, 9);
    });

    test('a date with a time on it is read as its own day', () {
      final rows = buildAdvRows(
        [row],
        {'ALPHA': row},
        StudyAdvFilters.defaults,
        resultsDates: {
          'ALPHA': kDay.add(const Duration(days: 5, hours: 15, minutes: 30)),
        },
        asOf: kDay.add(const Duration(hours: 9)),
      );

      expect(rows.single.daysToResults, 5,
          reason: '9am vs 3:30pm must not eat a day');
    });
  });

  group('rows', () {
    test('a blocked row is kept, never dropped', () {
      final advanced = [studyRow(turnoverCrore: 1), studyRow()];
      final rows = buildAdvRows(advanced, const {}, StudyAdvFilters.defaults);

      expect(rows.length, 2); // both are still here
      expect(rows.where((r) => r.blocked).length, 1);
      expect(rows.first.blocked, isFalse); // visible rows sort first
    });

    test('the delta is new minus old — what the corrections did', () {
      final row = buildAdvRows(
        [studyRow(score: 7)],
        {'ALPHA': studyRow(score: 9)},
        StudyAdvFilters.defaults,
      ).single;

      expect(row.scoreDelta, closeTo(-2, 1e-9));
    });

    test('rows the corrections demoted are listed on their own', () {
      final best = studyRow(score: 9);
      final rows = [
        StudyAdvRow(row: best, classic: best), // still a 🎯 → not demoted
        StudyAdvRow(
          row: studyRow(score: 9).copyWith(
            opportunityTag: '⏸ Watch — BUY CE (IV sasta, par premium mehenga)',
          ),
          classic: studyRow(score: 9),
        ),
      ];
      final result = StudyAdvResult(
        rows: rows,
        filters: StudyAdvFilters.defaults,
        asOf: kDay,
        duration: Duration.zero,
        scanned: 2,
      );

      expect(result.downgraded.length, 1);
    });

    test('the funnel names every gate that ate a row', () {
      final rows = buildAdvRows(
        [
          studyRow(turnoverCrore: 1),
          studyRow(daysToExpiry: 0),
          studyRow(),
        ],
        const {},
        StudyAdvFilters.defaults,
      );
      final result = StudyAdvResult(
        rows: rows,
        filters: StudyAdvFilters.defaults,
        asOf: kDay,
        duration: Duration.zero,
        scanned: 3,
      );

      expect(result.visible.length, 1);
      expect(result.funnelLine, contains('3 scan hue'));
      expect(result.funnelLine, contains('1 list me'));
      expect(result.funnelLine, contains('(1 turnover kam · 1 aaj expiry)'));
      expect(result.gateGroups.length, 2);
    });

    test('short history is called out instead of being hidden', () {
      final rows = buildAdvRows(
        [studyRow()],
        const {},
        StudyAdvFilters.defaults,
      );
      // 400 bars is plenty; a 61-bar series is not three months.
      final short = buildAdvRows(
        [studyRow().copyWith()],
        const {},
        StudyAdvFilters.defaults,
      );
      expect(short.single.row.bars, 400);
      expect(rows.single.row.bars, 400);
    });
  });

  group('the corrections themselves', () {
    test('A1 — low IV + negative edge: classic says 🎯, advanced says ⏸', () {
      final row = studyRow().copyWith(ivRank: IvRank.low, edgePct: -0.3);

      final classicTag =
          applyOpportunity(row, rules: StudyRules.classic).opportunityTag;
      final advancedTag =
          applyOpportunity(row, rules: StudyRules.advanced).opportunityTag;

      expect(classicTag, startsWith('🎯'));
      expect(advancedTag, startsWith('⏸'));
      expect(advancedTag, contains('premium mehenga'));
    });

    test('A1 — a low IV WITH an edge still earns the 🎯', () {
      final row = studyRow().copyWith(ivRank: IvRank.low, edgePct: 0.8);

      expect(
        applyOpportunity(row, rules: StudyRules.advanced).opportunityTag,
        startsWith('🎯'),
      );
    });

    test('A2 — both distances are measured from CMP, not one from the high',
        () {
      // Climb to 120, then fall back to 108: the 3-month high is well above
      // CMP, which is exactly where the two denominators disagree.
      final bars = <Candle>[
        for (var i = 0; i < 60; i++)
          Candle(
            time: kDay.subtract(Duration(days: 80 - i)),
            open: 100 + i * (20 / 60),
            high: 100 + i * (20 / 60),
            low: 100 + i * (20 / 60),
            close: 100 + i * (20 / 60),
            volume: 1000000,
          ),
        for (var i = 0; i < 20; i++)
          Candle(
            time: kDay.subtract(Duration(days: 20 - i)),
            open: 120 - i * 0.6,
            high: 120 - i * 0.6,
            low: 120 - i * 0.6,
            close: 120 - i * 0.6,
            volume: 1000000,
          ),
      ];

      final classic = computeStudy(
        scrip: scrip('ALPHA'),
        candles: bars,
        rules: StudyRules.classic,
      )!;
      final advanced = computeStudy(
        scrip: scrip('ALPHA'),
        candles: bars,
        rules: StudyRules.advanced,
      )!;

      expect(classic.high3m, closeTo(120, 0.01));
      expect(classic.ltp, closeTo(108.6, 0.01));
      // classic: 11.4 / 120 = 9.5 %   ·   advanced: 11.4 / 108.6 = 10.5 %
      expect(classic.distHiPct, closeTo(9.5, 0.05));
      expect(advanced.distHiPct, closeTo(10.5, 0.05));
      // …and the distance-to-low is unchanged (it always used CMP).
      expect(advanced.distLoPct, classic.distLoPct);
    });

    test('A3 — a two-session stub month no longer swings consistency', () {
      // March and April are full months; May has exactly two sessions.
      // The classic rules count May as a whole month; the advanced rules fold
      // those two sessions into April.
      final bars = <Candle>[];
      var price = 100.0;
      void add(DateTime day) {
        bars.add(Candle(
          time: day,
          open: price,
          high: price,
          low: price,
          close: price,
          volume: 1000000,
        ));
      }

      for (var d = 0; d < 29; d++) {
        add(DateTime(2025, 3, 3 + d));
        price += 0.9;
      }
      for (var d = 0; d < 30; d++) {
        add(DateTime(2025, 4, 1 + d));
        price += 0.9;
      }
      // …and a two-session stub in May that happens to go UP. That is the
      // dangerous case: the classic rules see three green "months" and pay out
      // a full 3.0 for a two-day drift.
      for (var d = 0; d < 2; d++) {
        add(DateTime(2025, 5, 12 + d));
        price += 2.0;
      }
      expect(bars.length, 61); // just above the 60-bar minimum

      final classic = computeStudy(
        scrip: scrip('ALPHA'),
        candles: bars,
        rules: StudyRules.classic,
      )!;
      final advanced = computeStudy(
        scrip: scrip('ALPHA'),
        candles: bars,
        rules: StudyRules.advanced,
      )!;

      expect(classic.months.length, 3); // May counted as a month
      expect(advanced.months.length, 2); // folded into April
      // Classic: three "green months" → the full 3.0, earned by two days.
      expect(classic.consistencyPoints, 3.0);
      // Advanced: only two real months were seen, so two points is the most
      // this series can claim (A4) — a two-day blip is not a third month.
      expect(advanced.consistencyPoints, 2.0);
    });

    test('A4 — two agreeing months cannot claim three points', () {
      // Same inputs, only the "how many months did we really see" flag differs.
      expect(
        consistencyPoints(Trend3M.strongUp, 2, 0, monthCount: 2),
        3.0,
      ); // classic
      expect(
        consistencyPoints(
          Trend3M.strongUp,
          2,
          0,
          monthCount: 2,
          requireFullMonths: true,
        ),
        2.0,
      ); // advanced
      expect(
        consistencyPoints(
          Trend3M.strongUp,
          3,
          0,
          monthCount: 3,
          requireFullMonths: true,
        ),
        3.0,
      );
    });

    test('A5 — a 🎯 three days from expiry is demoted, the classic one is not',
        () {
      // The stock is perfect: cheap IV, no negative edge. Only the clock is
      // wrong — theta eats the premium faster than the stock can travel.
      final dying = studyRow(daysToExpiry: 2);

      final classic = applyOpportunity(dying, rules: StudyRules.classic);
      final advanced = applyOpportunity(dying, rules: StudyRules.advanced);

      expect(classic.opportunityTag, startsWith('🎯'));
      expect(classic.isBestBuy, isTrue);

      expect(advanced.opportunityTag, startsWith('⏸'));
      expect(advanced.isBestBuy, isFalse);
      expect(advanced.opportunityTag, contains('expiry 2 din baad'));

      // Expiry day itself: the same rule, said in today's words.
      final today =
          applyOpportunity(studyRow(daysToExpiry: 0), rules: StudyRules.advanced);
      expect(today.opportunityTag, contains('aaj'));

      // With time on the clock the advanced rules still pay the 🎯.
      final roomy =
          applyOpportunity(studyRow(daysToExpiry: 20), rules: StudyRules.advanced);
      expect(roomy.opportunityTag, startsWith('🎯'));

      // No expiry information (options data missing) → no demotion either way.
      final unknown = applyOpportunity(
        studyRow(daysToExpiry: null),
        rules: StudyRules.advanced,
      );
      expect(unknown.opportunityTag, startsWith('🎯'));
    });

    test("the classic page's numbers do not move", () {
      // The whole promise of StudyRules: the defaults ARE today's behaviour.
      final candles = climb(80);
      final implicit = computeStudy(scrip: scrip('ALPHA'), candles: candles)!;
      final explicit = computeStudy(
        scrip: scrip('ALPHA'),
        candles: candles,
        rules: StudyRules.classic,
      )!;

      expect(explicit.score, implicit.score);
      expect(explicit.distHiPct, implicit.distHiPct);
      expect(explicit.months.length, implicit.months.length);
      expect(explicit.consistencyPoints, implicit.consistencyPoints);
    });
  });
}
