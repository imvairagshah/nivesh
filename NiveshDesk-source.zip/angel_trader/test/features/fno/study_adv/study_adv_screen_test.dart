// ---------------------------------------------------------------------------
// study_adv_screen_test.dart — the new page's cards, as the user reads them.
//
// Two numbers, one row: `Naya 10.5 | Purana 9.5`. And when a filter holds a
// row back, the row must say why — a filter that thins the list in silence is
// the bug that already bit us once (1.5.17).
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/features/fno/study/black_scholes.dart' show OptionType;
import 'package:angel_trader/features/fno/study/study_engine.dart';
import 'package:angel_trader/features/fno/study_adv/study_adv_filters.dart';
import 'package:angel_trader/features/fno/study_adv/study_adv_export.dart';
import 'package:angel_trader/features/fno/study/study_export.dart'
    show FnoStudyExportMeta, StudyExportService;
import 'package:angel_trader/features/fno/study_adv/study_adv_screen.dart';
import 'package:flutter/material.dart';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

final DateTime kDay = DateTime(2025, 6, 2);

Scrip scripFor(String symbol) => Scrip(
      token: symbol,
      symbol: '$symbol-EQ',
      name: '$symbol Limited',
      exchange: Exchange.nse,
    );

StudyRow row({
  String symbol = 'ALPHA',
  double score = 8,
  double turnoverCrore = 25,
  int? daysToExpiry = 20,
  String tag = '🎯 Best Buy — BUY CE (IV sasta)',
  bool legs = true,
  double avgIv = 18.2,
}) =>
    StudyRow(
      symbol: symbol,
      companyName: '$symbol Limited',
      exchange: Exchange.nse,
      token: symbol,
      underlying: symbol,
      ltp: 130,
      high3m: 132,
      low3m: 100,
      rangePct: 32,
      atr: 2,
      atrPct: 1.5,
      distHiPct: 1.5,
      distLoPct: 23,
      distHiDays: 1,
      distLoDays: 15,
      months: const [],
      total3mPct: 30,
      upMonths: 3,
      downMonths: 0,
      trend: Trend3M.strongUp,
      lotSize: 250,
      consistencyPoints: 3,
      magnitudePoints: 3,
      proximityPoints: 3,
      ivPoints: 2,
      score: score,
      ivRank: IvRank.low,
      opportunityTag: tag,
      rank: 1,
      reason: '',
      bars: 400,
      asOf: kDay,
      turnoverCrore: turnoverCrore,
      daysToExpiry: daysToExpiry,
      avgIv: avgIv,
      atmStrike: legs ? 130 : null,
      ce: legs ? leg(symbol, 130, OptionType.call, 'CE', 8.2, 7.4) : null,
      pe: legs ? leg(symbol, 130, OptionType.put, 'PE', 7.9, 7.1) : null,
      strangle: legs
          ? StudyStrangle(
              ce: leg(symbol, 136.5, OptionType.call, 'OTM-CE', 3.4, 3.1),
              pe: leg(symbol, 123.5, OptionType.put, 'OTM-PE', 3.1, 2.9),
              targetPremium: 8.0,
            )
          : null,
    );

StudyOptionLeg leg(
  String symbol,
  double strike,
  OptionType type,
  String suffix,
  double ltp,
  double previousClose,
) =>
    StudyOptionLeg(
      strike: strike,
      type: type,
      token: '$symbol-$suffix',
      symbol: '$symbol-$suffix',
      ltp: ltp,
      previousClose: previousClose,
    );

/// One advanced row plus its classic twin — what the page puts on a card.
StudyAdvRow pair(
  String symbol, {
  double score = 9,
  double classicScore = 9,
  double turnoverCrore = 25,
  int? daysToExpiry = 20,
  String tag = '\u{1F3AF} Best Buy \u2014 BUY CE (IV sasta)',
  StudyAdvFilters filters = StudyAdvFilters.defaults,
}) =>
    buildAdvRows(
      [
        row(
          symbol: symbol,
          score: score,
          turnoverCrore: turnoverCrore,
          daysToExpiry: daysToExpiry,
          tag: tag,
        ),
      ],
      {
        symbol: row(
          symbol: symbol,
          score: classicScore,
          turnoverCrore: turnoverCrore,
          daysToExpiry: daysToExpiry,
          tag: tag,
        ),
      },
      filters,
    ).single;

/// Four names: two clean, one on expiry day, one too thin to trade.
StudyAdvResult sample({StudyAdvFilters filters = StudyAdvFilters.defaults}) {
  final rows = <StudyAdvRow>[
    pair('RELIANCE', score: 10.5, classicScore: 9.5, filters: filters),
    pair(
      'TATASTEEL',
      score: 8.2,
      classicScore: 7.0,
      daysToExpiry: 1,
      filters: filters,
    ),
    pair('INFY', score: 6.1, classicScore: 6.0, daysToExpiry: 0, filters: filters),
    pair(
      'THINSTOCK',
      score: 7.4,
      classicScore: 7.2,
      turnoverCrore: 2,
      filters: filters,
    ),
  ];
  return StudyAdvResult(
    rows: rows,
    filters: filters,
    asOf: kDay,
    duration: const Duration(seconds: 3),
    scanned: 4,
  );
}

FnoStudyExportMeta meta(int rowCount) => FnoStudyExportMeta(
      asOf: kDay,
      runAt: kDay,
      rowCount: rowCount,
      bestBuyCount: 0,
      withOptions: 0,
    );

StudyAdvRow named(StudyAdvResult result, String symbol) =>
    result.rows.firstWhere((candidate) => candidate.row.symbol == symbol);

Future<void> pumpCard(
  WidgetTester tester,
  StudyAdvRow row, {
  StudyAdvFilters? filters,
  bool expanded = false,
  Map<String, double>? livePremiums,
  Map<String, double>? liveStrangle,
}) async {
  await tester.pumpWidget(MaterialApp(
    home: Scaffold(
      body: SingleChildScrollView(
        child: StudyAdvRowCard(
          row: row,
          filters: filters,
          expanded: expanded,
          livePremiums: livePremiums,
          liveStrangle: liveStrangle,
        ),
      ),
    ),
  ));
}

void main() {
  group('the card', () {
    testWidgets('shows the new score next to the old one', (tester) async {
      await pumpCard(tester, named(sample(), 'RELIANCE'));

      expect(find.text('RELIANCE'), findsOneWidget);
      expect(find.text('Score naya'), findsOneWidget);
      expect(find.text('purana'), findsOneWidget);
      // 10.5 (naya) and 9.5 (purana) — and the delta, which is the whole point.
      expect(find.text('10.5'), findsOneWidget);
      expect(find.text('9.5'), findsOneWidget);
      expect(find.text('+1.0'), findsOneWidget);
    });

    testWidgets('a demoted row shows a negative delta', (tester) async {
      await pumpCard(tester, pair('INFY', score: 5.5, classicScore: 8.0));

      expect(find.text('\u22122.5'), findsOneWidget);
    });

    testWidgets('a 🎯 row is marked, a watch row is not', (tester) async {
      await pumpCard(tester, named(sample(), 'RELIANCE'));
      expect(find.textContaining('Best Buy'), findsOneWidget);

      await pumpCard(
        tester,
        pair(
          'MID',
          score: 6.5,
          classicScore: 6.5,
          tag: '⏸ Watch — IV mehnga',
        ),
      );
      expect(find.textContaining('Best Buy'), findsNothing);
      expect(find.textContaining('Watch'), findsOneWidget);
    });

    testWidgets('carries turnover, expiry, trend, ATR and the 3M move',
        (tester) async {
      await pumpCard(tester, named(sample(), 'RELIANCE'));

      expect(find.text('turnover 25.0 cr'), findsOneWidget);
      expect(find.text('expiry 20 din'), findsOneWidget);
      expect(find.text('ATR 1.5%'), findsOneWidget);
      expect(find.text('+30.0% 3M'), findsOneWidget);
    });

    testWidgets('a held-back row says why, on the row itself', (tester) async {
      final thin = named(sample(), 'THINSTOCK');
      expect(thin.blocked, isTrue);
      expect(thin.gate, AdvGate.turnover);

      await pumpCard(tester, thin);
      expect(find.textContaining('CHHOOTA'), findsOneWidget);
      // The number that failed, next to the bar it failed on.
      expect(find.textContaining('turnover 2.0 cr < 10 cr'), findsOneWidget);
    });

    testWidgets('an expiry-day row is held back and says so', (tester) async {
      final infy = named(sample(), 'INFY');
      expect(infy.gate, AdvGate.expiryDay);

      await pumpCard(tester, infy);
      expect(find.textContaining('aaj expiry hai'), findsOneWidget);
    });

    testWidgets('a near-expiry row quotes the days left', (tester) async {
      final near = named(
        sample(filters: const StudyAdvFilters(blockNearExpiryDays: 3)),
        'TATASTEEL',
      );
      expect(near.gate, AdvGate.nearExpiry);

      await pumpCard(
        tester,
        near,
        filters: const StudyAdvFilters(blockNearExpiryDays: 3),
      );
      expect(find.textContaining('expiry 1 din baad (≤ 3)'), findsOneWidget);
    });

    testWidgets('a clean row carries no CHHOOTA line', (tester) async {
      await pumpCard(tester, named(sample(), 'RELIANCE'));
      expect(find.textContaining('CHHOOTA'), findsNothing);
    });

    testWidgets('the score cut quotes the cut', (tester) async {
      const filters = StudyAdvFilters(minScore: 9);
      final cut = sample(filters: filters).rows.firstWhere(
            (candidate) => candidate.gate == AdvGate.score,
          );

      await pumpCard(tester, cut, filters: filters);
      expect(find.textContaining('score'), findsWidgets);
      expect(find.textContaining('< 9'), findsOneWidget);
    });
  });

  group('the whole old page, on this page', () {
    // Bug 3 (1.5.21): the card carried the score and the filters but none of
    // the numbers the old page prints — no jodi, no kal ka P&L, no IV, no
    // detail panel, no export. These read the shipped source so a future
    // edit that drops one of them fails here rather than on a phone.
    final screen = File('lib/features/fno/study_adv/study_adv_screen.dart')
        .readAsStringSync();
    final provider = File('lib/features/fno/study_adv/study_adv_provider.dart')
        .readAsStringSync();

    test('tapping a row opens the old page ka poora panel', () {
      expect(screen, contains('StudyDetailPanel'));
      expect(screen, contains('onTap'));
      expect(provider, contains('toggleExpanded'));
      expect(provider, contains('expandedSymbol'));
    });

    test('the card prints what the old card prints', () {
      for (final line in [
        'OTM jodi',
        'kal ₹',
        'IV ',
        'ATM jodi ₹',
        '% of price',
        'option chain nahi mila',
      ]) {
        expect(screen, contains(line), reason: '$line is on the old card too');
      }
    });

    test('live premiums and the results date are wired to the feed', () {
      for (final needle in [
        'livePremiums',
        'liveKalPremiums',
        'liveStrangle',
        'liveKalStrangle',
        'liveFeedActive',
        'ensureEarnings',
        'earningsFor',
        'feedOwner',
      ]) {
        expect(provider, contains(needle), reason: '$needle drives the panel');
      }
    });

    test('export leaves the page the same four ways the old one does', () {
      expect(screen, contains('PopupMenuButton<StudyExportKind>'));
      expect(screen, contains('StudyDeliveryService'));
      // All four kinds, straight off the enum the old page uses — no subset.
      expect(screen, contains('for (final kind in StudyExportKind.values)'));
    });
  });

  group('the jodi, on the card', () {
    testWidgets('the OTM jodi prints its strikes and what it costs',
        (tester) async {
      await pumpCard(tester, named(sample(), 'RELIANCE'));

      // 123.5 PE + 136.5 CE at ₹6.50, and what it did since yesterday.
      expect(find.textContaining('OTM jodi'), findsOneWidget);
      expect(find.textContaining('PE'), findsWidgets);
      expect(find.textContaining('CE'), findsWidgets);
      expect(find.textContaining('₹6.50'), findsOneWidget);
      expect(find.textContaining('kal ₹6.00'), findsOneWidget);
      expect(find.textContaining('Profit 0.50 pts'), findsOneWidget);
    });

    testWidgets('IV and the ATM jodi are on the card too', (tester) async {
      await pumpCard(tester, named(sample(), 'RELIANCE'));
      expect(find.textContaining('IV 18.2%'), findsOneWidget);
      expect(find.textContaining('ATM jodi ₹16.10'), findsOneWidget);
    });

    testWidgets('both jodis print as a share of the stock price',
        (tester) async {
      await pumpCard(tester, named(sample(), 'RELIANCE'));

      // 130 ke stock par: OTM 6.50 → 5.00%, ATM 16.10 → 12.38%.
      expect(find.textContaining('= ₹6.50 (5.00% of price)'), findsOneWidget);
      expect(
          find.textContaining('ATM jodi ₹16.10 (12.38% of price)'),
          findsOneWidget);
    });

    testWidgets('the open row counts the live premium', (tester) async {
      await pumpCard(
        tester,
        named(sample(), 'RELIANCE'),
        expanded: true,
        livePremiums: const {'CE': 9.0, 'PE': 8.0},
        liveStrangle: const {'CE': 4.0, 'PE': 3.0},
      );

      // Live wins: 17.00 → 13.08%, 7.00 → 5.38%.
      expect(find.textContaining('= ₹7.00 (5.38% of price)'), findsOneWidget);
      expect(
          find.textContaining('ATM jodi ₹17.00 (13.08% of price)'),
          findsOneWidget);
      expect(find.textContaining('₹6.50'), findsNothing);
    });

    testWidgets('a stock with no chain says so instead of hiding it',
        (tester) async {
      final only = buildAdvRows(
        [row(symbol: 'NOCHAIN', legs: false)],
        {'NOCHAIN': row(symbol: 'NOCHAIN', legs: false)},
        StudyAdvFilters.defaults,
      ).single;

      await pumpCard(tester, only);
      expect(find.textContaining('option chain nahi mila'), findsOneWidget);
    });

    test('the export carries both scores and the gate', () {
      // The cells are pure — the file/WhatsApp hand-off is the classic
      // study's job and is covered there.
      final cells = [
        for (final row in sample().rows) StudyAdvExportService.rowCells(row)
      ];

      final headers = StudyAdvExportService.headers;
      expect(headers, contains('Score (purana)'));
      expect(headers, contains('Farq'));
      expect(headers, contains('Chhoota kyun'));
      expect(headers.length, StudyExportService.headers.length + 3);

      // RELIANCE: naya 10.5, purana 9.5, farq +1.0
      final reliance = cells.firstWhere(
        (cells) => cells[1]?.toString().contains('RELIANCE') ?? false,
      );
      expect(reliance[StudyAdvExportService.scoreIndex]?.toString(), '10.5');
      expect(reliance[headers.indexOf('Score (purana)')]?.toString(), '9.5');
      expect(reliance[headers.indexOf('Farq')]?.toString(), '+1.0');
      expect(
          reliance[headers.indexOf('Chhoota kyun')]?.toString().trim(), isEmpty);

      // THINSTOCK was held back by the gate — the file says which one.
      final thin = cells.firstWhere(
        (cells) => cells[1]?.toString().contains('THINSTOCK') ?? false,
      );
      expect(thin[headers.indexOf('Chhoota kyun')]?.toString(), isNotEmpty);
    });
  });

  group('the list order', () {
    testWidgets('clean rows come first, held-back rows sink', (tester) async {
      final rows = sample().rows;

      final firstBlocked = rows.indexWhere((r) => r.blocked);
      expect(firstBlocked, greaterThan(0));
      for (var i = firstBlocked; i < rows.length; i++) {
        expect(rows[i].blocked, isTrue);
      }
      // Best Buy first.
      expect(rows.first.row.isBestBuy, isTrue);
    });
  });
}
