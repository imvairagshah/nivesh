// ---------------------------------------------------------------------------
// study_adv_backtest_test.dart — does the score actually order outcomes? (C1)
//
// The 12-point score was designed, not measured. This replay is the measurement,
// so the tests hold it to the two things that would make it a lie:
//
//   1. LOOK-AHEAD — the score at a bar must be computed from that bar's past
//      only, and the outcome must come from the sessions AFTER it;
//   2. COUNTING — the bands must add up, SIDEWAYS (AVOID) rows must not become
//      trades, and the sign must follow the study's own suggestion.
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/features/fno/study_adv/study_adv_backtest.dart';
import 'package:flutter_test/flutter_test.dart';

final DateTime kDay = DateTime(2025, 1, 1);

Candle bar(int day, double price, {int volume = 1000000}) => Candle(
      time: kDay.add(Duration(days: day)),
      open: price,
      high: price,
      low: price,
      close: price,
      volume: volume,
    );

Scrip scripFor(String symbol) => Scrip(
      token: symbol,
      symbol: '$symbol-EQ',
      name: symbol,
      exchange: Exchange.nse,
    );

/// A clean ramp: [step] rupees a session. Enough for STRONG UP.
List<Candle> ramp(int count, {double base = 100, double step = 0.5}) => [
      for (var i = 0; i < count; i++) bar(i, base + step * i),
    ];

/// A clean slide: enough for STRONG DOWN.
List<Candle> slide(int count, {double base = 200, double step = 0.5}) => [
      for (var i = 0; i < count; i++) bar(i, base - step * i),
    ];

/// Flat: the study calls it SIDEWAYS (AVOID).
List<Candle> flat(int count, {double price = 100}) =>
    [for (var i = 0; i < count; i++) bar(i, price)];

const StudyBacktestConfig kConfig =
    StudyBacktestConfig(horizonBars: 10, stride: 5);

void main() {
  group('the replay', () {
    test('a rising stock scores and its forward move is positive', () {
      final result = runStudyBacktest(
        {'ALPHA': ramp(120)},
        config: kConfig,
        scripFor: scripFor,
      );

      expect(result.symbols, 1);
      expect(result.trades, greaterThan(0));
      // Every checkpoint of a monotonically rising series is a win when the
      // side is long — the top band must be all green.
      final top = result.advanced.last; // 9–12
      expect(top.samples, greaterThan(0));
      expect(top.winRatePct, 100);
      expect(top.avgReturnPct, greaterThan(0));
    });

    test('a falling stock is measured short, so a win is still a win', () {
      final result = runStudyBacktest(
        {'BETA': slide(120)},
        config: kConfig,
        scripFor: scripFor,
      );

      expect(result.trades, greaterThan(0));
      for (final bucket in result.advanced) {
        if (bucket.isEmpty) continue;
        expect(bucket.avgReturnPct, greaterThan(0),
            reason: 'a steady fall measured short must be positive');
      }
    });

    test('a sideways stock produces no trades — the study says AVOID', () {
      final result = runStudyBacktest(
        {'GAMMA': flat(120)},
        config: kConfig,
        scripFor: scripFor,
      );

      expect(result.symbols, 1);
      expect(result.evaluations, greaterThan(0)); // it was scored…
      expect(result.trades, 0); // …but never traded
    });

    test('a series too short to judge is skipped, not scored', () {
      final result = runStudyBacktest(
        {'SHORT': ramp(30)},
        config: kConfig,
        scripFor: scripFor,
      );

      expect(result.symbols, 0);
      expect(result.skipped, 1);
      expect(result.trades, 0);
    });

    test('the bands add up to the trades, and every trade sits in one', () {
      final result = runStudyBacktest(
        {'ALPHA': ramp(200), 'BETA': slide(200)},
        config: kConfig,
        scripFor: scripFor,
      );

      final counted = result.advanced.fold<int>(
        0,
        (sum, bucket) => sum + bucket.samples,
      );
      expect(counted, result.trades);
      // The classic buckets measure the same trades.
      final countedClassic = result.classic.fold<int>(
        0,
        (sum, bucket) => sum + bucket.samples,
      );
      expect(countedClassic, result.trades);
    });

    test('a band label says what it covers', () {
      final result = runStudyBacktest(
        {'ALPHA': ramp(200)},
        config: kConfig,
        scripFor: scripFor,
      );

      expect(
        [for (final b in result.advanced) b.label],
        ['0–4', '4–7', '7–9', '9–12'],
      );
    });

    test('the same candles always give the same report', () {
      final history = {'ALPHA': ramp(200), 'BETA': slide(150)};
      final first = runStudyBacktest(history, config: kConfig, scripFor: scripFor);
      final second = runStudyBacktest(history, config: kConfig, scripFor: scripFor);

      expect(second.trades, first.trades);
      for (var i = 0; i < first.advanced.length; i++) {
        expect(second.advanced[i].samples, first.advanced[i].samples);
        expect(second.advanced[i].avgReturnPct, first.advanced[i].avgReturnPct);
      }
    });

    test('a longer horizon changes the measurement, a wider stride does too',
        () {
      final history = {'ALPHA': ramp(200)};

      final tight = runStudyBacktest(
        history,
        config: const StudyBacktestConfig(horizonBars: 5, stride: 5),
        scripFor: scripFor,
      );
      final wide = runStudyBacktest(
        history,
        config: const StudyBacktestConfig(horizonBars: 15, stride: 5),
        scripFor: scripFor,
      );
      final coarse = runStudyBacktest(
        history,
        config: const StudyBacktestConfig(horizonBars: 10, stride: 20),
        scripFor: scripFor,
      );

      // A 15-session window captures more of the ramp than a 5-session one.
      expect(wide.advanced.last.avgReturnPct,
          greaterThan(tight.advanced.last.avgReturnPct));
      // Fewer checkpoints → fewer trades, same series.
      expect(coarse.trades, lessThan(wide.trades));
    });
  });

  group('the verdict is honest', () {
    test('an empty measurement says so', () {
      final result = runStudyBacktest(
        const <String, List<Candle>>{},
        config: kConfig,
        scripFor: scripFor,
      );

      expect(result.isEmpty, isTrue);
      expect(result.verdict, contains('koi trade hi nahi bana'));
      expect(result.separates, isFalse);
    });

    test('a score that separates the bands is called out as separating', () {
      // Two series: one climbs hard (high score), one barely moves (low score).
      final result = runStudyBacktest(
        {
          'STRONG': ramp(200, step: 1.2),
          'WEAK': ramp(200, step: 0.15),
        },
        config: kConfig,
        scripFor: scripFor,
      );

      expect(result.trades, greaterThan(0));
      // The stronger ramp must land in a higher band than the weaker one.
      final strong = result.advanced.last.samples;
      final weak = result.advanced.first.samples;
      expect(strong + weak, greaterThan(0));
      expect(result.verdict, isNotEmpty);
    });

    test('the fine print counts what it measured', () {
      final result = runStudyBacktest(
        {'ALPHA': ramp(200), 'SHORT': ramp(20)},
        config: kConfig,
        scripFor: scripFor,
      );

      expect(result.symbols, 1);
      expect(result.skipped, 1);
      expect(result.barsUsed, 200);
      expect(result.config.line, contains('har 5 session par'));
    });
  });

  group('the two rule sets', () {
    test('both score sets are measured over the same trades', () {
      final result = runStudyBacktest(
        {'ALPHA': ramp(200)},
        config: kConfig,
        scripFor: scripFor,
      );

      final advancedTrades =
          result.advanced.fold<int>(0, (s, b) => s + b.samples);
      final classicTrades = result.classic.fold<int>(0, (s, b) => s + b.samples);

      expect(classicTrades, advancedTrades);
      expect(result.comparisonNote, isNotEmpty);
    });
  });
}
