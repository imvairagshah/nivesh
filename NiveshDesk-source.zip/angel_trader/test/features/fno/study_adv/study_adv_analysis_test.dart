// ---------------------------------------------------------------------------
// study_adv_analysis_test.dart — offline analysis (IVP/IVR, DP, trend).
//
// Ye teenon cheezein user ke phone ke purane candles se banti hain, kisi naye
// request se nahi. Isliye yahan do baat pakki ki jati hain:
//
//   1. HISAB SAHI HAI — seedha udaharan (charhta hua bhav, do kimat ke beech
//      ghuumta hua bhav, shaant ke baad tezi) jinse sahi jawab pahle se pata
//      hai;
//   2. SACH BOLNA — kam data ho to "kam data" likha jaye, khaali jagah na
//      chhodhi jaye aur na hi khoke ke bharosa na ho to bharosa dikhaya jaye.
// ---------------------------------------------------------------------------

import 'dart:math' as math;

import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/features/fno/study_adv/study_adv_analysis.dart';
import 'package:flutter_test/flutter_test.dart';

/// Ek deterministic series — koi random nahi, warna test kabhi na kabhi hilega.
List<Candle> series(
  int count, {
  double start = 100,
  double Function(int i)? close,
  double Function(int i)? high,
  double Function(int i)? low,
  DateTime? from,
}) {
  final first = from ?? DateTime(2024, 1, 1);
  return [
    for (var i = 0; i < count; i++)
      Candle(
        time: first.add(Duration(days: i)),
        open: (close?.call(i) ?? start) * 0.999,
        high: (high?.call(i)) ?? (close?.call(i) ?? start) * 1.01,
        low: (low?.call(i)) ?? (close?.call(i) ?? start) * 0.99,
        close: close?.call(i) ?? start,
        volume: 1000,
      ),
  ];
}

/// Roz ek hi % charhne wala bhav — har din ka return barabar, to volatility 0.
List<Candle> steadyClimb(int count, {double start = 100, double step = 0.01}) =>
    series(count, close: (i) => start * math.pow(1 + step, i).toDouble());

/// 95 se 105 ke beech ghuumta hua bhav (10 baar upar-neeche).
List<Candle> seeSaw(int count, {int period = 10}) => series(
      count,
      close: (i) => 100 + 5 * math.sin(2 * math.pi * i / period),
      high: (i) => 100 + 5 * math.sin(2 * math.pi * i / period) + 1.5,
      low: (i) => 100 + 5 * math.sin(2 * math.pi * i / period) - 1.5,
    );

/// Pahle aadha hissa bilkul shaant, phir aadha roz 4% ka jhatka.
List<Candle> calmThenWild({int calm = 120, int wild = 60}) {
  final bars = <Candle>[];
  var price = 100.0;
  var day = DateTime(2024, 1, 1);
  for (var i = 0; i < calm; i++) {
    price *= 1.0005; // 0.05 % roz — hilchal naam ki
    bars.add(Candle(
      time: day,
      open: price,
      high: price * 1.001,
      low: price * 0.999,
      close: price,
      volume: 500,
    ));
    day = day.add(const Duration(days: 1));
  }
  var up = true;
  for (var i = 0; i < wild; i++) {
    price *= up ? 1.04 : 1 / 1.04;
    up = !up;
    bars.add(Candle(
      time: day,
      open: price,
      high: price * 1.005,
      low: price * 0.995,
      close: price,
      volume: 5000,
    ));
    day = day.add(const Duration(days: 1));
  }
  return bars;
}

void main() {
  final asOf = DateTime(2025, 6, 2);

  group('IVP / IVR', () {
    test('shaant ke baad tezi — ab ki hilchal apne itihaas me sabse upar', () {
      final analysis = buildStudyAdvAnalysis(
        bars: {'AAA': calmThenWild()},
        asOf: asOf,
        ivpWindow: IvpWindow.year1,
      );

      final row = analysis.ivpRows.single;
      expect(row.sufficient, isTrue); // 180 din, 40 se upar
      expect(row.ivp, greaterThan(80));
      expect(row.ivr, greaterThan(80));
      expect(row.max, greaterThan(row.average));
      expect(row.verdict, contains('mehnga'));
    });

    test('ek hi raftaar se chalne wale stock par sab shaant', () {
      // Har din ka return bilkul barabar → volatility 0 → sab kuch 0.
      final analysis = buildStudyAdvAnalysis(
        bars: {'FLAT': steadyClimb(200)},
        asOf: asOf,
      );
      final row = analysis.ivpRows.single;
      expect(row.current, lessThan(0.5));
      expect(row.ivp, inInclusiveRange(0, 100));
      expect(row.days, greaterThan(100));
    });

    test('IVP 0 se 100 ke bahar kabhi nahi', () {
      final analysis = buildStudyAdvAnalysis(
        bars: {
          'A': calmThenWild(),
          'B': seeSaw(300),
          'C': steadyClimb(300, step: 0.02),
        },
        asOf: asOf,
      );
      for (final row in analysis.ivpRows) {
        expect(row.ivp, inInclusiveRange(0, 100));
        expect(row.ivr, inInclusiveRange(0, 100));
      }
    });

    test('chhoti window me kam din, badi window me zyada', () {
      final bars = {'AAA': calmThenWild(calm: 200, wild: 200)};
      final sixMonths = buildStudyAdvAnalysis(
        bars: bars, asOf: asOf, ivpWindow: IvpWindow.months6,
      ).ivpRows.single;
      final threeYears = buildStudyAdvAnalysis(
        bars: bars, asOf: asOf, ivpWindow: IvpWindow.years3,
      ).ivpRows.single;

      expect(threeYears.days, greaterThan(sixMonths.days));
    });

    test('kam data ho to "kam data" likha jaye, chhupaya nahi', () {
      final analysis = buildStudyAdvAnalysis(
        bars: {'THIN': seeSaw(45)},
        asOf: asOf,
        ivpWindow: IvpWindow.year1,
      );
      final row = analysis.ivpRows.single;
      expect(row.sufficient, isFalse);
      expect(row.verdict, contains('kam data'));
    });
  });

  group('DP (support / resistance)', () {
    test('do kimat ke beech ghuumte stock par upar aur neeche dono level', () {
      final analysis = buildStudyAdvAnalysis(
        bars: {'SEE': seeSaw(120)},
        asOf: asOf,
        dpDays: 120,
      );
      final row = analysis.dpRows.single;
      expect(row.hasBoth, isTrue);

      expect(row.nearestUp!.price, greaterThan(row.cmp));
      expect(row.nearestDown!.price, lessThan(row.cmp));
      // Swing high/low baar baar bante hain — isliye ek se zyada chhua hona
      // chahiye, warna level hi kya level.
      expect(row.nearestUp!.touches + row.nearestDown!.touches,
          greaterThanOrEqualTo(2));
    });

    test('seedha charhte hue stock me koi swing hi nahi — to level bhi nahi', () {
      // Ek dum seedhi charht me na upar wala swing high hai, na neeche wala
      // swing low. Jhootha level banane se behtar hai "koi level nahi" likhna.
      final analysis = buildStudyAdvAnalysis(
        bars: {'CLIMB': steadyClimb(120)},
        asOf: asOf,
      );
      final row = analysis.rows.single;
      expect(row.dp, isNull);
      expect(analysis.dpRows, isEmpty);
    });

    test('charhte hue stock me dono level milte hain, upar wala door', () {
      // Haqeeqi charht: roz thoda upar, beech me chhote utaar.
      final rising = series(
        120,
        close: (i) => 100 + i * 0.6 + 6 * math.sin(2 * math.pi * i / 9 + 2.5),
        high: (i) => 100 + i * 0.6 + 6 * math.sin(2 * math.pi * i / 9 + 2.5) + 1,
        low: (i) => 100 + i * 0.6 + 6 * math.sin(2 * math.pi * i / 9 + 2.5) - 1,
      );
      final row = buildStudyAdvAnalysis(bars: {'UP': rising}, asOf: asOf)
          .dpRows
          .single;
      expect(row.hasBoth, isTrue);
      expect(row.nearestUp!.price, greaterThan(row.cmp));
      expect(row.nearestDown!.price, lessThan(row.cmp));
    });

    test('chhoti window me doori badalti hai (kam din = kareeb level)', () {
      final bars = {'SEE': seeSaw(200)};
      final short = buildStudyAdvAnalysis(bars: bars, asOf: asOf, dpDays: 40)
          .dpRows
          .single;
      final long = buildStudyAdvAnalysis(bars: bars, asOf: asOf, dpDays: 120)
          .dpRows
          .single;
      expect(short.days, 40);
      expect(long.days, 120);
    });
  });

  group('Trend (SMA + EMA)', () {
    test('charhta hua bhav — upar, aur dono line ek mat ke', () {
      final analysis = buildStudyAdvAnalysis(
        bars: {'UP': steadyClimb(200)},
        asOf: asOf,
        trendWindow: TrendWindow.months3,
      );
      final row = analysis.trendRows.single;
      expect(row.direction, TrendDirection.up);
      expect(row.aligned, isTrue);
      expect(row.verdict, contains('pakka'));
      expect(row.distanceFromMaPct, greaterThan(0));
    });

    test('girta hua bhav — neeche', () {
      final falling = series(200, close: (i) => 200 - i * 0.5);
      final analysis = buildStudyAdvAnalysis(
        bars: {'DOWN': falling},
        asOf: asOf,
        trendWindow: TrendWindow.months3,
      );
      final row = analysis.trendRows.single;
      expect(row.direction, TrendDirection.down);
      expect(row.aligned, isTrue);
      expect(row.distanceFromMaPct, lessThan(0));
    });

    test('ek hi jagah tika hua bhav — seedha, neeche nahi', () {
      // Bilkul saath-saath chalne par "neeche" kehna galat hota.
      final flat = series(200, close: (i) => 100.0 + (i % 2 == 0 ? 0.05 : -0.05));
      final analysis = buildStudyAdvAnalysis(
        bars: {'FLAT': flat},
        asOf: asOf,
        trendWindow: TrendWindow.months3,
      );
      expect(analysis.trendRows.single.direction, TrendDirection.flat);
    });

    test('window badalne se MA ki lambai badalti hai', () {
      final bars = {'UP': steadyClimb(300)};
      final oneMonth = buildStudyAdvAnalysis(
        bars: bars, asOf: asOf, trendWindow: TrendWindow.month1,
      ).trendRows.single;
      final oneYear = buildStudyAdvAnalysis(
        bars: bars, asOf: asOf, trendWindow: TrendWindow.year1,
      ).trendRows.single;

      // Lambi MA purane (saste) bhav ko bhi ginati hai, isliye chhoti MA se
      // neeche hoti hai jab bhav charh raha ho.
      expect(oneYear.sma, lessThan(oneMonth.sma));
    });

    test('jis stock ki MA hi na ban sake, wo sabse neeche — chhupaya nahi', () {
      // 1 saal ki window mangi, par 40 din ka data hai: MA ban hi nahi sakti.
      final analysis = buildStudyAdvAnalysis(
        bars: {
          'UP': steadyClimb(300),
          'THIN': steadyClimb(40, step: 0.05),
        },
        asOf: asOf,
        trendWindow: TrendWindow.year1,
      );
      final rows = analysis.trendRows;
      expect(rows.first.symbol, 'UP');
      expect(rows.last.symbol, 'THIN');
      expect(rows.last.sufficient, isFalse);
      expect(rows.last.direction, TrendDirection.unknown);
      expect(rows.last.verdict, contains('kam data'));
    });
  });

  group('poora analysis', () {
    test('teenon ek hi baar me bante hain, ek stock ke liye', () {
      final analysis = buildStudyAdvAnalysis(
        bars: {'AAA': seeSaw(200)},
        asOf: asOf,
      );
      expect(analysis.rows.single.ivp, isNotNull);
      expect(analysis.rows.single.dp, isNotNull);
      expect(analysis.rows.single.trend, isNotNull);
      expect(analysis.symbols, 1);
    });

    test('khaali haath — summary sach bole, na ki khaali jagah', () {
      final analysis = buildStudyAdvAnalysis(bars: {}, asOf: asOf);
      expect(analysis.isEmpty, isTrue);
      expect(analysis.summary, contains('Kisi bhi stock ke candles'));
    });

    test('kitne stock ke data mile aur kitne ke nahi — ginti khuli', () {
      final analysis = buildStudyAdvAnalysis(
        bars: {
          'OK': seeSaw(200),
          'THIN': seeSaw(28),
          'TOOSHORT': seeSaw(5),
        },
        asOf: asOf,
      );
      expect(analysis.symbols, 2);
      expect(analysis.empty, 1);
      expect(analysis.summary, contains('candles hi nahi mile'));
    });

    test('25 se kam candle wala stock gina hi nahi jata', () {
      final analysis = buildStudyAdvAnalysis(
        bars: {'SHORT': seeSaw(24)},
        asOf: asOf,
      );
      expect(analysis.isEmpty, isTrue);
      expect(analysis.empty, 1);
    });

    test('teen sau stock ka hisaab bina ghabraye ho jata hai', () {
      final bars = <String, List<Candle>>{
        for (var i = 0; i < 300; i++) 'SYM$i': seeSaw(400, period: 8 + i % 12),
      };
      final sw = Stopwatch()..start();
      final analysis = buildStudyAdvAnalysis(bars: bars, asOf: asOf);
      sw.stop();

      expect(analysis.symbols, 300);
      // Phone par bhi ye turant chalna chahiye — 5 second se upar ho to UI
      // jam jayega.
      expect(sw.elapsedMilliseconds, lessThan(5000));
    });
  });
}
