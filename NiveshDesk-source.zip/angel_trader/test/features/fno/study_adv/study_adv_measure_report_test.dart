// ---------------------------------------------------------------------------
// study_adv_measure_report_test.dart — the "Score ka hisab" tab (C1).
//
// This tab exists because a 12-point score that was never measured cannot be
// trusted. So the report is held to the same standard the study is held to:
// honest counts, both rule sets side by side, and the fine print on screen.
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/features/fno/study_adv/study_adv_backtest.dart';
import 'package:angel_trader/features/fno/study_adv/study_adv_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

final DateTime kDay = DateTime(2025, 1, 1);

Candle bar(int day, double price) => Candle(
      time: kDay.add(Duration(days: day)),
      open: price,
      high: price,
      low: price,
      close: price,
      volume: 1000000,
    );

List<Candle> ramp(int count, {double step = 0.5}) =>
    [for (var i = 0; i < count; i++) bar(i, 100 + step * i)];

List<Candle> flat(int count) => [for (var i = 0; i < count; i++) bar(i, 100)];

Scrip scripFor(String symbol) => Scrip(
      token: symbol,
      symbol: '$symbol-EQ',
      name: symbol,
      exchange: Exchange.nse,
    );

StudyScoreBacktest measure(Map<String, List<Candle>> history) =>
    runStudyBacktest(
      history,
      config: const StudyBacktestConfig(horizonBars: 10, stride: 5),
      scripFor: scripFor,
    );

Future<void> pumpReport(WidgetTester tester, StudyScoreBacktest result) async {
  await tester.pumpWidget(MaterialApp(
    home: Scaffold(body: StudyAdvMeasureReport(result: result)),
  ));
}

void main() {
  testWidgets('a measured run shows both rule sets and the fine print',
      (tester) async {
    final result = measure({'ALPHA': ramp(200)});
    await pumpReport(tester, result);

    expect(find.text('Naye niyam (is page ke score)'), findsOneWidget);
    expect(find.text('Purane niyam (classic study ke score)'), findsOneWidget);
    expect(find.text('Puri jankari'), findsOneWidget);
    // All four bands of both tables.
    expect(find.text('9–12'), findsNWidgets(2));
    expect(find.text('0–4'), findsNWidgets(2));
    // The verdict card.
    expect(find.text(result.verdict), findsOneWidget);
  });

  testWidgets('the fine print counts what it measured, and disclaims',
      (tester) async {
    await pumpReport(tester, measure({'ALPHA': ramp(200), 'SHORT': ramp(20)}));

    expect(
      find.textContaining('1 stock · ${measure({'ALPHA': ramp(200)}).evaluations} baar score nikala'),
      findsOneWidget,
    );
    expect(
      find.textContaining('1 stock ka itihaas kam tha'),
      findsOneWidget,
    );
    // The two promises the page must never break.
    expect(find.textContaining('Sideways (AVOID)'), findsOneWidget);
    expect(find.textContaining('koi guarantee nahi hai'), findsWidgets);
  });

  testWidgets('a run that measured no trades says so instead of going blank',
      (tester) async {
    final result = measure({'FLAT': flat(200)});
    expect(result.isEmpty, isTrue);

    await pumpReport(tester, result);
    expect(find.textContaining('koi trade hi nahi bana'), findsOneWidget);
    expect(find.text('Puri jankari'), findsOneWidget);
    expect(find.text('Naye niyam (is page ke score)'), findsNothing);
  });

  testWidgets('the band rows carry the hit-rate and the average move',
      (tester) async {
    final result = measure({'ALPHA': ramp(200)});
    await pumpReport(tester, result);

    for (final bucket in result.advanced) {
      if (bucket.isEmpty) continue;
      expect(find.textContaining(bucket.line), findsOneWidget);
    }
  });
}
