// ---------------------------------------------------------------------------
// study_adv_provider_test.dart — the new page's state machine.
//
// The page itself costs history and requests, so the rules that matter are the
// ones about WHEN it runs and WHAT it admits:
//
//   • nothing runs by itself — a study is asked for, never started (this is
//     the single most expensive thing in the app);
//   • one job at a time, and a job that fails says so in Hinglish;
//   • changing a filter marks the table stale — it never silently re-scans;
//   • a held-back row is still kept, so "kaun chhoota" can say why.
// ---------------------------------------------------------------------------

import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/ipo_dao.dart';
import 'package:angel_trader/data/local/dao/scrip_dao.dart';
import 'package:angel_trader/data/local/dao/earnings_dao.dart';
import 'package:angel_trader/data/local/dao/trade_dao.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/data/local/models/paper_trade.dart';
import 'package:angel_trader/data/local/models/study_snapshot.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/features/fno/study/black_scholes.dart' show OptionType;
import 'package:angel_trader/features/fno/study/study_engine.dart';
import 'package:angel_trader/data/remote/dto/quote.dart';
import 'package:angel_trader/features/fno/study_adv/study_adv_backtest.dart';
import 'package:angel_trader/features/fno/study_adv/study_adv_filters.dart';
import 'package:angel_trader/features/fno/study_adv/study_adv_plan.dart';
import 'package:angel_trader/features/fno/study_adv/study_adv_provider.dart';
import 'package:angel_trader/features/settings/settings_provider.dart';
import 'package:angel_trader/features/fno/study_adv/study_adv_service.dart';
import 'package:angel_trader/services/candle_source.dart';
import 'package:angel_trader/services/fno_study_service.dart';
import 'package:angel_trader/services/auth_service.dart';
import 'package:angel_trader/services/earnings_calendar_service.dart';
import 'package:angel_trader/services/fno_universe.dart';
import 'package:angel_trader/services/live_feed_service.dart';
import 'package:angel_trader/services/secure_store.dart';
import 'package:angel_trader/services/scrip_master_service.dart';
import 'package:angel_trader/services/study_market_data.dart';
import 'package:flutter_test/flutter_test.dart';
import 'dart:async' show unawaited;
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

class NoopSource implements CandleSource {
  @override
  Future<List<Candle>> fetchDailyCandles({
    required Scrip scrip,
    required DateTime from,
    required DateTime to,
    String interval = 'ONE_DAY',
  }) async =>
      const [];
}

class NoopMarket implements StudyMarketData {
  @override
  Future<Map<String, MarketQuote>> fetchQuotesFull(List<Scrip> scrips) async =>
      {};

  @override
  Future<OptionGreekBatch> fetchOptionGreeks({
    required String underlying,
    required String expiryLabel,
  }) async =>
      const OptionGreekBatch(byStrike: {});
}

/// An NSE feed with nothing in it.
Future<String> _emptyFeed(Uri _) async => '[]';

/// Today + [days], the way NSE writes a board-meeting date (`05-Jun-2025`).
///
/// It has to be in the future: the calendar only treats a meeting that has not
/// happened yet as an upcoming result — a date in the past is history, not a
/// risk, and blocks nothing.
String nseDateIn(int days) {
  const months = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', //
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
  ];
  final d = DateTime.now().add(Duration(days: days));
  return '${'${d.day}'.padLeft(2, '0')}-${months[d.month - 1]}-${d.year}';
}

/// Midnight of today + [days] — what the calendar stores for that date.
DateTime midnightIn(int days) {
  final d = DateTime.now().add(Duration(days: days));
  return DateTime(d.year, d.month, d.day);
}

/// RELIANCE results three days from now. Only an *announced* board meeting
/// counts (1.5.14).
Future<String> _relianceFeed(Uri _) async => jsonBoardMeeting(
      symbol: 'RELIANCE',
      date: nseDateIn(3),
    );

/// One row of NSE's board-meetings feed, in the shape it actually uses.
String jsonBoardMeeting({required String symbol, required String date}) =>
    '[{"bm_symbol":"$symbol","bm_date":"$date","bm_purpose":"To consider and '
    'approve the Audited Financial Results for the quarter ended March 2025",'
    '"bm_desc":""}]';

/// Stands in for the network + candle layer: the provider's own rules are what
/// is under test, not the maths (that is pinned in the engine tests).
class FakeStudyAdvService implements StudyAdvService {
  FakeStudyAdvService({
    this.rows = const [],
    this.measurement,
    this.failure,
    this.bars = const {},
    Map<String, List<Candle>>? symbolBars,
  }) : symbolBars = symbolBars ?? bars;

  /// Cached candles handed back by [cachedBars] (offline analysis ke liye).
  final Map<String, List<Candle>> bars;

  /// [barsForSymbol] kya de — plan card isi se banta hai.
  final Map<String, List<Candle>> symbolBars;

  int barsForSymbolCalls = 0;

  /// Advanced rows handed back by [run].
  final List<StudyRow> rows;

  /// What the measure job returns.
  final StudyScoreBacktest? measurement;

  /// When set, both jobs throw this.
  final Object? failure;

  int runCalls = 0;
  int backtestCalls = 0;
  int cachedBarsCalls = 0;
  StudyAdvFilters? lastFilters;
  List<Scrip>? lastUniverse;

  /// What the last run asked for — so a test can pin the new plumbing (B1
  /// IV source, B3 results dates) without touching the network.
  StudyIvSource? lastIvSource;
  Map<String, DateTime>? lastResultsDates;

  @override
  Future<StudyAdvResult> run({
    required List<Scrip> universe,
    required StudyAdvFilters filters,
    Map<String, String> companyNames = const {},
    DateTime? asOf,
    Map<String, DateTime> resultsDates = const {},
    StudyIvSource ivSource = StudyIvSource.auto,
    void Function(FnoStudyProgress progress)? onProgress,
    bool Function()? isCancelled,
  }) async {
    runCalls++;
    lastFilters = filters;
    lastUniverse = universe;
    lastIvSource = ivSource;
    lastResultsDates = resultsDates;
    if (failure != null) throw failure!;
    return StudyAdvResult(
      rows: buildAdvRows(
        rows,
        {for (final r in rows) r.symbol: r},
        filters,
        resultsDates: resultsDates,
        asOf: asOf,
      ),
      filters: filters,
      asOf: DateTime(2025, 6, 2),
      duration: const Duration(seconds: 4),
      scanned: universe.length,
    );
  }

  @override
  Future<Map<String, List<Candle>>> cachedBars({
    List<Scrip>? universe,
    int days = 420,
    void Function(int done, int total)? onProgress,
  }) async {
    cachedBarsCalls++;
    if (failure != null) throw failure!;
    return bars;
  }

  @override
  Future<List<Candle>> barsForSymbol(String plainSymbol, {int days = 420}) async {
    barsForSymbolCalls++;
    if (failure != null) throw failure!;
    return symbolBars[plainSymbol.toUpperCase()] ?? const <Candle>[];
  }

  @override
  Future<StudyScoreBacktest> backtest({
    required List<Scrip> universe,
    required StudyBacktestConfig config,
    required int years,
    DateTime? asOf,
    void Function(FnoStudyProgress progress)? onProgress,
    bool Function()? isCancelled,
  }) async {
    backtestCalls++;
    lastUniverse = universe;
    if (failure != null) throw failure!;
    return measurement!;
  }
}

StudyRow row({
  required String symbol,
  double score = 8,
  double turnoverCrore = 25,
  int? daysToExpiry = 20,
  double ltp = 100,
  double total3mPct = 12,
  double atrPct = 2,
  double? edgePct,
  Trend3M trend = Trend3M.strongUp,
  String tag = '🎯 Best Buy',
  bool legs = false,
}) =>
    StudyRow(
      symbol: symbol,
      companyName: '$symbol Limited',
      exchange: Exchange.nse,
      token: 'eq-$symbol',
      underlying: symbol,
      ltp: ltp,
      high3m: ltp * 1.2,
      low3m: ltp * 0.8,
      rangePct: 40,
      atr: ltp * 0.02,
      atrPct: atrPct,
      distHiPct: 15,
      distLoPct: 15,
      distHiDays: 10,
      distLoDays: 10,
      months: const [],
      total3mPct: total3mPct,
      upMonths: 3,
      downMonths: 0,
      trend: trend,
      lotSize: 100,
      consistencyPoints: 3,
      magnitudePoints: 3,
      proximityPoints: 3,
      ivPoints: 2,
      score: score,
      ivRank: IvRank.low,
      opportunityTag: tag,
      rank: 1,
      reason: 'Test row',
      bars: 400,
      asOf: DateTime(2025, 6, 2),
      turnoverCrore: turnoverCrore,
      daysToExpiry: daysToExpiry,
      edgePct: edgePct,
      atmStrike: legs ? ltp : null,
      ce: legs ? _leg(symbol, ltp, OptionType.call, 'CE', 8.2, 7.4) : null,
      pe: legs ? _leg(symbol, ltp, OptionType.put, 'PE', 7.9, 7.1) : null,
      strangle: legs
          ? StudyStrangle(
              ce: _leg(symbol, ltp, OptionType.call, 'OTM-CE', 3.4, 3.1),
              pe: _leg(symbol, ltp, OptionType.put, 'OTM-PE', 3.1, 2.9),
              targetPremium: 8.0,
            )
          : null,
    );

StudyOptionLeg _leg(
  String symbol,
  double strike,
  OptionType type,
  String suffix,
  double ltp,
  double previousClose,
) =>
    StudyOptionLeg(
      strike: strike,
      type: type,
      token: '$symbol-$suffix',
      symbol: '$symbol-$suffix',
      ltp: ltp,
      previousClose: previousClose,
    );

const List<String> kTickers = ['RELIANCE', 'INFY', 'TATASTEEL'];


void main() {
  late AppDatabase db;
  late LiveFeedService feed;

  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close();
    db = AppDatabase.instance;

    feed = LiveFeedService(auth: AuthService(store: SecureStore()));

    // The universe resolves against the local scrip master, so seed it the way
    // a synced device would look.
    await ScripDao(db).replaceAll([
      for (var i = 0; i < kTickers.length; i++)
        Scrip(
          token: '${1000 + i}',
          symbol: '${kTickers[i]}-EQ',
          name: kTickers[i],
          exchange: Exchange.nse,
        ),
    ]);
  });

  tearDown(() async {
    await feed.stop();
  });

  tearDownAll(() async {
    await AppDatabase.instance.close();
  });

  StudyAdvProvider build(
    FakeStudyAdvService service, {
    FnoUniverse? universe,
    SettingsProvider? settings,

    /// The NSE feed the earnings calendar reads. Default: an empty one.
    Future<String> Function(Uri) resultsFeed = _emptyFeed,

    /// Paper trades (sirf "Mera hisaab" ke liye).
    TradeDao? trades,
  }) {
    final settingsDao = SettingsDao(db);
    settings ??= SettingsProvider(settingsDao);
    return StudyAdvProvider(
        service: service,
        scripDao: ScripDao(db),
        ipoDao: IpoDao(db),
        scripMaster: ScripMasterService(
          scripDao: ScripDao(db),
          settingsDao: settingsDao,
        ),
        feed: feed,
        settings: settings,
        earnings: EarningsCalendarService(
          dao: EarningsDao(db),
          settings: settingsDao,
          get: resultsFeed,
        ),
        trades: trades,
        fnoUniverse: universe ??
            FnoUniverse(
              symbols: kTickers,
              companyNames: {for (final t in kTickers) t: '$t Limited'},
            ),
      );
  }

  /// Resolves the universe first, so the jobs do not have to.
  Future<StudyAdvProvider> ready(
    FakeStudyAdvService service, {
    FnoUniverse? universe,
    SettingsProvider? settings,
    Future<String> Function(Uri) resultsFeed = _emptyFeed,
    TradeDao? trades,
  }) async {
    final provider = build(
      service,
      universe: universe,
      settings: settings,
      resultsFeed: resultsFeed,
      trades: trades,
    );
    addTearDown(provider.dispose);
    await provider.resolveUniverse();
    return provider;
  }

  // ---- B1: the IV setting has to reach the study -------------------------

  group('the IV source setting', () {
    test('reaches the service — "apna hisaab" means zero greek calls',
        () async {
      final settings = SettingsProvider(SettingsDao(db));
      final service = FakeStudyAdvService(rows: [row(symbol: 'RELIANCE')]);
      final provider = await ready(service, settings: settings);

      await provider.scan();
      expect(service.lastIvSource, StudyIvSource.auto,
          reason: 'default is what the app has always done');

      await settings.setStudyIvSource('blackScholes');
      await provider.scan();
      expect(service.lastIvSource, StudyIvSource.blackScholes);
    });

    test('a setting we do not recognise falls back to auto, never breaks',
        () async {
      final settings = SettingsProvider(SettingsDao(db));
      final service = FakeStudyAdvService(rows: [row(symbol: 'RELIANCE')]);
      final provider = await ready(service, settings: settings);

      await settings.setStudyIvSource('kuch-bhi');
      await provider.scan();

      expect(service.lastIvSource, StudyIvSource.auto);
      expect(provider.error, isNull);
    });
  });

  // ---- B3: results dates reach the gate ----------------------------------

  group('the results gate, end to end', () {
    test('blocks the stock whose results are inside the window', () async {
      final service = FakeStudyAdvService(rows: [
        row(symbol: 'RELIANCE', score: 9),
        row(symbol: 'TATASTEEL', score: 8),
      ]);
      final provider =
          await ready(service, resultsFeed: _relianceFeed);

      provider.setBlockResults(5);
      await provider.scan();

      // 05-Jun minus 02-Jun = 3 din → RELIANCE is held back, TATASTEEL is not.
      expect(
        service.lastResultsDates,
        containsPair('RELIANCE', midnightIn(3)),
      );
      final symbols = [for (final r in provider.rows) r.row.symbol];
      expect(symbols, contains('TATASTEEL'));
      expect(symbols, isNot(contains('RELIANCE')));
      expect(
        provider.gateGroups.map((g) => g.gate),
        contains(AdvGate.results),
      );
    });

    test('off by default — and the calendar is not even fetched', () async {
      var feedCalls = 0;
      Future<String> counting(Uri uri) async {
        feedCalls++;
        return '[]';
      }

      final service = FakeStudyAdvService(rows: [row(symbol: 'RELIANCE')]);
      final provider = await ready(service, resultsFeed: counting);

      await provider.scan();

      expect(feedCalls, 0,
          reason: 'the gate is off, so nothing should be downloaded');
      expect(service.lastResultsDates, isEmpty);
    });

    test('when no dates come back the page says the gate blocked nobody',
        () async {
      final service = FakeStudyAdvService(rows: [row(symbol: 'RELIANCE')]);
      final provider = await ready(service, resultsFeed: _emptyFeed);

      provider.setBlockResults(5);
      await provider.scan();

      expect(provider.note, contains('Results dates NSE se nahi mili'));
      expect(provider.rows, isNotEmpty,
          reason: 'no dates must never be read as "no results anywhere"');
    });
  });

  group('nothing runs by itself', () {
    test('a fresh provider is idle and empty', () {
      final service = FakeStudyAdvService(rows: [
        row(symbol: 'RELIANCE', score: 9),
      ]);
      final provider = build(service);
      addTearDown(provider.dispose);

      expect(provider.status, StudyAdvStatus.idle);
      expect(provider.busy, isFalse);
      expect(provider.hasResult, isFalse);
      expect(provider.rows, isEmpty);
      expect(service.runCalls, 0);
    });

    test('resolving the universe does not scan', () async {
      final service = FakeStudyAdvService(rows: [row(symbol: 'RELIANCE')]);
      final provider = await ready(service);

      expect(provider.universeSize, 3);
      expect(service.runCalls, 0);
      expect(provider.status, StudyAdvStatus.idle);
    });

    test('an empty book is refused with a reason, not a blank screen',
        () async {
      final service = FakeStudyAdvService(rows: [row(symbol: 'RELIANCE')]);
      final provider = await ready(
        service,
        universe: const FnoUniverse(symbols: ['NOTLISTED'], companyNames: {}),
      );
      await provider.scan();

      expect(provider.status, StudyAdvStatus.error);
      expect(provider.error, contains('Scrip master update karo'));
      expect(service.runCalls, 0);
    });
  });

  group('the scan job', () {
    test('runs once, ends ready, and hands the filters through', () async {
      final service = FakeStudyAdvService(rows: [
        row(symbol: 'RELIANCE', score: 9),
        row(symbol: 'INFY', score: 7),
      ]);
      final provider = await ready(service);
      await provider.scan();

      expect(provider.status, StudyAdvStatus.ready);
      expect(service.runCalls, 1);
      expect(service.lastFilters, StudyAdvFilters.defaults);
      expect(service.lastUniverse!.length, 3);
      expect(provider.hasResult, isTrue);
      expect(provider.rows.map((r) => r.row.symbol), ['RELIANCE', 'INFY']);
    });

    test('a second job cannot start while one is running', () async {
      final service = FakeStudyAdvService(rows: [row(symbol: 'RELIANCE')]);
      final provider = await ready(service);

      final first = provider.scan();
      // Both of these must be refused on the spot — not queued behind the
      // first job. (They are not awaited: awaiting would let the first job
      // finish between the calls.)
      unawaited(provider.scan());
      unawaited(provider.measure());
      await first;

      expect(service.runCalls, 1);
      expect(service.backtestCalls, 0);
    });

    test('a failure becomes a Hinglish error, and clears', () async {
      final service = FakeStudyAdvService(failure: StateError('boom'));
      final provider = await ready(service);
      await provider.scan();

      expect(provider.status, StudyAdvStatus.error);
      expect(provider.error, contains('Kaam fail hua'));
      expect(provider.error, contains('boom'));

      provider.clearError();
      expect(provider.error, isNull);
      expect(provider.status, StudyAdvStatus.idle);
    });

    test('a run that finds nothing says so', () async {
      final provider = await ready(FakeStudyAdvService(rows: const []));
      await provider.scan();

      expect(provider.status, StudyAdvStatus.ready);
      expect(provider.hasResult, isFalse);
      expect(provider.note, contains('koi stock nahi mila'));
    });

    test('cancel stops the job and admits the count is partial', () async {
      final provider = await ready(
        FakeStudyAdvService(rows: [row(symbol: 'RELIANCE')]),
      );
      final job = provider.scan();
      provider.cancel();
      await job;

      expect(provider.note, contains('Beech me roka gaya'));
      expect(provider.busy, isFalse);
    });
  });

  group('filters', () {
    test('defaults are liquidity on, everything else off', () {
      final filters = StudyAdvFilters.defaults;

      expect(filters.minTurnoverCrore, 10);
      expect(filters.blockExpiryDay, isTrue);
      expect(filters.minScore, 0);
      expect(filters.blockNearExpiryDays, 0);
    });

    test('changing a filter marks the table stale, it does not re-scan',
        () async {
      final service = FakeStudyAdvService(rows: [row(symbol: 'RELIANCE')]);
      final provider = await ready(service);
      await provider.scan();
      expect(provider.stale, isFalse);

      provider.setMinScore(8);
      expect(provider.stale, isTrue);
      expect(service.runCalls, 1); // no silent re-scan

      await provider.scan();
      expect(provider.stale, isFalse);
      expect(service.lastFilters!.minScore, 8);
    });

    test('a filter that blocks a row still keeps it for "kaun chhoota"',
        () async {
      final service = FakeStudyAdvService(rows: [
        row(symbol: 'RELIANCE', score: 9),
        row(symbol: 'THIN', score: 9, turnoverCrore: 1),
      ]);
      final provider = await ready(service);
      await provider.scan();

      expect(provider.rows.map((r) => r.row.symbol), ['RELIANCE']);
      expect(provider.gateGroups, isNotEmpty);
      expect(
        provider.gateGroups.single.rows.map((r) => r.row.symbol),
        ['THIN'],
      );
      expect(provider.result!.blocked.length, 1);
    });

    test('reset puts every filter back', () async {
      final provider = await ready(
        FakeStudyAdvService(rows: [row(symbol: 'RELIANCE')]),
      );
      provider.setMinScore(9);
      provider.setMinTurnover(50);
      provider.setBlockExpiryDay(false);
      provider.setBlockNearExpiry(5);
      expect(provider.filters, isNot(StudyAdvFilters.defaults));

      provider.resetFilters();
      expect(provider.filters, StudyAdvFilters.defaults);
    });
  });

  group('sorting', () {
    test('best buys lead, then the new score', () async {
      final service = FakeStudyAdvService(rows: [
        row(symbol: 'LOW', score: 3),
        row(symbol: 'TOP', score: 10),
        row(symbol: 'MID', score: 6),
      ]);
      final provider = await ready(service);
      await provider.scan();

      expect(
        provider.rows.map((r) => r.row.symbol),
        ['TOP', 'MID', 'LOW'],
      );
    });

    test('tapping a column flips it, a new column starts descending',
        () async {
      final service = FakeStudyAdvService(rows: [
        row(symbol: 'LOW', score: 3),
        row(symbol: 'TOP', score: 10),
      ]);
      final provider = await ready(service);
      await provider.scan();

      provider.sortBy(StudyAdvSort.ltp);
      expect(provider.sortDescending, isTrue);

      provider.sortBy(StudyAdvSort.ltp);
      expect(provider.sortDescending, isFalse);

      provider.sortBy(StudyAdvSort.symbol);
      expect(provider.sortDescending, isFalse, reason: 'names read A→Z');
      expect(provider.rows.first.row.symbol, 'LOW');
    });

    test('the trend ladder sorts STRONG UP first', () async {
      final provider = await ready(FakeStudyAdvService(rows: [
        row(symbol: 'DOWN', score: 9, tag: '-', trend: Trend3M.strongDown),
        row(symbol: 'UP', score: 9, tag: '-'),
      ]));
      await provider.scan();
      provider.sortBy(StudyAdvSort.trend);

      expect(provider.sortDescending, isFalse);
      expect(provider.rows.map((r) => r.row.symbol), ['UP', 'DOWN']);
    });

    test('a row with no edge sorts last, not as zero', () async {
      final service = FakeStudyAdvService(rows: [
        row(symbol: 'NOEDGE', score: 9),
        row(symbol: 'SMALL', score: 9, edgePct: 0.4),
        row(symbol: 'BIG', score: 9, edgePct: 4.2),
      ]);
      final provider = await ready(service);
      await provider.scan();
      provider.sortBy(StudyAdvSort.edge);

      final order = provider.rows.map((r) => r.row.symbol).toList();
      expect(order.first, 'BIG');
      expect(order.last, 'NOEDGE');
    });
  });

  group('the open row', () {
    test('opening a row subscribes its legs, closing releases them', () async {
      final service = FakeStudyAdvService(rows: [
        row(symbol: 'RELIANCE', score: 9, legs: true),
        row(symbol: 'INFY', score: 8, legs: true),
      ]);
      final provider = await ready(service);
      await provider.scan();

      final first = provider.rows.first;
      expect(provider.expandedSymbol, isNull);

      provider.toggleExpanded(first);
      expect(provider.expandedSymbol, first.row.symbol);
      expect(provider.expandedRow, isNotNull);
      expect(
        feed.extraSubscriptionCount(StudyAdvProvider.feedOwner),
        greaterThan(0),
        reason: 'the open row must put its legs on the WebSocket',
      );

      provider.collapse();
      expect(provider.expandedSymbol, isNull);
      expect(feed.extraSubscriptionCount(StudyAdvProvider.feedOwner), 0,
          reason: 'nothing keeps ticking once the panel is closed');
    });

    test('only one row is open at a time', () async {
      final provider = await ready(FakeStudyAdvService(rows: [
        row(symbol: 'RELIANCE', score: 9),
        row(symbol: 'INFY', score: 8),
      ]));
      await provider.scan();

      provider.toggleExpanded(provider.rows.first);
      provider.toggleExpanded(provider.rows.last);
      expect(provider.expandedSymbol, provider.rows.last.row.symbol);
    });

    test('a row with no options is still openable — the panel says so',
        () async {
      final provider = await ready(FakeStudyAdvService(rows: [
        row(symbol: 'NOCHAIN', score: 9),
      ]));
      await provider.scan();

      provider.toggleExpanded(provider.rows.first);
      expect(provider.expandedRow, isNotNull);
      expect(provider.expandedRow!.strangle, isNull);
      // Nothing to subscribe, and no crash while working that out.
      expect(feed.extraSubscriptionCount(StudyAdvProvider.feedOwner), 0);
    });

    test('the export carries the rows the table shows', () async {
      final provider = await ready(FakeStudyAdvService(rows: [
        row(symbol: 'RELIANCE', score: 9),
        row(symbol: 'INFY', score: 8),
      ]));
      await provider.scan();

      final meta = provider.exportMeta;
      expect(meta.rowCount, 2);
      expect(meta.bestBuyCount, 2);
    });
  });

  group('the measure job', () {
    test('runs the backtest and reports the counts', () async {
      final service = FakeStudyAdvService(
        measurement: runStudyBacktest(
          {
            'RELIANCE': [
              for (var i = 0; i < 200; i++)
                Candle(
                  time: DateTime(2025, 1, 1).add(Duration(days: i)),
                  open: 100 + i * 0.5,
                  high: 100 + i * 0.5,
                  low: 100 + i * 0.5,
                  close: 100 + i * 0.5,
                  volume: 1000000,
                ),
            ],
          },
          config: const StudyBacktestConfig(horizonBars: 10, stride: 5),
          scripFor: (symbol) => Scrip(
            token: symbol,
            symbol: '$symbol-EQ',
            name: symbol,
            exchange: Exchange.nse,
          ),
        ),
      );
      final provider = await ready(service);
      provider.setHorizon(15);
      await provider.measure();

      expect(service.backtestCalls, 1);
      expect(provider.backtest, isNotNull);
      expect(provider.backtest!.trades, greaterThan(0));
      expect(provider.note, contains('trade'));
      expect(provider.status, StudyAdvStatus.ready);
    });

    test('an empty measurement says so', () async {
      final provider = await ready(
        FakeStudyAdvService(
          measurement: runStudyBacktest(
            const {},
            config: const StudyBacktestConfig(),
            scripFor: (symbol) => Scrip(
              token: symbol,
              symbol: '$symbol-EQ',
              name: symbol,
              exchange: Exchange.nse,
            ),
          ),
        ),
      );
      await provider.measure();

      expect(provider.backtest!.isEmpty, isTrue);
      expect(provider.note, contains('koi trade hi nahi bana'));
    });
  });

  // ---- offline analysis (kaunsi cheez internet mangti hai, kaunsi nahi) ---

  group('offline analysis', () {
    List<Candle> bars(int count, {double start = 100, double step = 0.004}) => [
          for (var i = 0; i < count; i++)
            Candle(
              time: DateTime(2024, 1, 1).add(Duration(days: i)),
              open: start * (1 + step * i),
              high: start * (1 + step * i) * 1.01,
              low: start * (1 + step * i) * 0.99,
              close: start * (1 + step * i),
              volume: 1000,
            ),
        ];

    test('candles phone se padhta hai — universe resolve kiye bina bhi',
        () async {
      final service = FakeStudyAdvService(bars: {'AAA': bars(300)});
      final provider = build(service); // universe resolve hua hi nahi
      addTearDown(provider.dispose);

      await provider.analyse();

      expect(provider.analysisError, isNull);
      expect(provider.hasAnalysis, isTrue);
      expect(provider.analysis!.symbols, 1);
      expect(provider.bars.keys, ['AAA']);
    });

    test('dobara mangne par candle dobara nahi padhe jate', () async {
      final service = FakeStudyAdvService(bars: {'AAA': bars(300)});
      final provider = build(service);
      addTearDown(provider.dispose);

      await provider.analyse();
      await provider.analyse();

      expect(service.cachedBarsCalls, 1);
      expect(provider.analysis, isNotNull);
    });

    test('force se dobara padha jata hai (scan ke baad tajja hota hai)',
        () async {
      final service = FakeStudyAdvService(bars: {'AAA': bars(300)});
      final provider = build(service);
      addTearDown(provider.dispose);

      await provider.analyse();
      final first = provider.analysis;
      await provider.analyse(force: true);

      expect(service.cachedBarsCalls, 2);
      expect(provider.analysis, isNot(same(first)));
    });

    test('khali haath — analysis banta hai par sach bolta hai', () async {
      final provider = build(FakeStudyAdvService(bars: {}));
      addTearDown(provider.dispose);

      await provider.analyse();

      expect(provider.analysis, isNotNull);
      expect(provider.hasAnalysis, isFalse);
      expect(provider.analysis!.summary, contains('Kisi bhi stock ke candles'));
    });

    test('galti ho to Hinglish me bataya jata hai', () async {
      final provider = build(FakeStudyAdvService(failure: 'disk full'));
      addTearDown(provider.dispose);

      await provider.analyse();

      expect(provider.analysis, isNull);
      expect(provider.analysisError, contains('disk full'));
      expect(provider.analysisLoading, isFalse);
    });
  });

  // ---- "Mera hisaab": apne trades ka aaina --------------------------------

  group('mera hisaab', () {
    test('trade book juda na ho to chup nahi, baat batata hai', () async {
      final provider = build(FakeStudyAdvService());
      addTearDown(provider.dispose);

      await provider.loadMyTrades();

      expect(provider.myTrades, isNull);
      expect(provider.myTradesError, contains('Trade book'));
    });

    test('band hue trade aur snapshot mil kar bucket banate hain', () async {
      final trades = TradeDao(db);
      final now = DateTime(2025, 6, 2);

      await trades.insertTrade(Trade(
        symbol: 'AAA',
        exchange: Exchange.nse,
        side: OrderSide.buy,
        quantity: 10,
        price: 100,
        executedAt: now,
      ));
      await trades.insertTrade(Trade(
        symbol: 'AAA',
        exchange: Exchange.nse,
        side: OrderSide.sell,
        quantity: 10,
        price: 112,
        executedAt: now,
        realizedPnl: 120,
      ));
      await trades.replaceStudySnapshots([
        StudySnapshotRow(
          symbol: 'AAA',
          savedAt: now,
          score: 9,
          trend: 'STRONG UP',
          ivRank: 'LOW',
        ),
      ]);

      final provider = build(FakeStudyAdvService(), trades: trades);
      addTearDown(provider.dispose);

      await provider.loadMyTrades();

      expect(provider.myTradesError, isNull);
      final report = provider.myTrades!;
      expect(report.closedTrades, 1);
      expect(report.matched, 1);

      final byKey = {for (final b in report.byScore) b.key: b};
      expect(byKey['score_top']!.closed, 1);
      expect(byKey['score_top']!.netPnl, 120);
    });

    test('snapshot na mile to bhi ginti khuli rahe', () async {
      final trades = TradeDao(db);
      await trades.insertTrade(Trade(
        symbol: 'BBB',
        exchange: Exchange.nse,
        side: OrderSide.sell,
        quantity: 10,
        price: 90,
        executedAt: DateTime(2025, 6, 2),
        realizedPnl: -40,
      ));

      final provider = build(FakeStudyAdvService(), trades: trades);
      addTearDown(provider.dispose);
      await provider.loadMyTrades();

      expect(provider.myTrades!.matched, 0);
      expect(provider.myTrades!.unmatched, 1);
      expect(provider.myTrades!.note, contains('ka nahi mila'));
    });

    test('scan ke baad snapshot likha jata hai (kal ke hisaab ke liye)',
        () async {
      final trades = TradeDao(db);
      final provider = await ready(
        FakeStudyAdvService(rows: [
          row(symbol: 'AAA', score: 9.2, trend: Trend3M.strongUp),
        ]),
        trades: trades,
      );

      await provider.scan();

      final saved = await trades.allStudySnapshots();
      expect(saved['AAA'], isNotNull);
      expect(saved['AAA']!.first.score, 9.2);
      expect(saved['AAA']!.first.trend, 'STRONG UP');
    });
  });

  // ---- "aaj kya kare": plan (B4) -----------------------------------------

  group('aaj kya kare (plan)', () {
    List<Candle> rising(int count) => [
          for (var i = 0; i < count; i++)
            Candle(
              time: DateTime(2024, 1, 1).add(Duration(days: i)),
              open: 100 + i * 0.5,
              high: 101 + i * 0.5,
              low: 99 + i * 0.5,
              close: 100 + i * 0.5,
              volume: 1000,
            ),
        ];

    test('khule hue row ke candles se plan banta hai — koi naya request nahi',
        () async {
      final service = FakeStudyAdvService(
        rows: [row(symbol: 'AAA', trend: Trend3M.strongUp, legs: true)],
        symbolBars: {'AAA': rising(300)},
      );
      final provider = await ready(service);
      await provider.scan();

      await provider.ensurePlan('AAA');
      final plan = provider.planFor('AAA');

      expect(plan, isNotNull);
      expect(plan!.symbol, 'AAA');
      expect(plan.stock!.side, PlanSide.buy);
      expect(plan.stock!.target, greaterThan(plan.stock!.entry));
      expect(plan.stock!.stop, lessThan(plan.stock!.entry));
      expect(plan.notes, contains('guarantee nahi'));
      expect(service.barsForSymbolCalls, 1);
    });

    test('ek baar padhe gaye candles dobara nahi padhe jate', () async {
      final service = FakeStudyAdvService(
        rows: [row(symbol: 'AAA', trend: Trend3M.up)],
        symbolBars: {'AAA': rising(300)},
      );
      final provider = await ready(service);
      await provider.scan();

      await provider.ensurePlan('AAA');
      await provider.ensurePlan('AAA');

      expect(service.barsForSymbolCalls, 1);
      expect(provider.planReady('AAA'), isTrue);
    });

    test('candles na mile to plan nahi — par chup nahi', () async {
      final service = FakeStudyAdvService(
        rows: [row(symbol: 'AAA', trend: Trend3M.up)],
        symbolBars: {},
      );
      final provider = await ready(service);
      await provider.scan();

      await provider.ensurePlan('AAA');

      // Plan null hai, par "candles mile nahi" wala jawaab taiyaar hai.
      expect(provider.planFor('AAA'), isNull);
      expect(provider.planReady('AAA'), isTrue);
    });
  });
}
