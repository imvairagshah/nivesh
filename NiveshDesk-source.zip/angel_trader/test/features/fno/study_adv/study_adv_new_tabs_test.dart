// ---------------------------------------------------------------------------
// study_adv_new_tabs_test.dart — naye tabs ki dikhav, bina DB/network ke.
//
// Route test sirf itna pakka karta hai ki page khulta hai (blank screen wala
// purana bug dobara na ho). Ye file uske aage ki baat karti hai: jo cheezein
// screen par padhni chahiyein, wo sach me padh rahi hain ya nahi.
//
// Isliye yahan seedhe banaye gaye (synthetic) rows diye jate hain — koi
// SQLite, koi network nahi. Jo dikhta hai wo sab "kya likha hai" ka test hai:
// IVP kis rang ka, DP ka level kaisa, aur sabse zaroori — chhoti ginti par
// chetavni likhi hai ya nahi.
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/models/paper_trade.dart';
import 'package:angel_trader/data/local/models/study_snapshot.dart';
import 'package:angel_trader/features/fno/study/black_scholes.dart' show OptionType;
import 'package:angel_trader/features/fno/study/study_engine.dart';
import 'package:angel_trader/features/fno/study_adv/study_adv_analysis.dart';
import 'package:angel_trader/features/fno/study_adv/study_adv_mytrades.dart';
import 'package:angel_trader/features/fno/study_adv/study_adv_plan.dart';
import 'package:angel_trader/features/fno/study_adv/study_adv_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

Widget wrap(Widget child) => MaterialApp(home: Scaffold(body: child));

/// Lambi screen: ListView sirf utne bachche banata hai jitne dikhte hain, aur
/// scroll karne par upar wale mit jate hain. Test me sab kuch ek saath dekhna
/// hai, isliye hi screen lambi kar di jati hai.
Future<void> pumpTall(WidgetTester tester, Widget child) async {
  tester.view.physicalSize = const Size(900, 6000);
  tester.view.devicePixelRatio = 1;
  addTearDown(tester.view.reset);
  await tester.pumpWidget(MaterialApp(home: Scaffold(body: child)));
}

IvpRow ivp({
  String symbol = 'RELIANCE',
  double ivp = 82,
  double ivr = 74,
  double current = 18.4,
  double average = 15.2,
  double min = 9.1,
  double max = 34.0,
  int days = 252,
}) =>
    IvpRow(
      symbol: symbol,
      current: current,
      ivp: ivp,
      ivr: ivr,
      min: min,
      max: max,
      average: average,
      days: days,
    );

DpRow dp({
  String symbol = 'RELIANCE',
  double cmp = 1420.5,
  double up = 1480,
  double down = 1380,
  int touches = 3,
}) =>
    DpRow(
      symbol: symbol,
      cmp: cmp,
      nearestUp: DpLevel(
        price: up,
        touches: touches,
        kind: 'upar',
        isNearestUp: true,
        isNearestDown: false,
        distancePct: (up - cmp) / cmp * 100,
      ),
      nearestDown: DpLevel(
        price: down,
        touches: touches,
        kind: 'neeche',
        isNearestUp: false,
        isNearestDown: true,
        distancePct: (down - cmp) / cmp * 100,
      ),
      days: 60,
    );

TrendRow trend({
  String symbol = 'RELIANCE',
  double cmp = 1420.5,
  double sma = 1380.2,
  double ema = 1390.1,
  TrendDirection direction = TrendDirection.up,
  bool aligned = true,
  int days = 200,
}) =>
    TrendRow(
      symbol: symbol,
      cmp: cmp,
      sma: sma,
      ema: ema,
      aligned: aligned,
      direction: direction,
      days: days,
    );

final DateTime _day = DateTime(2025, 6, 2);

Trade closed(String symbol, double pnl) => Trade(
      symbol: symbol,
      exchange: Exchange.nse,
      side: OrderSide.sell,
      quantity: 100,
      price: 250,
      executedAt: _day,
      realizedPnl: pnl,
    );

void main() {
  group('IVP tile', () {
    testWidgets('IVP, IVR aur matlab — sab ek jagah', (tester) async {
      await tester.pumpWidget(wrap(IvpTile(row: ivp())));

      expect(find.text('RELIANCE'), findsOneWidget);
      expect(find.text('IVP 82'), findsOneWidget);
      expect(find.text('IVR 74'), findsOneWidget);
      // Number ke saath matlab bhi: "bahut tez" ka matlab premium mehnga.
      expect(find.textContaining('bahut tez'), findsOneWidget);
      expect(find.textContaining('252 din'), findsOneWidget);
    });

    testWidgets('shaant stock alag baat batata hai', (tester) async {
      await tester.pumpWidget(wrap(IvpTile(row: ivp(ivp: 8, ivr: 5))));

      expect(find.textContaining('shaant'), findsOneWidget);
    });

    testWidgets('kam data ho to wahi likha jata hai', (tester) async {
      await tester.pumpWidget(wrap(IvpTile(row: ivp(days: 30))));

      expect(find.textContaining('kam data (30 din)'), findsOneWidget);
    });
  });

  group('DP tile', () {
    testWidgets('upar aur neeche dono level, doori ke saath', (tester) async {
      await tester.pumpWidget(wrap(DpTile(row: dp())));

      expect(find.textContaining('upar: ₹1480.00'), findsOneWidget);
      expect(find.textContaining('neeche: ₹1380.00'), findsOneWidget);
      // Kitni baar chhua — bina iske level adhura hai.
      expect(find.textContaining('3 baar chhua'), findsNWidgets(2));
    });

    testWidgets('ek taraf level na mile to bhi wahi likha jata hai',
        (tester) async {
      await tester.pumpWidget(wrap(
        const DpTile(
          row: DpRow(
              symbol: 'AAA',
              cmp: 100,
              nearestUp: null,
              nearestDown: DpLevel(
                price: 95,
                touches: 2,
                kind: 'neeche',
                isNearestUp: false,
                isNearestDown: true,
                distancePct: -5,
              ),
              days: 60,
            ),
          ),
        ));

      expect(find.textContaining('upar: koi level nahi mila'), findsOneWidget);
      expect(find.textContaining('neeche: ₹95'), findsOneWidget);
    });
  });

  group('Trend tile', () {
    testWidgets('pakka upar wala trend "pakka" likha hai', (tester) async {
      await tester.pumpWidget(wrap(TrendTile(row: trend())));

      expect(find.textContaining('upar (pakka)'), findsOneWidget);
      expect(find.textContaining('MA ₹1380.20'), findsOneWidget);
    });

    testWidgets('dono line ek mat ho to "thoda kamzor"', (tester) async {
      await tester.pumpWidget(wrap(
        TrendTile(row: trend(direction: TrendDirection.up, aligned: false)),
      ));

      expect(find.textContaining('kamzor'), findsOneWidget);
    });

    testWidgets('seedha aur neeche — alag alag shabd', (tester) async {
      await tester.pumpWidget(wrap(
        TrendTile(row: trend(direction: TrendDirection.flat, aligned: false)),
      ));
      expect(find.textContaining('seedha'), findsOneWidget);

      await tester.pumpWidget(wrap(
        TrendTile(row: trend(direction: TrendDirection.down)),
      ));
      expect(find.textContaining('neeche'), findsOneWidget);
    });
  });

  group('Mera hisaab — screen', () {
    MyTradesReport reportOf(List<Trade> trades, Map<String, StudySnapshotRow> snaps) =>
        buildMyTradesReport(trades: trades, snapshots: snaps);

    testWidgets('har bucket me ginti aur rupees — dono', (tester) async {
      final report = reportOf(
        [closed('AAA', 300), closed('BBB', -100)],
        {
          'AAA': StudySnapshotRow(
              symbol: 'AAA', savedAt: _day, score: 9, trend: 'STRONG UP',
              ivRank: 'LOW'),
          'BBB': StudySnapshotRow(
              symbol: 'BBB', savedAt: _day, score: 3, trend: 'DOWN',
              ivRank: 'HIGH'),
        },
      );
      await pumpTall(tester, MyTradesReportView(report: report));

      // Ginti khuli: 2 trade me se 2 ka joda mila (upar wali line).
      expect(find.textContaining('2 ka study se joda mila'), findsOneWidget);
      // Teeno hisaab (score / trend / IV) screen par hone chahiye.
      expect(find.text('Score ke hisaab se'), findsOneWidget);
      expect(find.text('Trend ke hisaab se'), findsOneWidget);
      expect(find.text('IV ke hisaab se'), findsOneWidget);
    });

    testWidgets('kam trade wale bucket par chetavni dikhti hai', (tester) async {
      final report = reportOf(
        [closed('AAA', 500)],
        {
          'AAA': StudySnapshotRow(
              symbol: 'AAA', savedAt: _day, score: 9, trend: 'UP',
              ivRank: 'LOW'),
        },
      );
      await pumpTall(tester, MyTradesReportView(report: report));

      // Ek trade ka 100% win rate — phir bhi bharosa nahi dilana.
      expect(find.textContaining('kuch pakka nahi'), findsWidgets);
      expect(
        find.textContaining('10 se kam trade — is par bharosa mat kijiye'),
        findsWidgets,
      );
      // Sachchai: kaunsi cheez hai, kaunsi nahi.
      expect(find.text('Ye kya hai (aur kya nahi)'), findsOneWidget);
    });

    testWidgets('khaali report ho to bhi screen khaali nahi', (tester) async {
      final report = reportOf([], {});
      await pumpTall(tester, MyTradesReportView(report: report));

      expect(find.textContaining('Abhi tak koi trade band nahi hua'),
          findsOneWidget);
      expect(find.textContaining('Paper Trading'), findsOneWidget);
    });
  });

  group('Aaj kya kare (plan card)', () {
    TradePlan planOf({
      required double cmp,
      required double atr,
      required Trend3M trend,
      DpRow? dp,
      StudyOptionLeg? ce,
      StudyOptionLeg? pe,
      ({double total, double? ceStrike, double? peStrike})? jodi,
    }) =>
        buildTradePlan(
          symbol: 'RELIANCE',
          cmp: cmp,
          atr: atr,
          trend: trend,
          dp: dp,
          ce: ce,
          pe: pe,
          jodi: jodi,
        );

    testWidgets('stock, CE aur jodi — teeno dikhte hain', (tester) async {
      final plan = planOf(
        cmp: 1000,
        atr: 20,
        trend: Trend3M.up,
        ce: const StudyOptionLeg(
          strike: 1000,
          type: OptionType.call,
          token: 'x',
          symbol: 'x',
          ltp: 30,
        ),
        jodi: (total: 18, ceStrike: 1060, peStrike: 940),
      );
      await pumpTall(tester, StudyPlanBody(plan: plan));

      // Stock wala hissa
      expect(find.textContaining('Stock kharido'), findsOneWidget);
      expect(find.textContaining('₹1000.00'), findsOneWidget); // entry
      expect(find.textContaining('₹980.00'), findsOneWidget); // stop = 1 ATR
      expect(find.textContaining('₹1040.00'), findsOneWidget); // target = 2 ATR
      // Option kharidna
      expect(find.textContaining('CE kharido (1000)'), findsOneWidget);
      // Jodi bechna
      expect(find.textContaining('Jodi becho (strangle)'), findsOneWidget);
      expect(find.textContaining('premium ka aadha'), findsOneWidget);
      expect(find.textContaining('premium ka 1.5×'), findsOneWidget);
    });

    testWidgets('mechanical niyam wali chetavni har plan ke saath', (tester) async {
      final plan = planOf(cmp: 1000, atr: 20, trend: Trend3M.up);
      await pumpTall(tester, StudyPlanBody(plan: plan));

      expect(find.textContaining('MECHANICAL'), findsOneWidget);
      expect(find.textContaining('guarantee nahi'), findsOneWidget);
      expect(find.text('offline hisaab'), findsOneWidget);
    });

    testWidgets('seedha bazaar — "koi plan nahi" likha, khaali jagah nahi',
        (tester) async {
      final plan = planOf(cmp: 1000, atr: 20, trend: Trend3M.sideways);
      await pumpTall(tester, StudyPlanBody(plan: plan));

      expect(find.textContaining('koi pakka plan nahi'), findsOneWidget);
      expect(find.textContaining('Stock kharido'), findsNothing);
    });

    testWidgets('delta na mile to convention wali line dikhti hai', (tester) async {
      final plan = planOf(
        cmp: 1000,
        atr: 20,
        trend: Trend3M.up,
        ce: const StudyOptionLeg(
          strike: 1000,
          type: OptionType.call,
          token: 'x',
          symbol: 'x',
          ltp: 30,
        ),
      );
      await pumpTall(tester, StudyPlanBody(plan: plan));

      // Do jagah likha hai: leg ke saath, aur plan ke notes me.
      expect(find.textContaining('convention'), findsWidgets);
    });
  });
}
