// 1.5.85 — Live diagnose ka pure logic: kaunsa step fatal hai, pehla failure
// kaunsa, aur report me dikhne wali message. (Network/DB touch nahi.)

import 'package:angel_trader/data/local/dao/fno_contract_dao.dart';
import 'package:angel_trader/features/fno/bankex/bankex_data_service.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('failure — pehla FATAL step chunte hain, non-fatal gaps nahi', () {
    const d = LiveDiagnosis(steps: [
      DiagStep(label: 'Angel login', ok: true, detail: 'session active'),
      DiagStep(label: 'BANKEX · IV', ok: false, fatal: false, detail: 'IV unknown'),
      DiagStep(label: 'BANKEX · quotes', ok: false, detail: '0/120 quotes'),
    ]);
    expect(d.ok, isFalse);
    expect(d.failure!.label, 'BANKEX · quotes');
    expect(d.failure!.detail, contains('0/120'));
  });

  test('failure — sirf non-fatal gap ho (IV unknown) to koi fatal failure nahi',
      () {
    const d = LiveDiagnosis(steps: [
      DiagStep(label: 'Angel login', ok: true, detail: 'ok'),
      DiagStep(label: 'BANKNIFTY · IV', ok: false, fatal: false, detail: 'IV unknown'),
    ]);
    expect(d.failure, isNull);
  });

  test('LiveLoadFailure.toString — screen/error text me step + reason', () {
    const f = LiveLoadFailure('BANKEX · spot', 'spot quote nahi mili');
    expect(f.toString(), 'BANKEX · spot — spot quote nahi mili');
  });

  test('DiagStep default fatal=true (quotes/book/spot fatal by default)', () {
    const s = DiagStep(label: 'x', ok: false, detail: 'y');
    expect(s.fatal, isTrue);
  });

  _windowTests();
}

// ---- 1.5.87: strike window (rate-limit fix) ----

FnoContract _c(double strike, String type) => FnoContract(
      underlying: 'BANKNIFTY',
      expiryLabel: '26NOV2026',
      expiryDate: DateTime(2026, 11, 26),
      strike: strike,
      optionType: type,
      token: '${strike.toInt()}$type',
      symbol: 'BANKNIFTY${strike.toInt()}$type',
    );

void _windowTests() {
  test('windowAround — ATM ±6% window (1000+ chain → quote calls kam)', () {
    // BANKNIFTY-like: 200 strikes × CE/PE = 400 contracts, spot 60000.
    final rows = <FnoContract>[
      for (var i = 0; i < 200; i++) ...[
        _c(50000 + i * 100, 'CE'),
        _c(50000 + i * 100, 'PE'),
      ],
    ];
    final window = LiveSnapshotLoader.windowAround(rows, 60000);
    expect(window.length, lessThan(rows.length));
    // ±6% of 60000 = ±3600 → 72 strikes × 2 = 144 contracts
    expect(window.length, inInclusiveRange(100, 160));
    expect(window.every((r) => (r.strike - 60000).abs() <= 3600), isTrue);
    // Max 4 batched calls @50 tokens
    expect((window.length / 50).ceil(), lessThanOrEqualTo(4));
  });

  test('windowAround — bahut chhota chain ho to nearest 30 fallback', () {
    final rows = <FnoContract>[
      for (var i = 0; i < 12; i++) _c(60000 + i * 100, 'CE'),
    ];
    final window = LiveSnapshotLoader.windowAround(rows, 60000);
    expect(window.length, 12); // 10 se kam → nearest-30 fallback, sab aa gaye
  });

  test('atmAroundMedian — sample chain ke beech ke strikes', () {
    final rows = <FnoContract>[
      for (var i = 0; i < 100; i++) _c(50000 + i * 100, 'CE'),
    ];
    final sample = LiveSnapshotLoader.atmAroundMedian(rows, take: 20);
    expect(sample, hasLength(20));
    // Median strike 54900 ke aas-paas hone chahiye
    expect((sample.first.strike - 54900).abs(), lessThanOrEqualTo(1000));
  });
}
