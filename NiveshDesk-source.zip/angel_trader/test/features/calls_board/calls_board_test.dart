// 1.5.71 — Options Calls Board: message parser battery + outcome rules +
// channel-link normalization. Pure, no network.
import 'package:angel_trader/features/calls_board/calls_models.dart';
import 'package:angel_trader/features/calls_board/calls_parsers.dart';
import 'package:angel_trader/features/calls_board/calls_provider.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('parseCallMessage — option calls', () {
    test('NIFTY CE BUY ABOVE + SL + TGT a/b', () {
      final d = parseCallMessage(
          'NIFTY 25500 CE BUY ABOVE 120 SL 90 TGT 150/180');
      expect(d, isNotNull);
      expect(d!.symbol, 'NIFTY');
      expect(d.kind, 'option');
      expect(d.strike, 25500);
      expect(d.optionType, 'CE');
      expect(d.side, 'buy');
      expect(d.entry, 120);
      expect(d.sl, 90);
      expect(d.target1, 150);
      expect(d.target2, 180);
    });

    test('BUY first + @entry + TARGET comma', () {
      final d = parseCallMessage(
          'BUY NIFTY 25500 CE @120 SL 90 TARGET 150, 180');
      expect(d, isNotNull);
      expect(d!.side, 'buy');
      expect(d.entry, 120);
      expect(d.target1, 150);
      expect(d.target2, 180);
    });

    test('PE sell at + stoploss + target', () {
      final d =
          parseCallMessage('NIFTY 25500 pe sell at 80 sl 110 target 50/30');
      expect(d, isNotNull);
      expect(d!.side, 'sell');
      expect(d.optionType, 'PE');
      expect(d.entry, 80);
      expect(d.sl, 110);
      expect(d.target1, 50);
      expect(d.target2, 30);
    });

    test('T1/T2 format + expiry month', () {
      final d = parseCallMessage(
          'BANKNIFTY 52000 CE 26 NOV buy cmp 310 sl 250 t1 380 t2 450');
      expect(d, isNotNull);
      expect(d!.symbol, 'BANKNIFTY');
      expect(d.expiryLabel, '26 NOV');
      expect(d.entry, 310);
      expect(d.target1, 380);
      expect(d.target2, 450);
    });
  });

  group('parseCallMessage — equity + future', () {
    test('RELIANCE FUT BUY — future kind, tracking note', () {
      final d = parseCallMessage('RELIANCE FUT BUY @2450 SL 2400 TGT 2600');
      expect(d, isNotNull);
      expect(d!.kind, 'future');
      expect(d.symbol, 'RELIANCE');
      expect(d.note, contains('tracking unavailable'));
    });

    test('equity BUY RELIANCE @2450', () {
      final d = parseCallMessage('BUY RELIANCE 2450 SL 2400 T1 2600 T2 2700');
      expect(d, isNotNull);
      expect(d!.kind, 'equity');
      expect(d.symbol, 'RELIANCE');
      expect(d.entry, 2450);
      expect(d.target2, 2700);
    });
  });

  group('parseCallMessage — skips honestly', () {
    test('exit/book-profit follow-up = null', () {
      expect(parseCallMessage('NIFTY 25500 CE exit at 150, book profit'),
          isNull);
      expect(parseCallMessage('Booked profit in 25500 ce'), isNull);
    });

    test('random text = null (koi guess nahi)', () {
      expect(parseCallMessage('Aaj market me teji aa sakti hai'), isNull);
      expect(parseCallMessage('Happy Diwali sabhi ko'), isNull);
    });

    test('call bina kisi price ke = null', () {
      expect(parseCallMessage('NIFTY 25500 CE BUY'), isNull);
    });

    test('bina symbol ke bare strike = null (guess nahi ki NIFTY hai)', () {
      expect(parseCallMessage('25500 pe buy at 80 sl 60'), isNull);
    });
  });

  group('classifyOutcome — mechanical SL/target rules', () {
    test('buy: target2 hit → win + points', () {
      final o = classifyOutcome(
        side: CallSide.buy,
        entry: 100,
        sl: 80,
        target1: 130,
        target2: 160,
        ltp: 165,
        daysHeld: 1,
      );
      expect(o.status, CallStatus.target2);
      expect(o.points, 60);
    });

    test('buy: SL hit → loss points (SL exit, LTP se nahi)', () {
      final o = classifyOutcome(
        side: CallSide.buy,
        entry: 100,
        sl: 80,
        target1: 130,
        ltp: 70,
        daysHeld: 1,
      );
      expect(o.status, CallStatus.sl);
      expect(o.exitPrice, 80);
      expect(o.points, -20);
    });

    test('sell: SL hit upar', () {
      final o = classifyOutcome(
        side: CallSide.sell,
        entry: 100,
        sl: 120,
        target1: 70,
        ltp: 125,
        daysHeld: 1,
      );
      expect(o.status, CallStatus.sl);
      expect(o.points, -20);
    });

    test('gap both sides = SL priority (conservative)', () {
      final o = classifyOutcome(
        side: CallSide.buy,
        entry: 100,
        sl: 80,
        target1: 130,
        ltp: 75, // SL ke neeche — target irrelevant
        daysHeld: 1,
      );
      expect(o.status, CallStatus.sl);
    });

    test('maxDays par expired — LTP pe points', () {
      final o = classifyOutcome(
        side: CallSide.buy,
        entry: 100,
        sl: 80,
        target1: 200,
        ltp: 110,
        daysHeld: 5,
      );
      expect(o.status, CallStatus.expired);
      expect(o.points, 10);
    });

    test('beech me = open, points null', () {
      final o = classifyOutcome(
        side: CallSide.buy,
        entry: 100,
        sl: 80,
        target1: 130,
        ltp: 105,
        daysHeld: 1,
      );
      expect(o.status, CallStatus.open);
      expect(o.points, isNull);
    });
  });

  group('normalizeChannelLink', () {
    test('har form se handle', () {
      expect(normalizeChannelLink('https://t.me/s/stock_aaj_or_kal'),
          'stock_aaj_or_kal');
      expect(normalizeChannelLink('https://t.me/my_channel'), 'my_channel');
      expect(normalizeChannelLink('t.me/my_channel'), 'my_channel');
      expect(normalizeChannelLink('@my_channel'), 'my_channel');
      expect(normalizeChannelLink('my_channel'), 'my_channel');
      expect(normalizeChannelLink('https://t.me/my_channel?x=1'), 'my_channel');
    });

    test('invalid → null', () {
      expect(normalizeChannelLink('ab'), isNull);
      expect(normalizeChannelLink('has space'), isNull);
      expect(normalizeChannelLink(''), isNull);
    });
  });
}
