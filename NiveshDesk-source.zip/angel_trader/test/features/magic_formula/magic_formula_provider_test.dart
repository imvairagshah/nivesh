import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/magic_formula_dao.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/features/magic_formula/magic_formula_models.dart';
import 'package:angel_trader/features/magic_formula/magic_formula_provider.dart';
import 'package:angel_trader/services/magic_formula_data_source.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late AppDatabase db;
  late SettingsDao settings;
  late MagicFormulaDao dao;
  final now = DateTime(2026, 10, 17);
  final candidates = [
    const MagicFormulaCandidate(
      symbol: 'ALPHA',
      companyName: 'Alpha Limited',
      exchange: 'NSE',
      sector: 'IT',
      dataSymbol: 'ALPHA',
      isin: 'INE000A01001',
    ),
    const MagicFormulaCandidate(
      symbol: 'BANKX',
      companyName: 'Bank X Limited',
      exchange: 'NSE',
      sector: 'Banking',
      dataSymbol: 'BANKX',
      isin: 'INE000A01002',
    ),
  ];

  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close();
    db = AppDatabase.instance;
    settings = SettingsDao(db);
    dao = MagicFormulaDao(db);
  });

  tearDown(() async {
    await AppDatabase.instance.close();
    AppDatabase.overridePath = null;
  });

  test(
    'opening the page uses SQLite only; scan and one-hour cache are tap driven',
    () async {
      final source = _FakeDataSource(candidates, now);
      final provider = MagicFormulaProvider(
        dao: dao,
        dataSource: source,
        settings: settings,
        clock: () => now,
      );

      await provider.bootstrap();
      expect(source.loadCandidateCalls, 0);
      expect(source.fetchCalls, 0);

      await provider.scan();
      expect(source.loadCandidateCalls, 1);
      expect(source.fetchCalls, 2);
      expect(provider.eligibleCount, 2);
      expect(provider.displayedRows, hasLength(2));

      await provider.scan();
      expect(source.loadCandidateCalls, 2);
      expect(
        source.fetchCalls,
        2,
        reason: 'fresh fundamentals come from SQLite',
      );

      await provider.scan(force: true);
      expect(
        source.fetchCalls,
        4,
        reason: 'explicit refresh bypasses the one-hour cache',
      );

      final offlineSource = _FakeDataSource(const [], now);
      final restored = MagicFormulaProvider(
        dao: dao,
        dataSource: offlineSource,
        settings: settings,
        clock: () => now,
      );
      await restored.bootstrap();

      expect(offlineSource.loadCandidateCalls, 0);
      expect(offlineSource.fetchCalls, 0);
      expect(restored.eligibleCount, 2);
      expect(restored.universe, MagicFormulaUniverse.all);

      provider.dispose();
      restored.dispose();
    },
  );

  test('old parser-version cache is cleared on bootstrap', () async {
    await settings.putMeta(
      MagicFormulaProvider.fundamentalsCacheVersionMetaKey,
      'nse-udiff-xbrl-context-v3',
    );
    await dao.saveAll([
      MagicFormulaFundamental(
        candidate: candidates.first,
        fetchedAt: now,
        source: 'NSE CM-UDiFF EOD Close + Integrated Filing XBRL',
        missingReason:
            'Missing official fields: Market Cap, Total Debt, Cash & Equivalents, Total Assets, Current Liabilities',
        marketPriceAsOf: DateTime(2026, 10, 16),
      ),
    ]);
    final provider = MagicFormulaProvider(
      dao: dao,
      dataSource: _FakeDataSource(candidates, now),
      settings: settings,
      clock: () => now,
    );

    await provider.bootstrap();

    expect(provider.hasCache, isFalse);
    expect(await dao.count(), 0);
    expect(
      await settings.meta(MagicFormulaProvider.fundamentalsCacheVersionMetaKey),
      MagicFormulaProvider.fundamentalsCacheVersion,
    );

    provider.dispose();
  });

  test(
    'HTTP 403 stops scan immediately without caching the failed row',
    () async {
      final source = _BlockedDataSource(candidates);
      final provider = MagicFormulaProvider(
        dao: dao,
        dataSource: source,
        settings: settings,
        clock: () => now,
      );

      await provider.bootstrap();
      await provider.scan();

      expect(
        source.fetchCalls,
        1,
        reason: 'do not repeat the same blocked feed',
      );
      expect(provider.hasError, isTrue);
      expect(provider.error, contains('HTTP 403'));
      expect(provider.error, contains('0/2'));
      expect(provider.isPartialScan, isTrue);
      expect(provider.skippedRows, isEmpty);
      expect(await dao.all(), isEmpty);

      await provider.scan();
      expect(
        source.fetchCalls,
        2,
        reason: '403 failures are not pinned for an hour',
      );

      provider.dispose();
    },
  );

  test('unavailable EOD report stops without caching failed rows', () async {
    final source = _EodUnavailableDataSource(candidates);
    final provider = MagicFormulaProvider(
      dao: dao,
      dataSource: source,
      settings: settings,
      clock: () => now,
    );

    await provider.bootstrap();
    await provider.scan();

    expect(source.fetchCalls, 1);
    expect(provider.hasError, isTrue);
    expect(provider.error, contains('Bhavcopy'));
    expect(provider.error, contains('0/2'));
    expect(provider.skippedRows, isEmpty);
    expect(await dao.all(), isEmpty);

    provider.dispose();
  });

  test(
    'bootstrap hides legacy cached HTTP 403 rows and scan retries them',
    () async {
      await settings.putMeta(
        MagicFormulaProvider.fundamentalsCacheVersionMetaKey,
        MagicFormulaProvider.fundamentalsCacheVersion,
      );
      await dao.saveAll([
        MagicFormulaFundamental(
          candidate: candidates.first,
          fetchedAt: now,
          source: 'NSE public feed',
          missingReason:
              'NSE public filing/quote feed: ClientException: NSE public request HTTP 403 (/api/quote-equity).',
        ),
      ]);
      final source = _FakeDataSource(candidates, now);
      final provider = MagicFormulaProvider(
        dao: dao,
        dataSource: source,
        settings: settings,
        clock: () => now,
      );

      await provider.bootstrap();
      expect(provider.skippedRows, isEmpty);

      await provider.scan();
      expect(source.fetchCalls, 2);
      expect(provider.eligibleCount, 2);

      provider.dispose();
    },
  );

  test('sector chips filter and rerank only the selected sector', () async {
    final source = _FakeDataSource(candidates, now);
    final provider = MagicFormulaProvider(
      dao: dao,
      dataSource: source,
      settings: settings,
      clock: () => now,
    );
    await provider.bootstrap();
    await provider.scan();

    provider.setUniverse(MagicFormulaUniverse.sectorWise);
    provider.clearSectors();
    expect(provider.eligibleCount, 0);
    provider.toggleSector('Banking');

    expect(provider.eligibleCount, 1);
    expect(provider.allRankedRows.single.candidate.symbol, 'BANKX');
    expect(provider.skippedCount, 0);

    provider.dispose();
  });

  test('scanMembers runs a basket list through the same pipeline', () async {
    final source = _FakeDataSource(candidates, now);
    final provider = MagicFormulaProvider(
      dao: dao,
      dataSource: source,
      settings: settings,
      clock: () => now,
    );
    await provider.bootstrap();

    // Basket members arrive as explicit candidates (only ALPHA in this one).
    await provider.scanMembers(
      const [
        MagicFormulaCandidate(
          symbol: 'ALPHA',
          companyName: 'Alpha Limited',
          exchange: 'NSE',
          dataSymbol: 'ALPHA',
          isin: 'INE000A01001',
        ),
      ],
      label: 'Long term',
    );

    expect(provider.lastScanUniverseKey, 'basket:Long term');
    expect(provider.eligibleCount, 1);
    expect(provider.allRankedRows.single.candidate.symbol, 'ALPHA');
    // The universe loader was never touched — explicit member scan.
    expect(source.loadCandidateCalls, 0);
    expect(source.fetchCalls, 1);

    // An empty basket reports honestly and scans nothing.
    await provider.scanMembers(const [], label: 'Empty');
    expect(provider.hasError, isTrue);
    expect(source.fetchCalls, 1);

    provider.dispose();
  });
}

class _BlockedDataSource implements MagicFormulaDataSource {
  _BlockedDataSource(this.candidates);

  final List<MagicFormulaCandidate> candidates;
  int fetchCalls = 0;

  @override
  Future<List<MagicFormulaCandidate>> loadCandidates(
    MagicFormulaUniverse universe,
  ) async => candidates;

  @override
  Future<MagicFormulaFundamental> fetchFundamentals(
    MagicFormulaCandidate candidate, {
    void Function(String stage)? onStage,
  }) async {
    fetchCalls++;
    throw NseMagicFormulaHttpException(
      statusCode: 403,
      uri: Uri.https('www.nseindia.com', '/api/quote-equity'),
    );
  }
}

class _EodUnavailableDataSource implements MagicFormulaDataSource {
  _EodUnavailableDataSource(this.candidates);

  final List<MagicFormulaCandidate> candidates;
  int fetchCalls = 0;

  @override
  Future<List<MagicFormulaCandidate>> loadCandidates(
    MagicFormulaUniverse universe,
  ) async => candidates;

  @override
  Future<MagicFormulaFundamental> fetchFundamentals(
    MagicFormulaCandidate candidate, {
    void Function(String stage)? onStage,
  }) async {
    fetchCalls++;
    throw const MagicFormulaScanAbortException(
      'NSE CM-UDiFF EOD Bhavcopy report unavailable.',
    );
  }
}

class _FakeDataSource implements MagicFormulaDataSource {
  _FakeDataSource(this.candidates, this.now);

  final List<MagicFormulaCandidate> candidates;
  final DateTime now;
  int loadCandidateCalls = 0;
  int fetchCalls = 0;

  @override
  Future<List<MagicFormulaCandidate>> loadCandidates(
    MagicFormulaUniverse universe,
  ) async {
    loadCandidateCalls++;
    return candidates;
  }

  @override
  Future<MagicFormulaFundamental> fetchFundamentals(
    MagicFormulaCandidate candidate, {
    void Function(String stage)? onStage,
  }) async {
    fetchCalls++;
    onStage?.call('Fixture fundamentals');
    final ebit = candidate.symbol == 'BANKX' ? 120.0 : 80.0;
    return MagicFormulaFundamental(
      candidate: candidate,
      marketCapCr: candidate.symbol == 'BANKX' ? 1600 : 1000,
      ebitTtmCr: ebit,
      totalDebtCr: 100,
      cashCr: 50,
      totalAssetsCr: 2000,
      currentLiabilitiesCr: candidate.symbol == 'BANKX' ? 1500 : 1000,
      statementBasis: 'Consolidated',
      periodEnd: DateTime(2026, 3, 31),
      fetchedAt: now,
      source: 'Offline fixture',
    );
  }
}
