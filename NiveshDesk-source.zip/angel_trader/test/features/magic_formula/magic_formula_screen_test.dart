import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/magic_basket_dao.dart';
import 'package:angel_trader/data/local/dao/magic_formula_dao.dart';
import 'package:angel_trader/data/local/dao/scrip_dao.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/features/magic_formula/magic_basket_provider.dart';
import 'package:angel_trader/features/magic_formula/magic_formula_export.dart';
import 'package:angel_trader/features/magic_formula/magic_formula_models.dart';
import 'package:angel_trader/features/magic_formula/magic_formula_provider.dart';
import 'package:angel_trader/features/magic_formula/magic_formula_screen.dart';
import 'package:angel_trader/services/magic_formula_data_source.dart';
import 'package:angel_trader/services/nse_listing_service.dart';
import 'package:angel_trader/services/stock_suggestion_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late AppDatabase db;
  late SettingsDao settings;
  const candidate = MagicFormulaCandidate(
    symbol: 'ACME',
    companyName: 'Acme, Example Limited',
    exchange: 'NSE',
    sector: 'IT',
    isin: 'INE000A01000',
    dataSymbol: 'ACME',
  );
  final scannedAt = DateTime(2026, 10, 17, 14, 30);

  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close();
    db = AppDatabase.instance;
    settings = SettingsDao(db);
  });

  tearDown(() async {
    await AppDatabase.instance.close();
    AppDatabase.overridePath = null;
  });

  testWidgets(
    'renders the standalone ranked page and expands financial detail',
    (tester) async {
      final provider = MagicFormulaProvider(
        dao: MagicFormulaDao(db),
        dataSource: _FakeDataSource(candidate, scannedAt),
        settings: settings,
        clock: () => scannedAt,
      );
      await tester.runAsync(() async {
        await provider.bootstrap();
        await provider.scan();
      });

      await tester.pumpWidget(
        MultiProvider(
          providers: [
            ChangeNotifierProvider<MagicFormulaProvider>.value(
              value: provider,
            ),
            ChangeNotifierProvider<MagicBasketProvider>.value(
              value: MagicBasketProvider(MagicBasketDao(db)),
            ),
            Provider<StockSuggestionService>.value(
              value: StockSuggestionService(
                listings: NseListingService(settings: settings),
                scripDao: ScripDao(db),
              ),
            ),
          ],
          child: const MaterialApp(home: MagicFormulaScreen()),
        ),
      );
      await tester.pump();

      expect(find.text('Magic Formula'), findsOneWidget);
      await tester.drag(find.byType(ListView).first, const Offset(0, -900));
      await tester.pump();
      expect(find.text('Magic Formula ranking'), findsOneWidget);
      expect(find.text('ACME'), findsOneWidget);
      expect(find.text('EOD 16 Oct 2026'), findsOneWidget);
      expect(find.text('20.00%'), findsWidgets);

      await tester.ensureVisible(find.text('ACME'));
      await tester.tap(find.text('ACME').first);
      await tester.pump();
      expect(find.text('TTM EBIT'), findsOneWidget);
      expect(find.text('STATEMENT BASIS'), findsOneWidget);

      provider.dispose();
    },
    timeout: const Timeout(Duration(seconds: 60)),
  );

  test(
    'CSV export includes ranked and skipped rows with escaped names and 2 decimals',
    () {
      final fundamental = MagicFormulaFundamental(
        candidate: candidate,
        marketCapCr: 1000,
        ebitTtmCr: 200,
        totalDebtCr: 100,
        cashCr: 50,
        totalAssetsCr: 2000,
        currentLiabilitiesCr: 1000,
        marketPriceAsOf: DateTime(2026, 10, 16),
        statementBasis: 'Consolidated',
        periodEnd: DateTime(2026, 3, 31),
        fetchedAt: scannedAt,
      );
      final ranked = MagicFormulaRankedStock(
        fundamental: fundamental,
        rocePct: 20,
        earningsYieldPct: 19.05,
        roceRank: 1,
        earningsYieldRank: 1,
        score: 2,
        rank: 1,
      );
      final skippedFundamental = fundamental.withCandidate(
        const MagicFormulaCandidate(
          symbol: 'MISS',
          companyName: 'Missing Example Limited',
          exchange: 'BSE',
        ),
      );
      final csv = MagicFormulaExportService.buildCsv(
        ranked: [ranked],
        skipped: [
          MagicFormulaSkippedStock(
            fundamental: skippedFundamental,
            reason: 'Missing: Total Debt',
          ),
        ],
        universe: MagicFormulaUniverse.all,
        scannedAt: scannedAt,
      );

      expect(csv, contains('Ranked,ALL Stocks,2026-10-17T14:30:00.000'));
      expect(csv, contains('"Acme, Example Limited"'));
      expect(csv, contains(',20.00,1,19.05,1,2,'));
      expect(csv, contains('Market Price As Of'));
      expect(csv, contains('2026-10-16'));
      expect(csv, contains('Skipped,ALL Stocks'));
      expect(csv, contains('Missing: Total Debt'));
    },
  );
}

class _FakeDataSource implements MagicFormulaDataSource {
  _FakeDataSource(this.candidate, this.scannedAt);

  final MagicFormulaCandidate candidate;
  final DateTime scannedAt;

  @override
  Future<List<MagicFormulaCandidate>> loadCandidates(
    MagicFormulaUniverse universe,
  ) async => [candidate];

  @override
  Future<MagicFormulaFundamental> fetchFundamentals(
    MagicFormulaCandidate candidate, {
    void Function(String stage)? onStage,
  }) async => MagicFormulaFundamental(
    candidate: candidate,
    marketCapCr: 1000,
    ebitTtmCr: 200,
    totalDebtCr: 100,
    cashCr: 50,
    totalAssetsCr: 2000,
    currentLiabilitiesCr: 1000,
    marketPriceAsOf: DateTime(2026, 10, 16),
    statementBasis: 'Consolidated',
    periodEnd: DateTime(2026, 3, 31),
    fetchedAt: scannedAt,
    source: 'Offline fixture',
  );
}
