import 'package:angel_trader/features/magic_formula/magic_formula_engine.dart';
import 'package:angel_trader/features/magic_formula/magic_formula_models.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('MagicFormulaEngine', () {
    test('applies the confirmed raw formulas, including to a bank', () {
      final bank = _fundamental(
        'BANKX',
        ebit: 250,
        marketCap: 1000,
        debt: 2000,
        cash: 100,
        assets: 10000,
        currentLiabilities: 8750,
      );

      final metrics = MagicFormulaEngine.metrics(bank)!;
      expect(metrics.rocePct, 20);
      expect(metrics.earningsYieldPct, closeTo(250 / 2900 * 100, 1e-10));
      expect(
        MagicFormulaEngine.rank([bank]).ranked.single.candidate.symbol,
        'BANKX',
      );
    });

    test('ranks ROCE and EY independently and sorts by rank sum', () {
      final rows = [
        _withRatios('ALPHA', roce: 40, ey: 4),
        _withRatios('BRAVO', roce: 30, ey: 15),
        _withRatios('CHARLIE', roce: 20, ey: 10),
        _withRatios('DELTA', roce: 10, ey: 4),
      ];

      final result = MagicFormulaEngine.rank(rows);

      expect(result.ranked.map((row) => row.candidate.symbol), [
        'BRAVO',
        'ALPHA',
        'CHARLIE',
        'DELTA',
      ]);
      final alpha = result.ranked.singleWhere(
        (row) => row.candidate.symbol == 'ALPHA',
      );
      final bravo = result.ranked.singleWhere(
        (row) => row.candidate.symbol == 'BRAVO',
      );
      final delta = result.ranked.singleWhere(
        (row) => row.candidate.symbol == 'DELTA',
      );
      expect((alpha.roceRank, alpha.earningsYieldRank, alpha.score), (1, 3, 4));
      expect((bravo.roceRank, bravo.earningsYieldRank, bravo.score), (2, 1, 3));
      // Equal EY values share competition rank 3; next rank is not 4.
      expect((delta.roceRank, delta.earningsYieldRank, delta.score), (4, 3, 7));
      expect(result.ranked.map((row) => row.rank), [1, 2, 3, 4]);
    });

    test(
      'keeps missing inputs and zero denominators out with clear reasons',
      () {
        final valid = _withRatios('VALID', roce: 20, ey: 10);
        final missingCash = _fundamental(
          'MISSING',
          ebit: 100,
          marketCap: 1000,
          debt: 0,
          cash: null,
          assets: 1000,
          currentLiabilities: 500,
        );
        final zeroEv = _fundamental(
          'ZEROEV',
          ebit: 100,
          marketCap: 100,
          debt: 0,
          cash: 100,
          assets: 1000,
          currentLiabilities: 500,
        );

        final result = MagicFormulaEngine.rank([valid, missingCash, zeroEv]);

        expect(result.ranked.map((row) => row.candidate.symbol), ['VALID']);
        expect(
          result.skipped.map((row) => row.fundamental.candidate.symbol),
          containsAll(['MISSING', 'ZEROEV']),
        );
        expect(
          result.skipped
              .singleWhere(
                (row) => row.fundamental.candidate.symbol == 'MISSING',
              )
              .reason,
          contains('Cash & Equivalents'),
        );
        expect(
          result.skipped
              .singleWhere(
                (row) => row.fundamental.candidate.symbol == 'ZEROEV',
              )
              .reason,
          contains('Enterprise Value is zero'),
        );
      },
    );
  });
}

MagicFormulaFundamental _withRatios(
  String symbol, {
  required double roce,
  required double ey,
}) {
  const ebit = 100.0;
  final capital = ebit * 100 / roce;
  final enterpriseValue = ebit * 100 / ey;
  return _fundamental(
    symbol,
    ebit: ebit,
    marketCap: enterpriseValue,
    debt: 0,
    cash: 0,
    assets: 1000,
    currentLiabilities: 1000 - capital,
  );
}

MagicFormulaFundamental _fundamental(
  String symbol, {
  required double ebit,
  required double marketCap,
  required double? debt,
  required double? cash,
  required double? assets,
  required double? currentLiabilities,
}) => MagicFormulaFundamental(
  candidate: MagicFormulaCandidate(
    symbol: symbol,
    companyName: '$symbol Example Limited',
    exchange: 'NSE',
    sector: 'Financial Services',
    isin: 'INE000A01000',
  ),
  marketCapCr: marketCap,
  ebitTtmCr: ebit,
  totalDebtCr: debt,
  cashCr: cash,
  totalAssetsCr: assets,
  currentLiabilitiesCr: currentLiabilities,
  statementBasis: 'Consolidated',
  periodEnd: DateTime(2026, 3, 31),
  fetchedAt: DateTime(2026, 10, 17),
);
