import 'package:angel_trader/features/magic_formula/fno_scanner/fno_scanner_engine.dart';
import 'package:angel_trader/features/magic_formula/fno_scanner/fno_scanner_service.dart';
import 'package:flutter_test/flutter_test.dart';

/// `n` sessions ending at [kEnd]; close walks by [step] from [base]; every
/// non-final bar is exactly [range] wide (high = close + range/2, low = close −
/// range/2) unless overridden for the LAST bar.
List<ScanBar> series(
  int n, {
  double base = 100,
  double step = 0,
  double range = 2,
  double vol = 1000,
  double? lastClose,
  double? lastHigh,
  double? lastLow,
  double? lastVol,
  double? prevHigh,
  double? prevLow,
  double? prevClose,
}) {
  final bars = <ScanBar>[];
  for (var i = 0; i < n; i++) {
    final isLast = i == n - 1;
    final isPrev = i == n - 2;
    var close = base + step * i;
    var high = close + range / 2;
    var low = close - range / 2;
    var volume = vol;
    if (isLast) {
      close = lastClose ?? close;
      high = lastHigh ?? close + range / 2;
      low = lastLow ?? close - range / 2;
      volume = lastVol ?? vol;
    } else if (isPrev && prevHigh != null) {
      high = prevHigh;
      low = prevLow ?? low;
      close = prevClose ?? close;
    }
    bars.add(ScanBar(
      date: DateTime(2026, 10, 1).add(Duration(days: i)),
      open: close,
      high: high,
      low: low,
      close: close,
      volume: volume,
    ));
  }
  return bars;
}

OiRow oiRow(
  String symbol, {
  double oi = 1000,
  double change = 0,
}) =>
    OiRow(symbol: symbol, oi: oi, oiChange: change);

void main() {
  group('top gainers / losers', () {
    test('% change desc/asc, only real movers, exact values', () {
      final result = computeScanner(ScannerInput(
        bars: {
          'AAA': series(21, lastClose: 110), // +10%
          'BBB': series(21, lastClose: 95), // −5%
          'CCC': series(21, lastClose: 102), // +2%
        },
        oi: const {},
      ));
      final gainers = result.lists.firstWhere((l) => l.key == 'gainers');
      final losers = result.lists.firstWhere((l) => l.key == 'losers');
      expect(gainers.entries.map((e) => e.symbol).toList(), ['AAA', 'CCC']);
      expect(gainers.entries.first.valueText, '+10.00%');
      expect(gainers.entries.first.rank, 1);
      expect(losers.entries.map((e) => e.symbol).toList(), ['BBB']);
      expect(losers.entries.first.valueText, '-5.00%');
    });
  });

  group('volume ×2', () {
    test('only ≥2× of the 20-day average, ranked by multiple', () {
      final result = computeScanner(ScannerInput(
        bars: {
          'SPIKE': series(21, vol: 1000, lastVol: 3000), // 3.0×
          'SOFT': series(21, vol: 1000, lastVol: 1500), // 1.5× — excluded
          'EDGE': series(21, vol: 1000, lastVol: 2100), // 2.1×
        },
        oi: const {},
      ));
      final volume = result.lists.firstWhere((l) => l.key == 'volume');
      expect(volume.entries.map((e) => e.symbol).toList(), ['SPIKE', 'EDGE']);
      expect(volume.entries.first.valueText, '3.0× avg');
    });

    test('exactly 2.0× qualifies (rule: ≥ 2)', () {
      final result = computeScanner(ScannerInput(
        bars: {
          'EXACT': series(21, vol: 1000, lastVol: 2000),
        },
        oi: const {},
      ));
      final volume = result.lists.firstWhere((l) => l.key == 'volume');
      expect(volume.entries.single.symbol, 'EXACT');
    });
  });

  group('narrow CPR (daily)', () {
    test('width = |2C−H−L|/3 of yesterday, narrowest first', () {
      final result = computeScanner(ScannerInput(
        bars: {
          // Yesterday's (H,L,C): width 0, 2/3, 4/3 respectively.
          'ZERO': series(21, prevHigh: 101, prevLow: 99, prevClose: 100),
          'MID': series(21, prevHigh: 103, prevLow: 99, prevClose: 100),
          'WIDE': series(21, prevHigh: 106, prevLow: 98, prevClose: 100),
        },
        oi: const {},
      ));
      final cpr = result.lists.firstWhere((l) => l.key == 'cpr');
      expect(cpr.entries.map((e) => e.symbol).toList(), ['ZERO', 'MID', 'WIDE']);
      expect(cpr.entries[0].valueText, '0.00% wide');
      expect(cpr.entries[1].valueText, '0.67% wide');
      expect(cpr.entries[2].valueText, '1.33% wide');
      expect(cpr.entries.first.subText, contains('× ATR'));
    });
  });

  group('OI change', () {
    test('|change % of previous OI| desc + build-up labels', () {
      final result = computeScanner(ScannerInput(
        bars: {
          'AAA': series(21, lastClose: 101), // price up
          'BBB': series(21, lastClose: 99), // price down
          'CCC': series(21, lastClose: 99), // price down
        },
        oi: {
          'AAA': oiRow('AAA', oi: 1000, change: 200), // +25.00%
          'BBB': oiRow('BBB', oi: 5000, change: -500), // −9.09%
          'CCC': oiRow('CCC', oi: 2000, change: 300), // +17.50%
        },
      ));
      final oi = result.lists.firstWhere((l) => l.key == 'oi');
      expect(oi.entries.map((e) => e.symbol).toList(), ['AAA', 'CCC', 'BBB']);
      expect(oi.entries[0].valueText, '+25.00%');
      expect(oi.entries[1].valueText, '+17.65%'); // 300 of previous 1700
      expect(oi.entries[2].valueText, '-9.09%');
      expect(oi.entries[0].subText, 'Long build-up');
      expect(oi.entries[1].subText, 'Short build-up');
      expect(oi.entries[2].subText, 'Short covering');
    });

    test('price up + OI down = Long unwinding', () {
      final result = computeScanner(ScannerInput(
        bars: {'AAA': series(21, lastClose: 101)},
        oi: {'AAA': oiRow('AAA', oi: 1000, change: -200)},
      ));
      final oi = result.lists.firstWhere((l) => l.key == 'oi');
      expect(oi.entries.single.subText, 'Long unwinding');
    });
  });

  group('score + shortlist', () {
    test('points 10..1 per list, score = points × 2, ≥2 lists shortlist', () {
      // CPR ranks controlled by yesterday's widths: 0, 1/3, 4/3 → STAR < HALF
      // < SOLO. Gainers ranks by % change; volume ranks by multiple.
      final result = computeScanner(ScannerInput(
        bars: {
          'STAR': series(21,
              lastClose: 110, lastVol: 3000, prevHigh: 100.5, prevLow: 99.5),
          'HALF': series(21,
              lastClose: 105, lastVol: 2500, prevHigh: 102, prevLow: 99),
          'SOLO': series(21,
              lastClose: 101, lastVol: 1000, prevHigh: 106, prevLow: 98),
        },
        oi: const {},
      ));
      // STAR: gainers 10 + volume 10 + cpr 10 = 30 → 60. HALF: 9+9+9 = 27 → 54.
      // SOLO: gainers 8 + cpr 8 (no volume) = 16 → 32. All three touch ≥2
      // lists (CPR counts), so all three shortlist — order by points.
      expect(result.shortlist.map((p) => p.symbol).toList(),
          ['STAR', 'HALF', 'SOLO']);
      final star = result.shortlist[0];
      expect(star.points, 30);
      expect(star.score, 60);
      expect(star.listNames,
          containsAll(['Top Gainers', 'Volume ×2', 'Narrow CPR (daily)']));
      expect(result.shortlist[1].score, 54);
      final solo = result.shortlist[2];
      expect(solo.score, 32);
      expect(solo.listNames, isNot(contains('Volume ×2')));
      expect(solo.listNames.length, 2);
    });

    test('a stock in only one list never shortlists', () {
      // 11 stocks: ten with zero-width CPR (they own the CPR top-10), plus
      // SOFT — a decliner (losers list) whose wide CPR ranks 11th. One list
      // only → never shortlisted, no plan.
      final bars = <String, List<ScanBar>>{
        for (var i = 0; i < 10; i++)
          'N$i': series(21, prevHigh: 100.5, prevLow: 99.5),
        'SOFT': series(21, lastClose: 95, prevHigh: 120, prevLow: 90),
      };
      final result = computeScanner(ScannerInput(bars: bars, oi: const {}));
      final cpr = result.lists.firstWhere((l) => l.key == 'cpr');
      expect(cpr.entries.any((e) => e.symbol == 'SOFT'), isFalse);
      final losers = result.lists.firstWhere((l) => l.key == 'losers');
      expect(losers.entries.single.symbol, 'SOFT'); // 1 list = no shortlist
      expect(result.shortlist.any((p) => p.symbol == 'SOFT'), isFalse);
    });
  });

  group('trade plan (mechanical rules)', () {
    test('BUY: entry = LTP, SL = 1×ATR, Target = 2×ATR', () {
      // Prior bars flat at 100 with range 2 → ATR settles at 2; last day jumps
      // to 110 (TR 10) → Wilder ATR = (2×13 + 10)/14 = 2.5714285714285716.
      final result = computeScanner(ScannerInput(
        bars: {'STAR': series(21, lastClose: 110, lastVol: 3000)},
        oi: const {},
      ));
      final pick = result.shortlist.single;
      // Last bar high = 111, prev close = 100 → last TR = 11 → ATR = 37/14.
      expect(pick.plan.direction, TradeDirection.buy);
      expect(pick.plan.entry, closeTo(110, 1e-9));
      expect(pick.plan.atr, closeTo(37 / 14, 1e-9));
      expect(pick.plan.sl, closeTo(110 - 37 / 14, 1e-9));
      expect(pick.plan.target, closeTo(110 + 2 * 37 / 14, 1e-9));
    });

    test('SELL: SL upar, Target neeche', () {
      // SINK: −10% day + OI build-up label 'Short build-up' (price down, OI up)
      // → votes negative → SELL.
      final withOi = computeScanner(ScannerInput(
        bars: {'SINK': series(21, lastClose: 90)},
        oi: {'SINK': oiRow('SINK', oi: 1000, change: 200)}, // OI list rank 1
      ));
      final pick = withOi.shortlist.single;
      expect(pick.plan.direction, TradeDirection.sell);
      expect(pick.plan.sl, greaterThan(pick.plan.entry));
      expect(pick.plan.target, lessThan(pick.plan.entry));
    });

    test('options rule numbers: SL = premium × 0.5, Target = premium × 1.5',
        () {
      const o = OptionsPlan(
        direction: TradeDirection.buy,
        strike: 25000,
        expiryLabel: '30OCT2026',
        lotSize: 75,
        premium: 100,
      );
      expect(o.slRule, closeTo(50, 1e-9));
      expect(o.targetRule, closeTo(150, 1e-9));
      const missing = OptionsPlan(direction: TradeDirection.buy);
      expect(missing.slRule, isNull);
      expect(missing.targetRule, isNull);
    });
  });

  group('F&O universe filter', () {
    test('lists me sirf F&O stocks — non-F&O cash stocks kahin nahi', () {
      // PLAIN is a non-F&O stock (not in universe) that would otherwise top
      // gainers AND volume — it must appear in NO list and NO shortlist.
      final result = computeScanner(ScannerInput(
        bars: {
          'FNO1': series(21, lastClose: 110, lastVol: 3000),
          'FNO2': series(21, lastClose: 95),
          'PLAIN': series(21, lastClose: 110, lastVol: 3000),
        },
        oi: {
          'FNO1': oiRow('FNO1', oi: 1000, change: 200),
          'FNO2': oiRow('FNO2', oi: 1000, change: -200),
        },
        universe: {'FNO1', 'FNO2'},
      ));
      for (final list in result.lists) {
        expect(
          list.entries.any((e) => e.symbol == 'PLAIN'),
          isFalse,
          reason: '${list.title} me non-F&O stock nahi aana chahiye',
        );
      }
      expect(result.universeSize, 2);
      expect(result.shortlist.any((p) => p.symbol == 'PLAIN'), isFalse);
      expect(result.shortlist.map((p) => p.symbol), containsAll(['FNO1', 'FNO2']));
    });
  });

  group('scanner parsers (official bhavcopy)', () {
    test('CM UDiFF: EQ kept with volume, other series dropped', () {
      const csv = 'TradDt,TckrSymb,SctySrs,OpnPric,HghPric,LwPric,ClsPric,'
          'LastPric,PrvsClsgPric,UndrlygPric,SttlmPric,TtlTradgVol,TtlTrfVal,'
          'TtlNbOfTxsExctd,SsnId,NewBrdLotQty,Rmks,Rsvd1,Rsvd2,Rsvd3,Rsvd4\n'
          '24-10-2026,ABC,EQ,100,105,99,104,104,101,0,0,5000,0,0,,0,,,,,\n'
          '24-10-2026,ABCSM,SM,10,11,9,10,10,10,0,0,100,0,0,,0,,,,,\n'
          '24-10-2026,DEF,EQ,200,210,198,205,205,202,0,0,9000,0,0,,0,,,,,';
      final bars = ScannerParsers.parseCmBhavcopy(csv, DateTime(2026, 10, 24));
      expect(bars.keys.toList()..sort(), ['ABC', 'DEF']);
      expect(bars['ABC']!.close, 104);
      expect(bars['ABC']!.volume, 5000);
      expect(bars['DEF']!.high, 210);
    });

    test('CM classic header also works, volume from TOTTRDQTY', () {
      const csv = 'SYMBOL,SERIES,OPEN,HIGH,LOW,CLOSE,LAST,PREVCLOSE,TOTTRDQTY\n'
          'ABC,EQ,100,105,99,104,104,101,12345';
      final bars = ScannerParsers.parseCmBhavcopy(csv, DateTime(2026, 10, 24));
      expect(bars['ABC']!.volume, 12345);
    });

    test('FO UDiFF real format: STF nearest per symbol, STO/IDF/IDO skipped',
        () {
      // Real BhavCopy_NSE_FO_0_0_0 header + FinInstrmTp values (verified
      // against the 2026-10-26 official file): STF=stock futures, STO=stock
      // options, IDF/IDO=index. Only STF rows count.
      const header =
          'TradDt,BizDt,Sgmt,Src,FinInstrmTp,FinInstrmId,ISIN,TckrSymb,SctySrs,'
          'XpryDt,FininstrmActlXpryDt,StrkPric,OptnTp,FinInstrmNm,OpnPric,'
          'HghPric,LwPric,ClsPric,LastPric,PrvsClsgPric,UndrlygPric,SttlmPric,'
          'OpnIntrst,ChngInOpnIntrst,TtlTradgVol,TtlTrfVal,TtlNbOfTxsExctd,'
          'SsnId,NewBrdLotQty,Rmks,Rsvd1,Rsvd2,Rsvd3,Rsvd4';
      String row(String type, String sym, String exp, String strike,
              String opt, String oi, String chg, String lot) =>
          '2026-10-26,2026-10-26,FO,NSE,$type,1001,,$sym,,$exp,$exp,$strike,'
          '$opt,NAME,1,1,1,100,100,99,99,100,$oi,$chg,100,5000,10,F1,$lot,,,,,';
      final csv = [
        header,
        // Stock OPTIONS — never counts.
        row('STO', 'ABCAPITAL', '2026-11-23', '360.00', 'PE', '480500', '21700', '3100'),
        // Far-expiry stock future — parser must pick the NEAR one instead.
        row('STF', 'ABCAPITAL', '2026-11-23', '0', '', '50000', '1000', '200'),
        row('STF', 'ABCAPITAL', '2026-10-27', '0', '', '10000', '2000', '200'),
        // Index futures/options (IDF/IDO) — never count.
        row('IDF', 'NIFTY', '2026-10-27', '0', '', '99999', '5000', '75'),
        row('IDO', 'NIFTY', '2026-10-27', '25000.00', 'CE', '88888', '4000', '75'),
      ].join('\n');
      final oi = ScannerParsers.parseFoBhavcopy(csv, DateTime(2026, 10, 26));
      expect(oi.keys.toList(), ['ABCAPITAL']);
      expect(oi['ABCAPITAL']!.oi, 10000);
      expect(oi['ABCAPITAL']!.oiChange, 2000);
      expect(oi['ABCAPITAL']!.lotSize, 200);
      expect(oi['ABCAPITAL']!.oiChangePct, closeTo(25, 1e-9)); // 2000 / 8000
    });

    test('date parsing covers NSE formats', () {
      expect(ScannerParsers.parseNseDate('2024-11-28'), DateTime(2024, 11, 28));
      expect(ScannerParsers.parseNseDate('28-Nov-2024'), DateTime(2024, 11, 28));
      expect(ScannerParsers.parseNseDate('28NOV2024'), DateTime(2024, 11, 28));
      expect(ScannerParsers.parseNseDate('garbage'), isNull);
    });

    test('result ↔ cache round-trip keeps lists, score and plan', () {
      final result = computeScanner(ScannerInput(
        bars: {'STAR': series(21, lastClose: 110, lastVol: 3000)},
        oi: {'STAR': oiRow('STAR', oi: 1000, change: 200)},
      ));
      final row = ScannerParsers.resultToRow(result);
      final back = ScannerParsers.resultFromRow(row);
      expect(back.universeSize, result.universeSize);
      expect(back.shortlist.single.symbol, 'STAR');
      expect(back.shortlist.single.score, result.shortlist.single.score);
      expect(back.shortlist.single.plan.sl,
          closeTo(result.shortlist.single.plan.sl!, 1e-9));
      expect(back.shortlist.single.oi!.oiChange, 200);
      expect(back.lists.map((l) => l.key).toList(),
          result.lists.map((l) => l.key).toList());
    });
  });
}
