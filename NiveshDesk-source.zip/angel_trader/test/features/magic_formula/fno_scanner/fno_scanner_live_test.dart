// 1.5.70 — F&O Scanner LIVE overlay: engine live-merge rules, base-input
// cache round-trip, market-hours gate. Pure, no network.
import 'package:angel_trader/features/magic_formula/fno_scanner/fno_scanner_engine.dart';
import 'package:angel_trader/features/magic_formula/fno_scanner/fno_scanner_provider.dart';
import 'package:angel_trader/features/magic_formula/fno_scanner/fno_scanner_service.dart';
import 'package:flutter_test/flutter_test.dart';

List<ScanBar> bars(List<double> closes, {double volume = 1000}) {
  final start = DateTime(2026, 9, 1);
  return [
    for (var i = 0; i < closes.length; i++)
      ScanBar(
        date: start.add(Duration(days: i)),
        open: closes[i],
        high: closes[i] * 1.01,
        low: closes[i] * 0.99,
        close: closes[i],
        volume: volume,
      ),
  ];
}

ScannerInput baseInput() {
  final symbols = ['AAA', 'BBB'];
  return ScannerInput(
    bars: {
      for (final s in symbols)
        s: bars([for (var i = 0; i < 21; i++) 100.0], volume: 1000),
    },
    oi: {
      'AAA': const OiRow(symbol: 'AAA', oi: 1000, oiChange: 100),
      'BBB': const OiRow(symbol: 'BBB', oi: 2000, oiChange: -200),
    },
    universe: {'AAA', 'BBB'},
  );
}

void main() {
  group('computeScanner live overlay (1.5.70)', () {
    test('live pChange se gainers/losers re-rank, Entry=live LTP', () {
      final input = baseInput();
      // EOD me dono flat. Live: AAA +5% (gainer), BBB -4% (loser).
      final live = {
        'AAA': const LiveQuote(ltp: 105, prevClose: 100, volume: 5000),
        'BBB': const LiveQuote(ltp: 96, prevClose: 100, volume: 500),
      };
      final r = computeScanner(ScannerInput(
        bars: input.bars,
        oi: input.oi,
        universe: input.universe,
        live: live,
      ));
      final gainers = r.lists.firstWhere((l) => l.key == 'gainers');
      expect(gainers.entries.first.symbol, 'AAA');
      final losers = r.lists.firstWhere((l) => l.key == 'losers');
      expect(losers.entries.first.symbol, 'BBB');
      // Plan Entry = live LTP. AAA gainers + volume (5×) dono me → shortlist.
      final pick = r.shortlist.firstWhere((p) => p.symbol == 'AAA');
      expect(pick.ltp, 105);
      expect(pick.plan.entry, 105);
      expect(pick.listNames, containsAll(['Top Gainers', 'Volume ×2']));
    });

    test('Volume ×2 list live volume se banti hai (20-avg EOD)', () {
      // EOD: sabka volume 1000 = 1× avg (list me koi nahi). Live AAA 5×.
      final input = baseInput();
      final r = computeScanner(ScannerInput(
        bars: input.bars,
        oi: input.oi,
        universe: input.universe,
        live: {
          'AAA': const LiveQuote(ltp: 101, prevClose: 100, volume: 5000),
          'BBB': const LiveQuote(ltp: 100, prevClose: 100, volume: 1000),
        },
      ));
      final volume = r.lists.firstWhere((l) => l.key == 'volume');
      expect(volume.entries.map((e) => e.symbol), ['AAA']);
    });

    test('OI list EOD hi rehti hai — live se koi asar nahi', () {
      final input = baseInput();
      final r = computeScanner(ScannerInput(
        bars: input.bars,
        oi: input.oi,
        universe: input.universe,
        live: {
          'AAA': const LiveQuote(ltp: 999, prevClose: 100, volume: 1),
        },
      ));
      final oi = r.lists.firstWhere((l) => l.key == 'oi');
      // BBB ka |−200/2200| ≈ 9.09% > AAA ka 100/1100 ≈ 9.09%... sort by abs.
      expect(oi.entries.map((e) => e.symbol).toSet(), {'AAA', 'BBB'});
    });

    test('live null = purana EOD behaviour (1.5.63 pinned rules intact)', () {
      final r = computeScanner(baseInput());
      expect(r.lists, hasLength(5));
      expect(r.asOf, DateTime(2026, 9, 21));
    });
  });

  group('ScannerParsers input cache round-trip', () {
    test('inputToRow → inputFromRow bars + oi + universe barabar', () {
      final input = baseInput();
      final row = ScannerParsers.inputToRow(input);
      final back = ScannerParsers.inputFromRow(row);
      expect(back, isNotNull);
      expect(back!.bars.keys, input.bars.keys);
      expect(back.bars['AAA']!.length, 21);
      expect(back.bars['AAA']!.last.close, 100);
      expect(back.bars['AAA']!.last.volume, 1000);
      expect(back.oi['AAA']!.oi, 1000);
      expect(back.oi['AAA']!.oiChange, 100);
      expect(back.oi['BBB']!.oiChangePct, closeTo(-200 / 2200 * 100, 0.001));
      expect(back.universe, {'AAA', 'BBB'});
    });

    test('garbage row → null (corrupt cache hi nahi)', () {
      expect(ScannerParsers.inputFromRow({'bars': 'x'}), isNull);
      expect(ScannerParsers.inputFromRow({}), isNull);
    });
  });

  group('marketOpenAt (IST session gate)', () {
    DateTime ist(int y, int mo, int d, int h, int mi) =>
        DateTime(y, mo, d, h, mi);

    test('Wed 9:15–15:30 open, band ke bahar band', () {
      // 2026-10-28 is a Wednesday.
      expect(FnoScannerProvider.marketOpenAt(ist(2026, 10, 28, 9, 15)), isTrue);
      expect(FnoScannerProvider.marketOpenAt(ist(2026, 10, 28, 12, 45)), isTrue);
      expect(FnoScannerProvider.marketOpenAt(ist(2026, 10, 28, 15, 30)), isTrue);
      expect(FnoScannerProvider.marketOpenAt(ist(2026, 10, 28, 15, 31)), isFalse);
      expect(FnoScannerProvider.marketOpenAt(ist(2026, 10, 28, 9, 14)), isFalse);
    });

    test('weekend band', () {
      expect(FnoScannerProvider.marketOpenAt(ist(2026, 10, 24, 11, 0)), isFalse);
      expect(FnoScannerProvider.marketOpenAt(ist(2026, 10, 25, 11, 0)), isFalse);
    });
  });
}
