// ---------------------------------------------------------------------------
// cross_engine_test.dart — the 50/200 SMA crossover maths.
//
// The candle shapes below were checked bar-by-bar with tool/probe_cross.dart:
//
//   GOLDEN  decline 220 bars (300→100), then rise 120 bars (100→300)
//           → the 50-SMA crosses above the 200-SMA 59 sessions before the end
//   DEATH   rise 220 bars (100→320), then fall 140 bars (320→110)
//           → the 50-SMA crosses below the 200-SMA 74 sessions before the end
//   CYCLES  down → up → down → up, which contains two golden crosses and one
//           death cross — used to prove that the *closest* cross wins
//
// A subtlety worth spelling out, because it is the natural trap when building
// synthetic series: the 200-day average only exists from bar 200 onwards, so a
// cross can only be detected if the two averages already straddle each other by
// then. A short decline followed by a rise has the fast average *above* the slow
// one at that first computable bar, which means no cross exists at all — the
// engine is right to report nothing.
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/features/golden_cross/cross_engine.dart';
import 'package:flutter_test/flutter_test.dart';

// ---------------------------------------------------------------------------
// Data builders
// ---------------------------------------------------------------------------

List<double> flat(int count, double price) => List<double>.filled(count, price);

/// Linear ramp of [count] points from [from] to [to] (inclusive of both ends).
List<double> ramp(int count, double from, double to) => [
      for (var i = 0; i < count; i++)
        count == 1 ? from : from + (to - from) * (i / (count - 1)),
    ];

/// Daily bars, one per calendar day, starting **on** [start].
List<Candle> series(List<double> closes, {DateTime? start}) {
  final bars = <Candle>[];
  var day = start ?? DateTime(2023, 1, 2);
  for (final close in closes) {
    bars.add(Candle(
      time: day,
      open: close,
      high: close * 1.01,
      low: close * 0.99,
      close: close,
      volume: 1000,
    ));
    day = day.add(const Duration(days: 1));
  }
  return bars;
}

/// The verified golden-cross shape (340 bars, cross 59 sessions before the end).
List<double> goldenShape() => [
      ...ramp(220, 300, 100),
      ...ramp(120, 100, 300),
    ];

/// The verified death-cross shape (360 bars, cross 74 sessions before the end).
List<double> deathShape() => [
      ...ramp(220, 100, 320),
      ...ramp(140, 320, 110),
    ];

/// Two golden crosses and one death cross (600 bars).
List<double> cycleShape() => [
      ...ramp(220, 300, 100),
      ...ramp(120, 100, 300),
      ...ramp(110, 300, 150),
      ...ramp(150, 150, 340),
    ];

/// Cuts [closes] just after [shaveFromEnd] bars so the signal lands on the very
/// last bar (age 0) — the "crossed today" case the UI highlights.
List<double> endingAtCross(List<double> closes, int shaveFromEnd) =>
    closes.sublist(0, closes.length - shaveFromEnd);

int _indexOfDate(List<Candle> candles, DateTime date) {
  for (var i = 0; i < candles.length; i++) {
    if (candles[i].istDate == date) return i;
  }
  return -1;
}

void main() {
  group('simpleMovingAverage', () {
    test('is null until the window is full, then averages exactly', () {
      final sma = simpleMovingAverage([1, 2, 3, 4, 5], 3);
      expect(sma[0], isNull);
      expect(sma[1], isNull);
      expect(sma[2], closeTo(2, 1e-9)); // (1+2+3)/3
      expect(sma[3], closeTo(3, 1e-9));
      expect(sma[4], closeTo(4, 1e-9));
    });

    test('handles a flat series without drift', () {
      final sma = simpleMovingAverage(flat(50, 100), 50);
      expect(sma.last, closeTo(100, 1e-9));
    });

    test('returns all nulls when there are fewer bars than the period', () {
      final sma = simpleMovingAverage([1, 2, 3], 200);
      expect(sma.every((v) => v == null), isTrue);
    });

    test('period 1 is the series itself', () {
      final values = [4.0, 8.0, 15.0];
      expect(simpleMovingAverage(values, 1), values);
    });

    test('closesOf mirrors the close column', () {
      final candles = series([10, 20, 30]);
      expect(closesOf(candles), [10.0, 20.0, 30.0]);
    });
  });

  group('findCross — golden', () {
    test('detects the 50 crossing above the 200', () {
      final candles = series(goldenShape());
      final signal = findCross(
        candles: candles,
        asOf: candles.last.istDate,
        symbol: 'TEST',
        direction: CrossDirection.golden,
        maxAgeBars: 400,
      );

      expect(signal, isNotNull);
      expect(signal!.direction, CrossDirection.golden);
      expect(signal.symbol, 'TEST');
      expect(signal.fastPeriod, 50);
      expect(signal.slowPeriod, 200);
      expect(signal.barsUsed, candles.length);

      // The defining inequalities hold on the cross bar and the bar before it.
      expect(signal.prevFast, lessThanOrEqualTo(signal.prevSlow));
      expect(signal.fast, greaterThan(signal.slow));
      expect(signal.gapPct, greaterThan(0));
      expect(signal.ageBars, 59);
      expect(signal.isFresh, isFalse);
    });

    test('no death cross hides in a golden series', () {
      final candles = series(goldenShape());
      expect(
        findCross(
          candles: candles,
          asOf: candles.last.istDate,
          symbol: 'TEST',
          direction: CrossDirection.death,
          maxAgeBars: 1000,
        ),
        isNull,
      );
    });

    test('maxAgeBars decides whether a 59-session-old cross is reported', () {
      final candles = series(goldenShape());

      // Today-only: the cross is far behind, so nothing is reported.
      expect(
        findCross(
          candles: candles,
          asOf: candles.last.istDate,
          symbol: 'TEST',
          maxAgeBars: 0,
        ),
        isNull,
      );

      // A week-wide window is still too narrow …
      expect(
        findCross(
          candles: candles,
          asOf: candles.last.istDate,
          symbol: 'TEST',
          maxAgeBars: 5,
        ),
        isNull,
      );

      // … but a 60-session window catches it.
      expect(
        findCross(
          candles: candles,
          asOf: candles.last.istDate,
          symbol: 'TEST',
          maxAgeBars: 60,
        ),
        isNotNull,
      );
    });

    test('cutting the series at the cross bar makes the signal fresh', () {
      final full = series(goldenShape());
      final candles = series(endingAtCross(goldenShape(), 59));

      expect(candles.length, full.length - 59);

      final signal = findCross(
        candles: candles,
        asOf: candles.last.istDate,
        symbol: 'TEST',
        maxAgeBars: 0,
      );

      expect(signal, isNotNull);
      expect(signal!.ageBars, 0);
      expect(signal.isFresh, isTrue);
      expect(signal.ageLabel, 'Crossed on this session');
      expect(signal.crossDate, candles.last.istDate);
    });

    test('age counts completed sessions since the cross', () {
      final candles = series(goldenShape());
      final signal = findCross(
        candles: candles,
        asOf: candles.last.istDate,
        symbol: 'TEST',
        maxAgeBars: 400,
      )!;

      final index = _indexOfDate(candles, signal.crossDate);
      expect(index, greaterThan(0));
      expect(signal.ageBars, candles.length - 1 - index);
      expect(signal.crossClose, closeTo(candles[index].close, 1e-9));
      expect(signal.lastClose, closeTo(candles.last.close, 1e-9));
    });

    test('the closest cross wins when the history holds several', () {
      final candles = series(cycleShape());
      final all = scanSeries(candles: candles, symbol: 'W');

      expect(all.length, 2, reason: 'the cycle shape contains two golden crosses');

      final latest = findCross(
        candles: candles,
        asOf: candles.last.istDate,
        symbol: 'W',
        maxAgeBars: 1000,
      )!;

      expect(latest.crossDate, all.last.crossDate);
      expect(latest.ageBars, lessThan(all.first.ageBars));
    });
  });

  group('findCross — death', () {
    test('detects the 50 crossing below the 200', () {
      final candles = series(deathShape());
      final signal = findCross(
        candles: candles,
        asOf: candles.last.istDate,
        symbol: 'TEST',
        direction: CrossDirection.death,
        maxAgeBars: 400,
      );

      expect(signal, isNotNull);
      expect(signal!.direction, CrossDirection.death);
      expect(signal.direction.isBullish, isFalse);
      expect(signal.direction.shortLabel, 'DEATH');
      expect(signal.direction.label, 'Death Cross');
      expect(signal.prevFast, greaterThanOrEqualTo(signal.prevSlow));
      expect(signal.fast, lessThan(signal.slow));
      expect(signal.gapPct, lessThan(0));
      expect(signal.ageBars, 74);
    });

    test('a golden search on the same data finds nothing', () {
      final candles = series(deathShape());
      expect(
        findCross(
          candles: candles,
          asOf: candles.last.istDate,
          symbol: 'TEST',
          direction: CrossDirection.golden,
          maxAgeBars: 1000,
        ),
        isNull,
      );
    });

    test('a truncated death series is fresh and found by a today-only scan', () {
      final candles = series(endingAtCross(deathShape(), 74));
      final signal = findCross(
        candles: candles,
        asOf: candles.last.istDate,
        symbol: 'TEST',
        direction: CrossDirection.death,
        maxAgeBars: 0,
      );

      expect(signal, isNotNull);
      expect(signal!.isFresh, isTrue);
      expect(signal.gapPct, lessThan(0));
      expect(signal.crossClose, closeTo(candles.last.close, 1e-9));
    });

    test('the cycle shape holds exactly one death cross', () {
      final candles = series(cycleShape());
      final deaths = scanSeries(
        candles: candles,
        symbol: 'W',
        direction: CrossDirection.death,
      );
      expect(deaths.length, 1);
      expect(deaths.single.direction, CrossDirection.death);
    });
  });

  group('insufficient history', () {
    test('needs at least slowPeriod + 1 bars', () {
      final short = series(flat(200, 100));
      expect(
        findCross(candles: short, asOf: short.last.istDate, symbol: 'NEW'),
        isNull,
      );

      // 201 bars is enough to compute both averages, but a flat series has
      // equal averages and an equal pair is neither a golden nor a death cross,
      // so the result is still null — for the right reason this time.
      final enough = series(flat(201, 100));
      expect(
        findCross(candles: enough, asOf: enough.last.istDate, symbol: 'NEW'),
        isNull,
      );
      expect(closesOf(enough).length, 201);
    });

    test('a strictly falling then flat series produces no golden cross', () {
      final candles = series([...ramp(220, 300, 100), ...flat(30, 100)]);
      expect(
        findCross(
          candles: candles,
          asOf: candles.last.istDate,
          symbol: 'FALL',
          maxAgeBars: 1000,
        ),
        isNull,
      );
    });

    test('a real cross is still invisible when the series is too short', () {
      final truncated = series(goldenShape().sublist(0, 150));
      expect(
        findCross(
          candles: truncated,
          asOf: truncated.last.istDate,
          symbol: 'SHORT',
          maxAgeBars: 1000,
        ),
        isNull,
      );
    });
  });

  group('as-of date handling', () {
    test('only bars up to the as-of date are considered', () {
      final candles = series(goldenShape());
      final signal = findCross(
        candles: candles,
        asOf: candles.last.istDate,
        symbol: 'TEST',
        maxAgeBars: 400,
      )!;

      // Screen two sessions before the cross: the signal must not exist yet.
      final before = signal.crossDate.subtract(const Duration(days: 2));
      expect(
        findCross(
          candles: candles,
          asOf: before,
          symbol: 'TEST',
          maxAgeBars: 0,
        ),
        isNull,
      );

      // On the cross date itself the signal is fresh.
      final onTheDay = findCross(
        candles: candles,
        asOf: signal.crossDate,
        symbol: 'TEST',
        maxAgeBars: 0,
      );
      expect(onTheDay, isNotNull);
      expect(onTheDay!.isFresh, isTrue);
      expect(onTheDay.crossDate, signal.crossDate);
      expect(onTheDay.fast, closeTo(signal.fast, 1e-9));
    });

    test('candlesUpTo filters and sorts', () {
      final candles = series(ramp(10, 100, 110), start: DateTime(2024, 3, 1));
      final picked = candlesUpTo(candles, DateTime(2024, 3, 5));
      expect(picked.length, 5);
      expect(picked.first.istDate, DateTime(2024, 3, 1));
      expect(picked.last.istDate, DateTime(2024, 3, 5));
    });

    test('sparkline keeps the last bars and marks the cross', () {
      final candles = series(goldenShape());
      final signal = findCross(
        candles: candles,
        asOf: candles.last.istDate,
        symbol: 'SPARK',
        maxAgeBars: 400,
        sparkBars: 60,
      )!;

      expect(signal.spark.length, 60);
      expect(signal.sparkFast.length, 60);
      expect(signal.sparkSlow.length, 60);
      expect(signal.sparkCrossIndex, inInclusiveRange(0, 59));
      // The cross sits 59 sessions back, so it lands on the first point of the
      // 60-session window.
      expect(signal.sparkCrossIndex, 0);
      expect(signal.spark.last, closeTo(signal.lastClose, 1e-6));
    });

    test('a cross older than the sparkline window is marked off-window', () {
      final candles = series(deathShape());
      final signal = findCross(
        candles: candles,
        asOf: candles.last.istDate,
        symbol: 'SPARK',
        direction: CrossDirection.death,
        maxAgeBars: 400,
        sparkBars: 30,
      )!;

      expect(signal.spark.length, 30);
      expect(signal.sparkCrossIndex, -1);
    });
  });

  group('persistence round-trip', () {
    test('toRow / fromRow keeps every card field', () {
      final candles = series(goldenShape());
      final signal = findCross(
        candles: candles,
        asOf: candles.last.istDate,
        symbol: 'SBIN',
        exchange: Exchange.nse,
        brokerSymbol: 'SBIN-EQ',
        companyName: 'State Bank of India',
        token: '3045',
        maxAgeBars: 400,
      )!;

      final restored = CrossSignal.fromRow(signal.toRow());

      expect(restored.symbol, 'SBIN');
      expect(restored.brokerSymbol, 'SBIN-EQ');
      expect(restored.companyName, 'State Bank of India');
      expect(restored.exchange, Exchange.nse);
      expect(restored.token, '3045');
      expect(restored.direction, CrossDirection.golden);
      expect(restored.crossDate, signal.crossDate);
      expect(restored.ageBars, signal.ageBars);
      expect(restored.crossClose, closeTo(signal.crossClose, 1e-3));
      expect(restored.lastClose, closeTo(signal.lastClose, 1e-3));
      expect(restored.fast, closeTo(signal.fast, 1e-3));
      expect(restored.slow, closeTo(signal.slow, 1e-3));
      expect(restored.prevFast, closeTo(signal.prevFast, 1e-3));
      expect(restored.prevSlow, closeTo(signal.prevSlow, 1e-3));
      expect(restored.spark.length, signal.spark.length);
      expect(restored.sparkCrossIndex, signal.sparkCrossIndex);
      expect(restored.priceKey, 'NSE:SBIN');
    });

    test('a death-cross row survives the round-trip as death', () {
      final candles = series(deathShape());
      final signal = findCross(
        candles: candles,
        asOf: candles.last.istDate,
        symbol: 'YESBANK',
        direction: CrossDirection.death,
        maxAgeBars: 400,
      )!;

      expect(CrossSignal.fromRow(signal.toRow()).direction, CrossDirection.death);
      expect(CrossDirection.fromCode('DEATH'), CrossDirection.death);
      expect(CrossDirection.fromCode('death'), CrossDirection.death);
      expect(CrossDirection.fromCode('golden'), CrossDirection.golden);
      expect(CrossDirection.fromCode(null), CrossDirection.golden);
    });
  });

  group('age labels', () {
    CrossSignal withAge(int age) => CrossSignal(
          direction: CrossDirection.golden,
          symbol: 'X',
          brokerSymbol: 'X',
          companyName: '',
          exchange: Exchange.nse,
          token: '1',
          crossDate: DateTime(2025, 9, 29),
          ageBars: age,
          crossClose: 100,
          lastClose: 105,
          fast: 101,
          slow: 99,
          prevFast: 98,
          prevSlow: 99,
          barsUsed: 260,
        );

    test('describe the session distance in words', () {
      expect(withAge(0).ageLabel, 'Crossed on this session');
      expect(withAge(1).ageLabel, 'Crossed 1 session earlier');
      expect(withAge(7).ageLabel, 'Crossed 7 sessions earlier');
    });

    test('isFresh only on the cross bar itself', () {
      expect(withAge(0).isFresh, isTrue);
      expect(withAge(1).isFresh, isFalse);
      expect(withAge(7).isFresh, isFalse);
    });

    test('gap and change helpers agree with the SMA pair', () {
      final signal = withAge(0);
      expect(signal.gapPct, closeTo((101 - 99) / 99 * 100, 1e-9));
      expect(signal.lastChangePct, closeTo((105 - 100) / 100 * 100, 1e-9));
      expect(signal.priceKey, 'NSE:X');
    });
  });
}
