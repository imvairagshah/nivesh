// ---------------------------------------------------------------------------
// cross_signal_card_test.dart — the Feature 2 card renders what the spec asks.
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/theme/app_theme.dart';
import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/features/golden_cross/cross_engine.dart';
import 'package:angel_trader/features/golden_cross/widgets/cross_signal_card.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

CrossSignal golden() => CrossSignal(
      direction: CrossDirection.golden,
      symbol: 'SBIN',
      brokerSymbol: 'SBIN-EQ',
      companyName: 'State Bank of India',
      exchange: Exchange.nse,
      token: '3045',
      crossDate: DateTime(2025, 9, 25),
      ageBars: 2,
      crossClose: 812.4,
      lastClose: 828.15,
      fast: 806.71,
      slow: 798.42,
      prevFast: 797.9,
      prevSlow: 798.6,
      barsUsed: 274,
      spark: [for (var i = 0; i < 60; i++) 700 + i * 2.1],
      sparkFast: [for (var i = 0; i < 60; i++) i < 10 ? null : 720 + i * 1.4],
      sparkSlow: [for (var i = 0; i < 60; i++) 760 + i * 0.5],
      sparkCrossIndex: 40,
    );

CrossSignal death() => CrossSignal(
      direction: CrossDirection.death,
      symbol: 'IDEA',
      brokerSymbol: 'IDEA-EQ',
      companyName: 'Vodafone Idea Ltd',
      exchange: Exchange.nse,
      token: '14366',
      crossDate: DateTime(2025, 9, 29),
      ageBars: 0,
      crossClose: 9.4,
      lastClose: 9.12,
      fast: 12.02,
      slow: 12.64,
      prevFast: 12.7,
      prevSlow: 12.68,
      barsUsed: 268,
      spark: [for (var i = 0; i < 60; i++) 14 - i * 0.08],
      sparkFast: [for (var i = 0; i < 60; i++) 13.4 - i * 0.02],
      sparkSlow: [for (var i = 0; i < 60; i++) 12.9 - i * 0.004],
      sparkCrossIndex: 12,
    );

Widget wrap(Widget child) => MaterialApp(
      theme: AppTheme.light(),
      home: Scaffold(body: SingleChildScrollView(child: child)),
    );

void main() {
  testWidgets('golden card shows symbol, name, both SMAs and the gap',
      (tester) async {
    await tester.pumpWidget(wrap(CrossSignalCard(signal: golden())));
    await tester.pumpAndSettle();

    expect(find.text('SBIN'), findsOneWidget);
    expect(find.text('State Bank of India'), findsOneWidget);
    expect(find.text('NSE'), findsOneWidget);
    expect(find.text('GOLDEN'), findsOneWidget);

    // SMA tiles.
    expect(find.text('SMA 50'), findsOneWidget);
    expect(find.text('SMA 200'), findsOneWidget);
    expect(find.text('806.71'), findsOneWidget);
    expect(find.text('798.42'), findsOneWidget);

    // Gap: (806.71 - 798.42) / 798.42 * 100 = +1.04%
    expect(find.text('+1.04%'), findsOneWidget);

    // Cross date + age wording, and the current price.
    expect(find.textContaining('25 Sep 2025'), findsOneWidget);
    expect(find.textContaining('Crossed 2 sessions earlier'), findsOneWidget);
    expect(find.textContaining('828.15'), findsOneWidget);
  });

  testWidgets('death card labels itself and never says GOLDEN', (tester) async {
    await tester.pumpWidget(wrap(CrossSignalCard(signal: death())));
    await tester.pumpAndSettle();

    expect(find.text('DEATH'), findsOneWidget);
    expect(find.text('GOLDEN'), findsNothing);
    expect(find.text('IDEA'), findsOneWidget);
    expect(find.text('Vodafone Idea Ltd'), findsOneWidget);

    // Gap is negative for a death cross.
    expect(find.textContaining('-'), findsWidgets);
    expect(find.textContaining('Crossed on this session'), findsOneWidget);
  });

  testWidgets('the Chart button fires the override', (tester) async {
    var tapped = 0;
    await tester.pumpWidget(
      wrap(CrossSignalCard(signal: golden(), onOpenChart: () => tapped++)),
    );
    await tester.pumpAndSettle();

    await tester.tap(find.widgetWithText(TextButton, 'Chart'));
    await tester.pump();

    expect(tapped, 1);
  });

  testWidgets('the card taps through to the detail sheet', (tester) async {
    var opened = 0;
    await tester.pumpWidget(
      wrap(CrossSignalCard(signal: golden(), onTap: () => opened++)),
    );
    await tester.pumpAndSettle();

    await tester.tap(find.text('State Bank of India'));
    await tester.pump();

    expect(opened, 1);
  });

  testWidgets('a signal without sparkline data still renders', (tester) async {
    final bare = CrossSignal(
      direction: CrossDirection.golden,
      symbol: 'NEWCO',
      brokerSymbol: 'NEWCO-EQ',
      companyName: '',
      exchange: Exchange.bse,
      token: '',
      crossDate: DateTime(2025, 9, 29),
      ageBars: 0,
      crossClose: 100,
      lastClose: 101,
      fast: 99.5,
      slow: 99.1,
      prevFast: 98.9,
      prevSlow: 99.15,
      barsUsed: 250,
    );

    await tester.pumpWidget(wrap(CrossSignalCard(signal: bare)));
    await tester.pumpAndSettle();

    expect(find.text('NEWCO'), findsOneWidget);
    expect(find.text('BSE'), findsOneWidget);
    // No company name → the card falls back to the price key.
    expect(find.text('BSE:NEWCO'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('renders in dark mode without throwing', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.dark(),
        home: Scaffold(body: CrossSignalCard(signal: death())),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('DEATH'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
