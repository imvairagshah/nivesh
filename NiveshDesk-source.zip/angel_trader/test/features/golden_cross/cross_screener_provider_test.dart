// ---------------------------------------------------------------------------
// cross_screener_provider_test.dart — the Feature 2 tab's state layer.
//
// Real SQLite, real settings, real DAOs and the real scanner; only the candle
// source is faked (it is the only thing that would touch the network). That
// makes these tests a decent stand-in for "open the tab on a fresh install and
// press scan".
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/candle_dao.dart';
import 'package:angel_trader/data/local/dao/ipo_dao.dart';
import 'package:angel_trader/data/local/dao/scan_cache_dao.dart';
import 'package:angel_trader/data/local/dao/scrip_dao.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/data/local/models/ipo.dart';
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/features/golden_cross/cross_engine.dart';
import 'package:angel_trader/features/golden_cross/cross_screener_provider.dart';
import 'package:angel_trader/services/universe_catalog.dart';
import 'package:angel_trader/features/settings/settings_provider.dart';
import 'package:angel_trader/services/auth_service.dart';
import 'package:angel_trader/services/candle_source.dart';
import 'package:angel_trader/services/cross_scan_service.dart';
import 'package:angel_trader/services/scrip_master_service.dart';
import 'package:angel_trader/services/secure_store.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

class FakeSource implements CandleSource {
  FakeSource(this.barsByToken);

  final Map<String, List<Candle>> barsByToken;
  int calls = 0;

  @override
  Future<List<Candle>> fetchDailyCandles({
    required Scrip scrip,
    required DateTime from,
    required DateTime to,
    String interval = 'ONE_DAY',
  }) async {
    calls++;
    return barsByToken[scrip.token] ?? const [];
  }
}

List<double> ramp(int count, double from, double to) => [
      for (var i = 0; i < count; i++)
        count == 1 ? from : from + (to - from) * (i / (count - 1)),
    ];

List<Candle> series(List<double> closes, {DateTime? start}) {
  final bars = <Candle>[];
  var day = start ?? DateTime(2023, 1, 2);
  for (final close in closes) {
    bars.add(Candle(
      time: day,
      open: close,
      high: close * 1.01,
      low: close * 0.99,
      close: close,
      volume: 500,
    ));
    day = day.add(const Duration(days: 1));
  }
  return bars;
}

/// Lengths of the two verified shapes once they are cut at their cross bar.
const int goldenCrossIndex = 280; // 281 bars, cross on the last one
const int deathCrossIndex = 285; // 286 bars, cross on the last one

/// Session the fixtures end on when [end] is not given (a Monday).
final DateTime fixtureEnd = DateTime(2025, 9, 29);

/// A series ending on [end] with a fresh golden cross on its last bar.
/// (Shape verified in cross_engine_test.dart / tool/probe_cross.dart.)
List<Candle> freshGolden({DateTime? end}) => series(
      [...ramp(220, 300, 100), ...ramp(120, 100, 300)].sublist(0, goldenCrossIndex + 1),
      start: (end ?? fixtureEnd).subtract(const Duration(days: goldenCrossIndex)),
    );

/// A series ending on [end] with a fresh death cross on its last bar.
List<Candle> freshDeath({DateTime? end}) => series(
      [...ramp(220, 100, 320), ...ramp(140, 320, 110)].sublist(0, deathCrossIndex + 1),
      start: (end ?? fixtureEnd).subtract(const Duration(days: deathCrossIndex)),
    );

Scrip nse(String symbol, String token, {String? name}) => Scrip(
      token: token,
      symbol: '$symbol-EQ',
      name: name ?? '$symbol Ltd',
      exchange: Exchange.nse,
    );

void main() {
  late IpoDao ipos;
  late ScripDao scrips;
  late SettingsDao settingsDao;
  late CandleDao candles;
  late ScanCacheDao cache;
  late SettingsProvider settings;
  late ScripMasterService master;

  setUpAll(() {
    TestWidgetsFlutterBinding.ensureInitialized();
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close();
    final db = AppDatabase.instance;
    ipos = IpoDao(db);
    scrips = ScripDao(db);
    settingsDao = SettingsDao(db);
    candles = CandleDao(db);
    cache = ScanCacheDao(db);

    settings = SettingsProvider(settingsDao);
    await settings.load();

    master = ScripMasterService(scripDao: scrips, settingsDao: settingsDao);
  });

  tearDown(() async {
    await AppDatabase.instance.close();
  });

  CrossScreenerProvider buildProvider({
    FakeSource? source,
    DateTime? now,
  }) {
    final scan = CrossScanService(
      source: source ?? FakeSource(const {}),
      candles: candles,
      cache: cache,
    );
    return CrossScreenerProvider(
      scan: scan,
      scripDao: scrips,
      ipoDao: ipos,
      settings: settings,
      auth: AuthService(store: SecureStore()),
      scripMaster: master,
      clock: () => now ?? DateTime(2025, 9, 29, 12), // a Monday, mid-session
    );
  }

  Future<void> seedScrips() async {
    await scrips.replaceAll([
      nse('RELIANCE', '2885'),
      nse('SBIN', '3045'),
      nse('INFY', '1594'),
      const Scrip(
        token: '500325',
        symbol: 'RELIANCE',
        name: 'Reliance Industries',
        exchange: Exchange.bse,
      ),
    ]);
  }

  // -------------------------------------------------------------------------
  group('bootstrap', () {
    test('starts empty when nothing is cached, then announces it', () async {
      await seedScrips();
      final provider = buildProvider();

      expect(provider.isLoadingCache, isTrue);
      await provider.bootstrap();

      expect(provider.isLoadingCache, isFalse);
      expect(provider.result, isNull);
      expect(provider.hasResult, isFalse);
      expect(provider.universe.size, greaterThan(0));
      expect(provider.error, isNull);
      provider.dispose();
    });

    test('picks up a cached scan without any network call', () async {
      await seedScrips();
      final source = FakeSource({'3045': freshGolden()});
      final provider = buildProvider(source: source);

      await provider.bootstrap();
      await provider.run(asOf: fixtureEnd);
      final callsAfterScan = source.calls;
      provider.dispose();

      // A brand-new provider (fresh app launch) sees the cached run.
      final reopened = buildProvider(source: source);
      await reopened.bootstrap();

      expect(reopened.hasResult, isTrue);
      expect(reopened.result!.fromCacheOnly, isTrue);
      expect(reopened.goldenCount, 1);
      expect(source.calls, callsAfterScan, reason: 'no refetch on reopen');
      reopened.dispose();
    });
  });

  // -------------------------------------------------------------------------
  group('universes', () {
    test('nifty50 resolves the names it can see and reports the rest', () async {
      await seedScrips();
      final provider = buildProvider();
      await provider.resolveUniverse();

      expect(provider.universe.universe.key, UniverseCatalog.nifty50);
      expect(provider.universe.size, 3); // RELIANCE, SBIN, INFY
      expect(
        provider.universe.missing.length,
        UniverseCatalog.nifty50Symbols.length - 3,
      );
      expect(provider.universe.missing, contains('ITC'));
      expect(provider.universe.label, contains('3 of 50 resolved'));
      provider.dispose();
    });

    test('master universes follow the exchange filter', () async {
      await seedScrips();
      final provider = buildProvider();

      await provider.setUniverse(UniverseCatalog.masterNse);
      expect(provider.universe.size, 3); // NSE only

      await provider.setUniverse(UniverseCatalog.masterAll);
      expect(provider.universe.size, 4); // NSE + BSE

      // The choice is persisted for the next launch.
      expect(settings.settings.goldenCrossUniverse, UniverseCatalog.masterAll);
      provider.dispose();
    });

    test('the IPO universe uses the IPO table and flags unknown tickers',
        () async {
      await seedScrips();
      await ipos.insert(Ipo(
        symbol: 'RELIANCE',
        companyName: 'Reliance Industries Ltd',
        exchange: Exchange.nse,
        listingDate: DateTime(2002, 11, 29),
        listingHigh: 300,
        listingLow: 260,
      ));
      await ipos.insert(Ipo(
        symbol: 'NOTLISTED',
        companyName: 'Ghost Ltd',
        exchange: Exchange.nse,
        listingDate: DateTime(2024, 5, 1),
        listingHigh: 100,
        listingLow: 90,
      ));

      final provider = buildProvider();
      await provider.setUniverse(UniverseCatalog.ipos);

      expect(provider.universe.size, 1);
      expect(provider.universe.missing, ['NOTLISTED']);
      provider.dispose();
    });

    test('an empty universe stops the scan with an explanation', () async {
      // No scrips seeded at all.
      final provider = buildProvider();
      await provider.run();

      expect(provider.error, isNotNull);
      expect(provider.error, contains('No instruments resolved'));
      expect(provider.result, isNull);
      provider.dispose();
    });
  });

  // -------------------------------------------------------------------------
  group('scanning and filters', () {
    Future<CrossScreenerProvider> scannedProvider() async {
      await seedScrips();
      final source = FakeSource({
        '3045': freshGolden(), // SBIN
        '1594': freshDeath(), // INFY
      });
      final provider = buildProvider(source: source);
      await settings.setDeathCrossEnabled(true);
      await provider.bootstrap();
      await provider.run(asOf: fixtureEnd);
      return provider;
    }

    test('run() fills the result, progress is cleared and no error is set',
        () async {
      final provider = await scannedProvider();

      expect(provider.error, isNull);
      expect(provider.isScanning, isFalse);
      expect(provider.progress, isNull);
      expect(provider.hasResult, isTrue);
      expect(provider.goldenCount, 1);
      expect(provider.deathCount, 1);
      expect(provider.freshCount, 2);
      expect(provider.visibleSignals.length, 2);
      provider.dispose();
    });

    test('golden, death and fresh filters narrow the list', () async {
      final provider = await scannedProvider();

      provider.setFilter(CrossFilter.golden);
      expect(provider.visibleSignals.map((s) => s.symbol), ['SBIN']);

      provider.setFilter(CrossFilter.death);
      expect(provider.visibleSignals.map((s) => s.symbol), ['INFY']);
      expect(provider.visibleSignals.single.direction, CrossDirection.death);

      provider.setFilter(CrossFilter.fresh);
      expect(provider.visibleSignals.length, 2);

      provider.setFilter(CrossFilter.all);
      expect(provider.visibleSignals.length, 2);
      provider.dispose();
    });

    test('search matches symbol and company name', () async {
      final provider = await scannedProvider();

      provider.setQuery('sbi');
      expect(provider.visibleSignals.map((s) => s.symbol), ['SBIN']);

      // The seeded company name is "INFY Ltd", so the full legal name of the
      // real company is *not* a match — search is a plain substring test.
      provider.setQuery('INFOSYS');
      expect(provider.visibleSignals, isEmpty);

      provider.setQuery('infy ltd');
      expect(provider.visibleSignals.map((s) => s.symbol), ['INFY']);

      provider.setQuery('nothing');
      expect(provider.visibleSignals, isEmpty);

      provider.clearFilters();
      expect(provider.query, isEmpty);
      expect(provider.filter, CrossFilter.all);
      expect(provider.visibleSignals.length, 2);
      provider.dispose();
    });

    test('the death-cross setting gates death signals', () async {
      await seedScrips();
      final source = FakeSource({
        '3045': freshGolden(),
        '1594': freshDeath(),
      });
      final provider = buildProvider(source: source);
      await provider.bootstrap();

      // Settings default: death screening off.
      expect(provider.includeDeath, isFalse);
      await provider.run(asOf: fixtureEnd);

      expect(provider.goldenCount, 1);
      expect(provider.deathCount, 0);
      provider.dispose();
    });

    test('the age window is user-selectable', () async {
      final provider = await scannedProvider();

      expect(provider.window.bars, CrossAgeWindow.defaultWindow.bars);
      provider.setWindow(const CrossAgeWindow(10, 'Last 10 sessions'));
      expect(provider.window.bars, 10);
      expect(CrossAgeWindow.choices.map((c) => c.bars), contains(0));
      provider.dispose();
    });

    test('clearing the cache empties the tab but keeps the candles', () async {
      final provider = await scannedProvider();
      expect(provider.hasResult, isTrue);

      await provider.clearScanCache();

      expect(provider.result, isNull);
      expect(await candles.barCount(exchange: 'NSE', symbol: 'SBIN-EQ'),
          greaterThan(0));
      provider.dispose();
    });

    test('a scan for the current session is not marked stale', () async {
      final provider = await scannedProvider();
      // The series ends in 2023 (recorded as stale), so force the view date to
      // today and confirm the staleness flag follows the data, not the clock.
      expect(provider.isStale, isTrue);
      await provider.setViewDate(MarketCalendar.nowIst());
      await provider.run(asOf: MarketCalendar.latestTradingDay());
      expect(provider.isStale, isFalse);
      provider.dispose();
    });
  });

  // -------------------------------------------------------------------------
  group('daily 6 PM job', () {
    // The window itself (Mon-Fri, after 18:00 IST) is covered by
    // test/core/markets_test.dart; here we only check the provider's guard.
    test('does nothing outside the window', () async {
      await seedScrips();
      final source = FakeSource({'3045': freshGolden()});
      final provider = buildProvider(
        source: source,
        now: DateTime(2025, 9, 29, 14), // 14:00 UTC = 19:30 IST → in window
      );
      await provider.bootstrap();

      final ran = await provider.maybeRunDailyJob();
      // Not logged in, so the job must refuse to burn API calls — the cached
      // tab state is untouched either way.
      expect(ran, isNull);
      expect(source.calls, 0);
      provider.dispose();
    });

    test('never scans twice for the same session in one app launch', () async {
      await seedScrips();
      final provider = buildProvider();
      await provider.bootstrap();

      expect(await provider.maybeRunDailyJob(), isNull);
      expect(await provider.maybeRunDailyJob(), isNull);
      provider.dispose();
    });
  });
}
