// ---------------------------------------------------------------------------
// rsi_engine_test.dart — the RSI maths, checked against outside ground truth.
//
// The important test here is the first one: those numbers do not come from this
// implementation. They are computed from the *classic* Wilder/Welles dataset
// (the 33 closes used in every RSI write-up) with a separate, hand-checked
// calculation:
//
//     gains  over the first 14 changes = 3.34  → avgGain = 0.238571
//     losses over the first 14 changes = 1.40  → avgLoss = 0.100000
//     RS = 2.385714 → RSI = 100 − 100/(1+RS) = 70.46
//
// If a refactor ever changes the smoothing to a simple moving average, this
// test fails immediately — which is the point: a scanner that is *almost* right
// about RSI is worse than no scanner.
//
// The remaining tests use a deterministic wave so that "overbought", "oversold"
// and "crossed today" can be asserted with exact values taken from the same
// independent calculation (see the note above each expected number).
// ---------------------------------------------------------------------------

import 'dart:math' as math;

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/features/rsi_scanner/rsi_engine.dart';
import 'package:flutter_test/flutter_test.dart';

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

/// The classic published RSI dataset (33 closes).
const List<double> kClassicCloses = [
  44.34, 44.09, 44.15, 43.61, 44.33, 44.83, 45.10, 45.42, 45.84, 46.08,
  45.89, 46.03, 45.61, 46.28, 46.28, 46.00, 46.03, 46.41, 46.22, 45.64,
  46.21, 46.25, 45.71, 46.45, 45.78, 45.35, 44.03, 44.18, 44.22, 44.57,
  43.42, 42.66, 43.13,
];

List<Candle> seriesFrom(List<double> closes, {DateTime? start}) {
  final bars = <Candle>[];
  var day = start ?? DateTime(2024, 1, 1);
  for (final close in closes) {
    bars.add(Candle(
      time: day,
      open: close,
      high: close * 1.01,
      low: close * 0.99,
      close: close,
      volume: 1000,
    ));
    day = day.add(const Duration(days: 1));
  }
  return bars;
}

/// Deterministic oscillation with a trend. `sign: -1` mirrors it into a
/// downtrend. Verified outside this codebase: the RSI values quoted in the
/// tests below were produced by an independent implementation of Wilder's
/// smoothing over exactly this series.
List<Candle> wave(
  int count, {
  double base = 100,
  double sign = 1,
  DateTime? start,
}) =>
    seriesFrom([
      for (var i = 0; i < count; i++)
        base + sign * (6 * math.sin(i / 4.2)) + sign * 0.25 * i,
    ], start: start);

Scrip scrip(String symbol, {String token = '1'}) => Scrip(
      token: token,
      symbol: '$symbol-EQ',
      name: '$symbol Limited',
      exchange: Exchange.nse,
    );

const thresholds = RsiThresholds(); // period 14, 67 / 33

void main() {
  group('Wilder smoothing — outside ground truth', () {
    test('matches the classic published dataset', () {
      final s = wilderRsiSeries(seriesFrom(kClassicCloses), period: 14);

      // 33 closes → 32 changes → 32 − 14 + 1 = 19 RSI values.
      expect(s.values, hasLength(19));
      expect(s.firstIndex, 14);

      // Hand-checked: 70.46, 66.25, 66.48 (see the file header for the maths).
      expect(s.values[0], closeTo(70.46, 0.01));
      expect(s.values[1], closeTo(66.25, 0.01));
      expect(s.values[2], closeTo(66.48, 0.01));

      // The series' last value was computed independently as 37.79.
      expect(s.latest, closeTo(37.79, 0.01));
    });

    test('a window with no losses pins RSI at 100', () {
      final s = wilderRsiSeries(
        seriesFrom([for (var i = 0; i < 30; i++) 100 + i.toDouble()]),
      );
      expect(s.latest, 100);
    });

    test('a window with no gains pins RSI at 0', () {
      final s = wilderRsiSeries(
        seriesFrom([for (var i = 0; i < 30; i++) 100 - i.toDouble()]),
      );
      expect(s.latest, 0);
    });

    test('a dead-flat window is neutral (50), not 100', () {
      final s = wilderRsiSeries(seriesFrom([for (var i = 0; i < 30; i++) 100]));
      expect(s.latest, 50);
    });

    test('too few bars produce no value at all', () {
      expect(wilderRsiSeries(seriesFrom([1, 2, 3, 4])).isEmpty, isTrue);
      // period + 1 bars is the absolute minimum for a single value.
      expect(wilderRsiSeries(seriesFrom([for (var i = 0; i < 15; i++) 100 + i.toDouble()])).values,
          hasLength(1));
    });
  });

  group('thresholds', () {
    test('defaults follow the brief: 14 · 67 / 33', () {
      expect(thresholds.period, 14);
      expect(thresholds.upper, 67);
      expect(thresholds.lower, 33);
      expect(thresholds.minimumBars, 56);
      expect(thresholds.label, 'RSI(14) · 67 / 33');
    });

    test('the boundaries are strict: 67 is not overbought, 33 is not oversold',
        () {
      expect(thresholds.zoneFor(67.0), RsiZone.neutral);
      expect(thresholds.zoneFor(67.01), RsiZone.overbought);
      expect(thresholds.zoneFor(33.0), RsiZone.neutral);
      expect(thresholds.zoneFor(32.99), RsiZone.oversold);
    });

    test('sanitised() repairs an impossible pair instead of throwing', () {
      const broken = RsiThresholds(period: 0, upper: 20, lower: 80);
      final fixed = broken.sanitised();
      expect(fixed.period, 2);
      expect(fixed.upper, 67);
      expect(fixed.lower, 33);
      expect(fixed.isValid, isTrue);

      expect(const RsiThresholds(period: 500).sanitised().period, 200);
      expect(const RsiThresholds(upper: 67, lower: 33).isValid, isTrue);
    });

    test('minimumBars scales with the period', () {
      expect(const RsiThresholds(period: 9).minimumBars, 36);
      expect(const RsiThresholds(period: 21).minimumBars, 84);
    });
  });

  group('readings', () {
    test('a steady climb lands in overbought', () {
      // Independently computed: last 75.58, previous 72.58.
      final reading = rsiReadingFor(
        scrip: scrip('STRONG'),
        candles: wave(82),
        thresholds: thresholds,
      );

      expect(reading, isNotNull);
      expect(reading!.rsi, closeTo(75.58, 0.02));
      expect(reading.prevRsi, closeTo(72.58, 0.02));
      expect(reading.zoneIn(thresholds), RsiZone.overbought);
      expect(reading.crossedAbove(67), isFalse,
          reason: 'it was already overbought yesterday');
      expect(reading.zoneAge, greaterThan(1));
      expect(reading.symbol, 'STRONG', reason: 'the -EQ suffix is stripped');
      expect(reading.brokerSymbol, 'STRONG-EQ');
      expect(reading.companyName, 'STRONG Limited');
    });

    test('a fresh cross above 67 is flagged', () {
      // Independently computed: last 68.89 (> 67), previous 64.48 (≤ 67).
      final reading = rsiReadingFor(
        scrip: scrip('CROSSED'),
        candles: wave(80),
        thresholds: thresholds,
      )!;

      expect(reading.rsi, closeTo(68.89, 0.02));
      expect(reading.prevRsi, closeTo(64.48, 0.02));
      expect(reading.zoneIn(thresholds), RsiZone.overbought);
      expect(reading.crossedAbove(67), isTrue, reason: 'aaj 67 ke upar aaya');
      expect(reading.isFreshIn(thresholds), isTrue);
      expect(reading.zoneAge, 1);
    });

    test('a fresh cross below 33 is flagged', () {
      // Independently computed on the mirrored wave: last 31.11, previous 35.52.
      final reading = rsiReadingFor(
        scrip: scrip('WEAK'),
        candles: wave(80, base: 200, sign: -1),
        thresholds: thresholds,
      )!;

      expect(reading.rsi, closeTo(31.11, 0.02));
      expect(reading.prevRsi, closeTo(35.52, 0.02));
      expect(reading.zoneIn(thresholds), RsiZone.oversold);
      expect(reading.crossedBelow(33), isTrue);
      expect(reading.isFreshIn(thresholds), isTrue);
    });

    test('an established downtrend is oversold but not fresh', () {
      // Independently computed: last 25.74, previous 21.11 — both far below 33.
      final reading = rsiReadingFor(
        scrip: scrip('FALLING'),
        candles: wave(64, base: 200, sign: -1),
        thresholds: thresholds,
      )!;

      expect(reading.rsi, closeTo(25.74, 0.02));
      expect(reading.zoneIn(thresholds), RsiZone.oversold);
      expect(reading.crossedBelow(33), isFalse);
      expect(reading.isFreshIn(thresholds), isFalse);
      expect(reading.zoneAge, greaterThan(1));
    });

    test('price and day change come from the candles actually used', () {
      final bars = wave(80);
      final reading = rsiReadingFor(
        scrip: scrip('PRICE'),
        candles: bars,
        thresholds: thresholds,
      )!;

      expect(reading.price, closeTo(bars.last.close, 0.0001));
      expect(reading.prevClose, closeTo(bars[bars.length - 2].close, 0.0001));
      expect(reading.changePct,
          closeTo((bars.last.close - bars[bars.length - 2].close) /
                  bars[bars.length - 2].close *
                  100,
              0.001));
      expect(reading.barDate, bars.last.istDate);
      expect(reading.bars, 80);
    });

    test('short history yields no reading (the scanner skips it)', () {
      expect(
        rsiReadingFor(
          scrip: scrip('NEW'),
          candles: wave(40),
          thresholds: thresholds,
        ),
        isNull,
        reason: '40 bars < 56 (period × 4)',
      );
    });

    test('asOf ignores bars after that session', () {
      final bars = wave(83);
      final cutoff = bars[79].istDate; // last bar of the 80-bar wave

      final reading = rsiReadingFor(
        scrip: scrip('ASOF'),
        candles: bars,
        thresholds: thresholds,
        asOf: cutoff,
      )!;

      // Same value as scanning the 80-bar series directly.
      expect(reading.rsi, closeTo(68.89, 0.02));
      expect(reading.barDate, cutoff);
      expect(reading.bars, 80);
    });

    test('a different period changes the answer (as it must)', () {
      // 90 bars so both period 9 (36 min) and 21 (84 min) have enough history.
      final bars = wave(90);
      final r14 = rsiReadingFor(
        scrip: scrip('P14'),
        candles: bars,
        thresholds: const RsiThresholds(period: 14),
      )!;
      final r21 = rsiReadingFor(
        scrip: scrip('P21'),
        candles: bars,
        thresholds: const RsiThresholds(period: 21),
      )!;
      expect(r14.rsi, isNot(closeTo(r21.rsi, 0.5)));
    });
  });

  group('sorting', () {
    RsiReading reading(String symbol, double rsi, {double? prev}) => RsiReading(
          symbol: symbol,
          companyName: '$symbol Ltd',
          exchange: Exchange.nse,
          brokerSymbol: '$symbol-EQ',
          token: '1',
          price: 100,
          prevClose: 100,
          rsi: rsi,
          prevRsi: prev,
          barDate: DateTime(2026, 1, 6),
          bars: 80,
        );

    test('overbought sorts strongest first', () {
      final rows = [
        reading('AAA', 70),
        reading('BBB', 82),
        reading('CCC', 75),
      ]..sort((a, b) => compareReadings(a, b, RsiZone.overbought, thresholds));
      expect([for (final r in rows) r.symbol], ['BBB', 'CCC', 'AAA']);
    });

    test('oversold sorts deepest first', () {
      final rows = [
        reading('AAA', 30),
        reading('BBB', 12),
        reading('CCC', 20),
      ]..sort((a, b) => compareReadings(a, b, RsiZone.oversold, thresholds));
      expect([for (final r in rows) r.symbol], ['BBB', 'CCC', 'AAA']);
    });

    test('a fresh cross outranks a stale one with the same RSI', () {
      final rows = [
        reading('OLD', 70, prev: 69), // already overbought yesterday
        reading('NEW', 70, prev: 60), // crossed today
      ]..sort((a, b) => compareReadings(a, b, RsiZone.overbought, thresholds));
      expect([for (final r in rows) r.symbol], ['NEW', 'OLD']);
    });
  });

  group('cache round-trip', () {
    test('toRow / fromRow keeps every column the table shows', () {
      final original = rsiReadingFor(
        scrip: scrip('ROUND'),
        candles: wave(82),
        thresholds: thresholds,
      )!;

      final restored = RsiReading.fromRow(original.toRow());

      expect(restored.symbol, original.symbol);
      expect(restored.companyName, original.companyName);
      expect(restored.exchange.code, original.exchange.code);
      expect(restored.brokerSymbol, original.brokerSymbol);
      expect(restored.token, original.token);
      expect(restored.price, closeTo(original.price, 0.0001));
      expect(restored.prevClose, closeTo(original.prevClose, 0.0001));
      expect(restored.rsi, closeTo(original.rsi, 0.0001));
      expect(restored.prevRsi, closeTo(original.prevRsi!, 0.0001));
      expect(restored.zoneAge, original.zoneAge);
      expect(restored.barDate, original.barDate);
      expect(restored.bars, original.bars);
    });
  });
}
