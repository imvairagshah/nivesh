// ---------------------------------------------------------------------------
// rsi_screener_provider_test.dart — tab-level behaviour of the RSI scanner.
//
// The maths and the scan loop are covered by their own suites; this file checks
// the things a *user* touches:
//
//   • the tab boots with the cached table and resolves the F&O universe,
//   • switching between the two tables never re-scans,
//   • editing the thresholds re-labels the existing rows immediately (and
//     persists the new values),
//   • a universe with nothing resolvable reports a readable error instead of
//     silently scanning zero instruments.
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/candle_dao.dart';
import 'package:angel_trader/data/local/dao/ipo_dao.dart';
import 'package:angel_trader/data/local/dao/scan_cache_dao.dart';
import 'package:angel_trader/data/local/dao/scrip_dao.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/features/rsi_scanner/rsi_engine.dart';
import 'package:angel_trader/features/rsi_scanner/rsi_screener_provider.dart';
import 'package:angel_trader/features/settings/settings_provider.dart';
import 'package:angel_trader/services/cross_scan_service.dart' show ScanUniverse;
import 'package:angel_trader/services/fno_universe.dart';
import 'package:angel_trader/services/rsi_scan_service.dart';
import 'package:angel_trader/services/scrip_master_service.dart';
import 'package:angel_trader/services/universe_catalog.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import '../../services/rsi_scan_service_test.dart'
    show FakeCandleSource, wave;

Scrip nse(String symbol, String token) => Scrip(
      token: token,
      symbol: '$symbol-EQ',
      name: '$symbol Limited',
      exchange: Exchange.nse,
    );

void main() {
  late IpoDao ipos;
  late ScripDao scrips;
  late SettingsDao settingsDao;
  late CandleDao candles;
  late ScanCacheDao cache;
  late SettingsProvider settings;
  late ScripMasterService master;

  setUpAll(() {
    TestWidgetsFlutterBinding.ensureInitialized();
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close();
    final db = AppDatabase.instance;
    ipos = IpoDao(db);
    scrips = ScripDao(db);
    settingsDao = SettingsDao(db);
    candles = CandleDao(db);
    cache = ScanCacheDao(db);

    settings = SettingsProvider(settingsDao);
    await settings.load();

    master = ScripMasterService(scripDao: scrips, settingsDao: settingsDao);
  });

  tearDown(() async {
    await AppDatabase.instance.close();
  });

  /// The F&O list is injected so the test never depends on the asset bundle.
  FnoUniverse fnoFixture() => const FnoUniverse(
        symbols: ['RELIANCE', 'SBIN', 'INFY'],
        companyNames: {
          'RELIANCE': 'Reliance Industries',
          'SBIN': 'State Bank of India',
          'INFY': 'Infosys',
        },
      );

  RsiScreenerProvider build({
    FakeCandleSource? source,
    FnoUniverse? fno,
  }) =>
      RsiScreenerProvider(
        scan: RsiScanService(
          source: source ?? FakeCandleSource(const {}),
          candles: candles,
          cache: cache,
        ),
        settings: settings,
        scripDao: scrips,
        ipoDao: ipos,
        scripMaster: master,
        fnoUniverse: fno ?? fnoFixture(),
      );

  Future<void> seedScrips() async {
    await scrips.replaceAll([
      nse('RELIANCE', '2885'),
      nse('SBIN', '3045'),
      nse('INFY', '1594'),
    ]);
  }

  group('defaults', () {
    test('the brief is the default: F&O universe, RSI 14 · 67 / 33', () {
      expect(settings.settings.rsiUniverse, UniverseCatalog.fno);
      expect(settings.settings.rsiPeriod, 14);
      expect(settings.settings.rsiUpper, 67);
      expect(settings.settings.rsiLower, 33);
    });

    test('the F&O universe is the first entry in the picker', () {
      expect(UniverseCatalog.all.first.key, UniverseCatalog.fno);
      expect(UniverseCatalog.byKey('fno').label, 'F&O stocks');
      // An unknown/legacy key still lands on Nifty 50, not on F&O.
      expect(UniverseCatalog.byKey('something-else').key, UniverseCatalog.nifty50);
    });
  });

  group('bootstrap', () {
    test('resolves the F&O universe against the local master', () async {
      await seedScrips();
      final provider = build();

      await provider.bootstrap();

      expect(provider.universe.size, 3);
      expect(provider.universeLabel, contains('F&O'));
      expect(provider.universe.hasMissing, isFalse);
      expect(provider.hasResult, isFalse, reason: 'nothing cached yet');
      expect(provider.statusLine, contains('Scan now'));
    });

    test('unresolvable F&O names are reported, not dropped quietly', () async {
      await seedScrips(); // master has no IDEA
      final provider = build(
        fno: const FnoUniverse(
          symbols: ['RELIANCE', 'IDEA'],
          companyNames: {},
        ),
      );

      await provider.bootstrap();

      expect(provider.universe.size, 1);
      expect(provider.universe.missing, contains('IDEA'));
      expect(provider.universe.label, contains('1 of 2 resolved'));
    });
  });

  group('scanning', () {
    test('a scan fills both tables and reports the counts', () async {
      await seedScrips();
      final source = FakeCandleSource({
        '2885': wave(82), // RSI 75.58 → overbought
        '3045': wave(80, base: 200, sign: -1), // RSI 31.11 → oversold
        '1594': wave(72), // neutral
      });
      final provider = build(source: source);

      await provider.bootstrap();
      await provider.run();

      expect(provider.overboughtCount, 1);
      expect(provider.oversoldCount, 1);
      expect(provider.freshCount, 1, reason: 'only the oversold one crossed');
      expect(provider.zone, RsiZone.overbought);
      expect(provider.rows.single.symbol, 'RELIANCE');

      // Switching tables is free — the rows are already in memory.
      await provider.setZone(RsiZone.oversold);
      expect(provider.rows.single.symbol, 'SBIN');
      expect(source.callCount, 3, reason: 'no second round of downloads');
    });

    test('an empty side falls back to the side that has rows', () async {
      await seedScrips();
      final source = FakeCandleSource({
        '2885': wave(80, base: 200, sign: -1), // oversold only
        '3045': wave(72),
        '1594': wave(72),
      });
      final provider = build(source: source);

      await provider.bootstrap();
      await provider.run();

      expect(provider.overboughtCount, 0);
      expect(provider.rows, isNotEmpty);
      expect(provider.zone, RsiZone.oversold,
          reason: 'an empty table with hits on the other side is confusing');
    });

    test('an unresolvable universe gives an actionable error', () async {
      await seedScrips();
      final provider = build(
        fno: const FnoUniverse(symbols: ['GHOSTCO'], companyNames: {}),
      );

      await provider.bootstrap();
      await provider.run();

      expect(provider.error, isNotNull);
      expect(provider.error, contains('resolve'));
      expect(provider.hasResult, isFalse);
    });
  });

  group('thresholds', () {
    test('editing the levels re-labels the cached rows and persists',
        () async {
      await seedScrips();
      final provider = build(source: FakeCandleSource({'2885': wave(82)}));

      await provider.bootstrap();
      await provider.run();
      expect(provider.overboughtCount, 1); // RSI 75.58 > 67

      // Tighten to 80 → the row no longer qualifies.
      await provider.setThresholds(const RsiThresholds(upper: 80, lower: 20));

      expect(provider.overboughtCount, 0);
      expect(provider.thresholds.upper, 80);
      expect(settings.settings.rsiUpper, 80, reason: 'persisted');

      // …and loosening it again brings the row back, without a rescan.
      await provider.setThresholds(const RsiThresholds(upper: 70, lower: 30));
      expect(provider.overboughtCount, 1);
      expect(provider.hasResult, isTrue);
    });

    test('an impossible pair is repaired before it is stored', () async {
      final provider = build();
      await provider.setThresholds(const RsiThresholds(upper: 20, lower: 80));

      expect(settings.settings.rsiUpper, 67);
      expect(settings.settings.rsiLower, 33);
    });

    test('a different period is stored as given', () async {
      final provider = build();
      await provider.setThresholds(const RsiThresholds(period: 21));

      expect(settings.settings.rsiPeriod, 21);
      expect(provider.thresholds.period, 21);
      expect(provider.thresholds.minimumBars, 84);
    });
  });

  group('universe switching', () {
    test('switching to all NSE equities resolves from the master', () async {
      await seedScrips();
      final provider = build();
      await provider.bootstrap();

      await provider.setUniverse(UniverseCatalog.masterNse);

      expect(settings.settings.rsiUniverse, UniverseCatalog.masterNse);
      expect(provider.universe.size, 3, reason: 'three NSE rows seeded');
      expect(provider.universe.universe.label, 'All NSE equities');
    });

    test('the picker hint for F&O comes from the injected list', () async {
      await seedScrips();
      final provider = build();
      await provider.bootstrap();

      final hints = await provider.universeSizeHints();
      expect(hints[UniverseCatalog.fno], 3);
      expect(hints[UniverseCatalog.nifty50], 50);
    });

    test('ScanUniverse metadata matches the catalog', () {
      final fno = UniverseCatalog.byKey('fno');
      expect(fno, isA<ScanUniverse>());
      expect(fno.dynamic, isFalse, reason: 'fixed list, resolved locally');
    });
  });
}
