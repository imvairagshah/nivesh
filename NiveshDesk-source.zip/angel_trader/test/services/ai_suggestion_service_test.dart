// ---------------------------------------------------------------------------
// ai_suggestion_service_test.dart — the AI Suggestion scan, end to end.
//
// Real SQLite (sqflite FFI), real candle cache, real contract book, real
// Black-Scholes; only the network is faked. What these tests hold the service
// to:
//
//   1. the list is ranked and cut to the Top N the user asked for,
//   2. the user's thresholds actually decide who is on the list (raise the bar
//      and rows disappear — the brief's "dynamic filter" requirement),
//   3. a stock whose data is missing is skipped **with a reason**, never scored
//      on partial numbers,
//   4. the option side is quoted once, in a batch, for the shortlist only —
//      not once per stock in the universe,
//   5. a dead quote endpoint costs the premiums, not the ideas.
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/candle_dao.dart';
import 'package:angel_trader/data/local/dao/fno_contract_dao.dart';
import 'package:angel_trader/data/remote/api_client.dart';
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/data/remote/dto/quote.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/features/fno/ai/ai_suggestion.dart';
import 'package:angel_trader/services/ai_suggestion_service.dart';
import 'package:angel_trader/services/earnings_calendar_service.dart'
    show EarningsInfo;
import 'package:angel_trader/services/candle_source.dart';
import 'package:angel_trader/services/study_market_data.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

// ---------------------------------------------------------------------------
// Fakes
// ---------------------------------------------------------------------------

class FakeCandleSource implements CandleSource {
  FakeCandleSource(this.barsByToken, {this.failTokens = const {}});

  final Map<String, List<Candle>> barsByToken;

  /// Tokens whose request blows up (broker error, not "no data").
  final Set<String> failTokens;

  @override
  Future<List<Candle>> fetchDailyCandles({
    required Scrip scrip,
    required DateTime from,
    required DateTime to,
    String interval = 'ONE_DAY',
  }) async {
    if (failTokens.contains(scrip.token)) {
      throw const ApiException(message: 'candle endpoint down');
    }
    return barsByToken[scrip.token] ?? const [];
  }
}

class FakeMarket implements StudyMarketData {
  FakeMarket({this.quotes = const {}, this.failQuotes = false});

  /// token → full quote.
  final Map<String, MarketQuote> quotes;
  final bool failQuotes;

  final List<List<String>> quoteCalls = [];
  final List<String> greekCalls = [];

  @override
  Future<Map<String, MarketQuote>> fetchQuotesFull(List<Scrip> scrips) async {
    quoteCalls.add(scrips.map((s) => s.token).toList());
    if (failQuotes) throw const ApiException(message: 'quote endpoint down');
    return {
      for (final scrip in scrips)
        if (quotes.containsKey(scrip.token)) scrip.token: quotes[scrip.token]!,
    };
  }

  @override
  Future<OptionGreekBatch> fetchOptionGreeks({
    required String underlying,
    required String expiryLabel,
  }) async {
    // The AI Suggestion engine must never ask for greeks: it solves IV from the
    // premium it already fetched. Any call here is a regression.
    greekCalls.add('$underlying|$expiryLabel');
    return const OptionGreekBatch(byStrike: {}, error: 'not-used');
  }
}

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

final DateTime kEnd = DateTime(2025, 3, 21);
final DateTime kExpiry = DateTime(2025, 4, 24);

/// A clean climb: [count] sessions, [step] rupees a day from [base].
///
/// [volume] defaults to 10 lakh shares a day, which at these prices is ~15-20
/// ₹ crore of turnover — enough to clear the liquidity gate. [lastVolume] lets a
/// fixture carry a volume spike on the final session — that is what separates
/// two otherwise identical ramps in the score.
List<Candle> climb(
  int count, {
  double base = 100,
  double step = 1,
  int volume = 1000000,
  int? lastVolume,
}) => [
      for (var i = 0; i < count; i++)
        Candle(
          time: kEnd.subtract(Duration(days: count - 1 - i)),
          open: base + step * i,
          high: base + step * i,
          low: base + step * i,
          close: base + step * i,
          volume: i == count - 1 ? (lastVolume ?? volume) : volume,
        ),
    ];

Scrip scrip(String token, String symbol) => Scrip(
      token: token,
      symbol: '$symbol-EQ',
      name: '$symbol Limited',
      exchange: Exchange.nse,
    );

MarketQuote quote(String token, double ltp) => MarketQuote(
      token: token,
      tradingSymbol: token,
      exchange: Exchange.nfo,
      ltp: ltp,
      previousClose: ltp * 0.9,
    );

FnoContract contract(
  String underlying,
  double strike,
  String type,
  String token,
) =>
    FnoContract(
      underlying: underlying,
      expiryLabel: '24APR2025',
      expiryDate: kExpiry,
      strike: strike,
      optionType: type,
      token: token,
      symbol: '${underlying}24APR${strike.toStringAsFixed(0)}$type',
      lotSize: 75,
    );

/// ALPHA climbs 1.5/day (spot 203.5), BETA 0.8/day (spot 155.2).
/// GAMMA has only 30 bars — too little to judge.
Map<String, List<Candle>> bars() => {
      '1': climb(70, step: 1.5, lastVolume: 3000000), // leader: 3x volume too
      '2': climb(70, step: 0.8),
      '3': climb(30),
    };

/// The same book, but at another expiry — the picker has to choose between
/// them (a contract with 3 days left is the wrong one for a buyer).
List<FnoContract> bookAt(
  String underlying,
  List<double> strikes,
  int tokenBase,
  DateTime expiry,
  String label,
) => [
      for (var i = 0; i < strikes.length; i++) ...[
        FnoContract(
          underlying: underlying,
          expiryLabel: label,
          expiryDate: expiry,
          strike: strikes[i],
          optionType: 'CE',
          token: '${tokenBase + i * 2}',
          symbol: '$underlying$label${strikes[i].toStringAsFixed(0)}CE',
          lotSize: 75,
        ),
        FnoContract(
          underlying: underlying,
          expiryLabel: label,
          expiryDate: expiry,
          strike: strikes[i],
          optionType: 'PE',
          token: '${tokenBase + i * 2 + 1}',
          symbol: '$underlying$label${strikes[i].toStringAsFixed(0)}PE',
          lotSize: 75,
        ),
      ],
    ];

/// Strikes on both sides of ATM so the strangle picker has something to choose.
List<FnoContract> book(String underlying, List<double> strikes, int tokenBase) => [
      for (var i = 0; i < strikes.length; i++) ...[
        contract(underlying, strikes[i], 'CE', '${tokenBase + i * 2}'),
        contract(underlying, strikes[i], 'PE', '${tokenBase + i * 2 + 1}'),
      ],
    ];

void main() {
  late CandleDao candles;
  late FnoContractDao contracts;

  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close();
    final db = AppDatabase.instance;
    candles = CandleDao(db);
    contracts = FnoContractDao(db);
  });

  tearDownAll(() async {
    await AppDatabase.instance.close();
  });

  AiSuggestionService build(CandleSource source, FakeMarket market) =>
      AiSuggestionService(
        source: source,
        candles: candles,
        contracts: contracts,
        marketData: market,
      );

  Future<void> seedBooks() => contracts.replaceAll([
        ...book('ALPHA', [190, 195, 200, 205, 210, 215], 9001),
        ...book('BETA', [140, 145, 150, 155, 160, 165], 9101),
      ]);

  /// 205 strike: token 9001 + 3*2 = 9007 (CE), 9008 (PE).
  /// 155 strike: token 9101 + 3*2 = 9107 (CE), 9108 (PE).
  Map<String, MarketQuote> quotes({double alpha = 5.2, double beta = 4.0}) => {
        '9007': quote('9007', alpha),
        '9008': quote('9008', alpha * 0.9),
        '9107': quote('9107', beta),
        '9108': quote('9108', beta * 0.9),
      };

  const names = {'ALPHA': 'Alpha Ltd', 'BETA': 'Beta Ltd', 'GAMMA': 'Gamma Ltd'};

  test('happy path: ranked rows, Top N cut, skips explained', () async {
    await seedBooks();
    final source = FakeCandleSource(bars());
    final market = FakeMarket(quotes: quotes());

    final result = await build(source, market).run(
      universe: [scrip('1', 'ALPHA'), scrip('2', 'BETA'), scrip('3', 'GAMMA')],
      companyNames: names,
      asOf: kEnd,
      filters: AiFilters.defaults,
    );

    // GAMMA cannot be judged on 30 bars → skipped with a reason, not scored.
    expect(result.rows.map((r) => r.symbol), ['ALPHA', 'BETA']);
    expect(result.scanned, 2);
    expect(result.universeSize, 3);
    expect(result.cancelled, isFalse);

    final gamma = result.skips.where((s) => s.symbol == 'GAMMA').toList();
    expect(gamma, hasLength(1));
    expect(gamma.single.reason, contains('bars'));

    // Ranks are 1…N and follow the score.
    expect(result.rows.first.rank, 1);
    expect(result.rows.last.rank, 2);
    expect(result.rows.first.score,
        greaterThanOrEqualTo(result.rows.last.score));
    expect(result.rows.first.name, 'Alpha Ltd');
    expect(result.rows.first.studyScore, greaterThan(0));

    // The option side is quoted ONCE for the whole shortlist (4 tokens).
    expect(market.quoteCalls, hasLength(1));
    expect(market.quoteCalls.single, hasLength(4));
    // …and the engine never asks for greeks: IV comes from the premium.
    expect(market.greekCalls, isEmpty);
  });

  test('a thin stock is refused at the liquidity gate — with the number', () async {
    await seedBooks();
    final market = FakeMarket(quotes: quotes());

    // GAMMA climbs like the others but trades 1,000 shares a day (~0.02 cr).
    final thin = {
      '1': climb(70, step: 1.5, lastVolume: 3000000),
      '4': climb(70, step: 1.4, volume: 1000),
    };
    final result = await build(FakeCandleSource(thin), market).run(
      universe: [scrip('1', 'ALPHA'), scrip('4', 'GAMMA')],
      companyNames: names,
      asOf: kEnd,
      filters: AiFilters.defaults,
    );

    expect(result.rows.map((r) => r.symbol), ['ALPHA']);
    final drop = result.drops.singleWhere((d) => d.symbol == 'GAMMA');
    expect(drop.gate, AiGate.liquidity);
    expect(drop.line(result.filters), contains('turnover'));
    expect(result.passedLiquidity, 1);
    expect(result.funnelLine, contains('1 liquidity paar'));

    // …and opening the gate brings it back.
    final open = await build(FakeCandleSource(thin), market).run(
      universe: [scrip('1', 'ALPHA'), scrip('4', 'GAMMA')],
      companyNames: names,
      asOf: kEnd,
      filters: const AiFilters(minTurnoverCrore: 0),
    );
    expect(open.rows.map((r) => r.symbol), contains('GAMMA'));
    expect(open.passedLiquidity, 2);
  });

  test('a confirmed result inside the window stops every new position',
      () async {
    await seedBooks();
    final market = FakeMarket(quotes: quotes());

    // Result in 3 days — IV crush for a buyer, gap risk for a seller.
    final soon = {
      'ALPHA': EarningsInfo(
        nextDate: kEnd.add(const Duration(days: 3)),
        nextLabel: 'Q4',
        nextConfirmed: true,
      ),
    };

    final blocked = await build(FakeCandleSource(bars()), market).run(
      universe: [scrip('1', 'ALPHA')],
      companyNames: names,
      asOf: kEnd,
      filters: AiFilters.defaults,
      events: soon,
    );

    final row = blocked.rows.single;
    expect(row.resultConfirmed, isTrue);
    expect(row.resultDate, kEnd.add(const Duration(days: 3)));
    expect(row.strategy.action, 'Wait');
    expect(row.strategy.pair, '—');
    expect(row.strategy.why, contains('Result'));

    // Move the result past the window → the trade comes back.
    final later = {
      'ALPHA': EarningsInfo(
        nextDate: kEnd.add(const Duration(days: 25)),
        nextLabel: 'Q4',
        nextConfirmed: true,
      ),
    };
    final allowed = await build(FakeCandleSource(bars()), market).run(
      universe: [scrip('1', 'ALPHA')],
      companyNames: names,
      asOf: kEnd,
      filters: AiFilters.defaults,
      events: later,
    );
    expect(allowed.rows.single.strategy.action, isNot('Wait'));
    // The date is still on the card, so the trader can see it coming.
    expect(allowed.rows.single.resultLine(kEnd), 'Result: 25 din me');
  });

  test('an estimated (guessed) result date is never used', () async {
    await seedBooks();
    final market = FakeMarket(quotes: quotes());

    // Builds ≤ 1.5.12 wrote guessed dates; they must be ignored everywhere.
    final guessed = {
      'ALPHA': EarningsInfo(
        nextDate: kEnd.add(const Duration(days: 2)),
        nextLabel: 'Q4',
        nextConfirmed: true,
        estimated: true,
      ),
    };
    final result = await build(FakeCandleSource(bars()), market).run(
      universe: [scrip('1', 'ALPHA')],
      companyNames: names,
      asOf: kEnd,
      filters: AiFilters.defaults,
      events: guessed,
    );

    expect(result.rows.single.resultDate, isNull);
    expect(result.rows.single.resultConfirmed, isFalse);
    expect(result.rows.single.strategy.action, isNot('Wait'));
  });

  test('the expiry is chosen, not taken: too few days left → next contract',
      () async {
    // A near expiry 5 days out and a far one 34 days out, both with a 205
    // strike. A buyer needs the far one (theta eats a 5-day option).
    await contracts.replaceAll([
      ...bookAt('ALPHA', [200, 205, 210], 9201, DateTime(2025, 3, 26),
          '26MAR2025'),
      ...book('ALPHA', [190, 195, 200, 205, 210, 215], 9001),
    ]);
    final market = FakeMarket(quotes: {
      ...quotes(),
      // Strikes are [200, 205, 210] → 205 is index 1 → CE 9203, PE 9204.
      '9203': quote('9203', 2.1),
      '9204': quote('9204', 1.9),
    });

    final result = await build(FakeCandleSource(bars()), market).run(
      universe: [scrip('1', 'ALPHA')],
      companyNames: names,
      asOf: kEnd,
      filters: AiFilters.defaults,
      capital: 100000,
    );

    final row = result.rows.single;
    // 34 days to expiry, not 5.
    expect(row.options!.daysToExpiry, 34);
    expect(row.options!.atmStrike, 205);
    expect(row.strategy.action, 'Buy');
    // …and a plan came with it.
    expect(row.plan, isNotNull);
  });

  test('only a dying expiry left → the trade is refused, with the reason',
      () async {
    await contracts.replaceAll([
      ...bookAt('ALPHA', [200, 205, 210], 9201, DateTime(2025, 3, 26),
          '26MAR2025'),
    ]);
    final market = FakeMarket(quotes: {
      '9203': quote('9203', 2.1),
      '9204': quote('9204', 1.9),
    });

    final result = await build(FakeCandleSource(bars()), market).run(
      universe: [scrip('1', 'ALPHA')],
      companyNames: names,
      asOf: kEnd,
      filters: AiFilters.defaults,
      capital: 100000,
    );

    final row = result.rows.single;
    expect(row.strategy.action, 'Wait');
    expect(row.strategy.why, contains('theta'));
    expect(row.plan, isNull); // nothing to plan for a refused trade
  });

  test('the plan is arithmetic, not a guess', () async {
    await seedBooks();
    final market = FakeMarket(quotes: quotes(alpha: 5.2));

    final result = await build(FakeCandleSource(bars()), market).run(
      universe: [scrip('1', 'ALPHA')],
      companyNames: names,
      asOf: kEnd,
      filters: AiFilters.defaults,
      capital: 100000,
    );

    final row = result.rows.single;
    final plan = row.plan!;

    // ALPHA closes at 203.5 with an ATR of 1.5 (1.5 rupees a day).
    expect(plan.risk, closeTo(1.5, 1e-9));
    expect(plan.reward, closeTo(3.0, 1e-9)); // 2 × risk
    expect(plan.rr, closeTo(2, 1e-9));

    // The ATM call was quoted at 5.2 → lot 75 costs ₹390 and risks ₹156.
    expect(plan.premium, closeTo(5.2, 1e-9));
    expect(plan.lotSize, 75);
    expect(plan.lotCost, closeTo(390, 1e-9));
    expect(plan.riskPerLot, closeTo(156, 1e-9));

    // 1.5 % of ₹1,00,000 = ₹1,500 → 9 lots (₹1,404 at risk).
    expect(plan.lots, 9);
    expect(plan.capitalAtRiskPct, closeTo(0.156, 1e-9));
  });

  test('the funnel says exactly where the list shrank', () async {
    await seedBooks();
    final market = FakeMarket(quotes: quotes());

    // A bar nobody can clear: both stocks must be reported as drops, each with
    // the number that failed — not silently vanish.
    final result = await build(FakeCandleSource(bars()), market).run(
      universe: [scrip('1', 'ALPHA'), scrip('2', 'BETA')],
      companyNames: names,
      asOf: kEnd,
      filters: const AiFilters(minScore: 100, minStudyScore: 0, topN: 20),
    );

    expect(result.rows, isEmpty);
    expect(result.scanned, 2);
    expect(result.passedStudy, 2); // the study gate was open
    expect(result.passedMomentum, 0);
    expect(result.drops, hasLength(2));
    expect(result.drops.every((d) => d.gate == AiGate.momentum), isTrue);

    // The closest misses come back highest-first, with the shortfall on them.
    final near = result.nearMisses(5);
    expect(near, hasLength(2));
    expect(near.first.score, greaterThanOrEqualTo(near.last.score));
    expect(near.first.line(result.filters), contains('momentum'));
    expect(result.funnelLine, contains('0 list me'));

    // …and a study gate that nobody clears is reported as the study gate.
    final studyGate = await build(FakeCandleSource(bars()), market).run(
      universe: [scrip('1', 'ALPHA')],
      companyNames: names,
      asOf: kEnd,
      filters: const AiFilters(minScore: 0, minStudyScore: 12, topN: 20),
    );
    expect(studyGate.passedStudy, 0);
    expect(studyGate.drops.single.gate, AiGate.study);
  });

  test('the Top N is the user\'s number, not the engine\'s', () async {
    await seedBooks();
    final market = FakeMarket(quotes: quotes());

    final two = await build(FakeCandleSource(bars()), market).run(
      universe: [scrip('1', 'ALPHA'), scrip('2', 'BETA')],
      companyNames: names,
      asOf: kEnd,
      filters: const AiFilters(minStudyScore: 0, minScore: 0, topN: 2),
    );
    expect(two.rows, hasLength(2));

    final one = await build(FakeCandleSource(bars()), market).run(
      universe: [scrip('1', 'ALPHA'), scrip('2', 'BETA')],
      companyNames: names,
      asOf: kEnd,
      filters: const AiFilters(minStudyScore: 0, minScore: 0, topN: 1),
    );
    expect(one.rows, hasLength(1));
    expect(one.rows.single.symbol, 'ALPHA'); // the stronger climb
    expect(one.rows.single.rank, 1);
  });

  test('raising a filter removes rows — the list obeys the user', () async {
    await seedBooks();
    final market = FakeMarket(quotes: quotes());

    Future<AiSuggestionResult> runWith(AiFilters filters) =>
        build(FakeCandleSource(bars()), market).run(
      universe: [scrip('1', 'ALPHA'), scrip('2', 'BETA')],
      companyNames: names,
      asOf: kEnd,
      filters: filters,
    );

    final open = await runWith(
      const AiFilters(minStudyScore: 0, minScore: 0, topN: 20),
    );
    expect(open.rows, hasLength(2));

    final best = open.rows.first.score;
    final second = open.rows.last.score;

    // Just under the leader's score → only the leader survives.
    final strict = await runWith(AiFilters(
      minStudyScore: 0,
      minScore: (second + best) / 2,
      topN: 20,
    ));
    expect(strict.rows, hasLength(1));
    expect(strict.rows.single.symbol, 'ALPHA');

    // Above everyone → an empty list, which the screen explains honestly.
    final impossible = await runWith(AiFilters(
      minStudyScore: 0,
      minScore: best + 1,
      topN: 20,
    ));
    expect(impossible.rows, isEmpty);
    expect(impossible.isEmpty, isTrue);

    // The study score gate works the same way.
    final studyGate = await runWith(
      const AiFilters(minStudyScore: 999, minScore: 0, topN: 20),
    );
    expect(studyGate.rows, isEmpty);
  });

  test('a broker error skips that stock with the reason, the rest still run',
      () async {
    await seedBooks();
    final source = FakeCandleSource(bars(), failTokens: {'2'});
    final market = FakeMarket(quotes: quotes());

    final result = await build(source, market).run(
      universe: [scrip('1', 'ALPHA'), scrip('2', 'BETA')],
      companyNames: names,
      asOf: kEnd,
      filters: AiFilters.defaults,
    );

    expect(result.rows.map((r) => r.symbol), ['ALPHA']);
    final skip = result.skips.single;
    expect(skip.symbol, 'BETA');
    expect(skip.reason, contains('candle endpoint down'));
  });

  test('cancel stops the scan and says so', () async {
    await seedBooks();
    final market = FakeMarket(quotes: quotes());
    var calls = 0;

    final result = await build(FakeCandleSource(bars()), market).run(
      universe: [scrip('1', 'ALPHA'), scrip('2', 'BETA')],
      companyNames: names,
      asOf: kEnd,
      filters: AiFilters.defaults,
      isCancelled: () => ++calls >= 1, // stop after the first stock
    );

    expect(result.cancelled, isTrue);
    expect(result.rows, isEmpty);
    // Nothing was quoted for a scan that never finished.
    expect(market.quoteCalls, isEmpty);
  });

  test('progress is reported while the candles come in', () async {
    await seedBooks();
    final market = FakeMarket(quotes: quotes());
    final seen = <double>[];

    await build(FakeCandleSource(bars()), market).run(
      universe: [scrip('1', 'ALPHA'), scrip('2', 'BETA'), scrip('3', 'GAMMA')],
      companyNames: names,
      asOf: kEnd,
      filters: AiFilters.defaults,
      onProgress: (p) => seen.add(p.fraction),
    );

    expect(seen, hasLength(3));
    expect(seen.first, lessThan(seen.last));
    expect(seen.last, lessThanOrEqualTo(1));
  });

  test('a dear premium turns the buy into a spread, and names the OTM leg',
      () async {
    await seedBooks();
    final market = FakeMarket(quotes: quotes(alpha: 5.2, beta: 4.0));

    final result = await build(FakeCandleSource(bars()), market).run(
      universe: [scrip('1', 'ALPHA'), scrip('2', 'BETA')],
      companyNames: names,
      asOf: kEnd,
      filters: const AiFilters(minStudyScore: 0, minScore: 0, topN: 20),
    );

    final alpha = result.rows.firstWhere((r) => r.symbol == 'ALPHA');
    expect(alpha.direction, AiDirection.bullish);
    expect(alpha.strategy.action, 'Buy');
    expect(alpha.strategy.name, 'Bull Call Spread');
    expect(alpha.strategy.strikeType, 'ATM + OTM');
    expect(alpha.strategy.pair, startsWith('CE 205 kharido'));

    // The OTM leg must be a real strike from the book, above the spot.
    final options = alpha.options!;
    expect(options.atmStrike, 205);
    expect(options.lotSize, 75);
    expect(options.otmCeStrike, greaterThan(203.5));
    expect(options.avgIv, greaterThan(0));
    expect(options.ivExpensive, isTrue);
    expect(options.premiumLine, contains('IV'));
    expect(options.premiumLine, contains('jodi ₹'));
  });

  test('a cheap premium stays a plain directional buy', () async {
    await seedBooks();
    // ≈8 % IV: the option charges less per day than the stock moves.
    final market = FakeMarket(quotes: quotes(alpha: 2.0, beta: 1.6));

    final result = await build(FakeCandleSource(bars()), market).run(
      universe: [scrip('1', 'ALPHA'), scrip('2', 'BETA')],
      companyNames: names,
      asOf: kEnd,
      filters: const AiFilters(minStudyScore: 0, minScore: 0, topN: 20),
    );

    final alpha = result.rows.firstWhere((r) => r.symbol == 'ALPHA');
    expect(alpha.strategy.name, 'Directional Buy');
    expect(alpha.strategy.pair, 'CE 205');
    expect(alpha.options!.ivExpensive, isFalse);
  });

  test('a dead quote endpoint costs the premiums, not the ideas', () async {
    await seedBooks();
    final market = FakeMarket(failQuotes: true);

    final result = await build(FakeCandleSource(bars()), market).run(
      universe: [scrip('1', 'ALPHA'), scrip('2', 'BETA')],
      companyNames: names,
      asOf: kEnd,
      filters: const AiFilters(minStudyScore: 0, minScore: 0, topN: 20),
    );

    expect(result.rows, hasLength(2)); // the read stands on its own
    for (final row in result.rows) {
      expect(row.strategy, same(AiStrategy.none));
      expect(row.strategy.pair, '—');
      expect(row.options, isNull);
    }
  });

  test('a stock with no option book keeps its rank and says "no data"',
      () async {
    // Only ALPHA has contracts; BETA has none.
    await contracts.replaceAll(book('ALPHA', [200, 205, 210], 9001));
    final market = FakeMarket(quotes: quotes());

    final result = await build(FakeCandleSource(bars()), market).run(
      universe: [scrip('1', 'ALPHA'), scrip('2', 'BETA')],
      companyNames: names,
      asOf: kEnd,
      filters: const AiFilters(minStudyScore: 0, minScore: 0, topN: 20),
    );

    expect(result.rows, hasLength(2));
    final beta = result.rows.firstWhere((r) => r.symbol == 'BETA');
    expect(beta.strategy, same(AiStrategy.none));
    expect(beta.rank, 2); // it did not lose its place in the list
  });

  test('a second run is served from the candle cache', () async {
    await seedBooks();
    final source = FakeCandleSource(bars());
    final market = FakeMarket(quotes: quotes());

    await build(source, market).run(
      universe: [scrip('1', 'ALPHA'), scrip('2', 'BETA')],
      companyNames: names,
      asOf: kEnd,
      filters: AiFilters.defaults,
    );
    final downloads = <String>[];

    // A fresh source that records what it was asked for: nothing should be
    // downloaded on the second run.
    final counting = _CountingSource(bars(), downloads);
    final second = await build(counting, FakeMarket(quotes: quotes())).run(
      universe: [scrip('1', 'ALPHA'), scrip('2', 'BETA')],
      companyNames: names,
      asOf: kEnd,
      filters: AiFilters.defaults,
    );

    expect(second.rows, hasLength(2));
    expect(downloads, isEmpty);
  });
}

/// A candle source that records which tokens were actually downloaded.
class _CountingSource implements CandleSource {
  _CountingSource(this.barsByToken, this.downloads);

  final Map<String, List<Candle>> barsByToken;
  final List<String> downloads;

  @override
  Future<List<Candle>> fetchDailyCandles({
    required Scrip scrip,
    required DateTime from,
    required DateTime to,
    String interval = 'ONE_DAY',
  }) async {
    downloads.add(scrip.token);
    return barsByToken[scrip.token] ?? const [];
  }
}
