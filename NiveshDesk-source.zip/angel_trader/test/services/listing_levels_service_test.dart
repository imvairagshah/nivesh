// ---------------------------------------------------------------------------
// listing_levels_service_test.dart — the "app fetches the listing-day levels
// itself" path.
//
// The bundled IPO master carries symbol + listing date for every mainboard IPO
// since 2015 (~550 rows) but no listing-day high/low. This service derives them
// from the broker's daily candles, once per row, and remembers where each level
// came from so nothing is fetched twice.
//
// NO NETWORK: real SQLite (FFI, in-memory) + real DAOs + the bundled starter
// scrip master; only the candle source is faked.
// ---------------------------------------------------------------------------

import 'dart:convert';

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/ipo_dao.dart';
import 'package:angel_trader/data/local/dao/scrip_dao.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/data/local/models/ipo.dart';
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/data/remote/dto/session.dart';
import 'package:angel_trader/services/auth_service.dart';
import 'package:angel_trader/services/candle_source.dart';
import 'package:angel_trader/services/listing_levels_service.dart';
import 'package:angel_trader/services/scrip_master_service.dart';
import 'package:angel_trader/services/secure_store.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

/// Stands in for `getCandleData`: the test decides what the market returned.
class _FakeCandles implements CandleSource {
  final Map<String, List<Candle>> byToken = {};
  final List<String> requestedTokens = [];
  Object? failure;

  /// Returned for any token not present in [byToken].
  List<Candle> anyToken = const [];

  @override
  Future<List<Candle>> fetchDailyCandles({
    required Scrip scrip,
    required DateTime from,
    required DateTime to,
    String interval = 'ONE_DAY',
  }) async {
    requestedTokens.add(scrip.token);
    final error = failure;
    if (error != null) throw error;
    return byToken[scrip.token] ?? anyToken;
  }
}

Candle _candle(DateTime day, {double high = 100, double low = 80, double open = 90, double close = 95}) =>
    Candle(time: day, open: open, high: high, low: low, close: close, volume: 1000);

String _jwt() {
  String seg(Map<String, dynamic> p) =>
      base64Url.encode(utf8.encode(jsonEncode(p))).replaceAll('=', '');
  return '${seg({'alg': 'HS512'})}.${seg({'exp': 4070908800})}.sig';
}

Future<AuthService> _auth({required bool loggedIn}) async {
  FlutterSecureStorage.setMockInitialValues(
    loggedIn
        ? {
            'angel_session_v1': jsonEncode(
              AngelSession(
                apiKey: 'k',
                clientCode: 'A1',
                jwtToken: _jwt(),
                refreshToken: 'r',
                feedToken: 'f',
                generatedAt: DateTime(2026, 10, 1, 9),
              ).toJson(),
            ),
          }
        : const {},
  );
  final auth = AuthService(store: SecureStore());
  await auth.restore();
  return auth;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late AppDatabase db;
  late IpoDao ipoDao;
  late ScripMasterService master;
  late _FakeCandles candles;

  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close();
    db = AppDatabase.instance;
    ipoDao = IpoDao(db);
    master = ScripMasterService(
      scripDao: ScripDao(db),
      settingsDao: SettingsDao(db),
    );
    await master.initialise(); // bundled 122-row starter master
    candles = _FakeCandles();
  });

  /// A row as the bundled master ships it: symbol + listing date, no levels.
  Future<Ipo> seedPending({
    String symbol = 'IDEA',
    DateTime? listed,
  }) async {
    final ipo = Ipo(
      symbol: symbol,
      companyName: '$symbol Ltd',
      exchange: Exchange.nse,
      listingDate: listed ?? DateTime(2016, 1, 1),
      listingHigh: 0,
      listingLow: 0,
      notes: 'Mainboard IPO 2016',
    );
    await ipoDao.insert(ipo);
    return ipo;
  }

  Future<ListingLevelsService> service({required bool loggedIn}) async {
    final auth = await _auth(loggedIn: loggedIn);
    return ListingLevelsService(
      ipoDao: ipoDao,
      scripMaster: master,
      candles: candles,
      auth: auth,
      batchSize: 10,
    );
  }

  test('pending rows are listed, newest listing first', () async {
    await seedPending(symbol: 'IDEA', listed: DateTime(2016, 1, 1));
    await seedPending(symbol: 'NYKAA', listed: DateTime(2021, 11, 10));
    final svc = await service(loggedIn: true);

    final pending = await svc.pendingRows();
    expect(pending.map((r) => r.symbol), ['NYKAA', 'IDEA']);
    expect(await ipoDao.countAwaitingLevels(), 2);
  });

  test('the first candle in the window becomes the listing-day high/low', () async {
    await seedPending(symbol: 'IDEA', listed: DateTime(2016, 1, 4));
    // The fake returns bars from 04 Jan 2016 (Monday, the listing session).
    candles.byToken['14366'] = [
      _candle(DateTime(2016, 1, 4), high: 24.60, low: 14.05),
      _candle(DateTime(2016, 1, 5), high: 26.10, low: 23.90),
    ];
    final svc = await service(loggedIn: true);

    final result = await svc.fetchPending(fetchAll: true);

    expect(result.updated, 1);
    expect(result.remaining, 0);
    final row = (await ipoDao.all()).single;
    expect(row.listingHigh, closeTo(24.60, 1e-9));
    expect(row.listingLow, closeTo(14.05, 1e-9));
    expect(row.levelsSource, LevelsSource.auto);
    expect(row.hasLevels, isTrue);
  });

  test('the window starts a few days before the listing date (holiday dips)',
      () async {
    await seedPending(symbol: 'IDEA', listed: DateTime(2016, 1, 4));
    final svc = await service(loggedIn: true);
    await svc.fetchPending(fetchAll: true);

    // fromDate = listing − 3 days … toDate = listing + 14 days, and the request
    // went to the right token.
    expect(candles.requestedTokens, ['14366']);
  });

  test('no data for the symbol → marked missing, not retried silently', () async {
    await seedPending(symbol: 'IDEA');
    final svc = await service(loggedIn: true);

    final result = await svc.fetchPending(fetchAll: true);

    expect(result.missing, 1);
    expect(result.updated, 0);
    final row = (await ipoDao.all()).single;
    expect(row.levelsSource, LevelsSource.missing);
    expect(row.levelsUnavailable, isTrue);
    // 'missing' rows drop out of the automatic queue…
    expect(await svc.pendingRows(), isEmpty);
    // …but an explicit retry picks them up again.
    expect((await svc.pendingRows(includeMissing: true)), hasLength(1));
  });

  test('a symbol with no token stays pending (master refresh can fix it)', () async {
    await seedPending(symbol: 'NOTALISTEDSTOCK');
    final svc = await service(loggedIn: true);

    final result = await svc.fetchPending(fetchAll: true);

    expect(result.skippedNoToken, 1);
    expect(result.remaining, 1);
    expect((await ipoDao.all()).single.levelsSource, LevelsSource.pending);
  });

  test('a broker error leaves the row pending and reports why', () async {
    await seedPending(symbol: 'IDEA');
    final svc = await service(loggedIn: true);
    candles.failure = Exception('rate limited');

    final result = await svc.fetchPending(fetchAll: true);

    expect(result.updated, 0);
    expect(result.error, contains('rate limited'));
    expect((await ipoDao.all()).single.levelsSource, LevelsSource.pending);
  });

  test('logged out → nothing is attempted and the caller is told', () async {
    await seedPending(symbol: 'IDEA');
    final svc = await service(loggedIn: false);

    final result = await svc.fetchPending(fetchAll: true);

    expect(result.needsLogin, isTrue);
    expect(candles.requestedTokens, isEmpty);
    expect((await ipoDao.all()).single.levelsSource, LevelsSource.pending);
  });

  test('batches stop at batchSize when not asked to fetch everything', () async {
    await seedPending(symbol: 'IDEA', listed: DateTime(2016, 1, 1));
    await seedPending(symbol: 'NYKAA', listed: DateTime(2016, 1, 2));
    await seedPending(symbol: 'SBIN', listed: DateTime(2016, 1, 3));
    await seedPending(symbol: 'DMART', listed: DateTime(2016, 1, 4));
    final auth = await _auth(loggedIn: true);
    final svc = ListingLevelsService(
      ipoDao: ipoDao,
      scripMaster: master,
      candles: candles,
      auth: auth,
      batchSize: 2, // 4 rows share one token, so a batch of 2 leaves 2 behind
    );
    // Every symbol answers, but an automatic run may only look at two rows.
    candles.anyToken = [_candle(DateTime(2016, 1, 1), high: 10, low: 9)];

    final result = await svc.fetchPending();

    expect(result.updated, 2, reason: 'batchSize = 2 caps one automatic run');
    expect(candles.requestedTokens, hasLength(2));
    expect(result.remaining, 2, reason: 'the rest resume on the next run');
  });

  test('progress is reported while the batch runs', () async {
    await seedPending(symbol: 'IDEA');
    candles.byToken['14366'] = [_candle(DateTime(2016, 1, 1), high: 10, low: 9)];
    final svc = await service(loggedIn: true);
    final seen = <String>[];

    await svc.fetchPending(
      fetchAll: true,
      onProgress: (done, total) => seen.add('$done/$total'),
    );

    expect(seen, ['1/1']);
  });

  group('symbols the broker master does not contain', () {
    test('are marked missing so the levels queue can actually finish', () async {
      await seedPending(symbol: 'IDEA'); // resolves in the starter master
      await seedPending(symbol: 'GHOSTCO'); // resolves nowhere
      final svc = await service(loggedIn: true);

      expect(await svc.markUnresolvableAsMissing(), 1);

      final rows = await ipoDao.all();
      final ghost = rows.firstWhere((r) => r.symbol == 'GHOSTCO');
      expect(ghost.levelsSource, 'missing');
      expect(ghost.levelsUnavailable, isTrue);
      // The resolvable row keeps waiting for its candle instead of being written off.
      expect(rows.firstWhere((r) => r.symbol == 'IDEA').levelsSource, '');
      expect(await ipoDao.countAwaitingLevels(), 1);
    });

    test('nothing happens while logged out (the starter master is too small)',
        () async {
      await seedPending(symbol: 'GHOSTCO');
      final svc = await service(loggedIn: false);

      expect(await svc.markUnresolvableAsMissing(), 0);
      expect((await ipoDao.all()).single.levelsSource, '');
    });

    test('rows that already have levels are never touched', () async {
      await seedPending(symbol: 'IDEA');
      final id = (await ipoDao.all()).single.id!;
      await ipoDao.setLevels(id, 100, 90, LevelsSource.seed);

      expect(await (await service(loggedIn: true)).markUnresolvableAsMissing(), 0);
      expect((await ipoDao.all()).single.levelsSource, 'seed');
    });
  });
}
