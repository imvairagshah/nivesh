// 1.5.89 — index rows ka detection + token cache keys (BANK NIFTY/BANKEX ka
// spot quote isi se milta hai; scrips table pollution nahi).

import 'package:angel_trader/services/scrip_master_service.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('normIndex — spaces/symbols hata kar key', () {
    expect(ScripMasterService.normIndex('NIFTY BANK'), 'NIFTYBANK');
    expect(ScripMasterService.normIndex('bank nifty'), 'BANKNIFTY');
    expect(ScripMasterService.normIndex('  BANKEX '), 'BANKEX');
  });

  test('isIndexRow — NSE AMXIDX index accept', () {
    expect(
        ScripMasterService.isIndexRow({
          'exch_seg': 'NSE',
          'instrumenttype': 'AMXIDX',
          'token': '99926009',
          'symbol': 'NIFTY BANK',
          'name': 'NIFTY BANK',
        }),
        isTrue);
  });

  test('isIndexRow — known index name (type khaali ho tab bhi)', () {
    expect(
        ScripMasterService.isIndexRow({
          'exch_seg': 'BSE',
          'instrumenttype': '',
          'token': '1',
          'symbol': 'BANKEX',
          'name': 'BANKEX',
        }),
        isTrue);
  });

  test('isIndexRow — equity/option rows reject', () {
    // Cash equity
    expect(
        ScripMasterService.isIndexRow({
          'exch_seg': 'NSE',
          'instrumenttype': '',
          'token': '2885',
          'symbol': 'RELIANCE-EQ',
          'name': 'RELIANCE',
        }),
        isFalse);
    // Option row (expiry set)
    expect(
        ScripMasterService.isIndexRow({
          'exch_seg': 'NFO',
          'instrumenttype': 'OPTIDX',
          'token': '1',
          'symbol': 'BANKNIFTY26NOV60100CE',
          'name': 'BANKNIFTY',
          'expiry': '26NOV2026',
        }),
        isFalse);
    // Token missing
    expect(
        ScripMasterService.isIndexRow({
          'exch_seg': 'NSE',
          'instrumenttype': 'AMXIDX',
          'symbol': 'NIFTY',
        }),
        isFalse);
  });
}
