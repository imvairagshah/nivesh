// ---------------------------------------------------------------------------
// feed_decoder_test.dart — the WebSocket 2.0 binary protocol.
//
// The decoder is the one piece of the live feed that can be verified completely
// offline, so it is tested hard: byte offsets, the NUL-padded token field, the
// paise→rupee conversion, the 2-byte control frames and the "shorter than its
// mode needs" malformed case.
//
// Offsets come from the official SmartAPI WebSocket 2.0 response contract (and
// agree with the official Python SDK's parser):
//   0 mode · 1 exchange type · 2..27 token · 27 sequence · 35 timestamp ·
//   43 LTP(int64, paise) · 51 last qty · 59 avg price · 67 volume · 115 prev close
// ---------------------------------------------------------------------------

import 'dart:typed_data';

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/remote/dto/quote.dart';
import 'package:angel_trader/services/feed_decoder.dart';
import 'package:flutter_test/flutter_test.dart';

/// Builds a Quote-mode (123-byte) packet, which the production code never sends
/// but the server does when a session is subscribed in mode 2.
Uint8List quotePacket({
  required String token,
  required int exchangeType,
  required double ltp,
  required int volume,
  required double previousClose,
  int sequence = 7,
  int timestampMs = 0,
}) {
  final bytes = Uint8List(FeedDecoder.quotePacketSize);
  final data = ByteData.sublistView(bytes);
  bytes[0] = 2; // quote mode
  bytes[1] = exchangeType;
  final tokenBytes = token.codeUnits;
  for (var i = 0; i < tokenBytes.length && i < FeedDecoder.tokenLength; i++) {
    bytes[FeedDecoder.tokenOffset + i] = tokenBytes[i];
  }
  data.setInt64(FeedDecoder.sequenceOffset, sequence, Endian.little);
  data.setInt64(FeedDecoder.timestampOffset, timestampMs, Endian.little);
  data.setInt64(FeedDecoder.ltpOffset, (ltp * 100).round(), Endian.little);
  data.setInt64(FeedDecoder.volumeOffset, volume, Endian.little);
  data.setInt64(
    FeedDecoder.previousCloseOffset,
    (previousClose * 100).round(),
    Endian.little,
  );
  return bytes;
}

void main() {
  group('LTP packets (mode 1)', () {
    test('decodes mode, exchange, token and price', () {
      final bytes = FeedDecoder.encodeLtpPacket(
        token: '3045',
        exchangeType: 1,
        ltp: 1234.55,
      );

      final frame = FeedDecoder.decode(bytes);

      expect(frame.isPacket, isTrue);
      final tick = frame.tick!;
      expect(tick.mode, FeedMode.ltp);
      expect(tick.exchange, Exchange.nse);
      expect(tick.token, '3045');
      expect(tick.ltp, 1234.55); // paise ÷ 100
    });

    test('the packet is exactly 51 bytes', () {
      final bytes = FeedDecoder.encodeLtpPacket(
        token: '1',
        exchangeType: 1,
        ltp: 10,
      );
      expect(bytes.length, FeedDecoder.ltpPacketSize);
      expect(bytes.length, 51);
    });

    test('trims the NUL padding from the 25-byte token field', () {
      final bytes = FeedDecoder.encodeLtpPacket(
        token: '2885',
        exchangeType: 1,
        ltp: 100,
      );
      expect(FeedDecoder.decode(bytes).tick!.token, '2885');

      // A token that fills the field must not be truncated or extended.
      final longToken = FeedDecoder.encodeLtpPacket(
        token: '1234567890123456789012345', // exactly 25 characters
        exchangeType: 1,
        ltp: 100,
      );
      expect(
        FeedDecoder.decode(longToken).tick!.token,
        '1234567890123456789012345',
      );
    });

    test('maps the wire exchange type (1 = nse_cm, 3 = bse_cm)', () {
      final nse = FeedDecoder.decode(
        FeedDecoder.encodeLtpPacket(token: '1', exchangeType: 1, ltp: 10),
      );
      final bse = FeedDecoder.decode(
        FeedDecoder.encodeLtpPacket(token: '1', exchangeType: 3, ltp: 10),
      );

      expect(nse.tick!.exchange, Exchange.nse);
      expect(bse.tick!.exchange, Exchange.bse);
      expect(FeedDecoder.typeForExchange(Exchange.bse), 3);
      expect(FeedDecoder.typeForExchange(Exchange.nse), 1);
    });

    test('an unsupported segment falls back to NSE instead of throwing', () {
      // 5 = mcx_fo, which this equity-only app never subscribes to.
      final frame = FeedDecoder.decode(
        FeedDecoder.encodeLtpPacket(token: '1', exchangeType: 5, ltp: 10),
      );
      expect(frame.isPacket, isTrue);
      expect(frame.tick!.exchange, Exchange.nse);
    });

    test('converts the epoch-millis feed timestamp into IST wall clock', () {
      // 04:00 UTC == 09:30 IST.
      final stamp = DateTime.utc(2025, 9, 29, 4, 0);
      final frame = FeedDecoder.decode(
        FeedDecoder.encodeLtpPacket(
          token: '3045',
          exchangeType: 1,
          ltp: 100,
          timestampMs: stamp.millisecondsSinceEpoch,
        ),
      );

      // `MarketCalendar.istFromUtc` returns a UTC-flagged DateTime whose *fields*
      // are IST wall clock (09:30), which is what every formatter formats.
      expect(frame.tick!.exchangeTime!.isUtc, isTrue);
      expect(frame.tick!.exchangeTime, DateTime.utc(2025, 9, 29, 9, 30));
      expect(frame.tick!.exchangeTime!.hour, 9);
    });

    test('a zero timestamp decodes as "unknown" rather than 1970', () {
      final frame = FeedDecoder.decode(
        FeedDecoder.encodeLtpPacket(
          token: '3045',
          exchangeType: 1,
          ltp: 100,
          timestampMs: 0,
        ),
      );
      expect(frame.tick!.exchangeTime, isNull);
    });

    test('keeps the sequence number for out-of-order detection', () {
      final frame = FeedDecoder.decode(
        FeedDecoder.encodeLtpPacket(
          token: '3045',
          exchangeType: 1,
          ltp: 100,
          sequence: 4242,
        ),
      );
      expect(frame.tick!.sequence, 4242);
    });

    test('LTP mode carries no quote fields', () {
      final tick = FeedDecoder.decode(
        FeedDecoder.encodeLtpPacket(token: '3045', exchangeType: 1, ltp: 100),
      ).tick!;
      expect(tick.volume, isNull);
      expect(tick.previousClose, isNull);
      expect(tick.changePct, isNull);
    });

    test('fractional paise round-trip safely', () {
      for (final price in [0.05, 9.99, 1234.55, 99999.95]) {
        final bytes = FeedDecoder.encodeLtpPacket(
          token: '3045',
          exchangeType: 1,
          ltp: price,
        );
        expect(FeedDecoder.decode(bytes).tick!.ltp, closeTo(price, 0.001));
      }
    });
  });

  group('Quote packets (mode 2)', () {
    test('decodes LTP, volume and the previous close', () {
      final frame = FeedDecoder.decode(
        quotePacket(
          token: '2885',
          exchangeType: 1,
          ltp: 1500.25,
          volume: 1234567,
          previousClose: 1480.10,
        ),
      );

      final tick = frame.tick!;
      expect(tick.mode, FeedMode.quote);
      expect(tick.token, '2885');
      expect(tick.ltp, 1500.25);
      expect(tick.volume, 1234567);
      expect(tick.previousClose, 1480.10);
      expect(tick.changePct, closeTo(1.36, 0.01));
    });

    test('a missing optional field stays null rather than becoming 0', () {
      final frame = FeedDecoder.decode(
        quotePacket(
          token: '2885',
          exchangeType: 1,
          ltp: 100,
          volume: 0, // no trades yet
          previousClose: 0, // server has nothing to report
        ),
      );
      expect(frame.tick!.volume, isNull);
      expect(frame.tick!.previousClose, isNull);
      expect(frame.tick!.changePct, isNull);
    });
  });

  group('control frames', () {
    test('a 2-byte frame with mode 0 is a pong', () {
      final frame = FeedDecoder.decode(Uint8List.fromList([0, 0]));
      expect(frame.isControl, isTrue);
      expect(frame.control!.isPong, isTrue);
      expect(frame.control, isA<FeedControlFrame>());
    });

    test('a 2-byte frame with mode 1 is a ping', () {
      final frame = FeedDecoder.decode(Uint8List.fromList([1, 0]));
      expect(frame.control!.isPing, isTrue);
    });

    test('a control frame is never mistaken for a tick', () {
      expect(FeedDecoder.decode(Uint8List.fromList([0, 0])).tick, isNull);
    });
  });

  group('malformed frames', () {
    test('an empty frame is rejected', () {
      final frame = FeedDecoder.decode(Uint8List(0));
      expect(frame.isMalformed, isTrue);
      expect(frame.reason, contains('empty'));
    });

    test('a truncated LTP packet is rejected with the sizes in the reason', () {
      final frame = FeedDecoder.decode(Uint8List.fromList(List.filled(20, 1)));
      expect(frame.isMalformed, isTrue);
      expect(frame.reason, contains('51'));
      expect(frame.reason, contains('20'));
    });

    test('a truncated quote packet is rejected', () {
      final full = quotePacket(
        token: '2885',
        exchangeType: 1,
        ltp: 100,
        volume: 5,
        previousClose: 99,
      );
      final frame = FeedDecoder.decode(
        Uint8List.sublistView(full, 0, 80), // 80 < 123
      );
      expect(frame.isMalformed, isTrue);
      expect(frame.reason, contains('123'));
    });

    test('a packet without a token is rejected', () {
      final bytes = Uint8List(FeedDecoder.ltpPacketSize);
      bytes[0] = 1; // mode, but every token byte stays 0
      final frame = FeedDecoder.decode(bytes);
      expect(frame.isMalformed, isTrue);
      expect(frame.reason, contains('token'));
    });

    test('a 3-byte frame with an unknown mode byte is rejected', () {
      final frame = FeedDecoder.decode(Uint8List.fromList([9, 1, 2]));
      expect(frame.isMalformed, isTrue);
    });
  });

  group('receivedAt stamping', () {
    test('the caller can pin "when the app saw it" (determinism)', () {
      final at = DateTime(2025, 9, 29, 9, 31, 2);
      final frame = FeedDecoder.decode(
        FeedDecoder.encodeLtpPacket(token: '3045', exchangeType: 1, ltp: 100),
        receivedAt: at,
      );
      expect(frame.tick!.receivedAt, at);
    });

    test('defaults to now when not supplied', () {
      final before = DateTime.now();
      final frame = FeedDecoder.decode(
        FeedDecoder.encodeLtpPacket(token: '3045', exchangeType: 1, ltp: 100),
      );
      expect(
        frame.tick!.receivedAt.isBefore(before.subtract(const Duration(seconds: 1))),
        isFalse,
      );
    });
  });
  group('exchange type mapping (F&O added)', () {
    test('2 is nse_fo, not nse_cm — an option tick must not price the stock',
        () {
      expect(FeedDecoder.exchangeForType(1), Exchange.nse);
      expect(FeedDecoder.exchangeForType(2), Exchange.nfo);
      expect(FeedDecoder.exchangeForType(3), Exchange.bse);
      expect(FeedDecoder.exchangeForType(4), Exchange.bse);
      expect(FeedDecoder.exchangeForType(0), Exchange.nse);
    });
  });

}
