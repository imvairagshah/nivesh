// ---------------------------------------------------------------------------
// ai_backtest_service_test.dart — the report's data path.
//
// The promise on the screen is "offline: phone ke cache se, koi internet call
// nahi". These tests hold the service to exactly that:
//
//   1. a cache that already holds the window costs ZERO requests (the fake
//      source throws if it is touched),
//   2. a cache that is too short is topped up once per symbol — and the fresh
//      series is the one that gets replayed,
//   3. a symbol with no data at all is skipped *with a reason*, never scored on
//      nothing.
//
// Real SQLite (sqflite FFI) and the real candle cache; only the network is
// faked.
// ---------------------------------------------------------------------------

import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/candle_dao.dart';
import 'package:angel_trader/data/remote/api_client.dart';
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/features/fno/ai/ai_backtest.dart';
import 'package:angel_trader/services/ai_backtest_service.dart';
import 'package:angel_trader/services/candle_source.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

final DateTime kToday = DateTime(2026, 10, 9);

/// Counts every call so "offline" is a measurable claim, not a slogan.
class CountingSource implements CandleSource {
  CountingSource({this.barsByToken = const {}, this.failTokens = const {}});

  final Map<String, List<Candle>> barsByToken;
  final Set<String> failTokens;

  final List<String> calls = [];

  @override
  Future<List<Candle>> fetchDailyCandles({
    required Scrip scrip,
    required DateTime from,
    required DateTime to,
    String interval = 'ONE_DAY',
  }) async {
    calls.add(scrip.token);
    if (failTokens.contains(scrip.token)) {
      throw const ApiException(message: 'no network in this test');
    }
    return barsByToken[scrip.token] ?? const [];
  }
}

Scrip scrip(String token, String symbol) => Scrip(
      token: token,
      symbol: '$symbol-EQ',
      name: '$symbol Limited',
      exchange: Exchange.nse,
    );

/// A steady climb with a volume spike every 25 sessions: unambiguous breakouts
/// and an unambiguous up-trend, so the replay has something to count.
List<Candle> ramp(int count, {double base = 100, double step = 0.2}) => [
      for (var i = 0; i < count; i++)
        Candle(
          time: kToday.subtract(Duration(days: count - 1 - i)),
          open: base + step * i,
          high: base + step * i,
          low: base + step * i,
          close: base + step * i,
          volume: i % 25 == 0 && i > 0 ? 3000000 : 1000000,
        ),
    ];

void main() {
  late CandleDao candles;

  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close();
    candles = CandleDao(AppDatabase.instance);
  });

  tearDownAll(() async {
    await AppDatabase.instance.close();
  });

  AiBacktestService build(CountingSource source) =>
      AiBacktestService(source: source, candles: candles, clock: () => kToday);

  Future<void> seed(String token, String symbol, List<Candle> bars) =>
      candles.saveBars(
        exchange: Exchange.nse.code,
        symbol: '$symbol-EQ',
        bars: bars,
        replaceWindow: true,
        windowFrom: bars.first.time,
        windowTo: bars.last.time,
      );

  test('a cache that already holds the window costs zero requests', () async {
    await seed('1', 'ALPHA', ramp(600));
    await seed('2', 'BETA', ramp(600, base: 250, step: 0.3));

    // Any call at all would throw, so a passing test *is* the assertion.
    final source = CountingSource(failTokens: {'1', '2'});

    final result = await build(source).run(
      universe: [scrip('1', 'ALPHA'), scrip('2', 'BETA')],
      config: const BtConfig(),
      years: 2,
    );

    expect(source.calls, isEmpty);
    expect(result.downloads, 0);
    expect(result.networkNote, contains('ek bhi internet call nahi gayi'));
    expect(result.symbolsScanned, 2);
    expect(result.skipped, isEmpty);
    expect(result.trades, isNotEmpty);
    expect(result.overall.samples, result.trades.length);
    // Both series are 600 sessions — a 2-year window expects ~500, so neither
    // is reported as short.
    expect(result.shortHistory, 0);
  });

  test('a thin cache is topped up once — and the fresh series is replayed',
      () async {
    await seed('1', 'ALPHA', ramp(100)); // 100 sessions is not 2 years
    final fresh = ramp(600);

    final source = CountingSource(barsByToken: {'1': fresh});

    final result = await build(source).run(
      universe: [scrip('1', 'ALPHA')],
      config: const BtConfig(),
      years: 2,
    );

    expect(source.calls, ['1']); // exactly one request, not one per bar
    expect(result.downloads, 1);
    // The long series is the one that got replayed: ~23 spike bars vs the 3 the
    // cached 100 sessions could ever have produced.
    expect(result.trades.length, greaterThan(10));
    expect(result.to, kToday);
  });

  test('the report is written back to the cache, so the next run is offline',
      () async {
    final source = CountingSource(barsByToken: {'1': ramp(600)});

    await build(source).run(
      universe: [scrip('1', 'ALPHA')],
      config: const BtConfig(),
      years: 2,
    );
    expect(source.calls, ['1']);

    // Second run, same service, empty network: the bars are already local.
    final offline = CountingSource(failTokens: {'1'});
    final again = await build(offline).run(
      universe: [scrip('1', 'ALPHA')],
      config: const BtConfig(),
      years: 2,
    );

    expect(offline.calls, isEmpty);
    expect(again.downloads, 0);
    expect(again.trades.length, greaterThan(10));
  });

  test('a symbol with no data at all is skipped with a reason', () async {
    final source = CountingSource(); // returns nothing for everybody

    final result = await build(source).run(
      universe: [scrip('9', 'GHOST'), scrip('1', 'ALPHA')],
      config: const BtConfig(),
      years: 1,
    );

    expect(result.skipped['GHOST'], contains('koi candle data nahi mila'));
    expect(result.skipped['ALPHA'], contains('koi candle data nahi mila'));
    expect(result.symbolsScanned, 0);
    expect(result.trades, isEmpty);
    expect(result.overall.samples, 0);
  });

  test('a broker error on one symbol does not sink the run', () async {
    await seed('1', 'ALPHA', ramp(600));
    final source = CountingSource(failTokens: {'2'}); // BETA blows up

    final result = await build(source).run(
      universe: [scrip('1', 'ALPHA'), scrip('2', 'BETA')],
      config: const BtConfig(),
      years: 2,
    );

    expect(result.skipped['BETA'], 'no network in this test');
    expect(result.symbolsScanned, 1);
    expect(result.trades, isNotEmpty);
  });

  test('progress is reported and a cancel stops the run', () async {
    await seed('1', 'ALPHA', ramp(600));
    await seed('2', 'BETA', ramp(600, base: 250, step: 0.3));
    final source = CountingSource(failTokens: {'1', '2'});

    final stages = <String>[];
    final result = await build(source).run(
      universe: [scrip('1', 'ALPHA'), scrip('2', 'BETA')],
      config: const BtConfig(),
      years: 2,
      onProgress: (p) => stages.add(p.stage),
      isCancelled: () => false,
    );

    expect(stages, isNotEmpty);
    expect(stages.first, 'Itihaas');
    expect(stages.last, 'Hisab');
    expect(result.cancelled, isFalse);

    // Now the same run, cancelled from the very first symbol.
    final stopped = await build(source).run(
      universe: [scrip('1', 'ALPHA'), scrip('2', 'BETA')],
      config: const BtConfig(),
      years: 2,
      isCancelled: () => true,
    );

    expect(stopped.cancelled, isTrue);
    expect(stopped.trades, isEmpty);
  });
}
