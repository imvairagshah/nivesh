// ---------------------------------------------------------------------------
// fno_study_service_test.dart — the 3-Month Study scan, end to end.
//
// Real SQLite (sqflite FFI), real candle cache, real contract book, real
// Black-Scholes; only the network is faked. That covers the four promises the
// service makes:
//
//   1. it never drops a stock just because its option data failed (degraded
//      mode — the spec's hard requirement),
//   2. it asks the broker for quotes in **batches**, once per 50 tokens,
//   3. a second scan is served from the candle cache (no repeat downloads),
//   4. everything it skipped or degraded is explainable in `skips`.
// ---------------------------------------------------------------------------

import 'dart:math' as math;

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/models/app_settings.dart';
import 'package:angel_trader/data/local/dao/candle_dao.dart';
import 'package:angel_trader/data/local/dao/fno_contract_dao.dart';
import 'package:angel_trader/data/local/dao/scan_cache_dao.dart';
import 'package:angel_trader/data/remote/api_client.dart';
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/data/remote/dto/quote.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/features/fno/study/study_engine.dart';
import 'package:angel_trader/services/candle_source.dart';
import 'package:angel_trader/services/fno_study_service.dart';
import 'package:angel_trader/services/study_market_data.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

// ---------------------------------------------------------------------------
// Fakes
// ---------------------------------------------------------------------------

class FakeCandleSource implements CandleSource {
  FakeCandleSource(this.barsByToken);

  final Map<String, List<Candle>> barsByToken;
  final List<String> requestedTokens = [];

  @override
  Future<List<Candle>> fetchDailyCandles({
    required Scrip scrip,
    required DateTime from,
    required DateTime to,
    String interval = 'ONE_DAY',
  }) async {
    requestedTokens.add(scrip.token);
    return barsByToken[scrip.token] ?? const [];
  }
}

class FakeMarket implements StudyMarketData {
  FakeMarket({
    this.quotes = const {},
    this.greeks = const {},
    this.failQuotes = false,
  });

  /// token → full quote.
  final Map<String, MarketQuote> quotes;

  /// `UNDERLYING|EXPIRY` → greek batch.
  final Map<String, OptionGreekBatch> greeks;

  final bool failQuotes;

  final List<List<String>> quoteCalls = [];
  final List<String> greekCalls = [];

  @override
  Future<Map<String, MarketQuote>> fetchQuotesFull(List<Scrip> scrips) async {
    quoteCalls.add(scrips.map((s) => s.token).toList());
    if (failQuotes) {
      throw const ApiException(message: 'quote endpoint down');
    }
    return {
      for (final scrip in scrips)
        if (quotes.containsKey(scrip.token)) scrip.token: quotes[scrip.token]!,
    };
  }

  @override
  Future<OptionGreekBatch> fetchOptionGreeks({
    required String underlying,
    required String expiryLabel,
  }) async {
    greekCalls.add('$underlying|$expiryLabel');
    return greeks['$underlying|$expiryLabel'] ??
        const OptionGreekBatch(byStrike: {}, error: 'no-data');
  }
}

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

final DateTime kEnd = DateTime(2025, 3, 21);

/// A clean up ramp: 63 daily bars from [base] to base + 62.
List<Candle> ramp(int count, {double base = 100}) => [
  for (var i = 0; i < count; i++)
    Candle(
      time: kEnd.subtract(Duration(days: count - 1 - i)),
      open: base + i,
      high: base + i,
      low: base + i,
      close: base + i,
      volume: 1000,
    ),
];

Scrip scrip(String token, String symbol) => Scrip(
  token: token,
  symbol: '$symbol-EQ',
  name: '$symbol Limited',
  exchange: Exchange.nse,
);

MarketQuote quote(String token, String symbol, double ltp, double close) =>
    MarketQuote(
      token: token,
      tradingSymbol: symbol,
      exchange: Exchange.nfo,
      ltp: ltp,
      previousClose: close,
    );

FnoContract contract({
  required String underlying,
  required double strike,
  required String type,
  required String token,
  String expiryLabel = '24APR2025',
  DateTime? expiryDate,
  int lotSize = 75,
}) => FnoContract(
  underlying: underlying,
  expiryLabel: expiryLabel,
  expiryDate: expiryDate ?? DateTime(2025, 4, 24),
  strike: strike,
  optionType: type,
  token: token,
  symbol:
      '$underlying${expiryLabel.substring(0, 5)}'
      '${strike.toStringAsFixed(0)}$type',
  lotSize: lotSize,
);

void main() {
  late CandleDao candles;
  late ScanCacheDao cache;
  late FnoContractDao contracts;

  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close();
    final db = AppDatabase.instance;
    candles = CandleDao(db);
    cache = ScanCacheDao(db);
    contracts = FnoContractDao(db);
  });

  tearDownAll(() async {
    await AppDatabase.instance.close();
  });

  FnoStudyService build(FakeCandleSource source, FakeMarket market) =>
      FnoStudyService(
        source: source,
        candles: candles,
        cache: cache,
        contracts: contracts,
        marketData: market,
      );

  /// `ALPHA` trades at 162.00 → ATM strike 160, lot 75.
  Future<void> seedAlphaBook() => contracts.replaceAll([
    contract(underlying: 'ALPHA', strike: 160, type: 'CE', token: '9001'),
    contract(underlying: 'ALPHA', strike: 160, type: 'PE', token: '9002'),
    contract(underlying: 'BETA', strike: 160, type: 'CE', token: '9003'),
    contract(underlying: 'BETA', strike: 160, type: 'PE', token: '9004'),
  ]);

  test('happy path: rows scored, options priced, snapshot saved', () async {
    await seedAlphaBook();
    final source = FakeCandleSource({'1': ramp(63), '2': ramp(63, base: 200)});
    final market = FakeMarket(
      quotes: {
        '9001': quote('9001', 'ALPHA24APR160CE', 8.5, 6.5),
        '9002': quote('9002', 'ALPHA24APR160PE', 5.0, 4.0),
        '9003': quote('9003', 'BETA24APR160CE', 9.0, 8.0),
        '9004': quote('9004', 'BETA24APR160PE', 6.0, 5.5),
      },
      greeks: {
        'ALPHA|24APR2025': OptionGreekBatch(
          byStrike: {'160.00|CE': 18, '160.00|PE': 22},
        ),
        'BETA|24APR2025': OptionGreekBatch(
          byStrike: {'160.00|CE': 40, '160.00|PE': 44},
        ),
      },
    );

    final result = await build(source, market).run(
      universe: [scrip('1', 'ALPHA'), scrip('2', 'BETA')],
      companyNames: const {'ALPHA': 'Alpha Ltd', 'BETA': 'Beta Ltd'},
      asOf: kEnd,
    );

    expect(result.rows.length, 2);
    expect(result.cancelled, isFalse);
    expect(result.withOptions, 2);
    expect(result.ivFromBroker, 4); // two legs × two stocks
    expect(result.ivFromBlackScholes, 0);
    expect(result.skips, isEmpty);

    final alpha = result.rows.firstWhere((r) => r.symbol == 'ALPHA');
    expect(alpha.companyName, 'Alpha Ltd');
    expect(alpha.trend, Trend3M.strongUp);
    expect(alpha.atmStrike, 160);
    expect(alpha.lotSize, 75);
    expect(alpha.avgIv, closeTo(20, 1e-9));
    expect(alpha.ivSource, IvSource.broker);
    expect(alpha.straddleLtp, closeTo(13.5, 1e-9));
    expect(alpha.straddleYesterday!.points, closeTo(3, 1e-9)); // 13.5 − 10.5
    expect(alpha.straddleYesterday!.rupees, closeTo(225, 1e-9)); // × 75

    // Quotes were asked for in ONE batch (4 tokens), not four calls.
    expect(market.quoteCalls.length, 1);
    expect(market.quoteCalls.single.length, 4);

    // Cheaper IV (20 vs 42) makes ALPHA the best buy and rank 1.
    expect(result.rows.first.symbol, 'ALPHA');
    expect(result.rows.first.isBestBuy, isTrue);
    expect(result.rows.first.rank, 1);
    expect(result.rows.last.symbol, 'BETA');
    expect(result.rows.last.opportunityTag, startsWith('⏸ Watch'));
  });

  test(
    'the selected expiry drives ATM contracts and is saved in the snapshot',
    () async {
      await contracts.replaceAll([
        contract(underlying: 'ALPHA', strike: 160, type: 'CE', token: '9001'),
        contract(underlying: 'ALPHA', strike: 160, type: 'PE', token: '9002'),
        contract(
          underlying: 'ALPHA',
          strike: 160,
          type: 'CE',
          token: '9011',
          expiryLabel: '29MAY2025',
          expiryDate: DateTime(2025, 5, 29),
        ),
        contract(
          underlying: 'ALPHA',
          strike: 160,
          type: 'PE',
          token: '9012',
          expiryLabel: '29MAY2025',
          expiryDate: DateTime(2025, 5, 29),
        ),
      ]);
      final market = FakeMarket(
        quotes: {
          '9011': quote('9011', 'ALPHA29MAY160CE', 8.5, 6.5),
          '9012': quote('9012', 'ALPHA29MAY160PE', 5.0, 4.0),
        },
        greeks: {
          'ALPHA|29MAY2025': const OptionGreekBatch(
            byStrike: {'160.00|CE': 18, '160.00|PE': 22},
          ),
        },
      );

      final result = await build(FakeCandleSource({'1': ramp(63)}), market).run(
        universe: [scrip('1', 'ALPHA')],
        asOf: kEnd,
        selectedExpiry: DateTime(2025, 5, 29),
      );

      final alpha = result.rows.single;
      expect(result.selectedExpiry, DateTime(2025, 5, 29));
      expect(alpha.expiryDate, DateTime(2025, 5, 29));
      expect(alpha.expiryLabel, '29MAY2025');
      expect(market.quoteCalls.single.toSet(), {'9011', '9012'});
      expect(market.greekCalls, ['ALPHA|29MAY2025']);

      final saved = await cache.latestRun(FnoStudyService.cacheKind);
      final meta = saved!.rows.single['meta'] as Map;
      expect(meta['selectedExpiry'], '2025-05-29');
      final cached = await build(
        FakeCandleSource(const {}),
        market,
      ).loadCached();
      expect(cached!.selectedExpiry, DateTime(2025, 5, 29));
    },
  );

  test(
    'an unavailable selected expiry never falls back to the nearest one',
    () async {
      await seedAlphaBook();
      final market = FakeMarket();

      final result = await build(FakeCandleSource({'1': ramp(63)}), market).run(
        universe: [scrip('1', 'ALPHA')],
        asOf: kEnd,
        selectedExpiry: DateTime(2025, 5, 29),
      );

      expect(result.rows.single.expiryDate, isNull);
      expect(result.withOptions, 0);
      expect(market.quoteCalls, isEmpty);
      expect(market.greekCalls, isEmpty);
    },
  );

  test('a stock that moved: the kal jodi uses the kal wala ATM strike', () async {
    // ALKEM-like: previous session closed at 5,100, today it trades at 5,300.
    // The jodi a trader could have bought "kal" is the **5,100** one — pricing
    // it off today's 5,300 strike is what made every trending stock look like a
    // loss (the user's bug report).
    await contracts.replaceAll([
      contract(underlying: 'ALKEM', strike: 5100, type: 'CE', token: '7001'),
      contract(underlying: 'ALKEM', strike: 5100, type: 'PE', token: '7002'),
      contract(underlying: 'ALKEM', strike: 5300, type: 'CE', token: '7003'),
      contract(underlying: 'ALKEM', strike: 5300, type: 'PE', token: '7004'),
    ]);

    final bars = <Candle>[
      for (var i = 0; i < 62; i++)
        Candle(
          time: kEnd.subtract(Duration(days: 62 - i)),
          open: 5100,
          high: 5105,
          low: 5095,
          close: 5100,
          volume: 1000,
        ),
      Candle(
        time: kEnd,
        open: 5150,
        high: 5305,
        low: 5140,
        close: 5300,
        volume: 4000,
      ),
    ];
    final source = FakeCandleSource({'1': bars});
    final market = FakeMarket(
      quotes: {
        // 5,100 legs: what they cost kal (close) and what they fetch today.
        '7001': quote('7001', 'ALKEM24APR5100CE', 260, 120),
        '7002': quote('7002', 'ALKEM24APR5100PE', 30, 118),
        // 5,300 legs — today's ATM pair.
        '7003': quote('7003', 'ALKEM24APR5300CE', 130, 55),
        '7004': quote('7004', 'ALKEM24APR5300PE', 125, 215),
      },
      greeks: {
        'ALKEM|24APR2025': OptionGreekBatch(
          byStrike: {'5300.00|CE': 26, '5300.00|PE': 28},
        ),
      },
    );

    final result = await build(source, market).run(
      universe: [scrip('1', 'ALKEM')],
      companyNames: const {'ALKEM': 'Alkem Laboratories Ltd'},
      asOf: kEnd,
    );
    final row = result.rows.single;

    expect(row.atmStrike, 5300, reason: 'aaj ka ATM');
    expect(row.kalStrike, 5100, reason: 'kal ka ATM (prev session close)');
    expect(row.kalJodiBase, closeTo(238, 1e-9)); // 120 + 118 (kal ka buy)
    expect(row.kalJodiNow, closeTo(290, 1e-9)); // 260 + 30 (aaj ki value)
    expect(
      row.straddleYesterday!.points,
      closeTo(52, 1e-9),
      reason: '290 − 238 — priced on 5,100, NOT on today\'s 5,300 pair',
    );
    expect(row.straddleYesterday!.rupees, closeTo(52 * 75, 1e-9));

    // Both pairs rode in the same batch, each token asked for once.
    expect(market.quoteCalls.length, 1);
    expect(
      market.quoteCalls.single.toSet().length,
      market.quoteCalls.single.length,
    );
    expect(market.quoteCalls.single.toSet(), {'7001', '7002', '7003', '7004'});
  });

  test('an unmoved stock asks for two tokens, not four', () async {
    await seedAlphaBook();
    final source = FakeCandleSource({'1': ramp(63)});
    final market = FakeMarket(
      quotes: {
        '9001': quote('9001', 'ALPHA24APR160CE', 8.5, 6.5),
        '9002': quote('9002', 'ALPHA24APR160PE', 5.0, 4.0),
      },
    );

    final result = await build(source, market).run(
      universe: [scrip('1', 'ALPHA')],
      companyNames: const {'ALPHA': 'Alpha Ltd'},
      asOf: kEnd,
    );
    final row = result.rows.single;

    expect(
      row.kalStrike,
      row.atmStrike,
      reason: 'same strike → kal ka pair = aaj ka pair',
    );
    expect(market.quoteCalls.single, [
      '9001',
      '9002',
    ], reason: 'deduped: no repeat quote for the same contracts');
    expect(row.straddleYesterday!.points, closeTo(3, 1e-9));
  });

  test('second scan is served from the candle cache', () async {
    await seedAlphaBook();
    final source = FakeCandleSource({'1': ramp(63)});
    final market = FakeMarket();
    final service = build(source, market);

    await service.run(universe: [scrip('1', 'ALPHA')], asOf: kEnd);
    expect(source.requestedTokens, ['1']);

    await service.run(universe: [scrip('1', 'ALPHA')], asOf: kEnd);
    expect(source.requestedTokens, ['1'], reason: 'no repeat download');
  });

  test('quote failure degrades the study instead of dropping stocks', () async {
    await seedAlphaBook();
    final source = FakeCandleSource({'1': ramp(63)});
    final market = FakeMarket(failQuotes: true);

    final result = await build(
      source,
      market,
    ).run(universe: [scrip('1', 'ALPHA')], asOf: kEnd);

    expect(result.rows.length, 1, reason: 'the stock is still in the table');
    final row = result.rows.single;
    expect(row.avgIv, isNull);
    expect(row.ce?.ltp, isNull);
    expect(row.atmStrike, 160, reason: 'the strike came from the local book');
    expect(row.trend, Trend3M.strongUp, reason: 'trend maths is unaffected');
    expect(row.score, greaterThan(0));
    expect(result.degraded, 1);

    // And the reason is on record.
    final notice = result.skips.firstWhere((s) => s.symbol == kOptionsNotice);
    expect(notice.reason, contains('degraded'));
  });

  test('missing greeks fall back to Black-Scholes from the premium', () async {
    await seedAlphaBook();
    final source = FakeCandleSource({'1': ramp(63)});
    final market = FakeMarket(
      quotes: {
        '9001': quote('9001', 'ALPHA24APR160CE', 8.5, 6.5),
        '9002': quote('9002', 'ALPHA24APR160PE', 5.0, 4.0),
      },
    ); // no greeks at all → endpoint unavailable

    final result = await build(
      source,
      market,
    ).run(universe: [scrip('1', 'ALPHA')], asOf: kEnd);

    final row = result.rows.single;
    expect(row.ce!.ivSource, IvSource.blackScholes);
    expect(row.pe!.ivSource, IvSource.blackScholes);
    expect(row.avgIv, isNotNull);
    expect(row.avgIv!, greaterThan(1));
    expect(row.avgIv!, lessThan(400));
    expect(row.edgePct, isNotNull);
    expect(result.ivFromBlackScholes, 2);
    expect(result.ivFromBroker, 0);
    expect(market.greekCalls.length, 1); // one call for the whole chain
  });

  // ---- B1: where IV comes from is the user's call ------------------------

  test('"apna hisaab" asks the broker nothing at all', () async {
    await seedAlphaBook();
    final source = FakeCandleSource({'1': ramp(63)});
    final market = FakeMarket(
      quotes: {
        '9001': quote('9001', 'ALPHA24APR160CE', 8.5, 6.5),
        '9002': quote('9002', 'ALPHA24APR160PE', 5.0, 4.0),
      },
      greeks: {
        'ALPHA|24APR2025': const OptionGreekBatch(
          byStrike: {'160.00|CE': 31.5, '160.00|PE': 30.2},
        ),
      },
    );

    final result = await build(source, market).run(
      universe: [scrip('1', 'ALPHA')],
      asOf: kEnd,
      ivSource: StudyIvSource.blackScholes,
    );

    // The whole point: not one greek request on a scan that would normally
    // make one per stock (~213 on the real universe).
    expect(market.greekCalls, isEmpty);
    // …and IV did not disappear — it was solved from the premium instead.
    final row = result.rows.single;
    expect(row.ce!.ivSource, IvSource.blackScholes);
    expect(row.avgIv, isNotNull);
    expect(result.ivFromBlackScholes, 2);
    expect(result.ivFromBroker, 0);
  });

  test('"sirf broker" invents nothing when the broker has no IV', () async {
    await seedAlphaBook();
    final source = FakeCandleSource({'1': ramp(63)});
    // Premiums are there (so Black-Scholes *could* solve), but no greeks.
    final market = FakeMarket(
      quotes: {
        '9001': quote('9001', 'ALPHA24APR160CE', 8.5, 6.5),
        '9002': quote('9002', 'ALPHA24APR160PE', 5.0, 4.0),
      },
    );

    final result = await build(source, market).run(
      universe: [scrip('1', 'ALPHA')],
      asOf: kEnd,
      ivSource: StudyIvSource.broker,
    );

    final row = result.rows.single;
    expect(row.ce!.iv, isNull);
    expect(row.pe!.iv, isNull);
    expect(row.ce!.ivSource, IvSource.none);
    expect(row.avgIv, isNull, reason: 'blank, not a number we made up');
    expect(result.ivFromBroker, 0);
    expect(result.ivFromBlackScholes, 0);
    // The row itself survives — no IV is a degraded row, not a missing one.
    expect(row.score, isNotNull);
  });

  test(
    '"auto" behaves exactly as before: broker first, maths as backup',
    () async {
      await seedAlphaBook();
      final source = FakeCandleSource({'1': ramp(63)});
      final market = FakeMarket(
        quotes: {
          '9001': quote('9001', 'ALPHA24APR160CE', 8.5, 6.5),
          '9002': quote('9002', 'ALPHA24APR160PE', 5.0, 4.0),
        },
      );

      final result = await build(source, market).run(
        universe: [scrip('1', 'ALPHA')],
        asOf: kEnd,
        ivSource: StudyIvSource.auto,
      );

      expect(market.greekCalls.length, 1, reason: 'the broker is still asked');
      final row = result.rows.single;
      expect(
        row.ce!.ivSource,
        IvSource.blackScholes,
        reason: 'no broker IV came back, so the fallback covered it',
      );
      expect(row.avgIv, isNotNull);
    },
  );

  test('the IV setting survives a settings round-trip', () {
    for (final source in StudyIvSource.values) {
      final saved = AppSettings().copyWith(studyIvSource: source.name).toMap();
      final loaded = AppSettings.fromMap(saved);
      expect(
        StudyIvSource.fromName(loaded.studyIvSource),
        source,
        reason: '${source.name} must come back unchanged',
      );
    }
    // A value we have never heard of must not break a scan.
    expect(StudyIvSource.fromName('garbage'), StudyIvSource.auto);
    expect(StudyIvSource.fromName(null), StudyIvSource.auto);
    expect(AppSettings().studyIvSource, 'auto', reason: 'default = aaj jaisa');
  });

  test('no contract in the local book → degraded, never skipped', () async {
    // ALPHA has no option contracts stored (the master refresh has not run yet).
    final source = FakeCandleSource({'1': ramp(63)});
    final market = FakeMarket();

    final result = await build(
      source,
      market,
    ).run(universe: [scrip('1', 'ALPHA')], asOf: kEnd);

    expect(result.rows.length, 1);
    expect(result.rows.single.atmStrike, isNull);
    expect(result.rows.single.avgIv, isNull);
    expect(result.withOptions, 0);
    expect(market.quoteCalls, isEmpty); // nothing to quote
    expect(market.greekCalls, isEmpty);
  });

  test('short history is skipped with a readable reason', () async {
    await seedAlphaBook();
    final source = FakeCandleSource({
      '1': ramp(63),
      '2': ramp(40, base: 300), // too little history
      '3': const [], // nothing at all
    });

    final result = await build(source, FakeMarket()).run(
      universe: [scrip('1', 'ALPHA'), scrip('2', 'SHORT'), scrip('3', 'GHOST')],
      asOf: kEnd,
    );

    expect(result.rows.length, 1);
    expect(result.skips.length, 2); // both stocks, no option notice here
    final short = result.skips.firstWhere((s) => s.symbol == 'SHORT');
    expect(short.reason, contains('40'));
    expect(short.reason, contains('60'));
    final ghost = result.skips.firstWhere((s) => s.symbol == 'GHOST');
    expect(ghost.reason, contains('candle'));
  });

  test('cancelling stops the run and keeps what was finished', () async {
    await seedAlphaBook();
    final source = FakeCandleSource({
      '1': ramp(63),
      '2': ramp(63, base: 200),
      '3': ramp(63, base: 300),
    });

    var calls = 0;
    final result = await build(source, FakeMarket()).run(
      universe: [scrip('1', 'ALPHA'), scrip('2', 'BETA'), scrip('3', 'GAMMA')],
      asOf: kEnd,
      isCancelled: () => calls++ > 0, // cancel right after the first instrument
    );

    expect(result.cancelled, isTrue);
    expect(result.rows.length, 1);
    expect(result.rows.single.symbol, 'ALPHA');
  });

  test('progress reports every phase and never goes backwards', () async {
    await seedAlphaBook();
    final source = FakeCandleSource({'1': ramp(63), '2': ramp(63, base: 200)});
    final market = FakeMarket(
      quotes: {
        '9001': quote('9001', 'ALPHA24APR160CE', 8.5, 6.5),
        '9002': quote('9002', 'ALPHA24APR160PE', 5.0, 4.0),
      },
      greeks: {
        'ALPHA|24APR2025': OptionGreekBatch(byStrike: {'160.00|CE': 18}),
      },
    );

    final stages = <StudyStage>[];
    var last = -1.0;
    await build(source, market).run(
      universe: [scrip('1', 'ALPHA'), scrip('2', 'BETA')],
      asOf: kEnd,
      onProgress: (progress) {
        if (stages.isEmpty || stages.last != progress.stage) {
          stages.add(progress.stage);
        }
        expect(progress.fraction, greaterThanOrEqualTo(last));
        expect(progress.fraction, lessThanOrEqualTo(1.0));
        last = progress.fraction;
      },
    );

    expect(stages.first, StudyStage.candles);
    expect(stages.last, StudyStage.scoring);
    expect(stages, contains(StudyStage.quotes));
    expect(stages, contains(StudyStage.greeks));
  });

  test('the snapshot reloads with the same rows and ranks', () async {
    await seedAlphaBook();
    final source = FakeCandleSource({'1': ramp(63), '2': ramp(63, base: 200)});
    final market = FakeMarket(
      quotes: {
        '9001': quote('9001', 'ALPHA24APR160CE', 8.5, 6.5),
        '9002': quote('9002', 'ALPHA24APR160PE', 5.0, 4.0),
        '9003': quote('9003', 'BETA24APR160CE', 9.0, 8.0),
        '9004': quote('9004', 'BETA24APR160PE', 6.0, 5.5),
      },
      greeks: {
        'ALPHA|24APR2025': OptionGreekBatch(
          byStrike: {'160.00|CE': 18, '160.00|PE': 22},
        ),
        'BETA|24APR2025': OptionGreekBatch(
          byStrike: {'160.00|CE': 40, '160.00|PE': 44},
        ),
      },
    );
    final service = build(source, market);

    final fresh = await service.run(
      universe: [scrip('1', 'ALPHA'), scrip('2', 'BETA')],
      companyNames: const {'ALPHA': 'Alpha Ltd'},
      asOf: kEnd,
    );

    final cached = await service.loadCached();
    expect(cached, isNotNull);
    expect(cached!.fromCacheOnly, isTrue);
    expect(cached.asOf, DateTime(2025, 3, 21));
    expect(cached.rows.length, fresh.rows.length);
    for (var i = 0; i < fresh.rows.length; i++) {
      expect(cached.rows[i].symbol, fresh.rows[i].symbol);
      expect(cached.rows[i].rank, fresh.rows[i].rank);
      expect(cached.rows[i].score, closeTo(fresh.rows[i].score, 1e-9));
      expect(cached.rows[i].opportunityTag, fresh.rows[i].opportunityTag);
      expect(cached.rows[i].avgIv, fresh.rows[i].avgIv);
    }
    expect(cached.rows.first.companyName, 'Alpha Ltd');
  });

  test('clearSnapshot empties the stored run', () async {
    final source = FakeCandleSource({'1': ramp(63)});
    final service = build(source, FakeMarket());

    await service.run(universe: [scrip('1', 'ALPHA')], asOf: kEnd);
    expect(await service.loadCached(), isNotNull);

    await service.clearCache();
    expect(await service.loadCached(), isNull);
  });

  test('the whole universe is scanned — there is no cap', () async {
    // 213 is the real F&O list size; the study must cover every resolved stock
    // rather than stopping at some "stocks per scan" number.
    const total = 213;
    final source = FakeCandleSource({
      for (var i = 0; i < total; i++) '$i': ramp(63, base: 100 + i.toDouble()),
    });
    final service = build(source, FakeMarket());

    final result = await service.run(
      universe: [for (var i = 0; i < total; i++) scrip('$i', 'S$i')],
      asOf: kEnd,
    );

    expect(result.universeSize, total);
    expect(result.scanned, total);
    expect(result.rows.length, total);
    expect(source.requestedTokens.length, total);
    expect(result.skips, isEmpty);
  });

  test('an explicit limit is still honoured when asked for', () async {
    // Kept for tests and a future "top N" tool — the UI never passes it.
    final source = FakeCandleSource({
      for (var i = 0; i < 20; i++) '$i': ramp(63, base: 100 + i.toDouble()),
    });

    final result = await build(source, FakeMarket()).run(
      universe: [for (var i = 0; i < 20; i++) scrip('$i', 'S$i')],
      maxStocks: 10,
      asOf: kEnd,
    );

    expect(result.universeSize, 10);
    expect(result.rows.length, 10);
    expect(source.requestedTokens.length, 10);
  });

  test(
    'the OTM jodi is picked at ~half the ATM jodi and priced from quotes',
    () async {
      // ALPHA closes at 160 → ATM 160, with two OTM steps each side.
      await contracts.replaceAll([
        contract(underlying: 'ALPHA', strike: 140, type: 'CE', token: '9031'),
        contract(underlying: 'ALPHA', strike: 140, type: 'PE', token: '9014'),
        contract(underlying: 'ALPHA', strike: 150, type: 'CE', token: '9041'),
        contract(underlying: 'ALPHA', strike: 150, type: 'PE', token: '9012'),
        contract(underlying: 'ALPHA', strike: 160, type: 'CE', token: '9001'),
        contract(underlying: 'ALPHA', strike: 160, type: 'PE', token: '9002'),
        contract(underlying: 'ALPHA', strike: 170, type: 'CE', token: '9021'),
        contract(underlying: 'ALPHA', strike: 170, type: 'PE', token: '9042'),
        contract(underlying: 'ALPHA', strike: 180, type: 'CE', token: '9051'),
        contract(underlying: 'ALPHA', strike: 180, type: 'PE', token: '9052'),
      ]);
      final source = FakeCandleSource({'1': ramp(61)}); // closes 100 … 160
      final market = FakeMarket(
        quotes: {
          '9001': quote('9001', 'ALPHA24APR160CE', 8.5, 6.5),
          '9002': quote('9002', 'ALPHA24APR160PE', 5.0, 4.0),
          '9021': quote('9021', 'ALPHA24APR170CE', 3.0, 2.0),
          '9012': quote('9012', 'ALPHA24APR150PE', 2.5, 1.5),
          '9051': quote('9051', 'ALPHA24APR180CE', 1.0, 0.9),
          '9014': quote('9014', 'ALPHA24APR140PE', 0.8, 0.7),
        },
        greeks: {
          'ALPHA|24APR2025': OptionGreekBatch(
            byStrike: {'160.00|CE': 18, '160.00|PE': 22},
          ),
        },
      );

      final row = (await build(
        source,
        market,
      ).run(universe: [scrip('1', 'ALPHA')], asOf: kEnd)).rows.single;

      expect(row.strangle, isNotNull, reason: 'the chain has OTM strikes');
      final strangle = row.strangle!;
      // The rule: aim at half of what the ATM jodi costs (8.50 + 5.00).
      expect(strangle.targetPremium, closeTo(6.75, 1e-9));
      // OTM: CE above the money, PE below it, one step out.
      expect(strangle.ce!.strike, 170);
      expect(strangle.pe!.strike, 150);
      // Premiums are the broker's, not the estimate's.
      expect(strangle.total, closeTo(5.5, 1e-9)); // 3.00 + 2.50

      // "Kal" wala OTM jodi: same strikes, priced at yesterday's close.
      expect(row.kalStrangle, isNotNull);
      expect(row.kalStrangle!.buyCost, closeTo(3.5, 1e-9)); // 2.00 + 1.50
      expect(row.kalStrangle!.total, closeTo(5.5, 1e-9));
      expect(
        row.kalStrangle!.yesterday(row.lotSize)!.rupees,
        closeTo(150, 1e-9),
      );
    },
  );

  test(
    'a chain with no OTM strikes leaves the row without an OTM jodi',
    () async {
      // seedAlphaBook only carries strike 160 — nothing above/below the money.
      await seedAlphaBook();
      final source = FakeCandleSource({'1': ramp(63)});
      final market = FakeMarket(
        quotes: {
          '9001': quote('9001', 'ALPHA24APR160CE', 8.5, 6.5),
          '9002': quote('9002', 'ALPHA24APR160PE', 5.0, 4.0),
        },
        greeks: {
          'ALPHA|24APR2025': OptionGreekBatch(
            byStrike: {'160.00|CE': 18, '160.00|PE': 22},
          ),
        },
      );

      final row = (await build(
        source,
        market,
      ).run(universe: [scrip('1', 'ALPHA')], asOf: kEnd)).rows.single;

      expect(row.strangle, isNull);
      expect(row.kalStrangle, isNull);
      expect(row.ce, isNotNull, reason: 'the ATM jodi is untouched');
    },
  );

  test('the day-over-day edge matches ATR% minus IV/sqrt(252)', () async {
    await seedAlphaBook();
    final source = FakeCandleSource({'1': ramp(63)});
    final market = FakeMarket(
      quotes: {
        '9001': quote('9001', 'ALPHA24APR160CE', 8.5, 6.5),
        '9002': quote('9002', 'ALPHA24APR160PE', 5.0, 4.0),
      },
      greeks: {
        'ALPHA|24APR2025': OptionGreekBatch(
          byStrike: {'160.00|CE': 18, '160.00|PE': 22},
        ),
      },
    );

    final row = (await build(
      source,
      market,
    ).run(universe: [scrip('1', 'ALPHA')], asOf: kEnd)).rows.single;

    expect(row.avgIv, closeTo(20, 1e-9));
    expect(row.edgePct, closeTo(row.atrPct - 20 / math.sqrt(252), 1e-9));
  });
}
