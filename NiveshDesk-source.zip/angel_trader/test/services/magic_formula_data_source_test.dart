import 'dart:convert';
import 'dart:io';

import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/data/local/dao/scrip_dao.dart';
import 'package:angel_trader/features/magic_formula/magic_formula_engine.dart';
import 'package:angel_trader/features/magic_formula/magic_formula_models.dart';
import 'package:angel_trader/services/magic_formula_data_source.dart';
import 'package:angel_trader/services/nse_listing_service.dart';
import 'package:archive/archive.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

const _fixtures = 'test/fixtures/magic_formula';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late AppDatabase db;
  late SettingsDao settings;

  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close();
    db = AppDatabase.instance;
    settings = SettingsDao(db);
  });

  tearDown(() async {
    await AppDatabase.instance.close();
    AppDatabase.overridePath = null;
  });

  test('public NSE transport never sends or retains a Cookie header', () async {
    final client = _RecordingClient();
    final transport = NseMagicFormulaHttp(client: client);

    await transport.get(
      Uri.https('www.nseindia.com', '/api/quote-equity', {'symbol': 'ACME'}),
      refererPath: '/companies-listing/corporate-integrated-filing',
    );

    expect(client.requests, hasLength(1));
    expect(
      client.requests.single.headers.keys.map((key) => key.toLowerCase()),
      isNot(contains('cookie')),
    );
    expect(
      client.requests.single.headers['Referer'],
      'https://www.nseindia.com/companies-listing/corporate-integrated-filing',
    );
    transport.close();
  });

  test('binary NSE transport preserves bytes without sending Cookie', () async {
    final client = _RecordingClient();
    final transport = NseMagicFormulaHttp(client: client);

    final bytes = await transport.getBytes(
      Uri.https('nsearchives.nseindia.com', '/content/cm/bhavcopy.zip'),
      refererPath: NseMagicFormulaDataSource.bhavcopyReferer,
    );

    expect(utf8.decode(bytes), 'fixture response');
    expect(
      client.requests.single.headers.keys.map((key) => key.toLowerCase()),
      isNot(contains('cookie')),
    );
    expect(
      client.requests.single.headers['Referer'],
      'https://www.nseindia.com/all-reports',
    );
    transport.close();
  });

  test('surfaces NSE HTTP 403 as a scan-wide access block', () async {
    final client = _RecordingClient(responseStatus: 403);
    final transport = NseMagicFormulaHttp(client: client);

    await expectLater(
      transport.get(Uri.https('www.nseindia.com', '/api/quote-equity')),
      throwsA(
        isA<NseMagicFormulaHttpException>()
            .having((error) => error.statusCode, 'statusCode', 403)
            .having((error) => error.shouldStopScan, 'shouldStopScan', isTrue)
            .having(
              (error) => error.userMessage,
              'userMessage',
              contains('HTTP 403'),
            ),
      ),
    );
    transport.close();
  });

  test(
    'source propagates a feed-wide 403 instead of making a skipped row',
    () async {
      final source = _source(
        db,
        settings,
        '{}',
        getOverride: (uri, {refererPath}) async {
          throw NseMagicFormulaHttpException(statusCode: 403, uri: uri);
        },
      );

      await expectLater(
        source.fetchFundamentals(_candidate),
        throwsA(isA<NseMagicFormulaHttpException>()),
      );
    },
  );

  test('XBRL archive 403 also bubbles up to stop the whole scan', () async {
    final source = _source(
      db,
      settings,
      _readFixture('integrated_filings.json'),
      archiveTransform: (_) => throw NseMagicFormulaHttpException(
        statusCode: 403,
        uri: Uri.https('nsearchives.nseindia.com', '/fixture.xml'),
      ),
    );

    await expectLater(
      source.fetchFundamentals(_candidate),
      throwsA(isA<NseMagicFormulaHttpException>()),
    );
  });

  test(
    'parses the official constituent CSV columns and sector labels offline',
    () {
      const csv =
          '\uFEFFSymbol,Company Name,Industry,ISIN Code\r\n'
          'ACME,"Acme, Example Limited",Financial Services,INE000A01000\r\n';

      final candidates = NseMagicFormulaDataSource.parseIndexCsv(csv);

      expect(candidates, hasLength(1));
      expect(candidates.single.symbol, 'ACME');
      expect(candidates.single.companyName, 'Acme, Example Limited');
      expect(candidates.single.sector, 'Financial Services');
      expect(candidates.single.cacheKey, 'ISIN:INE000A01000');
    },
  );

  // NOTE: the third fixture row is series N1 (debt) — cash-equity groups
  // including SME (SM) and REIT (RR) parse; debt/ETF rows stay out.
  test('parses UDiFF EOD closes by ISIN and filters non-common series', () {
    final quotes = NseMagicFormulaDataSource.parseBhavcopyCsv(
      _readFixture('bhavcopy_20261016.csv'),
    );

    expect(quotes, hasLength(2));
    final alpha = quotes.singleWhere((quote) => quote.isin == 'INE000A01000');
    expect(alpha.symbol, 'ACME');
    expect(alpha.series, 'EQ');
    expect(alpha.closePrice, 100);
    expect(alpha.tradeDate, DateTime(2026, 10, 16));

    final beta = quotes.singleWhere((quote) => quote.symbol == 'BECO');
    expect(beta.series, 'BE');
    expect(beta.closePrice, 20);
  });

  test(
    'reads the XBRL fixture and prefers complete consolidated statements',
    () async {
      var byteRequests = 0;
      final source = _source(
        db,
        settings,
        _readFixture('integrated_filings.json'),
        getBytesOverride: (uri, {refererPath}) async {
          byteRequests++;
          if (uri.path.contains('_20261017_')) {
            throw NseMagicFormulaHttpException(statusCode: 404, uri: uri);
          }
          if (uri.path.contains('_20261016_')) return _zipBhavcopyFixture();
          throw StateError('Unexpected fixture byte request: $uri');
        },
      );

      final row = await source.fetchFundamentals(_candidate);

      expect(row.statementBasis, 'Consolidated');
      expect(row.marketCapCr, 10000);
      expect(row.marketPriceAsOf, DateTime(2026, 10, 16));
      expect(row.ebitTtmCr, 2170);
      expect(row.totalDebtCr, 3000);
      expect(row.cashCr, 1000);
      expect(row.totalAssetsCr, 50000);
      expect(row.currentLiabilitiesCr, 10000);
      expect(row.candidate.sector, 'Financial Services');
      expect(row.missingReason, isEmpty);

      await source.fetchFundamentals(_candidate);
      expect(
        byteRequests,
        2,
        reason: 'the last available trading-date snapshot is cached for today',
      );

      final ranked = MagicFormulaEngine.rank([row]).ranked.single;
      expect(ranked.rocePct, closeTo(2170 / 40000 * 100, 1e-10));
      expect(ranked.earningsYieldPct, closeTo(2170 / 12000 * 100, 1e-10));
    },
  );

  test(
    'resolves same-date XBRL contexts and reads share capital from quarter facts',
    () async {
      final source = _source(
        db,
        settings,
        _readFixture('integrated_filings.json'),
        archiveTransform: (xml) {
          var updated = xml
              .replaceAll('OneI', 'BalanceAtClose')
              .replaceAll('OneD', 'QuarterDuration')
              .replaceAll(
                'PaidUpValueOfEquityShareCapital contextRef="BalanceAtClose"',
                'PaidUpValueOfEquityShareCapital contextRef="QuarterDuration"',
              )
              .replaceAll(
                'FaceValueOfEquityShareCapital contextRef="BalanceAtClose"',
                'FaceValueOfEquityShareCapital contextRef="QuarterDuration"',
              )
              .replaceAll(
                'contextRef="BalanceAtClose"',
                'contextRef="FinancialBalanceContext"',
              );
          final instantDate = RegExp(
            r'<xbrli:instant>([^<]+)</xbrli:instant>',
          ).firstMatch(updated)?.group(1);
          if (instantDate != null) {
            updated = updated.replaceFirst(
              '</xbrli:xbrl>',
              '<xbrli:context id="FinancialBalanceContext">'
                  '<xbrli:entity><xbrli:identifier scheme="">'
                  'INE000A01000</xbrli:identifier></xbrli:entity>'
                  '<xbrli:period><xbrli:instant>$instantDate</xbrli:instant>'
                  '</xbrli:period></xbrli:context></xbrli:xbrl>',
            );
          }
          if (xml.contains('<xbrli:instant>2026-03-31</xbrli:instant>')) {
            updated = updated.replaceFirst(
              'xmlns:ind-as="https://www.nseindia.com/xbrl/ind-as"',
              'xmlns:ind-as="https://www.nseindia.com/xbrl/ind-as" '
                  'xmlns:xbrldi="http://xbrl.org/2006/xbrldi"',
            );
            updated = updated.replaceFirst(
              '</xbrli:xbrl>',
              '<xbrli:context id="SegmentInstant">'
                  '<xbrli:entity><xbrli:identifier scheme="">'
                  'INE000A01000</xbrli:identifier><xbrli:segment>'
                  '<xbrldi:explicitMember dimension="ind-as:Segment">Metal'
                  '</xbrldi:explicitMember></xbrli:segment></xbrli:entity>'
                  '<xbrli:period><xbrli:instant>2026-03-31</xbrli:instant>'
                  '</xbrli:period></xbrli:context>'
                  '<ind-as:Assets contextRef="SegmentInstant" unitRef="INR">'
                  '999000000000000</ind-as:Assets></xbrli:xbrl>',
            );
          }
          return updated;
        },
      );

      final row = await source.fetchFundamentals(_candidate);

      expect(row.marketCapCr, 10000);
      expect(row.marketPriceAsOf, DateTime(2026, 10, 16));
      expect(row.ebitTtmCr, 2170);
      expect(row.totalDebtCr, 3000);
      expect(row.cashCr, 1000);
      expect(row.totalAssetsCr, 50000);
      expect(row.currentLiabilitiesCr, 10000);
      expect(row.balanceSheetDate, DateTime(2026, 3, 31));
      expect(row.missingReason, isEmpty);
    },
  );

  test('does not use older-date balance facts as a fallback', () async {
    final source = _source(
      db,
      settings,
      _readFixture('integrated_filings.json'),
      archiveTransform: (xml) {
        if (!xml.contains('<xbrli:instant>2026-03-31</xbrli:instant>')) {
          return xml;
        }
        var updated = xml;
        for (final tag in const [
          'Assets',
          'CurrentLiabilities',
          'TotalBorrowings',
          'CashAndCashEquivalents',
        ]) {
          updated = updated.replaceAll(
            '<ind-as:$tag contextRef="OneI"',
            '<ind-as:$tag contextRef="OlderBalance"',
          );
        }
        return updated.replaceFirst(
          '</xbrli:xbrl>',
          '<xbrli:context id="OlderBalance">'
              '<xbrli:entity><xbrli:identifier scheme="">'
              'INE000A01000</xbrli:identifier></xbrli:entity>'
              '<xbrli:period><xbrli:instant>2025-12-31</xbrli:instant>'
              '</xbrli:period></xbrli:context></xbrli:xbrl>',
        );
      },
    );

    final row = await source.fetchFundamentals(_candidate);

    expect(row.balanceSheetDate, DateTime(2026, 3, 31));
    expect(row.totalDebtCr, isNull);
    expect(row.cashCr, isNull);
    expect(row.totalAssetsCr, isNull);
    expect(row.currentLiabilitiesCr, isNull);
    expect(row.missingReason, contains('Total Debt'));
    expect(row.missingReason, contains('Cash & Equivalents'));
    expect(row.missingReason, contains('Total Assets'));
    expect(row.missingReason, contains('Current Liabilities'));
  });

  test('uses the newest official half-year balance sheet when the quarter '
      'filing has none (SEBI half-yearly BS rule)', () async {
    // Q1/Q3 Integrated Filing quarters carry P&L + share capital but no
    // Statement of Assets and Liabilities (filed half-yearly). The scan must
    // then use the newest already-selected filing that has one — here the
    // 31-Dec-2025 half-year statement — with its own date displayed.
    final source = _source(
      db,
      settings,
      _readFixture('integrated_filings.json'),
      archiveTransform: (xml) {
        if (!xml.contains('<xbrli:instant>2026-03-31</xbrli:instant>')) {
          return xml;
        }
        var updated = xml;
        for (final tag in const [
          'Assets',
          'CurrentLiabilities',
          'TotalBorrowings',
          'CashAndCashEquivalents',
        ]) {
          updated = updated.replaceAll(
            RegExp('<ind-as:$tag [^>]*>[^<]*</ind-as:$tag>'),
            '',
          );
        }
        return updated;
      },
    );

    final row = await source.fetchFundamentals(_candidate);

    expect(row.periodEnd, DateTime(2026, 3, 31));
    expect(row.balanceSheetDate, DateTime(2025, 12, 31));
    expect(row.ebitTtmCr, 2170);
    expect(row.marketCapCr, 10000);
    expect(row.totalDebtCr, 3000);
    expect(row.cashCr, 1000);
    expect(row.totalAssetsCr, 50000);
    expect(row.currentLiabilitiesCr, 10000);
    expect(row.missingReason, isEmpty);

    final ranked = MagicFormulaEngine.rank([row]).ranked.single;
    expect(ranked.rocePct, closeTo(2170 / 40000 * 100, 1e-10));
    expect(ranked.earningsYieldPct, closeTo(2170 / 12000 * 100, 1e-10));
  });

  test(
    'does not mix older filings into a partial quarter balance sheet',
    () async {
      // A filing that HAS balance-sheet facts but is missing some of them is
      // suspect, not "half-yearly absent" — the missing fields stay missing
      // instead of being copied from an older filing.
      final source = _source(
        db,
        settings,
        _readFixture('integrated_filings.json'),
        archiveTransform: (xml) {
          if (!xml.contains('<xbrli:instant>2026-03-31</xbrli:instant>')) {
            return xml;
          }
          var updated = xml;
          for (final tag in const [
            'Assets',
            'CurrentLiabilities',
            'TotalBorrowings',
          ]) {
            updated = updated.replaceAll(
              RegExp('<ind-as:$tag [^>]*>[^<]*</ind-as:$tag>'),
              '',
            );
          }
          return updated;
        },
      );

      final row = await source.fetchFundamentals(_candidate);

      expect(row.balanceSheetDate, DateTime(2026, 3, 31));
      expect(row.cashCr, 1000);
      expect(row.totalAssetsCr, isNull);
      expect(row.totalDebtCr, isNull);
      expect(row.currentLiabilitiesCr, isNull);
      expect(row.missingReason, contains('Total Assets'));
      expect(row.missingReason, contains('Total Debt'));
      expect(row.missingReason, contains('Current Liabilities'));
    },
  );

  test(
    'explains the half-yearly balance-sheet gap in the skip reason',
    () async {
      final source = _source(
        db,
        settings,
        _readFixture('integrated_filings.json'),
        archiveTransform: (xml) {
          var updated = xml;
          for (final tag in const [
            'Assets',
            'CurrentLiabilities',
            'TotalBorrowings',
            'CashAndCashEquivalents',
          ]) {
            updated = updated.replaceAll(
              RegExp('<ind-as:$tag [^>]*>[^<]*</ind-as:$tag>'),
              '',
            );
          }
          return updated;
        },
      );

      final row = await source.fetchFundamentals(_candidate);

      expect(row.totalDebtCr, isNull);
      expect(row.cashCr, isNull);
      expect(row.totalAssetsCr, isNull);
      expect(row.currentLiabilitiesCr, isNull);
      expect(row.missingReason, contains('Total Assets'));
      expect(row.missingReason, contains('half-yearly'));
      expect(
        MagicFormulaEngine.rank([row]).skipped.single.reason,
        contains('half-yearly'),
      );
    },
  );

  test(
    'falls back to standalone when consolidated data is incomplete',
    () async {
      final source = _source(
        db,
        settings,
        _readFixture('integrated_filings_missing_consolidated_debt.json'),
      );

      final row = await source.fetchFundamentals(_candidate);

      expect(row.statementBasis, 'Standalone');
      expect(row.totalDebtCr, 3000);
      expect(row.missingReason, isEmpty);
    },
  );

  test('does not mistake one generic Borrowings fact for total debt', () async {
    final source = _source(
      db,
      settings,
      _readFixture('integrated_filings.json'),
      archiveTransform: (xml) => xml
          .replaceAll('<ind-as:TotalBorrowings ', '<ind-as:Borrowings ')
          .replaceAll('</ind-as:TotalBorrowings>', '</ind-as:Borrowings>'),
    );

    final row = await source.fetchFundamentals(_candidate);

    expect(row.totalDebtCr, isNull);
    expect(row.missingReason, contains('Total Debt'));
    expect(
      MagicFormulaEngine.rank([row]).skipped.single.reason,
      contains('Total Debt'),
    );
  });

  test(
    'keeps unavailable debt null and explains the skip when no fallback exists',
    () async {
      final decoded =
          jsonDecode(
                _readFixture(
                  'integrated_filings_missing_consolidated_debt.json',
                ),
              )
              as Map<String, dynamic>;
      final consolidatedRows = (decoded['data'] as List)
          .where(
            (row) => (row as Map<String, dynamic>)['isConsolidated'] == true,
          )
          .toList();
      final consolidatedOnly = jsonEncode({'data': consolidatedRows});
      final source = _source(db, settings, consolidatedOnly);

      final row = await source.fetchFundamentals(_candidate);

      expect(row.statementBasis, 'Consolidated');
      expect(row.marketCapCr, 10000);
      expect(row.totalDebtCr, isNull);
      expect(row.missingReason, contains('Total Debt'));
      expect(MagicFormulaEngine.rank([row]).ranked, isEmpty);
      expect(
        MagicFormulaEngine.rank([row]).skipped.single.reason,
        contains('Total Debt'),
      );
    },
  );

  test(
    'maps the banking format: Borrowings debt, Deposits+provisions CL, '
    'RBI cash, and the approved PBT proxy with labelled basis',
    () async {
      final source = _source(
        db,
        settings,
        _readFixture('integrated_filings.json'),
        archiveTransform: (xml) => _rebuildAs(
          xml,
          const {
            'CapitalAndLiabilities@OneI': '500000000000',
            'Deposits@OneI': '300000000000',
            'OtherLiabilitiesAndProvisions@OneI': '50000000000',
            'Borrowings@OneI': '80000000000',
            'CashAndBalancesWithReserveBankOfIndia@OneI': '15000000000',
            'ProfitLossFromOrdinaryActivitiesBeforeTax@OneD': '4000000000',
            'PaidUpValueOfEquityShareCapital@OneI': '1000000000',
            'FaceValueOfEquityShareCapital@OneI': '1',
          },
        ),
      );

      final row = await source.fetchFundamentals(_candidate);

      expect(row.ebitTtmCr, 1600);
      expect(row.earningsBasis, 'PBT proxy (EBIT not tagged)');
      expect(row.marketCapCr, 10000);
      expect(row.totalDebtCr, 8000);
      expect(row.cashCr, 1500);
      expect(row.totalAssetsCr, 50000);
      expect(row.currentLiabilitiesCr, 35000);
      expect(row.missingReason, isEmpty);
      final ranked = MagicFormulaEngine.rank([row]).ranked.single;
      expect(ranked.rocePct, closeTo(1600 / 15000 * 100, 1e-10));
    },
  );

  test(
    'maps the NBFC format: debt is debt securities + borrowings + '
    'subordinated, CL is total liabilities minus debt, real EBIT tag kept',
    () async {
      final source = _source(
        db,
        settings,
        _readFixture('integrated_filings.json'),
        archiveTransform: (xml) => _rebuildAs(
          xml,
          const {
            'EquityAndLiabilities@OneI': '500000000000',
            'Liabilities@OneI': '440000000000',
            'FinancialLiabilities@OneI': '420000000000',
            'NonFinancialLiabilities@OneI': '20000000000',
            'DebtSecurities@OneI': '150000000000',
            'Borrowings@OneI': '200000000000',
            'SubordinatedLiabilities@OneI': '10000000000',
            'CashAndCashEquivalents@OneI': '10000000000',
            'ProfitBeforeExceptionalItemsAndTax@OneD': '5000000000',
            'PaidUpValueOfEquityShareCapital@OneI': '1000000000',
            'FaceValueOfEquityShareCapital@OneI': '1',
          },
        ),
      );

      final row = await source.fetchFundamentals(_candidate);

      expect(row.ebitTtmCr, 2000);
      expect(row.earningsBasis, isEmpty);
      expect(row.totalDebtCr, 36000);
      expect(row.currentLiabilitiesCr, 8000);
      expect(row.totalAssetsCr, 50000);
      expect(row.cashCr, 1000);
      expect(row.missingReason, isEmpty);
    },
  );

  test(
    'maps the insurance format: CashAndBankBalances, Borrowings debt, PBT '
    'proxy, and market cap shares derived from PAT/EPS when face value '
    'is not tagged',
    () async {
      final source = _source(
        db,
        settings,
        _readFixture('integrated_filings.json'),
        archiveTransform: (xml) => _rebuildAs(
          xml,
          const {
            'Assets@OneI': '300000000000',
            'CurrentLiabilities@OneI': '120000000000',
            'PolicyLiabilities@OneI': '100000000000',
            'Borrowings@OneI': '5000000000',
            'CashAndBankBalances@OneI': '8000000000',
            'ProfitBeforeTax@OneD': '2000000000',
            'ProfitLossAfterTaxBeforeExtraordinaryItems@OneD': '2000000000',
            'EarningPerShare@OneD': '2',
            'PaidUpEquityShareCapital@OneI': '1000000000',
          },
        ),
      );

      final row = await source.fetchFundamentals(_candidate);

      // shares = PAT 200 Cr / EPS 2 = 100 Cr shares × ₹100 = 10,000 Cr.
      expect(row.marketCapCr, 10000);
      expect(row.ebitTtmCr, 800);
      expect(row.earningsBasis, 'PBT proxy (EBIT not tagged)');
      expect(row.totalDebtCr, 500);
      expect(row.cashCr, 800);
      expect(row.totalAssetsCr, 30000);
      expect(row.currentLiabilitiesCr, 12000);
      expect(row.missingReason, isEmpty);
    },
  );

  test(
    'insurance face with a tagged share count: market cap is NumberOfShares '
    '× price even without face value, PAT or EPS',
    () async {
      final source = _source(
        db,
        settings,
        _readFixture('integrated_filings.json'),
        archiveTransform: (xml) => _rebuildAs(
          xml,
          const {
            'Assets@OneI': '300000000000',
            'CurrentLiabilities@OneI': '120000000000',
            'PolicyLiabilities@OneI': '100000000000',
            'Borrowings@OneI': '5000000000',
            'CashAndBankBalances@OneI': '8000000000',
            'ProfitLossBeforeTax@OneD': '2000000000',
            'NumberOfShares@OneI': '1000000000',
          },
        ),
      );

      final row = await source.fetchFundamentals(_candidate);

      // 1e9 shares × ₹100 = 10,000 Cr, no derivation needed.
      expect(row.marketCapCr, 10000);
      expect(row.ebitTtmCr, 800);
      expect(row.earningsBasis, 'PBT proxy (EBIT not tagged)');
      expect(row.missingReason, isEmpty);
    },
  );

  test(
    'PAT/EPS share-count fallback accepts a same-period pair tagged only '
    'on a year-to-date duration context',
    () async {
      final source = _source(
        db,
        settings,
        _readFixture('integrated_filings.json'),
        archiveTransform: (xml) => _rebuildAs(
          xml,
          const {
            'Assets@OneI': '300000000000',
            'CurrentLiabilities@OneI': '120000000000',
            'PolicyLiabilities@OneI': '100000000000',
            'Borrowings@OneI': '5000000000',
            'CashAndBankBalances@OneI': '8000000000',
            'ProfitBeforeTax@OneD': '2000000000',
            'PaidUpEquityShareCapital@OneI': '1000000000',
            'ProfitLossAfterTax@FourD': '2000000000',
            'EarningPerShare@FourD': '2',
          },
        ),
      );

      final row = await source.fetchFundamentals(_candidate);

      // Same-context pair on FourD: shares = 200 Cr PAT / ₹2 EPS = 100 Cr
      // shares × ₹100 = 10,000 Cr. A mixed-period pair is never used.
      expect(row.marketCapCr, 10000);
      expect(row.missingReason, isEmpty);
    },
  );

  test(
    'a single borrowings side counts as total debt only when the '
    'counterpart concept is absent from the document',
    () async {
      final source = _source(
        db,
        settings,
        _readFixture('integrated_filings.json'),
        archiveTransform: (xml) => _rebuildAs(
          xml,
          const {
            'Assets@OneI': '400000000000',
            'CurrentLiabilities@OneI': '90000000000',
            'BorrowingsNoncurrent@OneI': '7000000000',
            'CashAndCashEquivalents@OneI': '5000000000',
            'ProfitBeforeExceptionalAndExtraordinaryItemsAndTax@OneD':
                '3000000000',
            'PaidUpValueOfEquityShareCapital@OneI': '1000000000',
            'FaceValueOfEquityShareCapital@OneI': '1',
          },
        ),
      );

      final row = await source.fetchFundamentals(_candidate);

      // No BorrowingsCurrent concept anywhere in the document, so the
      // non-current line is the only interest-bearing debt shown.
      expect(row.totalDebtCr, 700);
      expect(row.missingReason, isEmpty);
    },
  );

  test(
    'derives current liabilities from the schedule identity '
    'CurrentAssets − NetCurrentAssets when no CL total is tagged',
    () async {
      final source = _source(
        db,
        settings,
        _readFixture('integrated_filings.json'),
        archiveTransform: (xml) => _rebuildAs(
          xml,
          const {
            'Assets@OneI': '300000000000',
            'PolicyLiabilities@OneI': '100000000000',
            'CurrentAssets@OneI': '20000000000',
            'NetCurrentAssets@OneI': '8000000000',
            'Borrowings@OneI': '5000000000',
            'CashAndBankBalances@OneI': '8000000000',
            'ProfitBeforeTax@OneD': '2000000000',
            'PaidUpValueOfEquityShareCapital@OneI': '1000000000',
            'FaceValueOfEquityShareCapital@OneI': '1',
          },
        ),
      );

      final row = await source.fetchFundamentals(_candidate);

      // CL = CurrentAssets 2,000 Cr − NetCurrentAssets 800 Cr = 1,200 Cr.
      expect(row.currentLiabilitiesCr, 1200);
      expect(row.missingReason, isEmpty);
    },
  );

  test(
    'refuses a capital-total face value and falls back to the PAT/EPS '
    'share count',
    () async {
      final source = _source(
        db,
        settings,
        _readFixture('integrated_filings.json'),
        archiveTransform: (xml) => _rebuildAs(
          xml,
          const {
            'Assets@OneI': '300000000000',
            'CurrentLiabilities@OneI': '120000000000',
            'PolicyLiabilities@OneI': '100000000000',
            'Borrowings@OneI': '5000000000',
            'CashAndBankBalances@OneI': '8000000000',
            'ProfitBeforeTax@OneD': '2000000000',
            'PaidUpEquityShareCapital@OneI': '1000000000',
            // Not a per-share ₹ value — a capital total must not be
            // treated as face value (paidUp/this would not be a share
            // count).
            'FaceValueOfEquityShareCapital@OneI': '10000000',
            'ProfitLossAfterTaxBeforeExtraordinaryItems@OneD': '2000000000',
            'EarningPerShare@OneD': '2',
          },
        ),
      );

      final row = await source.fetchFundamentals(_candidate);

      // 1e10/1e7 = 1,000 "shares" route is refused; PAT/EPS pair gives
      // 100 Cr shares × ₹100 = 10,000 Cr instead.
      expect(row.marketCapCr, 10000);
      expect(row.missingReason, isEmpty);
    },
  );

  test(
    'recognises other-than-bank EBIT name and the LongTerm+ShortTerm '
    'borrowings pair without any PBT-proxy label',
    () async {
      final source = _source(
        db,
        settings,
        _readFixture('integrated_filings.json'),
        archiveTransform: (xml) => _rebuildAs(
          xml,
          const {
            'Assets@OneI': '400000000000',
            'CurrentLiabilities@OneI': '90000000000',
            'LongTermBorrowings@OneI': '20000000000',
            'ShortTermBorrowings@OneI': '10000000000',
            'CashAndCashEquivalents@OneI': '5000000000',
            'ProfitBeforeExceptionalAndExtraordinaryItemsAndTax@OneD':
                '3000000000',
            'PaidUpValueOfEquityShareCapital@OneI': '1000000000',
            'FaceValueOfEquityShareCapital@OneI': '1',
          },
        ),
      );

      final row = await source.fetchFundamentals(_candidate);

      expect(row.ebitTtmCr, 1200);
      expect(row.earningsBasis, isEmpty);
      expect(row.totalDebtCr, 3000);
      expect(row.missingReason, isEmpty);
    },
  );

  test(
    'skip note discloses the PBT-proxy earnings basis when a balance field '
    'is missing in a banking-format filing',
    () async {
      final source = _source(
        db,
        settings,
        _readFixture('integrated_filings.json'),
        archiveTransform: (xml) => _rebuildAs(
          xml,
          const {
            'CapitalAndLiabilities@OneI': '500000000000',
            'Deposits@OneI': '300000000000',
            'OtherLiabilitiesAndProvisions@OneI': '50000000000',
            'Borrowings@OneI': '80000000000',
            'ProfitLossFromOrdinaryActivitiesBeforeTax@OneD': '4000000000',
            'PaidUpValueOfEquityShareCapital@OneI': '1000000000',
            'FaceValueOfEquityShareCapital@OneI': '1',
          },
        ),
      );

      final row = await source.fetchFundamentals(_candidate);

      expect(row.ebitTtmCr, 1600);
      expect(row.earningsBasis, 'PBT proxy (EBIT not tagged)');
      expect(row.cashCr, isNull);
      expect(row.missingReason, contains('Cash & Equivalents'));
      expect(row.missingReason, contains('PBT proxy (EBIT not tagged)'));
      expect(MagicFormulaEngine.rank([row]).ranked, isEmpty);
    },
  );
  test(
    'parses the real Bajaj Finserv NBFC-format instance end to end: '
    'financial-format debt/CL mapping on official values',
    () async {
      final source = _source(
        db,
        settings,
        _readFixture('integrated_filings.json'),
        archiveTransform: (xml) =>
            _shiftBfsQuarter(_readFixture('bfs_nbfc_plain.xml'), xml),
      );

      final row = await source.fetchFundamentals(_candidate);

      // Values straight from the BSE-hosted NBFC instance (Q4 FY26): rupee
      // facts / 1e7 = crore. EBIT tag exists in this format → no PBT proxy.
      expect(row.earningsBasis, isEmpty);
      expect(row.ebitTtmCr, closeTo(-13.47 * 4, 1e-9));
      expect(row.marketCapCr, closeTo(15987, 1e-9));
      expect(row.totalAssetsCr, closeTo(10349.67, 1e-9));
      expect(row.currentLiabilitiesCr, closeTo(168.27, 1e-9));
      expect(row.totalDebtCr, 0);
      expect(row.cashCr, closeTo(7.31, 1e-9));
      expect(row.missingReason, isEmpty);
    },
  );

  test(
    'reads the same real filing as inline XBRL: scale=7, sign=- and comma '
    'grouping must reconstruct the identical rupee values',
    () async {
      final source = _source(
        db,
        settings,
        _readFixture('integrated_filings.json'),
        archiveTransform: (xml) =>
            _shiftBfsQuarter(_readFixture('bfs_nbfc_ixbrl.html'), xml),
      );

      final row = await source.fetchFundamentals(_candidate);

      expect(row.earningsBasis, isEmpty);
      expect(row.ebitTtmCr, closeTo(-13.47 * 4, 1e-9));
      expect(row.marketCapCr, closeTo(15987, 1e-9));
      expect(row.totalAssetsCr, closeTo(10349.67, 1e-9));
      expect(row.currentLiabilitiesCr, closeTo(168.27, 1e-9));
      expect(row.totalDebtCr, 0);
      expect(row.cashCr, closeTo(7.31, 1e-9));
      expect(row.missingReason, isEmpty);
    },
  );

  test('accounting-style (13.47) negatives in facts parse as -13.47', () async {
    final source = _source(
      db,
      settings,
      _readFixture('integrated_filings.json'),
      archiveTransform: (xml) {
        final shifted = _shiftBfsQuarter(_readFixture('bfs_nbfc_plain.xml'), xml);
        // The quarter's EBIT fact text becomes an accounting negative.
        return shifted.replaceFirst('>-134700000</', '>(13.47)</');
      },
    );

    final row = await source.fetchFundamentals(_candidate);

    // (13.47) reads as -13.47 by _number — same as iXBRL rendered negatives.
    expect(row.ebitTtmCr, closeTo(-13.47 * 4 / 10000000, 1e-12));
    expect(row.missingReason, isEmpty);
  });
}

/// Date-shifts the trimmed real Bajaj Finserv fixture so its quarter matches
/// the synthetic quarter document being replaced.
String _shiftBfsQuarter(String bfsDoc, String quarterXml) {
  final instant = RegExp(
    r'<xbrli:instant>([^<]+)</xbrli:instant>',
  ).firstMatch(quarterXml)!.group(1)!;
  final quarterEnd = instant;
  const starts = {
    '2025-06-30': '2025-04-01',
    '2025-09-30': '2025-07-01',
    '2025-12-31': '2025-10-01',
    '2026-03-31': '2026-01-01',
  };
  final quarterStart = starts[quarterEnd]!;
  return bfsDoc
      .replaceAll('2025-04-01', '\u0001FYS')
      .replaceAll('2025-03-31', '\u0001PYI')
      .replaceAll('2026-01-01', '\u0001QS')
      .replaceAll('2026-03-31', '\u0001QE')
      .replaceAll('\u0001FYS', '2024-04-01')
      .replaceAll('\u0001PYI', '2024-03-31')
      .replaceAll('\u0001QS', quarterStart)
      .replaceAll('\u0001QE', quarterEnd);
}

/// Rewrites a fixture quarter document as a different filing-format
/// instance: same period dates, but the supplied facts replace the
/// fixture's IndAS ones. Fact keys are `LocalName@context` with context
/// `OneI` (instant balance sheet), `OneD` (discrete quarter) or `FourD`
/// (a year-to-date style duration ending at the same date).
String _rebuildAs(String xml, Map<String, String> facts) {
  final instant = RegExp(
    r'<xbrli:instant>([^<]+)</xbrli:instant>',
  ).firstMatch(xml)!.group(1)!;
  final start = RegExp(
    r'<xbrli:startDate>([^<]+)</xbrli:startDate>',
  ).firstMatch(xml)!.group(1)!;
  final end = RegExp(
    r'<xbrli:endDate>([^<]+)</xbrli:endDate>',
  ).firstMatch(xml)!.group(1)!;
  final ytdStart = DateTime.parse(end)
      .subtract(const Duration(days: 365))
      .toIso8601String()
      .substring(0, 10);
  final buffer = StringBuffer(
    '<?xml version="1.0" encoding="UTF-8"?>\n'
    '<xbrli:xbrl xmlns:xbrli="http://www.xbrl.org/2003/instance" '
    'xmlns:in-capmkt="https://www.sebi.gov.in/xbrl">\n'
    '<xbrli:context id="OneI"><xbrli:entity>'
    '<xbrli:identifier scheme="">INE000A01000</xbrli:identifier>'
    '</xbrli:entity><xbrli:period>'
    '<xbrli:instant>$instant</xbrli:instant></xbrli:period>'
    '</xbrli:context>\n'
    '<xbrli:context id="OneD"><xbrli:entity>'
    '<xbrli:identifier scheme="">INE000A01000</xbrli:identifier>'
    '</xbrli:entity><xbrli:period>'
    '<xbrli:startDate>$start</xbrli:startDate>'
    '<xbrli:endDate>$end</xbrli:endDate></xbrli:period>'
    '</xbrli:context>\n'
    '<xbrli:context id="FourD"><xbrli:entity>'
    '<xbrli:identifier scheme="">INE000A01000</xbrli:identifier>'
    '</xbrli:entity><xbrli:period>'
    '<xbrli:startDate>$ytdStart</xbrli:startDate>'
    '<xbrli:endDate>$end</xbrli:endDate></xbrli:period>'
    '</xbrli:context>\n',
  );
  for (final entry in facts.entries) {
    final parts = entry.key.split('@');
    buffer.write(
      '<in-capmkt:${parts[0]} contextRef="${parts[1]}" unitRef="INR">'
      '${entry.value}</in-capmkt:${parts[0]}>\n',
    );
  }
  buffer.write('</xbrli:xbrl>');
  return buffer.toString();
}

MagicFormulaCandidate get _candidate => const MagicFormulaCandidate(
  symbol: 'ACME',
  companyName: 'Acme Example Limited',
  exchange: 'NSE',
  sector: 'Financial Services',
  industry: 'Financial Services',
  dataSymbol: 'ACME',
  dataCompanyName: 'Acme Example Limited',
);

NseMagicFormulaDataSource _source(
  AppDatabase db,
  SettingsDao settings,
  String filingsBody, {
  String Function(String xml)? archiveTransform,
  NseMagicTextGetter? getOverride,
  NseMagicBytesGetter? getBytesOverride,
}) => NseMagicFormulaDataSource(
  scripDao: ScripDao(db),
  listings: NseListingService(settings: settings),
  settings: settings,
  minimumRequestGap: Duration.zero,
  clock: () => DateTime(2026, 10, 17),
  // No listing-master lookups in tests — face value comes from the filings
  // themselves or stays missing (never a network call).
  faceValueLookup: (_) async => null,
  get:
      getOverride ??
      (uri, {refererPath}) async {
        if (uri.path == NseMagicFormulaDataSource.integratedFilingsPath) {
          return filingsBody;
        }
        if (uri.host == 'nsearchives.nseindia.com') {
          final xml = _readFixture(uri.pathSegments.last);
          return archiveTransform?.call(xml) ?? xml;
        }
        throw StateError('Unexpected fixture request: $uri');
      },
  getBytes:
      getBytesOverride ??
      (uri, {refererPath}) async {
        if (uri.path.contains('_20261017_')) {
          throw NseMagicFormulaHttpException(statusCode: 404, uri: uri);
        }
        if (uri.path.contains('_20261016_')) return _zipBhavcopyFixture();
        throw StateError('Unexpected fixture byte request: $uri');
      },
);

List<int> _zipBhavcopyFixture() {
  final content = utf8.encode(_readFixture('bhavcopy_20261016.csv'));
  final archive = Archive()
    ..addFile(
      ArchiveFile(
        'BhavCopy_NSE_CM_0_0_0_20261016_F_0000.csv',
        content.length,
        content,
      ),
    );
  return ZipEncoder().encode(archive)!;
}

String _readFixture(String name) => File('$_fixtures/$name').readAsStringSync();

class _RecordingClient extends http.BaseClient {
  _RecordingClient({this.responseStatus = 200});

  final int responseStatus;
  final requests = <http.BaseRequest>[];

  @override
  Future<http.StreamedResponse> send(http.BaseRequest request) async {
    requests.add(request);
    return http.StreamedResponse(
      Stream<List<int>>.value(utf8.encode('fixture response')),
      responseStatus,
    );
  }
}
