// ---------------------------------------------------------------------------
// earnings_calendar_test.dart — "last result kab aaya, next kab aayega".
//
// The two NSE feeds are parsed here against fixtures that mirror the *real*
// field names (`bm_symbol`/`bm_date`/`bm_purpose`, `symbol`/`exchdisstime`/
// `relatingTo`/`toDate`), so a field rename on NSE shows up as a red test
// instead of a silently blank line on the phone.
//
// Also pinned: the **no-guessing** rule (a company with no board-meeting
// intimation gets no next date at all — only its last result), the day-level
// cache and its expiry, and that an old cache's guessed dates are dropped.
// ---------------------------------------------------------------------------

import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/earnings_dao.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/services/earnings_calendar_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

/// A trimmed copy of the real `/api/corporate-board-meetings` response.
const _boardMeetings = '''
[
  {"bm_symbol":"SIYSIL","bm_date":"30-Jan-2026","bm_purpose":"SIYARAM SILK MILLS LIMITED has informed the Exchange about Board Meeting to be held on 30-Jan-2026 to consider and approve the Quarterly Unaudited Financial results of the Company for the period ended December 2025 and Dividend.","bm_timestamp":"02-Jan-2026 10:00:00","bm_desc":"Board Meeting Intimation","sm_name":"Siyaram Silk Mills Limited"},
  {"bm_symbol":"RELIANCE","bm_date":"22-Jan-2026","bm_purpose":"Reliance Industries Limited has informed the Exchange about Board Meeting to be held on 22-Jan-2026 to consider and approve the Quarterly Unaudited Financial results.","bm_timestamp":"04-Jan-2026 10:15:00","bm_desc":"Board Meeting Intimation","sm_name":"Reliance Industries Limited"},
  {"bm_symbol":"TATAMOTORS","bm_date":"05-Feb-2026","bm_purpose":"Tata Motors Limited has informed the Exchange regarding a board meeting to consider a dividend on equity shares.","bm_timestamp":"04-Jan-2026 11:00:00","bm_desc":"Board Meeting Intimation","sm_name":"Tata Motors Limited"},
  {"bm_symbol":"","bm_date":"05-Feb-2026","bm_purpose":"Broken row with no symbol"},
  {"bm_symbol":"JUNK","bm_date":"not-a-date","bm_purpose":"Quarterly results"}
]
''';

/// A trimmed copy of the real `/api/corporates-financial-results` response —
/// RELIANCE appears twice (older + newer filing), SBIN once, TATAMOTORS not
/// at all (it only has the dividend-only board meeting).
const _financialResults = '''
[
  {"symbol":"RELIANCE","companyName":"Reliance Industries Limited","exchdisstime":"16-Jan-2025 20:20:54","filingDate":"16-Jan-2025 20:20","relatingTo":"Third Quarter","toDate":"31-Dec-2024","period":"Quarterly"},
  {"symbol":"RELIANCE","companyName":"Reliance Industries Limited","exchdisstime":"14-Oct-2025 21:05:11","filingDate":"14-Oct-2025 21:05","relatingTo":"Second Quarter","toDate":"30-Sep-2025","period":"Quarterly"},
  {"symbol":"SBIN","companyName":"State Bank of India","exchdisstime":"04-Nov-2025 18:02:00","relatingTo":"Second Quarter","toDate":"30-Sep-2025","period":"Quarterly"}
]
''';

void main() {
  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  // ---------------------------------------------------------------------
  group('parsing', () {
    test('board meetings: only results meetings survive', () {
      final meetings = EarningsCalendarService.parseBoardMeetings(
        _boardMeetings,
      );

      final symbols = meetings.map((m) => m.symbol).toList()..sort();
      expect(
        symbols,
        ['RELIANCE', 'SIYSIL'],
        reason:
            'the dividend-only '
            'TATAMOTORS meeting must not look like a results date',
      );
      expect(meetings.first.date.year, anyOf(2026, 2026));
      final reliance = meetings.firstWhere((m) => m.symbol == 'RELIANCE');
      expect(reliance.date, DateTime(2026, 1, 22));
      expect(reliance.announcedAt, DateTime(2026, 1, 4, 10, 15));
    });

    test('live NSE bm_timestamp is kept separate from bm_date', () {
      const liveResponse = '''
[
  {"bm_symbol":"KROSS","bm_date":"17-Oct-2026","bm_purpose":"Financial Results/Other business matters","bm_desc":"To consider and approve the financial results for the period ended September 30, 2026 and other business matters","bm_timestamp":"13-Oct-2026 20:10:24","sysTime":"13-Oct-2026 20:10:24"}
]
''';
      final meeting = EarningsCalendarService.parseBoardMeetings(
        liveResponse,
      ).single;

      expect(meeting.date, DateTime(2026, 10, 17));
      expect(meeting.announcedAt, DateTime(2026, 10, 13, 20, 10, 24));
      expect(
        EarningsCalendarService.parseRecentResultAnnouncements([
          meeting,
        ], now: DateTime(2026, 10, 14, 9))['KROSS|2026-10-17']!.announcedAt,
        DateTime(2026, 10, 13, 20, 10, 24),
      );
    });

    test('Naya needs a recent official bm_timestamp, never a fallback', () {
      final parsed = EarningsCalendarService.parseBoardMeetings(_boardMeetings);
      final meetings = [
        ...parsed,
        BoardMeeting(
          symbol: 'INFY',
          date: DateTime(2026, 1, 20),
          purpose: 'Quarterly Financial Results',
        ), // no bm_timestamp: must remain unlabelled
      ];
      final records = EarningsCalendarService.parseRecentResultAnnouncements(
        meetings,
        now: DateTime(2026, 1, 5),
      );

      const key = 'RELIANCE|2026-01-22';
      expect(records.keys, contains(key));
      expect(records[key]!.announcedAt, DateTime(2026, 1, 4, 10, 15));
      expect(
        records.keys,
        isNot(contains('SIYSIL|2026-01-30')),
        reason: 'older than two days',
      );
      expect(
        records.keys,
        isNot(contains('TATAMOTORS|2026-02-05')),
        reason: 'dividend-only agenda is not a result announcement',
      );
      expect(
        records.keys,
        isNot(contains('INFY|2026-01-20')),
        reason: 'meeting date and app first-seen time are not substitutes',
      );

      final exactlyTwoDaysLater =
          EarningsCalendarService.parseRecentResultAnnouncements(
            meetings,
            now: DateTime(2026, 1, 6, 10, 15),
          );
      expect(
        exactlyTwoDaysLater,
        isEmpty,
        reason: 'eligibility ends at the 48-hour boundary',
      );
    });

    test('financial results: newest filing per symbol wins', () {
      final latest = EarningsCalendarService.parseFinancialResults(
        _financialResults,
      );

      expect(latest.keys.toSet(), {'RELIANCE', 'SBIN'});
      expect(latest['RELIANCE']!.$1, DateTime(2025, 10, 14));
      expect(latest['RELIANCE']!.$2, contains('Q2'));
      expect(latest['SBIN']!.$1, DateTime(2025, 11, 4));
    });

    test('labels read like a human wrote them', () {
      expect(
        EarningsCalendarService.quarterLabel(
          relatingTo: 'Second Quarter',
          periodEnd: DateTime(2025, 9, 30),
        ),
        'Q2 · quarter ended Sep 2025',
      );
      expect(
        EarningsCalendarService.quarterLabel(
          relatingTo: 'Annual',
          periodEnd: DateTime(2025, 3, 31),
        ),
        'year ended Mar 2025',
      );
    });

    test('garbage input yields nothing, never a crash', () {
      expect(
        EarningsCalendarService.parseBoardMeetings('<html>403</html>'),
        isEmpty,
      );
      expect(
        EarningsCalendarService.parseFinancialResults('not json'),
        isEmpty,
      );
      expect(
        EarningsCalendarService.parseFinancialResults('{"data": []}'),
        isEmpty,
      );
      expect(EarningsCalendarService.parseNseDate(''), isNull);
      expect(EarningsCalendarService.parseNseDate('32-Foo-2026'), isNull);
      expect(
        EarningsCalendarService.parseNseDate('22-Jan-2026'),
        DateTime(2026, 1, 22),
      );
    });

    test('a {data: [...]} envelope is unwrapped', () {
      final rows = EarningsCalendarService.parseBoardMeetings(
        '{"data":[{"bm_symbol":"INFY","bm_date":"14-Jan-2026","bm_purpose":"'
        'to consider and approve quarterly results"}]}',
      );
      expect(rows.single.symbol, 'INFY');
    });
  });

  // ---------------------------------------------------------------------
  group('merging', () {
    final today = DateTime(2026, 1, 5);

    test('an announced meeting is a date; an absent one is *no* date', () {
      final merged = EarningsCalendarService.merge(
        meetings: EarningsCalendarService.parseBoardMeetings(_boardMeetings),
        lastResults: EarningsCalendarService.parseFinancialResults(
          _financialResults,
        ),
        today: today,
      );

      final reliance = merged['RELIANCE']!;
      expect(reliance.lastDate, DateTime(2025, 10, 14));
      expect(reliance.nextDate, DateTime(2026, 1, 22));
      expect(reliance.nextConfirmed, isTrue);
      expect(reliance.estimated, isFalse);

      // SBIN filed a result but has announced no meeting → **no** next date.
      // (1.5.12 guessed one here; a guess reads as a fact, so it is gone.)
      final sbin = merged['SBIN']!;
      expect(sbin.lastDate, DateTime(2025, 11, 4));
      expect(sbin.lastLabel, contains('Q2'));
      expect(sbin.nextDate, isNull, reason: 'nothing is estimated any more');
      expect(sbin.hasAnnouncedNext, isFalse);
      expect(sbin.nextConfirmed, isFalse);
    });

    test(
      'nothing is ever guessed — a company with no intimation has no date',
      () {
        final merged = EarningsCalendarService.merge(
          meetings: const <BoardMeeting>[],
          lastResults: {
            'SBIN': (DateTime(2025, 11, 4), 'Q2 · quarter ended Sep 2025'),
          },
          today: today,
        );

        final sbin = merged['SBIN']!;
        expect(sbin.nextDate, isNull);
        expect(sbin.announcedNext, isNull);
        // The last result is a fact, and it is what the calendar prints instead.
        expect(sbin.lastDate, DateTime(2025, 11, 4));
        expect(sbin.lastLabel, 'Q2 · quarter ended Sep 2025');
        expect(sbin.isEmpty, isFalse);
      },
    );

    test(
      'a meeting already held is a *declared* result, never the "next" one',
      () {
        final merged = EarningsCalendarService.merge(
          meetings: EarningsCalendarService.parseBoardMeetings(_boardMeetings),
          lastResults: const {},
          today: DateTime(2026, 3, 1), // after both January meetings
        );

        // The board met → the result is out. Before this rule these rows went
        // blank ("data nahi aa raha") until NSE's filings feed caught up.
        final reliance = merged['RELIANCE']!;
        expect(reliance.lastDate, DateTime(2026, 1, 22));
        expect(reliance.lastLabel, 'board meeting hui');
        expect(
          reliance.nextDate,
          isNull,
          reason: 'declared, next not announced',
        );
        expect(reliance.nextConfirmed, isFalse);

        final siysil = merged['SIYSIL']!;
        expect(siysil.lastDate, DateTime(2026, 1, 30));
      },
    );

    test('a filing on/after the meeting consumes it — result declared', () {
      final merged = EarningsCalendarService.merge(
        meetings: [
          BoardMeeting(
            symbol: 'INFY',
            date: DateTime(2026, 1, 14),
            purpose: 'quarterly results',
          ),
        ],
        lastResults: {
          'INFY': (DateTime(2026, 1, 14), 'Q3 · quarter ended Dec 2025'),
        },
        today: DateTime(2026, 1, 14), // result declared *today*
      );

      final infy = merged['INFY']!;
      expect(infy.lastDate, DateTime(2026, 1, 14));
      expect(
        infy.lastLabel,
        contains('Q3'),
        reason: 'the filing knows the quarter',
      );
      expect(
        infy.nextDate,
        isNull,
        reason: 'the meeting is past — it must not reappear as "next"',
      );
      expect(infy.nextConfirmed, isFalse);
    });

    test('a meeting today without a filing yet still counts as upcoming', () {
      final merged = EarningsCalendarService.merge(
        meetings: [
          BoardMeeting(
            symbol: 'INFY',
            date: DateTime(2026, 1, 14),
            purpose: 'quarterly results',
          ),
        ],
        lastResults: {
          'INFY': (DateTime(2025, 10, 15), 'Q2 · quarter ended Sep 2025'),
        },
        today: DateTime(2026, 1, 14),
      );

      final infy = merged['INFY']!;
      expect(infy.lastDate, DateTime(2025, 10, 15));
      expect(
        infy.nextDate,
        DateTime(2026, 1, 14),
        reason: 'aaj board meeting hai',
      );
      expect(infy.nextConfirmed, isTrue);
    });

    test('a newer filing beats an older held meeting', () {
      final merged = EarningsCalendarService.merge(
        meetings: [
          BoardMeeting(
            symbol: 'TCS',
            date: DateTime(2025, 12, 20),
            purpose: 'quarterly results',
          ),
        ],
        lastResults: {
          'TCS': (DateTime(2026, 1, 9), 'Q3 · quarter ended Dec 2025'),
        },
        today: DateTime(2026, 1, 12),
      );

      final tcs = merged['TCS']!;
      expect(tcs.lastDate, DateTime(2026, 1, 9));
      expect(tcs.lastLabel, contains('Q3'));
      expect(tcs.lastLabel, isNot('board meeting hui'));
    });
  });

  // ---------------------------------------------------------------------
  group('service cache', () {
    late EarningsDao dao;
    late SettingsDao settings;
    late int calls;

    setUp(() async {
      AppDatabase.overridePath = inMemoryDatabasePath;
      await AppDatabase.instance.close();
      dao = EarningsDao(AppDatabase.instance);
      settings = SettingsDao(AppDatabase.instance);
      calls = 0;
    });

    tearDown(() async {
      await AppDatabase.instance.close();
      AppDatabase.overridePath = null;
    });

    EarningsCalendarService service({
      required DateTime now,
      bool fail = false,
    }) => EarningsCalendarService(
      dao: dao,
      settings: settings,
      now: () => now,
      get: (uri) async {
        calls++;
        if (fail) throw Exception('NSE down');
        if (uri.toString() == EarningsCalendarService.warmUpUrl) {
          return '<html>home</html>';
        }
        if (uri.path.contains('board-meetings')) return _boardMeetings;
        return _financialResults;
      },
    );

    test('first load fetches both NSE feeds and writes the table', () async {
      final calendar = await service(now: DateTime(2026, 1, 5)).load();

      expect(calls, 3, reason: 'warm-up + board meetings + filings');
      expect(calendar.length, 3); // RELIANCE, SIYSIL, SBIN
      expect(await dao.count(), 3);
      expect(calendar.of('reliance')!.nextConfirmed, isTrue);
    });

    test(
      'Naya declared uses the verified NSE broadcast date, not meeting date',
      () async {
        final svc = service(now: DateTime(2026, 1, 5));
        await svc.load();

        expect(
          svc.newlyDeclaredAt('RELIANCE', DateTime(2026, 1, 22)),
          DateTime(2026, 1, 4, 10, 15),
          reason:
              'official bm_timestamp within two days, matched to its meeting date',
        );
        expect(
          svc.newlyDeclaredAt('SIYSIL', DateTime(2026, 1, 30)),
          isNull,
          reason: 'older than two days',
        );
        expect(
          svc.newlyDeclaredAt('SBIN', null),
          isNull,
          reason: 'no matching confirmed result meeting',
        );

        // A new service instance restores the verified marker from scrip_meta.
        final afterFirst = calls;
        final fresh = service(now: DateTime(2026, 1, 5, 10));
        await fresh.load();
        expect(calls, afterFirst, reason: 'calendar cache remains day-cached');
        expect(
          fresh.newlyDeclaredAt('RELIANCE', DateTime(2026, 1, 22)),
          DateTime(2026, 1, 4, 10, 15),
        );
      },
    );

    test(
      'a second load inside the validity window does not touch NSE',
      () async {
        final svc = service(now: DateTime(2026, 1, 5));
        await svc.load();
        final afterFirst = calls;

        // A brand-new service instance (same cache) must also stay quiet —
        // 10 h later is still inside the 20 h window.
        final fresh = service(now: DateTime(2026, 1, 5, 10));
        final calendar = await fresh.load();
        expect(calls, afterFirst);
        expect(calendar.of('RELIANCE'), isNotNull);
      },
    );

    test('a fetch from an earlier calendar day is always stale', () async {
      // 9 PM tonight, opened again at 8 AM tomorrow: only 11 hours apart, but a
      // new day — results get declared during the day, so it must refetch.
      await service(now: DateTime(2026, 1, 5, 21)).load();
      final afterFirst = calls;

      final nextMorning = service(now: DateTime(2026, 1, 6, 8));
      await nextMorning.load();
      expect(calls, afterFirst + 3, reason: 'naya din, naya fetch');
    });

    test('after the window it fetches again', () async {
      await service(now: DateTime(2026, 1, 5)).load();
      final afterFirst = calls;

      await service(now: DateTime(2026, 1, 7)).load();
      expect(calls, afterFirst + 3);
    });

    test('a failed fetch keeps the old dates and says so', () async {
      await service(now: DateTime(2026, 1, 5)).load();

      final offline = service(now: DateTime(2026, 1, 9), fail: true);
      final calendar = await offline.load();

      expect(
        calendar.of('RELIANCE')!.nextDate,
        DateTime(2026, 1, 22),
        reason: 'cached dates survive an NSE outage',
      );
      expect(offline.lastFetchFailed, isTrue);
      expect(offline.note, contains('taaza data nahi aaya'));
      expect(await dao.count(), 3, reason: 'the table was not wiped either');
    });

    // -----------------------------------------------------------------------
    // The blank-page class of bug. The page once showed *nothing at all* because
    // a block page parsed as "no rows" and then wiped the cache, and the empty
    // result was remembered as "fresh for today" so the app never retried.
    // -----------------------------------------------------------------------
    test('an HTML block page is a failure, never "NSE has no data"', () async {
      await service(now: DateTime(2026, 1, 5)).load();

      final blocked = EarningsCalendarService(
        dao: dao,
        settings: settings,
        now: () => DateTime(2026, 1, 9),
        get: (uri) async {
          calls++;
          // What NSE's bot filter actually returns: HTTP 200 + HTML.
          return '<html><head><title>Access Denied</title></head>'
              '<body>Reference #18.abcd</body></html>';
        },
      );
      final calendar = await blocked.load();

      expect(blocked.lastFetchFailed, isTrue);
      expect(blocked.note, contains('JSON nahi mila'));
      expect(calendar.length, 3, reason: 'the stored calendar survives');
      expect(await dao.count(), 3, reason: 'the table was not wiped');
    });

    test(
      'a valid-but-empty feed never invents rows or claims freshness',
      () async {
        // Fresh install, NSE answering "[]" (its empty / block variant).
        EarningsCalendarService emptyFeed() => EarningsCalendarService(
          dao: dao,
          settings: settings,
          now: () => DateTime(2026, 1, 5, 12),
          get: (uri) async {
            calls++;
            if (uri.toString() == EarningsCalendarService.warmUpUrl) {
              return '<html>home</html>';
            }
            return '[]';
          },
        );

        final first = await emptyFeed().load();
        expect(first.isEmpty, isTrue);
        expect(await dao.count(), 0, reason: 'nothing invented, nothing wiped');

        final svc = emptyFeed();
        await svc.load();
        expect(svc.lastFetchFailed, isTrue);
        expect(svc.note, contains('koi results date nahi aayi'));

        // Nothing was recorded as fresh, so the next load tries NSE again
        // instead of serving a blank page for the rest of the day.
        final afterFirst = calls;
        await svc.load();
        expect(
          calls,
          greaterThan(afterFirst),
          reason: 'an empty result must never be memoised as a good cache',
        );

        // And as soon as NSE answers properly, the list fills up.
        await service(now: DateTime(2026, 1, 5, 13)).load();
        expect(await dao.count(), 3);
      },
    );

    test('an empty feed on top of today\'s good data keeps the data', () async {
      await service(now: DateTime(2026, 1, 5)).load();

      final emptyFeed = EarningsCalendarService(
        dao: dao,
        settings: settings,
        now: () => DateTime(2026, 1, 5, 12),
        get: (uri) async {
          calls++;
          if (uri.toString() == EarningsCalendarService.warmUpUrl) {
            return '<html>home</html>';
          }
          return '[]';
        },
      );
      // A forced refresh — the day's cache is still valid, so a plain load()
      // would not even talk to NSE.
      final calendar = await emptyFeed.refresh();

      expect(calendar.of('RELIANCE'), isNotNull, reason: 'old rows kept');
      expect(await dao.count(), 3, reason: 'the table was not wiped');
      expect(emptyFeed.lastFetchFailed, isTrue);
      expect(emptyFeed.note, contains('koi results date nahi aayi'));
    });

    test(
      'one dead feed keeps the other half, and back-fills from the cache',
      () async {
        await service(now: DateTime(2026, 1, 5)).load();

        // Board meetings are blocked; filings answer normally.
        final half = EarningsCalendarService(
          dao: dao,
          settings: settings,
          now: () => DateTime(2026, 1, 6),
          get: (uri) async {
            calls++;
            if (uri.toString() == EarningsCalendarService.warmUpUrl) {
              return '<html>home</html>';
            }
            if (uri.path.contains('board-meetings')) {
              throw Exception('HTTP 403');
            }
            return _financialResults;
          },
        );
        final calendar = await half.load();

        expect(half.lastFetchFailed, isTrue);
        expect(half.note, contains('board meetings'));
        // RELIANCE's announced 22-Jan meeting is still there (from the cache)…
        expect(calendar.of('RELIANCE')!.nextConfirmed, isTrue);
        expect(calendar.of('RELIANCE')!.nextDate, DateTime(2026, 1, 22));
        // …and SBIN's filing came in fresh.
        expect(calendar.of('SBIN')!.lastDate, DateTime(2025, 11, 4));
      },
    );

    test('a rejected date window retries the plain query', () async {
      final asked = <Uri>[];
      final svc = EarningsCalendarService(
        dao: dao,
        settings: settings,
        now: () => DateTime(2026, 1, 5),
        get: (uri) async {
          calls++;
          asked.add(uri);
          if (uri.toString() == EarningsCalendarService.warmUpUrl) {
            return '<html>home</html>';
          }
          if (uri.path.contains('board-meetings')) {
            if (uri.queryParameters.containsKey('from_date')) {
              throw Exception('HTTP 400'); // our window is not accepted
            }
            return _boardMeetings; // the default window is
          }
          return _financialResults;
        },
      );
      final calendar = await svc.load();

      expect(
        asked.any(
          (u) =>
              u.path.contains('board-meetings') &&
              !u.queryParameters.containsKey('from_date'),
        ),
        isTrue,
        reason: 'the plain board-meetings query must be attempted',
      );
      expect(calendar.of('RELIANCE')!.nextConfirmed, isTrue);
      expect(svc.lastFetchFailed, isFalse);
    });

    // ---------------------------------------------------------------------
    // Rows written by build 1.5.12 carry a *guessed* next date (estimated=1).
    // The user asked for no guessed dates, so an old phone's cache must not
    // bring them back.
    // ---------------------------------------------------------------------
    test(
      'a guessed date cached by an older build is dropped on read',
      () async {
        await dao.replaceAll({
          'SBIN': EarningsInfo(
            lastDate: DateTime(2025, 11, 4),
            lastLabel: 'Q2 · quarter ended Sep 2025',
            nextDate: DateTime(2026, 2, 3),
            nextLabel: 'anumanit (pichle result se)',
            estimated: true,
          ),
        });

        final read = await dao.all();
        final sbin = read['SBIN']!;
        expect(
          sbin.lastDate,
          DateTime(2025, 11, 4),
          reason: 'the last result is a fact and stays',
        );
        expect(sbin.lastLabel, contains('Q2'));
        expect(sbin.nextDate, isNull, reason: 'the guess must not come back');
        expect(sbin.announcedNext, isNull);
        expect(sbin.hasAnnouncedNext, isFalse);
      },
    );

    test('an announced date survives the cache round-trip', () async {
      await dao.replaceAll({
        'RELIANCE': EarningsInfo(
          lastDate: DateTime(2025, 10, 14),
          lastLabel: 'Q2 · quarter ended Sep 2025',
          nextDate: DateTime(2026, 1, 22),
          nextLabel: 'board meeting confirm',
          nextConfirmed: true,
        ),
      });

      final reliance = (await dao.all())['RELIANCE']!;
      expect(reliance.nextDate, DateTime(2026, 1, 22));
      expect(reliance.announcedNext, DateTime(2026, 1, 22));
      expect(reliance.hasAnnouncedNext, isTrue);
    });
  });
}
