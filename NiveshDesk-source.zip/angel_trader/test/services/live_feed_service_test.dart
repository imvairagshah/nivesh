// ---------------------------------------------------------------------------
// live_feed_service_test.dart — the socket lifecycle and the subscription diff.
//
// NO NETWORK IS TOUCHED: the channel factory is injected, so the test drives a
// fake WebSocketChannel and inspects exactly what the service would have sent.
// That makes the risky parts of the feed verifiable offline:
//   * the connect headers (raw JWT, no "Bearer " prefix — a real gotcha)
//   * the subscribe/unsubscribe payload shape and the action codes (1 / 0)
//   * diffing: re-syncing the same watch list must send nothing at all
//   * token → price-key routing, and unknown tokens being counted not stored
//   * reconnect after a dropped socket, with re-subscription
// ---------------------------------------------------------------------------

import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/remote/dto/session.dart';
import 'package:angel_trader/services/auth_service.dart';
import 'package:angel_trader/services/feed_decoder.dart';
import 'package:angel_trader/services/live_feed_service.dart';
import 'package:angel_trader/services/secure_store.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_test/flutter_test.dart';
// ---------------------------------------------------------------------------
// A fake socket: records everything the service sends, and lets the test push
// frames in as if they arrived from SmartAPI.
// ---------------------------------------------------------------------------

class FakeSocket implements FeedSocket {
  final List<dynamic> sent = [];
  final StreamController<dynamic> _incoming = StreamController<dynamic>();
  bool closed = false;

  @override
  Stream<dynamic> get stream => _incoming.stream;

  @override
  Future<void> get ready => Future<void>.value();

  @override
  void send(String message) => sent.add(message);

  @override
  Future<void> close() async {
    closed = true;
    if (!_incoming.isClosed) await _incoming.close();
  }

  /// Pushes a frame *from the server* to the client.
  void emit(dynamic frame) {
    if (!_incoming.isClosed) _incoming.add(frame);
  }

  void emitError(Object error) {
    if (!_incoming.isClosed) _incoming.addError(error);
  }

  /// Simulates the server closing the socket.
  void finish() {
    if (!_incoming.isClosed) _incoming.close();
  }

  /// Everything the client sent, decoded from JSON.
  List<Map<String, dynamic>> get messages => sent
      .whereType<String>()
      .where((m) => m.trimLeft().startsWith('{'))
      .map((m) => jsonDecode(m) as Map<String, dynamic>)
      .toList(growable: false);

  List<Map<String, dynamic>> get subscriptions =>
      messages.where((m) => m['action'] == 1).toList(growable: false);
}

/// A JWT that never expires (exp = 2099), so `AuthService.restore()` performs no
/// refresh call.
String _longLivedJwt() {
  String segment(Map<String, dynamic> payload) => base64Url
      .encode(utf8.encode(jsonEncode(payload)))
      .replaceAll('=', '');
  return '${segment({'alg': 'HS512'})}.${segment({'exp': 4070908800})}.signature';
}

Future<AuthService> _loggedInAuth() async {
  FlutterSecureStorage.setMockInitialValues({
    'angel_session_v1': jsonEncode(
      AngelSession(
        apiKey: 'test-api-key',
        clientCode: 'A123456',
        jwtToken: _longLivedJwt(),
        refreshToken: 'refresh-token',
        feedToken: 'feed-token-xyz',
        generatedAt: DateTime.now(),
      ).toJson(),
    ),
  });
  final auth = AuthService(store: SecureStore());
  await auth.restore();
  return auth;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late AuthService auth;
  late FakeSocket socket;
  late int channelsCreated;
  Uri? lastUri;
  Map<String, dynamic>? lastHeaders;

  Future<void> setUpService({
    bool loggedIn = true,
    Duration pingInterval = const Duration(milliseconds: 40),
  }) async {
    if (loggedIn) {
      auth = await _loggedInAuth();
    } else {
      // The mock keystore is static, so it must be emptied explicitly — a
      // previous test's session would otherwise leak into this one.
      FlutterSecureStorage.setMockInitialValues({});
      auth = AuthService(store: SecureStore());
      await auth.restore();
      expect(auth.isLoggedIn, isFalse, reason: 'test fixture without a session');
    }

    socket = FakeSocket();
    channelsCreated = 0;
    lastUri = null;
    lastHeaders = null;
  }

  LiveFeedService build({
    Duration pingInterval = const Duration(milliseconds: 40),
    Duration reconnectBase = const Duration(milliseconds: 10),
    Duration reconnectMax = const Duration(milliseconds: 20),
  }) =>
      LiveFeedService(
        auth: auth,
        pingInterval: pingInterval,
        reconnectBase: reconnectBase,
        reconnectMax: reconnectMax,
        socketFactory: (uri, headers) {
          lastUri = uri;
          lastHeaders = headers;
          channelsCreated++;
          socket = FakeSocket();
          return socket;
        },
      );

  FeedSubscription sub(String token, {Exchange exchange = Exchange.nse, String? key}) =>
      FeedSubscription(
        token: token,
        exchange: exchange,
        priceKey: key ?? '${exchange.code}:TOKEN$token',
      );

  test('connects with the documented headers (raw JWT, no Bearer prefix)',
      () async {
    await setUpService();
    final feed = build();

    await feed.sync([sub('3045', key: 'NSE:SBIN')]);

    expect(lastUri.toString(), 'wss://smartapisocket.angelone.in/smart-stream');
    expect(lastHeaders!['Authorization'], auth.session!.jwtToken);
    expect(lastHeaders!['Authorization'], isNot(startsWith('Bearer')));
    expect(lastHeaders!['x-api-key'], 'test-api-key');
    expect(lastHeaders!['x-client-code'], 'A123456');
    expect(lastHeaders!['x-feed-token'], 'feed-token-xyz');
    expect(feed.status, FeedStatus.connected);

    feed.dispose();
    auth.dispose();
  });

  test('subscribes in LTP mode with grouped exchange types', () async {
    await setUpService();
    final feed = build();

    await feed.sync([
      sub('3045', key: 'NSE:SBIN'),
      sub('1594', key: 'NSE:INFY'),
      sub('500325', exchange: Exchange.bse, key: 'BSE:SBIN'),
    ]);

    expect(socket.subscriptions, hasLength(1));
    final message = socket.subscriptions.first;
    expect(message['action'], 1);
    expect(message['correlationID'], hasLength(10));
    final params = message['params'] as Map<String, dynamic>;
    expect(params['mode'], 1); // LTP

    final tokenList = (params['tokenList'] as List).cast<Map<String, dynamic>>();
    final byType = {
      for (final entry in tokenList) entry['exchangeType'] as int: entry['tokens'],
    };
    expect(byType[1], ['3045', '1594']);
    expect(byType[3], ['500325']);
    expect(feed.subscribedTokenCount, 3);

    feed.dispose();
    auth.dispose();
  });

  test('re-syncing the same watch list sends nothing (diffing)', () async {
    await setUpService();
    final feed = build();
    final wanted = [sub('3045', key: 'NSE:SBIN')];

    await feed.sync(wanted);
    final afterFirst = socket.messages.length;
    await feed.sync(wanted); // identical
    await feed.sync(List.of(wanted)); // equal but a different list instance

    expect(socket.messages.length, afterFirst);
    expect(feed.subscribedTokenCount, 1);

    feed.dispose();
    auth.dispose();
  });

  test('adding an instrument subscribes only the newcomer', () async {
    await setUpService();
    final feed = build();

    await feed.sync([sub('3045', key: 'NSE:SBIN')]);
    await feed.sync([
      sub('3045', key: 'NSE:SBIN'),
      sub('1594', key: 'NSE:INFY'),
    ]);

    final additions = socket.subscriptions.last['params'] as Map<String, dynamic>;
    final tokens = ((additions['tokenList'] as List).first
        as Map<String, dynamic>)['tokens'] as List;
    expect(tokens, ['1594']);

    feed.dispose();
    auth.dispose();
  });

  test('dropping an instrument unsubscribes it (action 0)', () async {
    await setUpService();
    final feed = build();

    await feed.sync([
      sub('3045', key: 'NSE:SBIN'),
      sub('1594', key: 'NSE:INFY'),
    ]);
    await feed.sync([sub('3045', key: 'NSE:SBIN')]);

    final unsub = socket.messages.lastWhere((m) => m['action'] == 0);
    final params = unsub['params'] as Map<String, dynamic>;
    final tokens = ((params['tokenList'] as List).first
        as Map<String, dynamic>)['tokens'] as List;
    expect(tokens, ['1594']);
    expect(feed.subscribedTokenCount, 1);

    feed.dispose();
    auth.dispose();
  });

  test('routes a tick to its price key and emits it on the stream', () async {
    await setUpService();
    final feed = build();
    final received = <String>[];
    final subscription = feed.ticks.listen((tick) => received.add(tick.token));

    await feed.sync([sub('3045', key: 'NSE:SBIN')]);

    socket.emit(FeedDecoder.encodeLtpPacket(
      token: '3045',
      exchangeType: 1,
      ltp: 812.35,
    ));
    await Future<void>.delayed(const Duration(milliseconds: 10));

    expect(feed.priceFor('NSE:SBIN'), 812.35);
    expect(feed.tickFor('NSE:SBIN')!.token, '3045');
    expect(feed.ticksReceived, 1);
    expect(feed.isFresh('NSE:SBIN'), isTrue);
    expect(received, ['3045']);

    await subscription.cancel();
    feed.dispose();
    auth.dispose();
  });

  test('a tick for an unsubscribed token is counted, never cached', () async {
    await setUpService();
    final feed = build();

    await feed.sync([sub('3045', key: 'NSE:SBIN')]);
    socket.emit(FeedDecoder.encodeLtpPacket(
      token: '9999',
      exchangeType: 1,
      ltp: 50,
    ));
    await Future<void>.delayed(const Duration(milliseconds: 10));

    expect(feed.unmappedTicks, 1);
    expect(feed.priceFor('NSE:SBIN'), isNull);

    feed.dispose();
    auth.dispose();
  });

  test('an out-of-order packet is ignored', () async {
    await setUpService();
    final feed = build();

    await feed.sync([sub('3045', key: 'NSE:SBIN')]);
    socket.emit(FeedDecoder.encodeLtpPacket(
      token: '3045',
      exchangeType: 1,
      ltp: 100,
      sequence: 10,
    ));
    await Future<void>.delayed(const Duration(milliseconds: 5));
    socket.emit(FeedDecoder.encodeLtpPacket(
      token: '3045',
      exchangeType: 1,
      ltp: 99,
      sequence: 9, // older than what we already have
    ));
    await Future<void>.delayed(const Duration(milliseconds: 5));

    expect(feed.priceFor('NSE:SBIN'), 100);

    feed.dispose();
    auth.dispose();
  });

  test('control frames and malformed frames never reach the price cache',
      () async {
    await setUpService();
    final feed = build();

    await feed.sync([sub('3045', key: 'NSE:SBIN')]);
    socket.emit(Uint8List.fromList([0, 0])); // pong
    socket.emit(Uint8List.fromList([9, 1, 2, 3, 4])); // junk
    await Future<void>.delayed(const Duration(milliseconds: 10));

    expect(feed.ticksReceived, 0);
    expect(feed.malformedFrames, 1);
    expect(feed.priceFor('NSE:SBIN'), isNull);

    feed.dispose();
    auth.dispose();
  });

  test('the heartbeat is the literal text "ping"', () async {
    await setUpService();
    final feed = build(pingInterval: const Duration(milliseconds: 30));

    await feed.sync([sub('3045', key: 'NSE:SBIN')]);
    await Future<void>.delayed(const Duration(milliseconds: 90));

    expect(socket.sent.whereType<String>(), contains('ping'));

    feed.dispose();
    auth.dispose();
  });

  test('reconnects and re-subscribes after the socket drops', () async {
    await setUpService();
    final feed = build();

    await feed.sync([sub('3045', key: 'NSE:SBIN')]);
    expect(channelsCreated, 1);

    socket.emitError('connection reset');
    // 10 ms base delay + ≤25% jitter → 200 ms is comfortably enough.
    await Future<void>.delayed(const Duration(milliseconds: 200));

    expect(channelsCreated, greaterThan(1)); // a new socket was opened
    expect(feed.status, FeedStatus.connected);
    expect(feed.reconnectCount, greaterThanOrEqualTo(1));

    // The server forgets subscriptions on reconnect → the full set is re-sent.
    final resubscribed = socket.subscriptions;
    expect(resubscribed, isNotEmpty);
    final tokens = ((resubscribed.last['params'] as Map<String, dynamic>)['tokenList']
        as List).first as Map<String, dynamic>;
    expect(tokens['tokens'], ['3045']);

    feed.dispose();
    auth.dispose();
  });

  test('without a session it reports an error instead of dialling out',
      () async {
    await setUpService(loggedIn: false);
    final feed = build();

    await feed.sync([sub('3045', key: 'NSE:SBIN')]);

    expect(channelsCreated, 0);
    expect(feed.status, FeedStatus.error);
    expect(feed.error, contains('Not logged in'));

    feed.dispose();
    auth.dispose();
  });

  test('stop() closes the socket and forgets the watch list, keeping prices',
      () async {
    await setUpService();
    final feed = build();

    await feed.sync([sub('3045', key: 'NSE:SBIN')]);
    socket.emit(FeedDecoder.encodeLtpPacket(
      token: '3045',
      exchangeType: 1,
      ltp: 700,
    ));
    await Future<void>.delayed(const Duration(milliseconds: 10));

    await feed.stop();

    expect(feed.status, FeedStatus.idle);
    expect(feed.subscribedTokenCount, 0);
    expect(feed.wantedTokenCount, 0);
    expect(socket.closed, isTrue);
    expect(feed.priceFor('NSE:SBIN'), 700); // last known value is retained

    await feed.stop(clearPrices: true);
    expect(feed.priceFor('NSE:SBIN'), isNull);

    feed.dispose();
    auth.dispose();
  });

  test('syncing an empty watch list unsubscribes everything', () async {
    await setUpService();
    final feed = build();

    await feed.sync([sub('3045', key: 'NSE:SBIN')]);
    await feed.sync(const []);

    expect(feed.subscribedTokenCount, 0);
    expect(socket.messages.last['action'], 0);

    feed.dispose();
    auth.dispose();
  });
}
