// 1.5.88 — REGRESSION GUARD for the real Bankex "live data" bug.
//
// Bug: services jo apna naya `AuthService` banate hain (Bankex loader,
// backtest, background brief) unke paas in-memory session nahi hota tha, aur
// `ensureValidSession()` bina restore kiye `false` return karta tha — user
// logged in hone ke bawajood har market-data call "Not logged in" se fail.
//
// Ye test pin karta hai: naya instance → stored session se restore → valid.

import 'package:angel_trader/data/remote/dto/session.dart';
import 'package:angel_trader/services/auth_service.dart';
import 'package:angel_trader/services/secure_store.dart';
import 'package:flutter_test/flutter_test.dart';

/// SecureStore ki storage calls override — plugin channel touch nahi hota.
class _FakeStore extends SecureStore {
  _FakeStore({this.session});
  AngelSession? session;

  @override
  Future<AngelCredentials?> readCredentials() async => null;

  @override
  Future<AngelSession?> readSession() async => session;

  @override
  Future<void> clearSession() async => session = null;

  @override
  Future<void> writeSession(AngelSession s) async => session = s;
}

AngelSession _session({required Duration validFor}) => AngelSession(
      apiKey: 'k',
      clientCode: 'C1',
      jwtToken: 'jwt',
      refreshToken: 'refresh',
      feedToken: 'feed',
      generatedAt: DateTime.now().subtract(const Duration(hours: 2)),
    );

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('REGRESSION — naya AuthService stored session restore karta hai',
      () async {
    final store = _FakeStore(
        session: AngelSession(
      apiKey: 'k',
      clientCode: 'C1',
      jwtToken: 'jwt',
      refreshToken: 'refresh',
      feedToken: 'feed',
      generatedAt: DateTime.now(),
    ));

    // Bilkul wahi situation jo Bankex loader me thi: naya instance, uski
    // in-memory `_session` khaali.
    final auth = AuthService(store: store);
    expect(auth.session, isNull);

    final ok = await auth.ensureValidSession();

    // Pehle ye `false` aata tha (bug); ab restore hoke true aana chahiye.
    expect(ok, isTrue);
    expect(auth.session, isNotNull);
    expect(auth.isLoggedIn, isTrue);
  });

  test('session stored nahi hai to honestly false (crash nahi)', () async {
    final auth = AuthService(store: _FakeStore());
    expect(await auth.ensureValidSession(), isFalse);
  });

  test('dobara call — session in-memory hai, restore ki zaroorat nahi',
      () async {
    final auth = AuthService(store: _FakeStore(session: _session(validFor: const Duration(hours: 12))));
    expect(await auth.ensureValidSession(), isTrue);
    expect(await auth.ensureValidSession(), isTrue);
  });
}
