// ---------------------------------------------------------------------------
// cross_scan_service_test.dart — the Feature 2 scan, with a fake candle source.
//
// These tests run the real SQLite schema (sqflite FFI on the test VM), the real
// crossover maths and the real caching logic. The only thing faked is the
// network: FakeCandleSource counts its calls, so the tests can prove the cache
// actually prevents repeat downloads — which is the whole point of the design
// under Angel One's 3 requests/second limit.
// ---------------------------------------------------------------------------

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/candle_dao.dart';
import 'package:angel_trader/data/local/dao/scan_cache_dao.dart';
import 'package:angel_trader/data/remote/api_client.dart';
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/features/golden_cross/cross_engine.dart';
import 'package:angel_trader/services/candle_source.dart';
import 'package:angel_trader/services/cross_scan_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

// ---------------------------------------------------------------------------
// Fakes + data builders
// ---------------------------------------------------------------------------

/// Counts requests and returns canned bars per token.
class FakeCandleSource implements CandleSource {
  FakeCandleSource(this.barsByToken);

  final Map<String, List<Candle>> barsByToken;
  final List<String> requestedTokens = [];
  final List<DateTime> requestedTo = [];

  /// Tokens that should throw, to exercise the failure path.
  final Set<String> failTokens = {};

  int get callCount => requestedTokens.length;

  @override
  Future<List<Candle>> fetchDailyCandles({
    required Scrip scrip,
    required DateTime from,
    required DateTime to,
    String interval = 'ONE_DAY',
  }) async {
    requestedTokens.add(scrip.token);
    requestedTo.add(to);
    if (failTokens.contains(scrip.token)) {
      throw const ApiException(message: 'Rate limit reached.');
    }
    return barsByToken[scrip.token] ?? const [];
  }
}

List<double> ramp(int count, double from, double to) => [
      for (var i = 0; i < count; i++)
        count == 1 ? from : from + (to - from) * (i / (count - 1)),
    ];

/// Daily bars, one per calendar day, starting **on** [start].
List<Candle> series(List<double> closes, {DateTime? start}) {
  final bars = <Candle>[];
  var day = start ?? DateTime(2023, 1, 2);
  for (final close in closes) {
    bars.add(Candle(
      time: day,
      open: close,
      high: close * 1.01,
      low: close * 0.99,
      close: close,
      volume: 500,
    ));
    day = day.add(const Duration(days: 1));
  }
  return bars;
}

/// Shape verified with tool/probe_cross.dart: a long decline followed by a long
/// rise puts the 50-SMA below the 200-SMA once the 200-SMA first exists, and the
/// cross happens 59 sessions before the end of the full 340-bar series. Cutting
/// the series at the cross bar therefore produces a *fresh* signal — which is
/// what a screener's users actually look for.
List<double> goldenShape() => [...ramp(220, 300, 100), ...ramp(120, 100, 300)];

/// Same idea for a death cross (360 bars, cross 74 sessions before the end).
List<double> deathShape() => [...ramp(220, 100, 320), ...ramp(140, 320, 110)];

/// 281 bars ending exactly on a fresh golden cross.
List<Candle> goldenSeries({DateTime? start}) => series(
      goldenShape().sublist(0, goldenShape().length - 59),
      start: start ?? DateTime(2023, 1, 2),
    );

/// 286 bars ending exactly on a fresh death cross.
List<Candle> deathSeries({DateTime? start}) => series(
      deathShape().sublist(0, deathShape().length - 74),
      start: start ?? DateTime(2023, 1, 2),
    );

/// Only 40 bars — far too few for a 200-day average.
List<Candle> shortSeries({DateTime? start}) =>
    series(ramp(40, 100, 140), start: start ?? DateTime(2024, 1, 1));

Scrip scrip(String token, String symbol, {Exchange exchange = Exchange.nse}) =>
    Scrip(token: token, symbol: symbol, name: '$symbol Ltd', exchange: exchange);

void main() {
  late CandleDao candles;
  late ScanCacheDao cache;
  late FakeCandleSource source;

  /// The as-of date the canned series end on.
  DateTime asOfFor(List<Candle> bars) => bars.last.istDate;

  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close();
    final db = AppDatabase.instance;
    candles = CandleDao(db);
    cache = ScanCacheDao(db);
    source = FakeCandleSource({});
  });

  tearDown(() async {
    await AppDatabase.instance.close();
  });

  CrossScanService buildService() => CrossScanService(
        source: source,
        candles: candles,
        cache: cache,
      );

  // -------------------------------------------------------------------------
  group('scan', () {
    test('finds a golden cross and reports the run statistics', () async {
      final bars = goldenSeries();
      source = FakeCandleSource({'111': bars});

      final result = await buildService().scan(
        universe: [scrip('111', 'GOLDEN-EQ')],
        asOf: asOfFor(bars),
        universeKey: 'nifty50',
      );

      expect(result.scanned, 1);
      expect(result.fetched, 1);
      expect(result.fromCache, 0);
      expect(result.universeKey, 'nifty50');
      expect(result.goldenCount, 1);
      expect(result.deathCount, 0);
      expect(result.hitCount, 1);

      final signal = result.signals.single;
      expect(signal.symbol, 'GOLDEN'); // plain ticker, no -EQ
      expect(signal.companyName, 'GOLDEN-EQ Ltd');
      expect(signal.direction, CrossDirection.golden);
      expect(signal.gapPct, greaterThan(0));
      expect(signal.spark, isNotEmpty);
    });

    test('golden-only scans do not record death crosses', () async {
      final bars = deathSeries();
      source = FakeCandleSource({'222': bars});
      final service = buildService();

      final both = await service.scan(
        universe: [scrip('222', 'DEAD-EQ')],
        asOf: asOfFor(bars),
        includeDeath: true,
      );
      expect(both.deathCount, 1);

      // Fresh database state, same data, death disabled.
      await candles.clear();
      await cache.clearRuns(CrossScanService.cacheKind);

      final goldenOnly = await service.scan(
        universe: [scrip('222', 'DEAD-EQ')],
        asOf: asOfFor(bars),
        includeDeath: false,
      );
      expect(goldenOnly.goldenCount, 0);
      expect(goldenOnly.deathCount, 0);
      expect(goldenOnly.hitCount, 0);
    });

    test('second scan of the same session hits the candle cache', () async {
      final bars = goldenSeries();
      source = FakeCandleSource({'111': bars});
      final service = buildService();
      final universe = [scrip('111', 'GOLDEN-EQ')];

      final first = await service.scan(universe: universe, asOf: asOfFor(bars));
      expect(first.fetched, 1);
      expect(source.callCount, 1);

      final second = await service.scan(universe: universe, asOf: asOfFor(bars));
      expect(second.fromCache, 1);
      expect(second.fetched, 0);
      expect(source.callCount, 1, reason: 'the cache must prevent a re-download');
      expect(second.goldenCount, 1);
    });

    test('skips instruments without enough history, with a reason', () async {
      final bars = shortSeries();
      source = FakeCandleSource({'333': bars});

      final result = await buildService().scan(
        universe: [scrip('333', 'NEWIPO-EQ')],
        asOf: asOfFor(bars),
      );

      expect(result.signals, isEmpty);
      expect(result.skips, hasLength(1));
      expect(result.skips.single.symbol, 'NEWIPO');
      expect(result.skips.single.reason, contains('daily bars available'));
    });

    test('a failing fetch becomes a skip, not a crash', () async {
      final bars = goldenSeries();
      source = FakeCandleSource({'111': bars})..failTokens.add('444');

      final result = await buildService().scan(
        universe: [
          scrip('111', 'GOOD-EQ'),
          scrip('444', 'BAD-EQ'),
        ],
        asOf: asOfFor(bars),
      );

      expect(result.scanned, 1);
      expect(result.goldenCount, 1);
      expect(result.skips.single.symbol, 'BAD');
      expect(result.skips.single.reason, contains('Rate limit'));
    });

    test('cancellation keeps what was already scanned', () async {
      final bars = goldenSeries();
      source = FakeCandleSource({
        '111': bars,
        '222': bars,
        '333': bars,
      });

      var seen = 0;
      final result = await buildService().scan(
        universe: [
          scrip('111', 'A-EQ'),
          scrip('222', 'B-EQ'),
          scrip('333', 'C-EQ'),
        ],
        asOf: asOfFor(bars),
        onProgress: (_) => seen++,
        isCancelled: () => seen >= 1,
      );

      expect(result.cancelled, isTrue);
      expect(seen, 1);
      expect(result.scanned, 1);
      expect(result.signals, hasLength(1));
    });

    test('progress reports totals, cache hits and failures', () async {
      final bars = goldenSeries();
      source = FakeCandleSource({'111': bars, '333': shortSeries()});
      final progress = <CrossScanProgress>[];

      await buildService().scan(
        universe: [scrip('111', 'A-EQ'), scrip('333', 'B-EQ')],
        asOf: asOfFor(bars),
        onProgress: progress.add,
      );

      expect(progress, hasLength(2));
      expect(progress.last.done, 2);
      expect(progress.last.total, 2);
      expect(progress.last.hits, 1);
      expect(progress.last.current, 'B');
      expect(progress.last.fraction, closeTo(1, 1e-9));
      expect(progress.last.eta.inMilliseconds, greaterThanOrEqualTo(0));
    });

    test('maxAgeBars is passed through to the engine', () async {
      // The untruncated shape crosses 59 sessions before its last bar, so a
      // today-only window must find nothing while a 60-session window finds it.
      final bars = series(goldenShape());
      source = FakeCandleSource({'111': bars});
      final service = buildService();

      final wide = await service.scan(
        universe: [scrip('111', 'A-EQ')],
        asOf: asOfFor(bars),
        maxAgeBars: 60,
      );
      expect(wide.hitCount, 1);
      expect(wide.signals.single.ageBars, 59);

      final fresh = await service.scan(
        universe: [scrip('111', 'A-EQ')],
        asOf: asOfFor(bars),
        maxAgeBars: 0,
      );
      expect(fresh.hitCount, 0);
    });
  });

  // -------------------------------------------------------------------------
  group('caching', () {
    test('results are persisted and rehydrated with every field intact', () async {
      final bars = goldenSeries();
      source = FakeCandleSource({'111': bars});
      final service = buildService();
      final asOf = asOfFor(bars);

      final scanned = await service.scan(
        universe: [scrip('111', 'GOLDEN-EQ')],
        asOf: asOf,
      );

      final cached = await service.loadCached();
      expect(cached, isNotNull);
      expect(cached!.fromCacheOnly, isTrue);
      expect(cached.signals, hasLength(scanned.hitCount));

      final a = scanned.signals.single;
      final b = cached.signals.single;
      expect(b.symbol, a.symbol);
      expect(b.crossDate, a.crossDate);
      expect(b.ageBars, a.ageBars);
      expect(b.fast, closeTo(a.fast, 1e-3));
      expect(b.slow, closeTo(a.slow, 1e-3));
      expect(b.spark.length, a.spark.length);
    });

    test('loadCached can fetch a specific past session', () async {
      final bars = goldenSeries();
      source = FakeCandleSource({'111': bars});
      final service = buildService();
      final asOf = asOfFor(bars);

      await service.scan(universe: [scrip('111', 'A-EQ')], asOf: asOf);

      expect(await service.loadCached(asOf: asOf), isNotNull);
      expect(await service.loadCached(asOf: DateTime(2020, 1, 1)), isNull);
    });

    test('rescanning a session replaces that session\'s run', () async {
      final bars = goldenSeries();
      source = FakeCandleSource({'111': bars});
      final service = buildService();
      final asOf = asOfFor(bars);

      await service.scan(universe: [scrip('111', 'A-EQ')], asOf: asOf);
      await service.scan(universe: [scrip('111', 'A-EQ')], asOf: asOf);

      final cached = await service.loadCached(asOf: asOf);
      expect(cached!.signals, hasLength(1), reason: 'no duplicate run rows');
    });

    test('clearCache wipes the stored scan', () async {
      final bars = goldenSeries();
      source = FakeCandleSource({'111': bars});
      final service = buildService();
      await service.scan(
        universe: [scrip('111', 'A-EQ')],
        asOf: asOfFor(bars),
      );

      await service.clearCache();
      expect(await service.loadCached(), isNull);
    });

    test('candle cache is pruned to the retention window', () async {
      // Bars ending in 2024 → a scan in 2026 must sweep them away.
      final old = goldenSeries(start: DateTime(2023, 6, 1));
      source = FakeCandleSource({'111': old});
      final service = buildService();

      await service.scan(
        universe: [scrip('111', 'A-EQ')],
        asOf: asOfFor(old),
      );
      expect(await candles.barCount(exchange: 'NSE', symbol: 'A-EQ'), greaterThan(0));

      // A much later scan (which fetches its own bars) prunes the old rows.
      final recent = goldenSeries(start: DateTime(2025, 9, 1));
      source = FakeCandleSource({'111': recent});
      await service.scan(
        universe: [scrip('111', 'A-EQ')],
        asOf: asOfFor(recent),
      );

      final stored = await candles.barsFor(exchange: 'NSE', symbol: 'A-EQ');
      expect(
        stored.every((c) => c.istDate.isAfter(DateTime(2024, 1, 1))),
        isTrue,
        reason: 'bars older than the retention window must be pruned',
      );
    });
  });

  // -------------------------------------------------------------------------
  group('candle cache itself', () {
    test('upserts, filters by date range and survives a replace-window save', () async {
      final bars = series(ramp(30, 100, 130), start: DateTime(2025, 1, 1));

      await candles.saveBars(
        exchange: 'NSE',
        symbol: 'TEST-EQ',
        bars: bars,
      );
      expect(await candles.barCount(exchange: 'NSE', symbol: 'TEST-EQ'), 30);
      expect(await candles.instrumentCount(), 1);

      // Same window again: no duplicates.
      await candles.saveBars(
        exchange: 'NSE',
        symbol: 'TEST-EQ',
        bars: bars,
        replaceWindow: true,
        windowFrom: bars.first.time,
        windowTo: bars.last.time,
      );
      expect(await candles.barCount(exchange: 'NSE', symbol: 'TEST-EQ'), 30);

      final window = await candles.barsFor(
        exchange: 'NSE',
        symbol: 'TEST-EQ',
        from: DateTime(2025, 1, 10),
        to: DateTime(2025, 1, 20),
      );
      expect(window, hasLength(11));
      expect(window.first.istDate, DateTime(2025, 1, 10));
      expect(window.last.istDate, DateTime(2025, 1, 20));

      final last = await candles.lastBarDate('NSE', 'TEST-EQ');
      expect(last, bars.last.istDate);
    });

    test('deleteFor removes one instrument only', () async {
      final bars = series(ramp(10, 100, 110), start: DateTime(2025, 2, 1));
      await candles.saveBars(exchange: 'NSE', symbol: 'A-EQ', bars: bars);
      await candles.saveBars(exchange: 'NSE', symbol: 'B-EQ', bars: bars);

      await candles.deleteFor('NSE', 'A-EQ');
      expect(await candles.barCount(exchange: 'NSE', symbol: 'A-EQ'), 0);
      expect(await candles.barCount(exchange: 'NSE', symbol: 'B-EQ'), 10);
    });
  });
}
