import 'dart:async';

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/scrip_dao.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/services/nse_listing_service.dart';
import 'package:angel_trader/services/stock_suggestion_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  group('StockSuggestionService scoring', () {
    const rows = [
      StockSuggestion(
        symbol: 'SBILIFE',
        companyName: 'SBI Life Insurance Company Ltd',
        exchange: 'NSE',
        isin: 'INE123W01016',
      ),
      StockSuggestion(
        symbol: 'SBIN',
        companyName: 'State Bank of India',
        exchange: 'NSE',
        isin: 'INE062A01020',
      ),
      StockSuggestion(
        symbol: '540719',
        companyName: 'SBI Life Insurance Company Ltd',
        exchange: 'BSE',
        isin: 'INE123W01016',
        scripCode: '540719',
      ),
      StockSuggestion(
        symbol: 'HDFCLIFE',
        companyName: 'HDFC Life Insurance Company Limited',
        exchange: 'NSE',
      ),
    ];

    test('exact ticker beats prefix beats substring beats name words', () {
      expect(StockSuggestionService.scoreMatch('SBIN', rows[1]), 0);
      expect(StockSuggestionService.scoreMatch('SBI', rows[1]), 1);
      expect(StockSuggestionService.scoreMatch('BIN', rows[1]), 2);
      expect(StockSuggestionService.scoreMatch('STATE', rows[1]), 3);
      // Mid-word name fragments fall to the lowest rank.
      expect(StockSuggestionService.scoreMatch('ANK', rows[1]), 4);
      expect(StockSuggestionService.scoreMatch('ZZZ', rows[1]), -1);
    });

    test('search ranks and limits results', () {
      final matches = StockSuggestionService.searchIn(rows, 'SBI');
      expect(matches, isNotEmpty);
      expect(matches.first.symbol, 'SBILIFE'); // prefix, shorter rank wins
      expect(matches.map((e) => e.symbol), contains('SBIN'));
      expect(StockSuggestionService.searchIn(rows, 'SBI', limit: 1).length, 1);
    });

    test('numeric codes search by digits and names search by words', () {
      expect(
        StockSuggestionService.searchIn(rows, '540719').single.symbol,
        '540719',
      );
      final insurance = StockSuggestionService.searchIn(rows, 'INSURANCE');
      expect(insurance.length, 3); // SBILIFE NSE+BSE + HDFCLIFE by name
    });

    test('blank queries return nothing', () {
      expect(StockSuggestionService.searchIn(rows, ''), isEmpty);
      expect(StockSuggestionService.searchIn(rows, '   '), isEmpty);
    });
  });

  group('StockSuggestionService master', () {
    late SettingsDao settings;

    setUpAll(() {
      sqfliteFfiInit();
      databaseFactory = databaseFactoryFfi;
    });

    setUp(() async {
      AppDatabase.overridePath = inMemoryDatabasePath;
      await AppDatabase.instance.close();
      settings = SettingsDao(AppDatabase.instance);
    });

    test('the four problem names resolve through the real master', () async {
      // Real NseListingService over an EQUITY_L-shaped fixture (the four
      // names from the phone report), empty broker master.
      final client = MockClient((request) async => http.Response(_equityL, 200));
      final service = StockSuggestionService(
        listings: NseListingService(settings: settings, client: client),
        scripDao: _FakeScripDao(),
      );
      for (final query in [
        'BHARTIARTL',
        'BHARTI AIRTEL',
        'HDFCLIFE',
        'HDFC LIFE',
        'SBILIFE',
        'SIEMENS',
        'VAML',
        'VEDANTA ALUMINIUM',
      ]) {
        final hits = await service.search(query);
        expect(hits, isNotEmpty, reason: 'search "$query" ko dhoondh nahi paya');
      }
      final bharti = await service.search('bharti airtel');
      expect(bharti.first.symbol, 'BHARTIARTL');
      expect(bharti.first.companyName, 'Bharti Airtel Limited');
      final vaml = await service.search('VAML');
      expect(vaml.first.symbol, 'VAML');
    });

    test('dual-listed broker rows collapse to the NSE listing row', () async {
      // A broker-master BSE row for a dual-listed name carries no ISIN of its
      // own; the listing master's ISIN enriches it, the dedupe collapses it,
      // and the dropdown shows the one NSE row — no coin-flip between two
      // identical names where one used to break the scan.
      final client = MockClient((request) async => http.Response(_equityL, 200));
      final service = StockSuggestionService(
        listings: NseListingService(settings: settings, client: client),
        scripDao: _FakeScripDao(
          const Scrip(
            token: '1',
            symbol: 'SIEMENS',
            name: 'Siemens Limited',
            exchange: Exchange.bse,
          ),
        ),
      );
      final rows = await service.master();
      final siemens = rows.where((r) => r.symbol == 'SIEMENS').toList();
      expect(siemens, hasLength(1));
      expect(siemens.single.exchange, 'NSE');
      expect(siemens.single.isin, 'INE003A01024');
    });

    test(
      'an expired list still answers instantly while the refresh runs',
      () async {
        // Second-line defence for flaky networks: once a list exists, an
        // expired/degraded cache must never make the dropdown wait again.
        final service = StockSuggestionService(
          listings: _HangingListings(settings),
          scripDao: _FakeScripDao(
            const Scrip(
              token: '1',
              symbol: 'SIEMENS',
              name: 'Siemens Limited',
              exchange: Exchange.nse,
            ),
          ),
          listingTimeout: const Duration(milliseconds: 150),
        );
        final first = await service.search('SIEMENS'); // builds (degraded)
        expect(first, isNotEmpty);
        final started = DateTime.now();
        final second = await service.search('SIEMENS'); // stale, instant
        expect(
          DateTime.now().difference(started),
          lessThan(const Duration(milliseconds: 400)),
          reason: 'second search ko stale list instantly deni chahiye',
        );
        expect(second.map((e) => e.symbol), contains('SIEMENS'));
      },
    );

    test(
      'a hanging NSE master cannot hold the dropdown hostage',
      () async {
        // The phone symptom: the listing download stalls on a blocked
        // network. Suggestions must still arrive — from the broker master —
        // within the small listingTimeout, not the download's own minute.
        final service = StockSuggestionService(
          listings: _HangingListings(settings),
          scripDao: _FakeScripDao(
            const Scrip(
              token: '1',
              symbol: 'SIEMENS',
              name: 'Siemens Limited',
              exchange: Exchange.nse,
            ),
          ),
          listingTimeout: const Duration(milliseconds: 150),
        );
        final started = DateTime.now();
        final hits = await service.search('SIEMENS');
        expect(
          DateTime.now().difference(started),
          lessThan(const Duration(seconds: 3)),
          reason: 'suggestions ko listing timeout ke turant baad aana chahiye',
        );
        expect(hits.map((e) => e.symbol), contains('SIEMENS'));
      },
    );
  });
}

/// EQUITY_L.csv shape (official header + the four reported names).
const _equityL = '''
SYMBOL, NAME OF COMPANY, SERIES, DATE OF LISTING, PAID UP VALUE, MARKET LOT, ISIN NUMBER, FACE VALUE
BHARTIARTL, Bharti Airtel Limited, EQ, 02-FEB-2002, 5, 1, INE397D01024, 5
HDFCLIFE, HDFC Life Insurance Company Limited, EQ, 17-NOV-2017, 10, 1, INE795G01014, 10
SBILIFE, SBI Life Insurance Company Ltd, EQ, 03-OCT-2017, 10, 1, INE123W01016, 10
SIEMENS, Siemens Limited, EQ, 01-JAN-2025, 2, 1, INE003A01024, 2
VAML, Vedanta Aluminium Metal Ltd, EQ, 15-JUN-2026, 1, 1, INE1CDF01017, 1
''';

class _FakeScripDao implements ScripDao {
  _FakeScripDao([Scrip? row]) : _rows = [if (row != null) row];

  final List<Scrip> _rows;

  @override
  Future<List<Scrip>> allEquities() async => _rows;

  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

class _HangingListings extends NseListingService {
  _HangingListings(SettingsDao settings) : super(settings: settings);

  @override
  Future<List<NseListing>> allListings({bool force = false}) =>
      Completer<List<NseListing>>().future; // never settles
}
