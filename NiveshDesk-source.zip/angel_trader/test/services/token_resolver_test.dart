// Token resolution tests — this is what turns `IDEA` (as stored in the IPO
// database) into the numeric SmartAPI token `1594`.
//
// The sample master below mirrors the real scrip-master row shape, including
// non-equity rows that must be filtered out.

import 'dart:convert';

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/services/token_resolver.dart';
import 'package:flutter_test/flutter_test.dart';

const _masterRows = <Map<String, dynamic>>[
  {
    'token': '3045',
    'symbol': 'SBIN-EQ',
    'name': 'STATE BANK OF INDIA',
    'expiry': '',
    'strike': '-1.00',
    'lotsize': '1',
    'instrumenttype': '',
    'exch_seg': 'NSE',
    'tick_size': '5.000000',
  },
  {
    'token': '500112',
    'symbol': 'SBIN',
    'name': 'STATE BANK OF INDIA',
    'expiry': '',
    'strike': '',
    'lotsize': '1',
    'instrumenttype': '',
    'exch_seg': 'BSE',
    'tick_size': '5.000000',
  },
  {
    'token': '1594',
    'symbol': 'IDEA-EQ',
    'name': 'VODAFONE IDEA LIMITED',
    'expiry': '',
    'strike': '-1.00',
    'lotsize': '1',
    'instrumenttype': '',
    'exch_seg': 'NSE',
    'tick_size': '5.000000',
  },
  {
    'token': '14366',
    'symbol': 'NYKAA-EQ',
    'name': 'FSN E COMMERCE VENTURES LIMITED',
    'expiry': '',
    'strike': '-1.00',
    'lotsize': '1',
    'instrumenttype': '',
    'exch_seg': 'NSE',
    'tick_size': '5.000000',
  },
  {
    'token': '543529',
    'symbol': 'DELHIVERY',
    'name': 'DELHIVERY LIMITED',
    'expiry': '',
    'strike': '',
    'lotsize': '1',
    'instrumenttype': '',
    'exch_seg': 'BSE',
    'tick_size': '5.000000',
  },
  {
    'token': '111',
    'symbol': 'ABCL-EQ',
    'name': 'ALPHA BETA CORP LIMITED',
    'expiry': '',
    'strike': '-1.00',
    'lotsize': '1',
    'instrumenttype': '',
    'exch_seg': 'NSE',
    'tick_size': '5.000000',
  },
  {
    'token': '112',
    'symbol': 'ABX-EQ',
    'name': 'ALPHA BETA CORP LIMITED',
    'expiry': '',
    'strike': '-1.00',
    'lotsize': '1',
    'instrumenttype': '',
    'exch_seg': 'NSE',
    'tick_size': '5.000000',
  },
  // --- must all be filtered out of the equity index ---
  {
    'token': '999999',
    'symbol': 'FINNIFTY',
    'name': 'NIFTY FIN SERVICE',
    'expiry': '',
    'strike': '',
    'lotsize': '',
    'instrumenttype': 'AMXIDX',
    'exch_seg': 'NSE',
    'tick_size': '5.000000',
  },
  {
    'token': '12345',
    'symbol': 'NIFTY25OCT25000CE',
    'name': 'NIFTY',
    'expiry': '30OCT2025',
    'strike': '25000',
    'lotsize': '75',
    'instrumenttype': 'OPTIDX',
    'exch_seg': 'NFO',
    'tick_size': '5.000000',
  },
  {
    'token': '234230',
    'symbol': 'GOLD25OCTFUT',
    'name': 'GOLD',
    'expiry': '05OCT2025',
    'strike': '',
    'lotsize': '100',
    'instrumenttype': 'FUTCOM',
    'exch_seg': 'MCX',
    'tick_size': '1.000000',
  },
];

void main() {
  late TokenResolver resolver;

  setUpAll(() {
    resolver = TokenResolver.fromJson(jsonEncode(_masterRows));
  });

  group('master filtering', () {
    test('keeps only cash-market equities', () {
      expect(resolver.size, 7); // SBIN x2, IDEA, NYKAA, DELHIVERY, ABCL, ABX
    });

    test('indices, options and commodity futures are excluded', () {
      final symbols = resolver.all.map((s) => s.symbol).toList();
      expect(symbols, isNot(contains('FINNIFTY')));
      expect(symbols, isNot(contains('NIFTY25OCT25000CE')));
      expect(symbols, isNot(contains('GOLD25OCTFUT')));
    });
  });

  group('resolve — exact ticker matches', () {
    test('plain ticker resolves on the preferred exchange', () {
      final r = resolver.resolve('IDEA', preferredExchange: Exchange.nse);
      expect(r.kind, TokenMatchKind.exact);
      expect(r.token, '1594');
      expect(r.scrip!.symbol, 'IDEA-EQ');
      expect(r.isResolved, isTrue);
    });

    test('case and the -EQ suffix do not matter', () {
      expect(resolver.resolve('idea').token, '1594');
      expect(resolver.resolve('idea-eq').token, '1594');
      expect(resolver.resolve('  IDEA  ').token, '1594');
    });

    test('an exchange prefix overrides the caller preference', () {
      final r = resolver.resolve('BSE:SBIN', preferredExchange: Exchange.nse);
      expect(r.token, '500112');
      expect(r.scrip!.exchange, Exchange.bse);
    });

    test('same ticker on both exchanges picks the preferred one', () {
      expect(resolver.resolve('SBIN', preferredExchange: Exchange.nse).token, '3045');
      expect(resolver.resolve('SBIN', preferredExchange: Exchange.bse).token, '500112');
    });
  });

  group('resolve — fallbacks', () {
    test('a BSE-only listing resolves cross-exchange', () {
      final r = resolver.resolve('DELHIVERY', preferredExchange: Exchange.nse);
      expect(r.kind, TokenMatchKind.crossExchange);
      expect(r.token, '543529');
      expect(r.scrip!.exchange, Exchange.bse);
      expect(r.note, contains('BSE'));
    });

    test('company name finds the ticker when the symbol differs from the IPO row', () {
      final r = resolver.resolve(
        'FSNVENTURES', // not a real ticker
        preferredExchange: Exchange.nse,
        companyName: 'FSN E-Commerce Ventures Ltd', // as written in the IPO CSV
      );
      expect(r.kind, TokenMatchKind.nameMatch);
      expect(r.token, '14366');
    });

    test('ambiguous company names return candidates for the UI to disambiguate', () {
      final r = resolver.resolve(
        'UNKNOWN',
        companyName: 'Alpha Beta Corp Ltd',
      );
      expect(r.kind, TokenMatchKind.ambiguous);
      expect(r.scrip, isNull);
      expect(r.candidates.length, 2);
      expect(r.isResolved, isFalse);
    });

    test('unknown ticker → none, with a readable note', () {
      final r = resolver.resolve('POLICYBZR', preferredExchange: Exchange.nse);
      expect(r.kind, TokenMatchKind.none);
      expect(r.note, contains('not found'));
    });

    test('empty input is handled without throwing', () {
      final r = resolver.resolve('   ');
      expect(r.kind, TokenMatchKind.none);
      expect(r.note, contains('Empty'));
    });
  });

  group('search', () {
    test('matches on ticker and on company name', () {
      expect(resolver.search('vodafone').first.symbol, 'IDEA-EQ');
      expect(resolver.search('SBIN').map((s) => s.exchange).toSet(),
          {Exchange.nse, Exchange.bse});
      expect(resolver.search('').isEmpty, isTrue);
    });

    test('respects the limit', () {
      expect(resolver.search('A', limit: 2).length, lessThanOrEqualTo(2));
    });
  });

  group('Scrip helpers', () {
    test('plainSymbol strips the NSE suffix TradingView does not want', () {
      expect(Scrip.plainSymbol('SBIN-EQ'), 'SBIN');
      expect(Scrip.plainSymbol('IDEA-BE'), 'IDEA');
      expect(Scrip.plainSymbol('NYKAA-BZ'), 'NYKAA');
      expect(Scrip.plainSymbol('DELHIVERY'), 'DELHIVERY');
    });

    test('fromScripMaster reads token, name, exchange and tick size', () {
      final scrip = Scrip.fromScripMaster(_masterRows.first);
      expect(scrip.token, '3045');
      expect(scrip.symbol, 'SBIN-EQ');
      expect(scrip.name, 'STATE BANK OF INDIA');
      expect(scrip.exchange, Exchange.nse);
      expect(scrip.tickSize, closeTo(0.05, 1e-9));
      expect(scrip.key, 'NSE:SBIN-EQ');
      expect(scrip.tradingViewUrl, contains('NSE:SBIN'));
    });

    test('isEquityRow gates the master exactly like the index does', () {
      expect(Scrip.isEquityRow(_masterRows[0]), isTrue); // NSE -EQ
      expect(Scrip.isEquityRow(_masterRows[4]), isTrue); // BSE plain
      expect(Scrip.isEquityRow(_masterRows[7]), isFalse); // index
      expect(Scrip.isEquityRow(_masterRows[8]), isFalse); // NFO option
      expect(Scrip.isEquityRow(_masterRows[9]), isFalse); // MCX future
    });
  });
}
