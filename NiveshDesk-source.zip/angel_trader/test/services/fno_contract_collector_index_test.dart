// 1.5.83 — Index options ab local option book me aate hain (Bankex module ke
// live load ke liye). Ye test pin karta hai ki kya accept hota hai aur kya
// reject — taaki 3-Month Study ka stock-option book na badle.

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/features/fno/bankex/sample_data.dart';
import 'package:angel_trader/data/local/dao/fno_contract_dao.dart';
import 'package:angel_trader/services/fno_contract_collector.dart';
import 'package:flutter_test/flutter_test.dart';

Map<String, dynamic> row({
  required String segment,
  required String instrument,
  required String name,
  required String symbol,
  required double strikeRupees,
  String expiry = '26NOV2026',
  String token = '12345',
}) =>
    {
      'exch_seg': segment,
      'instrumenttype': instrument,
      'name': name,
      'symbol': symbol,
      'token': token,
      'expiry': expiry,
      // Master paise me bhejta hai.
      'strike': '${(strikeRupees * 100).toStringAsFixed(6)}',
      'lotsize': '30',
    };

void main() {
  FnoContractCollector collector() =>
      FnoContractCollector(today: DateTime(2026, 11, 11));

  test('BANKNIFTY index options (NFO/OPTIDX) accept hote hain', () {
    final c = collector();
    final ok = c.addRow(row(
      segment: 'NFO',
      instrument: 'OPTIDX',
      name: 'BANKNIFTY',
      symbol: 'BANKNIFTY26NOV60100CE',
      strikeRupees: 60100,
    ));
    expect(ok, isTrue);
    expect(c.accepted, 1);
    final built = c.build();
    expect(built, hasLength(1));
    expect(built.single.underlying, 'BANKNIFTY');
    expect(built.single.strike, 60100);
    expect(built.single.optionType, 'CE');
  });

  test('BANKEX index options (BFO/OPTIDX) accept hote hain', () {
    final c = collector();
    final ok = c.addRow(row(
      segment: 'BFO',
      instrument: 'OPTIDX',
      name: 'BANKEX',
      symbol: 'BANKEX26NOV62300PE',
      strikeRupees: 62300,
      token: '999',
    ));
    expect(ok, isTrue);
    final built = c.build().single;
    expect(built.underlying, 'BANKEX');
    expect(built.optionType, 'PE');
    expect(built.strike, 62300);
  });

  test('doosre index (NIFTY) aur BSE stock options reject — book na bade', () {
    final c = collector();
    expect(
        c.addRow(row(
          segment: 'NFO',
          instrument: 'OPTIDX',
          name: 'NIFTY',
          symbol: 'NIFTY26NOV25000CE',
          strikeRupees: 25000,
        )),
        isFalse);
    expect(
        c.addRow(row(
          segment: 'BFO',
          instrument: 'OPTSTK',
          name: 'RELIANCE',
          symbol: 'RELIANCE26NOV3000CE',
          strikeRupees: 3000,
        )),
        isFalse);
    expect(
        c.addRow(row(
          segment: 'NFO',
          instrument: 'FUTIDX',
          name: 'BANKNIFTY',
          symbol: 'BANKNIFTY26NOVFUT',
          strikeRupees: 60100,
        )),
        isFalse);
    expect(c.build(), isEmpty);
  });

  test('purana behaviour intact — NFO stock options (OPTSTK) ab bhi accept',
      () {
    final c = collector();
    expect(
        c.addRow(row(
          segment: 'NFO',
          instrument: 'OPTSTK',
          name: 'RELIANCE',
          symbol: 'RELIANCE26NOV3000CE',
          strikeRupees: 3000,
        )),
        isTrue);
    expect(c.build().single.underlying, 'RELIANCE');
  });

  test('asScrip — BANKEX → BFO, baaki → NFO (quotes sahi segment me jaayein)',
      () {
    final bankex = FnoContract(
      underlying: 'BANKEX',
      expiryLabel: '26NOV2026',
      expiryDate: DateTime(2026, 11, 26),
      strike: 62300,
      optionType: 'CE',
      token: '999',
      symbol: 'BANKEX26NOV62300CE',
    );
    expect(bankex.asScrip().exchange, Exchange.bfo);
    expect(bankex.asScrip().exchange.code, 'BFO');

    final bn = FnoContract(
      underlying: 'BANKNIFTY',
      expiryLabel: '26NOV2026',
      expiryDate: DateTime(2026, 11, 26),
      strike: 60100,
      optionType: 'PE',
      token: '111',
      symbol: 'BANKNIFTY26NOV60100PE',
    );
    expect(bn.asScrip().exchange, Exchange.nfo);

    final stock = FnoContract(
      underlying: 'RELIANCE',
      expiryLabel: '26NOV2026',
      expiryDate: DateTime(2026, 11, 26),
      strike: 3000,
      optionType: 'CE',
      token: '222',
      symbol: 'RELIANCE26NOV3000CE',
    );
    expect(stock.asScrip().exchange, Exchange.nfo);
  });

  test('Exchange.fromCode BFO + isCash (IPO chips me BFO nahi)', () {
    expect(Exchange.fromCode('BFO'), Exchange.bfo);
    expect(Exchange.bfo.isCash, isFalse);
    expect(Exchange.nfo.isCash, isFalse);
    expect(Exchange.nse.isCash, isTrue);
  });

  test('MarketSnapshot.warnings default khaali (backward compatible)', () {
    final m = SampleData.snapshot();
    expect(m.warnings, isEmpty);
  });
}
