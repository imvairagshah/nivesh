// ---------------------------------------------------------------------------
// scrip_master_probe_test.dart — the "do not download 34 MB for nothing" rule.
//
// Angel One republishes the ~34 MB scrip master once a day; on weekends and
// holidays the file is often byte-identical to the previous one, and a second
// app launch on the same day never needs it again. The app therefore asks the
// host for the file's `Last-Modified` with a **1 KB ranged request** and only
// downloads when that fingerprint changed.
//
// The skip decision itself is a pure function, pinned here. Two properties
// matter more than the happy path:
//   * a *forced* refresh (the user pressed "Download latest", or the F&O
//     coverage check found the local copy thin) must never be skipped — a
//     repair has to really re-fetch; and
//   * unknown timestamps must fall back to downloading, never to skipping.
// ---------------------------------------------------------------------------

import 'package:angel_trader/data/remote/api_client.dart';
import 'package:angel_trader/services/scrip_master_service.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  final fileDate = DateTime.utc(2026, 10, 6, 2, 30, 5);

  group('skip decision', () {
    test('same file date + cached rows → skip the download', () {
      expect(
        ScripMasterService.canSkipDownload(
          remoteFileDate: fileDate,
          storedFileDate: fileDate,
          rowCount: 12000,
          force: false,
        ),
        isTrue,
      );
    });

    test('a newer file date → download', () {
      expect(
        ScripMasterService.canSkipDownload(
          remoteFileDate: DateTime.utc(2026, 10, 7, 2, 30),
          storedFileDate: fileDate,
          rowCount: 12000,
          force: false,
        ),
        isFalse,
      );
    });

    test('force always downloads (the copy may be damaged, not just old)', () {
      expect(
        ScripMasterService.canSkipDownload(
          remoteFileDate: fileDate,
          storedFileDate: fileDate,
          rowCount: 12000,
          force: true,
        ),
        isFalse,
      );
    });

    test('nothing cached → download', () {
      expect(
        ScripMasterService.canSkipDownload(
          remoteFileDate: fileDate,
          storedFileDate: fileDate,
          rowCount: 0,
          force: false,
        ),
        isFalse,
      );
    });

    test('unknown timestamps → download (never guess)', () {
      expect(
        ScripMasterService.canSkipDownload(
          remoteFileDate: null,
          storedFileDate: fileDate,
          rowCount: 12000,
          force: false,
        ),
        isFalse,
      );
      expect(
        ScripMasterService.canSkipDownload(
          remoteFileDate: fileDate,
          storedFileDate: null,
          rowCount: 12000,
          force: false,
        ),
        isFalse,
      );
    });

    test('timezone noise does not defeat the comparison', () {
      // The host sends UTC; the stored value round-trips through ISO-8601 and
      // comes back as the same instant in whatever zone the phone is in.
      expect(
        ScripMasterService.canSkipDownload(
          remoteFileDate: fileDate,
          storedFileDate: fileDate.toLocal(),
          rowCount: 12000,
          force: false,
        ),
        isTrue,
      );
    });
  });

  group('Last-Modified parsing', () {
    test('reads the format the host actually sends', () {
      // Captured from a live range request:
      //   last-modified: Tue, 06 Oct 2026 02:30:05 GMT
      expect(
        ApiClient.parseHttpDate('Tue, 06 Oct 2026 02:30:05 GMT'),
        DateTime.utc(2026, 10, 6, 2, 30, 5),
      );
      expect(
        ApiClient.parseHttpDate('Mon, 01 Jan 2024 00:00:00 GMT'),
        DateTime.utc(2024, 1, 1),
      );
    });

    test('rejects junk instead of inventing a date', () {
      expect(ApiClient.parseHttpDate(''), isNull);
      expect(ApiClient.parseHttpDate('not a date'), isNull);
      expect(ApiClient.parseHttpDate('Tue, 06 Xxx 2026 02:30:05 GMT'), isNull);
      expect(ApiClient.parseHttpDate('Tue, 06 Oct 2026 GMT'), isNull);
    });
  });
}
