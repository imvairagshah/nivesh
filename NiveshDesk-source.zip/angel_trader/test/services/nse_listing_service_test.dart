// ---------------------------------------------------------------------------
// nse_listing_service_test.dart — parsing NSE's official equity master.
//
// The real file is messy in specific, known ways (leading spaces in the header,
// month names in CAPS, one row per series including debt). Each of those is
// pinned here, plus the cache round-trip, so a future format tweak fails a test
// instead of silently discovering nothing.
// ---------------------------------------------------------------------------

import 'dart:convert';

import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/services/nse_listing_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

/// A faithful slice of EQUITY_L.csv: header spaces, caps months, several series.
const String _sample = '''
SYMBOL, NAME OF COMPANY, SERIES, DATE OF LISTING, PAID UP VALUE, MARKET LOT, ISIN NUMBER, FACE VALUE
SWIGGY, Swiggy Limited, EQ, 13-NOV-2024, 1, 1, INE0H8Y01015, 1
ITCHOTELS, ITC Hotels Limited, EQ, 29-JAN-2025, 1, 1, INE379A01028, 1
IDEA, Vodafone Idea Limited, EQ, 09-FEB-2007, 10, 1, INE669E01016, 10
SBIN, State Bank of India, EQ, 01-MAR-1995, 1, 1, INE062A01020, 1
EMKAYTOOLS, Emkay Tools Limited, SM, 12-SEP-2018, 10, 600, INE0B01018, 10
SOMEDEBT, Some Debt Series, N6, 05-JUN-2021, 1000000, 1, INE000000000, 1000000
''';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late AppDatabase db;
  late SettingsDao settings;

  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close();
    db = AppDatabase.instance;
    settings = SettingsDao(db);
  });

  group('parseCsv', () {
    final now = DateTime(2026, 10, 4);

    test('reads the official columns despite the spaces in the header', () {
      final rows = NseListingService.parseCsv(_sample, now: now);

      final swiggy = rows.firstWhere((r) => r.symbol == 'SWIGGY');
      expect(swiggy.companyName, 'Swiggy Limited');
      expect(swiggy.series, 'EQ');
      expect(swiggy.listingDate, DateTime(2024, 11, 13)); // caps month parsed
      expect(swiggy.isMainboard, isTrue);
      expect(swiggy.faceValue, 1);
      // Older rows survive only with an explicit wider lookback — the
      // default two-year window drops them, which is itself the point.
      final wide = NseListingService.parseCsv(
        _sample,
        now: now,
        lookback: const Duration(days: 7200),
      );
      expect(wide.firstWhere((r) => r.symbol == 'IDEA').faceValue, 10);
    });

    test('a comma-shifted name row is dropped, never given a shifted face value', () {
      const shifted = '''
SYMBOL, NAME OF COMPANY, SERIES, DATE OF LISTING, PAID UP VALUE, MARKET LOT, ISIN NUMBER, FACE VALUE
SHIFTED, Shifted, Name Limited, EQ, 01-NOV-2025, 1, 1, INE000000001, 1
''';
      final rows = NseListingService.parseCsv(shifted, now: now);
      // Every column after the comma lands one cell to the left — the date
      // cell holds `EQ` and fails to parse, so the row is dropped rather
      // than kept with a mis-read face value. (The parseCsv face-value gate
      // re-checks the cell count as second line of defence.)
      expect(rows, isEmpty);
    });

    test('keeps SME rows but flags them, drops debt rows entirely', () {
      // A long lookback so the eight-year-old sample rows survive the cut-off.
      final rows = NseListingService.parseCsv(
        _sample,
        now: now,
        lookback: const Duration(days: 4000),
      );

      final sme = rows.firstWhere((r) => r.symbol == 'EMKAYTOOLS');
      expect(sme.isSme, isTrue);
      expect(sme.isMainboard, isFalse);

      expect(rows.any((r) => r.symbol == 'SOMEDEBT'), isFalse);
    });

    test('applies the lookback cut-off', () {
      // Wide window: recent listings in, the 1995 row out.
      final wide = NseListingService.parseCsv(
        _sample,
        now: now,
        lookback: const Duration(days: 800),
      );
      expect(wide.map((r) => r.symbol), containsAll(<String>['SWIGGY', 'ITCHOTELS']));
      expect(wide.map((r) => r.symbol), isNot(contains('SBIN')));

      // Narrow window: nothing in the sample is that fresh.
      final narrow = NseListingService.parseCsv(
        _sample,
        now: now,
        lookback: const Duration(days: 30),
      );
      expect(narrow, isEmpty);
    });

    test('a future listing date (exchange typo, clock skew) is still read', () {
      const text = 'SYMBOL, NAME OF COMPANY, SERIES, DATE OF LISTING\n'
          'FUTURE, Future Co Limited, EQ, 01-JAN-2027\n';
      final rows = NseListingService.parseCsv(text, now: now);
      expect(rows.single.listingDate, DateTime(2027, 1, 1));
    });

    test('an unexpected header is reported, not ignored', () {
      expect(
        () => NseListingService.parseCsv('A, B, C\n1, 2, 3\n', now: now),
        throwsA(isA<NseListingException>()),
      );
    });
  });

  group('cache', () {
    test('a cached copy is reused, a forced call is not', () async {
      // Date-relative fixture (1.5.72): hard-coded 2024 dates aged out of the
      // service's 720-day lookback — the cache test must stay valid forever.
      final listingDate = DateTime.now().subtract(const Duration(days: 120));
      await settings.putMeta(
        NseListingService.cacheKey,
        jsonEncode([NseListing(
          symbol: 'SWIGGY',
          companyName: 'Swiggy Limited',
          series: 'EQ',
          listingDate: listingDate,
        ).toJson()]),
      );
      await settings.putMeta(
        NseListingService.cachedAtKey,
        DateTime.now().toIso8601String(),
      );

      // No HTTP client is injected: if the service tried to download, this call
      // would fail — proving the cache was used.
      final service = NseListingService(settings: settings);
      final rows = await service.listings();

      expect(rows.single.symbol, 'SWIGGY');
      expect(rows.single.listingDate, listingDate);
    });

    test('a stale cache is ignored', () async {
      await settings.putMeta(
        NseListingService.cacheKey,
        jsonEncode([NseListing(
          symbol: 'SWIGGY',
          companyName: 'Swiggy Limited',
          series: 'EQ',
          listingDate: DateTime(2024, 11, 13),
        ).toJson()]),
      );
      await settings.putMeta(
        NseListingService.cachedAtKey,
        DateTime.now().subtract(const Duration(days: 3)).toIso8601String(),
      );

      final service = NseListingService(settings: settings, cacheValidity: const Duration(hours: 24));
      await expectLater(service.listings(), throwsA(isA<NseListingException>()));
    });

    test('a corrupt cache is ignored rather than crashing', () async {
      await settings.putMeta(NseListingService.cacheKey, '{not json');
      await settings.putMeta(
        NseListingService.cachedAtKey,
        DateTime.now().toIso8601String(),
      );

      final service = NseListingService(settings: settings);
      await expectLater(service.listings(), throwsA(isA<NseListingException>()));
    });
  });
}
