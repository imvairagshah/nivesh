// ---------------------------------------------------------------------------
// ipo_discovery_service_test.dart — "naye IPO khud aa jayein" path.
//
// The service finds listings newer than the newest row in the database from two
// sources: the broker's own scrip master + candles (primary) and NSE's official
// equity master (dates). Everything here is offline: real SQLite (FFI,
// in-memory) + real DAOs + the bundled 122-row starter master; the candle source
// and the NSE master are faked, so the test decides exactly what "the market"
// and "the exchange" say.
// ---------------------------------------------------------------------------

import 'dart:convert';

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/ipo_dao.dart';
import 'package:angel_trader/data/local/dao/scrip_dao.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/data/local/models/ipo.dart';
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/data/remote/dto/session.dart';
import 'package:angel_trader/services/auth_service.dart';
import 'package:angel_trader/services/candle_source.dart';
import 'package:angel_trader/services/ipo_discovery_service.dart';
import 'package:angel_trader/services/nse_listing_service.dart';
import 'package:angel_trader/services/scrip_master_service.dart';
import 'package:angel_trader/services/secure_store.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

/// Candle source double: `firstBar[token]` is what the broker has, oldest bar
/// first. An unknown token simply has no history.
class _FakeCandles implements CandleSource {
  final Map<String, List<Candle>> firstBar = {};
  final List<String> requestedTokens = [];
  Object? failure;

  /// Returned for any token not present in [firstBar].
  List<Candle> anyToken = const [];

  @override
  Future<List<Candle>> fetchDailyCandles({
    required Scrip scrip,
    required DateTime from,
    required DateTime to,
    String interval = 'ONE_DAY',
  }) async {
    requestedTokens.add(scrip.token);
    final error = failure;
    if (error != null) throw error;
    return firstBar[scrip.token] ?? anyToken;
  }
}

/// NSE master double — same shape the real parser produces.
class _FakeNse extends NseListingService {
  _FakeNse(SettingsDao settings, this.rows)
      : super(settings: settings, lookback: const Duration(days: 3650));

  final List<NseListing> rows;
  Object? failure;
  int calls = 0;

  @override
  Future<List<NseListing>> listings({bool force = false}) async {
    calls++;
    final error = failure;
    if (error != null) throw error;
    return rows;
  }

  @override
  Future<Map<String, NseListing>> byIsin({bool force = false}) async {
    final error = failure;
    if (error != null) throw error;
    final map = <String, NseListing>{};
    for (final row in rows) {
      if (row.isin.isEmpty) continue;
      map.putIfAbsent(row.isin, () => row);
    }
    return map;
  }

  @override
  Future<Set<String>> allSymbols({bool force = false}) async {
    final error = failure;
    if (error != null) throw error;
    return {for (final row in rows) row.symbol.toUpperCase()};
  }
}

Candle _bar(DateTime day, {double high = 120, double low = 90}) =>
    Candle(time: day, open: 100, high: high, low: low, close: 110, volume: 5000);

String _jwt() {
  String seg(Map<String, dynamic> p) =>
      base64Url.encode(utf8.encode(jsonEncode(p))).replaceAll('=', '');
  return '${seg({'alg': 'HS512'})}.${seg({'exp': 4070908800})}.sig';
}

Future<AuthService> _auth({required bool loggedIn}) async {
  FlutterSecureStorage.setMockInitialValues(
    loggedIn
        ? {
            'angel_session_v1': jsonEncode(
              AngelSession(
                apiKey: 'k',
                clientCode: 'A1',
                jwtToken: _jwt(),
                refreshToken: 'r',
                feedToken: 'f',
                generatedAt: DateTime(2026, 10, 1, 9),
              ).toJson(),
            ),
          }
        : const {},
  );
  final auth = AuthService(store: SecureStore());
  await auth.restore();
  return auth;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late AppDatabase db;
  late IpoDao ipoDao;
  late SettingsDao settingsDao;
  late ScripMasterService master;
  late _FakeCandles candles;

  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close();
    db = AppDatabase.instance;
    ipoDao = IpoDao(db);
    settingsDao = SettingsDao(db);
    master = ScripMasterService(scripDao: ScripDao(db), settingsDao: settingsDao);
    await master.initialise(); // bundled starter master (122 rows)
    candles = _FakeCandles();
  });

  /// The existing database: one row, listed 1 Jun 2026.
  Future<DateTime> seedExisting({String symbol = 'NYKAA'}) async {
    final listed = DateTime(2026, 6, 1);
    await ipoDao.insert(Ipo(
      symbol: symbol,
      companyName: '$symbol Ltd',
      exchange: Exchange.nse,
      listingDate: listed,
      listingHigh: 100,
      listingLow: 90,
      levelsSource: 'seed',
    ));
    return listed;
  }

  /// Simulates the state a real install is in before a new company lists:
  /// yesterday's run snapshotted every symbol the master knew — which is
  /// everything except [except].
  Future<void> writeSnapshot({Set<String> except = const {}}) async {
    final all = (await master.resolver())
        .all
        .map((scrip) => Scrip.plainSymbol(scrip.symbol).toUpperCase())
        .toSet()
      ..removeAll(except);
    await settingsDao.putMeta(
      IpoDiscoveryService.seenSymbolsKey,
      jsonEncode(all.toList()..sort()),
    );
  }

  Future<IpoDiscoveryService> service({
    required bool loggedIn,
    NseListingService? nse,
    Duration minInterval = Duration.zero,
    int maxPerRun = 25,
  }) async => IpoDiscoveryService(
        ipoDao: ipoDao,
        scripMaster: master,
        candles: candles,
        auth: await _auth(loggedIn: loggedIn),
        nse: nse,
        settings: settingsDao,
        maxPerRun: maxPerRun,
        minInterval: minInterval,
        probeDelay: Duration.zero,
      );

  group('broker-first discovery', () {
    test('a symbol whose history starts after the newest row is added with '
        'its listing date and levels', () async {
      final listed = await seedExisting();
      // IDEA listed *after* the last run snapshotted the master — exactly how a
      // real new listing shows up for the next launch.
      await writeSnapshot(except: {'IDEA'});
      candles.firstBar['14366'] = [
        _bar(listed.add(const Duration(days: 3)), high: 155.5, low: 132.25),
      ];

      final report = await (await service(loggedIn: true)).discoverNewListings();

      expect(report.didAdd, isTrue);
      final added = report.added.single;
      expect(added.symbol, 'IDEA');
      expect(added.listingDate, listed.add(const Duration(days: 3)));
      expect(added.listingHigh, 155.5);
      expect(added.listingLow, 132.25);
      expect(added.levelsSource, 'auto');
      expect(added.notes, contains('Auto-detected'));

      final rows = await ipoDao.all();
      expect(rows.length, 2);
    });

    test('history older than the newest row is not a new listing', () async {
      final listed = await seedExisting();
      await writeSnapshot(except: {'IDEA'});
      candles.firstBar['14366'] = [_bar(listed.subtract(const Duration(days: 400)))];

      final report = await (await service(loggedIn: true)).discoverNewListings();

      expect(report.added, isEmpty);
      expect(report.skippedOld, greaterThanOrEqualTo(1));
      expect((await ipoDao.all()).length, 1);
    });

    test('the first run only records the snapshot — nothing is probed', () async {
      await seedExisting();

      final first = await (await service(loggedIn: true)).discoverNewListings();
      // Nothing is probed: on a fresh install every pre-2015 company in the
      // master would otherwise look like a candidate (that is ~2,000 candle
      // calls). Discovery starts from the next run, and the NSE pass covers the
      // fresh-install case with official dates.
      expect(candles.requestedTokens, isEmpty);
      expect(first.added, isEmpty);

      final stored = await settingsDao.meta(IpoDiscoveryService.seenSymbolsKey);
      expect(stored, isNotNull);
      final symbols = (jsonDecode(stored!) as List).cast<String>();
      expect(symbols, containsAll(<String>['NYKAA', 'IDEA']));
    });

    test('a symbol added once is never added again', () async {
      await seedExisting();
      await writeSnapshot(except: {'IDEA'});
      final listed = DateTime(2026, 6, 1);
      candles.firstBar['14366'] = [_bar(listed.add(const Duration(days: 2)))];
      await (await service(loggedIn: true)).discoverNewListings();
      expect((await ipoDao.all()).length, 2);

      final again = await (await service(loggedIn: true)).discoverNewListings();
      expect(again.added, isEmpty);
      expect((await ipoDao.all()).length, 2);
    });

    test('a deleted auto-added row does not come back', () async {
      await seedExisting();
      await writeSnapshot(except: {'IDEA'});
      final listed = DateTime(2026, 6, 1);
      candles.firstBar['14366'] = [_bar(listed.add(const Duration(days: 2)))];
      final report = await (await service(loggedIn: true)).discoverNewListings();
      await ipoDao.delete(report.added.single.id!);

      final again = await (await service(loggedIn: true)).discoverNewListings();
      expect(again.added, isEmpty);
      expect((await ipoDao.all()).length, 1);
    });

    test('at most maxPerRun candidates cost a candle call per run', () async {
      await seedExisting();
      final listed = DateTime(2026, 6, 1);
      // Ten symbols the last snapshot did not know about, all reporting a fresh
      // listing — three of them may be probed in one run, the rest wait.
      final pool = (await master.resolver())
          .all
          .map((scrip) => Scrip.plainSymbol(scrip.symbol).toUpperCase())
          .where((symbol) => symbol != 'NYKAA')
          .take(10)
          .toSet();
      await writeSnapshot(except: pool);
      candles.anyToken = [_bar(listed.add(const Duration(days: 2)), high: 10, low: 5)];

      final report = await (await service(loggedIn: true, maxPerRun: 3))
          .discoverNewListings();

      expect(report.probed, 3);
      expect(report.added.length, 3);
      expect(candles.requestedTokens.length, 3);
    });

    test('a broker failure is reported, never thrown at the caller', () async {
      await seedExisting();
      await writeSnapshot(except: {'IDEA'});
      final listed = DateTime(2026, 6, 1);
      candles.firstBar['14366'] = [_bar(listed.add(const Duration(days: 2)))];
      candles.failure = Exception('AG8001: invalid token');

      final report = await (await service(loggedIn: true)).discoverNewListings();

      expect(report.error, isNotNull);
      expect(report.added, isEmpty);
    });

    test('logged out: needsLogin, zero candle calls, nothing written', () async {
      await seedExisting();

      final report = await (await service(loggedIn: false)).discoverNewListings();

      expect(report.needsLogin, isTrue);
      expect(candles.requestedTokens, isEmpty);
      expect((await ipoDao.all()).length, 1);
      expect(await settingsDao.meta(IpoDiscoveryService.lastRunKey), isNull);
    });

    test('a second run inside the interval is skipped', () async {
      await seedExisting();
      await writeSnapshot();
      final svc = await service(loggedIn: true, minInterval: const Duration(hours: 6));
      await svc.discoverNewListings();

      final second = await svc.discoverNewListings();
      expect(second.skipped, isTrue);

      final forced = await svc.discoverNewListings(force: true);
      expect(forced.skipped, isFalse);
    });
  });

  group('NSE listing master', () {
    test('a first run (no snapshot) still picks up a new IPO from NSE', () async {
      final listed = await seedExisting();
      final nse = _FakeNse(settingsDao, [
        NseListing(
          symbol: 'FRESHCO',
          companyName: 'Fresh Co Limited',
          series: 'EQ',
          listingDate: listed.add(const Duration(days: 2)),
        ),
      ]);

      final report = await (await service(loggedIn: true, nse: nse))
          .discoverNewListings();

      expect(report.added.single.symbol, 'FRESHCO');
      expect(candles.requestedTokens, isEmpty);
    });

    test('a listing the broker master has not seen is added with the official '
        'date, levels pending', () async {
      final listed = await seedExisting();
      final nse = _FakeNse(settingsDao, [
        NseListing(
          symbol: 'NEWCO',
          companyName: 'Newco Industries Limited',
          series: 'EQ',
          listingDate: listed.add(const Duration(days: 5)),
        ),
      ]);

      final report = await (await service(loggedIn: true, nse: nse))
          .discoverNewListings(force: true);

      final added = report.added.single;
      expect(added.symbol, 'NEWCO');
      expect(added.companyName, 'Newco Industries Limited');
      expect(added.listingDate, listed.add(const Duration(days: 5)));
      // Not resolvable against the starter master → the levels service will pick
      // it up later, so it must stay *pending*, not be marked missing.
      expect(added.levelsSource, '');
      expect(added.notes, contains('NSE'));
    });

    test('SME series and older listings are ignored', () async {
      final listed = await seedExisting();
      final nse = _FakeNse(settingsDao, [
        NseListing(
          symbol: 'SMECO',
          companyName: 'Sme Co Limited',
          series: 'SM',
          listingDate: listed.add(const Duration(days: 5)),
        ),
        NseListing(
          symbol: 'OLDCO',
          companyName: 'Old Co Limited',
          series: 'EQ',
          listingDate: listed.subtract(const Duration(days: 30)),
        ),
      ]);

      final report = await (await service(loggedIn: true, nse: nse))
          .discoverNewListings(force: true);

      expect(report.added, isEmpty);
      expect((await ipoDao.all()).length, 1);
    });

    test('an NSE failure leaves broker discovery working', () async {
      final listed = await seedExisting();
      await writeSnapshot(except: {'IDEA'});
      candles.firstBar['14366'] = [_bar(listed.add(const Duration(days: 2)))];

      final nse = _FakeNse(settingsDao, const [])
        ..failure = NseListingException('NSE unreachable');
      final report = await (await service(loggedIn: true, nse: nse))
          .discoverNewListings();

      expect(report.added.single.symbol, 'IDEA');
      expect(report.error, contains('NSE'));
    });

    test('a symbol the broker already knows gets its levels from the first bar',
        () async {
      final listed = await seedExisting();
      candles.firstBar['6545'] = [
        _bar(listed.add(const Duration(days: 4)), high: 2050, low: 1900),
      ];
      final nse = _FakeNse(settingsDao, [
        NseListing(
          symbol: 'NYKAA',
          companyName: 'FSN E-Commerce Ventures Limited',
          series: 'EQ',
          listingDate: listed.add(const Duration(days: 4)),
        ),
      ]);

      final report = await (await service(loggedIn: true, nse: nse))
          .discoverNewListings(force: true);

      // NYKAA is already in the database: it is counted as known, not re-added.
      expect(report.added, isEmpty);
      expect(report.alreadyKnown, 1);
    });
  });

  group('identity (ISIN) — renames can never strand a row again', () {
    /// The database as an older install has it: identity stored, ticker stale.
    Future<Ipo> seedRow({
      required String symbol,
      required String isin,
      bool custom = false,
    }) async {
      final row = Ipo(
        symbol: symbol,
        companyName: '$symbol Limited',
        exchange: Exchange.nse,
        listingDate: DateTime(2016, 7, 21),
        listingHigh: 710,
        listingLow: 666,
        isin: isin,
        isCustom: custom,
        levelsSource: 'seed',
      );
      await ipoDao.insert(row);
      return row;
    }

    test('a ticker the exchange renamed is corrected from its ISIN', () async {
      await seedRow(symbol: 'LTIM', isin: 'INE214T01019');
      final nse = _FakeNse(settingsDao, [
        // Today's master: the same security, a new label.
        NseListing(
          symbol: 'LTM',
          companyName: 'LTM Limited',
          series: 'EQ',
          listingDate: DateTime(2016, 7, 21),
          isin: 'INE214T01019',
        ),
      ]);

      final report =
          await (await service(loggedIn: true, nse: nse)).repairRenamedSymbols();

      expect(report.repairs.single.from, 'LTIM');
      expect(report.repairs.single.to, 'LTM');
      final row = (await ipoDao.all()).single;
      expect(row.symbol, 'LTM');
      expect(row.companyName, 'LTM Limited');
      expect(row.isin, 'INE214T01019', reason: 'identity is unchanged by design');
      expect(row.listingHigh, 710, reason: 'levels survive the rename');
      expect(row.notes, contains('INE214T01019'));
    });

    test('nothing is rewritten while the old ticker still trades', () async {
      // Demerger/dual-listing window: two symbols, one ISIN. Rewriting here
      // would silently merge two different traded lines.
      await seedRow(symbol: 'TMCV', isin: 'INE1TAE01018');
      final nse = _FakeNse(settingsDao, [
        NseListing(
          symbol: 'TMCV',
          companyName: 'Tata Motors Commercial Vehicles',
          series: 'EQ',
          listingDate: DateTime(2025, 11, 12),
          isin: 'INE1TAE01018',
        ),
        NseListing(
          symbol: 'TMPV',
          companyName: 'Tata Motors Passenger Vehicles',
          series: 'EQ',
          listingDate: DateTime(2025, 10, 30),
          isin: 'INE1TAE01018',
        ),
      ]);

      final report =
          await (await service(loggedIn: true, nse: nse)).repairRenamedSymbols();

      expect(report.repairs, isEmpty);
      expect((await ipoDao.all()).single.symbol, 'TMCV');
    });

    test('a row the user maintains by hand is never touched', () async {
      await seedRow(symbol: 'LTIM', isin: 'INE214T01019', custom: true);
      final nse = _FakeNse(settingsDao, [
        NseListing(
          symbol: 'LTM',
          companyName: 'LTM Limited',
          series: 'EQ',
          listingDate: DateTime(2016, 7, 21),
          isin: 'INE214T01019',
        ),
      ]);

      final report =
          await (await service(loggedIn: true, nse: nse)).repairRenamedSymbols();

      expect(report.repairs, isEmpty);
      expect((await ipoDao.all()).single.symbol, 'LTIM');
    });

    test('rows without an ISIN get one from the master — so a *future* rename '
        'can be repaired too', () async {
      await ipoDao.insert(Ipo(
        symbol: 'SWIGGY',
        companyName: 'Swiggy Limited',
        exchange: Exchange.nse,
        listingDate: DateTime(2024, 11, 13),
        listingHigh: 465.80,
        listingLow: 391,
      ));
      final nse = _FakeNse(settingsDao, [
        NseListing(
          symbol: 'SWIGGY',
          companyName: 'Swiggy Limited',
          series: 'EQ',
          listingDate: DateTime(2024, 11, 13),
          isin: 'INE00H001014',
        ),
      ]);

      final report =
          await (await service(loggedIn: true, nse: nse)).repairRenamedSymbols();

      expect(report.isinsFilled, 1);
      expect((await ipoDao.all()).single.isin, 'INE00H001014');
    });

    test('a delisted company (ISIN not in the master) is left as it is', () async {
      await seedRow(symbol: 'MANPASAND', isin: 'INE576O01019');
      final nse = _FakeNse(settingsDao, [
        NseListing(
          symbol: 'SOMECO',
          companyName: 'Some Co',
          series: 'EQ',
          listingDate: DateTime(2024, 1, 1),
          isin: 'INE000000001',
        ),
      ]);

      final report =
          await (await service(loggedIn: true, nse: nse)).repairRenamedSymbols();

      expect(report.repairs, isEmpty);
      expect((await ipoDao.all()).single.symbol, 'MANPASAND');
    });

    test('an exchange outage is reported, not thrown', () async {
      await seedRow(symbol: 'LTIM', isin: 'INE214T01019');
      final nse = _FakeNse(settingsDao, const [])
        ..failure = NseListingException('NSE unreachable');

      final report =
          await (await service(loggedIn: true, nse: nse)).repairRenamedSymbols();

      expect(report.error, contains('NSE'));
      expect(report.repairs, isEmpty);
      expect((await ipoDao.all()).single.symbol, 'LTIM');
    });

    test('a discovery run reports the repair alongside any new listings',
        () async {
      await seedRow(symbol: 'AMIORG', isin: 'INE00FF01025');
      final nse = _FakeNse(settingsDao, [
        NseListing(
          symbol: 'ACUTAAS',
          companyName: 'Acutaas Chemicals Limited',
          series: 'EQ',
          listingDate: DateTime(2021, 9, 14),
          isin: 'INE00FF01025',
        ),
      ]);

      final report = await (await service(loggedIn: true, nse: nse))
          .discoverNewListings(force: true);

      expect(report.identity.repairs.single.to, 'ACUTAAS');
      expect(report.summary, contains('AMIORG → ACUTAAS'));
      expect(
        (await ipoDao.all()).single.companyName,
        'Acutaas Chemicals Limited',
      );
    });
  });
}
