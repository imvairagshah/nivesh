// ---------------------------------------------------------------------------
// fno_universe_test.dart — the shipped F&O list and its parser.
//
// The list is generated from Angel One's scrip master (every `FUTSTK` row is a
// *stock* future, i.e. a company whose shares are in the F&O segment). These
// tests guard both halves of that claim:
//
//   • the parser: header handling, sorting, company names, blank lines,
//   • the shipped CSV itself: it must be big enough to represent the real F&O
//     segment (~200+ names), free of duplicates and test contracts, and it must
//     contain today's tickers (LTM, not LTIM) — which is exactly why rows are
//     resolved through the ISIN-aware token resolver at scan time.
// ---------------------------------------------------------------------------

import 'dart:io';

import 'package:angel_trader/services/fno_universe.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('parser', () {
    test('reads symbols, company names and the review note', () {
      const csv = 'Symbol,Company Name,Notes\n'
          'SBIN,State Bank of India,NSE F&O (stock futures) · from Angel scrip master\n'
          'RELIANCE,Reliance Industries,NSE F&O (stock futures) · from Angel scrip master\n';

      final universe = FnoUniverse.parse(csv);

      expect(universe.symbols, ['RELIANCE', 'SBIN'], reason: 'sorted');
      expect(universe.companyNames['SBIN'], 'State Bank of India');
      expect(universe.asOf, 'NSE F&O (stock futures)');
      expect(universe.length, 2);
    });

    test('tolerates blank lines, missing names and lowercase input', () {
      const csv = 'symbol,company name,notes\n\n'
          'reliance,,x\n'
          '\n'
          'sbin,State Bank,\n';

      final universe = FnoUniverse.parse(csv);

      expect(universe.symbols, ['RELIANCE', 'SBIN']);
      expect(universe.companyNames.containsKey('RELIANCE'), isFalse);
      expect(universe.companyNames['SBIN'], 'State Bank');
    });

    test('an empty document yields the empty universe, not an exception', () {
      expect(FnoUniverse.parse('').isEmpty, isTrue);
      expect(FnoUniverse.empty.length, 0);
    });
  });

  group('shipped asset', () {
    late FnoUniverse universe;

    setUpAll(() {
      final file = File(FnoUniverse.assetPath);
      expect(file.existsSync(), isTrue,
          reason: '${FnoUniverse.assetPath} must ship with the app');
      universe = FnoUniverse.parse(file.readAsStringSync());
    });

    test('covers the whole F&O segment (200+ names)', () {
      expect(universe.length, greaterThanOrEqualTo(200));
      expect(universe.length, lessThan(400), reason: 'not the whole market');
    });

    test('every row has a sane ticker', () {
      final bad = <String>[];
      for (final symbol in universe.symbols) {
        if (symbol.isEmpty || !RegExp(r'^[A-Z0-9&\-]+$').hasMatch(symbol)) {
          bad.add(symbol);
        }
      }
      expect(bad, isEmpty, reason: 'malformed tickers: $bad');
    });

    test('company names are shipped where they are known — and never invented',
        () {
      // The broker's master carries only tickers, so the names come from the
      // IPO master (55 of the 213 today). The rest stay blank on purpose: the
      // table then shows "NSE · N bars" instead of a name nobody verified.
      expect(universe.companyNames.length, greaterThanOrEqualTo(50));
      expect(universe.companyNames.length, lessThan(universe.length));
      for (final entry in universe.companyNames.entries) {
        expect(entry.value.toUpperCase(), isNot(entry.key),
            reason: '${entry.key} repeats its ticker instead of a name');
        expect(entry.value.length, greaterThan(3));
      }
    });

    test('no duplicates (the DB has a unique (symbol, exchange) index)', () {
      expect(universe.symbols.toSet(), hasLength(universe.length));
    });

    test('exchange test contracts are filtered out', () {
      expect(
        universe.symbols.where((s) => s.contains('NSETEST')),
        isEmpty,
        reason: 'the master carries NSE test futures — they are not companies',
      );
    });

    test('carries index-free stock futures only', () {
      // Index futures (FUTIDX) are not companies and must never appear.
      for (final index in const ['NIFTY', 'BANKNIFTY', 'FINNIFTY', 'MIDCPNIFTY']) {
        expect(universe.symbols, isNot(contains(index)));
      }
    });

    test("uses today's tickers — renames are already reflected", () {
      expect(universe.symbols, contains('LTM'),
          reason: 'LTIMindtree became LTM in Feb 2026');
      expect(universe.symbols, isNot(contains('LTIM')));
      expect(universe.symbols, contains('RELIANCE'));
      expect(universe.symbols, contains('SBIN'));
      // 50-odd of these overlap the Nifty 50; a healthy F&O list always does.
      expect(universe.symbols.where((s) => s.length <= 3).length,
          greaterThan(10));
    });

    test('the names that are shipped match the IPO master', () {
      // PAYTM is in both lists; the F&O row must carry the same name the rest
      // of the app shows for it.
      expect(universe.companyNames['PAYTM']!.toLowerCase(), contains('one 97'));
      expect(universe.companyNames['NYKAA']!.toLowerCase(), contains('fsn'));
    });
  });
}
