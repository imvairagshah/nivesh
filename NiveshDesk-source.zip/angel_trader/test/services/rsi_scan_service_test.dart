// ---------------------------------------------------------------------------
// rsi_scan_service_test.dart — the RSI scan loop, with a fake candle source.
//
// The real SQLite schema, the real Wilder maths and the real caching logic run
// here (sqflite FFI on the test VM); only the network is faked. `FakeCandleSource`
// counts its calls, so these tests prove the three things the design promises:
//
//   • one pass fills BOTH tables (overbought and oversold),
//   • a second scan is served from the candle cache — no repeat downloads under
//     Angel One's 3 requests/second limit,
//   • nothing is ever dropped silently: short histories and failures land in
//     `skips` with a reason.
// ---------------------------------------------------------------------------

import 'dart:math' as math;

import 'package:angel_trader/core/utils/markets.dart';
import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/candle_dao.dart';
import 'package:angel_trader/data/local/dao/scan_cache_dao.dart';
import 'package:angel_trader/data/remote/api_client.dart';
import 'package:angel_trader/data/remote/dto/candle.dart';
import 'package:angel_trader/data/remote/dto/scrip.dart';
import 'package:angel_trader/features/rsi_scanner/rsi_engine.dart';
import 'package:angel_trader/services/candle_source.dart';
import 'package:angel_trader/services/rsi_scan_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

// ---------------------------------------------------------------------------
// Fakes + fixtures
// ---------------------------------------------------------------------------

class FakeCandleSource implements CandleSource {
  FakeCandleSource(this.barsByToken);

  final Map<String, List<Candle>> barsByToken;
  final List<String> requestedTokens = [];

  /// Tokens that should fail, to exercise the skip path.
  final Set<String> failTokens = {};

  int get callCount => requestedTokens.length;

  @override
  Future<List<Candle>> fetchDailyCandles({
    required Scrip scrip,
    required DateTime from,
    required DateTime to,
    String interval = 'ONE_DAY',
  }) async {
    requestedTokens.add(scrip.token);
    if (failTokens.contains(scrip.token)) {
      throw const ApiException(message: 'Rate limit reached.');
    }
    return barsByToken[scrip.token] ?? const [];
  }
}

List<Candle> series(List<double> closes, {DateTime? start}) {
  final bars = <Candle>[];
  var day = start ?? DateTime(2025, 1, 1);
  for (final close in closes) {
    bars.add(Candle(
      time: day,
      open: close,
      high: close * 1.01,
      low: close * 0.99,
      close: close,
      volume: 1000,
    ));
    day = day.add(const Duration(days: 1));
  }
  return bars;
}

/// The session every series below ends on. One shared end date matters: the
/// cache is considered usable only when it reaches the as-of date, so series of
/// different lengths must still finish on the same bar for the "second scan is
/// free" behaviour to be testable.
final DateTime kEnd = DateTime(2025, 3, 21);

/// Same deterministic wave the engine tests use (values verified there):
///   wave(82)                  → RSI 75.58 (overbought, not fresh)
///   wave(80)                  → RSI 68.89 (fresh cross above 67)
///   wave(80, base:200, -1)    → RSI 31.11 (fresh cross below 33)
///   wave(64, base:200, -1)    → RSI 25.74 (oversold, not fresh)
///   wave(64)                  → RSI 74.26 (overbought)
List<Candle> wave(int count, {double base = 100, double sign = 1}) => series(
      [
        for (var i = 0; i < count; i++)
          base + sign * (6 * math.sin(i / 4.2)) + sign * 0.25 * i,
      ],
      start: kEnd.subtract(Duration(days: count - 1)),
    );

Scrip scrip(String token, String symbol) => Scrip(
      token: token,
      symbol: '$symbol-EQ',
      name: '$symbol Limited',
      exchange: Exchange.nse,
    );

const thresholds = RsiThresholds();

void main() {
  late CandleDao candles;
  late ScanCacheDao cache;
  late FakeCandleSource source;
  late RsiScanService service;

  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() async {
    AppDatabase.overridePath = inMemoryDatabasePath;
    await AppDatabase.instance.close();
    final db = AppDatabase.instance;
    candles = CandleDao(db);
    cache = ScanCacheDao(db);
    source = FakeCandleSource({});
    service = RsiScanService(source: source, candles: candles, cache: cache);
  });

  tearDownAll(() async {
    await AppDatabase.instance.close();
    AppDatabase.overridePath = inMemoryDatabasePath;
  });

  /// The five instruments that can actually be scanned (all have ≥ 56 bars).
  List<Scrip> healthyUniverse() => [
        scrip('1', 'STRONG'),
        scrip('2', 'CROSSED'),
        scrip('3', 'WEAK'),
        scrip('4', 'FALLING'),
        scrip('5', 'NEUTRAL'),
      ];

  /// One universe with every case the scanner must handle.
  List<Scrip> mixedUniverse() => [
        scrip('1', 'STRONG'), // overbought, established
        scrip('2', 'CROSSED'), // fresh overbought cross
        scrip('3', 'WEAK'), // fresh oversold cross
        scrip('4', 'FALLING'), // oversold, established
        scrip('5', 'NEUTRAL'), // in the middle — no table
        scrip('6', 'NEWCO'), // too little history
      ];

  void primeSource() {
    source = FakeCandleSource({
      '1': wave(82),
      '2': wave(80),
      '3': wave(80, base: 200, sign: -1),
      '4': wave(64, base: 200, sign: -1),
      '5': wave(72), // RSI ≈ 40 → neutral, must appear in neither list
      '6': wave(40), // 40 bars < 56 → skip
    });
    service = RsiScanService(source: source, candles: candles, cache: cache);
  }

  DateTime asOf() => kEnd;

  test('one pass fills both tables with the right rows', () async {
    primeSource();

    final result = await service.scan(
      universe: mixedUniverse(),
      asOf: asOf(),
      thresholds: thresholds,
    );

    // 82-bar series ends later than the 80-bar ones; the scan uses the as-of
    // date, so every series is cut there — all six are still scannable.
    final overbought = [for (final r in result.overbought) r.symbol];
    final oversold = [for (final r in result.oversold) r.symbol];

    expect(overbought, containsAll(['STRONG', 'CROSSED']));
    expect(oversold, containsAll(['WEAK', 'FALLING']));
    expect(overbought, isNot(contains('NEUTRAL')));
    expect(oversold, isNot(contains('NEUTRAL')));

    // Strongest overbought first, deepest oversold first.
    expect(result.overbought.first.rsi,
        greaterThanOrEqualTo(result.overbought.last.rsi));
    expect(result.oversold.first.rsi,
        lessThanOrEqualTo(result.oversold.last.rsi));

    // The short history is reported, never hidden.
    expect(result.skips, hasLength(1));
    expect(result.skips.single.symbol, 'NEWCO');
    expect(result.skips.single.reason, contains('56'));

    expect(result.scanned, 6);
    expect(result.fetched, 6);
    expect(result.fromCache, 0);
    expect(result.thresholds.period, 14);
  });

  test('the newest bar is what decides "aaj cross hua"', () async {
    primeSource();
    final result = await service.scan(
      universe: mixedUniverse(),
      asOf: asOf(),
      thresholds: thresholds,
    );

    final crossed = result.overbought.firstWhere((r) => r.symbol == 'CROSSED');
    final strong = result.overbought.firstWhere((r) => r.symbol == 'STRONG');

    expect(crossed.isFreshIn(thresholds), isTrue);
    expect(strong.isFreshIn(thresholds), isFalse);

    final weak = result.oversold.firstWhere((r) => r.symbol == 'WEAK');
    final falling = result.oversold.firstWhere((r) => r.symbol == 'FALLING');
    expect(weak.isFreshIn(thresholds), isTrue);
    expect(falling.isFreshIn(thresholds), isFalse);
    expect(result.freshCount, 2);
  });

  test('a second scan is served from the candle cache (no extra downloads)',
      () async {
    primeSource();

    await service.scan(
      universe: healthyUniverse(),
      asOf: asOf(),
      thresholds: thresholds,
    );
    final firstRunCalls = source.callCount;
    expect(firstRunCalls, 5);

    final second = await service.scan(
      universe: healthyUniverse(),
      asOf: asOf(),
      thresholds: thresholds,
    );

    expect(source.callCount, firstRunCalls,
        reason: 'cached bars must not be re-downloaded — 3 requests/second is '
            'the hard limit this design protects');
    expect(second.fromCache, 5);
    expect(second.fetched, 0);
    expect(second.overbought, isNotEmpty);
  });

  test('a series that can never satisfy the minimum is retried, not trusted',
      () async {
    primeSource();

    // NEWCO has 40 bars, so its cached history is genuinely unusable (the RSI
    // would be a guess). The loader therefore re-fetches it on every scan —
    // correct behaviour, and cheap because it is one request, not a universe.
    await service.scan(
      universe: mixedUniverse(),
      asOf: asOf(),
      thresholds: thresholds,
    );
    final after = source.callCount;
    final second = await service.scan(
      universe: mixedUniverse(),
      asOf: asOf(),
      thresholds: thresholds,
    );

    expect(source.callCount, after + 1, reason: 'only the 40-bar symbol');
    expect(second.fromCache, 5);
    expect(second.fetched, 1);
  });

  test('a broker failure becomes a skip, not a lost scan', () async {
    primeSource();
    source.failTokens.add('2');

    final result = await service.scan(
      universe: mixedUniverse(),
      asOf: asOf(),
      thresholds: thresholds,
    );

    expect(
      result.skips.map((s) => s.symbol),
      containsAll(['CROSSED', 'NEWCO']),
    );
    expect(
      result.skips.firstWhere((s) => s.symbol == 'CROSSED').reason,
      contains('Rate limit'),
    );
    expect(result.overbought.map((r) => r.symbol), contains('STRONG'));
  });

  test('an instrument with no candles at all is skipped with a reason',
      () async {
    source = FakeCandleSource({'1': wave(82), '2': const []});
    service = RsiScanService(source: source, candles: candles, cache: cache);

    final result = await service.scan(
      universe: [scrip('1', 'STRONG'), scrip('2', 'DEAD')],
      asOf: asOf(),
      thresholds: thresholds,
    );

    expect(result.skips.single.symbol, 'DEAD');
    expect(result.skips.single.reason, contains('No daily candles'));
  });

  test('cancelling keeps what was already scanned', () async {
    primeSource();
    var seen = 0;

    final result = await service.scan(
      universe: mixedUniverse(),
      asOf: asOf(),
      thresholds: thresholds,
      isCancelled: () => seen > 0, // stop after the first instrument
      onProgress: (_) => seen++,
    );

    expect(result.cancelled, isTrue);
    expect(result.scanned, 1);
    expect(result.universeSize, 6);
    expect(result.summary, contains('cancelled'));
  });

  test('tighter thresholds shrink the tables without a new scan', () async {
    primeSource();
    final wide = await service.scan(
      universe: mixedUniverse(),
      asOf: asOf(),
      thresholds: thresholds,
    );
    final calls = source.callCount;
    expect(wide.overboughtCount, 2);

    // Re-labelling with 70 / 24 is exactly what the provider does when the user
    // edits the levels — no scan, and the rows themselves are untouched.
    final tight = RsiScanResult(
      asOf: wide.asOf,
      runAt: wide.runAt,
      universeKey: wide.universeKey,
      thresholds: const RsiThresholds(period: 14, upper: 70, lower: 24),
      overbought: wide.overbought,
      oversold: wide.oversold,
      skips: wide.skips,
      fromCacheOnly: true,
    );

    // 75.58 clears 70 (STRONG stays); 68.89 does not (CROSSED is hidden);
    // 25.74 is not below 24 any more (FALLING is hidden).
    expect(tight.overboughtCount, 1);
    expect(tight.rowsFor(RsiZone.overbought).single.symbol, 'STRONG');
    expect(tight.oversoldCount, 0);
    expect(source.callCount, calls, reason: 'no API call for a settings change');

    // Loosening brings the hidden row straight back — reversible by design.
    final loose = RsiScanResult(
      asOf: wide.asOf,
      runAt: wide.runAt,
      universeKey: wide.universeKey,
      thresholds: thresholds,
      overbought: wide.overbought,
      oversold: wide.oversold,
      skips: wide.skips,
      fromCacheOnly: true,
    );
    expect(loose.overboughtCount, 2);
    expect(loose.oversoldCount, 2);
  });

  test('progress reports every instrument with a running hit count', () async {
    primeSource();
    final seen = <RsiScanProgress>[];

    await service.scan(
      universe: mixedUniverse(),
      asOf: asOf(),
      thresholds: thresholds,
      onProgress: seen.add,
    );

    expect(seen, hasLength(6));
    expect(seen.last.done, 6);
    expect(seen.last.total, 6);
    expect(seen.last.overbought + seen.last.oversold, seen.last.hits);
    expect(seen.last.fraction, 1);
    expect(seen.first.current, 'STRONG');
  });

  group('persistence', () {
    test('the result is cached under the `rsi` kind and rehydrates', () async {
      primeSource();
      await service.scan(
        universe: mixedUniverse(),
        asOf: asOf(),
        thresholds: const RsiThresholds(period: 14, upper: 67, lower: 33),
        universeKey: 'fno',
      );

      final run = await cache.latestRun(ScanKind.rsi);
      expect(run, isNotNull, reason: 'scan_runs must hold the RSI output');
      expect(run!.asOf, '2025-03-21', reason: 'keyed by the as-of session');
      expect(run.kind, ScanKind.rsi);

      // A brand-new service instance (fresh app launch) reads it back.
      final fresh = RsiScanService(source: source, candles: candles, cache: cache);
      final cached = await fresh.loadCached();

      expect(cached, isNotNull);
      expect(cached!.fromCacheOnly, isTrue);
      expect(cached.thresholds.upper, 67);
      expect(cached.overbought.map((r) => r.symbol),
          containsAll(['STRONG', 'CROSSED']));
      expect(cached.oversold.map((r) => r.symbol),
          containsAll(['WEAK', 'FALLING']));
      expect(cached.summary, contains('Cached'));
      // Sorting survives the round-trip.
      expect(cached.overbought.first.rsi,
          greaterThanOrEqualTo(cached.overbought.last.rsi));
    });

    test('custom thresholds travel with the cached rows', () async {
      primeSource();
      await service.scan(
        universe: mixedUniverse(),
        asOf: asOf(),
        thresholds: const RsiThresholds(period: 9, upper: 80, lower: 20),
      );

      final cached = await service.loadCached();
      expect(cached!.thresholds.period, 9);
      expect(cached.thresholds.upper, 80);
      expect(cached.thresholds.lower, 20);
    });

    test('a cancelled run with no rows writes nothing', () async {
      primeSource();
      await service.scan(
        universe: mixedUniverse(),
        asOf: asOf(),
        thresholds: thresholds,
        isCancelled: () => true,
      );

      expect(await cache.latestRun(ScanKind.rsi), isNull);
    });

    test('clearCache leaves the candles alone', () async {
      primeSource();
      await service.scan(
        universe: healthyUniverse(),
        asOf: asOf(),
        thresholds: thresholds,
      );
      final before = source.callCount;

      await service.clearCache();

      expect(await service.loadCached(), isNull);
      final after = await service.scan(
        universe: healthyUniverse(),
        asOf: asOf(),
        thresholds: thresholds,
      );
      expect(source.callCount, before, reason: 'bars stay cached');
      expect(after.overbought, isNotEmpty);
    });
  });
}
