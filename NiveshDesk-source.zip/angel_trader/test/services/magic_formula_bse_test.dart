import 'dart:convert';
import 'dart:io';

import 'package:archive/archive.dart';
import 'package:angel_trader/data/local/app_database.dart';
import 'package:angel_trader/data/local/dao/scrip_dao.dart';
import 'package:angel_trader/data/local/dao/settings_dao.dart';
import 'package:angel_trader/features/magic_formula/magic_formula_engine.dart';
import 'package:angel_trader/features/magic_formula/magic_formula_models.dart';
import 'package:angel_trader/services/magic_formula_data_source.dart';
import 'package:angel_trader/services/nse_listing_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

/// BSE pipeline tests (1.5.39): official BSE CM-UDiFF price + BSE
/// `Integratedfinancedata` filings — offline fixtures only, no live requests.
void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('BSE Quarter_Name parsing', () {
    test('plain quarters carry basis and quarter-end date', () {
      final consolidated = NseMagicFormulaDataSource.parseBseQuarterName(
        'Consolidated-Sep-Qtr-2026',
      );
      expect(consolidated, isNotNull);
      expect(consolidated!.basis, 'Consolidated');
      expect(consolidated.periodEnd, DateTime(2026, 9, 30));

      final standalone = NseMagicFormulaDataSource.parseBseQuarterName(
        'Standalone-Jun-Qtr-2026',
      );
      expect(standalone!.basis, 'Standalone');
      expect(standalone.periodEnd, DateTime(2026, 6, 30));
    });

    test('Hly/Yearly/NineMths variants map to their period end', () {
      expect(
        NseMagicFormulaDataSource.parseBseQuarterName(
          'Consolidated-Sep-Hly-2026',
        )!.periodEnd,
        DateTime(2026, 9, 30),
      );
      expect(
        NseMagicFormulaDataSource.parseBseQuarterName(
          'Standalone-Mar-Yearly-2026',
        )!.periodEnd,
        DateTime(2026, 3, 31),
      );
      expect(
        NseMagicFormulaDataSource.parseBseQuarterName(
          'Standalone-Dec-NineMths-2025',
        )!.periodEnd,
        DateTime(2025, 12, 31),
      );
    });

    test('unknown shapes are refused, never guessed', () {
      expect(NseMagicFormulaDataSource.parseBseQuarterName(''), isNull);
      expect(
        NseMagicFormulaDataSource.parseBseQuarterName('Quarter 3 2026'),
        isNull,
      );
      expect(
        NseMagicFormulaDataSource.parseBseQuarterName('Consolidated-Feb-Qtr-2026'),
        isNull,
      );
    });
  });

  group('BSE CM-UDiFF bhavcopy parsing', () {
    test('parses BSE group series and keeps the scrip code column', () {
      final quotes = NseMagicFormulaDataSource.parseBhavcopyCsv(
        _fixture('bse_udiff_20261023.csv'),
      );
      // The zero-close row drops out; the traded rows stay.
      expect(quotes.length, 6);
      final biret = quotes.firstWhere((q) => q.symbol == 'BIRET');
      expect(biret.series, 'IF');
      expect(biret.securityId, '543261');

      final testbse = quotes.firstWhere((q) => q.symbol == 'TESTBSE');
      expect(testbse.series, 'A');
      expect(testbse.closePrice, 200);
      expect(testbse.securityId, '543320');
      expect(testbse.isin, 'INE999Z01000');
      expect(testbse.tradeDate, DateTime(2026, 10, 23));

      final sbi = quotes.firstWhere((q) => q.symbol == 'SBILIFE');
      expect(sbi.securityId, '540719');
      expect(sbi.closePrice, 1645);
    });

    test('REIT/InvIT and trade-to-trade series parse; debt series do not', () {
      // The real NSE CM-UDiFF file lists REITs under series RR (InvITs IV)
      // and still-traded equity under BZ/SM/ST. The parser used to drop them
      // all — every such NIFTY 500 member then failed on price/scrip code.
      const csv =
          'TradDt,BizDt,Sgmt,Src,FinInstrmTp,FinInstrmId,ISIN,TckrSymb,SctySrs,'
          'XpryDt,FininstrmActlXpryDt,StrkPric,OptnTp,FinInstrmNm,OpnPric,HghPric,'
          'LwPric,ClsPric,LastPric,PrvsClsgPric,UndrlygPric,SttlmPric,OpnIntrst,'
          'ChngInOpnIntrst,TtlTradgVol,TtlTrfVal,TtlNbOfTxsExctd,SsnId,'
          'NewBrdLotQty,Rmks,Rsvd1,Rsvd2,Rsvd3,Rsvd4\n'
          '2026-10-23,2026-10-23,CM,NSE,STK,2203,INE0FDU25010,BIRET,RR,,,,,'
          'BROOKFIELD REIT,300.00,305.00,294.00,304.46,304.46,297.00,,304.46,,,'
          '41000,12400000.00,611,F1,1,,,,,\n'
          '2026-10-23,2026-10-23,CM,NSE,STK,1234,INE000I01000,INVITX,IV,,,,,'
          'SOME INVIT,100.00,101.00,99.00,100.50,100.50,99.00,,100.50,,,'
          '10,1000.00,2,F1,1,,,,,\n'
          '2026-10-23,2026-10-23,CM,NSE,STK,5678,INE000S01000,SMALLCAP,SM,,,,,'
          'SMALL CAP LTD,20.00,21.00,19.00,20.50,20.50,19.50,,20.50,,,'
          '100,2000.00,5,F1,1,,,,,\n'
          '2026-10-23,2026-10-23,CM,NSE,STK,1111,INE000N01000,SOMEBOND,N1,,,,,'
          'SOME BOND,10.00,10.00,10.00,10.00,10.00,10.00,,10.00,,,'
          '1,10.00,1,F1,1,,,,,\n';
      final rows = NseMagicFormulaDataSource.parseBhavcopyCsv(csv);
      expect(
        rows.map((q) => q.symbol),
        containsAll(['BIRET', 'INVITX', 'SMALLCAP']),
      );
      expect(rows.map((q) => q.symbol), isNot(contains('SOMEBOND')));
    });
  });

  group('BSE fetchFundamentals pipeline', () {
    setUpAll(() {
      sqfliteFfiInit();
      databaseFactory = databaseFactoryFfi;
    });

    late AppDatabase db;
    late SettingsDao settings;

    setUp(() async {
      AppDatabase.overridePath = inMemoryDatabasePath;
      await AppDatabase.instance.close();
      db = AppDatabase.instance;
      settings = SettingsDao(db);
    });

    tearDown(() async {
      await AppDatabase.instance.close();
      AppDatabase.overridePath = null;
    });

    test(
      'BSE-only scrip: EOD close from BSE bhavcopy + filings from the BSE feed',
      () async {
        final source = _bseSource(
          db,
          settings,
          archiveTransform: (name, xml) => _rebuildAs(xml, _factsFor(name)),
          faceValueLookup: (_) async => null,
        );

        final row = await source.fetchFundamentals(
          const MagicFormulaCandidate(
            symbol: '543320',
            companyName: 'Test BSE Industries Limited',
            exchange: 'BSE',
          ),
        );

        expect(row.missingReason, isEmpty);
        expect(row.source, 'BSE CM-UDiFF EOD Close + Integrated Filing XBRL');
        expect(row.marketPriceAsOf, DateTime(2026, 10, 23));
        // 1e8 shares × ₹200 = ₹2,000 Cr.
        expect(row.marketCapCr, 2000);
        // Quarter PBTs 1+2+3+4 = 10 Cr.
        expect(row.ebitTtmCr, 10);
        expect(row.totalDebtCr, 400);
        expect(row.cashCr, 50);
        expect(row.totalAssetsCr, 1000);
        expect(row.currentLiabilitiesCr, 200);
        expect(row.statementBasis, 'Consolidated');
      },
    );

    test('listing-master face value forms market cap when filing has none', () async {
      final source = _bseSource(
        db,
        settings,
        archiveTransform: (name, xml) =>
            _rebuildAs(xml, _factsFor(name, includeFaceValue: false)),
        faceValueLookup: (isin) async => isin == 'INE999Z01000' ? 5 : null,
      );
      final row = await source.fetchFundamentals(
        const MagicFormulaCandidate(
          symbol: '543320',
          companyName: 'Test BSE Industries Limited',
          exchange: 'BSE',
          isin: 'INE999Z01000',
        ),
      );
      // 1e9 paid-up ÷ ₹5 face value = 2e8 shares × ₹200 = ₹4,000 Cr.
      expect(row.marketCapCr, 4000);
    });

    test(
      'capital-total face-value tag falls through to the master face value',
      () async {
        // The Bharti Airtel shape: the filing's FaceValueOfEquityShareCapital
        // carries the period's issued face capital (a total), not a per-share
        // ₹ value. The per-share value then comes from the official listing
        // master — the invalid filing tag must NOT block that fallback.
        final source = _bseSource(
          db,
          settings,
          archiveTransform: (name, xml) => _rebuildAs(xml, {
            ..._factsFor(name),
            'PaidUpEquityCapital@OneI': '31202000000',
            'FaceValueOfEquityShareCapital@OneI': '1586949',
          }),
          faceValueLookup: (isin) async => 5,
        );
        final row = await source.fetchFundamentals(
          const MagicFormulaCandidate(
            symbol: '543320',
            companyName: 'Test BSE Industries Limited',
            exchange: 'BSE',
            isin: 'INE999Z01000',
          ),
        );
        expect(row.missingReason, isEmpty);
        // 3.1202e10 paid-up ÷ ₹5 master face value = 6.2404e9 shares
        // × ₹200 = ₹124,808 Cr.
        expect(row.marketCapCr, closeTo(124808, 1));
      },
    );

    test(
      'an implausible share count falls through to the next official source',
      () async {
        final source = _bseSource(
          db,
          settings,
          archiveTransform: (name, xml) => _rebuildAs(xml, {
            ..._factsFor(name),
            'NumberOfShares@OneI': '5000000000000', // 5e12 — refused
          }),
          faceValueLookup: (isin) async => null,
        );
        final row = await source.fetchFundamentals(
          const MagicFormulaCandidate(
            symbol: '543320',
            companyName: 'Test BSE Industries Limited',
            exchange: 'BSE',
          ),
        );
        // Falls back to paid-up ÷ filing face value: 1e9 ÷ 10 = 1e8 shares
        // × ₹200 = ₹2,000 Cr (not null, not the bogus 5e12 reading).
        expect(row.marketCapCr, 2000);
      },
    );

    test(
      'Yahoo fallback fills market cap when the official chain cannot',
      () async {
        // The insurance shape taken to its end: no share count, no per-share
        // face value (filing or master), no PAT/EPS — only Yahoo's own market
        // cap (the user-approved fallback) can fill the gap, and it must be
        // labeled unofficial on the row.
        final source = _bseSource(
          db,
          settings,
          archiveTransform: (name, xml) =>
              _rebuildAs(xml, _factsFor(name, includeFaceValue: false)),
          faceValueLookup: (isin) async => null,
          yahooLookup: (symbol) async {
            expect(symbol, '543320.BO');
            return const YahooQuote(marketCapCr: 12345);
          },
        );
        final row = await source.fetchFundamentals(
          const MagicFormulaCandidate(
            symbol: '543320',
            companyName: 'Test BSE Industries Limited',
            exchange: 'BSE',
            isin: 'INE999Z01000',
          ),
        );
        expect(row.marketCapCr, 12345);
        expect(row.source, contains('Market Cap: Yahoo Finance (unofficial)'));
        // The unofficial fill removes Market Cap from the missing list — the
        // row must not claim a missing field it just filled.
        expect(row.missingReason, isNot(contains('Market Cap')));
        expect(row.missingReason, isEmpty);
        expect(row.hasRequiredFields, isTrue);
      },
    );

    test('a failed Yahoo fallback leaves the row honestly missing', () async {
      final source = _bseSource(
        db,
        settings,
        archiveTransform: (name, xml) =>
            _rebuildAs(xml, _factsFor(name, includeFaceValue: false)),
        faceValueLookup: (isin) async => null,
        yahooLookup: (symbol) async => null,
      );
      final row = await source.fetchFundamentals(
        const MagicFormulaCandidate(
          symbol: '543320',
          companyName: 'Test BSE Industries Limited',
          exchange: 'BSE',
          isin: 'INE999Z01000',
        ),
      );
      expect(row.marketCapCr, isNull);
      expect(row.missingReason, contains('Market Cap'));
      expect(row.source, isNot(contains('Yahoo')));
    });

    test(
      'Yahoo price rescues a basket member absent from the official EOD file',
      () async {
        final source = _bseSource(
          db,
          settings,
          archiveTransform: (name, xml) => _rebuildAs(xml, _factsFor(name)),
          faceValueLookup: (isin) async => null,
          yahooLookup: (symbol) async {
            expect(symbol, '543399.BO');
            return YahooQuote(
              marketCapCr: 4000,
              lastPrice: 200,
              priceAsOf: DateTime(2026, 10, 22),
            );
          },
        );
        final row = await source.fetchFundamentals(
          const MagicFormulaCandidate(
            symbol: '543399',
            companyName: 'Not In EOD Limited',
            exchange: 'BSE',
          ),
        );
        // Official share inputs (1e9 ÷ ₹10 = 1e8 shares) × the Yahoo price
        // ₹200 = ₹2,000 Cr — the price is labeled, the shares stay official.
        expect(row.marketCapCr, 2000);
        expect(row.marketPriceAsOf, DateTime(2026, 10, 22));
        expect(row.source, contains('Price: Yahoo Finance (unofficial)'));
        expect(row.source, isNot(contains('Market Cap: Yahoo')));
      },
    );

    test(
      'thin June face takes the balance whole from the half-year statement '
      '(the SBILIFE shape)',
      () async {
        // SBILIFE's real BSE filings: one document per period with several
        // period columns. The Jun-2026 quarter face tags Assets + paid-up
        // capital but NO liabilities/cash/borrowings lines (the Statement of
        // Assets and Liabilities is not due with Q1); the Mar-2026 document —
        // shared between `Mar-Qtr` and `Mar-Yearly` rows — tags the complete
        // statement. The scan must take the balance WHOLE from that half-year
        // statement (its own date displayed), never mix lines, and then rank.
        const dates = <String, Map<String, String>>{
          'q4.xml': {'2026-03-31': '2026-06-30', '2026-01-01': '2026-04-01'},
          'q3.xml': {'2025-12-31': '2026-03-31', '2025-10-01': '2026-01-01'},
          'q2.xml': {'2025-09-30': '2025-12-31', '2025-07-01': '2025-10-01'},
          'q1.xml': {'2025-06-30': '2025-09-30', '2025-04-01': '2025-07-01'},
        };
        const facts = <String, Map<String, String>>{
          // Jun-2026 — the thin Q1 face (Assets + paid-up only).
          'q4.xml': {
            'Assets@OneI': '10000000000',
            'PaidUpEquityShareCapital@OneI': '1000000000',
            'ProfitBeforeTax@OneD': '40000000',
          },
          // Mar-2026 — the half-year statement, complete.
          'q3.xml': {
            'Assets@OneI': '10000000000',
            'CurrentLiabilities@OneI': '2000000000',
            'Borrowings@OneI': '0',
            'CashAndBankBalances@OneI': '500000000',
            'PaidUpEquityShareCapital@OneI': '1000000000',
            'ProfitBeforeTax@OneD': '30000000',
          },
          'q2.xml': {
            'Assets@OneI': '10000000000',
            'PaidUpEquityShareCapital@OneI': '1000000000',
            'ProfitBeforeTax@OneD': '20000000',
          },
          'q1.xml': {
            'Assets@OneI': '10000000000',
            'PaidUpEquityShareCapital@OneI': '1000000000',
            'ProfitBeforeTax@OneD': '10000000',
          },
        };
        final source = _bseSource(
          db,
          settings,
          archiveTransform: (name, xml) {
            var out = _rebuildAs(xml, facts[name]!);
            dates[name]!.forEach((from, to) {
              out = out.replaceAll(from, to);
            });
            return out;
          },
          faceValueLookup: (isin) async => 10,
          filingsJson: jsonEncode({
            'Table': [
              for (final row in [
                ['Standalone-Jun-Qtr-2026', 'q4.xml', '2026-07-24T16:52:51.843'],
                ['Standalone-Mar-Qtr-2026', 'q3.xml', '2026-04-22T17:49:11.000'],
                ['Standalone-Mar-Yearly-2026', 'q3.xml', '2026-04-22T17:49:11.000'],
                ['Standalone-Dec-Qtr-2025', 'q2.xml', '2026-01-28T22:14:40.000'],
                ['Standalone-Sep-Qtr-2025', 'q1.xml', '2025-10-24T18:19:22.000'],
                ['Standalone-Sep-Hly-2025', 'q1.xml', '2025-10-24T18:19:22.000'],
              ])
                {
                  'Yr': 2026,
                  'Qtrid': 130,
                  'Quarter_Name': row[0],
                  'status': 'New',
                  'filing_date_time': row[2],
                  'revised_date_time': null,
                  'XbrlFile':
                      '/XBRLFILES/IFLIDuplicateUploadDocument/${row[1]}',
                  'xbrlurl':
                      '/XBRLFILES/IFLIDuplicateUploadDocument/${row[1]}',
                  'seourl': '',
                  'navigateurl': null,
                  'navigateurldebt': null,
                },
            ],
          }),
        );
        final row = await source.fetchFundamentals(
          const MagicFormulaCandidate(
            symbol: '540719',
            companyName: 'Test Insurance Limited',
            exchange: 'BSE',
            isin: 'INE999Z01000',
          ),
        );
        expect(row.periodEnd, DateTime(2026, 6, 30));
        // The balance is the half-year statement's, dated in full honesty.
        expect(row.balanceSheetDate, DateTime(2026, 3, 31));
        expect(row.totalAssetsCr, 1000);
        expect(row.currentLiabilitiesCr, 200);
        expect(row.totalDebtCr, 0);
        expect(row.cashCr, 50);
        expect(row.marketCapCr, 2000); // paid-up ÷ ₹10 face value × ₹200
        expect(row.ebitTtmCr, 10); // PBT proxy sum (1+2+3+4 Cr)
        expect(row.missingReason, isEmpty);
        expect(MagicFormulaEngine.rank([row]).ranked, hasLength(1));
      },
    );

    test(
      'gap-fed quarter stream assembles TTM from the NineMths column '
      '(the SIEMENS shape)',
      () async {
        // Siemens has a September fiscal year: BSE's integrated feed carries
        // no Dec-quarter rows, so the quarter ends jump Mar-2026 → Sep-2025.
        // The Jun-2026 document still tags the official NineMths column
        // (Oct-2025 → Jun-2026) — TTM = that column + the Sep-2025 quarter,
        // all official figures, no estimation.
        const dates = <String, Map<String, String>>{
          'q4.xml': {'2026-03-31': '2026-06-30', '2026-01-01': '2026-04-01'},
          'q3.xml': {'2025-12-31': '2026-03-31', '2025-10-01': '2026-01-01'},
        };
        const facts = <String, Map<String, String>>{
          // Jun-2026 — quarter + NineMths column, full balance sheet.
          'q4.xml': {
            'ProfitBeforeTax@OneD': '40000000',
            'ProfitBeforeTax@NineD': '90000000',
            'Assets@OneI': '10000000000',
            'CurrentLiabilities@OneI': '2000000000',
            'BorrowingsCurrent@OneI': '1000000000',
            'BorrowingsNoncurrent@OneI': '3000000000',
            'CashAndCashEquivalents@OneI': '500000000',
            'PaidUpEquityCapital@OneI': '1000000000',
            'FaceValueOfEquityShareCapital@OneI': '10',
          },
          // Mar-2026 — quarter only.
          'q3.xml': {
            'ProfitBeforeTax@OneD': '30000000',
            'Assets@OneI': '10000000000',
            'PaidUpEquityCapital@OneI': '1000000000',
          },
          // Sep-2025 — quarter (the TTM window's oldest slot).
          'q2.xml': {
            'ProfitBeforeTax@OneD': '20000000',
            'Assets@OneI': '10000000000',
          },
          // Jun-2025 — outside the TTM window; must NOT leak into the sum.
          'q1.xml': {
            'ProfitBeforeTax@OneD': '10000000',
            'Assets@OneI': '10000000000',
          },
        };
        final source = _bseSource(
          db,
          settings,
          archiveTransform: (name, xml) {
            // Shift the quarter grid BEFORE rebuilding so the generated
            // column contexts (NineMths/Yearly/comparative) carry the
            // shifted dates too.
            var shifted = xml;
            dates[name]?.forEach((from, to) {
              shifted = shifted.replaceAll(from, to);
            });
            return _rebuildAs(shifted, facts[name]!);
          },
          faceValueLookup: (isin) async => 10,
          filingsJson: jsonEncode({
            'Table': [
              for (final row in [
                ['Standalone-Jun-Qtr-2026', 'q4.xml', '2026-08-11T14:29:54.000'],
                ['Standalone-Mar-Qtr-2026', 'q3.xml', '2026-06-03T16:25:29.000'],
                ['Standalone-Sep-Qtr-2025', 'q2.xml', '2025-11-14T17:51:46.000'],
                ['Standalone-Jun-Qtr-2025', 'q1.xml', '2025-08-08T21:42:39.000'],
              ])
                {
                  'Yr': 2026,
                  'Qtrid': 130,
                  'Quarter_Name': row[0],
                  'status': 'New',
                  'filing_date_time': row[2],
                  'revised_date_time': null,
                  'XbrlFile':
                      '/XBRLFILES/IFLIDuplicateUploadDocument/${row[1]}',
                  'xbrlurl':
                      '/XBRLFILES/IFLIDuplicateUploadDocument/${row[1]}',
                  'seourl': '',
                  'navigateurl': null,
                  'navigateurldebt': null,
                },
            ],
          }),
        );
        final row = await source.fetchFundamentals(
          const MagicFormulaCandidate(
            symbol: '500550',
            companyName: 'Test September-FY Engineering Limited',
            exchange: 'BSE',
          ),
        );
        // TTM PBT = Sep-2025 quarter (2 Cr) + NineMths Oct-25→Jun-26 (9 Cr).
        // The Jun-2025 quarter and the Jun-2026 quarter column must not
        // double count; the missing Dec-2025 quarter is inside the NineMths.
        expect(
          row.ebitTtmCr,
          11,
          reason:
              'periodEnd=${row.periodEnd} balance=${row.balanceSheetDate} '
              'missing=${row.missingReason} basis=${row.earningsBasis} '
              'src=${row.source}',
        );
        expect(row.periodEnd, DateTime(2026, 6, 30));
        expect(row.missingReason, isEmpty);
        expect(row.marketCapCr, 2000);
        expect(MagicFormulaEngine.rank([row]).ranked, hasLength(1));
      },
    );

    test(
      'new listing assembles TTM from the Yearly column and its comparative '
      '(the VAML shape)',
      () async {
        // A demerged listing (effective May-2026) has only two quarter
        // rows. Its Mar-2026 document — shared between Mar-Qtr and Mar-Yearly
        // rows — tags the full FY26 column (Apr-2025 → Mar-2026), and the
        // Jun-2026 document shows the Apr-Jun-2025 comparative. TTM
        // (Jul-2025 → Jun-2026) = Yearly − prior-year quarter + current
        // quarter — exact official arithmetic, and the balance sheet comes
        // whole from the half-year statement (thin Q1 face rule).
        const dates = <String, Map<String, String>>{
          'q4.xml': {'2026-03-31': '2026-06-30', '2026-01-01': '2026-04-01'},
          'q3.xml': {'2025-12-31': '2026-03-31', '2025-10-01': '2026-01-01'},
        };
        const facts = <String, Map<String, String>>{
          // Jun-2026 — quarter + prior-year comparative, thin face.
          'q4.xml': {
            'ProfitBeforeTax@OneD': '20000000',
            'ProfitBeforeTax@PriorD': '10000000',
            'Assets@OneI': '10000000000',
            'PaidUpEquityShareCapital@OneI': '1000000000',
          },
          // Mar-2026 — quarter + full Yearly column + complete balance.
          'q3.xml': {
            'ProfitBeforeTax@OneD': '30000000',
            'ProfitBeforeTax@YearD': '100000000',
            'Assets@OneI': '10000000000',
            'CurrentLiabilities@OneI': '2000000000',
            'Borrowings@OneI': '0',
            'CashAndBankBalances@OneI': '500000000',
            'PaidUpEquityShareCapital@OneI': '1000000000',
            'FaceValueOfEquityShareCapital@OneI': '10',
          },
        };
        final source = _bseSource(
          db,
          settings,
          archiveTransform: (name, xml) {
            // Shift the quarter grid BEFORE rebuilding so the generated
            // column contexts (NineMths/Yearly/comparative) carry the
            // shifted dates too.
            var shifted = xml;
            dates[name]?.forEach((from, to) {
              shifted = shifted.replaceAll(from, to);
            });
            return _rebuildAs(shifted, facts[name]!);
          },
          faceValueLookup: (isin) async => 10,
          filingsJson: jsonEncode({
            'Table': [
              for (final row in [
                ['Standalone-Jun-Qtr-2026', 'q4.xml', '2026-07-30T17:32:00.000'],
                ['Standalone-Mar-Qtr-2026', 'q3.xml', '2026-06-16T15:40:41.000'],
                ['Standalone-Mar-Yearly-2026', 'q3.xml', '2026-06-16T15:40:41.000'],
              ])
                {
                  'Yr': 2026,
                  'Qtrid': 130,
                  'Quarter_Name': row[0],
                  'status': 'New',
                  'filing_date_time': row[2],
                  'revised_date_time': null,
                  'XbrlFile':
                      '/XBRLFILES/IFLIDuplicateUploadDocument/${row[1]}',
                  'xbrlurl':
                      '/XBRLFILES/IFLIDuplicateUploadDocument/${row[1]}',
                  'seourl': '',
                  'navigateurl': null,
                  'navigateurldebt': null,
                },
            ],
          }),
        );
        final row = await source.fetchFundamentals(
          const MagicFormulaCandidate(
            symbol: '544780',
            companyName: 'Test Demerged Metals Limited',
            exchange: 'BSE',
          ),
        );
        // TTM PBT = Yearly (10 Cr) − Apr-Jun-2025 comparative (1 Cr)
        // + Apr-Jun-2026 quarter (2 Cr) = 11 Cr.
        expect(row.ebitTtmCr, 11);
        expect(row.earningsBasis, contains('Yearly'));
        expect(row.earningsBasis, contains('prior-year quarter'));
        // Thin June face → balance whole from the Mar half-year statement.
        expect(row.balanceSheetDate, DateTime(2026, 3, 31));
        expect(row.totalAssetsCr, 1000);
        expect(row.currentLiabilitiesCr, 200);
        expect(row.totalDebtCr, 0);
        expect(row.cashCr, 50);
        expect(row.marketCapCr, 2000);
        expect(row.missingReason, isEmpty);
        expect(MagicFormulaEngine.rank([row]).ranked, hasLength(1));
      },
    );

    test(
      'a basket-added BSE row resolves its scrip code from the data symbol',
      () async {
        // The exact shape a basket suggestion produces: plain ticker as the
        // symbol, six-digit BSE code in the data symbol, no ISIN. Before the
        // fix every such row skipped with 'BSE scrip code nahi mili'.
        final source = _bseSource(
          db,
          settings,
          archiveTransform: (name, xml) => _rebuildAs(xml, _factsFor(name)),
          faceValueLookup: (isin) async => 10,
        );
        final row = await source.fetchFundamentals(
          const MagicFormulaCandidate(
            symbol: 'SIEMENS',
            companyName: 'Siemens Limited',
            exchange: 'BSE',
            dataSymbol: '500550',
          ),
        );
        expect(row.missingReason, isEmpty);
        expect(row.marketCapCr, 2000);
        expect(row.periodEnd, DateTime(2026, 3, 31));
        expect(MagicFormulaEngine.rank([row]).ranked, hasLength(1));
      },
    );

    test(
      'a stored basket row with no identity at all still finds its code',
      () async {
        // Rows added to baskets before 1.5.44 sit in the database with no
        // isin and no scrip code — just the ticker and 'BSE'. The scan must
        // still resolve the official UDiFF row by ticker, or every old
        // basket keeps failing after the fix ships.
        final source = _bseSource(
          db,
          settings,
          archiveTransform: (name, xml) => _rebuildAs(xml, _factsFor(name)),
          faceValueLookup: (isin) async => 10,
        );
        final row = await source.fetchFundamentals(
          const MagicFormulaCandidate(
            symbol: 'SIEMENS',
            companyName: 'Siemens Limited',
            exchange: 'BSE',
          ),
        );
        expect(row.missingReason, isEmpty);
        expect(row.marketCapCr, 2000);
        expect(MagicFormulaEngine.rank([row]).ranked, hasLength(1));
      },
    );

    test(
      'a REIT/InvIT basket member in BSE series IF keeps its official close',
      () async {
        // BIRET/EMBASSY/BAGMANE trade on BSE under series IF. The parser used
        // to drop those cash-market rows, every REIT row then failed with
        // 'BSE scrip code nahi mili' even though the official file carries
        // the scrip code and close.
        final source = _bseSource(
          db,
          settings,
          archiveTransform: (name, xml) => _rebuildAs(xml, _factsFor(name)),
          faceValueLookup: (isin) async => 10,
        );
        final row = await source.fetchFundamentals(
          const MagicFormulaCandidate(
            symbol: 'BIRET',
            companyName: 'Brookfield Infrastructure REIT',
            exchange: 'BSE',
          ),
        );
        expect(row.missingReason, isEmpty);
        expect(row.marketCapCr, closeTo(3020.7, 0.1));
        expect(MagicFormulaEngine.rank([row]).ranked, hasLength(1));
      },
    );

    test(
      'a broker-suffixed symbol still matches the official ticker',
      () async {
        // Broker masters append segment tags; the official report lists the
        // bare ticker. A stored basket row must not lose its identity to a
        // '-EQ'/'.BSE' suffix.
        final source = _bseSource(
          db,
          settings,
          archiveTransform: (name, xml) => _rebuildAs(xml, _factsFor(name)),
          faceValueLookup: (isin) async => 10,
        );
        final row = await source.fetchFundamentals(
          const MagicFormulaCandidate(
            symbol: 'SIEMENS.BSE',
            companyName: 'Siemens Limited',
            exchange: 'BSE',
            dataSymbol: 'SIEMENS-EQ',
          ),
        );
        expect(row.missingReason, isEmpty);
        expect(row.marketCapCr, 2000);
        expect(MagicFormulaEngine.rank([row]).ranked, hasLength(1));
      },
    );

    test('a failed row is never served from the cache as fresh', () async {
      // The bug behind 'same error abhi bhi': a missing row cached by an old
      // scan kept being served for an hour (and re-pinned on every retry), so
      // a fixed pipeline still looked broken. Absence must refetch.
      final now = DateTime(2026, 10, 25, 12);
      final failed = MagicFormulaFundamental(
        candidate: const MagicFormulaCandidate(
          symbol: 'DUMMYHEG',
          companyName: 'Dummy HEG Ltd',
          exchange: 'BSE',
        ),
        fetchedAt: now.subtract(const Duration(minutes: 5)),
        missingReason: 'BSE scrip code official reports me nahi mili.',
      );
      expect(failed.isFresh(now: now), isFalse);
      final ok = MagicFormulaFundamental(
        candidate: const MagicFormulaCandidate(
          symbol: 'SIEMENS',
          companyName: 'Siemens Limited',
          exchange: 'BSE',
        ),
        marketCapCr: 2000,
        ebitTtmCr: 100,
        fetchedAt: now.subtract(const Duration(minutes: 5)),
      );
      expect(ok.isFresh(now: now), isTrue);
    });

    test(
      'an NSE universe row falls back to the official BSE filing feed',
      () async {
        // The NIFTY 500 scan path: candidates arrive as NSE rows. When the
        // NSE Integrated Filing feed publishes nothing for a member (new
        // listings, demerged entities), the official BSE feed must be tried
        // before the row is declared missing — both feeds are official.
        final nseCsv = [
          'TradDt,BizDt,Sgmt,Src,FinInstrmTp,FinInstrmId,ISIN,TckrSymb,SctySrs,'
              'XpryDt,FininstrmActlXpryDt,StrkPric,OptnTp,FinInstrmNm,OpnPric,'
              'HghPric,LwPric,ClsPric,LastPric,PrvsClsgPric,UndrlygPric,'
              'SttlmPric,OpnIntrst,ChngInOpnIntrst,TtlTradgVol,TtlTrfVal,'
              'TtlNbOfTxsExctd,SsnId,NewBrdLotQty,Rmks,Rsvd1,Rsvd2,Rsvd3,Rsvd4',
          '2026-10-23,2026-10-23,CM,NSE,STK,3150,INE003A01024,SIEMENS,EQ,,,,,'
              'SIEMENS LTD,3200.00,3260.00,3190.00,3245.20,3245.20,3200.00,,'
              '3245.20,,,22222,4444000.00,444,F1,1,,,,,',
        ].join('\n');
        final zip = ZipEncoder().encode(
          Archive()
            ..addFile(
              ArchiveFile(
                'BhavCopy_NSE_CM_0_0_0_20261023_F_0000.csv',
                nseCsv.length,
                utf8.encode(nseCsv),
              ),
            ),
        )!;

        final source = NseMagicFormulaDataSource(
          scripDao: ScripDao(db),
          listings: NseListingService(settings: settings),
          settings: settings,
          minimumRequestGap: Duration.zero,
          clock: () => DateTime(2026, 10, 23),
          faceValueLookup: (_) async => 10,
          get: (uri, {refererPath}) async {
            if (uri.host == 'www.nseindia.com' &&
                uri.path.contains('integrated-filing')) {
              return '{"data": []}';
            }
            if (uri.host == NseMagicFormulaDataSource.bseIntegratedFilingHost) {
              return _fixture('bse_integrated_filings.json');
            }
            if (uri.host == 'www.bseindia.com' &&
                uri.path.startsWith('/XBRLFILES/')) {
              final name = uri.pathSegments.last;
              return _rebuildAs(_fixture(name), _factsFor(name));
            }
            throw StateError('Unexpected fixture request: $uri');
          },
          getBytes: (uri, {refererPath}) async {
            if (uri.host == 'nsearchives.nseindia.com' &&
                uri.path.endsWith('.zip')) {
              return zip;
            }
            if (uri.host == 'www.bseindia.com' &&
                uri.path.startsWith('/download/BhavCopy/Equity/')) {
              return utf8.encode(_fixture('bse_udiff_20261023.csv'));
            }
            throw StateError('Unexpected fixture byte request: $uri');
          },
        );

        final row = await source.fetchFundamentals(
          const MagicFormulaCandidate(
            symbol: 'SIEMENS',
            companyName: 'Siemens Ltd.',
            exchange: 'NSE',
            isin: 'INE003A01024',
            dataSymbol: 'SIEMENS',
          ),
        );
        expect(row.missingReason, isEmpty);
        expect(
          row.source,
          'NSE CM-UDiFF EOD Close + BSE Integrated Filing XBRL',
        );
        // Price from the NSE close file: 1e8 shares × ₹3245.20 = ₹32,452 Cr.
        expect(row.marketCapCr, closeTo(32452, 1));
        // TTM assembled from the BSE feed's official quarter columns.
        expect(row.ebitTtmCr, 10);
      },
    );

    test('a window that no official columns can cover stays honestly missing', () async {
      // Same two filings as the VAML shape but with no Yearly and no
      // comparative columns: the trailing window simply cannot be covered,
      // and no number may be invented for it.
      const dates = <String, Map<String, String>>{
        'q4.xml': {'2026-03-31': '2026-06-30', '2026-01-01': '2026-04-01'},
        'q3.xml': {'2025-12-31': '2026-03-31', '2025-10-01': '2026-01-01'},
      };
      const facts = <String, Map<String, String>>{
        'q4.xml': {
          'ProfitBeforeTax@OneD': '20000000',
          'Assets@OneI': '10000000000',
        },
        'q3.xml': {
          'ProfitBeforeTax@OneD': '30000000',
          'Assets@OneI': '10000000000',
        },
      };
      final source = _bseSource(
        db,
        settings,
        archiveTransform: (name, xml) {
          var shifted = xml;
          dates[name]?.forEach((from, to) {
            shifted = shifted.replaceAll(from, to);
          });
          return _rebuildAs(shifted, facts[name]!);
        },
        faceValueLookup: (isin) async => 10,
        filingsJson: jsonEncode({
          'Table': [
            for (final row in [
              ['Standalone-Jun-Qtr-2026', 'q4.xml', '2026-07-30T17:32:00.000'],
              ['Standalone-Mar-Qtr-2026', 'q3.xml', '2026-06-16T15:40:41.000'],
            ])
              {
                'Yr': 2026,
                'Qtrid': 130,
                'Quarter_Name': row[0],
                'status': 'New',
                'filing_date_time': row[2],
                'revised_date_time': null,
                'XbrlFile': '/XBRLFILES/IFLIDuplicateUploadDocument/${row[1]}',
                'xbrlurl': '/XBRLFILES/IFLIDuplicateUploadDocument/${row[1]}',
                'seourl': '',
                'navigateurl': null,
                'navigateurldebt': null,
              },
          ],
        }),
      );
      final row = await source.fetchFundamentals(
        const MagicFormulaCandidate(
          symbol: '544780',
          companyName: 'Test Demerged Metals Limited',
          exchange: 'BSE',
        ),
      );
      expect(row.ebitTtmCr, isNull);
      expect(row.missingReason, contains('TTM EBIT'));
      expect(MagicFormulaEngine.rank([row]).ranked, isEmpty);
    });

    test('missing scrip code is an honest skip, never a guessed link', () async {
      final source = _bseSource(
        db,
        settings,
        archiveTransform: (name, xml) => _rebuildAs(xml, _factsFor(name)),
        faceValueLookup: (_) async => null,
      );
      // 'NOCODE' prices by ticker in the fixture, but its row carries no
      // FinInstrmId and the candidate has no ISIN — no filing link is
      // invented.
      final row = await source.fetchFundamentals(
        const MagicFormulaCandidate(
          symbol: 'NOCODE',
          companyName: 'No Code Trading Ltd',
          exchange: 'BSE',
        ),
      );
      expect(row.marketCapCr, isNull);
      expect(row.missingReason.toLowerCase(), contains('scrip code'));
    });
  });
}

// ---------------------------------------------------------------------------
// Harness — offline routing, mirroring the NSE fixture harness.
// ---------------------------------------------------------------------------

NseMagicFormulaDataSource _bseSource(
  AppDatabase db,
  SettingsDao settings, {
  required String Function(String name, String xml) archiveTransform,
  required Future<double?> Function(String isin) faceValueLookup,
  YahooQuoteLookup? yahooLookup,
  String? filingsJson,
}) => NseMagicFormulaDataSource(
  scripDao: ScripDao(db),
  listings: NseListingService(settings: settings),
  settings: settings,
  minimumRequestGap: Duration.zero,
  clock: () => DateTime(2026, 10, 23),
  faceValueLookup: faceValueLookup,
  yahooLookup: yahooLookup,
  get: (uri, {refererPath}) async {
    if (uri.host == NseMagicFormulaDataSource.bseIntegratedFilingHost) {
      expect(uri.path, NseMagicFormulaDataSource.bseIntegratedFilingPath);
      expect(uri.queryParameters['scripcode'], isNotEmpty);
      return filingsJson ?? _fixture('bse_integrated_filings.json');
    }
    if (uri.host == 'www.bseindia.com' && uri.path.startsWith('/XBRLFILES/')) {
      final name = uri.pathSegments.last;
      return archiveTransform(name, _fixture(name));
    }
    throw StateError('Unexpected fixture request: $uri');
  },
  getBytes: (uri, {refererPath}) async {
    if (uri.host == 'www.bseindia.com' &&
        uri.path.startsWith('/download/BhavCopy/Equity/')) {
      expect(uri.path, contains('_20261023_'));
      return utf8.encode(_fixture('bse_udiff_20261023.csv'));
    }
    throw StateError('Unexpected fixture byte request: $uri');
  },
);

/// Balance + market-cap facts per quarter doc. q4 is the latest statement, so
/// its balance sheet wins. Quarter PBTs: q1=1, q2=2, q3=3, q4=4 (₹ Cr).
Map<String, String> _factsFor(String name, {bool includeFaceValue = true}) {
  final pbt = switch (name) {
    'q1.xml' => 10000000,
    'q2.xml' => 20000000,
    'q3.xml' => 30000000,
    _ => 40000000,
  };
  return {
    'ProfitBeforeTax@OneD': '$pbt',
    'Assets@OneI': '10000000000',
    'CurrentLiabilities@OneI': '2000000000',
    'BorrowingsCurrent@OneI': '1000000000',
    'BorrowingsNoncurrent@OneI': '3000000000',
    'CashAndCashEquivalents@OneI': '500000000',
    'PaidUpEquityCapital@OneI': '1000000000',
    if (includeFaceValue) 'FaceValueOfEquityShareCapital@OneI': '10',
  };
}

String _fixture(String name) =>
    File('test/fixtures/magic_formula/$name').readAsStringSync();

String _rebuildAs(String xml, Map<String, String> facts) {
  final instant = RegExp(
    r'<xbrli:instant>([^<]+)</xbrli:instant>',
  ).firstMatch(xml)!.group(1)!;
  final start = RegExp(
    r'<xbrli:startDate>([^<]+)</xbrli:startDate>',
  ).firstMatch(xml)!.group(1)!;
  final end = RegExp(
    r'<xbrli:endDate>([^<]+)</xbrli:endDate>',
  ).firstMatch(xml)!.group(1)!;
  final endDate = DateTime.parse(end);

  /// First day of the month [backMonths - 1] months before the end month —
  /// the SEBI column start for a [backMonths]-month period ending at [end].
  String monthStart(int backMonths) {
    var month = endDate.month - (backMonths - 1);
    var year = endDate.year;
    while (month <= 0) {
      month += 12;
      year -= 1;
    }
    return '$year-${month.toString().padLeft(2, '0')}-01';
  }

  String durationContext(String id, String colStart) =>
      '<xbrli:context id="$id"><xbrli:entity>'
      '<xbrli:identifier scheme="">INE999Z01000</xbrli:identifier>'
      '</xbrli:entity><xbrli:period>'
      '<xbrli:startDate>$colStart</xbrli:startDate>'
      '<xbrli:endDate>$end</xbrli:endDate></xbrli:period></xbrli:context>\n';
  final buffer = StringBuffer(
    '<?xml version="1.0" encoding="UTF-8"?>\n'
    '<xbrli:xbrl xmlns:xbrli="http://www.xbrl.org/2003/instance" '
    'xmlns:in-capmkt="https://www.sebi.gov.in/xbrl">\n'
    '<xbrli:context id="OneI"><xbrli:entity>'
    '<xbrli:identifier scheme="">INE999Z01000</xbrli:identifier>'
    '</xbrli:entity><xbrli:period>'
    '<xbrli:instant>$instant</xbrli:instant></xbrli:period>'
    '</xbrli:context>\n'
    '<xbrli:context id="OneD"><xbrli:entity>'
    '<xbrli:identifier scheme="">INE999Z01000</xbrli:identifier>'
    '</xbrli:entity><xbrli:period>'
    '<xbrli:startDate>$start</xbrli:startDate>'
    '<xbrli:endDate>$end</xbrli:endDate></xbrli:period>'
    '</xbrli:context>\n',
  );
  // Long-period (Hly/NineMths/Yearly) and comparative-quarter contexts are
  // emitted only when facts actually reference them.
  final used = facts.keys.map((k) => k.split('@').last).toSet();
  if (used.contains('HalfD')) {
    buffer.write(durationContext('HalfD', monthStart(6)));
  }
  if (used.contains('NineD')) {
    buffer.write(durationContext('NineD', monthStart(9)));
  }
  if (used.contains('YearD')) {
    buffer.write(durationContext('YearD', monthStart(12)));
  }
  if (used.contains('PriorD')) {
    final priorEnd = DateTime(endDate.year - 1, endDate.month, endDate.day);
    final priorStart = DateTime(priorEnd.year, priorEnd.month - 2, 1);
    final priorEndLabel =
        '${priorEnd.year}-${priorEnd.month.toString().padLeft(2, '0')}-'
        '${priorEnd.day.toString().padLeft(2, '0')}';
    final priorStartLabel =
        '${priorStart.year}-${priorStart.month.toString().padLeft(2, '0')}-01';
    buffer.write(durationContext('PriorD', priorStartLabel).replaceFirst(
      '<xbrli:endDate>$end</xbrli:endDate>',
      '<xbrli:endDate>$priorEndLabel</xbrli:endDate>',
    ));
  }
  for (final entry in facts.entries) {
    final parts = entry.key.split('@');
    buffer.write(
      '<in-capmkt:${parts[0]} contextRef="${parts[1]}" unitRef="INR">'
      '${entry.value}</in-capmkt:${parts[0]}>\n',
    );
  }
  buffer.write('</xbrli:xbrl>');
  return buffer.toString();
}
