// ---------------------------------------------------------------------------
// auth_service.dart — Angel One SmartAPI login, session refresh and logout.
//
// Flow:
//   1. POST /rest/auth/angelbroking/user/v1/loginByPassword
//        body    { clientcode, password, totp }
//        headers X-PrivateKey + the five mandatory SmartAPI headers
//      → { data: { jwtToken, refreshToken, feedToken } }
//   2. Persist the session in the keystore (SecureStore).
//   3. Every later REST call carries `Authorization: Bearer <jwtToken>`.
//   4. SmartAPI JWTs expire daily (05:00 IST); before that, the session is
//      renewed in place with POST /rest/auth/angelbroking/jwt/v1/generateTokens
//      using the refreshToken — the user is never asked for the TOTP again.
//
// The TOTP is generated on-device from the stored base32 secret (RFC 6238), see
// core/utils/totp.dart. A manually typed 6-digit code can be passed instead,
// which is useful when the phone's clock is drifting.
// ---------------------------------------------------------------------------

import 'dart:async';

import 'package:flutter/foundation.dart';

import '../core/utils/totp.dart';
import '../data/remote/api_client.dart';
import '../data/remote/dto/session.dart';
import 'secure_store.dart';

enum AuthStatus {
  /// Still reading the keystore — show a splash.
  unknown,

  /// No valid session; the login screen is required.
  loggedOut,

  /// A login request is in flight.
  authenticating,

  /// Session is valid (or was silently refreshed).
  loggedIn,
}

class AuthService extends ChangeNotifier {
  AuthService({required SecureStore store, ApiClient? client})
      : _store = store,
        _client = client ?? ApiClient();

  final SecureStore _store;
  final ApiClient _client;

  static const String _loginPath =
      '/rest/auth/angelbroking/user/v1/loginByPassword';
  static const String _refreshPath =
      '/rest/auth/angelbroking/jwt/v1/generateTokens';
  static const String _profilePath =
      '/rest/secure/angelbroking/user/v1/getProfile';

  AuthStatus _status = AuthStatus.unknown;
  AngelSession? _session;
  AngelProfile? _profile;
  AngelCredentials? _savedCredentials;
  String? _errorMessage;
  String? _errorHint;
  Timer? _refreshTimer;

  // ---- Read-only state for the UI -----------------------------------------

  AuthStatus get status => _status;
  AngelSession? get session => _session;
  AngelProfile? get profile => _profile;

  /// `true` once credentials are stored, so the login screen can pre-fill the
  /// API key / client code (the password & TOTP secret are never shown again).
  bool get hasSavedCredentials => _savedCredentials != null;
  String get savedApiKey => _savedCredentials?.apiKey ?? '';
  String get savedClientCode => _savedCredentials?.clientCode ?? '';
  bool get hasSavedPassword => (_savedCredentials?.password ?? '').isNotEmpty;
  bool get hasSavedTotpSecret => (_savedCredentials?.totpSecret ?? '').isNotEmpty;

  String? get errorMessage => _errorMessage;
  String? get errorHint => _errorHint;

  bool get isLoggedIn => _status == AuthStatus.loggedIn && _session != null;

  /// Minutes until the current token expires (shown in Settings).
  int? get minutesToExpiry => _session?.timeToExpiry.inMinutes;

  // -------------------------------------------------------------------------
  // Lifecycle
  // -------------------------------------------------------------------------

  /// Restores a stored session at app start (no network call unless a refresh
  /// is actually needed). Safe to call more than once.
  Future<void> restore() async {
    if (_status != AuthStatus.unknown && _status != AuthStatus.loggedOut) return;

    _savedCredentials = await _store.readCredentials();
    final stored = await _store.readSession();

    if (stored == null || stored.isExpired) {
      if (stored != null) await _store.clearSession();
      _setStatus(AuthStatus.loggedOut);
      return;
    }

    _session = stored;
    _setStatus(AuthStatus.loggedIn);
    if (stored.shouldRefresh) {
      // Fire-and-forget: the UI is already usable with the stored token.
      unawaited(refreshSession(silent: true));
    }
    unawaited(loadProfile());
  }

  /// Logs in with [credentials], generating the TOTP on-device.
  ///
  /// Pass [manualTotp] when the user typed the 6-digit code themselves.
  Future<bool> login(
    AngelCredentials credentials, {
    String? manualTotp,
    bool rememberCredentials = true,
  }) async {
    _errorMessage = null;
    _errorHint = null;
    _setStatus(AuthStatus.authenticating);

    try {
      final totp = (manualTotp ?? '').trim().isNotEmpty
          ? manualTotp!.trim()
          : Totp.generate(credentials.totpSecret);

      final body = await _client.postJson(
        _loginPath,
        {
          'clientcode': credentials.clientCode.trim().toUpperCase(),
          'password': credentials.password,
          'totp': totp,
          'state': 'angel_trader',
        },
        apiKey: credentials.apiKey.trim(),
        requiresAuth: false, // login does not carry a bearer token
      );

      final session = AngelSession.fromLoginResponse(
        body,
        apiKey: credentials.apiKey.trim(),
        clientCode: credentials.clientCode.trim().toUpperCase(),
      );

      _session = session;
      if (rememberCredentials) {
        _savedCredentials = credentials;
        await _store.writeCredentials(credentials);
      }
      await _store.writeSession(session);

      _setStatus(AuthStatus.loggedIn);
      _scheduleRefresh();
      unawaited(loadProfile());
      return true;
    } on LoginException catch (e) {
      _fail(e.message, e.hint);
      return false;
    } on ApiException catch (e) {
      _fail(
        e.message,
        e.isRateLimited
            ? 'SmartAPI throttles logins; wait about a minute and try again.'
            : '',
      );
      return false;
    } catch (e) {
      _fail('Login failed: $e');
      return false;
    }
  }

  /// One-tap re-login using the credentials already in the keystore.
  ///
  /// This is the flow after a daily token expiry (05:00 IST): the MPIN and the
  /// TOTP secret are already on the device, so the user does not retype
  /// anything — a fresh 6-digit code is generated automatically.
  Future<bool> loginWithSavedCredentials() async {
    final saved = _savedCredentials ?? await _store.readCredentials();
    if (saved == null || saved.validate().isNotEmpty) return false;
    _savedCredentials = saved;
    return login(saved);
  }

  /// Renews the JWT with the stored refresh token.
  Future<bool> refreshSession({bool silent = false}) async {
    final current = _session;
    if (current == null) return false;

    try {
      final body = await _client.postJson(
        _refreshPath,
        {'refreshToken': current.refreshToken},
        apiKey: current.apiKey,
        bearerToken: current.jwtToken,
        clientCode: current.clientCode,
      );

      final refreshed = current.refreshedWith(body);
      _session = refreshed;
      await _store.writeSession(refreshed);
      _setStatus(AuthStatus.loggedIn);
      _scheduleRefresh();
      return true;
    } catch (e) {
      // A silent refresh failure must not kick the user out mid-session: the
      // existing token may still be valid. Only surface it when the token is
      // genuinely dead.
      if (!silent || (current.isExpired)) {
        _fail(
          'Your Angel One session expired. Please log in again.',
          '',
        );
      }
      return false;
    }
  }

  /// Called by data services before a REST call. Returns `false` when the app
  /// is not (or no longer) authenticated, so callers can fall back to cache.
  Future<bool> ensureValidSession() async {
    final current = _session;
    if (current == null) return false;
    if (current.isExpired) {
      _setStatus(AuthStatus.loggedOut);
      await _store.clearSession();
      _session = null;
      return false;
    }
    if (current.shouldRefresh) {
      return refreshSession(silent: true);
    }
    return true;
  }

  /// Fetches the client name shown on the dashboard header.
  Future<void> loadProfile() async {
    final current = _session;
    if (current == null) return;
    try {
      final body = await _client.postJson(
        _profilePath,
        const {},
        apiKey: current.apiKey,
        bearerToken: current.jwtToken,
        clientCode: current.clientCode,
      );
      if (body['status'] == true) {
        _profile = AngelProfile.fromApi(body);
        notifyListeners();
      }
    } catch (_) {
      // Profile is cosmetic — never block the app on it.
    }
  }

  /// Clears the in-memory session (and optionally the saved credentials).
  Future<void> logout({bool forgetCredentials = false}) async {
    _refreshTimer?.cancel();
    _session = null;
    _profile = null;
    await _store.clearSession();
    if (forgetCredentials) {
      _savedCredentials = null;
      await _store.clearAll();
    }
    _errorMessage = null;
    _errorHint = null;
    _setStatus(AuthStatus.loggedOut);
  }

  /// Clears the error banner after the user has seen it.
  void clearError() {
    _errorMessage = null;
    _errorHint = null;
    notifyListeners();
  }

  // -------------------------------------------------------------------------
  // Internals
  // -------------------------------------------------------------------------

  /// Refreshes the token 10 minutes before it lapses, so an open screen keeps
  /// working without the user noticing.
  void _scheduleRefresh() {
    _refreshTimer?.cancel();
    final session = _session;
    if (session == null) return;

    final seconds = session.timeToExpiry.inSeconds - 600;
    final delay = Duration(seconds: seconds.clamp(60, 12 * 3600));
    _refreshTimer = Timer(delay, () => unawaited(refreshSession(silent: true)));
  }

  void _fail(String message, [String hint = '']) {
    _errorMessage = message;
    _errorHint = hint;
    _setStatus(AuthStatus.loggedOut);
  }

  void _setStatus(AuthStatus status) {
    _status = status;
    notifyListeners();
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    super.dispose();
  }
}
