// ---------------------------------------------------------------------------
// fno_study_service.dart — the "3-Month Study" scan, start to finish (F&O).
//
// What one run does, and why it is shaped this way:
//
//   Phase 1  candles (cache first, exactly like the other screeners) + pick the
//            ATM strike from the *local* option book. No option API call yet —
//            the strike choice only needs the stock's own price.
//   Phase 2  one batched FULL quote per 50 option tokens, for **all** stocks at
//            once. This is the difference between 60 requests and 2: the SPEC's
//            per-stock lookup would hammer a 3-requests-per-second endpoint for
//            no reason.
//   Phase 3  option greeks per stock (one call returns the whole chain for that
//            expiry) → real broker IV for the ATM CE/PE.
//   Phase 4  Black-Scholes fallback for whatever IV is still missing, then the
//            universe-wide pass (IV rank, opportunity tag, ranks) and the
//            snapshot is persisted.
//   Phase 4.5 the OTM jodi (strangle): the CE above the money and the PE below
//            it whose combined premium is closest to half the ATM jodi's, chosen
//            from the *local* chain with Black-Scholes estimates (a ranking aid
//            only) and then quoted for real — one batched call per 50 tokens.
//
// Failure policy (spec §6): a stock whose option data failed is **not** dropped —
// the options fields stay null, the row keeps its trend/ATR/score and the reason
// string says the data is degraded. Only "not enough candles" and "no candles at
// all" produce a skip row, and those are always visible in the skip sheet.
//
// Nothing here is Flutter-aware: candles arrive through [CandleSource], quotes
// and greeks through [StudyMarketData], contracts through [FnoContractDao] —
// so the whole scan is unit-tested with fakes.
// ---------------------------------------------------------------------------

import 'dart:async';
import 'dart:math' as math;

import '../core/utils/markets.dart';
import '../data/local/dao/candle_dao.dart';
import '../data/local/dao/fno_contract_dao.dart';
import '../data/local/dao/scan_cache_dao.dart';
import '../data/remote/api_client.dart';
import '../data/remote/dto/candle.dart';
import '../data/remote/dto/quote.dart';
import '../data/remote/dto/scrip.dart';
import '../features/fno/study/black_scholes.dart';
import '../features/fno/study/strangle.dart';
import '../features/fno/study/study_engine.dart';
import 'candle_source.dart';
import 'daily_bars_loader.dart';
import 'study_market_data.dart';

/// Which phase is running — shown on the progress line.
enum StudyStage {
  candles('Candles'),
  quotes('Option quotes'),
  greeks('IV (option chain)'),
  scoring('Scoring');

  const StudyStage(this.label);
  final String label;
}

/// Live picture of a study run, pushed to the UI after every unit of work.
class FnoStudyProgress {
  final StudyStage stage;

  /// Progress *inside* the current stage.
  final int done;
  final int total;

  /// Instrument being worked on (`RELIANCE`) — empty for batched stages.
  final String current;

  /// Overall 0 → 1 (the stages are weighted).
  final double fraction;

  /// Time this run has been going. Together with [fraction] this gives an ETA
  /// that stays honest when the candle phase is served from cache (a warm scan
  /// is ~5× faster than a cold one, and a fixed estimate would lie).
  final Duration elapsed;

  final int withOptions;
  final int skipped;

  const FnoStudyProgress({
    required this.stage,
    required this.done,
    required this.total,
    required this.fraction,
    this.elapsed = Duration.zero,
    this.current = '',
    this.withOptions = 0,
    this.skipped = 0,
  });

  /// `Candles 42/120 · RELIANCE`
  String get label {
    // A phase with nothing to count (IV solved on-device: zero greek calls)
    // must not read "0/0" — the counter is simply not the story there.
    if (total <= 0) {
      return current.isEmpty ? stage.label : '${stage.label} · $current';
    }
    final base = '${stage.label} $done/$total';
    return current.isEmpty ? base : '$base · $current';
  }

  /// Time left, extrapolated from what the run has actually done so far:
  /// `elapsed × (1 − fraction) / fraction`. A cached-candle scan corrects
  /// itself within a second or two instead of promising a cold-scan duration.
  Duration get eta {
    if (fraction <= 0.02 || elapsed.inMilliseconds < 800) return Duration.zero;
    final remaining = (1 - fraction).clamp(0.0, 1.0);
    final rate = elapsed.inMilliseconds / fraction;
    return Duration(milliseconds: (rate * remaining).round());
  }
}

/// Marker used in [StudySkip.symbol] for run-level notes (option quotes that
/// failed, IV that could not be solved) rather than a single stock.
const String kOptionsNotice = '— options —';

/// One instrument the study could not use, with the reason.
class StudySkip {
  final String symbol;
  final String reason;

  const StudySkip({required this.symbol, required this.reason});
}

/// Outcome of one study run (or of the last cached one, rehydrated).
class FnoStudyResult {
  final DateTime asOf;
  final DateTime runAt;
  final Duration duration;
  final int universeSize;
  final int scanned;
  final int withOptions;
  final int ivFromBroker;
  final int ivFromBlackScholes;
  final bool cancelled;
  final bool fromCacheOnly;

  /// Stock-option expiry explicitly selected for this scan, if any.
  final DateTime? selectedExpiry;

  final List<StudyRow> rows;
  final List<StudySkip> skips;

  /// The same stocks scored under a *second* rule set (`compareWith`), keyed by
  /// symbol — how "3 Month Study with Advance Filter" shows the classic score
  /// next to the corrected one. Empty unless it was asked for, so the classic
  /// page's result is exactly what it has always been.
  final Map<String, StudyRow> compareRows;

  const FnoStudyResult({
    required this.asOf,
    required this.runAt,
    required this.rows,
    this.duration = Duration.zero,
    this.universeSize = 0,
    this.scanned = 0,
    this.withOptions = 0,
    this.ivFromBroker = 0,
    this.ivFromBlackScholes = 0,
    this.cancelled = false,
    this.fromCacheOnly = false,
    this.selectedExpiry,
    this.skips = const [],
    this.compareRows = const {},
  });

  /// Rows whose option enrichment failed (degraded mode) — still in the table.
  int get degraded => rows.where((r) => r.avgIv == null).length;

  int get bestBuyCount => rows.where((r) => r.isBestBuy).length;

  List<StudyRow> get bestBuys => [
    for (final row in rows)
      if (row.isBestBuy) row,
  ];

  /// `Stocks 60 · 7 best-buy · 4 degraded · 18/Jan/2026`
  String get summary {
    final suffix = cancelled ? ' (rok diya)' : '';
    if (fromCacheOnly) {
      return '${rows.length} stocks (cached) · $bestBuyCount best-buy';
    }
    return '${rows.length} stocks, $bestBuyCount best-buy opportunities$suffix';
  }

  bool isStaleFor(DateTime day) =>
      DateTime(asOf.year, asOf.month, asOf.day) !=
      DateTime(day.year, day.month, day.day);
}

/// Same calendar day? (candles carry a timestamp, the study an as-of date)
bool _sameDay(DateTime a, DateTime b) =>
    a.year == b.year && a.month == b.month && a.day == b.day;

/// One stock in flight between the phases.
class _Pending {
  final Scrip scrip;
  final List<Candle> candles;

  /// ATM pair for **today's** price — what the "5 · ATM option" section buys.
  final AtmPair? pair;

  /// ATM pair for the **previous session's close** — the jodi the "agar kal
  /// jodi buy ki hoti" line is about. Same expiry, possibly a different strike.
  final AtmPair? kalPair;

  _Pending(this.scrip, this.candles, this.pair, this.kalPair);
}

/// One row's strangle plan: which contracts to quote, and what they were aimed
/// at (so the UI can print the rule, not just the numbers).
class _StranglePlan {
  const _StranglePlan({
    required this.index,
    required this.today,
    required this.todayTarget,
    required this.kal,
    required this.kalTarget,
  });

  final int index;
  final StranglePick? today;
  final double todayTarget;
  final StranglePick? kal;
  final double kalTarget;
}

class FnoStudyService {
  FnoStudyService({
    required CandleSource source,
    required CandleDao candles,
    required ScanCacheDao cache,
    required FnoContractDao contracts,
    required StudyMarketData marketData,
    DateTime Function()? clock,
  }) : _source = source,
       _candles = candles,
       _cache = cache,
       _contracts = contracts,
       _market = marketData,
       _clock = clock ?? DateTime.now;

  final CandleSource _source;
  final CandleDao _candles;
  final ScanCacheDao _cache;
  final FnoContractDao _contracts;
  final StudyMarketData _market;
  final DateTime Function() _clock;

  /// `scan_runs.kind` for this screener.
  static const String cacheKind = ScanKind.fnoStudy;

  /// `maxStocks: 0` (the default) means **no cap** — every stock that resolved
  /// in the F&O universe is scanned. There is deliberately no setting for this:
  /// a study that silently skips half the universe is worse than a slow one.
  /// A positive value is honoured for tests and for a future "top N" tool.
  static const int noLimit = 0;

  /// Stage weights for the progress bar — the middle two are the network ones.
  static const double _wCandles = 0.55;
  static const double _wQuotes = 0.15;
  static const double _wGreeks = 0.25;

  /// How old cached candles may get before a scan sweeps them.
  static const int retentionDays = 700;

  // -------------------------------------------------------------------------
  // Cached snapshot
  // -------------------------------------------------------------------------

  /// The last run, so opening the tab never forces a fresh scan (spec §3.1.1).
  Future<FnoStudyResult?> loadCached() async {
    final run = await _cache.latestRun(cacheKind);
    if (run == null) return null;
    final rows = _rowsFromPayload(run.rows);
    final rawMeta = run.rows.isNotEmpty ? run.rows.first['meta'] : null;
    final metadata = rawMeta is Map ? rawMeta : const <String, dynamic>{};
    var selectedExpiry = DateTime.tryParse(
      '${metadata['selectedExpiry'] ?? ''}',
    );
    if (selectedExpiry == null) {
      // Older snapshots did not keep explicit scan metadata. Use a row's
      // actual contract expiry when one exists; never guess from today's date.
      for (final row in rows) {
        if (row.expiryDate != null) {
          selectedExpiry = row.expiryDate;
          break;
        }
      }
    }
    return FnoStudyResult(
      asOf: DateTime.tryParse(run.asOf) ?? _clock(),
      runAt: run.createdAt,
      rows: rows,
      selectedExpiry: selectedExpiry,
      fromCacheOnly: true,
    );
  }

  Future<void> clearCache() => _cache.clearRuns(cacheKind);

  /// Cached daily bars for one scrip — offline. The scan already downloaded
  /// them; the AI Jodi Study chart reads this and never fetches live. An
  /// empty list honestly means "bars cache me nahi" (purana snapshot).
  Future<List<Candle>> cachedBars(Scrip scrip, {DateTime? from}) async {
    try {
      return await _candles.barsFor(
        exchange: scrip.exchange.code,
        symbol: scrip.symbol,
        from: from,
      );
    } catch (_) {
      return const <Candle>[];
    }
  }

  /// The three nearest NFO stock-option expiry dates currently in the book.
  Future<List<DateTime>> upcomingStockExpiries({DateTime? from}) => _contracts
      .upcomingStockExpiries(from: from ?? MarketCalendar.nowIst(), limit: 3);

  /// How many option contracts the local book holds. Zero means the master has
  /// never been refreshed by this version — which is also why a scan would come
  /// back degraded.
  Future<int> contractCount() => _contracts.count();

  /// How many underlyings the book knows about (a healthy book covers the whole
  /// F&O list).
  Future<int> contractUnderlyingCount() => _contracts.underlyingCount();

  static List<StudyRow> _rowsFromPayload(List<Map<String, dynamic>> payload) {
    if (payload.length == 1 && payload.first['rows'] is List) {
      final rows = <StudyRow>[];
      for (final row in payload.first['rows'] as List) {
        if (row is! Map) continue;
        try {
          rows.add(StudyRow.fromJson(row.cast<String, dynamic>()));
        } catch (_) {
          // A row written by an older build must not blank the whole table.
        }
      }
      return rows;
    }
    // Plain list (future/legacy shape).
    final rows = <StudyRow>[];
    for (final row in payload) {
      try {
        rows.add(StudyRow.fromJson(row));
      } catch (_) {}
    }
    return rows;
  }

  // -------------------------------------------------------------------------
  // The run
  // -------------------------------------------------------------------------

  /// Scans [universe] (the resolved F&O underlyings) and returns the ranked study.
  Future<FnoStudyResult> run({
    required List<Scrip> universe,
    Map<String, String> companyNames = const {},
    int maxStocks = noLimit,
    DateTime? asOf,

    /// Exact stock-option expiry selected in the 3-Month Study UI. Null keeps
    /// the service's legacy nearest-expiry behavior for existing callers.
    DateTime? selectedExpiry,
    void Function(FnoStudyProgress progress)? onProgress,
    bool Function()? isCancelled,

    /// Which scoring rules the returned [FnoStudyResult.rows] use. Defaults to
    /// the classic study's own rules, so an unchanged caller gets unchanged
    /// numbers (the AI Suggestion gate depends on that).
    StudyRules rules = StudyRules.classic,

    /// Score every stock a second time under these rules and hand them back in
    /// [FnoStudyResult.compareRows]. Costs no extra network — the candles,
    /// quotes and IV are already in hand.
    StudyRules? compareWith,

    /// Only a classic run overwrites the classic page's saved snapshot; an
    /// advance-filter run must never clobber it.
    bool persist = true,

    /// Where IV may come from (B1). [StudyIvSource.blackScholes] skips Phase 3
    /// altogether — zero greek requests, zero rate-limit pressure;
    /// [StudyIvSource.broker] takes the broker's number or nothing at all.
    StudyIvSource ivSource = StudyIvSource.auto,
  }) async {
    final started = _clock();
    final day = DateTime(
      (asOf ?? MarketCalendar.latestTradingDay()).year,
      (asOf ?? MarketCalendar.latestTradingDay()).month,
      (asOf ?? MarketCalendar.latestTradingDay()).day,
    );

    final instruments = (maxStocks > 0 && universe.length > maxStocks)
        ? universe.sublist(0, maxStocks)
        : universe;
    final loader = DailyBarsLoader(
      source: _source,
      candles: _candles,
      minimumBars: kStudyMinimumBars,
      lookbackDays: 400,
    );

    final skips = <StudySkip>[];
    final pending = <_Pending>[];
    var cancelled = false;

    // ---- Phase 1: candles + ATM strike (local book) ----------------------
    for (var i = 0; i < instruments.length; i++) {
      if (isCancelled?.call() ?? false) {
        cancelled = true;
        break;
      }
      final scrip = instruments[i];
      final plain = Scrip.plainSymbol(scrip.symbol);

      try {
        // One retry before a stock is given up on: a transient rate-limit or a
        // dropped connection must not silently shrink the study (the ask was
        // "all F&O stocks", not "most of them").
        List<Candle> bars;
        try {
          bars = (await loader.barsFor(scrip, day)).bars;
        } on ApiException catch (e) {
          if (e.isAuthError) rethrow;
          await Future<void>.delayed(const Duration(milliseconds: 1500));
          bars = (await loader.barsFor(scrip, day)).bars;
        }
        if (bars.length < kStudyMinimumBars) {
          skips.add(
            StudySkip(
              symbol: plain,
              reason: bars.isEmpty
                  ? 'Daily candles nahi mile (suspended/delisted ya broker ne '
                        'kuch nahi diya).'
                  : 'Sirf ${bars.length} daily bars hain — study ke liye '
                        '$kStudyMinimumBars chahiye.',
            ),
          );
        } else {
          final spot = bars.last.close;
          // Which bar is "kal"? When the newest bar is today's (a live or
          // cached intraday candle) the session before it is yesterday; when
          // the data simply ends earlier (pre-market, holiday), the newest bar
          // *is* the last completed session.
          final lastBar = bars.last;
          final dayBefore = bars.length >= 2 ? bars[bars.length - 2] : lastBar;
          final kalBar = _sameDay(lastBar.time, day) ? dayBefore : lastBar;

          AtmPair? pair;
          AtmPair? kalPair;
          try {
            pair = await _contracts.atmPair(
              underlying: plain,
              spot: spot,
              asOf: day,
              selectedExpiry: selectedExpiry,
            );
            // Same selected expiry; only the ATM strike uses kal ka close.
            kalPair = await _contracts.atmPair(
              underlying: plain,
              spot: kalBar.close,
              asOf: day,
              selectedExpiry: selectedExpiry,
            );
          } catch (_) {
            pair = null; // degraded: no ATM strike, everything else stands
            kalPair = null;
          }
          pending.add(_Pending(scrip, bars, pair, kalPair));
        }
      } on ApiException catch (e) {
        skips.add(StudySkip(symbol: plain, reason: e.message));
      } catch (e) {
        skips.add(StudySkip(symbol: plain, reason: '$e'));
      }

      onProgress?.call(
        FnoStudyProgress(
          stage: StudyStage.candles,
          done: i + 1,
          total: instruments.length,
          current: plain,
          fraction: _wCandles * ((i + 1) / math.max(instruments.length, 1)),
          elapsed: _clock().difference(started),
          withOptions: pending.where((p) => p.pair != null).length,
          skipped: skips.length,
        ),
      );
    }

    // ---- Phase 2: one batched quote call per 50 option tokens ------------
    final quoted = <String, MarketQuote>{};
    // Today's ATM legs **and** kal wale ATM legs. Deduped by token, so a stock
    // whose strike did not move still costs the broker exactly two tokens.
    final legScrips = <Scrip>[];
    final seenTokens = <String>{};
    for (final item in pending) {
      for (final pair in [item.pair, item.kalPair]) {
        if (pair == null) continue;
        for (final leg in _legScrips(pair)) {
          if (seenTokens.add(leg.token)) legScrips.add(leg);
        }
      }
    }

    if (legScrips.isNotEmpty && !cancelled) {
      final chunks = (legScrips.length / StudyMarketData.maxTokensPerCall)
          .ceil();
      for (var i = 0; i < chunks; i++) {
        if (isCancelled?.call() ?? false) {
          cancelled = true;
          break;
        }
        final slice = legScrips.sublist(
          i * StudyMarketData.maxTokensPerCall,
          math.min(
            (i + 1) * StudyMarketData.maxTokensPerCall,
            legScrips.length,
          ),
        );
        try {
          quoted.addAll(await _market.fetchQuotesFull(slice));
        } on ApiException catch (e) {
          // Quotes failing is a degradation, not a failure: scores, trends and
          // the "agar kal jodi" line simply stay blank for those stocks. The
          // reason is recorded so the study can say *why* instead of looking
          // broken.
          skips.add(
            StudySkip(
              symbol: kOptionsNotice,
              reason:
                  'Option premium quote fail hua (${e.message}). Is run me '
                  'options wale column khaali rahenge (degraded mode) — trend, '
                  'ATR aur levels theek hain.',
            ),
          );
        } catch (e) {
          skips.add(
            StudySkip(
              symbol: kOptionsNotice,
              reason: 'Option premium quote fail hua ($e) — degraded mode.',
            ),
          );
        }

        onProgress?.call(
          FnoStudyProgress(
            stage: StudyStage.quotes,
            done: i + 1,
            total: chunks,
            fraction: _wCandles + _wQuotes * ((i + 1) / math.max(chunks, 1)),
            elapsed: _clock().difference(started),
            withOptions: pending.where((p) => p.pair != null).length,
            skipped: skips.length,
          ),
        );
      }
    }

    // ---- Phase 3: broker IV, one call per stock --------------------------
    //
    // Skipped whole when the setting says "apna hisaab": the premium is
    // already in hand from Phase 2, so Phase 4 can solve every IV without a
    // single extra request. This is the switch that turns ~213 requests into
    // zero, and it is why the setting exists (F7).
    final ivByStock = <String, OptionGreekBatch>{};
    final withPair = [
      for (final item in pending)
        if (item.pair != null) item,
    ];
    final useBrokerIv = ivSource != StudyIvSource.blackScholes;

    if (!useBrokerIv) {
      // The greeks slice of the bar is not "pending" — there is nothing to
      // wait for, so it is marked done rather than left hanging at 80 %.
      onProgress?.call(
        FnoStudyProgress(
          stage: StudyStage.greeks,
          done: 0,
          total: 0,
          current: 'IV apne hisaab se (koi broker call nahi)',
          fraction: _wCandles + _wQuotes + _wGreeks,
          elapsed: _clock().difference(started),
          withOptions: withPair.length,
          skipped: skips.length,
        ),
      );
    }

    for (var i = 0; useBrokerIv && i < withPair.length; i++) {
      if (isCancelled?.call() ?? false) {
        cancelled = true;
        break;
      }
      final item = withPair[i];
      final pair = item.pair!;
      try {
        ivByStock[Scrip.plainSymbol(item.scrip.symbol)] = await _market
            .fetchOptionGreeks(
              underlying: pair.underlying,
              expiryLabel: pair.expiryLabel,
            );
      } on ApiException catch (_) {
        // Auth errors already surfaced in phase 1; treat as "no IV" here.
      } catch (_) {
        // Same: the Black-Scholes fallback below covers it.
      }

      onProgress?.call(
        FnoStudyProgress(
          stage: StudyStage.greeks,
          done: i + 1,
          total: withPair.length,
          current: Scrip.plainSymbol(item.scrip.symbol),
          fraction:
              _wCandles +
              _wQuotes +
              _wGreeks * ((i + 1) / math.max(withPair.length, 1)),
          elapsed: _clock().difference(started),
          withOptions: withPair.length,
          skipped: skips.length,
        ),
      );
    }

    // ---- Phase 4: fallback IV, rows, ranking ----------------------------
    onProgress?.call(
      FnoStudyProgress(
        stage: StudyStage.scoring,
        done: 0,
        total: 1,
        fraction: 0.98,
        elapsed: _clock().difference(started),
        withOptions: withPair.length,
        skipped: skips.length,
      ),
    );

    final built = <StudyRow>[];
    final compareRows = <String, StudyRow>{};
    var ivFromBroker = 0;
    var ivFromBlackScholes = 0;

    // "Sirf broker": solve nothing ourselves. A row the broker cannot price
    // simply carries no IV — an invented number is worse than a blank one.
    final allowBlackScholes = ivSource != StudyIvSource.broker;

    for (final item in pending) {
      final plain = Scrip.plainSymbol(item.scrip.symbol);
      StudyOptionInput? input;
      StudyOptionInput? kalInput;

      if (item.pair != null) {
        final pair = item.pair!;
        final greeks = ivByStock[plain];
        final spot = item.candles.last.close;
        final days = pair.expiryDate
            .difference(DateTime(day.year, day.month, day.day))
            .inDays;

        final enriched = <String, StudyOptionLeg>{};
        for (final contract in [pair.ce, pair.pe]) {
          if (contract == null) continue;
          final quote = quoted[contract.token];

          // IV "must be meaningless on expiry day" (spec §2.6) → skip solving.
          double? iv = greeks?.ivFor(pair.strike, contract.optionType);
          var source = iv != null ? IvSource.broker : IvSource.none;
          IvFailure? failure;

          if (iv == null &&
              allowBlackScholes &&
              days > 0 &&
              quote != null &&
              quote.ltp > 0) {
            final solved = impliedVolatility(
              type: contract.isCall ? OptionType.call : OptionType.put,
              premium: quote.ltp,
              spot: spot,
              strike: pair.strike,
              daysToExpiry: days,
            );
            if (solved.isSolved) {
              iv = solved.iv! * 100; // store as percent
              source = IvSource.blackScholes;
            } else {
              failure = solved.failure;
            }
          } else if (iv == null && days <= 0) {
            failure = IvFailure.badInput; // expiry day: IV is meaningless
          } else if (iv == null) {
            // Broker-only mode, and the broker had nothing for this leg. The
            // row keeps its trend/ATR/score and says its IV is missing — the
            // same degraded path a failed greeks call already takes.
            source = IvSource.none;
          }

          if (source == IvSource.broker) ivFromBroker++;
          if (source == IvSource.blackScholes) ivFromBlackScholes++;

          enriched[contract.optionType] = StudyOptionLeg(
            strike: pair.strike,
            type: contract.isCall ? OptionType.call : OptionType.put,
            token: contract.token,
            symbol: contract.symbol,
            ltp: quote?.ltp,
            previousClose: quote?.previousClose,
            iv: iv,
            ivSource: source,
            ivFailure: failure,
          );
        }

        input = StudyOptionInput(
          strike: pair.strike,
          expiryLabel: pair.expiryLabel,
          expiryDate: pair.expiryDate,
          lotSize: pair.lotSize,
          ce: enriched['CE'],
          pe: enriched['PE'],
        );
      }

      // "Kal" ka pair: same expiry, strike picked from the previous session's
      // close. Its legs only need `ltp` (aaj ka premium) and `previousClose`
      // (kal ka premium = the buy cost) — IV is not asked for them, because the
      // yesterday line is a P&L observation, not an IV opinion. When the stock
      // did not move, both pairs are the same strike → reuse today's legs.
      final kalPair = item.kalPair;
      if (kalPair != null) {
        if (input != null && kalPair.strike == input.strike) {
          kalInput = input;
        } else {
          final kalLegs = <String, StudyOptionLeg>{};
          for (final contract in [kalPair.ce, kalPair.pe]) {
            if (contract == null) continue;
            final quote = quoted[contract.token];
            kalLegs[contract.optionType] = StudyOptionLeg(
              strike: kalPair.strike,
              type: contract.isCall ? OptionType.call : OptionType.put,
              token: contract.token,
              symbol: contract.symbol,
              ltp: quote?.ltp,
              previousClose: quote?.previousClose,
            );
          }
          kalInput = StudyOptionInput(
            strike: kalPair.strike,
            expiryLabel: kalPair.expiryLabel,
            expiryDate: kalPair.expiryDate,
            lotSize: kalPair.lotSize,
            ce: kalLegs['CE'],
            pe: kalLegs['PE'],
          );
        }
      }

      final row = computeStudy(
        scrip: item.scrip,
        candles: item.candles,
        asOf: day,
        options: input,
        yesterdayOptions: kalInput,
        companyName: companyNames[plain],
        underlying: plain,
        rules: rules,
      );
      if (row == null) {
        skips.add(
          StudySkip(
            symbol: plain,
            reason: 'Study compute nahi hui (data kam tha).',
          ),
        );
      } else {
        built.add(row);
        if (compareWith != null) {
          final other = computeStudy(
            scrip: item.scrip,
            candles: item.candles,
            asOf: day,
            options: input,
            yesterdayOptions: kalInput,
            companyName: companyNames[plain],
            underlying: plain,
            rules: compareWith,
          );
          if (other != null) compareRows[plain] = other;
        }
      }
    }

    // ---- Phase 4.5: the OTM jodi (strangle) ------------------------------
    await _attachStrangles(
      built,
      started: started,
      withOptions: withPair.length,
      skipped: skips.length,
      onProgress: onProgress,
      isCancelled: isCancelled,
    );

    final ranked = rankStudy(built, rules: rules);
    // The comparison rows only need the universe-wide pass (IV rank + tag) of
    // their own rule set — the display order is always the [rules] rows'.
    final compared = <String, StudyRow>{};
    if (compareRows.isNotEmpty) {
      final other = rankStudy(
        compareRows.values.toList(),
        rules: compareWith ?? StudyRules.classic,
      );
      for (final row in other) {
        compared[row.symbol] = row;
      }
    }

    final result = FnoStudyResult(
      asOf: day,
      runAt: started,
      duration: _clock().difference(started),
      universeSize: instruments.length,
      scanned: pending.length,
      withOptions: withPair.length,
      ivFromBroker: ivFromBroker,
      ivFromBlackScholes: ivFromBlackScholes,
      cancelled: cancelled,
      selectedExpiry: selectedExpiry,
      rows: ranked,
      skips: skips,
      compareRows: compared,
    );

    // Only a classic run is the classic page's snapshot.
    if (persist && rules.name == StudyRules.classic.name) {
      await _persist(result);
    }

    try {
      await _candles.prune(
        before: day.subtract(const Duration(days: retentionDays)),
      );
    } catch (_) {
      // Best effort; never fail a good scan over housekeeping.
    }
    try {
      await _contracts.pruneExpired(before: day);
    } catch (_) {}

    return result;
  }

  /// Fills in the OTM jodi (strangle) for every row that can carry one.
  ///
  /// Deliberately cheap on the network: candidate pairs are priced with
  /// Black-Scholes off the row's own IV **only to rank them**, and just the
  /// winning pair is quoted (see `strangle.dart`). So this costs one batched
  /// quote call per 50 tokens — not one per candidate strike.
  ///
  /// Degradation is the whole policy here: a row the chain or the quotes cannot
  /// serve keeps `null`, the panel says the OTM jodi is not available, and the
  /// scan never fails over it.
  Future<void> _attachStrangles(
    List<StudyRow> rows, {
    required DateTime started,
    required int withOptions,
    required int skipped,
    void Function(FnoStudyProgress)? onProgress,
    bool Function()? isCancelled,
  }) async {
    final plans = <_StranglePlan>[];
    final wanted = <Scrip>[];
    final seen = <String>{};

    for (var i = 0; i < rows.length; i++) {
      if (isCancelled?.call() ?? false) return;
      final row = rows[i];

      final iv = row.avgIv;
      final days = row.daysToExpiry;
      final expiry = row.expiryDate;
      // The rule is "ATM jodi ka aadha" — so we need what the ATM jodi costs.
      final atmTotal = row.straddleLtp;
      if (iv == null || iv <= 0) continue;
      if (days == null || days <= 0) continue; // expiry day: nothing to price
      if (expiry == null || atmTotal == null || atmTotal <= 0) continue;

      final List<FnoContract> chain;
      try {
        chain = await _contracts.chainOn(row.underlying, expiry);
      } catch (_) {
        continue; // no chain for this stock → no OTM jodi, nothing else changes
      }
      if (chain.isEmpty) continue;

      final today = pickStrangle(
        chain: chain,
        spot: row.ltp,
        ivPercent: iv,
        daysToExpiry: days,
        targetPremium: atmTotal / 2,
      );

      // "Kal" wala pair: the strikes that were OTM at the previous session's
      // close, aimed at half of what the ATM jodi cost *then*.
      final kalSpot = row.kalStrike ?? row.atmStrike;
      final kalAtmCost = row.kalJodiBuyCost;
      final kal = (kalSpot != null && kalAtmCost != null && kalAtmCost > 0)
          ? pickStrangle(
              chain: chain,
              spot: kalSpot,
              ivPercent: iv,
              daysToExpiry: days,
              targetPremium: kalAtmCost / 2,
            )
          : null;

      if (today == null && kal == null) continue;

      plans.add(
        _StranglePlan(
          index: i,
          today: today,
          todayTarget: atmTotal / 2,
          kal: kal,
          kalTarget: (kalAtmCost ?? 0) / 2,
        ),
      );
      for (final contract in [today?.ce, today?.pe, kal?.ce, kal?.pe]) {
        if (contract == null) continue;
        if (!seen.add(contract.token)) continue;
        wanted.add(contract.asScrip());
      }

      if (i % 25 == 0) {
        onProgress?.call(
          FnoStudyProgress(
            stage: StudyStage.scoring,
            done: i + 1,
            total: rows.length,
            current: row.symbol,
            fraction: 0.985,
            elapsed: _clock().difference(started),
            withOptions: withOptions,
            skipped: skipped,
          ),
        );
      }
    }

    if (wanted.isEmpty) return;

    final quoted = <String, MarketQuote>{};
    final chunks = (wanted.length / StudyMarketData.maxTokensPerCall).ceil();
    for (var i = 0; i < chunks; i++) {
      if (isCancelled?.call() ?? false) return;
      final slice = wanted.sublist(
        i * StudyMarketData.maxTokensPerCall,
        math.min((i + 1) * StudyMarketData.maxTokensPerCall, wanted.length),
      );
      try {
        quoted.addAll(await _market.fetchQuotesFull(slice));
      } on ApiException catch (_) {
        // Quotes for the OTM jodi failing costs that one line, never the study.
        return;
      } catch (_) {
        return;
      }
    }

    for (final plan in plans) {
      rows[plan.index] = rows[plan.index].copyWith(
        strangle: _strangleOf(plan.today, quoted, plan.todayTarget),
        kalStrangle: _strangleOf(plan.kal, quoted, plan.kalTarget),
      );
    }
  }

  /// Builds one [StudyStrangle] from the picked contracts and their quotes.
  StudyStrangle? _strangleOf(
    StranglePick? pick,
    Map<String, MarketQuote> quoted,
    double target,
  ) {
    if (pick == null) return null;
    return StudyStrangle(
      ce: _legOf(pick.ce, quoted),
      pe: _legOf(pick.pe, quoted),
      targetPremium: target,
    );
  }

  StudyOptionLeg _legOf(FnoContract contract, Map<String, MarketQuote> quoted) {
    final quote = quoted[contract.token];
    return StudyOptionLeg(
      strike: contract.strike,
      type: contract.isCall ? OptionType.call : OptionType.put,
      token: contract.token,
      symbol: contract.symbol,
      ltp: quote?.ltp,
      previousClose: quote?.previousClose,
    );
  }

  static List<Scrip> _legScrips(AtmPair pair) => [
    if (pair.ce != null) pair.ce!.asScrip(),
    if (pair.pe != null) pair.pe!.asScrip(),
  ];

  Future<void> _persist(FnoStudyResult result) async {
    if (result.cancelled && result.rows.isEmpty) return;
    await _cache.saveRun(
      kind: cacheKind,
      asOf: _isoDate(result.asOf),
      rows: [
        {
          'meta': {
            'universeSize': result.universeSize,
            'scanned': result.scanned,
            'withOptions': result.withOptions,
            'ivFromBroker': result.ivFromBroker,
            'ivFromBlackScholes': result.ivFromBlackScholes,
            'cancelled': result.cancelled,
            'selectedExpiry': result.selectedExpiry == null
                ? null
                : _isoDate(result.selectedExpiry!),
          },
          'rows': [for (final row in result.rows) row.toJson()],
        },
      ],
    );
  }

  static String _isoDate(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-'
      '${d.month.toString().padLeft(2, '0')}-'
      '${d.day.toString().padLeft(2, '0')}';
}
