// ---------------------------------------------------------------------------
// secure_store.dart — credentials & session tokens at rest.
//
// SmartAPI credentials (API key, MPIN/password, TOTP secret) and the daily JWT
// are secrets: they live in the platform keystore (Keychain on iOS, Encrypted
// SharedPreferences / Keystore on Android) via flutter_secure_storage, never in
// SQLite and never in plain SharedPreferences.
// ---------------------------------------------------------------------------

import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../data/remote/dto/session.dart';

class SecureStore {
  SecureStore({FlutterSecureStorage? storage})
      : _storage = storage ??
            const FlutterSecureStorage(
              // flutter_secure_storage 10+ always encrypts on Android
              // (AES-GCM via the Keystore); `resetOnError` makes the app
              // self-heal if the device key is invalidated instead of throwing
              // on every read.
              aOptions: AndroidOptions(resetOnError: true),
              iOptions: IOSOptions(
                accessibility: KeychainAccessibility.first_unlock,
              ),
            );

  final FlutterSecureStorage _storage;

  static const String _kCredentials = 'angel_credentials_v1';
  static const String _kSession = 'angel_session_v1';

  Future<AngelCredentials?> readCredentials() async {
    final raw = await _storage.read(key: _kCredentials);
    if (raw == null || raw.isEmpty) return null;
    try {
      final json = jsonDecode(raw);
      return json is Map<String, dynamic>
          ? AngelCredentials.fromJson(json)
          : null;
    } catch (_) {
      return null;
    }
  }

  Future<void> writeCredentials(AngelCredentials credentials) =>
      _storage.write(key: _kCredentials, value: jsonEncode(credentials.toJson()));

  Future<AngelSession?> readSession() async {
    final raw = await _storage.read(key: _kSession);
    if (raw == null || raw.isEmpty) return null;
    try {
      final json = jsonDecode(raw);
      return json is Map<String, dynamic> ? AngelSession.fromJson(json) : null;
    } catch (_) {
      return null;
    }
  }

  Future<void> writeSession(AngelSession session) =>
      _storage.write(key: _kSession, value: jsonEncode(session.toJson()));

  Future<void> clearSession() => _storage.delete(key: _kSession);

  Future<void> clearAll() async {
    await _storage.delete(key: _kSession);
    await _storage.delete(key: _kCredentials);
  }
}
