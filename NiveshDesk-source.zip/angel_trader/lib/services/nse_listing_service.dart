// ---------------------------------------------------------------------------
// nse_listing_service.dart — the official NSE equity master, used as the
// "what listed recently?" index for automatic IPO discovery.
//
// `EQUITY_L.csv` (archives.nseindia.com) is a plain, unauthenticated CSV:
//
//     SYMBOL, NAME OF COMPANY, SERIES, DATE OF LISTING, ISIN NUMBER, …
//
// Two things make it exactly the right source for this job:
//
//   • `DATE OF LISTING` is the *official* listing date, decided by the exchange
//     rather than guessed from price history.
//   • It needs no login, so discovery still works on a day the broker session
//     has expired.
//
// Two things to be careful about (both handled here):
//
//   • The headers carry leading spaces → keys and values are trimmed.
//   • `DATE OF LISTING` is also stamped when a company *migrates* to NSE from
//     BSE, so a recent date does not prove an IPO. The discovery service treats
//     these rows as candidates and confirms them against broker data (a new
//     IPO's price history simply does not exist before its listing date).
//
// The parsed list is cached in the settings table for [cacheValidity] so a phone
// download the file at most once a day — and only keeps rows from the last
// [lookback] so the cached JSON stays small (a few hundred rows, not 2,600).
// ---------------------------------------------------------------------------

import 'dart:convert';

import 'package:http/http.dart' as http;

import '../core/utils/formatters.dart';
import '../data/local/dao/settings_dao.dart';

/// One row of the NSE equity master (only the columns this feature needs).
class NseListing {
  const NseListing({
    required this.symbol,
    required this.companyName,
    required this.series,
    required this.listingDate,
    this.isin = '',
    this.faceValue,
  });

  /// Plain ticker, e.g. `SWIGGY`.
  final String symbol;

  final String companyName;

  /// NSE series: `EQ` (normal), `BE` (trade-for-trade), `SM` (SME platform)…
  final String series;

  final DateTime listingDate;

  /// The security's ISIN — the stable identity behind a ticker that can be
  /// renamed. Blank when the master row had none.
  final String isin;

  /// Official per-share face value (₹) from the listing master's
  /// `FACE VALUE` (or `PAID UP VALUE`) column. Null when the master row has
  /// none — market cap then falls back to the filing's own facts.
  final double? faceValue;

  /// Mainboard cash-market series. `SM`/`ST` are the SME platform, which this
  /// app deliberately does not screen.
  bool get isMainboard => series == 'EQ' || series == 'BE';

  bool get isSme => series == 'SM' || series == 'ST';

  Map<String, dynamic> toJson() => {
    's': symbol,
    'n': companyName,
    'e': series,
    'd': listingDate.toIso8601String(),
    'i': isin,
    if (faceValue != null) 'f': faceValue,
  };

  factory NseListing.fromJson(Map<String, dynamic> json) => NseListing(
    symbol: '${json['s']}',
    companyName: '${json['n']}',
    series: '${json['e']}',
    listingDate: DateTime.parse('${json['d']}'),
    isin: '${json['i'] ?? ''}',
    faceValue: (json['f'] as num?)?.toDouble(),
  );

  @override
  String toString() => 'NseListing($symbol, $series, $listingDate)';
}

/// Thrown when the master cannot be downloaded or parsed at all.
class NseListingException implements Exception {
  NseListingException(this.message);

  final String message;

  @override
  String toString() => 'NseListingException: $message';
}

class NseListingService {
  NseListingService({
    required SettingsDao settings,
    http.Client? client,
    this.cacheValidity = const Duration(hours: 24),
    this.lookback = const Duration(days: 720),
  }) : _settings = settings,
       _client = client;

  /// Unauthenticated, official, archived by NSE since 2014.
  static const String url =
      'https://archives.nseindia.com/content/equities/EQUITY_L.csv';

  /// Settings keys for the cached copy.
  static const String cacheKey = 'nse_listings_cache';
  static const String cachedAtKey = 'nse_listings_at';

  final SettingsDao _settings;
  final http.Client? _client;

  /// How long a cached copy is reused.
  final Duration cacheValidity;

  /// How far back rows are kept (the discovery service only ever asks for
  /// very recent ones; older rows only bloat the settings row).
  final Duration lookback;

  List<NseListing>? _memo;
  DateTime? _memoAt;

  /// The most recent listing date the master knows about (for diagnostics/UI).
  Future<DateTime?> freshestListingDate() async {
    final all = await _all();
    if (all.isEmpty) return null;
    var newest = all.first.listingDate;
    for (final l in all) {
      if (l.listingDate.isAfter(newest)) newest = l.listingDate;
    }
    return newest;
  }

  /// Listings from roughly the last [lookback], newest first.
  ///
  /// [force] = true skips the cache (used by the manual "check for new IPOs"
  /// action, so a user tap never shows day-old data).
  Future<List<NseListing>> listings({bool force = false}) async {
    final all = await _all(force: force);
    final cutoff = DateTime.now().subtract(lookback);
    final recent = [
      for (final listing in all)
        if (listing.listingDate.isAfter(cutoff)) listing,
    ];
    recent.sort((a, b) => b.listingDate.compareTo(a.listingDate));
    return recent;
  }

  /// Every official NSE cash listing in the master. Public for Equity tools
  /// that need the current symbol/name/ISIN map; this uses the same cached
  /// download as IPO discovery.
  Future<List<NseListing>> allListings({bool force = false}) =>
      _all(force: force);

  /// Every ticker in the master — the question *"does this symbol still
  /// trade?"* is answered from here, and it is what makes rename detection
  /// safe: a symbol is only considered renamed when it is gone from this set.
  Future<Set<String>> allSymbols({bool force = false}) async {
    final all = await _all(force: force);
    return {for (final listing in all) listing.symbol.toUpperCase()};
  }

  /// `ISIN → listing` — the identity index. A company keeps its ISIN when it
  /// renames itself (LTIM → LTM, AMIORG → ACUTAAS), so this is the lookup that
  /// survives the change.
  Future<Map<String, NseListing>> byIsin({bool force = false}) async {
    final all = await _all(force: force);
    final map = <String, NseListing>{};
    for (final listing in all) {
      if (listing.isin.isEmpty) continue;
      map.putIfAbsent(listing.isin, () => listing);
    }
    return map;
  }

  /// `SYMBOL → ISIN` for filling identity into rows that have none yet.
  Future<Map<String, String>> isinBySymbol({bool force = false}) async {
    final all = await _all(force: force);
    return {
      for (final listing in all)
        if (listing.isin.isNotEmpty) listing.symbol.toUpperCase(): listing.isin,
    };
  }

  /// Official per-share face value (₹) for an ISIN from the listing master,
  /// or null when the master row has none. Never guessed.
  Future<double?> faceValueFor(String isin) async {
    final key = isin.trim().toUpperCase();
    if (key.isEmpty) return null;
    final listing = (await byIsin())[key];
    return listing?.faceValue;
  }

  /// The whole master (cached), unfiltered — [listings] filters it for display.
  Future<List<NseListing>> _all({bool force = false}) async {
    final memo = _memo;
    if (!force &&
        memo != null &&
        _memoAt != null &&
        DateTime.now().difference(_memoAt!) < cacheValidity) {
      return memo;
    }

    if (!force) {
      final cached = await _cached();
      if (cached != null) {
        _memo = cached;
        _memoAt = DateTime.now();
        return cached;
      }
    }

    final text = await _download();
    // Parse with an effectively unlimited lookback: the cache holds the whole
    // master so `allSymbols` can answer for companies listed in 1995 too.
    final listings = parseCsv(
      text,
      now: DateTime.now(),
      lookback: const Duration(days: 365 * 60),
    );
    _memo = listings;
    _memoAt = DateTime.now();
    await _settings.putMeta(
      cacheKey,
      jsonEncode([for (final l in listings) l.toJson()]),
    );
    await _settings.putMeta(cachedAtKey, DateTime.now().toIso8601String());
    return listings;
  }

  Future<List<NseListing>?> _cached() async {
    final raw = await _settings.meta(cacheKey);
    final at = DateTime.tryParse(await _settings.meta(cachedAtKey) ?? '');
    if (raw == null || at == null) return null;
    if (DateTime.now().difference(at) >= cacheValidity) return null;
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return null;
      return [
        for (final row in decoded.whereType<Map<String, dynamic>>())
          NseListing.fromJson(row),
      ];
    } catch (_) {
      return null; // corrupt cache: just download again
    }
  }

  Future<String> _download() async {
    final client = _client ?? http.Client();
    try {
      final response = await client
          .get(
            Uri.parse(url),
            headers: const {
              // NSE's archive 403s bare bots; a normal UA + same-site referer works.
              'User-Agent': 'Mozilla/5.0 (NiveshDesk; +https://niveshdesk.app)',
              'Referer': 'https://www.nseindia.com/',
            },
          )
          .timeout(const Duration(seconds: 60));
      if (response.statusCode >= 400) {
        throw NseListingException(
          'NSE master download failed (HTTP ${response.statusCode}).',
        );
      }
      return response.body;
    } on NseListingException {
      rethrow;
    } catch (error) {
      throw NseListingException('NSE master download failed ($error).');
    } finally {
      if (_client == null) client.close();
    }
  }

  /// Parses `EQUITY_L.csv`. Pure and static so it can be unit-tested without a
  /// network or a database — the only side effect is none at all.
  ///
  /// Rows are kept when they are mainboard/SME (i.e. real cash-market series —
  /// debt rows such as `N5`/`GB` are dropped) and listed within [lookback].
  /// Parses `EQUITY_L.csv`.
  ///
  /// [lookback] limits which rows are *returned*; the whole file is still
  /// parsed, because [NseListingService.allSymbols] needs the complete picture
  /// to answer "does this ticker still trade?" — the question at the heart of
  /// rename detection.
  static List<NseListing> parseCsv(
    String text, {
    required DateTime now,
    Duration lookback = const Duration(days: 720),
  }) {
    final cutoff = now.subtract(lookback);
    final lines = const LineSplitter().convert(text);
    if (lines.isEmpty) return const [];

    // Header first, with its leading spaces trimmed (`" NAME OF COMPANY"`).
    final header = lines.first
        .split(',')
        .map((h) => h.trim().toUpperCase())
        .toList();
    int indexOf(String name) => header.indexOf(name);

    final iSymbol = indexOf('SYMBOL');
    final iName = indexOf('NAME OF COMPANY');
    final iSeries = indexOf('SERIES');
    final iDate = indexOf('DATE OF LISTING');
    final iIsin = indexOf('ISIN NUMBER');
    // `FACE VALUE` is the labelled column on current masters; some vintages
    // carry the same ₹-per-share number under `PAID UP VALUE`. Both are
    // official listing-master numbers, never inferred.
    final iFace = indexOf('FACE VALUE') >= 0
        ? indexOf('FACE VALUE')
        : indexOf('PAID UP VALUE');
    if (iSymbol < 0 || iDate < 0) {
      throw NseListingException('Unexpected NSE master header: ${lines.first}');
    }

    final out = <NseListing>[];
    for (final line in lines.skip(1)) {
      if (line.trim().isEmpty) continue;
      final cells = line.split(',');
      if (cells.length <= iDate) continue;
      final symbol = cells[iSymbol].trim().toUpperCase();
      final series = (iSeries >= 0 ? cells[iSeries] : '').trim().toUpperCase();
      final date = Fmt.parseDate(_titleCaseMonth(cells[iDate].trim()));
      if (symbol.isEmpty || date == null) continue;
      if (!series.startsWith('EQ') &&
          !series.startsWith('BE') &&
          !series.startsWith('SM') &&
          !series.startsWith('ST')) {
        continue; // debt / ETF / other non-equity series
      }
      if (date.isBefore(cutoff)) continue;
      // Face value is read only when the row's cell count matches the
      // header: a company name containing a comma shifts every later column,
      // and a shifted read could hand the market-lot number to face value.
      // A shifted row keeps no face value (null) — never a wrong one.
      final faceValue = iFace >= 0 && cells.length == header.length
          ? double.tryParse(cells[iFace].trim())
          : null;
      out.add(
        NseListing(
          symbol: symbol,
          companyName: (iName >= 0 ? cells[iName] : symbol).trim(),
          series: series,
          listingDate: date,
          isin: (iIsin >= 0 && cells.length > iIsin)
              ? cells[iIsin].trim().toUpperCase()
              : '',
          faceValue: faceValue != null && faceValue > 0 ? faceValue : null,
        ),
      );
    }
    return out;
  }

  /// NSE writes months in caps (`31-JAN-2022`); `DateFormat` expects `Jan`.
  static String _titleCaseMonth(String value) {
    final parts = value.split('-');
    if (parts.length != 3) return value;
    final month = parts[1];
    if (month.length != 3) return value;
    return '${parts[0]}-${month[0].toUpperCase()}${month.substring(1).toLowerCase()}-${parts[2]}';
  }
}
