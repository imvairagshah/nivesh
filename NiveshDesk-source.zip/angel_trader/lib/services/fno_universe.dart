// ---------------------------------------------------------------------------
// fno_universe.dart — the NSE F&O stock list.
//
// Where it comes from: `assets/data/fno_symbols.csv`, generated from Angel One's
// own scrip master — every row of the master whose `instrumenttype` is `FUTSTK`
// (a *stock* future) is a company whose shares have futures and options, i.e. an
// F&O stock. Index futures (`FUTIDX`: NIFTY, BANKNIFTY, …) and the exchange's
// `NSETEST` contracts are filtered out. That makes the list broker-sourced
// rather than a hand-typed guess, and it currently holds 213 names.
//
// Symbol identity: this is exactly the case the ISIN work covers — the F&O list
// carries today's tickers (`LTM`, not `LTIM`), and each row is resolved through
// [TokenResolver] at scan time, so a rename inside the master is picked up
// instead of silently dropping the stock.
//
// The CSV is parsed by hand (it is three columns and never quoted) so this file
// has no dependency on the IPO importer and can be unit-tested with a plain
// string.
// ---------------------------------------------------------------------------

import 'dart:convert' show LineSplitter;

import 'package:flutter/services.dart' show AssetBundle, rootBundle;

/// The F&O symbol list plus the company names that go with it.
class FnoUniverse {
  const FnoUniverse({
    required this.symbols,
    required this.companyNames,
    this.asOf = '',
  });

  /// Plain NSE tickers, alphabetical.
  final List<String> symbols;

  /// `TICKER → company name` (used for the table's second line and for the
  /// resolver's name-based fallback).
  final Map<String, String> companyNames;

  /// The `Notes` column of the first row — carries the review date, so the UI
  /// can say how fresh the list is.
  final String asOf;

  int get length => symbols.length;
  bool get isEmpty => symbols.isEmpty;

  static const FnoUniverse empty =
      FnoUniverse(symbols: [], companyNames: {});

  static const String assetPath = 'assets/data/fno_symbols.csv';

  static FnoUniverse? _memo;

  /// Loads (and memoises) the shipped list.
  ///
  /// Never throws: a missing or damaged asset returns [empty] and the caller
  /// shows "F&O list unavailable" instead of a crash — the scanner is still
  /// usable through the other universes.
  static Future<FnoUniverse> load({AssetBundle? bundle, bool force = false}) async {
    if (!force && _memo != null) return _memo!;
    try {
      final text = await (bundle ?? rootBundle).loadString(assetPath);
      _memo = parse(text);
    } catch (_) {
      _memo = empty;
    }
    return _memo!;
  }

  /// Parses the CSV (`Symbol,Company Name,Notes`; header optional).
  static FnoUniverse parse(String csvText) {
    final symbols = <String>[];
    final names = <String, String>{};
    var asOf = '';

    for (final raw in const LineSplitter().convert(csvText)) {
      final line = raw.trim();
      if (line.isEmpty) continue;

      final cells = line.split(',');
      final symbol = cells.first.trim().toUpperCase();
      if (symbol.isEmpty) continue;
      if (symbol == 'SYMBOL') continue; // header

      final name = cells.length > 1 ? cells[1].trim() : '';
      if (name.isNotEmpty) names[symbol] = name;
      if (cells.length > 2 && asOf.isEmpty) {
        final note = cells[2].trim();
        // "… · from Angel scrip master" → keep the first clause for the UI.
        asOf = note.split('·').first.trim();
      }
      symbols.add(symbol);
    }

    symbols.sort();
    return FnoUniverse(symbols: symbols, companyNames: names, asOf: asOf);
  }

  /// Test seam.
  static void resetMemo() => _memo = null;
}
