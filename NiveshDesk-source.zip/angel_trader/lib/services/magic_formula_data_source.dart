import 'dart:convert';
import 'dart:math' as math;

import 'package:archive/archive.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:xml/xml.dart';

import '../core/utils/markets.dart';
import '../data/local/dao/scrip_dao.dart';
import '../data/local/dao/settings_dao.dart';
import '../data/remote/dto/scrip.dart';
import '../features/magic_formula/magic_formula_models.dart';
import 'nse_listing_service.dart';

/// One Yahoo Finance quote reading — the user-approved **fallback** for when
/// the official chain cannot form market cap (or, for basket members, an EOD
/// close). Pre-normalized: [marketCapCr] in ₹ crore, [lastPrice] in ₹,
/// [priceAsOf] the quote's own market date. Only ever used as labeled
/// enrichment ('Yahoo Finance (unofficial)'); never the primary source.
class YahooQuote {
  const YahooQuote({
    this.marketCapCr,
    this.lastPrice,
    this.priceAsOf,
    this.currency = 'INR',
  });

  final double? marketCapCr;
  final double? lastPrice;
  final DateTime? priceAsOf;
  final String currency;
}

/// Test seam for the Yahoo fallback: production talks to Yahoo's public JSON
/// endpoints; tests inject a pure lookup and stay offline.
typedef YahooQuoteLookup = Future<YahooQuote?> Function(String yahooSymbol);

/// Injectable boundary so ranking and provider tests stay completely offline.
abstract class MagicFormulaDataSource {
  Future<List<MagicFormulaCandidate>> loadCandidates(
    MagicFormulaUniverse universe,
  );

  Future<MagicFormulaFundamental> fetchFundamentals(
    MagicFormulaCandidate candidate, {
    void Function(String stage)? onStage,
  });
}

typedef NseMagicTextGetter =
    Future<String> Function(Uri uri, {String? refererPath});
typedef NseMagicBytesGetter =
    Future<List<int>> Function(Uri uri, {String? refererPath});

/// An HTTP failure from the cookie-less official NSE transport.
class NseMagicFormulaHttpException implements Exception {
  const NseMagicFormulaHttpException({
    required this.statusCode,
    required this.uri,
  });

  final int statusCode;
  final Uri uri;

  /// These responses normally affect the whole feed, not one ticker. Stop a
  /// universe scan rather than caching the same service failure per symbol.
  bool get shouldStopScan =>
      statusCode == 401 ||
      statusCode == 403 ||
      statusCode == 408 ||
      statusCode == 429 ||
      statusCode >= 500;

  String get userMessage {
    if (statusCode == 403) {
      return 'NSE public feed ne HTTP 403 se request block ki. Thodi der baad retry karein.';
    }
    if (statusCode == 429) {
      return 'NSE public feed ne rate limit (HTTP 429) ki. Thodi der baad retry karein.';
    }
    if (statusCode == 401) {
      return 'NSE public feed ne HTTP 401 diya; is scan ke liye data available nahi hai.';
    }
    if (statusCode == 408 || statusCode >= 500) {
      return 'NSE public feed abhi available nahi (HTTP $statusCode). Baad me retry karein.';
    }
    return 'NSE public request HTTP $statusCode (${uri.path}).';
  }

  @override
  String toString() => 'NSE public request HTTP $statusCode (${uri.path}).';
}

/// Cookie-less HTTP transport for official NSE public pages/feeds.
///
/// It never reads a browser jar, stores `Set-Cookie`, or sends a `Cookie`
/// header. A user tap may still receive an NSE bot-block/HTTP error; that is
/// surfaced by the data source as missing data rather than bypassed.
class NseMagicFormulaHttp {
  NseMagicFormulaHttp({http.Client? client})
    : _client = client ?? http.Client();

  final http.Client _client;

  static const Map<String, String> _headers = {
    'User-Agent':
        'Mozilla/5.0 (Linux; Android 13; K) AppleWebKit/537.36 '
        '(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
    'Accept': 'application/json, text/plain, application/xml, */*',
    'Accept-Language': 'en-IN,en;q=0.9',
    'X-Requested-With': 'XMLHttpRequest',
  };

  /// BSE (api.bseindia.com / www.bseindia.com) sits behind Akamai with a
  /// browser-fingerprint rule: requests need the full Chrome header set
  /// (client hints + Origin/Sec-Fetch + Accept-Encoding) or they 403.
  /// Measured against the live public endpoints; no cookies, no session.
  static const Map<String, String> _bseHeaders = {
    'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
        '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/plain, application/xml, */*',
    'Accept-Language': 'en-US,en;q=0.5',
    'Origin': 'https://www.bseindia.com',
    'Sec-Fetch-Site': 'same-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'sec-ch-ua': '"Chromium";v="126", "Not)A;Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'X-Requested-With': 'XMLHttpRequest',
  };

  Future<String> get(Uri uri, {String? refererPath}) async =>
      (await _response(uri, refererPath: refererPath)).body;

  Future<List<int>> getBytes(Uri uri, {String? refererPath}) async =>
      (await _response(uri, refererPath: refererPath)).bodyBytes;

  Future<http.Response> _response(Uri uri, {String? refererPath}) async {
    final isBse = uri.host.endsWith('bseindia.com');
    final referer = isBse
        ? 'https://www.bseindia.com${refererPath ?? '/'}'
        : refererPath == null
        ? 'https://www.nseindia.com/'
        : 'https://www.nseindia.com$refererPath';
    final response = await _client
        .get(
          uri,
          headers: {
            ...(isBse ? _bseHeaders : _headers),
            'Referer': referer,
            'Accept-Encoding': 'gzip, deflate',
          },
        )
        .timeout(const Duration(seconds: 45));
    if (response.statusCode >= 400) {
      throw NseMagicFormulaHttpException(
        statusCode: response.statusCode,
        uri: uri,
      );
    }
    return response;
  }

  void close() => _client.close();
}

class MagicFormulaSourceException implements Exception {
  const MagicFormulaSourceException(this.message);
  final String message;

  @override
  String toString() => message;
}

/// A feed-wide problem that makes continuing ticker-by-ticker pointless.
class MagicFormulaScanAbortException implements Exception {
  const MagicFormulaScanAbortException(this.message);
  final String message;

  @override
  String toString() => message;
}

/// Best-effort public-exchange source for the personal/offline-first app.
///
/// NIFTY memberships come from NSE's downloadable index CSVs. Financials come
/// from the exchanges' own Integrated Filing XBRL (NSE feed, or BSE's public
/// `Integratedfinancedata` feed), and EOD closes from the exchanges' official
/// CM-UDiFF bhavcopies — with no API key, broker session, or user cookies.
/// Neither exchange publishes a stable developer API contract for these
/// endpoints; this reader treats missing/changed fields as unavailable, never
/// as zero.
class NseMagicFormulaDataSource implements MagicFormulaDataSource {
  NseMagicFormulaDataSource({
    required ScripDao scripDao,
    required NseListingService listings,
    required SettingsDao settings,
    required NseMagicTextGetter get,
    required NseMagicBytesGetter getBytes,
    DateTime Function()? clock,
    this.minimumRequestGap = const Duration(milliseconds: 180),
    Future<double?> Function(String isin)? faceValueLookup,
    YahooQuoteLookup? yahooLookup,
  }) : _scripDao = scripDao,
       _listings = listings,
       _settings = settings,
       _get = get,
       _getBytes = getBytes,
       _clock = clock ?? DateTime.now,
       _faceValueLookup = faceValueLookup,
       _yahooLookup = yahooLookup;

  final ScripDao _scripDao;
  final NseListingService _listings;
  final SettingsDao _settings;
  final NseMagicTextGetter _get;
  final NseMagicBytesGetter _getBytes;
  final DateTime Function() _clock;
  final Duration minimumRequestGap;

  /// Seam for tests: production uses the official listing master through
  /// [NseListingService.faceValueFor]; tests inject a pure lookup so no
  /// network is touched.
  final Future<double?> Function(String isin)? _faceValueLookup;

  /// Seam for tests: production uses Yahoo's public JSON endpoints (the
  /// approved unofficial fallback); tests inject a pure lookup.
  final YahooQuoteLookup? _yahooLookup;
  String? _yahooCookie;
  String? _yahooCrumb;
  DateTime? _yahooSessionAt;
  DateTime? _lastRequestAt;
  _NseBhavcopySnapshot? _bhavcopyCache;
  DateTime? _bhavcopyFetchedOn;
  Future<_NseBhavcopySnapshot>? _bhavcopyFlight;
  _NseBhavcopySnapshot? _bseBhavcopyCache;
  DateTime? _bseBhavcopyFetchedOn;
  Future<_NseBhavcopySnapshot>? _bseBhavcopyFlight;

  static const Duration indexCacheValidity = Duration(hours: 24);
  static const String integratedFilingsPath = '/api/integrated-filing-results';
  static const String integratedReferer =
      '/companies-listing/corporate-integrated-filing';
  static const String bhavcopyReferer = '/all-reports';

  static const Map<MagicFormulaUniverse, String> indexCsvUrls = {
    MagicFormulaUniverse.nifty50:
        'https://archives.nseindia.com/content/indices/ind_nifty50list.csv',
    MagicFormulaUniverse.nifty100:
        'https://archives.nseindia.com/content/indices/ind_nifty100list.csv',
    MagicFormulaUniverse.nifty500:
        'https://archives.nseindia.com/content/indices/ind_nifty500list.csv',
  };

  @override
  Future<List<MagicFormulaCandidate>> loadCandidates(
    MagicFormulaUniverse universe,
  ) async {
    if (universe == MagicFormulaUniverse.all ||
        universe == MagicFormulaUniverse.sectorWise) {
      return _allCashEquities();
    }
    final url = indexCsvUrls[universe];
    if (url == null) {
      throw const MagicFormulaSourceException(
        'Is universe ke liye official NSE list available nahi hai.',
      );
    }
    return _indexCandidates(universe, Uri.parse(url));
  }

  Future<List<MagicFormulaCandidate>> _indexCandidates(
    MagicFormulaUniverse universe,
    Uri uri,
  ) async {
    final key = 'magic_formula_${universe.key}_csv';
    final stampKey = '${key}_at';
    final rawCache = await _settings.meta(key);
    final cachedAt = DateTime.tryParse(await _settings.meta(stampKey) ?? '');
    if (rawCache != null &&
        cachedAt != null &&
        _clock().difference(cachedAt) < indexCacheValidity) {
      final fromCache = _decodeCandidateCache(rawCache);
      if (fromCache.isNotEmpty) return fromCache;
    }

    try {
      final csv = await _request(uri, refererPath: '/');
      final parsed = parseIndexCsv(csv);
      if (parsed.isEmpty) {
        throw const FormatException('NSE index CSV mein rows nahi mili.');
      }
      await _settings.putMeta(
        key,
        jsonEncode(parsed.map(_candidateJson).toList()),
      );
      await _settings.putMeta(stampKey, _clock().toIso8601String());
      return parsed;
    } catch (error) {
      // An older official list remains useful if NSE is temporarily blocked;
      // surface its age in source metadata instead of pretending it is live.
      if (rawCache != null) {
        final fallback = _decodeCandidateCache(rawCache);
        if (fallback.isNotEmpty) return fallback;
      }
      throw MagicFormulaSourceException(
        'NSE ki ${universe.label} constituent list download nahi hui. '
        'Internet check karke dobara try karein. ($error)',
      );
    }
  }

  Future<List<MagicFormulaCandidate>> _allCashEquities() async {
    final scrips = await _scripDao.allEquities();
    if (scrips.isEmpty) {
      throw const MagicFormulaSourceException(
        'Local equity master khaali hai. Settings mein scrip master refresh karke dobara try karein.',
      );
    }

    List<NseListing> officialListings = const [];
    try {
      officialListings = await _listings.allListings();
    } catch (_) {
      // The broker's local cash master still gives a usable ticker list; rows
      // without an official NSE mapping will be shown as missing data.
    }
    final nseBySymbol = <String, NseListing>{
      for (final listing in officialListings)
        if (listing.isMainboard) listing.symbol.toUpperCase(): listing,
    };
    final nseByName = <String, NseListing>{
      for (final listing in officialListings)
        if (listing.isMainboard &&
            _normalizedCompanyName(listing.companyName).isNotEmpty)
          _normalizedCompanyName(listing.companyName): listing,
    };
    final sectorBySymbol = <String, MagicFormulaCandidate>{};
    final nifty500Url = indexCsvUrls[MagicFormulaUniverse.nifty500];
    if (nifty500Url != null) {
      try {
        final indexRows = await _indexCandidates(
          MagicFormulaUniverse.nifty500,
          Uri.parse(nifty500Url),
        );
        sectorBySymbol.addEntries(
          indexRows.map((row) => MapEntry(row.symbol.toUpperCase(), row)),
        );
      } catch (_) {
        // The official NIFTY 500 industry map is enrichment only. If it is
        // unavailable, preserve the ALL universe and show unknown sectors.
      }
    }

    final candidates = <String, MagicFormulaCandidate>{};
    for (final scrip in scrips) {
      if (!scrip.exchange.isCash || _isNonCommonInstrument(scrip)) continue;
      final plain = Scrip.plainSymbol(scrip.symbol).trim().toUpperCase();
      if (plain.isEmpty) continue;

      if (scrip.exchange == Exchange.nse) {
        final listing = nseBySymbol[plain];
        if (listing != null && !listing.isMainboard) continue;
        final resolvedSymbol = listing?.symbol ?? plain;
        final classification = sectorBySymbol[resolvedSymbol.toUpperCase()];
        final candidate = MagicFormulaCandidate(
          symbol: resolvedSymbol,
          companyName: listing?.companyName.isNotEmpty == true
              ? listing!.companyName
              : scrip.name,
          exchange: 'NSE',
          sector: classification?.sector ?? '',
          industry: classification?.industry ?? '',
          isin: listing?.isin ?? classification?.isin ?? '',
          dataSymbol: resolvedSymbol,
          dataCompanyName: listing?.companyName ?? scrip.name,
        );
        candidates.putIfAbsent(candidate.cacheKey, () => candidate);
        continue;
      }

      // BSE's numeric scrip can use the NSE filing feed only when its company
      // name resolves to an official NSE cash listing. The ISIN then collapses
      // the dual listing to one stock; no name-based value is invented.
      final matchedListing = nseByName[_normalizedCompanyName(scrip.name)];
      if (matchedListing != null) {
        final classification =
            sectorBySymbol[matchedListing.symbol.toUpperCase()];
        final candidate = MagicFormulaCandidate(
          symbol: matchedListing.symbol,
          companyName: matchedListing.companyName,
          exchange: 'NSE/BSE',
          sector: classification?.sector ?? '',
          industry: classification?.industry ?? '',
          isin: matchedListing.isin,
          dataSymbol: matchedListing.symbol,
          dataCompanyName: matchedListing.companyName,
        );
        candidates.putIfAbsent(candidate.cacheKey, () => candidate);
      } else {
        final candidate = MagicFormulaCandidate(
          symbol: plain,
          companyName: scrip.name.isEmpty ? plain : scrip.name,
          exchange: 'BSE',
        );
        candidates.putIfAbsent(candidate.cacheKey, () => candidate);
      }
    }
    final rows = candidates.values.toList()
      ..sort((a, b) => a.symbol.compareTo(b.symbol));
    return rows;
  }

  @override
  Future<MagicFormulaFundamental> fetchFundamentals(
    MagicFormulaCandidate candidate, {
    void Function(String stage)? onStage,
  }) async {
    final fetchedAt = _clock();
    final isBse = candidate.exchange == 'BSE' || candidate.dataSymbol.isEmpty;
    try {
      final _NseBhavcopySnapshot bhavcopy;
      if (isBse) {
        onStage?.call('BSE official EOD close load ho raha hai');
        bhavcopy = await _latestBseBhavcopy();
      } else {
        onStage?.call('NSE official EOD close load ho raha hai');
        bhavcopy = await _latestBhavcopy();
      }
      final close = bhavcopy.priceFor(candidate);
      var usedYahooPrice = false;
      var usedYahooMarketCap = false;
      // Lazy: `_yahooQuoteFor` runs only when an official input turns out to
      // be missing, and at most once per candidate (shared future).
      late final Future<YahooQuote?> yahooQuote = _yahooQuoteFor(candidate);
      final _QuoteInfo quoteInfo;
      if (close == null) {
        // A basket member can be absent from the official EOD file (suspended
        // that day, newly listed). The approved fallback is Yahoo's own quote —
        // labeled 'Yahoo Finance (unofficial)' on the row. Absence stays
        // absence: no Yahoo quote, no invented price.
        final yahoo = await yahooQuote;
        final price = yahoo?.lastPrice;
        if (price == null || !(price > 0)) {
          return MagicFormulaFundamental(
            candidate: candidate,
            marketPriceAsOf: bhavcopy.tradeDate,
            fetchedAt: fetchedAt,
            source: isBse
                ? 'BSE CM-UDiFF EOD Bhavcopy'
                : 'NSE CM-UDiFF EOD Bhavcopy',
            missingReason:
                'Latest official EQ/BE close is report me nahi mila; Market Cap guess nahi kiya.',
          );
        }
        usedYahooPrice = true;
        quoteInfo = _QuoteInfo(
          lastPrice: price,
          priceAsOf: yahoo?.priceAsOf ?? bhavcopy.tradeDate,
        );
      } else {
        quoteInfo = _QuoteInfo(
          lastPrice: close.closePrice,
          priceAsOf: close.tradeDate,
        );
      }
      // Row source label: the official chain stays the headline; any Yahoo
      // fallback is appended as a clearly marked unofficial segment.
      String decorateSource(String base) {
        var label = base;
        if (usedYahooPrice) {
          label += ' | Price: Yahoo Finance (unofficial)';
        }
        if (usedYahooMarketCap) {
          label += ' | Market Cap: Yahoo Finance (unofficial)';
        }
        return label;
      }
      final sector = candidate.sector.isNotEmpty
          ? candidate.sector
          : mapSector(candidate.industry);
      final displayCandidate = MagicFormulaCandidate(
        symbol: candidate.symbol,
        companyName: candidate.companyName,
        exchange: candidate.exchange,
        sector: sector,
        industry: candidate.industry,
        isin: candidate.isin.isNotEmpty ? candidate.isin : (close?.isin ?? ''),
        dataSymbol: candidate.dataSymbol,
        dataCompanyName: candidate.dataCompanyName,
      );

      final List<_NseFiling> filings;
      // Which official feed actually supplied the filings — reflected in the
      // row's source label.
      var filingsFromBse = false;
      if (isBse) {
        onStage?.call('BSE Integrated Filing list');
        // BSE's public filings feed is keyed by the six-digit scrip code
        // (the UDiFF FinInstrmId). It comes from the row itself when the
        // symbol is the code, otherwise via the row's ISIN — never guessed.
        final scripCode = _bseScripCode(displayCandidate, bhavcopy);
        if (scripCode == null) {
          return _missing(
            displayCandidate,
            fetchedAt,
            'BSE scrip code official reports me nahi mili; filing link '
            'bina code ke discover nahi hoti, is row ko guess nahi kiya.',
            source: 'BSE CM-UDiFF EOD Bhavcopy',
          );
        }
        filings = await _fetchBseFilings(scripCode);
        filingsFromBse = true;
      } else {
        onStage?.call('NSE Integrated Filing list');
        var collected = await _fetchFilings(displayCandidate);
        if (collected.isEmpty) {
          // Official fallback across exchanges: NSE's Integrated Filing feed
          // publishes nothing for some members (new listings, demerged
          // entities, REITs) while the company's official BSE feed has the
          // filings — keyed by the six-digit scrip code from the bhavcopy.
          // Both feeds are exchange-official; nothing unofficial enters and
          // absence in both stays absence.
          onStage?.call('BSE Integrated Filing list (NSE feed me nahi mila)');
          _NseBhavcopySnapshot bseSnapshot;
          try {
            bseSnapshot = await _latestBseBhavcopy();
          } catch (_) {
            bseSnapshot = _NseBhavcopySnapshot(const []);
          }
          final scripCode = _bseScripCode(displayCandidate, bseSnapshot);
          if (scripCode != null) {
            try {
              final bseFilings = await _fetchBseFilings(scripCode);
              if (bseFilings.isNotEmpty) {
                collected = bseFilings;
                filingsFromBse = true;
              }
            } catch (_) {
              // Best-effort fallback — the NSE-side outcome stands.
            }
          }
        }
        filings = collected;
      }
      // Official listing-master face value: several filing faces (insurance
      // IFLI in particular) tag paid-up capital but no face value, so the
      // filing alone cannot form a share count. The exchange listing master
      // is the official fallback; absence stays absence.
      double? masterFaceValue;
      try {
        final lookup = _faceValueLookup;
        masterFaceValue = lookup != null
            ? await lookup(displayCandidate.isin)
            : await _listings.faceValueFor(displayCandidate.isin);
      } catch (_) {
        // Enrichment only — the filing's own facts still apply without it.
      }
      final selections = _selectFourConsecutiveFilings(filings);
      if (selections.isEmpty) {
        var marketCapCr = _marketCapCr(quoteInfo, null);
        if (marketCapCr == null) {
          final yahoo = await yahooQuote;
          final value = yahoo?.marketCapCr;
          if (value != null && value > 0) {
            marketCapCr = value;
            usedYahooMarketCap = true;
          }
        }
        return MagicFormulaFundamental(
          candidate: displayCandidate,
          marketCapCr: marketCapCr,
          marketPriceAsOf: quoteInfo.priceAsOf,
          fetchedAt: fetchedAt,
          source: decorateSource(
            isBse
                ? 'BSE CM-UDiFF EOD Close + Integrated Filing'
                : filingsFromBse
                ? 'NSE CM-UDiFF EOD Close + BSE Integrated Filing'
                : 'NSE CM-UDiFF EOD Close + Integrated Filing',
          ),
          missingReason:
              'TTM EBIT ke liye ek hi statement basis par 4 consecutive quarter filings nahi mili.',
        );
      }

      final attempts = <_BasisRead>[];
      for (final selection in selections) {
        final attempt = await _readBasis(
          selection,
          quoteInfo: quoteInfo,
          masterFaceValue: masterFaceValue,
          yahooQuote: () => yahooQuote,
          onStage: onStage,
        );
        attempts.add(attempt);
        if (attempt.usedYahooMarketCap) usedYahooMarketCap = true;
        // Consolidated is first. Only use standalone when the consolidated
        // basis cannot provide every required input.
        if (attempt.isComplete) break;
      }
      attempts.sort((a, b) {
        final byCompleteness = b.completeness.compareTo(a.completeness);
        if (byCompleteness != 0) return byCompleteness;
        // Preserve consolidated as the preferred basis when both are partial.
        return a.selection.basis == 'Consolidated' ? -1 : 1;
      });
      final chosen = attempts.first;
      final latest = chosen.statements.isEmpty ? null : chosen.statements.first;
      final balance = chosen.balanceSource;
      return MagicFormulaFundamental(
        candidate: displayCandidate,
        marketCapCr: chosen.marketCapCr,
        ebitTtmCr: chosen.ebitTtmCr,
        totalDebtCr: balance?.totalDebt == null
            ? null
            : balance!.totalDebt! / 10000000,
        cashCr: balance?.cash == null ? null : balance!.cash! / 10000000,
        totalAssetsCr: balance?.totalAssets == null
            ? null
            : balance!.totalAssets! / 10000000,
        currentLiabilitiesCr: balance?.currentLiabilities == null
            ? null
            : balance!.currentLiabilities! / 10000000,
        marketPriceAsOf: quoteInfo.priceAsOf,
        statementBasis: chosen.selection.basis,
        earningsBasis: chosen.earningsBasis,
        periodStart: chosen.statements.length == 4
            ? chosen.statements.last.periodStart
            : null,
        periodEnd: latest?.periodEnd,
        balanceSheetDate: balance?.balanceSheetDate,
        fetchedAt: fetchedAt,
        source: decorateSource(
          isBse
              ? 'BSE CM-UDiFF EOD Close + Integrated Filing XBRL'
              : filingsFromBse
              ? 'NSE CM-UDiFF EOD Close + BSE Integrated Filing XBRL'
              : 'NSE CM-UDiFF EOD Close + Integrated Filing XBRL',
        ),
        missingReason: chosen.missingReason,
      );
    } on MagicFormulaScanAbortException {
      rethrow;
    } on NseMagicFormulaHttpException catch (error) {
      if (error.shouldStopScan) rethrow;
      return _missing(
        candidate,
        fetchedAt,
        '${isBse ? 'BSE' : 'NSE'} public filing/EOD feed: ${_shortError(error)}',
      );
    } catch (error) {
      return _missing(
        candidate,
        fetchedAt,
        '${isBse ? 'BSE' : 'NSE'} public filing/EOD feed: ${_shortError(error)}',
      );
    }
  }

  Future<_NseBhavcopySnapshot> _latestBhavcopy() async {
    final today = _dateOnly(_clock());
    final cached = _bhavcopyCache;
    if (cached != null && _bhavcopyFetchedOn == today) return cached;
    final inFlight = _bhavcopyFlight;
    if (inFlight != null) return inFlight;

    final request = _loadLatestBhavcopy(today);
    _bhavcopyFlight = request;
    try {
      final snapshot = await request;
      _bhavcopyCache = snapshot;
      _bhavcopyFetchedOn = today;
      return snapshot;
    } finally {
      if (identical(_bhavcopyFlight, request)) _bhavcopyFlight = null;
    }
  }

  Future<_NseBhavcopySnapshot> _loadLatestBhavcopy(DateTime today) async {
    const maxCalendarDays = 14;
    Uri? lastUri;
    for (var offset = 0; offset < maxCalendarDays; offset++) {
      final date = today.subtract(Duration(days: offset));
      final dateKey =
          '${date.year}${date.month.toString().padLeft(2, '0')}'
          '${date.day.toString().padLeft(2, '0')}';
      // NSE All Reports publishes this final CM-UDiFF archive name. The UDiFF
      // format defines the TradDt/ISIN/TckrSymb/SctySrs/ClsPric tags parsed
      // below. If this public archive is unavailable or changes, stop rather
      // than silently switching to a live or unofficial price source.
      final uri = Uri.https(
        'nsearchives.nseindia.com',
        '/content/cm/BhavCopy_NSE_CM_0_0_0_${dateKey}_F_0000.csv.zip',
      );
      lastUri = uri;
      try {
        final bytes = await _requestBytes(uri, refererPath: bhavcopyReferer);
        final csv = _decodeBhavcopyZip(bytes);
        final rows = parseBhavcopyCsv(csv)
            .where((row) => _dateOnly(row.tradeDate) == date)
            .toList(growable: false);
        if (rows.isEmpty) {
          throw const FormatException(
            'CM-UDiFF file me expected date ke EQ/BE close rows nahi mile.',
          );
        }
        return _NseBhavcopySnapshot(rows);
      } on NseMagicFormulaHttpException catch (error) {
        if (error.statusCode == 404) continue;
        rethrow;
      } on MagicFormulaScanAbortException {
        rethrow;
      } catch (error) {
        throw MagicFormulaScanAbortException(
          'NSE CM-UDiFF EOD report read nahi hua; scan yahin roka. '
          'Koi price guess nahi kiya. (${_shortError(error)})',
        );
      }
    }
    throw MagicFormulaScanAbortException(
      'NSE ka latest CM-UDiFF EOD report pichhle $maxCalendarDays calendar days me nahi mila'
      '${lastUri == null ? '' : ' (${lastUri.path})'}. Baad me retry karein.',
    );
  }

  static String _decodeBhavcopyZip(List<int> bytes) {
    final archive = ZipDecoder().decodeBytes(bytes);
    ArchiveFile? csvFile;
    for (final file in archive.files) {
      if (file.isFile && file.name.toLowerCase().endsWith('.csv')) {
        csvFile = file;
        break;
      }
    }
    if (csvFile == null) {
      throw const FormatException('ZIP ke andar CSV report nahi mila.');
    }
    final content = csvFile.content;
    if (content is! List<int>) {
      throw const FormatException(
        'Bhavcopy CSV ka binary content invalid hai.',
      );
    }
    return utf8.decode(content);
  }

  Future<List<_NseFiling>> _fetchFilings(
    MagicFormulaCandidate candidate,
  ) async {
    final uri = Uri.https('www.nseindia.com', integratedFilingsPath, {
      'index': 'equities',
      'symbol': candidate.dataSymbol,
      'issuer': candidate.dataCompanyName.isEmpty
          ? candidate.companyName
          : candidate.dataCompanyName,
      'period_ended': 'all',
      'type': 'Integrated Filing- Financials',
      'page': '1',
      'size': '50',
    });
    final body = await _request(uri, refererPath: integratedReferer);
    _requireJson(body, 'NSE Integrated Filing');
    final root = _decodeJson(body);
    final rows = _findRows(root);
    final filings = <_NseFiling>[];
    for (final row in rows) {
      final xbrl = _findString(row, const [
        'xbrl',
        'xbrlUrl',
        'xbrlFile',
        'xbrlFileUrl',
        'xbrlLink',
      ]);
      final period = _findDate(row, const [
        'qe_Date',
        'qeDate',
        'periodEnd',
        'period_end',
        'periodEnded',
        'period_end_date',
      ]);
      final basis = _filingBasis(row);
      if (xbrl == null || period == null || basis == null) continue;
      final resolved = _resolveArchiveUrl(xbrl);
      if (resolved == null) continue;
      filings.add(
        _NseFiling(
          xbrlUrl: resolved,
          periodEnd: period,
          basis: basis,
          filedAt: _findDate(row, const [
            'creation_Date',
            'creationDate',
            'filingDate',
            'filedAt',
            'broadcastDate',
          ]),
        ),
      );
    }
    return filings;
  }

  /// BSE scrip code for the filings feed: the candidate's own numeric symbol
  /// when it is one, otherwise the UDiFF `FinInstrmId` of the candidate's
  /// ISIN row in the official bhavcopy. Never invented.
  static String? _bseScripCode(
    MagicFormulaCandidate candidate,
    _NseBhavcopySnapshot snapshot,
  ) {
    final symbol = candidate.symbol.trim();
    if (RegExp(r'^\d{5,6}$').hasMatch(symbol)) return symbol;
    // Basket-added BSE rows carry the six-digit code in the data symbol.
    final dataSymbol = candidate.dataSymbol.trim();
    if (RegExp(r'^\d{5,6}$').hasMatch(dataSymbol)) return dataSymbol;
    return snapshot.securityIdFor(candidate);
  }

  Future<_NseBhavcopySnapshot> _latestBseBhavcopy() async {
    final today = _dateOnly(_clock());
    final cached = _bseBhavcopyCache;
    if (cached != null && _bseBhavcopyFetchedOn == today) return cached;
    final inFlight = _bseBhavcopyFlight;
    if (inFlight != null) return inFlight;

    final request = _loadLatestBseBhavcopy(today);
    _bseBhavcopyFlight = request;
    try {
      final snapshot = await request;
      _bseBhavcopyCache = snapshot;
      _bseBhavcopyFetchedOn = today;
      return snapshot;
    } finally {
      if (identical(_bseBhavcopyFlight, request)) _bseBhavcopyFlight = null;
    }
  }

  Future<_NseBhavcopySnapshot> _loadLatestBseBhavcopy(DateTime today) async {
    const maxCalendarDays = 14;
    Uri? lastUri;
    for (var offset = 0; offset < maxCalendarDays; offset++) {
      final date = today.subtract(Duration(days: offset));
      final dateKey =
          '${date.year}${date.month.toString().padLeft(2, '0')}'
          '${date.day.toString().padLeft(2, '0')}';
      // BSE publishes the same standardized CM-UDiFF equity report as NSE
      // (BSE UDiFF notice: bhavcopy is UDiFF-only since 08-July-2024). The
      // columns — TradDt/ISIN/TckrSymb/SctySrs/FinInstrmId/ClsPric — are the
      // ones parsed below. If this public archive is unavailable or changes,
      // stop rather than switching to a live or unofficial price source.
      final uri = Uri.https(
        'www.bseindia.com',
        '/download/BhavCopy/Equity/BhavCopy_BSE_CM_0_0_0_${dateKey}_F_0000.CSV',
      );
      lastUri = uri;
      try {
        final bytes = await _requestBytes(uri);
        final rows = parseBhavcopyCsv(utf8.decode(bytes))
            .where((row) => _dateOnly(row.tradeDate) == date)
            .toList(growable: false);
        if (rows.isEmpty) {
          throw const FormatException(
            'CM-UDiFF file me expected date ke equity close rows nahi mile.',
          );
        }
        return _NseBhavcopySnapshot(rows);
      } on NseMagicFormulaHttpException catch (error) {
        if (error.statusCode == 404) continue;
        rethrow;
      } on MagicFormulaScanAbortException {
        rethrow;
      } catch (error) {
        throw MagicFormulaScanAbortException(
          'BSE ka CM-UDiFF EOD report read nahi hua; scan yahin roka. '
          'Koi price guess nahi kiya. (${_shortError(error)})',
        );
      }
    }
    throw MagicFormulaScanAbortException(
      'BSE ka latest CM-UDiFF EOD report pichhle $maxCalendarDays calendar '
      'days me nahi mila${lastUri == null ? '' : ' (${lastUri.path})'}. '
      'Baad me retry karein.',
    );
  }

  /// BSE public integrated-filing feed (the quote page's "Integrated Filing"
  /// tab): one call per scrip returns the full filing history with the XBRL
  /// instance path in `XbrlFile`, the basis and period in `Quarter_Name`, and
  /// the filing/revision timestamps. `Yyyy`-style keys are BSE's own.
  static const String bseIntegratedFilingHost = 'api.bseindia.com';
  static const String bseIntegratedFilingPath =
      '/BseIndiaAPI/api/Integratedfinancedata/w';

  Future<List<_NseFiling>> _fetchBseFilings(String scripCode) async {
    final uri = Uri.https(bseIntegratedFilingHost, bseIntegratedFilingPath, {
      'scripcode': scripCode,
    });
    final body = await _request(uri);
    return _parseBseIntegratedFilingsRows(body);
  }

  /// Parses the BSE `Integratedfinancedata` JSON into filing rows — pure so
  /// offline tests can pin the shape through [fetchFundamentals] without any
  /// network.
  static List<_NseFiling> _parseBseIntegratedFilingsRows(String body) {
    _requireJson(body, 'BSE Integrated Filing');
    final root = _decodeJson(body);
    final rows = _findRows(root);
    final filings = <_NseFiling>[];
    for (final row in rows) {
      final path = _findString(row, const ['XbrlFile', 'xbrlFile', 'xbrlurl']);
      final quarterName = _findString(row, const [
        'Quarter_Name',
        'quarterName',
        'quarter_name',
      ]);
      final parsed = parseBseQuarterName(quarterName ?? '');
      if (path == null || parsed == null) continue;
      final resolved = _resolveArchiveUrl(path);
      if (resolved == null) continue;
      final revisedAt = _findDate(row, const ['revised_date_time']);
      filings.add(
        _NseFiling(
          xbrlUrl: resolved,
          periodEnd: parsed.periodEnd,
          basis: parsed.basis,
          filedAt: revisedAt ?? _findDate(row, const [
            'filing_date_time',
            'filingDateTime',
          ]),
        ),
      );
    }
    return filings;
  }

  /// `Quarter_Name` encodes basis + period, e.g.
  /// `Consolidated-Sep-Qtr-2026`, `Standalone-Mar-Yearly-2026`,
  /// `Standalone-Dec-NineMths-2025`, `Consolidated-Sep-Hly-2026`.
  /// Only the plain quarter (`-Qtr-`) rows are TTM quarters; the Hly /
  /// NineMths / Yearly rows are the same filings' other period columns and
  /// map to the same period end.
  static ({DateTime periodEnd, String basis})? parseBseQuarterName(
    String quarterName,
  ) {
    final match = RegExp(
      r'^(Consolidated|Standalone)-(Jun|Sep|Dec|Mar)-'
      r'(Qtr|Hly|NineMths|Yearly)-(\d{4})$',
      caseSensitive: false,
    ).firstMatch(quarterName.trim());
    if (match == null) return null;
    final basis = match.group(1)!.toLowerCase() == 'consolidated'
        ? 'Consolidated'
        : 'Standalone';
    final month = switch (match.group(2)!.toLowerCase()) {
      'jun' => 6,
      'sep' => 9,
      'dec' => 12,
      _ => 3,
    };
    final year = int.parse(match.group(4)!);
    final periodEnd = DateTime(year, month + 1, 0);
    return (periodEnd: periodEnd, basis: basis);
  }

  List<_SelectedFilings> _selectFourConsecutiveFilings(List<_NseFiling> input) {
    final selections = <_SelectedFilings>[];
    for (final basis in const ['Consolidated', 'Standalone']) {
      final sorted = input.where((row) => row.basis == basis).toList()
        ..sort((a, b) {
          final byEnd = b.periodEnd.compareTo(a.periodEnd);
          if (byEnd != 0) return byEnd;
          return (b.filedAt ?? DateTime(0)).compareTo(a.filedAt ?? DateTime(0));
        });
      final distinct = <DateTime, _NseFiling>{};
      for (final row in sorted) {
        distinct.putIfAbsent(_dateOnly(row.periodEnd), () => row);
      }
      final quarters = distinct.values.toList()
        ..sort((a, b) => b.periodEnd.compareTo(a.periodEnd));
      if (quarters.isEmpty) continue;
      final take = quarters.length < 4 ? quarters.length : 4;
      final latestFour = quarters.take(take).toList(growable: false);
      if (_clock().difference(latestFour.first.periodEnd).inDays > 400) {
        continue;
      }
      // A feed stream can have quarter-row gaps (a September fiscal year's
      // December quarters are absent from BSE's integrated feed) or fewer
      // than four rows (a newly listed demerged entity). Such a set is still
      // offered to the read: the TTM assembler then either covers the
      // trailing twelve months exactly from the documents' own period
      // columns or reports the earnings input as honestly missing. A
      // non-contiguous set never produces a wrong window by itself —
      // nothing is summed unless the cover is exact.
      selections.add(_SelectedFilings(basis, latestFour));
    }
    return selections;
  }

  Future<_BasisRead> _readBasis(
    _SelectedFilings selection, {
    required _QuoteInfo quoteInfo,
    double? masterFaceValue,
    Future<YahooQuote?> Function()? yahooQuote,
    void Function(String stage)? onStage,
  }) async {
    final statements = <_NseXbrlStatement>[];
    String? readError;
    try {
      for (var index = 0; index < selection.filings.length; index++) {
        final filing = selection.filings[index];
        onStage?.call(
          'XBRL ${selection.basis} ${index + 1}/4 · ${_dateLabel(filing.periodEnd)}',
        );
        final xml = await _fetchXbrl(filing.xbrlUrl);
        final statement = _parseXbrl(xml, filing);
        if (statement.periodEnd != _dateOnly(filing.periodEnd)) {
          readError = 'XBRL quarter end filing list se match nahi karta.';
          break;
        }
        statements.add(statement);
      }
    } on NseMagicFormulaHttpException catch (error) {
      if (error.shouldStopScan) rethrow;
      readError = 'XBRL read failed: ${_shortError(error)}';
    } catch (error) {
      readError = 'XBRL read failed: ${_shortError(error)}';
    }

    statements.sort((a, b) => b.periodEnd.compareTo(a.periodEnd));
    final latest = statements.isEmpty ? null : statements.first;

    // SEBI Reg 33(3)(f): the Statement of Assets and Liabilities is filed
    // half-yearly (with the Sep and Mar quarters). Three situations, each
    // handled without ever mixing fields across statements:
    //  * The newest face carries no balance-sheet fact at all → use the
    //    newest already-selected filing that does, with that statement's
    //    own date shown as the balance-sheet date.
    //  * The newest face is a June/December quarter carrying only a partial
    //    balance line set — the statement is not even due then (SBILIFE's
    //    Jun-2026 IFLI face tags Assets and paid-up capital but no
    //    liabilities/cash/borrowings lines, while its Mar-YEARLY face tags
    //    the complete statement) → the half-year statement is the official
    //    balance for that scan, taken whole from the newest filing that
    //    carries it.
    //  * A Sep/Mar face (where the statement IS due) with missing lines — or
    //    whose balance facts sit on an older instant than its own period
    //    end — is suspect, not "half-yearly absent": those fields stay
    //    missing and nothing is back-filled from older filings.
    _NseXbrlStatement? balanceSource = latest;
    final isHalfYearQuarterEnd = latest != null &&
        (latest.periodEnd.month == 3 || latest.periodEnd.month == 9);
    final latestBalanceIncomplete = latest == null ||
        latest.totalAssets == null ||
        latest.currentLiabilities == null ||
        latest.totalDebt == null ||
        latest.cash == null;
    final needsBalanceFallback = latest != null &&
        (!latest.hasBalanceSheetFacts ||
            (!isHalfYearQuarterEnd && latestBalanceIncomplete));
    if (needsBalanceFallback) {
      for (final row in statements.skip(1)) {
        if (row.hasBalanceSheetFacts &&
            row.totalAssets != null &&
            row.currentLiabilities != null) {
          balanceSource = row;
          break;
        }
      }
    }

    // TTM assembly: four discrete quarter columns when the feed has them;
    // otherwise an exact cover from the documents' official period columns
    // (Hly / NineMths / Yearly faces, comparative quarter columns) — sums
    // and exact differences of official figures only. No exact cover → the
    // earnings input stays honestly missing. Mixing EBIT and PBT columns is
    // never allowed: one basis per cover.
    final windowEnd = statements.isEmpty ? null : statements.first.periodEnd;
    final ttmEbit = windowEnd == null
        ? null
        : _assembleTtm(statements, windowEnd: windowEnd, usePbt: false);
    var ebitTtmCr = ttmEbit == null ? null : ttmEbit.value / 10000000;
    var earningsBasis = '';
    if (ttmEbit != null && ttmEbit.derived > 0) {
      earningsBasis = ttmEbit.label;
    }
    if (ebitTtmCr == null) {
      // Approved PBT proxy: banking/insurance/NBFC taxonomies tag no EBIT
      // element. TTM PBT then serves as the earnings input and the basis is
      // labelled in the row detail and skip note.
      final ttmPbt = windowEnd == null
          ? null
          : _assembleTtm(statements, windowEnd: windowEnd, usePbt: true);
      if (ttmPbt != null) {
        ebitTtmCr = ttmPbt.value / 10000000;
        earningsBasis = ttmPbt.derived > 0
            ? 'PBT proxy (EBIT not tagged); ${ttmPbt.label}'
            : 'PBT proxy (EBIT not tagged)';
      }
    }
    final marketCapCr = _marketCapCr(quoteInfo, latest, masterFaceValue);
    var yahooMarketCapCr = marketCapCr;
    var usedYahooMarketCap = false;
    // Approved fallback: when the official chain cannot form a share count,
    // Yahoo Finance's own market cap (INR, labeled unofficial on the row)
    // fills the gap — before the missing list is built, so the row neither
    // claims a missing Market Cap nor silently pretends the number is official.
    if (yahooMarketCapCr == null || yahooMarketCapCr <= 0) {
      try {
        final quote = await yahooQuote?.call();
        final value = quote?.marketCapCr;
        if (quote != null && quote.currency == 'INR' && value != null && value > 0) {
          yahooMarketCapCr = value;
          usedYahooMarketCap = true;
        }
      } catch (_) {
        // The unofficial fallback is enrichment — absence changes nothing.
      }
    }
    final missing = <String>[];
    if (ebitTtmCr == null) missing.add('TTM EBIT');
    if (yahooMarketCapCr == null || yahooMarketCapCr <= 0) {
      missing.add('Market Cap');
    }
    if (balanceSource?.totalDebt == null) missing.add('Total Debt');
    if (balanceSource?.cash == null) missing.add('Cash & Equivalents');
    if (balanceSource?.totalAssets == null) missing.add('Total Assets');
    if (balanceSource?.currentLiabilities == null) {
      missing.add('Current Liabilities');
    }
    if (readError != null) missing.add(readError);

    var missingReason = missing.isEmpty
        ? ''
        : 'Missing official fields: ${missing.join(', ')}';
    final allBalanceFieldsMissing = [
      'Total Debt',
      'Cash & Equivalents',
      'Total Assets',
      'Current Liabilities',
    ].every(missing.contains);
    final formatLabel = statements
        .map((row) => row.formatLabel)
        .whereType<String>()
        .cast<String?>()
        .firstWhere((value) => value != null, orElse: () => null);
    if (allBalanceFieldsMissing &&
        latest != null &&
        !latest.hasBalanceSheetFacts) {
      missingReason +=
          ' — is quarter ki Integrated Filing mein balance sheet nahi hai; '
          'SEBI rule se Statement of Assets and Liabilities half-yearly '
          '(Q2/Q4) filings mein file hoti hai.';
      if (formatLabel != null) {
        missingReason += ' Filing $formatLabel format ka hai.';
      }
    }
    if (earningsBasis.isNotEmpty && missing.isNotEmpty) {
      missingReason += ' Earnings input: $earningsBasis.';
    }
    if (ebitTtmCr == null &&
        statements.isNotEmpty &&
        statements.any((row) => row.pbt != null)) {
      final withPbt = statements.where((row) => row.pbt != null).length;
      missingReason +=
          ' PBT proxy bhi incomplete hai ($withPbt/4 quarters me PBT mila).';
    }

    return _BasisRead(
      selection: selection,
      statements: statements,
      ebitTtmCr: ebitTtmCr,
      marketCapCr: yahooMarketCapCr,
      usedYahooMarketCap: usedYahooMarketCap,
      balanceSource: balanceSource,
      missingReason: missingReason,
      earningsBasis: earningsBasis,
    );
  }

  static double? _marketCapCr(
    _QuoteInfo quoteInfo,
    _NseXbrlStatement? latest, [
    double? masterFaceValue,
  ]) {
    final price = quoteInfo.lastPrice;
    if (price == null || price <= 0) return null;

    double? shares;

    // 1. Direct share count — Old Life/General-Insurance formats tag the
    // count itself (concept NumberOfShares).
    final shareCount = latest?.numberOfShares;
    if (_validShares(shareCount)) {
      shares = shareCount;
    }

    // 2/3. Paid-up equity ÷ per-share face value (₹1–₹1,000). The filing's
    // own face-value tag goes first, but ONLY when it really is a per-share
    // value: several faces put a capital total under a face-value element
    // (Bharti Airtel's filing tags the period's issued face capital), and
    // such a reading must not block the official listing-master fallback —
    // each source gets its own guarded try, never a silent bad ratio.
    final paidUpEquity = latest?.paidUpEquity;
    if (shares == null && paidUpEquity != null && paidUpEquity > 0) {
      for (final faceValue in <double?>[latest?.faceValue, masterFaceValue]) {
        if (faceValue == null || !(faceValue > 0) || faceValue > 1000) {
          continue;
        }
        final fromPaidUp = paidUpEquity / faceValue;
        if (_validShares(fromPaidUp)) {
          shares = fromPaidUp;
          break;
        }
      }
    }

    // 4. Insurance-format filings tag paid-up equity share capital but no
    // face value (SEBI Life-Insurance taxonomy has no face-value element).
    // Derive the share count from same-period official facts: profit after
    // tax and earnings per share. Never assumed, never mixed across periods.
    if (shares == null) {
      final pat = latest?.pat;
      final eps = latest?.eps;
      if (pat != null && eps != null && eps != 0) {
        final fromPatEps = pat / eps;
        if (_validShares(fromPatEps)) shares = fromPatEps;
      }
    }

    if (shares == null) return null;
    final marketCapCr = shares * price / 10000000;
    return marketCapCr.isFinite && marketCapCr > 0 ? marketCapCr : null;
  }

  /// A plausible share count: positive, below one lakh crore shares.
  static bool _validShares(double? value) =>
      value != null && value > 0 && value < 1e12;

  /// The last [count] quarter-end dates ending at [windowEnd].
  static List<DateTime> _quarterEndsEnding(DateTime windowEnd, int count) {
    final out = <DateTime>[];
    for (var i = count - 1; i >= 0; i--) {
      var month = windowEnd.month - 3 * i;
      var year = windowEnd.year;
      while (month <= 0) {
        month += 12;
        year -= 1;
      }
      out.add(DateTime(year, month + 1, 0));
    }
    return out;
  }

  /// The quarter end [quarters] quarters after [from] (negative = before).
  static DateTime _quarterEndOffset(DateTime from, int quarters) {
    var month = from.month + 3 * quarters;
    var year = from.year;
    while (month <= 0) {
      month += 12;
      year -= 1;
    }
    while (month > 12) {
      month -= 12;
      year += 1;
    }
    return DateTime(year, month + 1, 0);
  }

  /// Exact trailing-twelve-month assembly over the four quarter slots ending
  /// at [windowEnd], from official period columns only — discrete quarter
  /// columns, Hly / NineMths / Yearly columns, and comparative quarter
  /// columns. Sums and exact differences of official figures, never
  /// estimates. Returns null when the columns cannot cover the window
  /// exactly — the row then honestly reports the missing TTM input.
  ///
  /// Shapes covered (in preference order, subtraction last):
  ///  * four discrete quarter columns (the classic path);
  ///  * one longer column inside the window + quarters for the rest
  ///    (SIEMENS' feed lacks Dec-quarter rows: NineMths + Q4 works);
  ///  * one longer column spilling before the window, cancelled by the
  ///    comparative quarter column(s) + quarters for the rest
  ///    (VAML's first year: Yearly − prior-year quarter + current quarter).
  static ({double value, String label, int derived})? _assembleTtm(
    List<_NseXbrlStatement> statements, {
    required DateTime windowEnd,
    required bool usePbt,
  }) {
    final slots = _quarterEndsEnding(windowEnd, 4);

    double? quarterValue(DateTime slotEnd) {
      for (final s in statements) {
        if (s.periodEnd == slotEnd) {
          final v = usePbt ? s.pbt : s.ebit;
          if (v != null) return v;
        }
        final priorEnd = DateTime(
          slotEnd.year + 1,
          slotEnd.month,
          slotEnd.day,
        );
        if (s.periodEnd == priorEnd) {
          final v = usePbt ? s.priorQuarterPbt : s.priorQuarterEbit;
          if (v != null) return v;
        }
      }
      return null;
    }

    final columns = <({int quarters, double value, DateTime end})>[];
    for (final s in statements) {
      final cols = usePbt ? s.pbtColumns : s.ebitColumns;
      for (final entry in cols.entries) {
        columns.add((quarters: entry.key, value: entry.value, end: s.periodEnd));
      }
    }
    String columnLabel(int quarters) => switch (quarters) {
      2 => 'Hly',
      3 => 'NineMths',
      _ => 'Yearly',
    };

    // A. Four discrete quarter columns.
    final quarters = <double>[];
    var allQuarters = true;
    for (final slot in slots) {
      final v = quarterValue(slot);
      if (v == null) {
        allQuarters = false;
        break;
      }
      quarters.add(v);
    }
    if (allQuarters) {
      return (
        value: quarters.fold<double>(0, (a, b) => a + b),
        label: 'TTM = sum of 4 official quarter columns',
        derived: 0,
      );
    }

    // B. One longer column inside the window + quarters for the rest.
    // C. One longer column spilling before the window, cancelled by
    //    comparative quarter columns, + quarters for the rest.
    ({double value, String label, int derived})? best;
    for (final col in columns) {
      final endIndex = slots.indexOf(col.end);
      if (endIndex < 0 || col.quarters > 4) continue;
      final startIndex = endIndex - col.quarters + 1;
      var value = col.value;
      var derived = 0;
      var ok = true;
      var spillCount = 0;
      // Spill quarters before the window must be exactly cancelable.
      for (var i = startIndex; i < 0; i++) {
        final v = quarterValue(_quarterEndOffset(slots.first, i));
        if (v == null) {
          ok = false;
          break;
        }
        value -= v;
        derived += 1;
        spillCount += 1;
      }
      if (!ok) continue;
      var tailCount = 0;
      for (var j = 0; j < 4; j++) {
        if (j >= startIndex && j <= endIndex) continue; // covered by column
        final v = quarterValue(slots[j]);
        if (v == null) {
          ok = false;
          break;
        }
        value += v;
        tailCount += 1;
      }
      if (!ok) continue;
      final label = StringBuffer('TTM = ${columnLabel(col.quarters)}');
      if (spillCount > 0) {
        label.write(' − $spillCount prior-year quarter${spillCount == 1 ? '' : 's'}');
      }
      if (tailCount > 0) {
        label.write(' + $tailCount quarter${tailCount == 1 ? '' : 's'}');
      }
      final candidate = (
        value: value,
        label: label.toString(),
        derived: derived,
      );
      if (best == null ||
          candidate.derived < best.derived ||
          (candidate.derived == best.derived &&
              candidate.label.length < best.label.length)) {
        best = candidate;
      }
      if (best.derived == 0) return best; // prefer a subtraction-free cover
    }
    return best;
  }

  /// Yahoo Finance (unofficial) — the user-approved market-cap/price
  /// fallback for when the official chain cannot form an input. NSE (`*.NS`)
  /// and BSE (`*.BO`) tickers on Yahoo's public JSON endpoints, through the
  /// same cookie + crumb handshake its own web app uses. Non-INR quotes are
  /// refused; every failure returns null and the row stays honestly missing.
  Future<YahooQuote?> _yahooQuoteFor(MagicFormulaCandidate candidate) async {
    final symbol = _yahooSymbol(candidate);
    if (symbol == null) return null;
    final lookup = _yahooLookup;
    if (lookup != null) return lookup(symbol);
    try {
      final session = await _yahooSession();
      if (session == null) return null;
      final uri = Uri.https(
        'query1.finance.yahoo.com',
        '/v10/finance/quoteSummary/$symbol',
        {'modules': 'price', 'crumb': session.crumb},
      );
      final response = await http.get(
        uri,
        headers: {
          'User-Agent': NseMagicFormulaHttp._headers['User-Agent']!,
          'Accept': 'application/json',
          'Cookie': session.cookie,
        },
      ).timeout(const Duration(seconds: 12));
      if (response.statusCode != 200) return null;
      final decoded = jsonDecode(response.body);
      final results = (decoded['quoteSummary']?['result'] as List?) ?? const [];
      if (results.isEmpty) return null;
      final price = (results.first as Map)['price'];
      if (price is! Map) return null;
      final currency = price['currency']?.toString() ?? '';
      if (currency != 'INR') return null;
      final marketCap = _yahooRaw(price['marketCap']);
      final lastPrice = _yahooRaw(price['regularMarketPrice']);
      final asOfUnix = _yahooRaw(price['regularMarketTime']);
      return YahooQuote(
        marketCapCr: marketCap == null ? null : marketCap / 10000000,
        lastPrice: lastPrice,
        priceAsOf: asOfUnix == null
            ? null
            : DateTime.fromMillisecondsSinceEpoch(asOfUnix.toInt() * 1000),
        currency: currency,
      );
    } catch (_) {
      return null;
    }
  }

  /// Yahoo tickers follow the exchange suffix convention; an unresolvable
  /// candidate (BSE rows without a numeric code) gets no fallback at all.
  static String? _yahooSymbol(MagicFormulaCandidate candidate) {
    if (candidate.exchange == 'BSE') {
      for (final code in [candidate.symbol, candidate.dataSymbol]) {
        final trimmed = code.trim();
        if (RegExp(r'^\d{5,6}$').hasMatch(trimmed)) return '$trimmed.BO';
      }
      return null;
    }
    final symbol = candidate.symbol.trim().toUpperCase();
    if (symbol.isEmpty || !RegExp(r'^[A-Z0-9&\-]{1,25}$').hasMatch(symbol)) {
      return null;
    }
    return '$symbol.NS';
  }

  static double? _yahooRaw(Object? node) {
    if (node is num) return node.toDouble();
    if (node is Map && node['raw'] is num) {
      return (node['raw'] as num).toDouble();
    }
    return null;
  }

  /// Yahoo's JSON endpoints expect a browser cookie + crumb, exactly as its
  /// own web app fetches them. Held in memory for half a day per process.
  Future<({String cookie, String crumb})?> _yahooSession() async {
    final at = _yahooSessionAt;
    final cookie = _yahooCookie;
    final crumb = _yahooCrumb;
    if (at != null &&
        cookie != null &&
        crumb != null &&
        DateTime.now().difference(at) < const Duration(hours: 12)) {
      return (cookie: cookie, crumb: crumb);
    }
    try {
      final seed = await http
          .get(
            Uri.https('fc.yahoo.com', '/'),
            headers: {'User-Agent': NseMagicFormulaHttp._headers['User-Agent']!},
          )
          .timeout(const Duration(seconds: 12));
      final setCookie = seed.headers['set-cookie'] ?? '';
      final pairs = RegExp(r'([A-Za-z0-9._-]+=[^;,\s]+)')
          .allMatches(setCookie)
          .map((match) => match.group(1)!)
          .toList(growable: false);
      if (pairs.isEmpty) return null;
      final cookieHeader = pairs.join('; ');
      final crumbResponse = await http
          .get(
            Uri.https('query1.finance.yahoo.com', '/v1/test/getcrumb'),
            headers: {'User-Agent': NseMagicFormulaHttp._headers['User-Agent']!, 'Cookie': cookieHeader},
          )
          .timeout(const Duration(seconds: 12));
      final crumb = crumbResponse.body.trim();
      if (crumbResponse.statusCode != 200 || crumb.isEmpty || crumb.length > 32) {
        return null;
      }
      _yahooCookie = cookieHeader;
      _yahooCrumb = crumb;
      _yahooSessionAt = DateTime.now();
      return (cookie: cookieHeader, crumb: crumb);
    } catch (_) {
      return null;
    }
  }

  Future<String> _fetchXbrl(Uri uri) async {
    final isNseArchive = uri.host == 'nsearchives.nseindia.com';
    final isBseArchive = uri.host == 'www.bseindia.com';
    if (uri.scheme != 'https' || (!isNseArchive && !isBseArchive)) {
      throw const MagicFormulaSourceException(
        'XBRL link official exchange archive host par nahi hai; blocked for safety.',
      );
    }
    final body = await _request(
      uri,
      refererPath: isNseArchive ? integratedReferer : '/',
    );
    if (!body.trimLeft().startsWith('<')) {
      throw const FormatException(
        'XBRL XML ke badle HTML/empty response mila.',
      );
    }
    return body;
  }

  Future<void> _waitForRequestGap() async {
    final last = _lastRequestAt;
    if (last != null) {
      final elapsed = _clock().difference(last);
      if (elapsed < minimumRequestGap) {
        await Future<void>.delayed(minimumRequestGap - elapsed);
      }
    }
    _lastRequestAt = _clock();
  }

  Future<String> _request(Uri uri, {String? refererPath}) async {
    await _waitForRequestGap();
    return _get(uri, refererPath: refererPath);
  }

  Future<List<int>> _requestBytes(
    Uri uri, {
    String? refererPath,
  }) async {
    await _waitForRequestGap();
    return _getBytes(uri, refererPath: refererPath);
  }

  static void _requireJson(String body, String label) {
    final text = body.trimLeft();
    if (!text.startsWith('{') && !text.startsWith('[')) {
      throw FormatException('$label returned non-JSON (${_preview(body)}).');
    }
  }

  static dynamic _decodeJson(String body) => jsonDecode(body);

  static List<Map<String, dynamic>> _findRows(dynamic root) {
    if (root is List) {
      return root
          .whereType<Map>()
          .map((row) => row.cast<String, dynamic>())
          .toList();
    }
    if (root is! Map) return const [];
    // NSE's feed nests rows under `data`; BSE's API returns them under
    // `Table` (ASP.NET habit).
    for (final key in const [
      'data',
      'results',
      'items',
      'financialResults',
      'Table',
    ]) {
      final value = root[key];
      if (value is List) {
        return value
            .whereType<Map>()
            .map((row) => row.cast<String, dynamic>())
            .toList();
      }
      if (value is Map) {
        final nested = _findRows(value);
        if (nested.isNotEmpty) return nested;
      }
    }
    return const [];
  }

  static String? _findString(Map<String, dynamic> row, List<String> names) {
    final wanted = names.map(_normalKey).toSet();
    for (final entry in row.entries) {
      if (wanted.contains(_normalKey(entry.key))) {
        final value = '${entry.value ?? ''}'.trim();
        if (value.isNotEmpty && value.toLowerCase() != 'null') return value;
      }
    }
    // Some responses place XBRL under an attachment list.
    for (final value in row.values) {
      if (value is List) {
        for (final item in value.whereType<Map>()) {
          final nested = item.cast<String, dynamic>();
          final found = _findString(nested, names);
          if (found != null) return found;
        }
      }
    }
    return null;
  }

  static DateTime? _findDate(Map<String, dynamic> row, List<String> names) {
    final raw = _findString(row, names);
    return _parseDate(raw);
  }

  static String? _filingBasis(Map<String, dynamic> row) {
    for (final entry in row.entries) {
      final key = _normalKey(entry.key);
      if (!key.contains('consolidat') &&
          !key.contains('basis') &&
          !key.contains('financialstatement')) {
        continue;
      }
      final value = entry.value;
      if (value == true || value == 1) return 'Consolidated';
      if (value == false || value == 0) return 'Standalone';
      final text = '$value'.trim().toLowerCase();
      if (text.contains('consolidat') || text == 'c') return 'Consolidated';
      if (text.contains('standalone') || text == 's') return 'Standalone';
      if (text == 'true' || text == 'yes' || text == 'y') return 'Consolidated';
      if (text == 'false' || text == 'no' || text == 'n') return 'Standalone';
    }
    return null;
  }

  static Uri? _resolveArchiveUrl(String raw) {
    final value = raw.trim();
    if (value.isEmpty || value == '-') return null;
    final parsed = Uri.tryParse(value);
    if (parsed == null) return null;
    if (parsed.hasScheme) {
      // Two official archive hosts only: NSE's filing archive and BSE's
      // XBRLFILES tree. Anything else is refused, never fetched.
      if (parsed.scheme != 'https' ||
          (parsed.host != 'nsearchives.nseindia.com' &&
              parsed.host != 'www.bseindia.com')) {
        return null;
      }
      return parsed;
    }
    if (value.startsWith('/corporate/')) {
      return Uri.https('nsearchives.nseindia.com', value);
    }
    if (value.startsWith('/XBRLFILES/')) {
      return Uri.https('www.bseindia.com', value);
    }
    return null;
  }

  static _NseXbrlStatement _parseXbrl(String xml, _NseFiling filing) {
    final document = XmlDocument.parse(xml);
    final contexts = <String, _XbrlContext>{};
    for (final element in document.descendants.whereType<XmlElement>()) {
      if (element.name.local != 'context') continue;
      final id = element.getAttribute('id') ?? '';
      if (id.isEmpty) continue;
      DateTime? instant;
      DateTime? start;
      DateTime? end;
      var hasDimensions = false;
      for (final child in element.descendants.whereType<XmlElement>()) {
        switch (child.name.local) {
          case 'instant':
            instant = _parseDate(child.innerText);
            break;
          case 'startDate':
            start = _parseDate(child.innerText);
            break;
          case 'endDate':
            end = _parseDate(child.innerText);
            break;
          case 'explicitMember':
          case 'typedMember':
          case 'segment':
          case 'scenario':
            hasDimensions = true;
            break;
        }
      }
      contexts[id] = _XbrlContext(
        instant: instant,
        start: start,
        end: end,
        hasDimensions: hasDimensions,
      );
    }

    final facts = <String, Map<String, double>>{};
    // Scan every element with a contextRef, not just the root's direct
    // children: inline-XBRL documents nest the same facts inside the HTML
    // body. In inline XBRL the element name is carried by the `name`
    // attribute on `ix:nonFraction`/`ix:nonNumeric`, not the tag itself.
    // Non-numeric facts (text blocks) simply fail to parse and are skipped.
    for (final element in document.descendants.whereType<XmlElement>()) {
      final contextRef = element.getAttribute('contextRef');
      if (contextRef == null || contextRef.isEmpty) continue;
      var local = element.name.local;
      if (local == 'nonFraction' || local == 'nonNumeric') {
        final declared = element.getAttribute('name')?.trim() ?? '';
        if (declared.isEmpty) continue;
        local = declared.contains(':') ? declared.split(':').last : declared;
      }
      final value = _factValue(element);
      if (value == null) continue;
      facts.putIfAbsent(local.toLowerCase(), () => {})[contextRef] = value;
    }

    List<MapEntry<String, _XbrlContext>> balanceContextEntries() {
      // Context IDs are instance-document labels, not taxonomy constants.
      // Keep every dimensionless instant for the newest date at/before the
      // filing date: a filing can split balance-sheet facts across sibling
      // same-date contexts. Segment contexts can contain partial totals.
      final candidates = contexts.entries.where((entry) {
        final context = entry.value;
        final instant = context.instant;
        return instant != null &&
            context.start == null &&
            context.end == null &&
            !context.hasDimensions &&
            !instant.isAfter(filing.periodEnd);
      }).toList();
      candidates.sort((a, b) {
        if (a.key == b.key) return 0;
        final byDate = b.value.instant!.compareTo(a.value.instant!);
        if (byDate != 0) return byDate;
        if (a.key == 'OneI') return -1;
        if (b.key == 'OneI') return 1;
        return a.key.compareTo(b.key);
      });
      return candidates;
    }

    String? quarterContext() {
      // Select a discrete quarter duration ending on the filing date. This
      // deliberately excludes YTD/year durations; summing those across four
      // filings would inflate TTM EBIT. OneD is a tie-breaker, not a requirement.
      final candidates = contexts.entries.where((entry) {
        final context = entry.value;
        final start = context.start;
        final end = context.end;
        if (start == null ||
            end == null ||
            context.instant != null ||
            context.hasDimensions ||
            end != filing.periodEnd) {
          return false;
        }
        final days = end.difference(start).inDays + 1;
        return days >= 70 && days <= 110;
      }).toList();
      candidates.sort((a, b) {
        if (a.key == b.key) return 0;
        if (a.key == 'OneD') return -1;
        if (b.key == 'OneD') return 1;
        final aDays = a.value.end!.difference(a.value.start!).inDays + 1;
        final bDays = b.value.end!.difference(b.value.start!).inDays + 1;
        final byLength = (aDays - 90).abs().compareTo((bDays - 90).abs());
        if (byLength != 0) return byLength;
        return a.key.compareTo(b.key);
      });
      return candidates.isEmpty ? null : candidates.first.key;
    }

    final bsContextEntries = balanceContextEntries();
    final balanceDate = bsContextEntries.isEmpty
        ? null
        : bsContextEntries.first.value.instant;
    final bsContextIds = bsContextEntries
        .where((entry) => entry.value.instant == balanceDate)
        .map((entry) => entry.key)
        .toList(growable: false);
    final qContext = quarterContext();
    final periodContext = qContext == null ? null : contexts[qContext];
    final quarterEnd = periodContext?.end ?? filing.periodEnd;

    double? fact(Iterable<String> tags, String? context) {
      if (context == null) return null;
      for (final tag in tags) {
        final found = facts[tag.toLowerCase()]?[context];
        if (found != null) return found;
      }
      return null;
    }

    double? factAcross(Iterable<String> tags, Iterable<String> contextIds) {
      for (final context in contextIds) {
        final value = fact(tags, context);
        if (value != null) return value;
      }
      return null;
    }

    /// Presence probe over every context (dimensioned included) — used to
    /// tell "concept absent from the document" apart from "not on the
    /// selected contexts".
    double? factAnywhere(Iterable<String> tags) {
      for (final tag in tags) {
        final byContext = facts[tag.toLowerCase()];
        if (byContext != null && byContext.isNotEmpty) {
          return byContext.values.first;
        }
      }
      return null;
    }

    // ---- Filing-format detection -------------------------------------
    // SEBI integrated filing uses per-segment taxonomies whose element
    // names differ from the IndAS generic set (NSE "XBRL Information" —
    // IndAS, other-than-bank, Banking, NBFC, General/Life Insurance).
    // Markers below are taxonomy-exclusive local names, verified against
    // the official SEBI taxonomy packages (BSE downloads) and BSE-hosted
    // sample instances (IFBanking/IFNBFC documents).
    final allInstantIds = contexts.entries
        .where(
          (entry) =>
              entry.value.instant != null &&
              entry.value.start == null &&
              entry.value.end == null &&
              !entry.value.hasDimensions,
        )
        .map((entry) => entry.key)
        .toList(growable: false);
    final allDurationIds = contexts.entries
        .where(
          (entry) =>
              entry.value.start != null &&
              entry.value.end != null &&
              entry.value.instant == null &&
              !entry.value.hasDimensions,
        )
        .map((entry) => entry.key)
        .toList(growable: false);

    final isBankingFormat =
        factAcross(const [
          'CapitalAndLiabilities',
          'CashAndBalancesWithReserveBankOfIndia',
          'OtherLiabilitiesAndProvisions',
        ], allInstantIds) !=
            null ||
        factAcross(const [
          'InterestExpended',
          'OperatingProfitBeforeProvisionAndContingencies',
        ], allDurationIds) !=
            null;
    final isNbfcFormat =
        factAcross(const [
          'FinancialLiabilities',
          'NonFinancialLiabilities',
          'SubordinatedLiabilities',
          'DebtSecurities',
        ], allInstantIds) !=
            null;
    final isInsuranceFormat =
        factAcross(const [
          'PolicyLiabilities',
          'PolicyholdersFunds',
          'ShareholdersFunds',
          'CashAndBankBalances',
        ], allInstantIds) !=
            null;
    final formatLabel = isBankingFormat
        ? 'Banking'
        : isNbfcFormat
        ? 'NBFC'
        : isInsuranceFormat
        ? 'Insurance'
        : null;

    // ---- Earnings input ---------------------------------------------
    // Preferred: the filing's own EBIT-equivalent. The PBT proxy (approved
    // for banking/insurance/NBFC formats that tag no EBIT element) is
    // resolved in _readBasis across the four quarters and its basis is
    // shown in the row/skip note.
    const ebitTags = [
      'ProfitBeforeExceptionalItemsAndTax',
      'ProfitBeforeExceptionalAndExtraordinaryItemsAndTax',
      'EarningsBeforeInterestAndTaxes',
      'EBIT',
    ];
    const pbtTags = [
      'ProfitBeforeTax',
      'ProfitLossFromOrdinaryActivitiesBeforeTax',
      'ProfitLossBeforeTax',
      'ProfitBeforeExtraordinaryItemsAndTax',
      'ProfitOrLossBeforeTax',
      'ProfitOrLossBeforeExtraordinaryItems',
      'ProfitBeforeExceptionalItemsAndTax',
    ];
    const assetsTags = [
      'Assets',
      'EquityAndLiabilities',
      'TotalAssets',
      'CapitalAndLiabilities',
    ];
    const currentLiabilitiesTags = [
      'CurrentLiabilities',
      'TotalCurrentLiabilities',
      'CurrentLiabilitiesAndProvisions',
    ];
    // A generic `Borrowings` fact may represent only the non-current line in
    // IndAS statements. Require an explicit total, or both current and
    // non-current components — unless the document is in a financial
    // (banking/NBFC/insurance) format, whose faces carry `Borrowings` as
    // the total line (verified on official SEBI taxonomies + BSE samples).
    // Also accepts the Reg 30 "total financial indebtedness" disclosure
    // element (Life/General-Insurance integrated taxonomies) — an official
    // total that needs no component assembly.
    const totalDebtTags = [
      'TotalBorrowings',
      'TotalDebt',
      'AmountOfTotalFinancialIndebtednessOfTheListedEntityIncludingShortTermAndLongTermDebtAtTheEndOfPeriod',
    ];
    const currentDebtTags = [
      'CurrentBorrowings',
      'ShortTermBorrowings',
      'BorrowingsCurrent',
    ];
    const noncurrentDebtTags = [
      'NoncurrentBorrowings',
      'LongTermBorrowings',
      'BorrowingsNoncurrent',
    ];
    const cashTags = [
      'CashAndCashEquivalents',
      'CashAndCashEquivalentsAndBankBalances',
      'CashAndCashEquivalentsIncludingBankBalances',
      'CashAndCashEquivalentsCashFlowStatement',
      'CashAndBalancesWithReserveBankOfIndia',
      'CashAndBankBalances',
      'BankBalanceOtherThanCashAndCashEquivalents',
      'CashOnHand',
    ];
    const paidUpTags = [
      'PaidUpValueOfEquityShareCapital',
      'PaidUpEquityShareCapital',
      'PaidUpShareCapital',
      'EquityShareCapital',
      'PaidUpEquityCapital',
      'ShareCapital',
    ];
    const faceValueTags = [
      'FaceValueOfEquityShareCapital',
      'EquityShareFaceValue',
      'FaceValueOfEquityShare',
    ];
    const epsTags = [
      'EarningPerShare',
      'EarningsPerShare',
      'BasicEarningsPerShareAfterExtraordinaryItems',
      'BasicEarningsPerShare',
    ];
    const patTags = [
      'ProfitLossAfterTaxBeforeExtraordinaryItems',
      'NetProfitAfterTax',
      'ProfitLossAfterTaxAndExtraordinaryItems',
      'ProfitLossForThePeriod',
      'ProfitLossForPeriod',
      'ProfitLossAfterTax',
    ];

    final ebit = fact(ebitTags, qContext);
    final pbt = fact(pbtTags, qContext);

    // Official longer period columns (Hly / NineMths / Yearly faces) ending
    // at the filing period end, and the comparative quarter column ending
    // one year earlier — the raw material for exact TTM assembly when the
    // feed's quarter rows have gaps (a September fiscal year's December
    // quarters are absent from BSE's integrated feed) or fewer than four
    // quarter rows exist (a newly listed demerged entity).
    Map<int, double> columnsFor(Iterable<String> tags) {
      final out = <int, double>{};
      for (final id in allDurationIds) {
        final context = contexts[id];
        final start = context?.start;
        final end = context?.end;
        if (context == null ||
            start == null ||
            end == null ||
            context.hasDimensions ||
            end != filing.periodEnd) {
          continue;
        }
        final days = end.difference(start).inDays + 1;
        final quarters = switch (days) {
          >= 150 && <= 215 => 2,
          >= 235 && <= 305 => 3,
          >= 330 && <= 400 => 4,
          _ => 0,
        };
        if (quarters == 0 || out.containsKey(quarters)) continue;
        final value = fact(tags, id);
        if (value != null) out[quarters] = value;
      }
      return out;
    }

    double? comparativeQuarterFor(Iterable<String> tags) {
      final priorEnd = DateTime(
        filing.periodEnd.year - 1,
        filing.periodEnd.month,
        filing.periodEnd.day,
      );
      for (final id in allDurationIds) {
        final context = contexts[id];
        final start = context?.start;
        final end = context?.end;
        if (context == null ||
            start == null ||
            end == null ||
            context.hasDimensions ||
            end != priorEnd) {
          continue;
        }
        final days = end.difference(start).inDays + 1;
        if (days < 70 || days > 110) continue;
        final value = fact(tags, id);
        if (value != null) return value;
      }
      return null;
    }

    final ebitColumns = columnsFor(ebitTags);
    final pbtColumns = columnsFor(pbtTags);
    final priorQuarterEbit = comparativeQuarterFor(ebitTags);
    final priorQuarterPbt = comparativeQuarterFor(pbtTags);

    final assets = factAcross(assetsTags, bsContextIds);
    final cash = factAcross(cashTags, bsContextIds);
    final paidUpEquity =
        factAcross(paidUpTags, bsContextIds) ?? fact(paidUpTags, qContext);
    final faceValue =
        factAcross(faceValueTags, bsContextIds) ??
        fact(faceValueTags, qContext);
    // Old Life/General-Insurance formats tag the share count itself — the
    // most direct market-cap input (no face-value or PAT/EPS derivation).
    final numberOfShares =
        factAcross(const ['NumberOfShares'], bsContextIds) ??
        fact(const ['NumberOfShares'], qContext);
    double? eps = fact(epsTags, qContext);
    double? pat = fact(patTags, qContext);
    if (eps == null || pat == null) {
      // Share count from pat/eps needs BOTH facts on the SAME period. Some
      // utilities tag the pair only on the year-to-date context — accept any
      // single duration context that carries both (never a mixed pair).
      for (final id in allDurationIds) {
        if (id == qContext) continue;
        final e = fact(epsTags, id);
        final p = fact(patTags, id);
        if (e != null && p != null) {
          eps = e;
          pat = p;
          break;
        }
      }
    }

    // ---- Total debt --------------------------------------------------
    double? totalDebt =
        factAcross(totalDebtTags, bsContextIds) ??
        _sumIfBoth(
          factAcross(currentDebtTags, bsContextIds),
          factAcross(noncurrentDebtTags, bsContextIds),
        );
    if (totalDebt == null && (isBankingFormat || isNbfcFormat || isInsuranceFormat)) {
      // Financial-format faces list the interest-bearing lines directly:
      // NBFC — Debt Securities + Borrowings (other than debt securities) +
      // Subordinated Liabilities; Banking/Insurance — one Borrowings line.
      final borrowings = factAcross(const ['Borrowings'], bsContextIds);
      final debtSecurities = factAcross(const ['DebtSecurities'], bsContextIds);
      final subordinated = factAcross(
        const ['SubordinatedLiabilities'],
        bsContextIds,
      );
      if (isNbfcFormat) {
        final parts = <double>[
          if (borrowings != null) borrowings,
          if (debtSecurities != null) debtSecurities,
          if (subordinated != null) subordinated,
        ];
        if ((borrowings != null || debtSecurities != null) && parts.isNotEmpty) {
          totalDebt = parts.fold<double>(0, (sum, value) => sum + value);
        }
      } else if (borrowings != null) {
        totalDebt = borrowings;
      }
    }
    if (totalDebt == null) {
      // Some filers tag only one side of the borrowings pair (typically just
      // the non-current line). A single side may serve as total debt only
      // when the counterpart concept is absent from the whole document —
      // then it is not a hidden value; the filer simply has no such line.
      final cur = factAcross(currentDebtTags, bsContextIds);
      final non = factAcross(noncurrentDebtTags, bsContextIds);
      if (cur != null && factAnywhere(noncurrentDebtTags) == null) {
        totalDebt = cur;
      } else if (non != null && factAnywhere(currentDebtTags) == null) {
        totalDebt = non;
      }
    }

    // ---- Current liabilities ----------------------------------------
    double? currentLiabilities = factAcross(
      currentLiabilitiesTags,
      bsContextIds,
    );
    if (currentLiabilities == null) {
      if (isBankingFormat) {
        // Banking Schedule: no current/non-current totals. The formula's
        // "current liabilities" takes the non-borrowing funding lines
        // (Deposits + Other Liabilities and Provisions); capital employed
        // then equals Capital + Reserves + Borrowings.
        final deposits = factAcross(const ['Deposits'], bsContextIds);
        final otherLiabilities = factAcross(
          const ['OtherLiabilitiesAndProvisions'],
          bsContextIds,
        );
        if (deposits != null || otherLiabilities != null) {
          currentLiabilities = (deposits ?? 0) + (otherLiabilities ?? 0);
        }
      } else if (isNbfcFormat && totalDebt != null) {
        // NBFC face splits liabilities Financial/Non-financial, not
        // current/non-current. Everything outside the interest-bearing
        // debt lines (payables, provisions, deposits, tax, other) plays
        // the formula's "current liabilities" role: total liabilities
        // minus total debt.
        final liab = factAcross(const ['Liabilities'], bsContextIds);
        final fin = factAcross(const ['FinancialLiabilities'], bsContextIds);
        final nonFin = factAcross(
          const ['NonFinancialLiabilities'],
          bsContextIds,
        );
        final totalLiab = liab ??
            ((fin != null || nonFin != null) ? (fin ?? 0) + (nonFin ?? 0) : null);
        if (totalLiab != null && totalLiab >= totalDebt) {
          currentLiabilities = totalLiab - totalDebt;
        }
      }
      if (currentLiabilities == null) {
        // Schedule identity used by insurance (and older) faces: net current
        // assets = current assets − current liabilities and provisions. Both
        // face totals are official facts; only their difference is derived.
        final currentAssets = factAcross(const ['CurrentAssets'], bsContextIds);
        final netCurrent = factAcross(const ['NetCurrentAssets'], bsContextIds);
        if (currentAssets != null && netCurrent != null) {
          final derived = currentAssets - netCurrent;
          if (derived >= 0 && derived <= currentAssets) {
            currentLiabilities = derived;
          }
        }
      }
    }

    // SEBI Reg 33(3)(f): the Statement of Assets and Liabilities is filed
    // half-yearly, so a quarter filing (Q1/Q3) can contain no balance-sheet
    // fact at all. Record whether this document has any balance-sheet fact
    // anywhere (even on a non-selected instant date) so the scan can tell
    // "quarter filing without a balance sheet" apart from a stale-dated
    // balance sheet — which is still refused below.
    final hasBalanceSheetFacts =
        factAcross(assetsTags, allInstantIds) != null ||
        factAcross(currentLiabilitiesTags, allInstantIds) != null ||
        factAcross(const [
              'TotalBorrowings',
              'TotalDebt',
              'Borrowings',
              'DebtSecurities',
              'SubordinatedLiabilities',
              'Deposits',
              'OtherLiabilitiesAndProvisions',
              'FinancialLiabilities',
              'NonFinancialLiabilities',
              'Liabilities',
              'PolicyLiabilities',
              'PolicyholdersFunds',
            ], allInstantIds) !=
            null ||
        factAcross(currentDebtTags, allInstantIds) != null ||
        factAcross(noncurrentDebtTags, allInstantIds) != null ||
        factAcross(cashTags, allInstantIds) != null;

    final actualStart = periodContext?.start;

    return _NseXbrlStatement(
      periodStart: actualStart,
      periodEnd: quarterEnd,
      balanceSheetDate: balanceDate,
      ebit: ebit,
      pbt: pbt,
      ebitColumns: ebitColumns,
      pbtColumns: pbtColumns,
      priorQuarterEbit: priorQuarterEbit,
      priorQuarterPbt: priorQuarterPbt,
      totalAssets: assets,
      currentLiabilities: currentLiabilities,
      totalDebt: totalDebt,
      cash: cash,
      paidUpEquity: paidUpEquity,
      faceValue: faceValue,
      numberOfShares: numberOfShares,
      eps: eps,
      pat: pat,
      formatLabel: formatLabel,
      hasBalanceSheetFacts: hasBalanceSheetFacts,
    );
  }

  static MagicFormulaFundamental _missing(
    MagicFormulaCandidate candidate,
    DateTime at,
    String reason, {
    String source = 'NSE filings',
  }) => MagicFormulaFundamental(
    candidate: candidate,
    fetchedAt: at,
    source: source,
    missingReason: reason,
  );

  static List<NseMagicBhavcopyQuote> parseBhavcopyCsv(String csv) {
    final rows = _parseCsv(csv);
    if (rows.length < 2) return const [];
    final headers = rows.first.map(_normalKey).toList(growable: false);
    final dateIndex = _indexOf(headers, const ['tradDt', 'tradeDate']);
    final isinIndex = _indexOf(headers, const ['isin']);
    final symbolIndex = _indexOf(headers, const ['tckrSymb', 'symbol']);
    final seriesIndex = _indexOf(headers, const ['sctySrs', 'series']);
    final closeIndex = _indexOf(headers, const [
      'clsPric',
      'closePrice',
      'close',
    ]);
    final instrumentTypeIndex = _indexOf(headers, const [
      'finInstrmTp',
      'instrumentType',
    ]);
    final securityIdIndex = _indexOf(headers, const [
      'finInstrmId',
      'scCode',
      'securityId',
    ]);
    if ([dateIndex, symbolIndex, seriesIndex, closeIndex].any((i) => i < 0)) {
      return const [];
    }

    // NSE UDiFF series: EQ/BE/BZ/SM/ST are cash-equity groups, RR is the
    // series for listed REITs (BIRET/EMBASSY/BAGMANE), IV for InvITs; BSE's
    // same-format report labels cash equity by group (A/B/T/…) and lists
    // REIT/InvIT units under IF. Both files are accepted — each only ever
    // contains its own exchange's labels. Debt/govt/ETF series (GS/GB/TB,
    // N0–NZ, …) stay out.
    const allowedSeries = {
      'EQ',
      'BE',
      'BZ',
      'SM',
      'ST',
      'IL',
      'RR',
      'IV',
      'A',
      'B',
      'T',
      'MT',
      'IF',
    };
    final quotes = <NseMagicBhavcopyQuote>[];
    for (final row in rows.skip(1)) {
      String field(int index) =>
          index < 0 || index >= row.length ? '' : row[index].trim();
      final tradeDate = _parseDate(field(dateIndex));
      final symbol = field(symbolIndex).toUpperCase();
      final isin = field(isinIndex).toUpperCase();
      final series = field(seriesIndex).toUpperCase();
      final instrumentType = field(instrumentTypeIndex).toUpperCase();
      final close = _number(field(closeIndex));
      if (tradeDate == null ||
          symbol.isEmpty ||
          !allowedSeries.contains(series) ||
          (instrumentType.isNotEmpty &&
              instrumentType != 'STK' &&
              instrumentType != 'EQUITY') ||
          close == null ||
          close <= 0) {
        continue;
      }
      quotes.add(
        NseMagicBhavcopyQuote(
          tradeDate: tradeDate,
          symbol: symbol,
          isin: isin,
          series: series,
          closePrice: close,
          securityId: field(securityIdIndex),
        ),
      );
    }
    return quotes;
  }

  static List<MagicFormulaCandidate> parseIndexCsv(String csv) {
    final rows = _parseCsv(csv);
    if (rows.length < 2) return const [];
    final headers = rows.first.map(_normalKey).toList(growable: false);
    final symbolIndex = _indexOf(headers, const ['symbol', 'tradingsymbol']);
    if (symbolIndex < 0) return const [];
    final nameIndex = _indexOf(headers, const ['companyname', 'company']);
    final industryIndex = _indexOf(headers, const [
      'industry',
      'sector',
      'basicindustry',
    ]);
    final isinIndex = _indexOf(headers, const ['isincode', 'isin']);
    final output = <MagicFormulaCandidate>[];
    final seen = <String>{};
    for (final row in rows.skip(1)) {
      String field(int index) =>
          index < 0 || index >= row.length ? '' : row[index].trim();
      final symbol = field(symbolIndex).toUpperCase();
      if (symbol.isEmpty) continue;
      final isin = field(isinIndex).toUpperCase();
      final identity = isin.isEmpty ? symbol : isin;
      if (!seen.add(identity)) continue;
      final industry = field(industryIndex);
      output.add(
        MagicFormulaCandidate(
          symbol: symbol,
          companyName: field(nameIndex).isEmpty ? symbol : field(nameIndex),
          exchange: 'NSE',
          industry: industry,
          sector: mapSector(industry),
          isin: isin,
          dataSymbol: symbol,
          dataCompanyName: field(nameIndex),
        ),
      );
    }
    return output;
  }

  static List<List<String>> _parseCsv(String source) {
    final text = source.replaceFirst('\uFEFF', '');
    final rows = <List<String>>[];
    var row = <String>[];
    final field = StringBuffer();
    var quoted = false;
    for (var index = 0; index < text.length; index++) {
      final char = text[index];
      if (char == '"') {
        if (quoted && index + 1 < text.length && text[index + 1] == '"') {
          field.write('"');
          index++;
        } else {
          quoted = !quoted;
        }
      } else if (!quoted && char == ',') {
        row.add(field.toString().trim());
        field.clear();
      } else if (!quoted && (char == '\n' || char == '\r')) {
        if (char == '\r' &&
            index + 1 < text.length &&
            text[index + 1] == '\n') {
          index++;
        }
        row.add(field.toString().trim());
        field.clear();
        if (row.any((value) => value.isNotEmpty)) rows.add(row);
        row = <String>[];
      } else {
        field.write(char);
      }
    }
    if (field.isNotEmpty || row.isNotEmpty) {
      row.add(field.toString().trim());
      if (row.any((value) => value.isNotEmpty)) rows.add(row);
    }
    return rows;
  }

  static int _indexOf(List<String> headers, List<String> candidates) {
    for (final candidate in candidates) {
      final index = headers.indexOf(_normalKey(candidate));
      if (index >= 0) return index;
    }
    return -1;
  }

  static List<MagicFormulaCandidate> _decodeCandidateCache(String raw) {
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return const [];
      return [
        for (final item in decoded.whereType<Map>())
          MagicFormulaCandidate(
            symbol: '${item['symbol'] ?? ''}',
            companyName: '${item['companyName'] ?? ''}',
            exchange: '${item['exchange'] ?? 'NSE'}',
            sector: '${item['sector'] ?? ''}',
            industry: '${item['industry'] ?? ''}',
            isin: '${item['isin'] ?? ''}',
            dataSymbol: '${item['dataSymbol'] ?? ''}',
            dataCompanyName: '${item['dataCompanyName'] ?? ''}',
          ),
      ];
    } catch (_) {
      return const [];
    }
  }

  static Map<String, Object?> _candidateJson(MagicFormulaCandidate row) => {
    'symbol': row.symbol,
    'companyName': row.companyName,
    'exchange': row.exchange,
    'sector': row.sector,
    'industry': row.industry,
    'isin': row.isin,
    'dataSymbol': row.dataSymbol,
    'dataCompanyName': row.dataCompanyName,
  };

  static String mapSector(String industry) {
    final value = industry.toLowerCase();
    if (value.contains('public sector bank') || value.contains('psu bank')) {
      return 'PSU Banks';
    }
    if (value.contains('bank')) return 'Banking';
    if (value.contains('information technology') ||
        value.contains('software') ||
        value.contains('it services')) {
      return 'IT';
    }
    if (value.contains('pharma') ||
        value.contains('pharmaceutical') ||
        value.contains('drug')) {
      return 'Pharma';
    }
    if (value.contains('automobile') ||
        value.contains('auto component') ||
        value.contains('auto ancillary')) {
      return 'Auto';
    }
    if (value.contains('fmcg') ||
        value.contains('fast moving consumer') ||
        value.contains('personal care')) {
      return 'FMCG';
    }
    if (value.contains('metal') || value.contains('mining')) return 'Metals';
    if (value.contains('oil') ||
        value.contains('gas') ||
        value.contains('energy')) {
      return 'Energy';
    }
    if (value.contains('realty') || value.contains('real estate')) {
      return 'Realty';
    }
    if (value.contains('financial service') ||
        value.contains('finance') ||
        value.contains('nbfc') ||
        value.contains('insurance')) {
      return 'Financial Services';
    }
    if (value.contains('healthcare')) return 'Healthcare';
    if (value.contains('capital goods')) return 'Capital Goods';
    if (value.contains('construction materials')) {
      return 'Construction Materials';
    }
    if (value.contains('consumer services')) return 'Consumer Services';
    if (value == 'services' || value.endsWith(' services')) return 'Services';
    if (value.contains('infrastructure') || value.contains('construction')) {
      return 'Infrastructure';
    }
    if (value.contains('chemical')) return 'Chemicals';
    if (value.contains('consumer durables') ||
        value.contains('durable goods')) {
      return 'Consumer Durables';
    }
    if (value.contains('media') || value.contains('entertainment')) {
      return 'Media';
    }
    if (value.contains('telecom') || value.contains('telecommunication')) {
      return 'Telecom';
    }
    if (value.contains('power') || value.contains('electric utilities')) {
      return 'Power';
    }
    return '';
  }

  static String _normalizedCompanyName(String raw) => raw
      .toUpperCase()
      .replaceAll(RegExp(r'[^A-Z0-9 ]'), ' ')
      .replaceAll(
        RegExp(r'\b(LIMITED|LTD|CORPORATION|CORP|COMPANY|CO|PLC)\b'),
        ' ',
      )
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();

  static bool _isNonCommonInstrument(Scrip scrip) {
    final symbol = scrip.symbol.toUpperCase();
    final name = scrip.name.toUpperCase();
    if (RegExp(r'-(SM|ST)$').hasMatch(symbol)) return true;
    const markers = [
      ' ETF',
      ' EXCHANGE TRADED FUND',
      ' MUTUAL FUND',
      ' SOVEREIGN GOLD BOND',
      ' SGB ',
    ];
    return markers.any((marker) => name.contains(marker)) ||
        symbol.contains('BEES') ||
        symbol.contains('GOLDCASE') ||
        symbol.contains('LIQUIDCASE');
  }

  static String _normalKey(String value) =>
      value.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

  static double? _number(Object? value) {
    if (value is num) {
      final number = value.toDouble();
      return number.isFinite ? number : null;
    }
    if (value == null) return null;
    var text = '$value'
        .trim()
        .replaceAll(',', '')
        .replaceAll('−', '-') // unicode minus in rendered facts
        .replaceAll(RegExp(r'[₹$]|Rs\.?\s*', caseSensitive: false), '')
        .replaceAll(RegExp(r'\s+'), '');
    // Accounting negatives like (13.47) in rendered inline-XBRL facts.
    final parenthesised = RegExp(r'^\((.*)\)$').firstMatch(text);
    if (parenthesised != null) {
      text = '-${parenthesised.group(1)!}';
    }
    if (text.isEmpty || text == '-' || text.toLowerCase() == 'null') {
      return null;
    }
    final number = double.tryParse(text);
    return number != null && number.isFinite ? number : null;
  }

  /// Inline-XBRL facts carry `scale` (value × 10^scale) and `sign='-'`
  /// refinements on the visible text; plain instances have neither. Honour
  /// both so scaled iXBRL documents read back the same rupee values as their
  /// plain-XML siblings.
  static double? _factValue(XmlElement element) {
    final value = _number(element.innerText);
    if (value == null) return null;
    var scaled = value;
    final scaleRaw = element.getAttribute('scale')?.trim();
    if (scaleRaw != null && scaleRaw.isNotEmpty) {
      final scale = int.tryParse(scaleRaw);
      if (scale == null) return null;
      scaled = value * math.pow(10, scale).toDouble();
    }
    if (element.getAttribute('sign')?.trim() == '-') scaled = -scaled;
    return scaled.isFinite ? scaled : null;
  }

  static DateTime? _parseDate(String? raw) {
    if (raw == null || raw.trim().isEmpty || raw.trim() == '-') return null;
    final text = raw.trim();
    final iso = DateTime.tryParse(text);
    if (iso != null) return DateTime(iso.year, iso.month, iso.day);
    final matched = RegExp(
      r'^(\d{1,2})[- /]([A-Za-z]{3,9}|\d{1,2})[- /](\d{4})$',
    ).firstMatch(text);
    if (matched == null) return null;
    final day = int.tryParse(matched.group(1)!);
    final monthRaw = matched.group(2)!;
    final year = int.tryParse(matched.group(3)!);
    const months = {
      'jan': 1,
      'feb': 2,
      'mar': 3,
      'apr': 4,
      'may': 5,
      'jun': 6,
      'jul': 7,
      'aug': 8,
      'sep': 9,
      'oct': 10,
      'nov': 11,
      'dec': 12,
    };
    final month =
        int.tryParse(monthRaw) ??
        months[monthRaw.substring(0, 3).toLowerCase()];
    if (day == null || month == null || year == null) return null;
    return DateTime(year, month, day);
  }

  static double? _sumIfBoth(double? a, double? b) =>
      a == null || b == null ? null : a + b;

  static String _dateLabel(DateTime date) =>
      '${date.day.toString().padLeft(2, '0')}-'
      '${_monthName(date.month)}-${date.year}';

  static String _monthName(int month) => const [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ][month - 1];

  static String _shortError(Object error) {
    var text = '$error'
        .replaceFirst('Exception: ', '')
        .replaceFirst('FormatException: ', '')
        .replaceFirst('ClientException: ', '');
    text = text.split('\n').first.trim();
    if (text.length > 120) text = '${text.substring(0, 120)}…';
    return text;
  }

  static String _preview(String body) {
    final text = body.trim().replaceAll(RegExp(r'\s+'), ' ');
    return text.length <= 50 ? text : '${text.substring(0, 50)}…';
  }

  static DateTime _dateOnly(DateTime date) =>
      DateTime(date.year, date.month, date.day);
}

@immutable
class NseMagicBhavcopyQuote {
  const NseMagicBhavcopyQuote({
    required this.tradeDate,
    required this.symbol,
    required this.isin,
    required this.series,
    required this.closePrice,
    this.securityId = '',
  });

  final DateTime tradeDate;
  final String symbol;
  final String isin;
  final String series;
  final double closePrice;

  /// UDiFF `FinInstrmId` — on BSE's report this is the six-digit scrip code.
  final String securityId;
}

@immutable
class _NseBhavcopySnapshot {
  _NseBhavcopySnapshot(List<NseMagicBhavcopyQuote> quotes)
    : tradeDate = quotes.first.tradeDate,
      _byIsin = {
        for (final quote in quotes)
          if (quote.isin.isNotEmpty) quote.isin.toUpperCase(): quote,
      },
      _bySymbol = {
        for (final quote in quotes) quote.symbol.toUpperCase(): quote,
      },
      _bySecurityId = {
        for (final quote in quotes)
          if (quote.securityId.isNotEmpty)
            quote.securityId.toUpperCase(): quote,
      };

  final DateTime tradeDate;
  final Map<String, NseMagicBhavcopyQuote> _byIsin;
  final Map<String, NseMagicBhavcopyQuote> _bySymbol;
  final Map<String, NseMagicBhavcopyQuote> _bySecurityId;

  NseMagicBhavcopyQuote? priceFor(MagicFormulaCandidate candidate) {
    final isin = candidate.isin.trim().toUpperCase();
    if (isin.isNotEmpty) {
      final byIsin = _byIsin[isin];
      if (byIsin != null) return byIsin;
    }
    final symbol = _normLookupSymbol(
      candidate.dataSymbol.isEmpty ? candidate.symbol : candidate.dataSymbol,
    );
    final bySymbol = _bySymbol[symbol];
    if (bySymbol != null) return bySymbol;
    // BSE-only candidates carry the numeric scrip code as the symbol while
    // the report lists the alphabetic ticker — match the code column too.
    final byCode = _bySecurityId[symbol];
    if (byCode != null) return byCode;
    // The stored row's own symbol is the last key to try: a basket member
    // can carry a stale data symbol while its ticker still matches the
    // report.
    final fallback = _normLookupSymbol(candidate.symbol);
    return _bySymbol[fallback] ?? _bySecurityId[fallback];
  }

  /// The report's own security id (BSE: six-digit scrip code) for this
  /// candidate — by symbol or by ISIN. Null when the row is not in the file.
  String? securityIdFor(MagicFormulaCandidate candidate) {
    final isin = candidate.isin.trim().toUpperCase();
    if (isin.isNotEmpty) {
      final byIsin = _byIsin[isin];
      if (byIsin != null && byIsin.securityId.isNotEmpty) {
        return byIsin.securityId;
      }
    }
    String? idOf(String key) {
      final quote = _bySymbol[key] ?? _bySecurityId[key];
      final id = quote?.securityId ?? '';
      return id.isEmpty ? null : id;
    }

    final symbol = _normLookupSymbol(
      candidate.dataSymbol.isEmpty ? candidate.symbol : candidate.dataSymbol,
    );
    return idOf(symbol) ?? idOf(_normLookupSymbol(candidate.symbol));
  }

  /// Broker masters suffix symbols with segment/exchange tags (`-EQ`, `.BSE`)
  /// while the official report lists the bare ticker — normalise both sides
  /// so a stored basket row still finds its official line.
  static String _normLookupSymbol(String value) {
    var s = value.trim().toUpperCase();
    final dot = s.indexOf('.');
    if (dot > 0) s = s.substring(0, dot);
    s = s.replaceAll(RegExp(r'-(EQ|BE|BZ|SM|ST|IL)$'), '');
    return s.trim();
  }
}

@immutable
class _QuoteInfo {
  const _QuoteInfo({required this.lastPrice, required this.priceAsOf});

  final double? lastPrice;
  final DateTime? priceAsOf;
}

@immutable
class _NseFiling {
  const _NseFiling({
    required this.xbrlUrl,
    required this.periodEnd,
    required this.basis,
    this.filedAt,
  });
  final Uri xbrlUrl;
  final DateTime periodEnd;
  final String basis;
  final DateTime? filedAt;
}

@immutable
class _SelectedFilings {
  const _SelectedFilings(this.basis, this.filings);
  final String basis;
  final List<_NseFiling> filings;
}

@immutable
class _BasisRead {
  const _BasisRead({
    required this.selection,
    required this.statements,
    required this.ebitTtmCr,
    required this.marketCapCr,
    required this.balanceSource,
    required this.missingReason,
    this.usedYahooMarketCap = false,
    this.earningsBasis = '',
  });

  final _SelectedFilings selection;
  final List<_NseXbrlStatement> statements;
  final double? ebitTtmCr;
  final double? marketCapCr;

  /// True when [marketCapCr] came from the labeled Yahoo fallback rather
  /// than the official chain — the row source must then say so.
  final bool usedYahooMarketCap;

  /// '' = TTM EBIT from the filing's own EBIT tag; otherwise a disclosed
  /// substitute basis such as 'PBT proxy (EBIT not tagged)'.
  final String earningsBasis;

  /// Statement that supplies the balance-sheet inputs and the displayed
  /// balance-sheet date. Usually the newest statement; falls back to the
  /// newest half-year filing that actually carries a balance sheet.
  final _NseXbrlStatement? balanceSource;
  final String missingReason;

  _NseXbrlStatement? get latest => statements.isEmpty ? null : statements.first;

  int get completeness {
    final row = balanceSource;
    return [
      ebitTtmCr,
      marketCapCr,
      row?.totalDebt,
      row?.cash,
      row?.totalAssets,
      row?.currentLiabilities,
    ].where((value) => value != null).length;
  }

  bool get isComplete => missingReason.isEmpty && completeness == 6;
}

@immutable
class _NseXbrlStatement {
  const _NseXbrlStatement({
    required this.periodStart,
    required this.periodEnd,
    required this.balanceSheetDate,
    required this.ebit,
    required this.pbt,
    required this.ebitColumns,
    required this.pbtColumns,
    required this.priorQuarterEbit,
    required this.priorQuarterPbt,
    required this.totalAssets,
    required this.currentLiabilities,
    required this.totalDebt,
    required this.cash,
    required this.paidUpEquity,
    required this.faceValue,
    required this.numberOfShares,
    required this.eps,
    required this.pat,
    required this.formatLabel,
    required this.hasBalanceSheetFacts,
  });
  final DateTime? periodStart;
  final DateTime periodEnd;
  final DateTime? balanceSheetDate;
  final double? ebit;
  final double? pbt;

  /// Official longer period columns ending at [periodEnd] (SEBI Hly /
  /// NineMths / Yearly faces), keyed by the number of quarters they cover
  /// (2–4). Raw material for exact TTM assembly when the feed's quarter rows
  /// have gaps or fewer than four exist.
  final Map<int, double> ebitColumns;
  final Map<int, double> pbtColumns;

  /// The comparative quarter column (ending one year before [periodEnd]) —
  /// every SEBI filing shows it; a newly listed demerged entity's trailing
  /// year can depend on it.
  final double? priorQuarterEbit;
  final double? priorQuarterPbt;
  final double? totalAssets;
  final double? currentLiabilities;
  final double? totalDebt;
  final double? cash;
  final double? paidUpEquity;
  final double? faceValue;
  final double? numberOfShares;
  final double? eps;
  final double? pat;

  /// Banking / NBFC / Insurance per-segment taxonomy when recognized, else
  /// null (IndAS generic or unknown).
  final String? formatLabel;

  /// Whether the filing document contains any balance-sheet fact at all.
  /// SEBI files the Statement of Assets and Liabilities half-yearly (Q2/Q4);
  /// a quarter filing without one is expected, not an error.
  final bool hasBalanceSheetFacts;
}

@immutable
class _XbrlContext {
  const _XbrlContext({
    this.instant,
    this.start,
    this.end,
    this.hasDimensions = false,
  });

  final DateTime? instant;
  final DateTime? start;
  final DateTime? end;
  final bool hasDimensions;
}
