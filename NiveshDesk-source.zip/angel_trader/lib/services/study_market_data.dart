// ---------------------------------------------------------------------------
// study_market_data.dart — the slice of the market-data layer the F&O study
// needs, expressed as an interface.
//
// Why an interface instead of a concrete [MarketDataService]: the study's
// orchestration (batched quotes, per-stock greeks, degrade-on-failure) is the
// part worth testing, and it must be testable without a live SmartAPI session.
// `MarketDataService implements StudyMarketData`, and the tests provide a fake.
//
// It also gives the option-greek result a home outside the HTTP client.
// ---------------------------------------------------------------------------

import '../data/remote/dto/quote.dart';
import '../data/remote/dto/scrip.dart';

/// The two calls the F&O study makes.
abstract interface class StudyMarketData {
  /// SmartAPI's documented cap for one quote/ltp request.
  static const int maxTokensPerCall = 50;

  /// Batched **full** quotes (LTP + previous close) keyed by instrument token.
  ///
  /// Full mode matters: the "agar kal jodi buy ki hoti" line needs yesterday's
  /// premium, which LTP mode does not return.
  Future<Map<String, MarketQuote>> fetchQuotesFull(List<Scrip> scrips);

  /// Implied volatilities for one underlying + expiry, straight from the
  /// broker's option-greek endpoint. An empty map (with [OptionGreekBatch.error]
  /// set) means "unavailable" — never an exception the study must catch.
  Future<OptionGreekBatch> fetchOptionGreeks({
    required String underlying,
    required String expiryLabel,
  });
}

/// Result of one option-greek request.
///
/// [byStrike] is keyed `"2650.00|CE"` and carries IV in **percent** units
/// (`28.5`, not `0.285`). [error] says *why* an IV is missing instead of just
/// leaving a blank in the table.
class OptionGreekBatch {
  final Map<String, double> byStrike;
  final String? error;

  const OptionGreekBatch({required this.byStrike, this.error});

  bool get isEmpty => byStrike.isEmpty;

  double? ivFor(double strike, String optionType) =>
      byStrike['${strike.toStringAsFixed(2)}|${optionType.toUpperCase()}'];
}
