// ---------------------------------------------------------------------------
// ipo_discovery_service.dart — finds IPOs that listed *after* the newest row in
// the database, and adds them automatically.
//
// WHY THIS EXISTS
// The bundled master (`assets/data/ipos.csv`) is a snapshot: every mainboard IPO
// from 2015 up to the day the file was cut. Tomorrow's listing is, by
// definition, not in it. Without this service the user would have to wait for a
// new APK every time a company lists.
//
// HOW IT DECIDES (two sources, broker first)
//
//   1. BROKER (primary, no third-party site involved)
//      The app already downloads the daily scrip master. Symbols present today
//      but absent from the last snapshot — and absent from the database — are
//      candidates. For each one `getCandleData` answers a single question:
//      *when does this instrument's history start?* A genuine new listing has
//      its first bar on (or a day or two around) its listing date, and that same
//      first bar carries the listing-day **high and low**. One candle call gives
//      date + levels together.
//
//   2. NSE EQUITY_L (fallback / cross-check, official listing dates)
//      If the broker's snapshot cannot see a symbol yet — the master updates a
//      few hours behind the exchange, and an SME/NSE-first listing can lag —
//      the official master's `DATE OF LISTING` says a listing happened. Those
//      rows are added with the exchange's date; their levels arrive later
//      through the normal `ListingLevelsService` path (levels_source stays
//      pending until then).
//
// WHAT IT DELIBERATELY DOES NOT DO
//   • No SME (`-SM`/series `SM`): this app screens mainboard names.
//   • No blind bulk probing: candidates are capped per run ([maxPerRun]) and the
//     whole thing is rate-limited ([minInterval]), because every candidate costs
//     one candle call on the user's own credentials.
//   • No silent guessing of *what* a new symbol is. Renames and demergers also
//     produce new tickers, so every row added here carries an explicit note and
//     shows up in one review banner in the screener — one tap deletes a
//     false positive, and the symbol is remembered as reviewed so it is not
//     added again.
// ---------------------------------------------------------------------------

import 'dart:convert';

import 'package:flutter/foundation.dart';

import '../core/utils/markets.dart';
import '../data/local/dao/ipo_dao.dart';
import '../data/local/dao/settings_dao.dart';
import '../data/local/models/ipo.dart';
import '../data/remote/dto/scrip.dart';
import 'auth_service.dart';
import 'candle_source.dart';
import 'listing_levels_service.dart';
import 'nse_listing_service.dart';
import 'scrip_master_service.dart';

/// One ticker the app corrected after the exchange renamed a company.
class IdentityRepair {
  const IdentityRepair({
    required this.isin,
    required this.from,
    required this.to,
    this.companyName = '',
  });

  /// The stable identity that proved the rename.
  final String isin;
  final String from;
  final String to;
  final String companyName;

  @override
  String toString() => '$from → $to';
}

/// Outcome of one [IpoDiscoveryService.repairRenamedSymbols] pass.
class IdentityRepairReport {
  const IdentityRepairReport({
    this.repairs = const [],
    this.isinsFilled = 0,
    this.error,
  });

  final List<IdentityRepair> repairs;

  /// Rows that gained an ISIN (so a future rename can be repaired for them too).
  final int isinsFilled;

  final String? error;

  bool get didSomething => repairs.isNotEmpty;
}

/// What one discovery run did.
class DiscoveryReport {
  const DiscoveryReport({
    this.identity = const IdentityRepairReport(),
    this.added = const [],
    this.probed = 0,
    this.skippedOld = 0,
    this.skippedSme = 0,
    this.alreadyKnown = 0,
    this.needsLogin = false,
    this.skipped = false,
    this.error,
  });

  /// Tickers corrected by the identity pass (see
  /// [IpoDiscoveryService.repairRenamedSymbols]).
  final IdentityRepairReport identity;

  /// Rows inserted into the database, newest listing first.
  final List<Ipo> added;

  /// Candidates that cost a candle call this run.
  final int probed;

  /// Candidates that turned out not to be new listings: either their history
  /// starts before the newest known listing (a rename or a BSE→NSE migration —
  /// new to the master, old as a company), or they have no history at all.
  final int skippedOld;

  /// SME-platform instruments, ignored by design.
  final int skippedSme;

  /// Already in the database (nothing to do).
  final int alreadyKnown;

  /// No broker session: discovery needs one for the candle probe.
  final bool needsLogin;

  /// The run was inside [IpoDiscoveryService.minInterval]; nothing was checked.
  final bool skipped;

  final String? error;

  bool get didAdd => added.isNotEmpty || identity.didSomething;

  String get summary {
    final parts = <String>[
      if (added.isNotEmpty) '${added.length} naye IPO add hue',
      if (identity.repairs.isNotEmpty)
        '${identity.repairs.length} ticker repair: '
            '${identity.repairs.map((r) => '${r.from} → ${r.to}').join(', ')}',
    ];
    return parts.isEmpty ? 'Koi naya IPO nahi mila.' : parts.join(' · ');
  }
}

class IpoDiscoveryService {
  IpoDiscoveryService({
    required IpoDao ipoDao,
    required ScripMasterService scripMaster,
    required CandleSource candles,
    required AuthService auth,
    NseListingService? nse,
    SettingsDao? settings,
    this.maxPerRun = 25,
    this.minInterval = const Duration(hours: 6),
    this.probeDelay = const Duration(milliseconds: 350),
    this.lookback = const Duration(days: 400),
  })  : _ipoDao = ipoDao,
        _scripMaster = scripMaster,
        _candles = candles,
        _auth = auth,
        _nse = nse,
        _settings = settings;

  final IpoDao _ipoDao;
  final ScripMasterService _scripMaster;
  final CandleSource _candles;
  final AuthService _auth;
  final NseListingService? _nse;
  final SettingsDao? _settings;

  /// Candidate symbols probed per run (each = one candle call).
  final int maxPerRun;

  /// Minimum gap between automatic runs — keeps a user who opens the app ten
  /// times a day from probing ten times.
  final Duration minInterval;

  /// Pause between two candle calls; together with [maxPerRun] this keeps the
  /// run far below the SmartAPI per-second limit.
  final Duration probeDelay;

  /// How far back to look for a candidate's first bar when the database's
  /// newest listing is old (a fresh install, or months without opening the app).
  final Duration lookback;

  /// Settings keys: which master symbols have already been reviewed, and when
  /// the last run happened.
  static const String seenSymbolsKey = 'ipo_discovery_seen';
  static const String lastRunKey = 'ipo_discovery_at';

  /// Symbols that must never be treated as candidates.
  /// `-RE` is a rights entitlement, `-IL` an insolvency listing: neither is an IPO.
  static const Set<String> _neverNotIpo = {'-RE', '-IL'};

  /// `true` when a fresh automatic run is due.
  Future<bool> get isDue async {
    final at = DateTime.tryParse(await _settings?.meta(lastRunKey) ?? '');
    if (at == null) return true;
    return DateTime.now().difference(at) >= minInterval;
  }

  /// Finds and stores listings newer than the newest row in the database.
  ///
  /// Safe to call on every launch: it is rate-limited, capped, and idempotent
  /// (the same symbol is never added twice — reviewed symbols are remembered
  /// even after the user deletes a row).
  Future<DiscoveryReport> discoverNewListings({bool force = false}) async {
    if (!_auth.isLoggedIn) {
      return const DiscoveryReport(needsLogin: true);
    }
    if (!force && !await isDue) {
      return const DiscoveryReport(skipped: true);
    }

    try {
      final rows = await _ipoDao.all();
      final known = {for (final row in rows) row.symbol.toUpperCase()};
      final newest = _newestListingDate(rows);
      final floor = _floorFrom(newest);

      final resolver = await _scripMaster.resolver();
      final masterSymbols = <String, Scrip>{};
      for (final scrip in resolver.all) {
        final plain = Scrip.plainSymbol(scrip.symbol).toUpperCase();
        if (plain.isEmpty || _isNeverIpo(scrip.symbol)) continue;
        final existing = masterSymbols[plain];
        // Prefer the NSE instrument when a ticker exists on both exchanges.
        if (existing == null ||
            (existing.exchange != Exchange.nse && scrip.exchange == Exchange.nse)) {
          masterSymbols[plain] = scrip;
        }
      }

      final seen = await _seenSymbols();
      final isFirstRun = seen.isEmpty;

      final added = <Ipo>[];
      // Symbols actually looked at this run. Only these may enter the snapshot:
      // candidates beyond [maxPerRun] must stay visible for the next run.
      final processed = <String>{};
      var probed = 0;
      var skippedOld = 0;
      var skippedSme = 0;
      var alreadyKnown = 0;
      String? firstError;

      // ---------------------------------------------------------------------
      // 1. Broker path
      // ---------------------------------------------------------------------
      // On a first run every non-IPO equity in the master would look "new", so
      // the snapshot is simply recorded and discovery starts from the next run
      // onwards — plus the NSE pass below, which is date-driven and safe even
      // then.
      if (!isFirstRun) {
        final candidates = <Scrip>[];
        var sme = 0;
        for (final entry in masterSymbols.entries) {
          final symbol = entry.key;
          if (known.contains(symbol) || seen.contains(symbol)) continue;
          if (_isSme(entry.value)) {
            sme++;
            continue;
          }
          candidates.add(entry.value);
        }
        skippedSme += sme;
        candidates.sort((a, b) =>
            Scrip.plainSymbol(a.symbol).compareTo(Scrip.plainSymbol(b.symbol)));

        for (final scrip in candidates.take(maxPerRun)) {
          final symbol = Scrip.plainSymbol(scrip.symbol).toUpperCase();
          processed.add(symbol);
          probed++;
          try {
            final first = await _firstBar(scrip, floor);
            if (first == null) {
              skippedOld++; // symbol is new to the master, its history is not new
              continue;
            }
            if (!first.date.isAfter(newest)) {
              skippedOld++; // older than the newest row: not a new listing
              continue;
            }
            added.add(await _insert(
              symbol: symbol,
              companyName: scrip.name.isEmpty ? symbol : scrip.name,
              exchange: scrip.exchange,
              listingDate: first.date,
              high: first.high,
              low: first.low,
              note: 'Auto-detected new listing (broker data)',
            ));
          } catch (error) {
            firstError ??= '$error';
          } finally {
            if (probeDelay > Duration.zero) await Future<void>.delayed(probeDelay);
          }
        }
      }

      // ---------------------------------------------------------------------
      // 2. NSE path — official dates, catches what the broker master lags on
      // ---------------------------------------------------------------------
      final nse = _nse;
      if (nse != null) {
        List<NseListing> listings;
        try {
          listings = await nse.listings(force: force);
        } on NseListingException catch (error) {
          firstError ??= error.message;
          listings = const [];
        }

        for (final listing in listings) {
          if (!listing.isMainboard) continue;
          final symbol = listing.symbol.toUpperCase();
          if (!listing.listingDate.isAfter(newest)) continue; // older listings
          if (known.contains(symbol) || seen.contains(symbol)) {
            alreadyKnown++;
            processed.add(symbol);
            continue;
          }
          if (added.any((row) => row.symbol.toUpperCase() == symbol)) continue;

          // Levels: ask the broker when the symbol is already resolvable, so a
          // discovered row is immediately scannable instead of waiting for the
          // next levels batch.
          double high = 0;
          double low = 0;
          final scrip = masterSymbols[symbol];
          if (scrip != null) {
            try {
              final first = await _firstBar(scrip, listing.listingDate
                  .subtract(const Duration(days: 5)));
              if (first != null) {
                high = first.high;
                low = first.low;
              }
            } catch (error) {
              firstError ??= '$error';
            } finally {
              if (probeDelay > Duration.zero) await Future<void>.delayed(probeDelay);
            }
          }

          added.add(await _insert(
            symbol: symbol,
            companyName: listing.companyName.isEmpty
                ? symbol
                : listing.companyName,
            exchange: Exchange.nse,
            listingDate: listing.listingDate,
            high: high,
            low: low,
            note: high > 0
                ? 'Auto-detected from NSE listing + broker data'
                : 'Auto-detected from NSE listing (levels pending)',
          ));
        }
      }

      // ---------------------------------------------------------------------
      // 3. Remember what has been reviewed
      // ---------------------------------------------------------------------
      final reviewed = <String>{...seen, ...known, ...processed};
      if (isFirstRun) {
        // Nothing was probed on the very first run: record today's master so the
        // next run only sees symbols that appeared after today.
        reviewed.addAll(masterSymbols.keys);
      }
      await _settings?.putMeta(seenSymbolsKey, jsonEncode(reviewed.toList()..sort()));
      await _settings?.putMeta(lastRunKey, DateTime.now().toIso8601String());

      if (added.isNotEmpty) {
        debugPrint('IPO discovery: added ${added.length} '
            '(${added.map((row) => row.symbol).join(', ')})');
      }

      // Renames happen between the master's cut-off and now, so every run also
      // re-checks identity: a row whose ISIN now carries a different ticker is
      // corrected on the spot (this is what keeps the scan counter honest
      // forever, instead of needing a new build each time a company renames).
      IdentityRepairReport identity = const IdentityRepairReport();
      try {
        identity = await repairRenamedSymbols(force: force);
      } catch (error) {
        firstError ??= '$error';
      }

      added.sort((a, b) => b.listingDate.compareTo(a.listingDate));
      return DiscoveryReport(
        identity: identity,
        added: added,
        probed: probed,
        skippedOld: skippedOld,
        skippedSme: skippedSme,
        alreadyKnown: alreadyKnown,
        error: firstError,
      );
    } catch (error) {
      return DiscoveryReport(error: '$error');
    }
  }

  /// Inserts one discovered row and returns it with its id.
  Future<Ipo> _insert({
    required String symbol,
    required String companyName,
    required Exchange exchange,
    required DateTime listingDate,
    required double high,
    required double low,
    required String note,
  }) async {
    final row = Ipo(
      symbol: symbol,
      companyName: companyName,
      exchange: exchange,
      listingDate: listingDate,
      listingHigh: high,
      listingLow: low,
      notes: note,
      levelsSource: high > 0 && low > 0 ? LevelsSource.auto : LevelsSource.pending,
    );
    final id = await _ipoDao.insert(row);
    return Ipo(
      id: id,
      symbol: row.symbol,
      companyName: row.companyName,
      exchange: row.exchange,
      listingDate: row.listingDate,
      listingHigh: row.listingHigh,
      listingLow: row.listingLow,
      sector: row.sector,
      notes: row.notes,
      levelsSource: row.levelsSource,
    );
  }

  /// The listing-session bar: the oldest daily candle in the probe window.
  ///
  /// Returns `null` when the instrument has no bars in the window at all (the
  /// symbol exists in the master but never traded — a rights entitlement, a
  /// suspended name, or a company that migrated without fresh history).
  Future<({DateTime date, double high, double low})?> _firstBar(
    Scrip scrip,
    DateTime from,
  ) async {
    final start = from.isBefore(DateTime.now().subtract(lookback))
        ? DateTime.now().subtract(lookback)
        : from;
    final bars = await _candles.fetchDailyCandles(
      scrip: scrip,
      from: start,
      to: DateTime.now().add(const Duration(days: 1)),
    );
    if (bars.isEmpty) return null;
    bars.sort((a, b) => a.time.compareTo(b.time));
    final first = bars.first;
    // Candle timestamps are IST instants; the database stores plain dates, so
    // normalise before comparing (otherwise a 09:15 IST bar looks "after" the
    // same day's midnight date and a same-day row would be duplicated).
    final day = DateTime(first.time.year, first.time.month, first.time.day);
    return (date: day, high: first.high, low: first.low);
  }

  DateTime _newestListingDate(List<Ipo> rows) {
    var newest = rows.isEmpty ? DateTime(2015, 1, 1) : rows.first.listingDate;
    for (final row in rows) {
      if (row.listingDate.isAfter(newest)) newest = row.listingDate;
    }
    return newest;
  }

  /// Candidates older than this are not new IPOs — go back a little to avoid
  /// missing a listing that happened the same week the master was refreshed.
  DateTime _floorFrom(DateTime newest) => newest.subtract(const Duration(days: 5));

  /// Repairs rows whose ticker the exchange has changed since they were stored.
  ///
  /// This is the fix for the "counter stops at 555/559" class of problem, done
  /// the durable way: **the ISIN decides identity, the symbol is only a label.**
  ///
  ///   • A company can rename itself and its ticker at any time (LTIM → LTM,
  ///     AMIORG → ACUTAAS). The ISIN does not change.
  ///   • So: look up the row's ISIN in today's exchange master. If the master
  ///     now maps that ISIN to a *different* symbol — and the stored symbol is
  ///     no longer in the master at all — the ticker was renamed. Update the row
  ///     (symbol + company name), keep the listing date, levels and notes.
  ///   • Both conditions matter. The "old symbol is gone" check is what makes
  ///     this safe: during a demerger or a dual listing two tickers can briefly
  ///     carry the same ISIN, and nothing should be rewritten in that window.
  ///
  /// Runs only when the exchange master is available; when it is not, the
  /// static [IpoScreenerProvider.renamedSymbols] table still covers the renames
  /// that happened before this build.
  Future<IdentityRepairReport> repairRenamedSymbols({bool force = false}) async {
    final nse = _nse;
    if (nse == null) return const IdentityRepairReport();

    final rows = await _ipoDao.all();
    if (rows.isEmpty) return const IdentityRepairReport();

    final List<NseListing> listings;
    final Map<String, NseListing> byIsin;
    final Set<String> symbols;
    try {
      listings = await nse.listings(force: force);
      byIsin = await nse.byIsin(force: force);
      symbols = await nse.allSymbols(force: force);
    } on NseListingException catch (error) {
      return IdentityRepairReport(error: error.message);
    } catch (error) {
      return IdentityRepairReport(error: '$error');
    }

    final repairs = <IdentityRepair>[];
    final filled = await _fillMissingIsins(rows, listings);

    for (final row in rows) {
      final isin = row.isin.toUpperCase();
      if (isin.isEmpty) continue; // identity unknown: nothing to check against

      final current = byIsin[isin];
      if (current == null) continue; // delisted name: leave it alone
      if (current.symbol.toUpperCase() == row.symbol.toUpperCase()) continue;
      // The stored ticker must have actually stopped trading — otherwise this is
      // a same-ISIN overlap (demerger transition), not a rename.
      if (symbols.contains(row.symbol.toUpperCase())) continue;
      if (row.isCustom) continue; // a row the user maintains by hand

      final moved = await _ipoDao.renameSymbol(
        from: row.symbol,
        to: current.symbol.toUpperCase(),
        companyName: current.companyName.isEmpty
            ? row.companyName
            : current.companyName,
        note: 'ISIN ${row.isin} moved to ${current.symbol} (exchange rename)',
      );
      if (moved > 0) {
        repairs.add(IdentityRepair(
          isin: isin,
          from: row.symbol.toUpperCase(),
          to: current.symbol.toUpperCase(),
          companyName: current.companyName,
        ));
      }
    }

    if (repairs.isNotEmpty) {
      debugPrint('IPO identity: ${repairs.length} ticker(s) repaired '
          '(${repairs.map((r) => '${r.from} → ${r.to}').join(', ')})');
    }
    return IdentityRepairReport(repairs: repairs, isinsFilled: filled);
  }

  /// Copies ISINs from the exchange master onto rows that do not have one yet.
  ///
  /// Rows that arrive without an identity can never be repaired later, so this
  /// runs whenever a master is available — it is what makes a row shipped by an
  /// older version future-proof from today onwards.
  Future<int> _fillMissingIsins(List<Ipo> rows, List<NseListing> listings) async {
    final isinBySymbol = <String, String>{};
    for (final listing in listings) {
      if (listing.isin.isEmpty) continue;
      isinBySymbol.putIfAbsent(listing.symbol.toUpperCase(), () => listing.isin);
    }
    var filled = 0;
    for (final row in rows) {
      if (row.isin.isNotEmpty || row.id == null) continue;
      final isin = isinBySymbol[row.symbol.toUpperCase()];
      if (isin == null) continue;
      await _ipoDao.setIsin(row.id!, isin);
      filled++;
    }
    if (filled > 0) debugPrint('IPO identity: $filled ISIN(s) filled in');
    return filled;
  }
  /// Symbols already reviewed (recorded at the end of every run). Kept in the
  /// settings table rather than a new DB table on purpose: it is a diagnostic
  /// snapshot, not user data, and must survive a row the user deleted — a name
  /// that was added once and removed by hand must not come back tomorrow.
  Future<Set<String>> _seenSymbols() async {
    final raw = await _settings?.meta(seenSymbolsKey);
    if (raw == null || raw.isEmpty) return <String>{};
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return <String>{};
      return {for (final value in decoded) '$value'.toUpperCase()};
    } catch (_) {
      return <String>{}; // corrupt snapshot: rebuild it on this run
    }
  }

  bool _isNeverIpo(String exchangeSymbol) {
    final upper = exchangeSymbol.toUpperCase();
    return _neverNotIpo.any(upper.endsWith);
  }

  bool _isSme(Scrip scrip) {
    final upper = scrip.symbol.toUpperCase();
    return upper.endsWith('-SM') || upper.endsWith('-ST');
  }
}
