// ---------------------------------------------------------------------------
// earnings_calendar_service.dart — "company ka last result kab aaya, next kab
// aayega" — the one piece of company data the broker's SmartAPI does not serve.
//
// Source (public, login-less, same fallback role the user approved for NSE):
//
//   upcoming  GET /api/corporate-board-meetings?index=equities
//             → [{bm_symbol, bm_date "30-Oct-2023", bm_purpose "...Quarterly
//                Unaudited Financial results...", sm_name, sm_isin}, …]
//             Boards must intimate NSE in advance, so a matching row is a
//             **confirmed** date.
//
//   past      GET /api/corporates-financial-results?index=equities&period=Quarterly
//             → [{symbol, companyName, exchdisstime "16-Jan-2025 20:20:54",
//                relatingTo "Third Quarter", toDate "31-Dec-2024"}, …]
//             The latest filing for a symbol is its **last** result.
//   new       the same board-meetings row carries `bm_timestamp` (NSE's
//             timestamp for the filed notice), separate from `bm_date`.
//             Missing publication timestamps are never replaced with first-seen time.
//
// NSE gates these behind cookies, so a warm-up request to the home page runs
// first (exactly like the shipped nse_listing_service.dart does for EQUITY_L).
//
// Everything is cached for a day in SQLite: the app asks NSE at most once per
// day, and both the screen and the export read a plain table afterwards.
//
// NO GUESSING. A board intimates NSE only ~2–4 weeks ahead, so on most days
// most of this list has no *next* date — and it used to be filled with our own
// guess (last filing + ~91 days, tagged "anumanit"). The user does not want a
// guessed date at all: a company with no intimation simply has **no next
// date**, and the useful thing it carries is its last result (kab aaya tha,
// kaunsa quarter, kitne din hue). Rows written by builds ≤ 1.5.12 still hold
// such a guess in the cache; the DAO drops it on read (see EarningsDao.all).
// ---------------------------------------------------------------------------

import 'dart:convert';

import 'package:http/http.dart' as http;

import '../core/utils/formatters.dart' show Fmt;
import '../data/local/dao/earnings_dao.dart';
import '../data/local/dao/result_history_dao.dart';
import '../data/local/dao/settings_dao.dart';
import '../data/local/models/result_stamp.dart';

/// What one company's results calendar looks like.
class EarningsInfo {
  /// Day the latest result was filed with the exchange (null = not in the feed).
  final DateTime? lastDate;

  /// `Q2 · quarter ended 30-Sep-2025` — short, for one UI line.
  final String lastLabel;

  /// Next results day — NSE's own announcement, or null. Never a guess.
  final DateTime? nextDate;
  final String nextLabel;

  /// `true` when NSE carries a board-meeting intimation for [nextDate].
  final bool nextConfirmed;

  /// Legacy flag: `true` only on rows written by builds ≤ 1.5.12, which guessed
  /// the next date from the last filing. Nothing is guessed any more — such a
  /// date is ignored everywhere ([announcedNext] is null for it).
  final bool estimated;

  const EarningsInfo({
    this.lastDate,
    this.lastLabel = '',
    this.nextDate,
    this.nextLabel = '',
    this.nextConfirmed = false,
    this.estimated = false,
  });

  bool get isEmpty => lastDate == null && nextDate == null;

  /// `true` only for a date NSE itself announced — never for a guess.
  ///
  /// Rows cached by builds ≤ 1.5.12 carry an invented next date
  /// ([estimated]); [announcedNext] hides it, so an old phone's cache cannot
  /// bring guessed dates back.
  bool get hasAnnouncedNext => nextDate != null && nextConfirmed && !estimated;

  /// [nextDate], but null unless NSE announced it. Every screen reads this.
  DateTime? get announcedNext => hasAnnouncedNext ? nextDate : null;

  static const EarningsInfo none = EarningsInfo();

  /// One-line summary for logs / diagnostics.
  @override
  String toString() =>
      'Earnings(last=$lastDate "$lastLabel", next=$nextDate "$nextLabel", '
      'confirmed=$nextConfirmed, estimated=$estimated)';
}

/// A parsed board-meeting row (the "next result" half).
class BoardMeeting {
  final String symbol;
  final DateTime date;
  final String purpose;

  /// Official NSE timestamp for this meeting notice (`bm_timestamp`).
  /// Null means the notice publication time is not verified.
  final DateTime? announcedAt;

  const BoardMeeting({
    required this.symbol,
    required this.date,
    required this.purpose,
    this.announcedAt,
  });
}

/// A results-meeting notice whose NSE publication timestamp is verified.
/// [announcedAt] is the board-meeting feed's `bm_timestamp`, not `bm_date`.
class RecentResultAnnouncement {
  const RecentResultAnnouncement({
    required this.symbol,
    required this.meetingDate,
    required this.announcedAt,
  });

  final String symbol;
  final DateTime meetingDate;
  final DateTime announcedAt;

  Map<String, Object?> toJson() => {
    'symbol': symbol,
    'meetingDate': _isoDate(meetingDate),
    'announcedAt': announcedAt.toIso8601String(),
  };

  static RecentResultAnnouncement? fromJson(Object? value) {
    if (value is! Map) return null;
    final symbol = '${value['symbol'] ?? ''}'.trim().toUpperCase();
    final meetingDate = DateTime.tryParse('${value['meetingDate'] ?? ''}');
    final announcedAt = DateTime.tryParse('${value['announcedAt'] ?? ''}');
    if (symbol.isEmpty || meetingDate == null || announcedAt == null) {
      return null;
    }
    return RecentResultAnnouncement(
      symbol: symbol,
      meetingDate: meetingDate,
      announcedAt: announcedAt,
    );
  }

  static String _isoDate(DateTime date) =>
      '${date.year.toString().padLeft(4, '0')}-'
      '${date.month.toString().padLeft(2, '0')}-'
      '${date.day.toString().padLeft(2, '0')}';
}

/// The whole calendar: `SYMBOL → EarningsInfo`. Immutable, cheap to copy.
class EarningsCalendar {
  final Map<String, EarningsInfo> bySymbol;
  final DateTime fetchedAt;

  const EarningsCalendar({required this.bySymbol, required this.fetchedAt});

  static EarningsCalendar empty([DateTime? at]) => EarningsCalendar(
    bySymbol: const {},
    fetchedAt: at ?? DateTime.fromMillisecondsSinceEpoch(0),
  );

  bool get isEmpty => bySymbol.isEmpty;
  int get length => bySymbol.length;

  EarningsInfo? of(String symbol) => bySymbol[symbol.trim().toUpperCase()];
}

class EarningsCalendarService {
  EarningsCalendarService({
    required EarningsDao dao,
    required SettingsDao settings,
    ResultHistoryDao? history,
    Future<String> Function(Uri uri)? get,
    DateTime Function()? now,
  }) : _dao = dao,
       _settings = settings,
       _history = history,
       _get = get,
       _now = now ?? DateTime.now;

  final EarningsDao _dao;
  final SettingsDao _settings;

  /// Pichle results ki suchi (playbook ke liye). `null` ho to sirf aaj ka
  /// hisaab chalta hai — purane tests isi tarah chalte hain.
  final ResultHistoryDao? _history;

  /// Injected HTTP seam: returns the response body for [uri]. Production wires
  /// this to the app's ApiClient; tests hand in a fixture.
  final Future<String> Function(Uri uri)? _get;
  final DateTime Function() _now;

  /// NSE API paths (verified against the public nse library's own source).
  static const String boardMeetingsPath =
      'https://www.nseindia.com/api/corporate-board-meetings';
  static const String financialResultsPath =
      'https://www.nseindia.com/api/corporates-financial-results';
  static const String warmUpUrl = 'https://www.nseindia.com/';

  /// Key in `scrip_meta` remembering the last successful fetch.
  static const String metaFetchedAt = 'earnings_fetched_at';

  /// Key in `scrip_meta` remembering when `result_history` was first written.
  ///
  /// Purane build (schema v10) ke phone par ye table khaali hoti hai. Itihaas
  /// ek baar bhi likha na gaya ho to calendar ka cache taaza hone par bhi ek
  /// baar NSE se dobara pada jata hai — warna playbook hamesha khaali rahega.
  static const String metaResultHistoryAt = 'result_history_at';

  /// Verified NSE broadcast dates for new result-meeting announcements.
  static const String metaRecentResultAnnouncements =
      'recent_result_announcements_bm_timestamp_v2';

  /// A result announcement stays highlighted for this long after NSE's
  /// official broadcast date/time. No first-seen or scheduled-meeting date is
  /// substituted when the publication timestamp is missing.
  static const Duration newResultAnnouncementLifetime = Duration(days: 2);

  /// How long a fetch is reused. Results dates change rarely; once a day is
  /// plenty and keeps the app quiet on the user's connection.
  static const Duration cacheValidity = Duration(hours: 20);

  /// Board-meeting window we ask NSE for. Backwards it covers a full quarter
  /// of **past** meetings: a board meeting that has already happened *is* the
  /// declaration of a result, so this is what lets the calendar show a date for
  /// companies whose numbers are out but whose row is not in the filings feed
  /// yet. Forwards it reaches ~4 months, so an announced next-quarter meeting
  /// is picked up as soon as the board intimates it.
  static const Duration boardWindowBack = Duration(days: 100);
  static const Duration boardWindowForward = Duration(days: 120);

  /// How far back the filings feed is asked for.
  ///
  /// Ek filing har ~91 din me aati hai, isliye **6 result** (playbook ki
  /// zarurat) ke liye ~2 saal pichhe tak padhna padta hai. 200 din me 2-3
  /// quarter hi milte the.
  static const Duration lastResultsWindow = Duration(days: 730);

  /// Kitne purane result ek stock ke liye yaad rakhe jayen (naye se purane).
  static const int historyPerSymbol = 8;

  EarningsCalendar? _memo;
  bool _fetching = false;
  String? _note;
  bool _failed = false;
  Map<String, RecentResultAnnouncement> _recentResultAnnouncements = {};
  Future<void>? _recentAnnouncementsLoad;

  EarningsCalendar? get memo => _memo;
  bool get isFetching => _fetching;

  /// What the last fetch did — a plain remark on success, the explanation on
  /// failure.
  String? get note => _note;

  /// `true` when the last NSE attempt failed (screens show [note] as a warning
  /// only in that case; a success remark is not a warning).
  bool get lastFetchFailed => _failed;

  /// NSE broadcast date for a confirmed result meeting if it was announced
  /// within the last 48 hours. A null result means it is not verified as new.
  DateTime? newlyDeclaredAt(String symbol, DateTime? meetingDate) {
    if (meetingDate == null) return null;
    final record =
        _recentResultAnnouncements[_announcementKey(symbol, meetingDate)];
    if (record == null || !_isRecentAnnouncement(record.announcedAt, _now())) {
      return null;
    }
    return record.announcedAt;
  }

  // -------------------------------------------------------------------------
  // Cache-backed load
  // -------------------------------------------------------------------------

  /// Returns the calendar, fetching from NSE only when the cache is stale.
  ///
  /// An **empty** calendar is never treated as a good cache. If the last attempt
  /// brought nothing back, the next call tries again — a page that stays blank
  /// while claiming to be up to date for the rest of the day is the worst
  /// outcome for the user, and it is exactly the bug this guards.
  Future<EarningsCalendar> load({bool force = false}) async {
    await _loadRecentResultAnnouncements();
    final memo = _memo;
    if (!force && memo != null && !memo.isEmpty && !_isStale(memo.fetchedAt)) {
      // Calendar taaza hai. Par agar itihaas kabhi likha hi nahi gaya to ek
      // baar naya fetch kar lo (niche wala `historyBackfilled` bhi yahi karta
      // hai — yahan memo pehle se hai, isliye seedha return).
      if (await _hasResultHistory()) return memo;
    }

    final stored = await _dao.all();
    final fetchedAt = _parseStamp(await _settings.meta(metaFetchedAt));
    final cached = EarningsCalendar(
      bySymbol: stored,
      fetchedAt: fetchedAt ?? DateTime.fromMillisecondsSinceEpoch(0),
    );

    // Cache taaza hai — par itihaas kabhi likha hi na gaya ho (purane build se
    // upgrade) to ek baar NSE se dobara padha jata hai. Warna playbook hamesha
    // khaali rahega aur user sochega "feature kaam nahi karta".
    final historyBackfilled = _history == null || await _hasResultHistory();
    if (!force &&
        historyBackfilled &&
        !cached.isEmpty &&
        !_isStale(cached.fetchedAt)) {
      _memo = cached;
      return cached;
    }
    if (force || _get != null) {
      try {
        return await refresh();
      } catch (e) {
        // Only a database-level problem can land here; the network problems are
        // handled inside refresh() so that one dead feed never sinks the other.
        _failed = true;
        _note =
            'Results calendar update nahi hua ($e). Purani list dikhayi ja '
            'rahi hai.';
        _memo = cached;
        return cached;
      }
    }
    _memo = cached;
    return _memo!;
  }

  /// Hits NSE (warm-up + both feeds) and rewrites the cache.
  ///
  /// Four rules, each earned by a real failure:
  ///   1. The two feeds are **independent** — one failing must not sink the
  ///      other (the page once went completely blank because the board-meetings
  ///      call was blocked while the filings feed was fine).
  ///   2. A body that is not JSON (an HTML block page, a redirect) is a
  ///      **failure**, never "NSE has no data".
  ///   3. An empty result **never wipes** a calendar we already have, and it
  ///      never records a fresh timestamp — so the app retries instead of
  ///      serving a blank page all day.
  ///   4. A feed that failed is back-filled from the cache, so a partial outage
  ///      costs the user nothing.
  /// `true` jab `result_history` kabhi likhi ja chuki ho.
  ///
  /// Itihaas ka DAO hi na ho (purane tests / purana rasta) to `true` lautate
  /// hain — matlab "backfill ki zarurat nahi".
  Future<bool> _hasResultHistory() async {
    if (_history == null) return true;
    return _parseStamp(await _settings.meta(metaResultHistoryAt)) != null;
  }

  Future<EarningsCalendar> refresh() async {
    final get = _get;
    if (get == null) return _memo ?? await _storedCalendar();
    await _loadRecentResultAnnouncements();
    // Re-entrancy guard. (Going back through load() here used to be possible
    // and would recurse forever when no memo existed yet.)
    if (_fetching) return _memo ?? await _storedCalendar();

    _fetching = true;
    try {
      // Cookies: NSE refuses API calls that did not come via the home page.
      try {
        await get(Uri.parse(warmUpUrl));
      } catch (_) {
        // A failed warm-up is not fatal — some networks keep a usable session.
      }

      final now = _now();
      final stored = await _dao.all();
      final previousAt = _parseStamp(await _settings.meta(metaFetchedAt));
      final failures = <String>[];

      // ---- feed 1: board meetings → the *next* result (announced)
      var meetings = <BoardMeeting>[];
      var boardMeetingsFeedSucceeded = false;
      try {
        meetings = parseBoardMeetings(
          await _fetchJson(
            get,
            dated: _boardMeetingsUri(now),
            plain: Uri.parse('$boardMeetingsPath?index=equities'),
            label: 'board meetings',
          ),
        );
        boardMeetingsFeedSucceeded = true;
      } catch (e) {
        failures.add(_short(e, 'board meetings'));
        // Keep the meetings the cache already announced.
        for (final entry in stored.entries) {
          final info = entry.value;
          final next = info.nextDate;
          if (info.nextConfirmed && next != null && !next.isBefore(now)) {
            meetings.add(
              BoardMeeting(symbol: entry.key, date: next, purpose: ''),
            );
          }
        }
      }

      // ---- feed 2: filings → the *last* result (on record)
      // Wahi jawab do kaam karta hai: aakhiri result (calendar ke liye) aur
      // poora itihaas (playbook ke liye). NSE ko ek hi baar bulana hai.
      var results = <String, (DateTime, String)>{};
      var historyRows = <String, List<ResultStamp>>{};
      try {
        final body = await _fetchJson(
          get,
          dated: _financialResultsUri(now),
          plain: Uri.parse(
            '$financialResultsPath?index=equities&period=Quarterly',
          ),
          label: 'filings',
        );
        historyRows = parseFinancialResultsHistory(body);
        results = <String, (DateTime, String)>{
          for (final entry in historyRows.entries)
            entry.key: (entry.value.first.date, entry.value.first.period),
        };
      } catch (e) {
        failures.add(_short(e, 'filings'));
        for (final entry in stored.entries) {
          final info = entry.value;
          final last = info.lastDate;
          if (last != null) results[entry.key] = (last, info.lastLabel);
        }
      }

      // The dedicated board-meetings endpoint carries the notice timestamp
      // (`bm_timestamp`) on the same record as its meeting date. Only that
      // NSE-provided timestamp can earn the Naya label; never use first-seen
      // time or the scheduled `bm_date` as a substitute.
      if (boardMeetingsFeedSucceeded) {
        _recentResultAnnouncements = parseRecentResultAnnouncements(
          meetings,
          now: now,
        );
      } else {
        _recentResultAnnouncements = _stillRecentAnnouncements(now);
      }
      await _saveRecentResultAnnouncements();

      final merged = merge(
        meetings: meetings,
        lastResults: results,
        today: now,
      );
      // Both feeds down = nothing fresh to record. (One feed down is fine: the
      // other one is real data, and the failed half came from the cache.)
      final bothFeedsDown = failures.length >= 2;

      if (merged.isEmpty || bothFeedsDown) {
        // Nothing to show. Do NOT touch the table or the timestamp: the old
        // rows stay, the app will try again, and the user is told why.
        _failed = true;
        _note = failures.isEmpty
            ? 'NSE se is waqt koi results date nahi aayi — purani list dikhayi '
                  'ja rahi hai. Dobara try karo.'
            : 'NSE se taaza data nahi aaya (${failures.join(' · ')}). Purani '
                  'list dikhayi ja rahi hai — app dobara koshish karega.';
        _memo = EarningsCalendar(
          bySymbol: stored,
          fetchedAt: previousAt ?? DateTime.fromMillisecondsSinceEpoch(0),
        );
        return _memo!;
      }

      await _dao.replaceAll(merged);
      // Itihaas alag table me — sirf unhi symbols ka jo is calendar me hain.
      // (Filings feed poori NSE equities deta hai; F&O list se bahar wale
      // symbols ka itihaas rakhne se file bina wajah badh jayegi.)
      final historyDao = _history;
      if (historyDao != null && historyRows.isNotEmpty) {
        final kept = <String, List<ResultStamp>>{
          for (final entry in historyRows.entries)
            if (merged.containsKey(entry.key)) entry.key: entry.value,
        };
        if (kept.isNotEmpty) {
          await historyDao.replaceAll(kept);
          await _settings.putMeta(metaResultHistoryAt, now.toIso8601String());
        }
      }
      await _settings.putMeta(metaFetchedAt, now.toIso8601String());

      _memo = EarningsCalendar(bySymbol: merged, fetchedAt: now);
      _failed = failures.isNotEmpty;
      _note = failures.isEmpty
          ? '${merged.length} stocks ke results dates NSE se aa gaye.'
          : '${merged.length} stocks aaye · par ${failures.join(' · ')}';
      return _memo!;
    } finally {
      _fetching = false;
    }
  }

  /// The cached calendar straight from SQLite (used when a refresh cannot run).
  Future<EarningsCalendar> _storedCalendar() async {
    final at = _parseStamp(await _settings.meta(metaFetchedAt));
    return EarningsCalendar(
      bySymbol: await _dao.all(),
      fetchedAt: at ?? DateTime.fromMillisecondsSinceEpoch(0),
    );
  }

  Uri _boardMeetingsUri(DateTime now) => Uri.parse(
    '$boardMeetingsPath?index=equities'
    '&from_date=${_nseDate(now.subtract(boardWindowBack))}'
    '&to_date=${_nseDate(now.add(boardWindowForward))}',
  );

  Uri _financialResultsUri(DateTime now) => Uri.parse(
    '$financialResultsPath?index=equities&period=Quarterly'
    '&from_date=${_nseDate(now.subtract(lastResultsWindow))}'
    '&to_date=${_nseDate(now)}',
  );

  /// GETs [dated] and, if that fails, retries [plain] once.
  ///
  /// Our date window is our own invention; an exchange that dislikes it still
  /// serves its default window, and the parse below filters by date anyway.
  /// A non-JSON body throws — see rule 2 in [refresh].
  static Future<String> _fetchJson(
    Future<String> Function(Uri) get, {
    required Uri dated,
    required Uri plain,
    required String label,
  }) async {
    Object? firstError;
    final attempts = <Uri>[dated, if (plain != dated) plain];
    for (final uri in attempts) {
      try {
        final body = await get(uri);
        if (!_looksLikeJson(body)) {
          throw FormatException('JSON nahi mila (${_preview(body)})');
        }
        return body;
      } catch (e) {
        firstError ??= e;
      }
    }
    throw firstError ?? Exception('$label: NSE se jawab nahi aaya');
  }

  /// `true` when a response body can possibly be one of our JSON feeds.
  static bool _looksLikeJson(String body) {
    final text = body.trimLeft();
    return text.startsWith('[') || text.startsWith('{');
  }

  static String _preview(String body) {
    final text = body.trim().replaceAll(RegExp(r'\s+'), ' ');
    return text.length <= 50 ? text : '${text.substring(0, 50)}…';
  }

  /// `board meetings: NSE ne HTTP 403 diya (…)` — short enough for one UI line.
  static String _short(Object error, String label) {
    var text = '$error'
        .replaceFirst('Exception: ', '')
        .replaceFirst('ClientException: ', '')
        .replaceFirst('FormatException: ', '');
    text = text.split('\n').first.trim();
    if (text.length > 72) text = '${text.substring(0, 72)}…';
    return '$label: $text';
  }

  bool _isStale(DateTime at) {
    final now = _now();
    if (now.difference(at) > cacheValidity) return true;
    // Results get declared *during* the day, so a fetch from an earlier
    // calendar day is treated as stale even when it is only a few hours old:
    // otherwise a list pulled at 8 PM would still be served at 9 AM tomorrow
    // ("result declare ho gaya par app me nahi aaya").
    final fetched = DateTime(at.year, at.month, at.day);
    final today = DateTime(now.year, now.month, now.day);
    return fetched != today;
  }

  static String _nseDate(DateTime date) =>
      '${date.day.toString().padLeft(2, '0')}-'
      '${date.month.toString().padLeft(2, '0')}-${date.year}';

  static DateTime? _parseStamp(String? raw) =>
      raw == null ? null : DateTime.tryParse(raw);

  // -------------------------------------------------------------------------
  // Parsing + merging (pure, unit-tested)
  // -------------------------------------------------------------------------

  /// Select only active result-meeting notices whose official NSE
  /// `bm_timestamp` falls within [lifetime]. A missing publication timestamp
  /// is intentionally suppressed; `bm_date` and app first-seen time are not
  /// publication dates.
  static Map<String, RecentResultAnnouncement> parseRecentResultAnnouncements(
    List<BoardMeeting> meetings, {
    required DateTime now,
    Duration lifetime = newResultAnnouncementLifetime,
  }) {
    final today = _dateOnly(now);
    final out = <String, RecentResultAnnouncement>{};
    for (final meeting in meetings) {
      final announcedAt = meeting.announcedAt;
      if (announcedAt == null ||
          _dateOnly(meeting.date).isBefore(today) ||
          !_isResultsPurpose(meeting.purpose) ||
          !_isRecentAnnouncement(announcedAt, now, lifetime)) {
        continue;
      }

      final record = RecentResultAnnouncement(
        symbol: meeting.symbol,
        meetingDate: _dateOnly(meeting.date),
        announcedAt: announcedAt,
      );
      final key = _announcementKey(meeting.symbol, meeting.date);
      final previous = out[key];
      if (previous == null || announcedAt.isAfter(previous.announcedAt)) {
        out[key] = record;
      }
    }
    return out;
  }

  Future<void> _loadRecentResultAnnouncements() {
    return _recentAnnouncementsLoad ??= _readRecentResultAnnouncements();
  }

  Future<void> _readRecentResultAnnouncements() async {
    try {
      final raw = await _settings.meta(metaRecentResultAnnouncements);
      if (raw == null || raw.isEmpty) return;
      final decoded = jsonDecode(raw);
      if (decoded is! List) return;
      final now = _now();
      _recentResultAnnouncements = {
        for (final value in decoded)
          if (RecentResultAnnouncement.fromJson(value) case final record?)
            if (_isRecentAnnouncement(record.announcedAt, now))
              _announcementKey(record.symbol, record.meetingDate): record,
      };
    } catch (_) {
      _recentResultAnnouncements = {};
    }
  }

  Future<void> _saveRecentResultAnnouncements() async {
    await _settings.putMeta(
      metaRecentResultAnnouncements,
      jsonEncode(
        _recentResultAnnouncements.values.map((item) => item.toJson()).toList(),
      ),
    );
  }

  Map<String, RecentResultAnnouncement> _stillRecentAnnouncements(
    DateTime now,
  ) => {
    for (final entry in _recentResultAnnouncements.entries)
      if (_isRecentAnnouncement(entry.value.announcedAt, now))
        entry.key: entry.value,
  };

  static bool _isRecentAnnouncement(
    DateTime announcedAt,
    DateTime now, [
    Duration lifetime = newResultAnnouncementLifetime,
  ]) {
    if (announcedAt.isAfter(now)) return false;
    return now.difference(announcedAt) < lifetime;
  }

  static String _announcementKey(String symbol, DateTime meetingDate) =>
      '${symbol.trim().toUpperCase()}|${_isoDate(_dateOnly(meetingDate))}';

  static DateTime _dateOnly(DateTime date) =>
      DateTime(date.year, date.month, date.day);

  static String _isoDate(DateTime date) =>
      '${date.year.toString().padLeft(4, '0')}-'
      '${date.month.toString().padLeft(2, '0')}-'
      '${date.day.toString().padLeft(2, '0')}';

  /// Parses the board-meetings feed, keeping only **results** meetings.
  ///
  /// Boards meet for dividends, fund-raising, buybacks and more; only a meeting
  /// whose purpose mentions financial results tells us when the numbers come.
  static List<BoardMeeting> parseBoardMeetings(String jsonText) {
    final out = <BoardMeeting>[];
    for (final row in _rows(jsonText)) {
      final symbol = '${row['bm_symbol'] ?? row['symbol'] ?? ''}'
          .trim()
          .toUpperCase();
      final date = parseNseDate('${row['bm_date'] ?? row['date'] ?? ''}');
      final purpose = '${row['bm_purpose'] ?? ''}'.trim();
      final rawAnnouncementTime = row['bm_timestamp'];
      final announcedAt = rawAnnouncementTime == null
          ? null
          : parseNseDateTime('$rawAnnouncementTime') ??
                parseNseStamp('$rawAnnouncementTime');
      if (symbol.isEmpty || date == null) continue;
      if (!_isResultsPurpose(purpose)) continue;
      out.add(
        BoardMeeting(
          symbol: symbol,
          date: date,
          purpose: purpose,
          announcedAt: announcedAt,
        ),
      );
    }
    return out;
  }

  /// `true` for "…to consider and approve the Quarterly Unaudited Financial
  /// results…" and friends — but not "to consider dividend".
  static bool _isResultsPurpose(String purpose) {
    final p = purpose.toLowerCase();
    if (p.contains('result')) return true;
    return p.contains('financial') && p.contains('approve');
  }

  /// Latest filing per symbol from the financial-results feed.
  static Map<String, (DateTime date, String label)> parseFinancialResults(
    String jsonText,
  ) {
    final best = <String, (DateTime, String)>{};
    for (final row in _rows(jsonText)) {
      final symbol = '${row['symbol'] ?? ''}'.trim().toUpperCase();
      if (symbol.isEmpty) continue;
      final date = parseNseStamp(
        '${row['exchdisstime'] ?? row['filingDate'] ?? row['broadCastDate'] ?? ''}',
      );
      if (date == null) continue;
      final label = quarterLabel(
        relatingTo: '${row['relatingTo'] ?? ''}',
        periodEnd: parseNseDate('${row['toDate'] ?? ''}'),
      );
      final current = best[symbol];
      if (current == null || date.isAfter(current.$1)) {
        best[symbol] = (date, label);
      }
    }
    return best;
  }

  /// Har symbol ke **pichle announced results** — naye se purane.
  ///
  /// [parseFinancialResults] sirf aakhiri wala rakhta hai; playbook ko kai
  /// dates chahiye isliye yahan poora itihaas milta hai. Ek hi din do baar file
  /// hua to ek hi gina jata hai (PRIMARY KEY bhi wahi hai).
  static Map<String, List<ResultStamp>> parseFinancialResultsHistory(
    String jsonText, {
    int perSymbol = historyPerSymbol,
  }) {
    final bySymbol = <String, Map<String, ResultStamp>>{};
    for (final row in _rows(jsonText)) {
      final symbol = '${row['symbol'] ?? ''}'.trim().toUpperCase();
      if (symbol.isEmpty) continue;
      final rawStamp =
          '${row['exchdisstime'] ?? row['filingDate'] ?? row['broadCastDate'] ?? ''}';
      final date = parseNseStamp(rawStamp);
      if (date == null) continue;
      final filedAt = parseNseDateTime(rawStamp);
      // After-close result ka price reaction agle trading session me hoga.
      // Weekend / holiday ko yahan ginna zaruri nahi: playbook agla actual
      // candle dhoondhta hai (first candle on/after this calendar date).
      final reactionDate =
          filedAt != null &&
              (filedAt.hour > 15 ||
                  (filedAt.hour == 15 && filedAt.minute >= 30))
          ? DateTime(date.year, date.month, date.day + 1)
          : date;
      final label = quarterLabel(
        relatingTo: '${row['relatingTo'] ?? ''}',
        periodEnd: parseNseDate('${row['toDate'] ?? ''}'),
      );
      final bucket = bySymbol.putIfAbsent(
        symbol,
        () => <String, ResultStamp>{},
      );
      final key =
          '${date.year.toString().padLeft(4, '0')}-'
          '${date.month.toString().padLeft(2, '0')}-'
          '${date.day.toString().padLeft(2, '0')}';
      final existing = bucket[key];
      // Ek din do baar filing = ek result. Period chhota ho to chhod do.
      if (existing != null && existing.period.isNotEmpty) continue;
      bucket[key] = ResultStamp(
        date: date,
        period: label,
        reactionDate: reactionDate,
      );
    }

    return <String, List<ResultStamp>>{
      for (final entry in bySymbol.entries)
        entry.key:
            (entry.value.values.toList()
                  ..sort((a, b) => b.date.compareTo(a.date)))
                .take(perSymbol)
                .toList(growable: false),
    };
  }

  /// Combines both feeds into the table the UI reads.
  static Map<String, EarningsInfo> merge({
    required List<BoardMeeting> meetings,
    required Map<String, (DateTime date, String label)> lastResults,
    required DateTime today,
  }) {
    final day = DateTime(today.year, today.month, today.day);

    // Next: the earliest announced meeting that has not happened yet.
    // Two piles: meetings that have not happened yet (today counts — the
    // numbers are due today) and meetings that already happened.
    final upcoming = <String, BoardMeeting>{};
    final held = <String, BoardMeeting>{};
    for (final meeting in meetings) {
      if (meeting.date.isBefore(day)) {
        final current = held[meeting.symbol];
        if (current == null || meeting.date.isAfter(current.date)) {
          held[meeting.symbol] = meeting;
        }
      } else {
        final current = upcoming[meeting.symbol];
        if (current == null || meeting.date.isBefore(current.date)) {
          upcoming[meeting.symbol] = meeting;
        }
      }
    }

    final symbols = {...lastResults.keys, ...upcoming.keys, ...held.keys};
    final out = <String, EarningsInfo>{};

    for (final symbol in symbols) {
      final filing = lastResults[symbol];
      var meeting = upcoming[symbol];

      // A meeting the company has already reported on is *consumed*: once a
      // filing is on record on/after the meeting date, that meeting is a past
      // result and must never appear as the "next" one. (Before this rule the
      // calendar showed "next: aaj" on result day, even hours after the
      // numbers were out.)
      if (meeting != null &&
          filing != null &&
          !filing.$1.isBefore(meeting.date)) {
        meeting = null;
      }

      final heldMeeting = held[symbol];

      // Last result: the filing when it is at least as new as the last held
      // meeting, otherwise the meeting itself — a company that has already
      // declared shows its date even before NSE's filings feed catches up.
      DateTime? lastDate;
      var lastLabel = '';
      if (filing != null &&
          (heldMeeting == null || !filing.$1.isBefore(heldMeeting.date))) {
        lastDate = filing.$1;
        lastLabel = filing.$2;
      } else if (heldMeeting != null) {
        lastDate = heldMeeting.date;
        lastLabel = 'board meeting hui';
      }

      if (meeting != null) {
        out[symbol] = EarningsInfo(
          lastDate: lastDate,
          lastLabel: lastLabel,
          nextDate: meeting.date,
          nextLabel: 'board meeting confirm',
          nextConfirmed: true,
        );
        continue;
      }

      // Nothing announced → **no next date**. (Up to 1.5.12 this guessed one
      // a quarter after the last result. A guessed date is worse than no date:
      // it reads as a fact and moves the stock's row to the wrong day, so the
      // user asked for it gone.) What the row keeps is its last result, which
      // is a fact, and which is now the line the calendar prints for it.
      out[symbol] = EarningsInfo(lastDate: lastDate, lastLabel: lastLabel);
    }
    return out;
  }

  /// `30-Oct-2023` → 2023-10-30.
  static DateTime? parseNseDate(String raw) {
    final text = raw.trim();
    if (text.isEmpty) return null;
    try {
      return DateTime.parse(text); // already ISO
    } catch (_) {
      // fall through to the exchange format
    }
    final parts = text.split('-');
    if (parts.length != 3) return null;
    final day = int.tryParse(parts[0]);
    final year = int.tryParse(parts[2]);
    final token = parts[1].trim().toUpperCase();
    if (token.length < 3) return null;
    // `_months` is human-cased ("Jan"); NSE sends "Jan"/"JAN" depending on the
    // endpoint, so compare case-insensitively.
    final month = _months.indexWhere(
      (name) => name.toUpperCase() == token.substring(0, 3),
    );
    if (day == null || year == null || month < 0) return null;
    if (day < 1 || day > 31) return null;
    return DateTime(year, month + 1, day);
  }

  /// `16-Jan-2025 20:20:54` → 2025-01-16 (the filing day).
  static DateTime? parseNseStamp(String raw) {
    final text = raw.trim();
    if (text.isEmpty) return null;
    final dateOnly = text.split(' ').first;
    return parseNseDate(dateOnly) ?? DateTime.tryParse(text);
  }

  /// Filing ka poora local timestamp, agar NSE ne time diya ho.
  ///
  /// `16-Jan-2025 20:20:54` → `2025-01-16 20:20:54`; sirf date wale row par
  /// `null` (reaction day ke liye tab filing day hi maana jayega).
  static DateTime? parseNseDateTime(String raw) {
    final text = raw.trim();
    if (text.isEmpty) return null;
    final iso = DateTime.tryParse(text);
    if (iso != null) return iso;

    final parts = text.split(RegExp(r'\s+'));
    if (parts.length < 2) return null;
    final date = parseNseDate(parts.first);
    if (date == null) return null;
    final clock = parts[1].split(':');
    if (clock.length < 2) return null;
    final hour = int.tryParse(clock[0]);
    final minute = int.tryParse(clock[1]);
    final second = clock.length > 2 ? int.tryParse(clock[2]) ?? 0 : 0;
    if (hour == null || minute == null || hour > 23 || minute > 59) return null;
    return DateTime(date.year, date.month, date.day, hour, minute, second);
  }

  /// `Third Quarter` + `31-Dec-2024` → `Q3 · quarter ended Dec 2024`.
  static String quarterLabel({
    required String relatingTo,
    DateTime? periodEnd,
  }) {
    final words = relatingTo.toLowerCase();
    final quarter = switch (words) {
      final w when w.contains('first') => 'Q1',
      final w when w.contains('second') => 'Q2',
      final w when w.contains('third') => 'Q3',
      final w when w.contains('fourth') => 'Q4',
      final w when w.contains('annual') => 'Annual',
      _ => '',
    };
    final end = periodEnd == null
        ? ''
        : 'quarter ended ${_monthYear(periodEnd)}';
    if (quarter.isEmpty) return end;
    if (end.isEmpty) return quarter;
    if (quarter == 'Annual') return end.replaceFirst('quarter', 'year');
    return '$quarter · $end';
  }

  static String _monthYear(DateTime date) =>
      '${_months[date.month - 1]} ${date.year}';

  static const List<String> _months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];

  /// Tolerates both a bare list and a `{data: [...]}` envelope, and any junk.
  static Iterable<Map<String, dynamic>> _rows(String jsonText) {
    try {
      final decoded = jsonDecode(jsonText);
      if (decoded is List) return decoded.whereType<Map<String, dynamic>>();
      if (decoded is Map && decoded['data'] is List) {
        return (decoded['data'] as List).whereType<Map<String, dynamic>>();
      }
    } catch (_) {
      // Not JSON (an HTML block page, a redirect…) — treat as no data.
    }
    return const [];
  }

  /// `true` when [date] is inside the cached calendar's usefulness window.
  static bool isUpcoming(DateTime date, DateTime today) {
    final day = DateTime(today.year, today.month, today.day);
    return !date.isBefore(day);
  }

  /// Debug helper used by Settings → Diagnostics.
  String describe(EarningsInfo info) {
    final last = info.lastDate == null
        ? 'last: —'
        : 'last: ${Fmt.date(info.lastDate!)} ${info.lastLabel}';
    final announced = info.announcedNext;
    final next = announced == null
        ? 'next: —'
        : 'next: ${Fmt.date(announced)} (board meeting confirm)';
    return '$last · $next';
  }
}

/// ---------------------------------------------------------------------------
/// The tiny NSE HTTP client: the JSON APIs need a session cookie, so the
/// warm-up response's `set-cookie` values are replayed on the next request —
/// which is exactly what a browser does and what the exchange checks for.
///
/// It uses the same plain UA + same-site Referer that the shipped NSE listing
/// service uses (the archive 403s bare bots).
/// ---------------------------------------------------------------------------
class NseHttp {
  NseHttp({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;
  final Map<String, String> _cookies = {};

  /// Browser-shaped headers. NSE fronts its APIs with a bot filter: a UA that is
  /// not a real browser string (our first version said `NiveshDesk`) gets an
  /// HTML block page back, which used to parse as "no data" and blank the page.
  static const Map<String, String> _baseHeaders = {
    'User-Agent':
        'Mozilla/5.0 (Linux; Android 13; K) AppleWebKit/537.36 '
        '(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
    'Referer': 'https://www.nseindia.com/',
    'X-Requested-With': 'XMLHttpRequest',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'en-IN,en;q=0.9',
  };

  /// GETs [uri] and returns the body, carrying this client's own NSE session
  /// cookies along. No browser/user cookies are read or requested.
  Future<String> get(Uri uri) => getWithReferer(uri);

  /// Same public request, with a page-specific same-site Referer for NSE's
  /// filing feeds. [refererPath] must be a path on nseindia.com.
  Future<String> getWithReferer(Uri uri, {String? refererPath}) async {
    final referer = refererPath == null
        ? null
        : 'https://www.nseindia.com$refererPath';
    final response = await _client
        .get(
          uri,
          headers: {
            ..._baseHeaders,
            if (referer != null) 'Referer': referer,
            if (_cookies.isNotEmpty) 'Cookie': _cookieHeader,
          },
        )
        .timeout(const Duration(seconds: 45));

    _absorbCookies(response.headers['set-cookie']);
    if (response.statusCode >= 400) {
      throw http.ClientException(
        'NSE ne HTTP ${response.statusCode} diya (${uri.path}).',
        uri,
      );
    }
    return response.body;
  }

  String get _cookieHeader =>
      _cookies.entries.map((e) => '${e.key}=${e.value}').join('; ');

  void _absorbCookies(String? raw) {
    if (raw == null || raw.isEmpty) return;
    for (final part in raw.split(',')) {
      final pair = part.split(';').first.trim();
      final eq = pair.indexOf('=');
      if (eq <= 0) continue;
      _cookies[pair.substring(0, eq)] = pair.substring(eq + 1);
    }
  }

  void close() => _client.close();
}
