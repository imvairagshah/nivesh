// ---------------------------------------------------------------------------
// notification_service.dart — 1.5.74 OS-level notifications.
//
//   • Android  → flutter_local_notifications (channel "NiveshDesk Alerts")
//   • Windows  → local_notifier (toast)
//   • Linux    → flutter_local_notifications Linux impl (smoke builds)
//   • Baaki    → no-op (in-app bell hamesha kaam karta hai)
//
// Har call try/catch me hai — notification kabhi app crash nahi karega.
// ---------------------------------------------------------------------------

import 'dart:io' show Platform;

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:local_notifier/local_notifier.dart';

class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  bool _inited = false;
  bool _windows = false;
  int _nextId = 1;

  Future<void> init() async {
    if (_inited || kIsWeb) return;
    try {
      if (Platform.isWindows) {
        await LocalNotifier.instance.setup(
          appName: 'NiveshDesk',
          shortcutPolicy: ShortcutPolicy.requireCreate,
        );
        _windows = true;
      } else if (Platform.isAndroid || Platform.isLinux) {
        const android = AndroidInitializationSettings('@mipmap/ic_launcher');
        const linux = LinuxInitializationSettings(defaultActionName: 'open');
        await _plugin.initialize(
          settings: const InitializationSettings(
            android: android,
            linux: linux,
          ),
          onDidReceiveNotificationResponse: (response) {
            final p = response.payload;
            if (p != null && p.isNotEmpty) {
              final cb = onPayload;
              if (cb != null) {
                cb(p);
              } else {
                pendingPayload = p;
              }
            }
          },
        );
        if (Platform.isAndroid) {
          await _plugin
              .resolvePlatformSpecificImplementation<
                  AndroidFlutterLocalNotificationsPlugin>()
              ?.requestNotificationsPermission();
        }
      }
      _inited = true;
    } catch (_) {
      // Init fail = sirf OS pop-up nahi aayega — in-app bell chalta rahega.
      _inited = false;
    }
  }

  /// Ek OS notification dikhao. Idempotent-ish: same title+body dubara jaldi
  /// nahi chhidakti (30 second ka dedupe window). [payload] tap-routing ke liye.
  final Map<String, DateTime> _recent = {};
  static const _dedupe = Duration(seconds: 30);

  /// Tap-routing: notification par tap karke app aaya to payload yahan milta
  /// hai; HomeShell usse destination kholta hai (e.g. 'morning_brief').
  static String? pendingPayload;
  static void Function(String payload)? onPayload;

  Future<void> show(String title, String body, {String? payload}) async {
    final key = '$title|$body';
    final now = DateTime.now();
    final last = _recent[key];
    if (last != null && now.difference(last) < _dedupe) return;
    _recent[key] = now;
    if (_recent.length > 200) {
      _recent.removeWhere(
          (_, t) => now.difference(t) > const Duration(minutes: 10));
    }

    if (!_inited) {
      // Ek baar aur try — init pehle fail hua ho to.
      await init();
      if (!_inited) return;
    }
    try {
      if (_windows) {
        await LocalNotification(title: title, body: body).show();
      } else if (Platform.isAndroid || Platform.isLinux) {
        await _plugin.show(
          id: _nextId++ % 2000000000,
          title: title,
          body: body,
          payload: payload,
          notificationDetails: const NotificationDetails(
            android: AndroidNotificationDetails(
              'niveshdesk_alerts',
              'NiveshDesk Alerts',
              channelDescription:
                  'Calls SL/target, price alerts aur study/scanner signals',
              importance: Importance.high,
              priority: Priority.high,
            ),
            linux: LinuxNotificationDetails(),
          ),
        );
      }
    } catch (_) {
      // Best effort — in-app log me alert already hai.
    }
  }
}
