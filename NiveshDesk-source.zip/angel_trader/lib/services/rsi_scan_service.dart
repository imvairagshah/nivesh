// ---------------------------------------------------------------------------
// rsi_scan_service.dart — the RSI scanner, start to finish.
//
// The brief: "Daily candle me RSI aaj kaun se stocks ka 67 ke upar aaya hai aur
// 33 ke neeche, with a table of stock name, price and RSI."
//
// For every instrument in the chosen universe it:
//
//   1. serves daily bars from the local cache when that cache already reaches
//      the as-of date, otherwise fetches them from SmartAPI (shared with the
//      Golden Cross scanner: 400 calendar days ≈ 275 sessions),
//   2. computes Wilder's RSI on the daily closes (`rsi_engine.dart`),
//   3. keeps the rows above the upper threshold and below the lower one —
//      with yesterday's RSI beside today's so "aaj cross hua" is knowable,
//   4. writes both lists to `scan_runs` so the tab opens instantly offline, and
//   5. reports progress after every instrument (bar + ETA + cancel).
//
// Rate limits drive the design exactly as in the cross scanner: the loop is
// strictly sequential, resumable, and never re-downloads bars it already has.
// Nothing here touches Flutter or the network directly — bars arrive through
// [CandleSource], so the whole service is unit-tested with a fake.
// ---------------------------------------------------------------------------

import 'dart:async';

import '../core/utils/markets.dart';
import '../data/local/dao/candle_dao.dart';
import '../data/local/dao/scan_cache_dao.dart';
import '../data/remote/api_client.dart';
import '../data/remote/dto/scrip.dart';
import '../features/rsi_scanner/rsi_engine.dart';
import 'candle_source.dart';
import 'daily_bars_loader.dart';

/// Live picture of an RSI scan, pushed to the UI after every instrument.
class RsiScanProgress {
  final int done;
  final int total;
  final int overbought;
  final int oversold;
  final int fromCache;
  final int fetched;
  final int failures;

  /// Ticker currently being processed (`SBIN`).
  final String current;

  const RsiScanProgress({
    required this.done,
    required this.total,
    required this.overbought,
    required this.oversold,
    required this.fromCache,
    required this.fetched,
    required this.failures,
    required this.current,
  });

  double get fraction => total == 0 ? 0 : (done / total).clamp(0, 1);

  int get hits => overbought + oversold;

  /// Rough ETA for the remaining instruments (≈360 ms per download, cached
  /// symbols are nearly free — so the estimate uses the observed fetch ratio).
  Duration get eta {
    final remaining = total - done;
    if (remaining <= 0 || done == 0) return Duration.zero;
    final fetchRatio = fetched / done;
    final perSymbol = Duration(milliseconds: (400 * fetchRatio + 8).round());
    return perSymbol * remaining;
  }
}

/// One instrument the scan could not use, with the reason (never silent).
class RsiSkip {
  final String symbol;
  final String reason;

  const RsiSkip({required this.symbol, required this.reason});
}

/// Outcome of one RSI scan (or of the last cached scan, rehydrated).
class RsiScanResult {
  final DateTime asOf;
  final DateTime runAt;
  final Duration duration;
  final String universeKey;
  final int universeSize;
  final int scanned;
  final int fromCache;
  final int fetched;
  final bool cancelled;
  final bool fromCacheOnly;

  /// The thresholds this run used — cached rows are re-labeled with them.
  final RsiThresholds thresholds;

  final List<RsiReading> overbought;
  final List<RsiReading> oversold;
  final List<RsiSkip> skips;

  const RsiScanResult({
    required this.asOf,
    required this.runAt,
    required this.universeKey,
    required this.overbought,
    required this.oversold,
    this.thresholds = const RsiThresholds(),
    this.duration = Duration.zero,
    this.universeSize = 0,
    this.scanned = 0,
    this.fromCache = 0,
    this.fetched = 0,
    this.cancelled = false,
    this.fromCacheOnly = false,
    this.skips = const [],
  });

  /// The scan collected the rows that were in-zone *when it ran*; the two
  /// getters below apply the thresholds that are in force **now**. That matters
  /// because editing the levels re-labels a cached table instantly — tightening
  /// hides a row, loosening brings it straight back, and neither costs an API
  /// call. (Rows never observed outside the zone cannot appear, of course: the
  /// scanner only stores hits.)
  List<RsiReading> rowsFor(RsiZone zone) => [
        for (final r in zone == RsiZone.oversold ? oversold : overbought)
          if (thresholds.zoneFor(r.rsi) == zone) r,
      ];

  int get overboughtCount => rowsFor(RsiZone.overbought).length;
  int get oversoldCount => rowsFor(RsiZone.oversold).length;

  int get hitCount => overboughtCount + oversoldCount;

  bool get isEmpty => hitCount == 0;

  int get freshCount => rowsFor(RsiZone.overbought)
          .where((r) => r.crossedAbove(thresholds.upper))
          .length +
      rowsFor(RsiZone.oversold).where((r) => r.crossedBelow(thresholds.lower)).length;

  /// `true` when the result was scanned for a different trading day than [day].
  bool isStaleFor(DateTime day) =>
      DateTime(asOf.year, asOf.month, asOf.day) !=
      DateTime(day.year, day.month, day.day);

  /// `Scanned 213/213 · 41 overbought, 18 oversold · 22/Jan/2026`
  String get summary {
    final suffix = cancelled ? ' (cancelled)' : '';
    if (fromCacheOnly) {
      return 'Cached scan · $overboughtCount overbought, '
          '$oversoldCount oversold';
    }
    return 'Scanned $scanned/$universeSize · $overboughtCount overbought, '
        '$oversoldCount oversold$suffix';
  }

  /// Rows that only crossed on the newest bar.
  String get freshSummary {
    final fresh = freshCount;
    if (fresh == 0) return '';
    return '$fresh naya cross';
  }
}

class RsiScanService {
  RsiScanService({
    required CandleSource source,
    required CandleDao candles,
    required ScanCacheDao cache,
    DateTime Function()? clock,
  })  : _source = source,
        _candles = candles,
        _cache = cache,
        _clock = clock ?? DateTime.now;

  final CandleSource _source;
  final CandleDao _candles;
  final ScanCacheDao _cache;
  final DateTime Function() _clock;

  /// `scan_runs.kind` used by this screener.
  static const String cacheKind = ScanKind.rsi;

  /// Same window as the Golden Cross scanner on purpose: one candle cache,
  /// 275-odd sessions, enough for a converged RSI and a 200-day average.
  static const int lookbackDays = CandleRequirement.lookbackCalendarDays;

  /// Refuse absurdly large universes (a mis-tap on "all instruments" would be
  /// ~15 minutes of rate-limited downloads).
  static const int maxInstruments = 2500;

  /// Above this the UI asks for confirmation before starting.
  static const int confirmAbove = 200;

  /// How old cached bars may get before a scan sweeps them.
  static const int retentionDays = 700;

  DailyBarsLoader _loaderFor(RsiThresholds thresholds) => DailyBarsLoader(
        source: _source,
        candles: _candles,
        minimumBars: thresholds.minimumBars,
        lookbackDays: lookbackDays,
      );

  // -------------------------------------------------------------------------
  // Cached results
  // -------------------------------------------------------------------------

  /// Last cached run, optionally for a specific [asOf] date.
  ///
  /// Rehydrated rows carry the thresholds they were scanned with, so a cached
  /// table is always labelled honestly even if the settings changed since.
  Future<RsiScanResult?> loadCached({DateTime? asOf}) async {
    final run = await _cache.latestRun(
      cacheKind,
      asOf: asOf == null ? null : _isoDate(asOf),
    );
    if (run == null) return null;

    final overbought = <RsiReading>[];
    final oversold = <RsiReading>[];

    // The payload is `{meta: {...}, rows: [...]}` — older builds wrote a plain
    // list, which is tolerated (defaults are used) so an upgrade never blanks
    // the tab.
    final payload = run.rows;
    Map<String, dynamic> meta = const {};
    List<Map<String, dynamic>> rows = const [];
    if (payload.length == 1 && payload.first['rows'] is List) {
      final metaRaw = payload.first['meta'];
      if (metaRaw is Map) meta = metaRaw.cast<String, dynamic>();
      rows = [
        for (final row in (payload.first['rows'] as List))
          if (row is Map) row.cast<String, dynamic>(),
      ];
    } else {
      rows = payload;
    }

    final thresholds = RsiThresholds(
      period: (meta['period'] as num? ?? 14).toInt(),
      upper: (meta['upper'] as num? ?? 67).toDouble(),
      lower: (meta['lower'] as num? ?? 33).toDouble(),
    ).sanitised();

    for (final row in rows) {
      try {
        final reading = RsiReading.fromRow(row);
        if (thresholds.zoneFor(reading.rsi) == RsiZone.oversold) {
          oversold.add(reading);
        } else {
          overbought.add(reading);
        }
      } catch (_) {
        // A row written by an older build must never crash the whole table.
      }
    }

    overbought.sort((a, b) => compareReadings(a, b, RsiZone.overbought, thresholds));
    oversold.sort((a, b) => compareReadings(a, b, RsiZone.oversold, thresholds));

    return RsiScanResult(
      asOf: DateTime.tryParse(run.asOf) ?? _clock(),
      runAt: run.createdAt,
      universeKey: '',
      thresholds: thresholds,
      overbought: overbought,
      oversold: oversold,
      fromCacheOnly: true,
    );
  }

  /// Drops the cached scan output (candles are kept, so the next scan is still
  /// fast — this only clears the rendered table).
  Future<void> clearCache() => _cache.clearRuns(cacheKind);

  // -------------------------------------------------------------------------
  // Scanning
  // -------------------------------------------------------------------------

  /// Scans [universe] for RSI extremes on [asOf].
  ///
  /// [onProgress] fires after every instrument; return `true` from [isCancelled]
  /// to stop early (already-fetched candles stay cached and the partial result
  /// is still returned and persisted).
  Future<RsiScanResult> scan({
    required List<Scrip> universe,
    required DateTime asOf,
    RsiThresholds thresholds = const RsiThresholds(),
    String universeKey = '',
    /// Optional `TICKER → company name` lookup (the F&O list carries names for
    /// the companies that also appear in the IPO master; the rest show their
    /// exchange and history length instead of a guessed name).
    Map<String, String> companyNames = const {},
    void Function(RsiScanProgress progress)? onProgress,
    bool Function()? isCancelled,
  }) async {
    final started = _clock();
    final day = DateTime(asOf.year, asOf.month, asOf.day);
    final t = thresholds.sanitised();
    final instruments = universe.length > maxInstruments
        ? universe.sublist(0, maxInstruments)
        : universe;
    final loader = _loaderFor(t);

    final overbought = <RsiReading>[];
    final oversold = <RsiReading>[];
    final skips = <RsiSkip>[];
    var fromCache = 0;
    var fetched = 0;
    var scanned = 0;
    var cancelled = false;

    for (var i = 0; i < instruments.length; i++) {
      if (isCancelled?.call() ?? false) {
        cancelled = true;
        break;
      }

      final scrip = instruments[i];
      final plain = Scrip.plainSymbol(scrip.symbol);

      try {
        final bars = await loader.barsFor(scrip, day);
        if (bars.usedCache) fromCache++;
        if (bars.downloaded) fetched++;

        if (bars.bars.isEmpty) {
          skips.add(RsiSkip(
            symbol: plain,
            reason: 'No daily candles available (suspended, delisted or the '
                'broker returned nothing for this token).',
          ));
        } else {
          final reading = rsiReadingFor(
            scrip: scrip,
            candles: bars.bars,
            thresholds: t,
            asOf: day,
            companyName: companyNames[plain],
          );

          if (reading == null) {
            skips.add(RsiSkip(
              symbol: plain,
              reason: 'Only ${bars.bars.length} daily bars available '
                  '(RSI(${t.period}) needs ${t.minimumBars}).',
            ));
          } else {
            // Both zones are collected in one pass: the user can flip between
            // "upar" and "neeche" without paying for a second scan.
            switch (t.zoneFor(reading.rsi)) {
              case RsiZone.overbought:
                overbought.add(reading);
              case RsiZone.oversold:
                oversold.add(reading);
              case RsiZone.neutral:
                break;
            }
          }
        }
        scanned++;
      } on ApiException catch (e) {
        skips.add(RsiSkip(symbol: plain, reason: e.message));
      } catch (e) {
        skips.add(RsiSkip(symbol: plain, reason: '$e'));
      }

      onProgress?.call(RsiScanProgress(
        done: i + 1,
        total: instruments.length,
        overbought: overbought.length,
        oversold: oversold.length,
        fromCache: fromCache,
        fetched: fetched,
        failures: skips.length,
        current: plain,
      ));
    }

    overbought.sort((a, b) => compareReadings(a, b, RsiZone.overbought, t));
    oversold.sort((a, b) => compareReadings(a, b, RsiZone.oversold, t));

    final result = RsiScanResult(
      asOf: day,
      runAt: started,
      duration: _clock().difference(started),
      universeKey: universeKey,
      universeSize: instruments.length,
      scanned: scanned,
      fromCache: fromCache,
      fetched: fetched,
      thresholds: t,
      cancelled: cancelled,
      overbought: overbought,
      oversold: oversold,
      skips: skips,
    );

    await _persist(result);

    // Housekeeping: keep the shared candle cache inside the lookback window.
    try {
      await _candles.prune(before: day.subtract(const Duration(days: retentionDays)));
    } catch (_) {
      // Pruning is best-effort; a failure must never fail a good scan.
    }

    return result;
  }

  /// Writes the result into `scan_runs` (replacing that day's earlier run).
  Future<void> _persist(RsiScanResult result) async {
    if (result.cancelled && result.isEmpty) return; // nothing worth keeping
    await _cache.saveRun(
      kind: cacheKind,
      asOf: _isoDate(result.asOf),
      rows: [
        {
          'meta': {
            'period': result.thresholds.period,
            'upper': result.thresholds.upper,
            'lower': result.thresholds.lower,
            'universe': result.universeKey,
          },
          'rows': [
            for (final r in result.overbought) r.toRow(),
            for (final r in result.oversold) r.toRow(),
          ],
        },
      ],
    );
  }

  static String _isoDate(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-'
      '${d.month.toString().padLeft(2, '0')}-'
      '${d.day.toString().padLeft(2, '0')}';
}
