// ---------------------------------------------------------------------------
// market_data_service.dart — everything that asks SmartAPI for prices.
//
//   POST /rest/secure/angelbroking/market/v1/quote/          (LTP, batched ×50)
//   POST /rest/secure/angelbroking/order/v1/getLtpData       (single LTP)
//   POST /rest/secure/angelbroking/historical/v1/getCandleData  (Feature 2)
//
// Rate limits (documented): 3 req/s and 180 req/min on getCandleData, 10 req/s
// on the quote endpoint. [ApiClient]'s limiter keeps us under both, and the
// Golden Cross scanner additionally pages sequentially rather than in parallel.
// ---------------------------------------------------------------------------

import 'dart:async';

import 'package:intl/intl.dart';

import '../core/utils/markets.dart';
import '../data/remote/api_client.dart';
import '../data/remote/dto/candle.dart';
import '../data/remote/dto/quote.dart';
import '../data/remote/dto/scrip.dart';
import 'study_market_data.dart';
import 'auth_service.dart';
import 'candle_source.dart';

class MarketDataService implements CandleSource, StudyMarketData {
  MarketDataService({required AuthService auth, ApiClient? client})
      : _auth = auth,
        _client = client ?? ApiClient();

  final AuthService _auth;
  final ApiClient _client;

  static const String _quotePath = '/rest/secure/angelbroking/market/v1/quote/';
  static const String _ltpPath = '/rest/secure/angelbroking/order/v1/getLtpData';
  static const String _greeksPath =
      '/rest/secure/angelbroking/marketData/v1/optionGreek';
  static const String _candlePath =
      '/rest/secure/angelbroking/historical/v1/getCandleData';

  /// SmartAPI accepts up to 50 tokens per quote call.
  static const int maxTokensPerCall = 50;

  /// Extra candles fetched beyond the 200 needed for SMA(200) — protects against
  /// long suspensions and freshly listed stocks (see CandleRequirement).
  static const int candleLookbackDays = CandleRequirement.lookbackCalendarDays;

  static final DateFormat _candleStamp = DateFormat('yyyy-MM-dd HH:mm');

  // -------------------------------------------------------------------------
  // Live price snapshots (IPO screener)
  // -------------------------------------------------------------------------

  /// Fetches last traded prices for [scrips].
  ///
  /// Returns a map keyed `EXCHANGE:PLAIN_SYMBOL` (e.g. `NSE:IDEA`) — exactly the
  /// key the screener engine looks up via `Ipo.priceKey`, so no re-keying is
  /// needed in the UI layer.
  ///
  /// Tokens are chunked 50 per request. A failure in one chunk does not lose the
  /// other chunks' prices; the error is surfaced only if *every* chunk failed.
  Future<Map<String, PricedValue>> fetchLtp(List<Scrip> scrips) async {
    final prices = <String, PricedValue>{};
    if (scrips.isEmpty) return prices;

    if (!await _auth.ensureValidSession()) {
      throw const ApiException(
        message: 'Not logged in to Angel One — showing cached prices.',
        isAuthError: true,
      );
    }

    final byExchange = <String, List<Scrip>>{};
    for (final scrip in scrips) {
      byExchange.putIfAbsent(scrip.exchange.code, () => []).add(scrip);
    }

    final chunks = <List<Scrip>>[];
    byExchange.forEach((_, list) {
      for (var i = 0; i < list.length; i += maxTokensPerCall) {
        chunks.add(list.sublist(
          i,
          i + maxTokensPerCall > list.length ? list.length : i + maxTokensPerCall,
        ));
      }
    });

    Object? lastError;
    var successes = 0;

    for (final chunk in chunks) {
      final exchange = chunk.first.exchange.code;
      try {
        final body = await _client.postJson(
          _quotePath,
          {
            'mode': 'LTP',
            'exchangeTokens': {
              exchange: chunk.map((e) => e.token).toList(),
            },
          },
          apiKey: _auth.session!.apiKey,
          bearerToken: _auth.session!.jwtToken,
          clientCode: _auth.session!.clientCode,
        );

        final data = body['data'];
        final fetched = (data is Map ? data['fetched'] : null);
        if (fetched is! List) continue;

        final now = DateTime.now();
        for (final row in fetched.whereType<Map>()) {
          final quote = MarketQuote.fromSmartApi(row.cast<String, dynamic>());
          if (quote.ltp <= 0) continue;
          final key = priceKeyFor(quote.exchange, quote.tradingSymbol);
          prices[key] = PricedValue(
            value: quote.ltp,
            asOf: now,
            isLive: true,
            changePct: quote.changePct,
          );
        }
        successes++;
      } on ApiException catch (e) {
        lastError = e;
        if (e.isAuthError) rethrow; // no point retrying the other chunks
      } catch (e) {
        lastError = e;
      }
    }

    if (successes == 0 && lastError != null) {
      throw lastError is ApiException
          ? lastError
          : ApiException(message: 'Price download failed: $lastError');
    }
    return prices;
  }

  /// Price key used everywhere in the app: `EXCHANGE:PLAIN_SYMBOL`.
  static String priceKeyFor(Exchange exchange, String tradingSymbol) =>
      '${exchange.code}:${Scrip.plainSymbol(tradingSymbol)}';

  /// Single-instrument LTP (paper-trading order form, stop-loss checks).
  Future<MarketQuote?> fetchSingleLtp(Scrip scrip) async {
    if (!await _auth.ensureValidSession()) return null;
    final body = await _client.postJson(
      _ltpPath,
      {
        'exchange': scrip.exchange.code,
        'tradingsymbol': scrip.symbol,
        'symboltoken': scrip.token,
      },
      apiKey: _auth.session!.apiKey,
      bearerToken: _auth.session!.jwtToken,
      clientCode: _auth.session!.clientCode,
    );
    if (body['status'] != true || body['data'] is! Map) return null;
    return MarketQuote.fromSmartApi((body['data'] as Map).cast<String, dynamic>());
  }

  // -------------------------------------------------------------------------
  // F&O module: full quotes (LTP + previous close) and option greeks (IV)
  // -------------------------------------------------------------------------

  /// Batched **full** quotes keyed by instrument token.
  ///
  /// The F&O study needs two fields at once that LTP mode does not carry:
  /// `ltp` (today's premium) and `close` (the previous session's premium, which
  /// powers the "agar kal jodi buy ki hoti" line). Mode `FULL` returns both, so
  /// one call per 50 tokens covers the whole ATM book of a scan.
  ///
  /// A failing chunk never loses the others; if *every* chunk fails the caller
  /// gets an exception so it can degrade the affected stocks instead of showing
  /// zeros.
  Future<Map<String, MarketQuote>> fetchQuotesFull(List<Scrip> scrips) async {
    final quotes = <String, MarketQuote>{};
    if (scrips.isEmpty) return quotes;

    if (!await _auth.ensureValidSession()) {
      throw const ApiException(
        message: 'Not logged in to Angel One.',
        isAuthError: true,
      );
    }

    final byExchange = <String, List<Scrip>>{};
    for (final scrip in scrips) {
      byExchange.putIfAbsent(scrip.exchange.code, () => []).add(scrip);
    }

    Object? lastError;
    var successes = 0;

    for (final entry in byExchange.entries) {
      final exchange = entry.key;
      final tokens = entry.value.map((s) => s.token).toList();
      for (var i = 0; i < tokens.length; i += maxTokensPerCall) {
        final slice = tokens.sublist(
          i,
          i + maxTokensPerCall > tokens.length ? tokens.length : i + maxTokensPerCall,
        );
        try {
          final body = await _client.postJson(
            _quotePath,
            {
              'mode': 'FULL',
              'exchangeTokens': {exchange: slice},
            },
            apiKey: _auth.session!.apiKey,
            bearerToken: _auth.session!.jwtToken,
            clientCode: _auth.session!.clientCode,
          );

          final data = body['data'];
          final fetched = (data is Map ? data['fetched'] : null);
          if (fetched is! List) continue;

          for (final row in fetched.whereType<Map>()) {
            final quote = MarketQuote.fromSmartApi(row.cast<String, dynamic>());
            if (quote.token.isEmpty) continue;
            quotes[quote.token] = quote;
          }
          successes++;
        } on ApiException catch (e) {
          lastError = e;
          if (e.isAuthError) rethrow;
        } catch (e) {
          lastError = e;
        }
      }
    }

    if (successes == 0 && lastError != null) {
      throw lastError is ApiException
          ? lastError
          : ApiException(message: 'Quote download failed: $lastError');
    }
    return quotes;
  }

  /// Implied volatilities for **one underlying + expiry**, straight from the
  /// broker's option-greek endpoint.
  ///
  /// One call returns every strike of that series, so a whole scan costs one
  /// request per stock instead of one per contract. Returns an empty map (with
  /// the reason in [OptionGreekBatch.error]) when the endpoint is unavailable —
  /// the study then reverse-solves IV from the premium with Black-Scholes.
  Future<OptionGreekBatch> fetchOptionGreeks({
    required String underlying,
    required String expiryLabel,
  }) async {
    if (underlying.trim().isEmpty || expiryLabel.trim().isEmpty) {
      return const OptionGreekBatch(byStrike: {}, error: 'missing-name');
    }
    if (!await _auth.ensureValidSession()) {
      throw const ApiException(
        message: 'Not logged in to Angel One.',
        isAuthError: true,
      );
    }

    try {
      final body = await _client.postJson(
        _greeksPath,
        {
          'name': underlying.trim().toUpperCase(),
          'expirydate': expiryLabel.trim().toUpperCase(),
        },
        apiKey: _auth.session!.apiKey,
        bearerToken: _auth.session!.jwtToken,
        clientCode: _auth.session!.clientCode,
      );

      if (body['status'] != true) {
        return OptionGreekBatch(
          byStrike: const {},
          error: '${body['message'] ?? 'greeks unavailable'}',
        );
      }

      final rows = body['data'];
      if (rows is! List) {
        return const OptionGreekBatch(byStrike: {}, error: 'no-data');
      }

      final byStrike = <String, double>{};
      for (final row in rows.whereType<Map>()) {
        final json = row.cast<String, dynamic>();
        final strike = _double(json['strikePrice']);
        final type = '${json['optionType'] ?? ''}'.trim().toUpperCase();
        final iv = _double(json['impliedVolatility']);
        if (strike == null || strike <= 0 || iv == null || iv <= 0) continue;
        if (type != 'CE' && type != 'PE') continue;
        byStrike[greeksKey(strike, type)] = iv;
      }

      return OptionGreekBatch(byStrike: byStrike, error: byStrike.isEmpty ? 'empty' : null);
    } on ApiException catch (e) {
      if (e.isAuthError) rethrow;
      return OptionGreekBatch(byStrike: const {}, error: e.message);
    } catch (e) {
      return OptionGreekBatch(byStrike: const {}, error: '$e');
    }
  }

  /// Key used to look a strike up inside [OptionGreekBatch.byStrike] — and by
  /// the study when it asks for "the ATM 2650 CE".
  static String greeksKey(double strike, String optionType) =>
      '${strike.toStringAsFixed(2)}|${optionType.toUpperCase()}';

  static double? _double(dynamic value) {
    if (value == null) return null;
    if (value is num) return value.toDouble();
    return double.tryParse('$value');
  }

  // -------------------------------------------------------------------------
  // Historical candles (Golden Cross screener)
  // -------------------------------------------------------------------------

  /// Daily candles for one instrument between [from] and [to] (inclusive).
  ///
  /// [exchange] defaults to NSE cash. SmartAPI caps `ONE_DAY` requests at 2000
  /// days, so a 400-calendar-day window is comfortably inside the limit.
  ///
  /// This is the [CandleSource] implementation consumed by the Feature 2
  /// scanner (`CrossScanService`).
  @override
  Future<List<Candle>> fetchDailyCandles({
    required Scrip scrip,
    required DateTime from,
    required DateTime to,
    String interval = 'ONE_DAY',
  }) async {
    if (!await _auth.ensureValidSession()) {
      throw const ApiException(
        message: 'Not logged in to Angel One.',
        isAuthError: true,
      );
    }

    final body = await _client.postJson(
      _candlePath,
      {
        'exchange': scrip.exchange.code,
        'symboltoken': scrip.token,
        'interval': interval,
        'fromdate': _candleStamp.format(from),
        'todate': _candleStamp.format(to),
      },
      apiKey: _auth.session!.apiKey,
      bearerToken: _auth.session!.jwtToken,
      clientCode: _auth.session!.clientCode,
    );

    if (body['status'] != true) {
      throw ApiException(
        message: '${body['message'] ?? 'Candle request failed'}',
        errorCode: '${body['errorcode'] ?? ''}',
      );
    }

    final rows = body['data'];
    if (rows is! List) return const [];

    final candles = <Candle>[];
    for (final row in rows) {
      if (row is! List) continue;
      try {
        candles.add(Candle.fromSmartApiRow(row));
      } catch (_) {
        // Skip malformed bars rather than dropping the whole series.
      }
    }
    // Oldest → newest: the SMA/crossover maths depends on this ordering.
    candles.sort((a, b) => a.time.compareTo(b.time));
    return candles;
  }

  /// Convenience wrapper: last [days] calendar days of daily candles.
  Future<List<Candle>> fetchDailyCandlesLookback({
    required Scrip scrip,
    int days = candleLookbackDays,
    DateTime? until,
  }) {
    final end = until ?? MarketCalendar.latestTradingDay();
    final start = end.subtract(Duration(days: days));
    // 15:30 on both ends so the last bar of the day is included.
    return fetchDailyCandles(
      scrip: scrip,
      from: DateTime(start.year, start.month, start.day, 9, 15),
      to: DateTime(end.year, end.month, end.day, 15, 30),
    );
  }

  void dispose() => _client.dispose();
}
