// ---------------------------------------------------------------------------
// ai_suggestion_service.dart — the "AI Suggestion" scan (F&O module).
//
// What one run does:
//   Phase 1  daily candles for every F&O stock (cache first — the study's
//            loader keeps ~400 days, which covers RSI, EMA 9/21, 50 DMA and the
//            52-week high/low without a single extra request).
//   Phase 2  score every stock on the user's filters, keep the ones that pass,
//            sort, and cut to the Top N (default 20).
//   Phase 3  only for those Top N: the option side — ATM pair + OTM pair from
//            the local contract book, then one batched quote call and one
//            greeks call per stock, so the card can name the exact contracts.
//
// Why the option work happens last: quoting 213 stocks would be ~9 batched
// calls and 213 greeks calls for rows nobody reads. Twenty is affordable, and
// the rate-limit discipline the user asked for is kept.
//
// Failure policy (same as the study): a stock whose data is missing is skipped
// with a reason, never scored on partial numbers. The list is short, honest and
// reproducible — that is the whole point of a local engine.
// ---------------------------------------------------------------------------

import 'dart:math' as math;

import '../data/local/dao/candle_dao.dart';
import '../data/local/dao/fno_contract_dao.dart';
import '../data/remote/api_client.dart';
import '../data/remote/dto/candle.dart';
import '../data/remote/dto/quote.dart';
import '../data/remote/dto/scrip.dart';
import '../features/fno/ai/ai_indicators.dart';
import '../features/fno/ai/ai_plan.dart';
import '../features/fno/ai/ai_suggestion.dart';
import '../features/fno/study/black_scholes.dart'
    show impliedVolatility, OptionType;
import '../features/fno/study/study_engine.dart';
import '../features/fno/study/strangle.dart';
import 'candle_source.dart';
import 'earnings_calendar_service.dart' show EarningsInfo;
import 'daily_bars_loader.dart';
import 'study_market_data.dart';

/// Why a stock did not make the list — shown in the "kaun chhoota" sheet.
class AiSkip {
  const AiSkip(this.symbol, this.reason);

  final String symbol;
  final String reason;
}

/// Why a stock was scored but did not make the list.
enum AiGate {
  /// Turnover was below the user's bar — too thin to trade honestly.
  liquidity('turnover kam (patla stock)'),

  /// The 3-month study score was below the user's bar.
  study('3-month study score kam'),

  /// The momentum score was below the user's bar.
  momentum('momentum score kam');

  const AiGate(this.label);

  final String label;
}

/// A stock that was judged and fell at one of the two gates.
///
/// Kept (with both numbers) so the screen can answer "itne kam kyun hain?" with
/// facts: which gate ate the list, and who was closest to clearing it.
class AiNearMiss {
  const AiNearMiss({
    required this.symbol,
    required this.score,
    required this.studyScore,
    required this.gate,
    this.turnoverCrore = 0,
  });

  final String symbol;
  final double score;
  final double studyScore;
  final double turnoverCrore;
  final AiGate gate;

  /// The number that failed, next to the bar it failed.
  String line(AiFilters filters) => switch (gate) {
        AiGate.liquidity => '$symbol · turnover ${turnoverCrore.toStringAsFixed(1)} cr < '
            '${filters.minTurnoverCrore.toStringAsFixed(0)} cr',
        AiGate.study => '$symbol · study ${studyScore.toStringAsFixed(1)} < '
            '${filters.minStudyScore.toStringAsFixed(1)}',
        AiGate.momentum => '$symbol · momentum ${score.toStringAsFixed(0)} < '
            '${filters.minScore.toStringAsFixed(0)}',
      };
}

/// The result of one run.
class AiSuggestionResult {
  const AiSuggestionResult({
    required this.asOf,
    required this.runAt,
    required this.duration,
    required this.universeSize,
    required this.scanned,
    required this.passedLiquidity,
    required this.passedStudy,
    required this.passedMomentum,
    required this.rows,
    required this.skips,
    required this.drops,
    required this.filters,
    required this.cancelled,
  });

  final DateTime asOf;
  final DateTime runAt;
  final Duration duration;
  final int universeSize;
  final int scanned;

  /// How many cleared the turnover (liquidity) gate.
  final int passedLiquidity;

  /// How many cleared the 3-month study gate.
  final int passedStudy;

  /// How many cleared **both** gates (before the Top-N cut).
  final int passedMomentum;

  /// The Top N, rank 1 … N.
  final List<AiSuggestion> rows;
  final List<AiSkip> skips;

  /// Judged but below a filter — every one of them, not just the closest.
  final List<AiNearMiss> drops;

  /// The closest misses (highest momentum score first), for the sheet.
  List<AiNearMiss> nearMisses([int limit = 10]) {
    final sorted = [...drops]
      ..sort((a, b) => b.score.compareTo(a.score));
    return sorted.take(limit).toList();
  }

  /// The filters the run used — printed on the screen so a list can always be
  /// read back against the thresholds that produced it.
  final AiFilters filters;
  final bool cancelled;

  bool get isEmpty => rows.isEmpty;

  /// `213 scan · 180 liquidity paar · 41 study paar · 12 momentum paar · 12 ideas`
  String get funnelLine => '$scanned scan hue · $passedLiquidity liquidity paar · '
      '$passedStudy study paar · $passedMomentum momentum paar · '
      '${rows.length} list me';
}

/// Progress for the UI, shaped like the study's so both screens read alike.
class AiProgress {
  const AiProgress({
    required this.stage,
    required this.done,
    required this.total,
    required this.fraction,
    required this.elapsed,
    this.current = '',
  });

  final String stage;
  final int done;
  final int total;
  final double fraction;
  final Duration elapsed;
  final String current;

  String get label => current.isEmpty ? '$stage $done/$total' : '$stage · $current';
}

class AiSuggestionService {
  AiSuggestionService({
    required CandleSource source,
    required CandleDao candles,
    required FnoContractDao contracts,
    required StudyMarketData marketData,
    DateTime Function()? clock,
  })  : _source = source,
        _candles = candles,
        _contracts = contracts,
        _market = marketData,
        _clock = clock ?? DateTime.now;

  final CandleSource _source;
  final CandleDao _candles;
  final FnoContractDao _contracts;
  final StudyMarketData _market;
  final DateTime Function() _clock;

  /// Bars needed before the engine will judge a stock. 60 sessions covers
  /// RSI(14), EMA 21 and 50 DMA; the 52-week numbers use whatever else exists.
  static const int minimumBars = 60;

  /// How much history to ask for (calendar days) — ~250 trading sessions.
  static const int lookbackDays = 400;

  /// How much dearer than the stock's own daily move the premium must be before
  /// it counts as "mehengi" (and the engine switches from a naked buy to a
  /// spread, or from "wait" to a strangle sell).
  static const double kExpensiveFactor = 1.25;

  /// Below this fraction of the spot price, a straddle's premium says the pair
  /// is quoted but not really traded.
  static const double kThinPremiumRatio = 0.002;

  Future<AiSuggestionResult> run({
    required List<Scrip> universe,
    required AiFilters filters,
    Map<String, String> companyNames = const {},

    /// `SYMBOL → earnings info`. Only **announced** (never estimated) next
    /// dates are read from it; a stock with a result inside the user's event
    /// window is not given a new option position.
    Map<String, EarningsInfo> events = const {},

    /// Paper capital — only used to size the plan (how many lots the risk
    /// budget allows). Nothing is ever ordered.
    double capital = 0,
    DateTime? asOf,
    void Function(AiProgress)? onProgress,
    bool Function()? isCancelled,
  }) async {
    final started = _clock();
    final day = asOf ?? started;
    final loader = DailyBarsLoader(
      source: _source,
      candles: _candles,
      minimumBars: minimumBars,
      lookbackDays: lookbackDays,
    );

    final skips = <AiSkip>[];
    final candidates = <_AiCandidate>[];
    var cancelled = false;

    // ---- Phase 1: candles + indicators ------------------------------------
    for (var i = 0; i < universe.length; i++) {
      if (isCancelled?.call() ?? false) {
        cancelled = true;
        break;
      }
      final scrip = universe[i];
      final plain = Scrip.plainSymbol(scrip.symbol);

      try {
        final bars = (await loader.barsFor(scrip, day)).bars;
        if (bars.length < minimumBars) {
          skips.add(AiSkip(
            plain,
            'Sirf ${bars.length} bars mile — kam se kam $minimumBars chahiye.',
          ));
        } else {
          candidates.add(_AiCandidate(scrip, bars));
        }
      } on ApiException catch (e) {
        skips.add(AiSkip(plain, e.message));
      } catch (e) {
        skips.add(AiSkip(plain, '$e'));
      }

      onProgress?.call(AiProgress(
        stage: 'Candles',
        done: i + 1,
        total: universe.length,
        current: plain,
        fraction: 0.7 * ((i + 1) / math.max(universe.length, 1)),
        elapsed: _clock().difference(started),
      ));
    }

    // ---- Phase 2: score, filter, rank -------------------------------------
    final scored = <_AiScored>[];
    final drops = <AiNearMiss>[];
    var passedLiquidity = 0;
    var passedStudy = 0;
    var passedMomentum = 0;
    for (final candidate in candidates) {
      final outcome = _score(
        candidate,
        companyNames: companyNames,
        filters: filters,
        day: day,
        events: events,
      );
      if (outcome.row != null) {
        passedLiquidity++;
        passedStudy++;
        passedMomentum++;
        scored.add(outcome.row!);
      } else if (outcome.drop != null) {
        // A stock that fell at a later gate cleared the earlier ones.
        if (outcome.drop!.gate == AiGate.study ||
            outcome.drop!.gate == AiGate.momentum) {
          passedLiquidity++;
        }
        if (outcome.drop!.gate == AiGate.momentum) passedStudy++;
        drops.add(outcome.drop!);
      }
    }

    scored.sort((a, b) {
      final byScore = b.row.score.compareTo(a.row.score);
      return byScore != 0 ? byScore : a.row.symbol.compareTo(b.row.symbol);
    });

    final top = scored.take(filters.topN).toList();

    // ---- Phase 3: the option side, for the Top N only ---------------------
    await _attachOptions(top, day: day, filters: filters, capital: capital);

    final rows = <AiSuggestion>[];
    for (var i = 0; i < top.length; i++) {
      rows.add(top[i].row.copyWithRank(i + 1));
    }

    return AiSuggestionResult(
      asOf: day,
      runAt: started,
      duration: _clock().difference(started),
      universeSize: universe.length,
      scanned: candidates.length,
      passedLiquidity: passedLiquidity,
      passedStudy: passedStudy,
      passedMomentum: passedMomentum,
      rows: rows,
      skips: skips,
      drops: drops,
      filters: filters,
      cancelled: cancelled,
    );
  }

  /// Scores one stock and applies the user's filters.
  ///
  /// Both numbers are always computed, even for a stock that fails the first
  /// gate — that is what lets the screen say *which* gate removed it and how
  /// close it came.
  _AiScoreOutcome _score(
    _AiCandidate candidate, {
    required Map<String, String> companyNames,
    required AiFilters filters,
    required DateTime day,
    Map<String, EarningsInfo> events = const {},
  }) {
    final plain = Scrip.plainSymbol(candidate.scrip.symbol);
    final bars = candidate.bars;
    final snap = buildSnapshot(bars);

    // The 3-month study's own numbers — reuse, do not reinvent.
    final study = computeStudy(
      scrip: candidate.scrip,
      candles: bars,
      asOf: day,
      companyName: companyNames[plain],
      underlying: plain,
    );
    final upMonths = study?.upMonths ?? 0;
    final studyScore = study?.score ?? 0;

    // Gate 0: can this be traded at all? A thin stock's "breakout" is not an
    // edge — the spread eats it.
    if (snap.turnoverCrore < filters.minTurnoverCrore) {
      // The momentum score is still computed, so the sheet can show how close
      // it came even though the gate is not a scoring one.
      return _AiScoreOutcome(
        drop: AiNearMiss(
          symbol: plain,
          score: 0,
          studyScore: 0,
          turnoverCrore: snap.turnoverCrore,
          gate: AiGate.liquidity,
        ),
      );
    }

    final pattern = detectPattern(
      bars,
      snap,
      oversold: filters.rsiOversold,
      overbought: filters.rsiOverbought,
      volumeSpike: filters.volumeSpike,
    );
    final direction = resolveDirection(snap, snap.return3m, snap.stackUp);
    final score = momentumScore(
      snap,
      oversold: filters.rsiOversold,
      overbought: filters.rsiOverbought,
      volumeSpike: filters.volumeSpike,
      nearHighPct: filters.nearHighPct,
      greenRatio: greenShare(bars),
      upMonths: upMonths.toDouble(),
    );
    // Gate 1: the 3-month study's own score (0…12).
    if (study == null || studyScore < filters.minStudyScore) {
      return _AiScoreOutcome(
        drop: AiNearMiss(
          symbol: plain,
          score: score,
          studyScore: studyScore,
          gate: AiGate.study,
        ),
      );
    }

    // Gate 2: the momentum score (0…100).
    if (score < filters.minScore) {
      return _AiScoreOutcome(
        drop: AiNearMiss(
          symbol: plain,
          score: score,
          studyScore: studyScore,
          gate: AiGate.momentum,
        ),
      );
    }

    final event = events[plain.toUpperCase()];
    final row = AiSuggestion(
      symbol: plain,
      name: companyNames[plain] ?? '',
      rank: 0,
      score: score,
      studyScore: studyScore,
      snapshot: snap,
      pattern: pattern,
      direction: direction,
      move: resolveMove(pattern, direction),
      rationale: buildRationale(
        snap: snap,
        pattern: pattern,
        direction: direction,
        return3m: snap.return3m,
        upMonths: upMonths,
        filters: filters,
      ),
      strategy: AiStrategy.none,
      resultDate: event?.announcedNext,
      resultConfirmed: event?.announcedNext != null,
    );

    return _AiScored(row: row, bars: bars, scrip: candidate.scrip, study: study)
        .asOutcome;
  }

  /// Fills in the option context (and therefore the suggested trade) for the
  /// shortlisted rows.
  ///
  /// Network cost is deliberately tiny: the ATM legs of the whole Top N go out
  /// in **one batched quote call** (≤ 50 tokens), the IV is reverse-solved from
  /// those same premiums with Black-Scholes (no greeks call per stock), and the
  /// OTM strikes are picked locally — so twenty ideas cost one request.
  Future<void> _attachOptions(
    List<_AiScored> rows, {
    required DateTime day,
    required AiFilters filters,
    required double capital,
  }) async {
    if (rows.isEmpty) return;

    final midnight = DateTime(day.year, day.month, day.day);
    final plans = <_AiOptionPlan>[];

    // ---- Round 1: the ATM pair of every shortlisted row --------------------
    for (var i = 0; i < rows.length; i++) {
      final row = rows[i];
      final plain = Scrip.plainSymbol(row.scrip.symbol);
      // The expiry is chosen, not taken: the nearest contract often has only a
      // few days left, which is wrong for a buyer (theta) and wrong for a
      // seller (no premium left). Take the first one with enough days; if none
      // has, fall back to the nearest and let the rules refuse the trade.
      AtmPair? pair;
      try {
        final dates = await _contracts.expiries(plain, from: day);
        if (dates.isEmpty) continue;
        final wanted = dates.firstWhere(
          (d) => d.difference(midnight).inDays >= filters.buyMinDte,
          orElse: () => dates.first,
        );
        pair = await _contracts.atmPair(
          underlying: plain,
          spot: rows[i].row.snapshot.ltp,
          asOf: wanted,
        );
      } catch (_) {
        pair = null; // degraded: no chain in the local book
      }
      if (pair == null) continue;
      plans.add(_AiOptionPlan(
        index: i,
        pair: pair,
        daysToExpiry: pair.expiryDate.difference(midnight).inDays,
      ));
    }
    if (plans.isEmpty) return;

    final quotes = await _quote([
      for (final plan in plans) ...[plan.pair.ce, plan.pair.pe],
    ]);
    if (quotes.isEmpty) return; // no premium anywhere → the cards say so

    // ---- IV and the OTM pair, both derived from those premiums -------------
    for (final plan in plans) {
      final scored = rows[plan.index];
      final spot = scored.row.snapshot.ltp;
      final ce = plan.pair.ce;
      final pe = plan.pair.pe;
      final ceLtp = ce == null ? null : quotes[ce.token]?.ltp;
      final peLtp = pe == null ? null : quotes[pe.token]?.ltp;

      final ivs = <double>[];
      if (ce != null && ceLtp != null) {
        final iv = _solveIv(ce, ceLtp, spot, plan.daysToExpiry);
        if (iv != null) ivs.add(iv);
      }
      if (pe != null && peLtp != null) {
        final iv = _solveIv(pe, peLtp, spot, plan.daysToExpiry);
        if (iv != null) ivs.add(iv);
      }
      final avgIv = ivs.isEmpty
          ? null
          : ivs.reduce((a, b) => a + b) / ivs.length;

      plan.ceLtp = ceLtp;
      plan.peLtp = peLtp;
      plan.straddleTotal =
          (ceLtp == null && peLtp == null) ? null : (ceLtp ?? 0) + (peLtp ?? 0);
      plan.avgIv = avgIv;
      if (avgIv == null) continue;

      // "Premium mehengi": the option charges more per day than the stock
      // actually moves (IV/√252 versus ATR%). One stock, no cross-sectional
      // percentile — the Top N is too small a sample for that to mean anything.
      final implied1d = avgIv / math.sqrt(252);
      plan.edgePct = scored.row.snapshot.atrPct - implied1d;
      plan.expensive = implied1d >= scored.row.snapshot.atrPct * kExpensiveFactor;

      // The sell-side OTM pair: closest to half the ATM jodi's premium.
      if (plan.straddleTotal == null || plan.straddleTotal! <= 0) continue;
      if (plan.daysToExpiry <= 0) continue; // expiry day: nothing to price
      List<FnoContract> chain;
      try {
        chain = await _contracts.chainOn(plan.pair.underlying, plan.pair.expiryDate);
      } catch (_) {
        continue;
      }
      if (chain.isEmpty) continue;
      plan.otm = pickStrangle(
        chain: chain,
        spot: spot,
        ivPercent: avgIv,
        daysToExpiry: plan.daysToExpiry,
        targetPremium: plan.straddleTotal! / 2,
      );
    }

    // ---- Strategy text -----------------------------------------------------
    for (final plan in plans) {
      final scored = rows[plan.index];
      final row = scored.row;
      final spot = row.snapshot.ltp;
      final total = plan.straddleTotal ?? 0;

      // A result date the exchange actually announced — never an estimate.
      final announced = row.resultConfirmed ? row.resultDate : null;
      final daysToResult = announced == null
          ? null
          : DateTime(announced.year, announced.month, announced.day)
              .difference(midnight)
              .inDays;

      final context = AiOptionContext(
        atmStrike: plan.pair.strike,
        otmCeStrike: plan.otm?.ceStrike,
        otmPeStrike: plan.otm?.peStrike,
        avgIv: plan.avgIv,
        straddleTotal: plan.straddleTotal,
        ivExpensive: plan.expensive,
        edgePct: plan.edgePct,
        lotSize: plan.pair.lotSize,
        daysToExpiry: plan.daysToExpiry,
        daysToResult: daysToResult,
        // Under 0.2 % of spot the pair is quoted, not traded — the spread is
        // wider than the edge.
        thin: plan.straddleTotal != null && total < spot * kThinPremiumRatio,
      );
      final strategy = resolveStrategy(
        direction: row.direction,
        pattern: row.pattern,
        snap: row.snapshot,
        options: context,
        filters: filters,
      );

      // ---- the trade plan ---------------------------------------------------
      // Only debit trades get a sized plan: a short option's cost is margin,
      // not premium, and pretending otherwise would be the worst kind of
      // arithmetic — the card says so instead.
      double? tradePremium;
      if (strategy.action == 'Buy') {
        tradePremium = strategy.name.startsWith('Straddle')
            ? plan.straddleTotal
            : (row.direction == AiDirection.bearish ? plan.peLtp : plan.ceLtp);
      }
      final tradePlan = strategy.wait
          ? null
          : buildTradePlan(
              snap: row.snapshot,
              direction: row.direction,
              pattern: row.pattern,
              premium: tradePremium,
              lotSize: plan.pair.lotSize,
              capital: capital,
              riskPct: filters.riskPct,
            );

      rows[plan.index] = rows[plan.index].copyWith(
        row: AiSuggestion(
          symbol: row.symbol,
          name: row.name,
          rank: row.rank,
          score: row.score,
          studyScore: row.studyScore,
          snapshot: row.snapshot,
          pattern: row.pattern,
          direction: row.direction,
          move: row.move,
          rationale: row.rationale,
          strategy: strategy,
          options: context,
          plan: tradePlan,
          // Carried across, or the re-built row would lose the event data.
          resultDate: row.resultDate,
          resultConfirmed: row.resultConfirmed,
        ),
      );
    }
  }

  /// Batched quotes, one call per 50 tokens — the same discipline the study
  /// keeps. A dead endpoint yields an empty map, never an exception, so the
  /// list of ideas survives without premiums.
  Future<Map<String, MarketQuote>> _quote(List<FnoContract?> wanted) async {
    final seen = <String>{};
    final scrips = <Scrip>[];
    for (final contract in wanted) {
      if (contract == null) continue;
      if (!seen.add(contract.token)) continue;
      scrips.add(contract.asScrip());
    }
    if (scrips.isEmpty) return const {};

    // Not const: the map is filled in as the batches come back.
    final out = <String, MarketQuote>{};
    final size = StudyMarketData.maxTokensPerCall;
    for (var i = 0; i * size < scrips.length; i++) {
      final slice = scrips.sublist(
        i * size,
        math.min((i + 1) * size, scrips.length),
      );
      try {
        out.addAll(await _market.fetchQuotesFull(slice));
      } on ApiException catch (_) {
        return out;
      } catch (_) {
        return out;
      }
    }
    return out;
  }

  /// Reverse-solved IV (percent) from one leg's traded premium.
  double? _solveIv(
    FnoContract contract,
    double premium,
    double spot,
    int daysToExpiry,
  ) {
    final solved = impliedVolatility(
      type: contract.isCall ? OptionType.call : OptionType.put,
      premium: premium,
      spot: spot,
      strike: contract.strike,
      daysToExpiry: daysToExpiry,
    );
    return solved.isSolved ? solved.iv! * 100 : null;
  }
}

/// One stock's candles, before scoring.
class _AiCandidate {
  const _AiCandidate(this.scrip, this.bars);

  final Scrip scrip;
  final List<Candle> bars;
}

/// What [_score] decided: a row that qualified, or the reason it did not.
class _AiScoreOutcome {
  const _AiScoreOutcome({this.row, this.drop});

  final _AiScored? row;
  final AiNearMiss? drop;
}

/// A scored row plus the data the option phase needs.
class _AiScored {
  const _AiScored({
    required this.row,
    required this.bars,
    required this.scrip,
    required this.study,
  });

  final AiSuggestion row;
  final List<Candle> bars;
  final Scrip scrip;
  final StudyRow study;

  _AiScored copyWith({required AiSuggestion row}) =>
      _AiScored(row: row, bars: bars, scrip: scrip, study: study);

  _AiScoreOutcome get asOutcome => _AiScoreOutcome(row: this);
}

/// What the option phase works out for one shortlisted row.
///
/// Mutable on purpose: it is filled in as the quotes come back.
class _AiOptionPlan {
  _AiOptionPlan({
    required this.index,
    required this.pair,
    required this.daysToExpiry,
  });

  final int index;
  final AtmPair pair;
  final int daysToExpiry;

  StranglePick? otm;

  /// The ATM legs' traded premiums — what the trade actually costs.
  double? ceLtp;
  double? peLtp;
  double? avgIv;
  double? straddleTotal;
  double? edgePct;
  bool expensive = false;
}
