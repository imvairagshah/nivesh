// ---------------------------------------------------------------------------
// daily_bars_loader.dart — "give me the daily bars for this instrument", cache
// first and network second.
//
// Extracted from the Golden Cross scanner so the RSI scanner can reuse it
// verbatim: both screen daily candles, both are limited by `getCandleData`'s 3
// requests/second, and both must never re-download bars they already have.
// Sharing the loader also means the two screeners share the *cache* — running
// the Golden Cross scan first makes an RSI scan almost instant, and the other
// way round.
//
// Rules kept identical to the original implementation:
//   • serve from SQLite when the cached series reaches the as-of date and holds
//     at least [minimumBars] bars;
//   • otherwise download a fixed [lookbackDays] window and replace that window
//     in the cache (so a re-scan never duplicates rows);
//   • if the download returns nothing (fresh listing, suspension, wrong
//     segment), fall back to whatever the cache had rather than erasing it;
//   • a damaged cache row must never stop a scan.
// ---------------------------------------------------------------------------

import '../data/local/dao/candle_dao.dart';
import '../data/remote/dto/candle.dart';
import '../data/remote/dto/scrip.dart';
import 'candle_source.dart';

/// The bars we ended up scanning, plus where they came from.
class DailyBars {
  final List<Candle> bars;
  final bool usedCache;
  final bool downloaded;

  const DailyBars({
    required this.bars,
    required this.usedCache,
    required this.downloaded,
  });

  static const DailyBars none =
      DailyBars(bars: [], usedCache: false, downloaded: false);
}

class DailyBarsLoader {
  DailyBarsLoader({
    required CandleSource source,
    required CandleDao candles,
    required this.minimumBars,
    this.lookbackDays = 400,
  })  : _source = source,
        _candles = candles;

  final CandleSource _source;
  final CandleDao _candles;

  /// Below this many bars the caller treats the instrument as unscannable.
  /// It also gates the cache: a cached series shorter than this is re-fetched.
  final int minimumBars;

  /// Calendar days of history requested per instrument.
  final int lookbackDays;

  /// Best available daily series for [scrip] up to [day] (inclusive).
  Future<DailyBars> barsFor(Scrip scrip, DateTime day) async {
    final from = day.subtract(Duration(days: lookbackDays));

    var cached = const <Candle>[];
    try {
      cached = await _candles.barsFor(
        exchange: scrip.exchange.code,
        symbol: scrip.symbol,
        from: from,
        to: day,
      );
    } catch (_) {
      cached = const []; // a damaged cache row must not stop the scan
    }

    final cachedReachesDate = cached.isNotEmpty &&
        !cached.last.istDate.isBefore(DateTime(day.year, day.month, day.day)) &&
        cached.length >= minimumBars;
    if (cachedReachesDate) {
      return DailyBars(bars: cached, usedCache: true, downloaded: false);
    }

    final downloaded = await _source.fetchDailyCandles(
      scrip: scrip,
      from: DateTime(from.year, from.month, from.day, 9, 15),
      to: DateTime(day.year, day.month, day.day, 15, 30),
    );

    if (downloaded.isEmpty) {
      // No bars in the window (freshly listed / suspended / wrong segment).
      // Keep whatever the cache had, so a temporarily failing endpoint does not
      // erase a usable series.
      return DailyBars(
        bars: cached,
        usedCache: cached.isNotEmpty,
        downloaded: true,
      );
    }

    try {
      await _candles.saveBars(
        exchange: scrip.exchange.code,
        symbol: scrip.symbol,
        bars: downloaded,
        replaceWindow: true,
        windowFrom: DateTime(from.year, from.month, from.day, 9, 15),
        windowTo: DateTime(day.year, day.month, day.day, 15, 30),
      );
    } catch (_) {
      // Caching is a nice-to-have; the freshly fetched bars are still scanned.
    }

    return DailyBars(bars: downloaded, usedCache: false, downloaded: true);
  }
}
