// ---------------------------------------------------------------------------
// scan_notifier.dart — optional "tell me when the daily scan finds something".
//
// The daily Golden Cross scan runs on its own after 6 PM IST. Without this the
// user has to remember to open the tab; with it, the phone (or a small server)
// gets a POST the moment hits appear — ntfy.sh, a Telegram bot endpoint, or your
// own webhook all accept the JSON body below.
//
// Design rules:
//   * never throw — a broken webhook must not fail a scan that already worked,
//   * never block the UI — the caller awaits with a short timeout and shows the
//     outcome as a chip,
//   * send data, not just prose: `text` for humans, `signals[]` for machines.
// ---------------------------------------------------------------------------

import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../features/golden_cross/cross_engine.dart';
import 'cross_scan_service.dart';

enum NotifyOutcome {
  /// No URL configured — nothing to do.
  skipped,

  /// The endpoint answered 2xx.
  sent,

  /// Anything else; [NotifyReport.detail] carries the reason.
  failed,
}

class NotifyReport {
  final NotifyOutcome outcome;
  final String detail;

  const NotifyReport(this.outcome, this.detail);

  bool get isSent => outcome == NotifyOutcome.sent;

  @override
  String toString() => 'NotifyReport(${outcome.name}: $detail)';
}

class ScanNotifier {
  ScanNotifier({
    http.Client? client,
    Duration timeout = const Duration(seconds: 12),
  })  : _http = client ?? http.Client(),
        _timeout = timeout;

  final http.Client _http;
  final Duration _timeout;

  /// Max signals embedded in the payload (the rest are summarised by count).
  static const int maxSignals = 15;

  /// POSTs a summary of [result] to [webhookUrl].
  Future<NotifyReport> send({
    required String webhookUrl,
    required CrossScanResult result,
    String universeLabel = '',
  }) async {
    final url = webhookUrl.trim();
    if (url.isEmpty) {
      return const NotifyReport(NotifyOutcome.skipped, 'No webhook configured.');
    }
    final uri = Uri.tryParse(url);
    if (uri == null || !uri.hasScheme) {
      return const NotifyReport(NotifyOutcome.failed, 'Webhook URL is not valid.');
    }

    final body = jsonEncode(
      buildPayload(result: result, universeLabel: universeLabel),
    );

    try {
      final response = await _http
          .post(
            uri,
            headers: const {'Content-Type': 'application/json'},
            body: body,
          )
          .timeout(_timeout);

      if (response.statusCode >= 200 && response.statusCode < 300) {
        return NotifyReport(
          NotifyOutcome.sent,
          'Webhook replied ${response.statusCode}.',
        );
      }
      return NotifyReport(
        NotifyOutcome.failed,
        'Webhook replied ${response.statusCode}.',
      );
    } on TimeoutException {
      return const NotifyReport(NotifyOutcome.failed, 'Webhook timed out.');
    } catch (e) {
      return NotifyReport(NotifyOutcome.failed, 'Webhook error: $e');
    }
  }

  /// The JSON body, exposed for tests and for the "copy payload" debug action.
  static Map<String, dynamic> buildPayload({
    required CrossScanResult result,
    String universeLabel = '',
  }) {
    final date = result.asOf;
    final iso = '${date.year.toString().padLeft(4, '0')}-'
        '${date.month.toString().padLeft(2, '0')}-'
        '${date.day.toString().padLeft(2, '0')}';

    final top = result.signals.take(maxSignals).map((s) {
      return {
        'symbol': s.symbol,
        'exchange': s.exchange.code,
        'direction': s.direction.code,
        'crossDate': _iso(s.crossDate),
        'ageBars': s.ageBars,
        'close': double.parse(s.lastClose.toStringAsFixed(2)),
        'sma50': double.parse(s.fast.toStringAsFixed(2)),
        'sma200': double.parse(s.slow.toStringAsFixed(2)),
        'gapPct': double.parse(s.gapPct.toStringAsFixed(2)),
        'chart': 'https://in.tradingview.com/chart/?symbol='
            '${Uri.encodeComponent('${s.exchange.code}:${s.symbol}')}',
      };
    }).toList();

    final headline =
        '${result.goldenCount} golden / ${result.deathCount} death cross'
        '${result.hitCount == 1 ? '' : 'es'} on $iso';

    return {
      'source': 'angel_trader',
      'kind': 'cross_scan',
      'title': 'Angel Trader — $headline',
      'message': headline,
      'text': _plainText(result, iso, universeLabel),
      'asOf': iso,
      'universe': universeLabel,
      'golden': result.goldenCount,
      'death': result.deathCount,
      'fresh': result.freshCount,
      'scanned': result.scanned,
      'signals': top,
      'truncated': result.signals.length > maxSignals,
    };
  }

  static String _plainText(
    CrossScanResult result,
    String iso,
    String universeLabel,
  ) {
    final buffer = StringBuffer()
      ..writeln('Angel Trader cross scan — $iso')
      ..writeln('Universe: ${universeLabel.isEmpty ? '—' : universeLabel}')
      ..writeln('${result.goldenCount} golden cross, ${result.deathCount} death cross');

    for (final s in result.signals.take(maxSignals)) {
      buffer.writeln(
        '• ${s.symbol} (${s.exchange.code}) ${s.direction.shortLabel} — '
        'SMA50 ${s.fast.toStringAsFixed(2)} vs SMA200 ${s.slow.toStringAsFixed(2)} '
        '(${s.gapPct >= 0 ? '+' : ''}${s.gapPct.toStringAsFixed(2)}%), '
        'close ${s.lastClose.toStringAsFixed(2)}',
      );
    }
    if (result.signals.length > maxSignals) {
      buffer.writeln('… and ${result.signals.length - maxSignals} more.');
    }
    buffer.write('Paper trading only — not investment advice.');
    return buffer.toString();
  }

  static String _iso(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-'
      '${d.month.toString().padLeft(2, '0')}-'
      '${d.day.toString().padLeft(2, '0')}';

  void dispose() => _http.close();
}

/// Convenience for tests and callers that only want the one-liner.
String describeSignals(List<CrossSignal> signals) =>
    '${signals.where((s) => s.direction == CrossDirection.golden).length} golden, '
    '${signals.where((s) => s.direction == CrossDirection.death).length} death';
