import '../../core/utils/markets.dart';
import '../../data/local/dao/scrip_dao.dart';
import '../../data/remote/dto/scrip.dart';
import 'nse_listing_service.dart';

/// One stock in the suggestion dropdown: a plain identity row the picker can
/// put into a basket. Always sourced from an official/local master — NSE's
/// listing master or the broker's scrip master — never invented.
class StockSuggestion {
  const StockSuggestion({
    required this.symbol,
    required this.companyName,
    required this.exchange,
    this.isin = '',
    this.scripCode = '',
  });

  /// NSE ticker (e.g. `SBILIFE`) or BSE six-digit code (e.g. `540719`).
  final String symbol;

  final String companyName;

  /// 'NSE' or 'BSE'.
  final String exchange;

  /// The ISIN when the master row carries one.
  final String isin;

  /// BSE six-digit scrip code when known (BSE rows, or resolved later).
  final String scripCode;

  @override
  bool operator ==(Object other) =>
      other is StockSuggestion &&
      other.exchange == exchange &&
      other.symbol == symbol;

  @override
  int get hashCode => Object.hash(exchange, symbol);
}

/// Merged, searchable stock master for the basket picker.
///
/// Sources: the official NSE listing master (ticker, name, ISIN) and the
/// broker's local cash scrip master (which also covers BSE-only listings).
/// Dual-listed stocks collapse to their NSE row — the scan pipeline then
/// uses the full NSE path; BSE-only rows stay BSE.
class StockSuggestionService {
  StockSuggestionService({
    required NseListingService listings,
    required ScripDao scripDao,
    this.listingTimeout = const Duration(seconds: 8),
  }) : _listings = listings,
       _scripDao = scripDao;

  final NseListingService _listings;
  final ScripDao _scripDao;

  /// The NSE master is enrichment — on a slow or blocked network it must
  /// never hold the typing dropdown hostage (the raw download can wait up to
  /// a minute; suggestions get [listingTimeout] and then move on to the
  /// broker master).
  final Duration listingTimeout;

  List<StockSuggestion>? _memo;
  DateTime? _memoAt;
  bool _memoDegraded = false;
  Future<void>? _refreshing;
  static const Duration cacheValidity = Duration(hours: 6);

  /// A degraded (NSE-master missing) list is re-tried far sooner, so the
  /// listing rows join the dropdown as soon as a fetch finally succeeds.
  static const Duration degradedValidity = Duration(seconds: 30);

  Future<List<StockSuggestion>> master({bool force = false}) async {
    final memo = _memo;
    if (!force &&
        memo != null &&
        _memoAt != null &&
        DateTime.now().difference(_memoAt!) <
            (_memoDegraded ? degradedValidity : cacheValidity)) {
      return memo;
    }
    if (!force && memo != null) {
      // Serve-stale-while-revalidate: the existing list answers the typing
      // dropdown immediately while a refresh runs in the background — a slow
      // or blocked network can never hold the dropdown hostage twice.
      _refreshing ??= _refresh().whenComplete(() => _refreshing = null);
      return memo;
    }
    return _refresh();
  }

  Future<List<StockSuggestion>> _refresh() async {
    final out = <StockSuggestion>[];
    final byIsin = <String, StockSuggestion>{};
    final isinBySymbol = <String, String>{};
    final seen = <String>{};

    void add(StockSuggestion row) {
      final key = '${row.exchange}:${row.symbol}';
      if (!seen.add(key)) return;
      if (row.isin.isNotEmpty) {
        final existing = byIsin[row.isin];
        if (existing != null) {
          // Same security already listed (usually as NSE) — one row per
          // ISIN keeps the dropdown from showing duplicates.
          return;
        }
        byIsin[row.isin] = row;
      }
      out.add(row);
    }

    var listingDegraded = false;
    try {
      final listings = await _listings
          .allListings()
          .timeout(listingTimeout);
      for (final listing in listings) {
        if (!listing.isMainboard) continue;
        isinBySymbol[listing.symbol.toUpperCase()] = listing.isin.toUpperCase();
        add(
          StockSuggestion(
            symbol: listing.symbol.toUpperCase(),
            companyName: listing.companyName,
            exchange: 'NSE',
            isin: listing.isin.toUpperCase(),
          ),
        );
      }
    } catch (_) {
      // The NSE master is enrichment; the broker master below still works.
      listingDegraded = true;
    }

    try {
      for (final scrip in await _scripDao.allEquities()) {
        if (!scrip.exchange.isCash) continue;
        final symbol = Scrip.plainSymbol(scrip.symbol).trim().toUpperCase();
        if (symbol.isEmpty) continue;
        // The listing master's ISIN (when known) enriches broker rows:
        // dual-listed names then collapse to the single NSE listing row
        // instead of appearing twice, and a BSE row keeps a resolvable
        // identity even when the broker master carries no ISIN.
        final isin = isinBySymbol[symbol] ?? '';
        if (scrip.exchange == Exchange.nse) {
          add(
            StockSuggestion(
              symbol: symbol,
              companyName: scrip.name,
              exchange: 'NSE',
              isin: isin,
            ),
          );
        } else {
          add(
            StockSuggestion(
              symbol: symbol,
              companyName: scrip.name.isEmpty ? symbol : scrip.name,
              exchange: 'BSE',
              isin: isin,
              scripCode: RegExp(r'^\d{5,6}$').hasMatch(symbol) ? symbol : '',
            ),
          );
        }
      }
    } catch (_) {
      // Empty broker master — suggestions then rest on the NSE master alone.
    }

    out.sort((a, b) => a.symbol.compareTo(b.symbol));
    _memo = out;
    _memoAt = DateTime.now();
    _memoDegraded = listingDegraded;
    return out;
  }

  /// Ranked matches for a typed query: symbol-prefix first, then symbol
  /// substring, then company-name word matches. Pure scoring in [scoreMatch]
  /// so tests can pin it.
  Future<List<StockSuggestion>> search(String query, {int limit = 8}) async {
    final rows = await master();
    return searchIn(rows, query, limit: limit);
  }

  /// The pure search over an already-built master.
  static List<StockSuggestion> searchIn(
    List<StockSuggestion> rows,
    String query, {
    int limit = 8,
  }) {
    final q = query.trim().toUpperCase();
    if (q.isEmpty) return const [];
    final scored = <(int, StockSuggestion)>[];
    for (final row in rows) {
      final score = scoreMatch(q, row);
      if (score >= 0) scored.add((score, row));
    }
    scored.sort((a, b) {
      final byScore = a.$1.compareTo(b.$1);
      if (byScore != 0) return byScore;
      return a.$2.symbol.compareTo(b.$2.symbol);
    });
    return scored.take(limit).map((e) => e.$2).toList(growable: false);
  }

  /// Match score (lower is better), or -1 when the row does not match.
  /// Exact ticker → 0; ticker prefix → 1; ticker substring → 2; company-name
  /// word prefix → 3; company-name substring → 4.
  static int scoreMatch(String upperQuery, StockSuggestion row) {
    final symbol = row.symbol.toUpperCase();
    if (symbol == upperQuery) return 0;
    if (symbol.startsWith(upperQuery)) return 1;
    if (symbol.contains(upperQuery)) return 2;
    final name = row.companyName.toUpperCase();
    if (RegExp(r'(^|[^A-Z0-9])' + RegExp.escape(upperQuery)).hasMatch(name)) {
      return 3;
    }
    if (name.contains(upperQuery)) return 4;
    return -1;
  }
}
