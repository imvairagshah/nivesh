// ---------------------------------------------------------------------------
// cross_scan_service.dart — the Feature 2 daily scan, start to finish.
//
// For every instrument in the chosen universe it:
//
//   1. serves the daily bars from the local candle cache when that cache already
//      reaches the requested date, otherwise fetches them from SmartAPI
//      (~400 calendar days ≈ 275 sessions, enough for a 200-day average),
//   2. runs the 50/200 SMA crossover search (`cross_engine.dart`),
//   3. collects the hits and writes them to `scan_runs` so the tab opens
//      instantly and works offline, and
//   4. reports progress after every instrument so the UI can show a bar, an ETA
//      and a cancel button.
//
// Rate limits drive the whole design: `getCandleData` allows 3 requests/second
// (180/min, 5000/hour) and [ApiClient] paces calls at ~2.8/s. The scan is
// therefore strictly sequential, resumable (a cancelled or failed run keeps
// whatever it already cached) and never re-fetches an instrument whose cached
// history already covers the as-of date.
//
// Nothing here knows about Flutter or the network directly: candles arrive
// through [CandleSource], so the whole service is unit-tested with a fake.
// ---------------------------------------------------------------------------

import 'dart:async';

import '../core/utils/markets.dart';
import '../data/local/dao/candle_dao.dart';
import '../data/local/dao/scan_cache_dao.dart';
import '../data/remote/api_client.dart';
import '../data/remote/dto/scrip.dart';
import '../features/golden_cross/cross_engine.dart';
import 'candle_source.dart';
import 'daily_bars_loader.dart';

/// Instruments the user can point the scanner at.
///
/// `key` is what gets persisted in settings; the label/description drive the
/// picker sheet in the Golden Cross tab.
class ScanUniverse {
  final String key;
  final String label;
  final String description;

  /// Whether the size has to be discovered from local data (vs. a fixed list).
  final bool dynamic;

  const ScanUniverse({
    required this.key,
    required this.label,
    required this.description,
    this.dynamic = true,
  });
}

/// A live picture of the scan, pushed to the UI after every instrument.
class CrossScanProgress {
  final int done;
  final int total;
  final int hits;
  final int fromCache;
  final int fetched;
  final int failures;

  /// Ticker currently being processed (`SBIN`).
  final String current;

  const CrossScanProgress({
    required this.done,
    required this.total,
    required this.hits,
    required this.fromCache,
    required this.fetched,
    required this.failures,
    required this.current,
  });

  double get fraction => total == 0 ? 0 : (done / total).clamp(0, 1);

  /// Rough ETA for the remaining instruments.
  ///
  /// Every symbol that still needs a download costs one rate-limited request
  /// (~360 ms with the default limiter); cached symbols are effectively free, so
  /// the estimate uses the observed fetch ratio of the run so far.
  Duration get eta {
    final remaining = total - done;
    if (remaining <= 0 || done == 0) return Duration.zero;
    final fetchRatio = fetched / done;
    final perSymbol = Duration(
      milliseconds: (400 * fetchRatio + 8).round(), // 400 ms fetch + local compute
    );
    return perSymbol * remaining;
  }
}

/// One instrument the scan could not use, with the reason (shown in the
/// "skipped" sheet so the failure is never silent).
class ScanSkip {
  final String symbol;
  final String reason;

  const ScanSkip({required this.symbol, required this.reason});
}

/// Outcome of one scan (or of the last cached scan, rehydrated).
class CrossScanResult {
  final DateTime asOf;
  final DateTime runAt;
  final Duration duration;
  final String universeKey;
  final int universeSize;
  final int scanned;
  final int fromCache;
  final int fetched;
  final bool includeDeath;
  final bool cancelled;
  final bool fromCacheOnly;
  final List<CrossSignal> signals;
  final List<ScanSkip> skips;

  const CrossScanResult({
    required this.asOf,
    required this.runAt,
    required this.universeKey,
    required this.signals,
    this.duration = Duration.zero,
    this.universeSize = 0,
    this.scanned = 0,
    this.fromCache = 0,
    this.fetched = 0,
    this.includeDeath = true,
    this.cancelled = false,
    this.fromCacheOnly = false,
    this.skips = const [],
  });

  int get hitCount => signals.length;

  int countOf(CrossDirection direction) =>
      signals.where((s) => s.direction == direction).length;

  int get goldenCount => countOf(CrossDirection.golden);
  int get deathCount => countOf(CrossDirection.death);
  int get freshCount => signals.where((s) => s.isFresh).length;

  bool get isEmpty => signals.isEmpty;

  /// `true` when the result was scanned for a different trading day than [day].
  bool isStaleFor(DateTime day) =>
      DateTime(asOf.year, asOf.month, asOf.day) !=
      DateTime(day.year, day.month, day.day);

  /// Human summary used in the header card and the webhook message.
  String get summary {
    final suffix = cancelled ? ' (cancelled)' : '';
    if (fromCacheOnly) {
      return 'Cached scan for ${_short(asOf)} · $goldenCount golden, '
          '$deathCount death';
    }
    return 'Scanned $scanned/$universeSize instruments for ${_short(asOf)} · '
        '$goldenCount golden, $deathCount death$suffix';
  }

  static String _short(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/'
      '${d.year}';
}

class CrossScanService {
  CrossScanService({
    required CandleSource source,
    required CandleDao candles,
    required ScanCacheDao cache,
    DateTime Function()? clock,
  })  : _source = source,
        _candles = candles,
        _cache = cache,
        _clock = clock ?? DateTime.now;

  final CandleSource _source;
  final CandleDao _candles;
  final ScanCacheDao _cache;
  final DateTime Function() _clock;

  /// Cache-first daily bars (shared with the RSI scanner — see
  /// `daily_bars_loader.dart`).
  late final DailyBarsLoader _loader = DailyBarsLoader(
    source: _source,
    candles: _candles,
    minimumBars: minimumBars,
    lookbackDays: lookbackDays,
  );

  /// `scan_runs.kind` used for this screener.
  static const String cacheKind = ScanKind.goldenCross;

  /// Bars below this are not enough for a 200-day average (see
  /// [CandleRequirement.minimumBars]).
  static const int minimumBars = CandleRequirement.minimumBars;

  /// Calendar days of history requested per instrument.
  static const int lookbackDays = CandleRequirement.lookbackCalendarDays;

  /// Refuse absurdly large universes: anything above this is almost certainly a
  /// mis-tap on "all instruments" and would take ~15 minutes of rate-limited
  /// downloads.
  static const int maxInstruments = 2500;

  /// Above this the UI asks the user to confirm before starting.
  static const int confirmAbove = 200;

  /// How old cached bars may get before a scan sweeps them.
  static const int retentionDays = 700;

  // -------------------------------------------------------------------------
  // Cached results
  // -------------------------------------------------------------------------

  /// Last cached run, optionally for a specific [asOf] date.
  ///
  /// Rehydrated results carry the signals only: per-run statistics (fetch count,
  /// skips, duration) belong to the run that produced them and are shown as
  /// zeroes / empty here, which the UI labels as "cached".
  Future<CrossScanResult?> loadCached({DateTime? asOf}) async {
    final run = await _cache.latestRun(
      cacheKind,
      asOf: asOf == null ? null : _isoDate(asOf),
    );
    if (run == null) return null;

    final signals = <CrossSignal>[];
    for (final row in run.rows) {
      try {
        signals.add(CrossSignal.fromRow(row));
      } catch (_) {
        // A row written by an older build must never crash the whole list.
      }
    }
    signals.sort(_byFreshness);

    return CrossScanResult(
      asOf: DateTime.tryParse(run.asOf) ?? _clock(),
      runAt: run.createdAt,
      universeKey: '',
      signals: signals,
      includeDeath: true,
      fromCacheOnly: true,
    );
  }

  /// Drops the cached scan output.
  Future<void> clearCache() => _cache.clearRuns(cacheKind);

  // -------------------------------------------------------------------------
  // Scanning
  // -------------------------------------------------------------------------

  /// Scans [universe] for crosses on [asOf].
  ///
  /// [onProgress] fires after every instrument; return `true` from
  /// [isCancelled] to stop early (already-fetched candles stay cached, and the
  /// partial result is still returned and persisted).
  Future<CrossScanResult> scan({
    required List<Scrip> universe,
    required DateTime asOf,
    CrossDirection direction = CrossDirection.golden,
    bool includeDeath = true,
    int maxAgeBars = 5,
    int fastPeriod = CrossSignal.kFastPeriod,
    int slowPeriod = CrossSignal.kSlowPeriod,
    String universeKey = '',
    void Function(CrossScanProgress progress)? onProgress,
    bool Function()? isCancelled,
  }) async {
    final started = _clock();
    final day = DateTime(asOf.year, asOf.month, asOf.day);
    final instruments = universe.length > maxInstruments
        ? universe.sublist(0, maxInstruments)
        : universe;

    final directions = <CrossDirection>[
      direction,
      if (includeDeath && direction == CrossDirection.golden)
        CrossDirection.death,
    ];

    final signals = <CrossSignal>[];
    final skips = <ScanSkip>[];
    var fromCache = 0;
    var fetched = 0;
    var scanned = 0;
    var cancelled = false;

    for (var i = 0; i < instruments.length; i++) {
      if (isCancelled?.call() ?? false) {
        cancelled = true;
        break;
      }

      final scrip = instruments[i];
      final plain = Scrip.plainSymbol(scrip.symbol);

      try {
        final bars = await _barsFor(scrip, day);
        if (bars.usedCache) fromCache++;
        if (bars.downloaded) fetched++;

        if (bars.bars.length < minimumBars) {
          skips.add(ScanSkip(
            symbol: plain,
            reason: 'Only ${bars.bars.length} daily bars available '
                '(needs $minimumBars).',
          ));
        } else {
          for (final dir in directions) {
            final signal = findCross(
              candles: bars.bars,
              asOf: day,
              symbol: plain,
              direction: dir,
              exchange: scrip.exchange,
              brokerSymbol: scrip.symbol,
              companyName: scrip.name,
              token: scrip.token,
              fastPeriod: fastPeriod,
              slowPeriod: slowPeriod,
              maxAgeBars: maxAgeBars,
            );
            if (signal != null) signals.add(signal);
          }
        }
        scanned++;
      } on ApiException catch (e) {
        skips.add(ScanSkip(symbol: plain, reason: e.message));
      } catch (e) {
        skips.add(ScanSkip(symbol: plain, reason: '$e'));
      }

      onProgress?.call(CrossScanProgress(
        done: i + 1,
        total: instruments.length,
        hits: signals.length,
        fromCache: fromCache,
        fetched: fetched,
        failures: skips.length,
        current: plain,
      ));
    }

    signals.sort(_byFreshness);

    final result = CrossScanResult(
      asOf: day,
      runAt: started,
      duration: _clock().difference(started),
      universeKey: universeKey,
      universeSize: instruments.length,
      scanned: scanned,
      fromCache: fromCache,
      fetched: fetched,
      includeDeath: directions.contains(CrossDirection.death),
      cancelled: cancelled,
      signals: signals,
      skips: skips,
    );

    await _persist(result);

    // Housekeeping: keep the cache inside the screener's own lookback window.
    try {
      await _candles.prune(
        before: day.subtract(const Duration(days: retentionDays)),
      );
    } catch (_) {
      // Pruning is best-effort; a failure must never fail a good scan.
    }

    return result;
  }

  /// Writes the result into `scan_runs` (replacing that day's earlier run).
  Future<void> _persist(CrossScanResult result) async {
    if (result.cancelled && result.signals.isEmpty) return; // nothing worth keeping
    await _cache.saveRun(
      kind: cacheKind,
      asOf: _isoDate(result.asOf),
      rows: [for (final s in result.signals) s.toRow()],
    );
  }

  // -------------------------------------------------------------------------
  // Bars: cache first, network second
  // -------------------------------------------------------------------------

  /// Returns the best available daily series for [scrip] up to [day].
  ///
  /// The cache-first / download-second dance lives in [DailyBarsLoader] because
  /// the RSI scanner needs exactly the same behaviour.
  Future<DailyBars> _barsFor(Scrip scrip, DateTime day) =>
      _loader.barsFor(scrip, day);

  // -------------------------------------------------------------------------
  // Helpers
  // -------------------------------------------------------------------------

  /// Freshest first, then the widest SMA gap, then alphabetical — a stable,
  /// explainable order that does not shuffle between rebuilds.
  static int _byFreshness(CrossSignal a, CrossSignal b) {
    final age = a.ageBars.compareTo(b.ageBars);
    if (age != 0) return age;
    final gap = b.gapPct.abs().compareTo(a.gapPct.abs());
    if (gap != 0) return gap;
    return a.symbol.compareTo(b.symbol);
  }

  static String _isoDate(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-'
      '${d.month.toString().padLeft(2, '0')}-'
      '${d.day.toString().padLeft(2, '0')}';
}
