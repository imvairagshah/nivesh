// ---------------------------------------------------------------------------
// token_resolver.dart — symbol ➜ SmartAPI instrument-token resolution.
//
// Every quote request needs a numeric `symboltoken`, but the IPO database (and
// the user) speak in plain tickers: `IDEA`, `NYKAA`, `POLICYBZR`.
// Angel One's symbols carry suffixes (`IDEA-EQ`, `NYKAA-EQ`), so a direct
// string match is not enough.
//
// Resolution order (first hit wins):
//   1. exact match on the same exchange            → [TokenMatchKind.exact]
//   2. exact match on the other cash exchange      → [TokenMatchKind.crossExchange]
//   3. unique company-name match                   → [TokenMatchKind.nameMatch]
//   4. several name matches                        → [TokenMatchKind.ambiguous]
//   5. nothing                                     → [TokenMatchKind.none]
//
// This class is deliberately Flutter-free: it is fed raw JSON (either the daily
// ~50 MB scrip master or the bundled starter file) and is unit-tested in
// test/services/token_resolver_test.dart.
// ---------------------------------------------------------------------------

import 'dart:convert';

import '../core/utils/markets.dart';
import '../data/remote/dto/scrip.dart';

enum TokenMatchKind {
  /// Same exchange, same symbol.
  exact,

  /// Found on the other cash exchange (row keeps its own exchange).
  crossExchange,

  /// Matched by company name (unique).
  nameMatch,

  /// Several plausible instruments — the UI should ask the user to pick.
  ambiguous,

  /// Not found: exclude from scans and tell the user why.
  none,
}

class TokenResolution {
  final TokenMatchKind kind;
  final Scrip? scrip;

  /// Populated when [kind] is [TokenMatchKind.ambiguous].
  final List<Scrip> candidates;

  /// Short human-readable explanation shown on the screener card.
  final String note;

  const TokenResolution({
    required this.kind,
    this.scrip,
    this.candidates = const [],
    this.note = '',
  });

  bool get isResolved => scrip != null && kind != TokenMatchKind.none;
  String? get token => scrip?.token;

  @override
  String toString() => 'TokenResolution(${kind.name}, ${scrip?.key}, note="$note")';
}

class TokenResolver {
  /// Plain ticker (upper-case, no `-EQ`) → instruments on that ticker.
  final Map<String, List<Scrip>> _bySymbol = {};

  /// Upper-case company name → instruments (for the fuzzy/company-name path).
  final Map<String, List<Scrip>> _byName = {};

  final List<Scrip> _all;

  TokenResolver._(this._all);

  /// Builds a resolver from raw scrip-master JSON text (a JSON array of rows).
  ///
  /// Non-equity rows are filtered out via [Scrip.isEquityRow], so both the full
  /// master and the packaged starter file can be handed straight in.
  factory TokenResolver.fromJson(String jsonText) {
    final decoded = jsonDecode(jsonText);
    if (decoded is! List) {
      throw const FormatException(
        'Scrip master must be a JSON array of instrument rows.',
      );
    }
    return TokenResolver.fromRows(decoded.whereType<Map<String, dynamic>>());
  }

  /// Builds a resolver from already-parsed rows (used for the SQLite-cached
  /// master, which is stored as typed columns).
  factory TokenResolver.fromRows(Iterable<Map<String, dynamic>> rows) {
    final scrips = <Scrip>[];
    for (final row in rows) {
      if (!Scrip.isEquityRow(row)) continue;
      final scrip = Scrip.fromScripMaster(row);
      if (scrip.token.isEmpty || scrip.symbol.isEmpty) continue;
      scrips.add(scrip);
    }
    return TokenResolver.fromScrips(scrips);
  }

  factory TokenResolver.fromScrips(Iterable<Scrip> scrips) {
    final list = List<Scrip>.unmodifiable(scrips);
    final resolver = TokenResolver._(list);
    for (final scrip in list) {
      resolver._index(scrip);
    }
    return resolver;
  }

  void _index(Scrip scrip) {
    final plain = Scrip.plainSymbol(scrip.symbol);
    _bySymbol
        .putIfAbsent('${scrip.exchange.code}:$plain', () => <Scrip>[])
        .add(scrip);
    if (scrip.name.isNotEmpty) {
      final name = _normaliseName(scrip.name);
      if (name.isNotEmpty) {
        _byName.putIfAbsent(name, () => <Scrip>[]).add(scrip);
      }
    }
  }

  /// Total number of instruments known (diagnostics / "master loaded" chip).
  int get size => _all.length;

  List<Scrip> get all => _all;

  // -------------------------------------------------------------------------
  // Resolution
  // -------------------------------------------------------------------------

  /// Resolves [rawSymbol] for the given [preferredExchange].
  ///
  /// [companyName] is optional; supply it (from the IPO row) to unlock the
  /// company-name fallback when the ticker itself is not in the master.
  TokenResolution resolve(
    String rawSymbol, {
    Exchange preferredExchange = Exchange.nse,
    String companyName = '',
  }) {
    // Accept "NSE:IDEA" / "BSE:500112" as pasted from TradingView or the CSV and
    // let the prefix win over the caller's assumption.
    var exchange = preferredExchange;
    var raw = rawSymbol.trim();
    if (raw.contains(':')) {
      final parts = raw.split(':');
      exchange = Exchange.fromCode(parts.first);
      raw = parts.sublist(1).join(':');
    }

    final symbol = Scrip.plainSymbol(raw);
    if (symbol.isEmpty) {
      return const TokenResolution(
        kind: TokenMatchKind.none,
        note: 'Empty symbol.',
      );
    }
    final preferred = exchange;

    // 1. Same exchange, exact ticker.
    final sameExchange = _bySymbol['${preferred.code}:$symbol'];
    if (sameExchange != null && sameExchange.isNotEmpty) {
      final scrip = sameExchange.first;
      return TokenResolution(
        kind: TokenMatchKind.exact,
        scrip: scrip,
        note: sameExchange.length > 1
            ? '${sameExchange.length} instruments share this ticker; '
                'using token ${scrip.token}.'
            : '',
      );
    }

    // 2. Other cash exchange (e.g. an NSE-listed ticker that only trades on BSE
    //    after a merger/delisting).
    final otherExchange =
        preferred == Exchange.nse ? Exchange.bse : Exchange.nse;
    final cross = _bySymbol['${otherExchange.code}:$symbol'];
    if (cross != null && cross.isNotEmpty) {
      return TokenResolution(
        kind: TokenMatchKind.crossExchange,
        scrip: cross.first,
        note: 'Only listed on ${cross.first.exchange.code}.',
      );
    }

    // 3/4. Company-name fallback — only when the caller gave us a name.
    if (companyName.trim().isNotEmpty) {
      final candidates = _matchByName(companyName);
      if (candidates.length == 1) {
        return TokenResolution(
          kind: TokenMatchKind.nameMatch,
          scrip: candidates.first,
          note: 'Matched by company name → ${candidates.first.symbol}.',
        );
      }
      if (candidates.length > 1) {
        return TokenResolution(
          kind: TokenMatchKind.ambiguous,
          candidates: candidates.take(8).toList(growable: false),
          note: '${candidates.length} possible instruments — tap to choose.',
        );
      }
    }

    // 5. Nothing. The screener reports these so the user can fix the row.
    return TokenResolution(
      kind: TokenMatchKind.none,
      note: 'Token not found in the scrip master.',
    );
  }

  /// Free-text search for the "pick an instrument" dialog.
  List<Scrip> search(String query, {int limit = 25}) {
    final q = query.trim().toUpperCase();
    if (q.isEmpty) return const [];
    final results = <Scrip>[];
    for (final scrip in _all) {
      if (scrip.symbol.contains(q) || scrip.name.toUpperCase().contains(q)) {
        results.add(scrip);
        if (results.length >= limit) break;
      }
    }
    return results;
  }

  // -------------------------------------------------------------------------
  // Internals
  // -------------------------------------------------------------------------

  /// Company-name matching that tolerates the abbreviations Indian filings use:
  /// `FSN E-Commerce Ventures Ltd` (IPO row) vs `FSN E COMMERCE VENTURES LTD`
  /// (scrip master) must match.
  List<Scrip> _matchByName(String companyName) {
    final target = _normaliseName(companyName);
    if (target.isEmpty) return const [];

    // a) Exact normalised name.
    final exact = _byName[target];
    if (exact != null && exact.isNotEmpty) return exact;

    // b) Name containment either way.
    final hits = <Scrip>[];
    for (final entry in _byName.entries) {
      if (entry.key.contains(target) || target.contains(entry.key)) {
        hits.addAll(entry.value);
      }
    }
    if (hits.isNotEmpty) return hits;

    // c) Last resort: distinctive first two words ("FSN ECOMMERCE").
    final words = target.split(' ').where((w) => w.length > 2).toList();
    if (words.isEmpty) return const [];
    final needle = words.take(2).join(' ');
    for (final entry in _byName.entries) {
      if (entry.key.startsWith(needle)) hits.addAll(entry.value);
    }
    return hits;
  }

  /// Upper-cases, strips punctuation and the noise words that differ between
  /// the IPO spreadsheet and the broker master.
  static String _normaliseName(String name) => name
      .toUpperCase()
      .replaceAll(RegExp(r'[^A-Z0-9 ]'), ' ')
      .replaceAll(RegExp(r'\b(LIMITED|LTD|PVT|PRIVATE|INDIA|CO|COMPANY)\b'), ' ')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
}
