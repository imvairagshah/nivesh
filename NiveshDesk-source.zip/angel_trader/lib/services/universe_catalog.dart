// ---------------------------------------------------------------------------
// universe_catalog.dart — "which instruments do the screeners look at?"
//
// Asking Angel One for 400 daily candles of every listed company is both slow
// (3 requests/second) and pointless — most of those charts are illiquid. The
// user therefore picks a universe:
//
//   fno        – every NSE stock in the F&O segment (shipped list, 213 names),
//                the default for the RSI scanner
//   nifty50    – the 50 large caps below (a full scan takes ~20 s)
//   ipos       – the Feature 1 IPO database, so a recent listing can be checked
//                as soon as it has enough history
//   master_nse – every NSE cash equity in the local scrip master
//   master_all – NSE + BSE (only sensible once the full master is downloaded)
//
// Resolution always happens against *local* data (the SQLite scrip master and
// the IPO table), so switching universes costs nothing and works offline. Any
// ticker that cannot be resolved is reported in [UniverseResolution.missing]
// instead of being dropped silently — the picker shows "49 of 50 resolved".
// ---------------------------------------------------------------------------

import '../core/utils/markets.dart';
import '../data/local/dao/ipo_dao.dart';
import '../data/local/dao/scrip_dao.dart';
import '../data/remote/dto/scrip.dart';
import 'cross_scan_service.dart' show ScanUniverse;
import 'token_resolver.dart';

/// One resolved universe: the instruments plus what could not be found.
class UniverseResolution {
  final ScanUniverse universe;
  final List<Scrip> scrips;

  /// Plain tickers that had no instrument in the local scrip master.
  final List<String> missing;

  const UniverseResolution({
    required this.universe,
    required this.scrips,
    this.missing = const [],
  });

  int get size => scrips.length;
  bool get isEmpty => scrips.isEmpty;
  bool get hasMissing => missing.isNotEmpty;

  /// `Nifty 50 · 49 of 50 resolved`
  String get label => hasMissing
      ? '${universe.label} · $size of ${size + missing.length} resolved'
      : '${universe.label} · $size instruments';

  /// Placeholder used before the first resolution finishes.
  static const UniverseResolution empty = UniverseResolution(
    universe: ScanUniverse(
      key: UniverseCatalog.nifty50,
      label: 'Nifty 50',
      description: '',
      dynamic: false,
    ),
    scrips: [],
  );
}

class UniverseCatalog {
  UniverseCatalog._();

  // Universe keys (persisted in settings as `golden_cross_universe` and
  // `rsi_universe`).
  static const String fno = 'fno';
  static const String nifty50 = 'nifty50';
  static const String ipos = 'ipos';
  static const String masterNse = 'master_nse';
  static const String masterAll = 'master_all';

  /// Order shown in the picker sheet (cheapest first).
  static const List<ScanUniverse> all = [
    ScanUniverse(
      key: fno,
      label: 'F&O stocks',
      description: 'Every NSE stock with futures & options — 213 names, '
          '~80 s for a fresh scan.',
      dynamic: false,
    ),
    ScanUniverse(
      key: nifty50,
      label: 'Nifty 50',
      description: 'Large caps only — fastest fresh scan, ~20 s.',
      dynamic: false,
    ),
    ScanUniverse(
      key: ipos,
      label: 'IPO database',
      description: 'The Feature 1 IPO list — checks recent listings for a cross.',
      dynamic: false,
    ),
    ScanUniverse(
      key: masterNse,
      label: 'All NSE equities',
      description: 'Every NSE cash instrument in the local scrip master.',
    ),
    ScanUniverse(
      key: masterAll,
      label: 'All NSE + BSE',
      description: 'Everything in the master — hundreds of requests, be patient.',
    ),
  ];

  static ScanUniverse byKey(String? key) {
    final wanted = (key ?? '').trim().toLowerCase();
    for (final u in all) {
      if (u.key == wanted) return u;
    }
    // Unknown/legacy key → Nifty 50 (the long-standing default), not F&O, so a
    // settings row written by an older build keeps behaving as it did.
    return byKeyOrNull(nifty50) ?? all.first;
  }

  static ScanUniverse? byKeyOrNull(String key) {
    for (final u in all) {
      if (u.key == key) return u;
    }
    return null;
  }

  /// Nifty 50 constituents used by the [nifty50] universe.
  ///
  /// Plain NSE tickers, no broker suffix. Index membership changes a few times a
  /// year: a ticker that has been replaced simply lands in
  /// [UniverseResolution.missing] and costs one line in the picker, so nothing
  /// breaks between reviews. List reviewed against the Sep-2025 reshuffle.
  static const List<String> nifty50Symbols = [
    'ADANIENT', 'ADANIPORTS', 'APOLLOHOSP', 'ASIANPAINT', 'AXISBANK',
    'BAJAJ-AUTO', 'BAJFINANCE', 'BAJAJFINSV', 'BEL', 'BHARTIARTL',
    'BRITANNIA', 'CIPLA', 'COALINDIA', 'DRREDDY', 'EICHERMOT',
    'ETERNAL', 'GRASIM', 'HCLTECH', 'HDFCBANK', 'HEROMOTOCO',
    'HINDALCO', 'HINDUNILVR', 'ICICIBANK', 'INDIGO', 'INDUSINDBK',
    'INFY', 'ITC', 'JIOFIN', 'JSWSTEEL', 'KOTAKBANK',
    'LT', 'M&M', 'MARUTI', 'MAXHEALTH', 'NESTLEIND',
    'NTPC', 'ONGC', 'POWERGRID', 'RELIANCE', 'SBIN',
    'SHRIRAMFIN', 'SUNPHARMA', 'TATACONSUM', 'TATAMOTORS', 'TATASTEEL',
    'TECHM', 'TITAN', 'TRENT', 'ULTRACEMCO', 'WIPRO',
  ];

  /// Recently replaced constituents kept as a safety net: they are resolved
  /// only if the master still has them (e.g. an old app database), and are
  /// de-duplicated, so they can never add noise to the universe.
  static const List<String> nifty50FallbackSymbols = [
    'LTIM', 'HDFCLIFE', 'BPCL', 'DIVISLAB',
  ];

  /// Resolves [key] against local data.
  ///
  /// Resolution goes through [TokenResolver] for the ticker-based universes,
  /// because the broker stores plain tickers with a suffix (`SBIN` is
  /// `SBIN-EQ` in the master) — an exact SQL match on the raw ticker would find
  /// nothing at all. The resolver also gives these universes the cross-exchange
  /// and company-name fallbacks for free.
  ///
  /// The `master_*` universes never build a resolver: they are a straight read
  /// of the cached master, so no index is needed.
  static Future<UniverseResolution> resolve(
    String key, {
    required ScripDao scripDao,
    required IpoDao ipoDao,
    TokenResolver? resolver,
    /// NSE F&O underlyings (from `assets/data/fno_symbols.csv`, or the caller's
    /// own list). Only needed for the [fno] universe.
    List<String>? fnoSymbols,
  }) async {
    final universe = byKey(key);
    switch (universe.key) {
      case masterNse:
      case masterAll:
        return _resolveMaster(universe, scripDao: scripDao);
      case fno:
        return _resolveTickers(
          universe,
          tickers: fnoSymbols ?? const [],
          resolver: resolver ?? await resolverFor(scripDao),
        );
      case ipos:
        return _resolveIpos(
          universe,
          ipoDao: ipoDao,
          resolver: resolver ?? await resolverFor(scripDao),
        );
      case nifty50:
      default:
        return _resolveNifty(
          universe,
          resolver: resolver ?? await resolverFor(scripDao),
        );
    }
  }

  /// Builds a [TokenResolver] from the locally cached master (a few thousand
  /// rows — cheap enough to build on demand).
  static Future<TokenResolver> resolverFor(ScripDao scripDao) async =>
      TokenResolver.fromScrips(await scripDao.allEquities());

  // -------------------------------------------------------------------------
  // Resolvers
  // -------------------------------------------------------------------------

  /// Resolves a plain ticker list (F&O) — the same lookup path as Nifty 50.
  static Future<UniverseResolution> _resolveTickers(
    ScanUniverse universe, {
    required List<String> tickers,
    required TokenResolver resolver,
  }) async {
    final scrips = <Scrip>[];
    final seen = <String>{};
    final missing = <String>[];

    for (final ticker in tickers) {
      final found = resolver.resolve(ticker, preferredExchange: Exchange.nse).scrip;
      if (found == null) {
        missing.add(ticker);
        continue;
      }
      if (seen.add(found.key)) scrips.add(found);
    }

    return UniverseResolution(
      universe: universe,
      scrips: scrips,
      missing: missing,
    );
  }

  static Future<UniverseResolution> _resolveNifty(
    ScanUniverse universe, {
    required TokenResolver resolver,
  }) async {
    final scrips = <Scrip>[];
    final seen = <String>{};
    final missing = <String>[];

    bool add(String ticker) {
      final scrip = resolver.resolve(ticker, preferredExchange: Exchange.nse).scrip;
      if (scrip == null) return false;
      if (seen.add(scrip.key)) scrips.add(scrip);
      return true;
    }

    for (final ticker in nifty50Symbols) {
      if (!add(ticker)) missing.add(ticker);
    }
    // Fallbacks are additive only: they never create a *missing* marker.
    for (final ticker in nifty50FallbackSymbols) {
      add(ticker);
    }

    return UniverseResolution(
      universe: universe,
      scrips: scrips,
      missing: missing,
    );
  }

  static Future<UniverseResolution> _resolveIpos(
    ScanUniverse universe, {
    required IpoDao ipoDao,
    required TokenResolver resolver,
  }) async {
    final rows = await ipoDao.all();

    final scrips = <Scrip>[];
    final seen = <String>{};
    final missing = <String>[];

    for (final ipo in rows) {
      final resolution = resolver.resolve(
        ipo.symbol,
        preferredExchange: ipo.exchange,
        companyName: ipo.companyName,
      );
      final found = resolution.scrip;
      if (found == null) {
        missing.add(ipo.symbol);
        continue;
      }
      if (seen.add(found.key)) scrips.add(found);
    }

    return UniverseResolution(
      universe: universe,
      scrips: scrips,
      missing: missing,
    );
  }

  static Future<UniverseResolution> _resolveMaster(
    ScanUniverse universe, {
    required ScripDao scripDao,
  }) async {
    final all = await scripDao.allEquities();
    final wanted = <String>{
      Exchange.nse.code,
      if (universe.key == masterAll) Exchange.bse.code,
    };
    final scrips = [
      for (final s in all)
        if (wanted.contains(s.exchange.code)) s,
    ];
    return UniverseResolution(universe: universe, scrips: scrips);
  }
}
