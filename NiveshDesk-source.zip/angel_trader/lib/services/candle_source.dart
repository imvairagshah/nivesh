// ---------------------------------------------------------------------------
// candle_source.dart — the one thing the cross scanner needs from the outside
// world: daily candles for an instrument.
//
// Introducing this tiny interface (instead of calling MarketDataService
// directly) keeps CrossScanService testable: the real implementation is
// MarketDataService (SmartAPI `getCandleData`), and the tests drop in an
// in-memory fake. Nothing else in the scanner knows the network exists.
// ---------------------------------------------------------------------------

import '../data/remote/dto/candle.dart';
import '../data/remote/dto/scrip.dart';

abstract class CandleSource {
  /// Daily (or [interval]) candles for [scrip] between [from] and [to],
  /// inclusive, oldest → newest.
  ///
  /// Implementations must throw (rather than return an empty list) when the
  /// request itself failed — an empty list legitimately means "this instrument
  /// has no bars in that window" (freshly listed, suspended, or wrong segment).
  Future<List<Candle>> fetchDailyCandles({
    required Scrip scrip,
    required DateTime from,
    required DateTime to,
    String interval = 'ONE_DAY',
  });
}
