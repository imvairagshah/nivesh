// ---------------------------------------------------------------------------
// feed_decoder.dart — turns SmartAPI WebSocket 2.0 binary frames into [LiveTick]s.
//
// The feed is little-endian binary, NOT JSON. Layout (official docs, "WebSocket
// Streaming 2.0 → Response Contract", and the official Python SDK's
// `_parse_binary_data` which agrees with it):
//
//   offset  size  field
//   ------  ----  ------------------------------------------------------------
//     0      1    subscription mode   1 = LTP, 2 = Quote, 3 = Snap Quote
//     1      1    exchange type       1 = nse_cm, 3 = bse_cm (see markets.dart)
//     2     25    instrument token, UTF-8, NUL-padded
//    27      8    sequence number (int64)
//    35      8    exchange timestamp, epoch **milliseconds** (int64)
//    43      8    last traded price, in **paise**  ← LTP mode ends here (51 B)
//    51      8    last traded quantity
//    59      8    average traded price
//    67      8    volume traded for the day
//   115      8    close price (previous close)   ← Quote mode ends here (123 B)
//   ...            snap-quote fields up to 379 bytes
//
// Two traps worth spelling out, because both cost real debugging time:
//
//   1. The doc table labels the LTP field "int32" but gives its size as 8 bytes
//      and says prices are in paise. The official SDK reads a **64-bit**
//      little-endian integer at offset 43, and that is what works on the wire.
//      We follow the SDK and read int64.
//   2. The server also sends 2-byte **control** frames: byte 0 is 0 for a pong
//      and 1 for a ping (a data packet always has a mode of 1-3 there). They
//      must be filtered out before parsing, or the token decode reads junk.
//
// Everything here is a pure function of the bytes, so the whole protocol can be
// unit-tested without a socket: see test/services/feed_decoder_test.dart.
// ---------------------------------------------------------------------------

import 'dart:convert';
import 'dart:typed_data';

import '../core/utils/markets.dart';
import '../data/remote/dto/quote.dart';

/// What a frame turned out to be.
enum FeedFrameKind {
  /// A data packet (LTP / Quote / Snap Quote).
  packet,

  /// A 2-byte heartbeat frame — ping (1) or pong (0).
  control,

  /// Too short, or a mode we do not know. Counted by the caller, never thrown.
  malformed,
}

/// A heartbeat frame from the server.
class FeedControlFrame {
  /// Raw mode byte: 0 = pong, 1 = ping.
  final int mode;

  const FeedControlFrame(this.mode);

  bool get isPong => mode == 0;
  bool get isPing => mode == 1;

  @override
  String toString() => 'FeedControlFrame(${isPong ? 'pong' : 'ping'})';
}

/// One decoded frame: exactly one of [tick] / [control] is set.
class FeedFrame {
  final FeedFrameKind kind;
  final LiveTick? tick;
  final FeedControlFrame? control;

  /// Why a [FeedFrameKind.malformed] frame was rejected (for diagnostics).
  final String? reason;

  const FeedFrame._(this.kind, {this.tick, this.control, this.reason});

  const FeedFrame.packet(LiveTick tick)
      : this._(FeedFrameKind.packet, tick: tick);

  const FeedFrame.controlFrame(FeedControlFrame control)
      : this._(FeedFrameKind.control, control: control);

  const FeedFrame.malformed(String reason)
      : this._(FeedFrameKind.malformed, reason: reason);

  bool get isPacket => kind == FeedFrameKind.packet;
  bool get isControl => kind == FeedFrameKind.control;
  bool get isMalformed => kind == FeedFrameKind.malformed;

  @override
  String toString() => switch (kind) {
        FeedFrameKind.packet => 'FeedFrame.packet($tick)',
        FeedFrameKind.control => 'FeedFrame.control($control)',
        FeedFrameKind.malformed => 'FeedFrame.malformed($reason)',
      };
}

class FeedDecoder {
  FeedDecoder._();

  // ---- Field offsets / sizes (see the table above) ------------------------
  static const int modeOffset = 0;
  static const int exchangeOffset = 1;
  static const int tokenOffset = 2;
  static const int tokenLength = 25;
  static const int sequenceOffset = 27;
  static const int timestampOffset = 35;
  static const int ltpOffset = 43;
  static const int lastTradedQtyOffset = 51;
  static const int averagePriceOffset = 59;
  static const int volumeOffset = 67;
  static const int previousCloseOffset = 115;

  /// Packet sizes per mode — a frame shorter than its mode's size is malformed.
  static const int ltpPacketSize = 51;
  static const int quotePacketSize = 123;
  static const int snapQuotePacketSize = 379;

  /// Paise → rupees. (Currency pairs divide by 1e7 instead; this app only
  /// streams equity cash segments, so the rupee conversion is the right one.)
  static const double paise = 100.0;

  /// Decodes one WebSocket frame.
  ///
  /// [receivedAt] lets the caller stamp "when the app saw this" (used by the
  /// tests to keep timestamps deterministic).
  static FeedFrame decode(Uint8List bytes, {DateTime? receivedAt}) {
    if (bytes.isEmpty) return const FeedFrame.malformed('empty frame');

    // ---- control frames (2 bytes: 0 = pong, 1 = ping)
    if (bytes.length <= 2) {
      final mode = bytes[0];
      if (mode == 0 || mode == 1) {
        return FeedFrame.controlFrame(FeedControlFrame(mode));
      }
      return FeedFrame.malformed('short frame of ${bytes.length} bytes');
    }

    final data = ByteData.sublistView(bytes);
    final modeCode = bytes[modeOffset];
    final exchangeType = bytes[exchangeOffset];

    // Guard the read before touching the packet body.
    final requiredSize = switch (modeCode) {
      1 => ltpPacketSize,
      2 => quotePacketSize,
      3 => snapQuotePacketSize,
      _ => ltpPacketSize, // unknown mode: parse the header anyway, ignore extras
    };
    if (bytes.length < requiredSize) {
      return FeedFrame.malformed(
        'mode $modeCode needs $requiredSize bytes, got ${bytes.length}',
      );
    }

    final feedMode = switch (modeCode) {
      2 => FeedMode.quote,
      3 => FeedMode.snapQuote,
      _ => FeedMode.ltp,
    };

    final token = _decodeToken(bytes);
    if (token.isEmpty) {
      return const FeedFrame.malformed('no instrument token in packet');
    }

    final sequence = data.getInt64(sequenceOffset, Endian.little);
    final stampMs = data.getInt64(timestampOffset, Endian.little);
    final ltp = data.getInt64(ltpOffset, Endian.little) / paise;

    // Quote mode carries the rest of the day's numbers; LTP mode stops at 51.
    double? optionalDouble(int offset) {
      if (bytes.length < offset + 8) return null;
      final value = data.getInt64(offset, Endian.little) / paise;
      return value > 0 ? value : null;
    }

    int? optionalInt(int offset) {
      if (bytes.length < offset + 8) return null;
      final value = data.getInt64(offset, Endian.little);
      return value > 0 ? value : null;
    }

    return FeedFrame.packet(LiveTick(
      mode: feedMode,
      exchange: exchangeForType(exchangeType),
      token: token,
      ltp: ltp,
      sequence: sequence,
      // Feed timestamps are UTC epoch millis; the app displays IST everywhere,
      // so the tick carries IST wall-clock fields (UTC-flagged DateTime, exactly
      // like MarketCalendar.nowIst/describeNow).
      exchangeTime: stampMs <= 0
          ? null
          : MarketCalendar.istFromUtc(
              DateTime.fromMillisecondsSinceEpoch(stampMs, isUtc: true),
            ),
      volume: feedMode == FeedMode.ltp ? null : optionalInt(volumeOffset),
      previousClose:
          feedMode == FeedMode.ltp ? null : optionalDouble(previousCloseOffset),
      receivedAt: receivedAt,
    ));
  }

  /// Reads the 25-byte, NUL-padded token field.
  static String _decodeToken(Uint8List bytes) {
    final slice = bytes.sublist(tokenOffset, tokenOffset + tokenLength);
    var end = slice.indexOf(0);
    if (end < 0) end = slice.length;
    if (end == 0) return '';
    return utf8.decode(slice.sublist(0, end), allowMalformed: true).trim();
  }

  /// Maps the wire exchange type onto the app's [Exchange] enum.
  ///
  /// Only the two cash segments are supported (nse_cm = 1, bse_cm = 3); anything
  /// else (F&O, MCX …) falls back to NSE so a stray packet cannot crash a widget
  /// — the caller can still inspect the raw type on the tick if it cares.
  static Exchange exchangeForType(int exchangeType) => switch (exchangeType) {
        2 => Exchange.nfo, // nse_fo — option/futures contracts
        3 => Exchange.bse,
        4 => Exchange.bse, // bse_fo: no separate enum, BSE is the closest label
        _ => Exchange.nse, // 1 (nse_cm) and anything unknown
      };

  /// The `exchangeType` the feed expects for [exchange] (1 = nse_cm, 2 = nse_fo,
  /// 3 = bse_cm).
  static int typeForExchange(Exchange exchange) => exchange.wsType;

  /// Builds a synthetic LTP packet — used by tests and by any offline tooling
  /// that wants to exercise the decoder without a live socket.
  static Uint8List encodeLtpPacket({
    required String token,
    required int exchangeType,
    required double ltp,
    int sequence = 1,
    int timestampMs = 0,
  }) {
    final bytes = Uint8List(ltpPacketSize);
    final data = ByteData.sublistView(bytes);
    bytes[modeOffset] = 1;
    bytes[exchangeOffset] = exchangeType;
    final tokenBytes = utf8.encode(token);
    for (var i = 0; i < tokenBytes.length && i < tokenLength; i++) {
      bytes[tokenOffset + i] = tokenBytes[i];
    }
    data.setInt64(sequenceOffset, sequence, Endian.little);
    data.setInt64(timestampOffset, timestampMs, Endian.little);
    data.setInt64(ltpOffset, (ltp * paise).round(), Endian.little);
    return bytes;
  }
}
