// ---------------------------------------------------------------------------
// ai_backtest_service.dart — feeds the hit-rate report with real candles.
//
// The engine (features/fno/ai/ai_backtest.dart) is pure; this class is the only
// part that touches the database and the broker, and it does as little as it
// can:
//
//   • serve the series from the local candle cache when the cache already holds
//     the window the user asked for — a fully cached run makes ZERO network
//     calls, which is the whole point of "offline backtest";
//   • otherwise fetch that symbol's history once and keep it (the cache is
//     replaced window-by-window, the same way the study's loader does it);
//   • hand the series to the pure engine and report progress / cancellation.
//
// The one network caveat, and the screen says it out loud: a 3-year run over
// the whole F&O universe may need one request per symbol the *first* time.
// After that it is offline forever, and the report's `downloads` counter says
// exactly how many were fetched.
// ---------------------------------------------------------------------------

import '../data/local/dao/candle_dao.dart';
import '../data/remote/api_client.dart';
import '../data/remote/dto/candle.dart';
import '../data/remote/dto/scrip.dart';
import '../features/fno/ai/ai_backtest.dart';
import 'ai_suggestion_service.dart' show AiProgress;
import 'candle_source.dart';

class AiBacktestService {
  AiBacktestService({
    required CandleSource source,
    required CandleDao candles,
    DateTime Function()? clock,
  })  : _source = source,
        _candles = candles,
        _clock = clock ?? DateTime.now;

  final CandleSource _source;
  final CandleDao _candles;
  final DateTime Function() _clock;

  /// Trading sessions in a year — used to decide whether a cached series is
  /// long enough for the window the user asked for.
  static const int sessionsPerYear = 250;

  /// Calendar days added on top of the window so the 60-bar warm-up and the
  /// exchange holidays do not eat into the period being reported on.
  static const int calendarSlackDays = 150;

  /// A cached series is trusted when it holds at least this share of the
  /// sessions the window should have (70 %: a long suspension is not a gap in
  /// the data, it is a fact about the stock).
  static const double cacheSufficiency = 0.7;

  Future<BtResult> run({
    required List<Scrip> universe,
    required BtConfig config,
    required int years,
    DateTime? asOf,
    void Function(AiProgress)? onProgress,
    bool Function()? isCancelled,
  }) async {
    final started = _clock();
    final day = asOf ?? started;
    final lookbackDays = years * 365 + calendarSlackDays;
    final from = day.subtract(Duration(days: lookbackDays));
    final wanted = years * sessionsPerYear;
    final enough = (wanted * cacheSufficiency).round();

    final history = <String, List<Candle>>{};
    final loadSkips = <String, String>{};
    var downloads = 0;
    var cancelled = false;

    for (var i = 0; i < universe.length; i++) {
      if (isCancelled?.call() ?? false) {
        cancelled = true;
        break;
      }
      final scrip = universe[i];
      final plain = Scrip.plainSymbol(scrip.symbol);

      try {
        var bars = await _readCache(scrip, from, day);
        final reachesNow = bars.isNotEmpty &&
            !bars.last.istDate.isBefore(_midnight(day));

        if (!(reachesNow && bars.length >= enough)) {
          final fresh = await _source.fetchDailyCandles(
            scrip: scrip,
            from: DateTime(from.year, from.month, from.day, 9, 15),
            to: DateTime(day.year, day.month, day.day, 15, 30),
          );
          if (fresh.isNotEmpty) {
            downloads++;
            await _writeCache(scrip, fresh, from, day);
            bars = fresh;
          }
        }

        if (bars.isEmpty) {
          loadSkips[plain] = 'Is stock ka koi candle data nahi mila.';
        } else {
          history[plain] = bars;
        }
      } on ApiException catch (e) {
        loadSkips[plain] = e.message;
      } catch (e) {
        loadSkips[plain] = '$e';
      }

      onProgress?.call(
        AiProgress(
          stage: 'Itihaas',
          done: i + 1,
          total: universe.length,
          current: plain,
          fraction: 0.8 * ((i + 1) / (universe.isEmpty ? 1 : universe.length)),
          elapsed: _clock().difference(started),
        ),
      );

      // One symbol per event-loop turn: the progress bar keeps moving and the
      // cancel button keeps working instead of the UI freezing for a minute.
      await Future<void>.delayed(Duration.zero);
    }

    onProgress?.call(
      AiProgress(
        stage: 'Hisab',
        done: universe.length,
        total: universe.length,
        fraction: 0.9,
        elapsed: _clock().difference(started),
      ),
    );
    await Future<void>.delayed(Duration.zero);

    final result = runBacktest(
      history,
      config: config,
      years: years,
      downloads: downloads,
      cancelled: cancelled,
      duration: _clock().difference(started),
    );

    return result.withSkips(loadSkips);
  }

  Future<List<Candle>> _readCache(Scrip scrip, DateTime from, DateTime to) async {
    try {
      return await _candles.barsFor(
        exchange: scrip.exchange.code,
        symbol: scrip.symbol,
        from: from,
        to: to,
      );
    } catch (_) {
      // A damaged cache row must never stop a report.
      return const <Candle>[];
    }
  }

  Future<void> _writeCache(
    Scrip scrip,
    List<Candle> bars,
    DateTime from,
    DateTime to,
  ) async {
    try {
      await _candles.saveBars(
        exchange: scrip.exchange.code,
        symbol: scrip.symbol,
        bars: bars,
        replaceWindow: true,
        windowFrom: DateTime(from.year, from.month, from.day, 9, 15),
        windowTo: DateTime(to.year, to.month, to.day, 15, 30),
      );
    } catch (_) {
      // Caching is a nice-to-have; the run still uses the bars it fetched.
    }
  }
}

DateTime _midnight(DateTime day) => DateTime(day.year, day.month, day.day);
