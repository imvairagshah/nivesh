// ---------------------------------------------------------------------------
// fno_contract_collector.dart — pulls the option book out of the scrip master.
//
// The master streams ~100k rows; this collector sits inside that stream and keeps
// only what the F&O module can use:
//
//   • `exch_seg == NFO`, `instrumenttype == OPTSTK`  → stock options only
//     (index options OPTIDX and the noise of BFO/FUT* rows are skipped),
//   • rows whose symbol ends in CE/PE and carry a strike, expiry and lot size,
//   • only the **three nearest expiries** per underlying, so the 3-Month Study
//     can offer current + next two stock-monthly expiries without weekly index
//     contracts or the rest of the master.
//
// Two parsing details that bite in practice:
//   • `expiry` is `26JAN2026` (no separators) — `Fmt.parseDate` cannot read it,
//     so the month token is mapped by hand.
//   • `strike` is in **paise** (`"2650000.000000"` = ₹26,500), exactly like the
//     tick size in the cash master. Forgetting the ÷100 puts the ATM strike
//     three orders of magnitude away from spot.
//
// The class is deliberately free of IO so it can be unit-tested with hand-built
// rows (see test/services/fno_contract_collector_test.dart).
// ---------------------------------------------------------------------------

import '../core/utils/markets.dart' show MarketCalendar;
import '../data/local/dao/fno_contract_dao.dart';

class FnoContractCollector {
  FnoContractCollector({this.maxExpiriesPerUnderlying = 3, DateTime? today})
    : _today = _dateOnly(today ?? MarketCalendar.nowIst());

  final DateTime _today;

  static DateTime _dateOnly(DateTime date) =>
      DateTime(date.year, date.month, date.day);

  /// Keep only the nearest stock-option expiries in the local book. The
  /// 3-Month Study uses three monthly expiries; the source filter above excludes
  /// OPTIDX (where NSE weekly index expiries live).
  final int maxExpiriesPerUnderlying;

  // underlying → expiryDate → "strike|type" → contract
  final Map<String, Map<DateTime, Map<String, FnoContract>>> _book = {};

  /// Rows seen that looked like a stock option contract.
  int accepted = 0;

  /// Rows skipped because they were not NFO stock options.
  int rejected = 0;

  int get underlyingCount => _book.length;

  int get contractCount {
    var total = 0;
    for (final expiries in _book.values) {
      for (final chain in expiries.values) {
        total += chain.length;
      }
    }
    return total;
  }

  /// Feeds one raw master row. Returns `true` when it was stored.
  bool addRow(Map<String, dynamic> row) {
    final segment = '${row['exch_seg'] ?? ''}'.trim().toUpperCase();
    final instrument = '${row['instrumenttype'] ?? ''}'.trim().toUpperCase();
    if (segment != 'NFO' || instrument != 'OPTSTK') {
      rejected++;
      return false;
    }

    final underlying = '${row['name'] ?? ''}'.trim().toUpperCase();
    final symbol = '${row['symbol'] ?? ''}'.trim().toUpperCase();
    final token = '${row['token'] ?? ''}'.trim();
    if (underlying.isEmpty || symbol.isEmpty || token.isEmpty) {
      rejected++;
      return false;
    }

    final optionType = symbol.endsWith('CE')
        ? 'CE'
        : (symbol.endsWith('PE') ? 'PE' : '');
    if (optionType.isEmpty) {
      rejected++;
      return false;
    }

    final expiry = parseExpiry('${row['expiry'] ?? ''}');
    if (expiry == null) {
      rejected++;
      return false;
    }
    if (expiry.isBefore(_today)) {
      rejected++; // expired series must not crowd out the next three months
      return false;
    }

    final strike = parseStrike(row['strike']);
    if (strike <= 0) {
      rejected++;
      return false;
    }

    final contract = FnoContract(
      underlying: underlying,
      expiryLabel: '${row['expiry']}'.trim().toUpperCase(),
      expiryDate: expiry,
      strike: strike,
      optionType: optionType,
      token: token,
      symbol: symbol,
      lotSize: parseLotSize(row['lotsize']),
    );

    final expiries = _book.putIfAbsent(
      underlying,
      () => <DateTime, Map<String, FnoContract>>{},
    );
    expiries.putIfAbsent(
      expiry,
      () => <String, FnoContract>{},
    )['${strike.toStringAsFixed(2)}|$optionType'] = contract;
    accepted++;

    _pruneExpiries(expiries);
    return true;
  }

  /// Keeps the nearest [maxExpiriesPerUnderlying] expiries per stock. The
  /// master may stream contracts in any order, so pruning after every row makes
  /// the final book deterministic and independent of file ordering.
  void _pruneExpiries(Map<DateTime, Map<String, FnoContract>> expiries) {
    final limit = maxExpiriesPerUnderlying;
    if (limit <= 0) {
      expiries.clear();
      return;
    }
    if (expiries.length <= limit) return;
    final sorted = expiries.keys.toList()..sort();
    for (final date in sorted.skip(limit)) {
      expiries.remove(date);
    }
  }

  /// The book, ready for [FnoContractDao.replaceAll].
  List<FnoContract> build() => [
    for (final expiries in _book.values)
      for (final chain in expiries.values) ...chain.values,
  ];

  void reset() {
    _book.clear();
    accepted = 0;
    rejected = 0;
  }

  // -------------------------------------------------------------------------
  // Parsers (static + public so the tests can pin them down)
  // -------------------------------------------------------------------------

  static const List<String> _months = [
    'JAN',
    'FEB',
    'MAR',
    'APR',
    'MAY',
    'JUN',
    'JUL',
    'AUG',
    'SEP',
    'OCT',
    'NOV',
    'DEC',
  ];

  /// `26JAN2026` → `DateTime(2026, 1, 26)`. Also tolerates `26-JAN-2026`.
  static DateTime? parseExpiry(String raw) {
    final text = raw.trim().toUpperCase().replaceAll('-', '');
    if (text.length < 8) return null;

    final dayPart = int.tryParse(text.substring(0, 2));
    final monthToken = text.substring(2, 5);
    final yearPart = int.tryParse(text.substring(5));
    if (dayPart == null || yearPart == null) return null;

    final monthIndex = _months.indexOf(monthToken);
    if (monthIndex < 0) return null;
    if (dayPart < 1 || dayPart > 31) return null;

    return DateTime(yearPart, monthIndex + 1, dayPart);
  }

  /// The master encodes strikes in paise: `"2650000.000000"` → ₹26,500.
  static double parseStrike(dynamic raw) {
    final value = raw is num ? raw.toDouble() : double.tryParse('$raw') ?? 0;
    if (value <= 0) return 0;
    return value / 100;
  }

  static int parseLotSize(dynamic raw) {
    if (raw is num) return raw.toInt();
    return int.tryParse('$raw') ?? 0;
  }
}
