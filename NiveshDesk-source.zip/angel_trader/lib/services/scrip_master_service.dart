// ---------------------------------------------------------------------------
// scrip_master_service.dart — daily instrument-master refresh.
//
// Angel One publishes the full instrument list as one JSON array (~50 MB,
// ~100k rows) at:
//   https://margincalculator.angelbroking.com/OpenAPI_File/files/OpenAPIScripMaster.json
//
// Downloading that with `jsonDecode` would spike hundreds of MB of RAM on a
// phone, so the response is piped through [JsonArrayScanner], filtered to
// cash-market equities and written to SQLite in batches while it streams.
//
// A small bundled sample (assets/data/scrip_master.json) seeds the table on
// first launch, so the IPO screener can resolve tokens before the user has ever
// refreshed the master — and offline.
// ---------------------------------------------------------------------------

import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;

import '../core/utils/json_array_scanner.dart';
import '../data/local/dao/fno_contract_dao.dart';
import 'fno_contract_collector.dart';
import '../data/local/dao/scrip_dao.dart';
import '../data/local/dao/settings_dao.dart';
import '../data/remote/api_client.dart';
import '../data/remote/dto/scrip.dart';
import 'token_resolver.dart';

/// Metadata keys written to `scrip_meta`.
class ScripMetaKeys {
  ScripMetaKeys._();
  static const String lastUpdated = 'scrip_master_updated_at';
  static const String rowCount = 'scrip_master_rows';
  static const String source = 'scrip_master_source'; // network | bundled
  static const String complete = 'scrip_master_complete'; // '1' when finished

  /// How many option contracts the F&O book holds after the last refresh.
  static const String fnoContracts = 'fno_contract_rows';

  /// `Last-Modified` of the broker file that is currently in SQLite — the
  /// fingerprint the 1 KB freshness probe compares against.
  static const String fileDate = 'scrip_master_file_date';
}

enum ScripMasterStatus { empty, bundled, downloading, downloaded, failed }

class ScripMasterService extends ChangeNotifier {
  ScripMasterService({
    required ScripDao scripDao,
    required SettingsDao settingsDao,

    /// Optional: when supplied, every master refresh also rebuilds the local
    /// option-contract book the F&O module reads (see [FnoContractCollector]).
    FnoContractDao? fnoContracts,
    ApiClient? client,

    /// Optional: housekeeping run after a real download (never after a skipped
    /// one). `AppDatabase.vacuum` goes here — the refresh clears and rewrites
    /// ~40k rows, so the freed pages are worth handing back to the OS.
    Future<int> Function()? compact,
  }) : _scripDao = scripDao,
       _settingsDao = settingsDao,
       _fnoContracts = fnoContracts,
       _client = client ?? ApiClient(),
       _compact = compact;

  final ScripDao _scripDao;
  final FnoContractDao? _fnoContracts;
  final SettingsDao _settingsDao;
  final ApiClient _client;
  final Future<int> Function()? _compact;

  /// Where Angel One publishes the daily master.
  static const String masterUrl =
      'https://margincalculator.angelbroking.com/OpenAPI_File/files/OpenAPIScripMaster.json';

  /// Bundled fallback shipped in the APK/IPA.
  static const String bundledAsset = 'assets/data/scrip_master.json';

  /// How long a cached master is considered fresh (Angel republishes daily).
  static const Duration cacheValidity = Duration(hours: 24);

  /// Rows inserted per SQLite transaction while streaming.
  static const int insertBatchSize = 2000;

  TokenResolver? _resolver;

  /// `Last-Modified` of the broker file behind the current cache (null when the
  /// master came from the bundled asset, or before the first probe).
  DateTime? _lastModified;

  /// Runs the 1 KB freshness probe; injected in tests.
  Future<DateTime?> Function()? probeFileDate;

  Future<DateTime?> _probeFileDate() async {
    try {
      return await (probeFileDate?.call() ??
          _client.probeLastModified(Uri.parse(masterUrl)));
    } catch (_) {
      return null;
    }
  }

  static String _stamp(DateTime d) {
    final local = d.toLocal();
    return '${local.day.toString().padLeft(2, '0')}/'
        '${local.month.toString().padLeft(2, '0')} ${local.hour.toString().padLeft(2, '0')}:'
        '${local.minute.toString().padLeft(2, '0')}';
  }

  ScripMasterStatus _status = ScripMasterStatus.empty;
  int _rowCount = 0;
  DateTime? _lastUpdated;
  String _source = '';
  double _progress = 0;
  String _stage = '';

  // ---- Read-only state -----------------------------------------------------

  ScripMasterStatus get status => _status;
  int get rowCount => _rowCount;
  DateTime? get lastUpdated => _lastUpdated;

  /// `Last-Modified` of the broker file the cache was built from.
  DateTime? get fileDate => _lastModified;
  String get source => _source;

  /// 0..1 while downloading, for the progress indicator in Settings.
  double get progress => _progress;

  /// Human-readable stage, e.g. "Reading instruments (42,000…)".
  String get stage => _stage;

  bool get isRefreshing => _status == ScripMasterStatus.downloading;

  /// `true` when the cached master is younger than [cacheValidity].
  bool get isFresh {
    final updated = _lastUpdated;
    if (updated == null) return false;
    return DateTime.now().difference(updated) < cacheValidity;
  }

  // -------------------------------------------------------------------------
  // Startup
  // -------------------------------------------------------------------------

  /// Loads metadata and, when the table is empty, seeds the bundled sample.
  ///
  /// Call once during app start, before resolving any token.
  Future<void> initialise() async {
    _rowCount = await _scripDao.count();
    _lastUpdated = DateTime.tryParse(
      await _settingsDao.meta(ScripMetaKeys.lastUpdated) ?? '',
    );
    _source = await _settingsDao.meta(ScripMetaKeys.source) ?? '';
    _lastModified = DateTime.tryParse(
      await _settingsDao.meta(ScripMetaKeys.fileDate) ?? '',
    );

    if (_rowCount == 0) {
      await _seedFromAsset();
    } else {
      _status = _source == 'network'
          ? ScripMasterStatus.downloaded
          : ScripMasterStatus.bundled;
    }
    _resolver = null; // force a rebuild on next use
    notifyListeners();
  }

  /// Loads the packaged sample into SQLite. Runs in ~a second for ~1,000 rows.
  Future<void> _seedFromAsset() async {
    try {
      _stage = 'Loading bundled instruments…';
      notifyListeners();

      final text = await rootBundle.loadString(bundledAsset);
      final scrips = _parseBundled(text);
      if (scrips.isNotEmpty) {
        await _scripDao.replaceAll(scrips);
        await _settingsDao.putMeta(ScripMetaKeys.source, 'bundled');
        await _settingsDao.putMeta(ScripMetaKeys.rowCount, '${scrips.length}');
        await _settingsDao.putMeta(
          ScripMetaKeys.lastUpdated,
          DateTime.now().toIso8601String(),
        );
      }
      _rowCount = await _scripDao.count();
      _source = 'bundled';
      _lastUpdated = DateTime.now();
      _status = ScripMasterStatus.bundled;
    } catch (e) {
      debugPrint('ScripMasterService: bundled seed failed — $e');
      _status = ScripMasterStatus.failed;
      _stage = 'Bundled instrument list could not be read.';
    }
    notifyListeners();
  }

  List<Scrip> _parseBundled(String jsonText) {
    final decoded = jsonDecode(jsonText);
    if (decoded is! List) return const [];
    final scrips = <Scrip>[];
    for (final row in decoded.whereType<Map>()) {
      final map = row.cast<String, dynamic>();
      if (!Scrip.isEquityRow(map)) continue;
      scrips.add(Scrip.fromScripMaster(map));
    }
    return scrips;
  }

  // -------------------------------------------------------------------------
  // Token resolution
  // -------------------------------------------------------------------------

  /// In-memory [TokenResolver] built from the cached master (rebuilt after each
  /// refresh). Building it is cheap — a few thousand rows.
  Future<TokenResolver> resolver({bool forceRebuild = false}) async {
    if (_resolver != null && !forceRebuild) return _resolver!;
    final scrips = await _scripDao.allEquities();
    _resolver = TokenResolver.fromScrips(scrips);
    return _resolver!;
  }

  // -------------------------------------------------------------------------
  // Daily refresh
  // -------------------------------------------------------------------------

  /// Downloads and stores the latest master.
  ///
  /// [force] = false skips the download when the cache is still fresh.
  /// Returns the number of equities cached.
  /// `true` when the ~34 MB download can be skipped because the broker has not
  /// published anything new — the copy in SQLite was built from a file with the
  /// same `Last-Modified`.
  ///
  /// Deliberately refuses to skip when:
  ///   * [force] is set (the user pressed *Download latest*, or the F&O coverage
  ///     check found the local copy thin — a repair must really re-fetch), or
  ///   * nothing is cached yet, or
  ///   * either side's timestamp is unknown (better to download than to guess).
  static bool canSkipDownload({
    required DateTime? remoteFileDate,
    required DateTime? storedFileDate,
    required int rowCount,
    required bool force,
  }) {
    if (force) return false;
    if (rowCount <= 0) return false;
    if (remoteFileDate == null || storedFileDate == null) return false;
    return remoteFileDate.toUtc().isAtSameMomentAs(storedFileDate.toUtc());
  }

  Future<int> refresh({bool force = false}) async {
    if (isRefreshing) return _rowCount;
    if (!force && isFresh && _rowCount > 0) return _rowCount;

    // 34 MB is worth a 1 KB question. The broker's file carries a
    // `Last-Modified`; when it matches the copy we already have (weekend,
    // holiday, or a second app launch on the same day) there is nothing to
    // download.
    final storedFileDate = DateTime.tryParse(
      await _settingsDao.meta(ScripMetaKeys.fileDate) ?? '',
    );
    final remoteFileDate = await _probeFileDate();

    if (canSkipDownload(
      remoteFileDate: remoteFileDate,
      storedFileDate: storedFileDate,
      rowCount: _rowCount,
      force: force,
    )) {
      _lastUpdated = DateTime.now();
      _source = 'network';
      _status = ScripMasterStatus.downloaded;
      _progress = 1;
      _stage =
          'Broker ka master file wahi hai (${_stamp(remoteFileDate!)}) — '
          '34 MB dobara download nahi kiya.';
      await _settingsDao.putMeta(
        ScripMetaKeys.lastUpdated,
        _lastUpdated!.toIso8601String(),
      );
      await _settingsDao.putMeta(ScripMetaKeys.complete, '1');
      _resolver = null; // the table is the same; a rebuild is harmless
      notifyListeners();
      return _rowCount;
    }

    _status = ScripMasterStatus.downloading;
    _progress = 0;
    _stage = 'Contacting Angel One…';
    notifyListeners();

    // Mark the cache as in-flight: if the app is killed mid-download the flag
    // stays '0' and [initialise] knows to fall back to the bundled sample.
    await _settingsDao.putMeta(ScripMetaKeys.complete, '0');

    try {
      final response = await _client.streamGet(Uri.parse(masterUrl));
      final total = response.contentLength ?? -1;
      var received = 0;

      final scanner = JsonArrayScanner();
      final pending = <Scrip>[];
      final options = FnoContractCollector();
      var cached = 0;

      await _scripDao.clear();

      // `.map` counts bytes for the progress bar; `.transform` performs proper
      // UTF-8 decoding so multi-byte characters are never split across chunks.
      final textStream = response.stream
          .map((bytes) {
            received += bytes.length;
            if (total > 0) {
              _progress =
                  (received / total) * 0.6; // download = 60 % of the work
              _stage = 'Downloading master (${_mb(received)} / ${_mb(total)})';
              if (received % (512 * 1024) < 8 * 1024) notifyListeners();
            } else {
              _stage = 'Downloading master (${_mb(received)})';
            }
            return bytes;
          })
          .transform(utf8.decoder);

      await for (final text in textStream) {
        final objects = scanner.feed(text);
        if (objects.isEmpty) continue;

        for (final object in objects) {
          // Option contracts ride along in the same stream; the collector keeps
          // NFO stock options and the three nearest monthly expiries.
          if (_fnoContracts != null) options.addRow(object);

          if (!Scrip.isEquityRow(object)) continue;
          final scrip = Scrip.fromScripMaster(object);
          if (scrip.token.isEmpty || scrip.symbol.isEmpty) continue;
          pending.add(scrip);
        }

        if (pending.length >= insertBatchSize) {
          await _scripDao.replaceAllIncremental(pending);
          cached += pending.length;
          pending.clear();
          _stage = 'Saving instruments ($cached)…';
          _progress =
              0.6 + 0.4 * (total > 0 ? (received / total).clamp(0, 1) : 0.5);
          notifyListeners();
        }
      }

      if (pending.isNotEmpty) {
        await _scripDao.replaceAllIncremental(pending);
        cached += pending.length;
      }

      // Persist the option book (no-op when no DAO was supplied, i.e. in tests
      // that only care about cash equities).
      if (_fnoContracts != null) {
        final contracts = options.build();
        if (contracts.isNotEmpty) {
          await _fnoContracts.replaceAll(contracts);
          await _settingsDao.putMeta(
            ScripMetaKeys.fnoContracts,
            '${contracts.length}',
          );
        }
      }

      // Remember which broker file this copy came from, so the next refresh
      // can answer with a 1 KB probe instead of another 34 MB.
      await _settingsDao.putMeta(
        ScripMetaKeys.fileDate,
        (remoteFileDate ?? DateTime.now()).toUtc().toIso8601String(),
      );
      _lastModified = remoteFileDate ?? _lastModified;

      _rowCount = await _scripDao.count();
      _lastUpdated = DateTime.now();
      _source = 'network';
      _status = ScripMasterStatus.downloaded;
      _progress = 1;
      _stage = 'Master updated — ${_rowCount.toString()} instruments.';

      await _settingsDao.putMeta(ScripMetaKeys.rowCount, '$_rowCount');
      await _settingsDao.putMeta(
        ScripMetaKeys.lastUpdated,
        _lastUpdated!.toIso8601String(),
      );
      await _settingsDao.putMeta(ScripMetaKeys.source, 'network');
      await _settingsDao.putMeta(ScripMetaKeys.complete, '1');

      // Housekeeping, never fatal: the table was cleared and rewritten, so the
      // freed pages are garbage now.
      try {
        await _compact?.call();
      } catch (_) {
        // A failed VACUUM must not fail a successful master download.
      }

      _resolver = null;
      notifyListeners();
      return _rowCount;
    } catch (e) {
      _status = ScripMasterStatus.failed;
      _stage = 'Update failed: $e';
      // The previous master was cleared, so re-seed the bundled sample rather
      // than leaving the user with no tokens at all.
      if (await _scripDao.count() == 0) {
        await _seedFromAsset();
      }
      notifyListeners();
      rethrow;
    }
  }

  String _mb(int bytes) => '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
}
