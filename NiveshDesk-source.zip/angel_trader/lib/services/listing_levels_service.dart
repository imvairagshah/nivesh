// ---------------------------------------------------------------------------
// listing_levels_service.dart — fills in the listing-day high/low automatically.
//
// WHY THIS EXISTS
// The IPO proximity screener compares the live LTP against the *listing day*
// high and low (±3 % band, Feature 1's rule). A hand-maintained database can
// only ever hold a few dozen such levels — the bundled master now carries every
// mainboard IPO since 2015 (~550 rows), and nobody is going to type 550 highs
// and lows by hand.
//
// So the app fetches them itself, from data it already has access to:
//   1. resolve the symbol to a SmartAPI token (daily scrip master)
//   2. ask `getCandleData` for daily candles covering the listing date
//      (a small window: listing date − 2 days … + 14 days, so a Friday listing
//      or a one-day holiday still lands inside the window)
//   3. the *first* session in that window IS the listing session → its high and
//      low are the listing-day high/low
//   4. store them on the row with `levels_source = 'auto'`
//
// Every result is cached in SQLite forever, so this runs once per row, in small
// resumable batches, and never re-asks for levels it already has. Rows whose
// symbol is gone (delisted, renamed, absorbed by a merger) are marked
// `'missing'` — they are then skipped by the screener with a reason instead of
// being retried on every scan.
//
// CAVEAT (documented in the README as well): if a stock has split or issued a
// bonus since listing, the broker's historical OHLC is adjusted, so the derived
// level can differ from the exchange-quoted listing-day high/low. Levels the
// app fetched itself are therefore labelled "auto" in the card's detail sheet,
// and the curated rows keep their hand-verified values.
// ---------------------------------------------------------------------------

import 'package:flutter/foundation.dart';

import '../data/local/dao/ipo_dao.dart';
import '../data/local/models/ipo.dart';
import 'auth_service.dart';
import 'candle_source.dart';
import 'scrip_master_service.dart';

/// Where a row's listing high/low came from. Mirrors `Ipo.levelsSource`.
class LevelsSource {
  LevelsSource._();

  /// Not known yet — the row is a candidate for [ListingLevelsService].
  static const String pending = '';

  /// Shipped in `assets/data/ipos.csv` and hand-verified.
  static const String seed = 'seed';

  /// Typed in by the user (or edited) in the IPO form.
  static const String user = 'user';

  /// Derived from the broker's daily candles by this service.
  static const String auto = 'auto';

  /// Looked for, but the market data had nothing (delisted / renamed symbol).
  static const String missing = 'missing';
}

/// What one batch (or one "fetch everything") accomplished.
class LevelsFetchResult {
  const LevelsFetchResult({
    this.updated = 0,
    this.missing = 0,
    this.skippedNoToken = 0,
    this.remaining = 0,
    this.needsLogin = false,
    this.stopped = false,
    this.error,
  });

  /// Rows that now carry auto levels.
  final int updated;

  /// Rows the market data had nothing for (marked `missing`).
  final int missing;

  /// Rows whose symbol did not resolve to a token this run (left pending).
  final int skippedNoToken;

  /// Rows still waiting for levels when the batch ended.
  final int remaining;

  /// `true` when there was no usable SmartAPI session (nothing was attempted).
  final bool needsLogin;

  /// `true` when the caller's `shouldStop` asked us to stop early.
  final bool stopped;

  /// First non-fatal error, when the run hit one.
  final String? error;

  bool get didSomething => updated > 0 || missing > 0;
}

/// Progress callback: (done, total) for the current run.
typedef LevelsProgress = void Function(int done, int total);

class ListingLevelsService {
  ListingLevelsService({
    required IpoDao ipoDao,
    required ScripMasterService scripMaster,
    required CandleSource candles,
    required AuthService auth,
    this.batchSize = 25,
  })  : _ipoDao = ipoDao,
        _scripMaster = scripMaster,
        _candles = candles,
        _auth = auth;

  final IpoDao _ipoDao;
  final ScripMasterService _scripMaster;
  final CandleSource _candles;
  final AuthService _auth;

  /// Rows fetched per run when the caller does not ask for the full list. Keeps
  /// a background run short (~15 s) so it never fights the UI or the feed.
  final int batchSize;

  /// How far past the listing date to look for the first session.
  static const Duration _windowAfter = Duration(days: 14);

  /// How far before it to look (covers "listed on a Friday, first candle
  /// stamped a day earlier in UTC" and holiday edge cases).
  static const Duration _windowBefore = Duration(days: 3);

  /// Rows that still need levels, newest listings first — a fresh IPO is the
  /// one a user is most likely to be looking at.
  Future<List<Ipo>> pendingRows({bool includeMissing = false}) async {
    final rows = await _ipoDao.all();
    return rows
        .where((ipo) =>
            !ipo.hasLevels &&
            (ipo.levelsSource == LevelsSource.pending ||
                (includeMissing && ipo.levelsSource == LevelsSource.missing)))
        .toList(growable: false);
  }

  /// Fetches listing-day high/low for up to [fetchAll] ? every pending row : one
  /// batch. Safe to call repeatedly: it picks up where the last run stopped.
  Future<LevelsFetchResult> fetchPending({
    bool fetchAll = false,
    LevelsProgress? onProgress,
    bool Function()? shouldStop,
  }) async {
    if (!_auth.isLoggedIn) {
      return const LevelsFetchResult(needsLogin: true);
    }

    final pending = await pendingRows();
    if (pending.isEmpty) return const LevelsFetchResult();

    final total = pending.length;
    final limit = fetchAll ? total : (batchSize < total ? batchSize : total);
    final resolver = await _scripMaster.resolver();

    var updated = 0;
    var missing = 0;
    var noToken = 0;
    var done = 0;
    String? firstError;
    var stopped = false;

    for (var i = 0; i < limit; i++) {
      if (shouldStop?.call() ?? false) {
        stopped = true;
        break;
      }
      final ipo = pending[i];
      done++;

      final resolution = resolver.resolve(
        ipo.symbol,
        preferredExchange: ipo.exchange,
        companyName: ipo.companyName,
      );
      final scrip = resolution.scrip;
      if (scrip == null) {
        // The scrip master has no such symbol (yet): leave the row pending so a
        // later master refresh can pick it up, and count it for the report.
        noToken++;
        onProgress?.call(done, total);
        continue;
      }

      try {
        final candles = await _candles.fetchDailyCandles(
          scrip: scrip,
          from: ipo.listingDate.subtract(_windowBefore),
          to: ipo.listingDate.add(_windowAfter),
        );

        if (candles.isEmpty) {
          await _ipoDao.setLevels(ipo.id!, 0, 0, LevelsSource.missing);
          missing++;
        } else {
          // The first session in the window is the listing session.
          final first = candles.first;
          await _ipoDao.setLevels(
            ipo.id!,
            first.high,
            first.low,
            LevelsSource.auto,
          );
          updated++;
        }
      } catch (e) {
        // Rate limits / network blips are not the row's fault: leave it pending
        // and remember the message so the UI can show why progress stalled.
        firstError ??= '$e';
      }
      onProgress?.call(done, total);
    }

    final remaining = (await pendingRows()).length;
    return LevelsFetchResult(
      updated: updated,
      missing: missing,
      skippedNoToken: noToken,
      remaining: remaining,
      stopped: stopped,
      error: firstError,
    );
  }

  /// "Fetch levels for everything, in batches" — used by the explicit button.
  /// Reports coarse progress and can be cancelled by popping the screen (the
  /// caller passes [shouldStop]).
  Future<LevelsFetchResult> fetchAllPending({
    LevelsProgress? onProgress,
    bool Function()? shouldStop,
  }) =>
      fetchPending(fetchAll: true, onProgress: onProgress, shouldStop: shouldStop);

  /// Marks pending rows whose symbol cannot be resolved **while the full
  /// instrument master is loaded** as `missing`.
  ///
  /// Without this, a row whose ticker no longer exists (a company that renamed
  /// after the master was cut — LTIM → LTM, AMIORG → ACUTAAS) would sit in the
  /// queue forever: every launch it is skipped for "no token", the levels line
  /// keeps saying *"N IPOs need listing-day high/low"*, and the number never
  /// moves. Marking it `missing` is honest — the screener then reports it with a
  /// reason (and it appears in the "needs attention" list in the UI) instead of
  /// pretending it is still being fetched.
  ///
  /// Callers must only invoke this when the master is complete ([
  /// ScripMasterService.source] == `network`); with the bundled 122-row starter
  /// file almost every row would resolve to nothing and be wrongly marked.
  Future<int> markUnresolvableAsMissing() async {
    if (!_auth.isLoggedIn) return 0;
    final resolver = await _scripMaster.resolver();
    final rows = await _ipoDao.awaitingLevels();
    var marked = 0;
    for (final ipo in rows) {
      final resolution = resolver.resolve(
        ipo.symbol,
        preferredExchange: ipo.exchange,
        companyName: ipo.companyName,
      );
      if (resolution.isResolved) continue; // has a token: the normal path will get it
      await _ipoDao.setLevels(ipo.id!, 0, 0, LevelsSource.missing);
      marked++;
    }
    return marked;
  }

  /// Re-runs rows previously marked `missing` (e.g. after the daily scrip
  /// master refresh renamed or re-added a symbol).
  Future<LevelsFetchResult> retryMissing() async {
    final rows = await pendingRows(includeMissing: true);
    if (rows.isEmpty) return const LevelsFetchResult();
    for (final row in rows) {
      await _ipoDao.setLevels(row.id!, 0, 0, LevelsSource.pending);
    }
    return fetchPending(fetchAll: true);
  }

  @visibleForTesting
  static Duration get windowBefore => _windowBefore;
  @visibleForTesting
  static Duration get windowAfter => _windowAfter;
}
