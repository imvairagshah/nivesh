// ---------------------------------------------------------------------------
// live_feed_service.dart — the SmartAPI WebSocket 2.0 client used for live
// paper-trading prices and stop-loss monitoring.
//
//   wss://smartapisocket.angelone.in/smart-stream
//
// Connect headers (note the trap: the REST API wants `Bearer <jwt>`, the feed
// wants the **raw** JWT — that is what the official Python SDK sends, and a
// "Bearer " prefix here is rejected):
//
//   Authorization    <jwtToken>        ← no "Bearer " prefix
//   x-api-key        <apiKey>
//   x-client-code    <clientCode>
//   x-feed-token     <feedToken>
//
// Subscribe / unsubscribe (JSON, action 1 / 0):
//   {"correlationID":"ab12cd34ef","action":1,
//    "params":{"mode":1,"tokenList":[{"exchangeType":1,"tokens":["3045"]}]}}
//
// Heartbeat: the app sends the literal text "ping" every 10 s (the interval the
// official SDK uses); the server answers "pong" or a 2-byte binary control
// frame. If nothing arrives for three intervals the socket is treated as
// half-open and recycled — otherwise a phone that lost signal keeps showing
// stale prices that never update and never error.
//
// The service owns three things and nothing else:
//   * the socket lifecycle (connect, reconnect with exponential backoff, close)
//   * the subscription set (diffed, never re-sent wholesale)
//   * the last-tick cache, so any widget can ask `priceFor('NSE:SBIN')`
//
// Parsing lives in feed_decoder.dart (pure, unit-tested); the trading rules live
// in PaperTradingProvider. This class knows nothing about orders.
// ---------------------------------------------------------------------------

import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:web_socket_channel/io.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

import '../core/utils/markets.dart';
import '../data/remote/dto/quote.dart';
import 'auth_service.dart';
import 'feed_decoder.dart';

/// Connection state, surfaced in the Paper Trading header.
enum FeedStatus {
  /// No socket, and nothing wanted one.
  idle('Idle'),

  /// Opening the socket.
  connecting('Connecting…'),

  /// Live and subscribed.
  connected('Live'),

  /// Was connected, dropped, coming back.
  reconnecting('Reconnecting…'),

  /// Could not connect at all (no session, or the socket refused).
  error('Feed error');

  const FeedStatus(this.label);

  final String label;

  bool get isLive => this == FeedStatus.connected;
}

/// One instrument the app wants prices for.
@immutable
class FeedSubscription {
  /// Numeric instrument token (string form, as the master stores it).
  final String token;

  final Exchange exchange;

  /// App-wide price key, `EXCHANGE:PLAIN_SYMBOL` (e.g. `NSE:SBIN`).
  final String priceKey;

  const FeedSubscription({
    required this.token,
    required this.exchange,
    required this.priceKey,
  });

  /// Uniqueness key: tokens are only unique *within* an exchange segment.
  String get id => '${exchange.wsType}:$token';

  @override
  bool operator ==(Object other) =>
      other is FeedSubscription && other.id == id && other.priceKey == priceKey;

  @override
  int get hashCode => Object.hash(id, priceKey);
}

/// The three things the feed needs from a socket: a stream of incoming frames, a
/// way to send text, and a way to hang up.
///
/// Putting this thin interface in front of `WebSocketChannel` keeps the trading
/// logic free of transport details and — more practically — makes the whole
/// service testable: the tests inject a fake socket and assert on the exact JSON
/// that would have gone to SmartAPI, with no network involved.
abstract class FeedSocket {
  /// Incoming frames: `String` (heartbeat text) or `List<int>`/`Uint8List`
  /// (binary packets).
  Stream<dynamic> get stream;

  /// Completes once the connection is usable; fails if the handshake fails.
  Future<void> get ready;

  /// Sends a text frame (the only kind the protocol needs from the client).
  void send(String message);

  /// Closes the connection. Must never throw.
  Future<void> close();
}

/// Default transport: the dart:io WebSocket, which is what a mobile app uses.
/// (A browser build could not use this — SmartAPI's feed needs auth *headers*,
/// which `WebSocket` in a browser cannot set.)
class IoFeedSocket implements FeedSocket {
  IoFeedSocket(this._channel);

  final WebSocketChannel _channel;

  @override
  Stream<dynamic> get stream => _channel.stream;

  @override
  Future<void> get ready => _channel.ready;

  @override
  void send(String message) => _channel.sink.add(message);

  @override
  Future<void> close() async {
    try {
      await _channel.sink.close();
    } catch (_) {
      // Already dead — nothing to do.
    }
  }
}

/// Builds a socket for one connection attempt. Injected in tests.
typedef FeedSocketFactory = FeedSocket Function(
  Uri uri,
  Map<String, dynamic> headers,
);

class LiveFeedService extends ChangeNotifier {
  LiveFeedService({
    required AuthService auth,
    FeedSocketFactory? socketFactory,
    Duration pingInterval = const Duration(seconds: 10),
    Duration reconnectBase = const Duration(seconds: 2),
    Duration reconnectMax = const Duration(seconds: 60),
    int maxTokens = maxTokensPerSession,
    this.pingTimeoutIntervals = 3,
  })  : _auth = auth,
        _socketFactory = socketFactory ??
            ((uri, headers) => IoFeedSocket(IOWebSocketChannel.connect(
                  uri,
                  headers: headers,
                  connectTimeout: const Duration(seconds: 15),
                ))),
        _pingInterval = pingInterval,
        _reconnectBase = reconnectBase,
        _reconnectMax = reconnectMax,
        _maxTokens = maxTokens;

  /// Documented cap: one WebSocket session may carry 1,000 subscriptions in
  /// LTP mode.
  static const int maxTokensPerSession = 1000;

  static final Uri endpoint = Uri.parse('wss://smartapisocket.angelone.in/smart-stream');

  final AuthService _auth;
  final FeedSocketFactory _socketFactory;
  final Duration _pingInterval;
  final Duration _reconnectBase;
  final Duration _reconnectMax;
  final int _maxTokens;

  /// How many ping intervals may pass without any server traffic before the
  /// socket is recycled.
  final int pingTimeoutIntervals;

  // ---- connection -------------------------------------------------------
  FeedSocket? _socket;
  StreamSubscription<dynamic>? _frameSub;
  Timer? _pingTimer;
  Timer? _reconnectTimer;
  FeedStatus _status = FeedStatus.idle;
  String? _error;
  int _reconnectAttempt = 0;
  bool _disposed = false;
  bool _stopping = false;
  bool _connecting = false;

  // ---- subscriptions ----------------------------------------------------
  /// What the app wants (the target set); the diff source of truth.
  final Map<String, FeedSubscription> _desired = {};

  /// What the server currently has. Cleared on reconnect so the whole target set
  /// is re-sent (the server forgets subscriptions when the socket drops).
  final Map<String, FeedSubscription> _subscribed = {};

  /// What the *caller* of [sync] asked for, without the feature extras — so a
  /// module can add or drop its own tokens without accidentally re-subscribing
  /// the ones it is trying to release.
  final Map<String, FeedSubscription> _baseWanted = {};

  /// Subscriptions owned by *other* features — keyed `owner|id`.
  ///
  /// The trading engine owns [sync]; a module that only wants a couple of extra
  /// tokens (the F&O study's live ATM premium line) registers them here and they
  /// ride along with every [sync] call without either side knowing about the
  /// other.
  final Map<String, FeedSubscription> _extras = {};

  // ---- price cache ------------------------------------------------------
  /// Latest tick per subscription id.
  final Map<String, LiveTick> _ticks = {};

  /// Latest tick per price key (`NSE:SBIN`) — what the UI asks for.
  final Map<String, LiveTick> _byPriceKey = {};

  final StreamController<LiveTick> _tickController =
      StreamController<LiveTick>.broadcast();

  // ---- diagnostics ------------------------------------------------------
  DateTime? _connectedAt;
  DateTime? _lastServerMessageAt;
  int _ticksReceived = 0;
  int _malformedFrames = 0;
  int _unmappedTicks = 0;
  int _reconnects = 0;

  // -------------------------------------------------------------------------
  // Read-only surface
  // -------------------------------------------------------------------------

  FeedStatus get status => _status;
  String? get error => _error;
  bool get isStreaming => _status.isLive;

  /// Stream of decoded ticks. Broadcast: the stop-loss watcher, the open-order
  /// matcher and the UI all listen at once.
  Stream<LiveTick> get ticks => _tickController.stream;

  int get subscribedTokenCount => _subscribed.length;
  int get wantedTokenCount => _desired.length;
  int get ticksReceived => _ticksReceived;
  int get malformedFrames => _malformedFrames;
  int get unmappedTicks => _unmappedTicks;
  int get reconnectCount => _reconnects;
  DateTime? get connectedAt => _connectedAt;
  DateTime? get lastServerMessageAt => _lastServerMessageAt;
  DateTime? get lastTickAt => _lastTickAt;
  DateTime? _lastTickAt;
  DateTime? _lastNotifyAt;

  /// Price keys with a live price (used for "n of m priced" labels).
  Set<String> get pricedKeys => _byPriceKey.keys.toSet();

  /// Latest price for a key like `NSE:SBIN`, `null` when never ticked.
  double? priceFor(String priceKey) {
    final tick = _byPriceKey[priceKey];
    if (tick == null) return null;
    return tick.ltp;
  }

  LiveTick? tickFor(String priceKey) => _byPriceKey[priceKey];

  /// Every cached tick, keyed by subscription id (`<exchangeType>:<token>`).
  /// Exposed for diagnostics and tests; the UI should use [tickFor].
  Map<String, LiveTick> get ticksBySubscription => Map.unmodifiable(_ticks);

  /// How stale the price for [priceKey] is (null when there is none).
  Duration? stalenessFor(String priceKey, {DateTime? now}) {
    final tick = _byPriceKey[priceKey];
    if (tick == null) return null;
    return (now ?? DateTime.now()).difference(tick.receivedAt);
  }

  /// `true` when [priceKey] has a tick younger than [maxAge].
  bool isFresh(String priceKey, {Duration maxAge = const Duration(minutes: 2)}) {
    final age = stalenessFor(priceKey);
    return age != null && age <= maxAge;
  }

  // -------------------------------------------------------------------------
  // Subscription management
  // -------------------------------------------------------------------------

  /// Declares exactly which instruments the app wants, then connects or sends
  /// only the **difference** to the server.
  ///
  /// Called on every change of the watch list (open positions, resting limit
  /// orders, the symbol being previewed in the order sheet). Idempotent: calling
  /// it with the same set sends nothing.
  Future<void> sync(List<FeedSubscription> wanted) async {
    if (_disposed) return;

    final base = <String, FeedSubscription>{};
    for (final sub in wanted) {
      if (sub.token.isEmpty) continue;
      if (base.length >= _maxTokens) break; // documented session cap
      base[sub.id] = sub;
    }
    _baseWanted
      ..clear()
      ..addAll(base);

    final target = <String, FeedSubscription>{...base};

    // Feature-owned extras (e.g. the F&O study watching its ATM CE/PE).
    for (final sub in _extras.values) {
      if (sub.token.isEmpty) continue;
      if (target.length >= _maxTokens) break;
      target[sub.id] = sub;
    }

    // Unsubscribe what is no longer wanted (best effort — a dropped socket will
    // re-subscribe from `_desired` anyway).
    final removals = <FeedSubscription>[];
    for (final entry in _desired.entries) {
      if (!target.containsKey(entry.key)) removals.add(entry.value);
    }

    _desired
      ..clear()
      ..addAll(target);

    if (_desired.isEmpty) {
      // Nothing to watch: keep the socket if it is already open (the user may be
      // about to place an order) but drop the subscriptions.
      if (_subscribed.isNotEmpty) await _sendUnsubscribe(_subscribed.values.toList());
      _subscribed.clear();
      notifyListeners();
      return;
    }

    if (_status != FeedStatus.connected) {
      await _connect();
      return; // _connect() subscribes the whole target set
    }

    final additions = _desired.values
        .where((sub) => !_subscribed.containsKey(sub.id))
        .toList(growable: false);

    if (removals.isNotEmpty) await _sendUnsubscribe(removals);
    if (additions.isNotEmpty) await _sendSubscribe(additions);
    notifyListeners();
  }

  /// Registers (or replaces) the subscriptions owned by [owner].
  ///
  /// Used by the F&O study: while a stock's detail panel is open its ATM CE and
  /// PE are streamed, and closing the panel releases them. Survives overlapping
  /// [sync] calls from the trading engine.
  Future<void> setExtraSubscriptions(
    String owner,
    List<FeedSubscription> subscriptions,
  ) async {
    if (_disposed) return;
    _extras.removeWhere((key, _) => key.startsWith('$owner|'));
    for (final sub in subscriptions) {
      _extras['$owner|${sub.id}'] = sub;
    }
    await sync(_baseWanted.values.toList());
  }

  /// How many extra subscriptions [owner] holds right now.
  ///
  /// A screen owns its slice of the one shared socket; this is how a test (or a
  /// status line) checks that closing a panel really let go of its legs
  /// instead of leaving them ticking forever.
  int extraSubscriptionCount(String owner) =>
      _extras.keys.where((key) => key.startsWith('$owner|')).length;

  /// Releases everything registered by [owner].
  Future<void> clearExtraSubscriptions(String owner) async {
    if (_disposed) return;
    _extras.removeWhere((key, _) => key.startsWith('$owner|'));
    await sync(_baseWanted.values.toList());
  }

  /// Drops every subscription but keeps the socket (used when the last position
  /// and order are gone).
  Future<void> clearSubscriptions() async {
    _desired.clear();
    if (_subscribed.isNotEmpty && _status == FeedStatus.connected) {
      await _sendUnsubscribe(_subscribed.values.toList());
    }
    _subscribed.clear();
    notifyListeners();
  }

  /// Opens the socket if it is closed, then (re)subscribes everything wanted.
  Future<void> _connect() async {
    if (_disposed || _stopping || _connecting) return;
    if (_desired.isEmpty) return;
    _connecting = true;
    try {
      await _connectInner();
    } finally {
      _connecting = false;
    }
  }

  Future<void> _connectInner() async {
    if (_disposed || _stopping) return;

    final session = _auth.session;
    if (session == null || session.feedToken.isEmpty) {
      _fail('Not logged in to Angel One — the live feed needs a session '
          '(Settings → Sign in). Paper trading still works with manual prices.');
      return;
    }

    _reconnectTimer?.cancel();
    _setStatus(_reconnectAttempt == 0 ? FeedStatus.connecting : FeedStatus.reconnecting);

    try {
      final socket = _socketFactory(endpoint, {
        // RAW jwt — no "Bearer " prefix on the streaming endpoint.
        'Authorization': session.jwtToken,
        'x-api-key': session.apiKey,
        'x-client-code': session.clientCode,
        'x-feed-token': session.feedToken,
      });

      _socket = socket;
      _frameSub = socket.stream.listen(
        _onFrame,
        onError: (Object e) => _onSocketLost('$e'),
        onDone: () => _onSocketLost('socket closed'),
        cancelOnError: false,
      );

      await socket.ready;

      if (_disposed || _stopping) {
        await _closeSocket();
        return;
      }

      _connectedAt = DateTime.now();
      _lastServerMessageAt = DateTime.now();
      _reconnectAttempt = 0;
      _error = null;
      _subscribed.clear();
      _setStatus(FeedStatus.connected);

      // The server forgets subscriptions with the socket: send the whole set.
      await _sendSubscribe(_desired.values.toList());
      _startPingTimer();
    } catch (e) {
      _onSocketLost('connect failed: $e');
    }
  }

  Future<void> _sendSubscribe(List<FeedSubscription> subs) async {
    if (subs.isEmpty) return;
    final ok = _send({
      'correlationID': _correlationId(),
      'action': 1,
      'params': {
        'mode': FeedMode.ltp.code,
        'tokenList': _groupByExchange(subs),
      },
    });
    if (ok) {
      for (final sub in subs) {
        _subscribed[sub.id] = sub;
      }
    }
  }

  Future<void> _sendUnsubscribe(List<FeedSubscription> subs) async {
    if (subs.isEmpty) return;
    _send({
      'correlationID': _correlationId(),
      'action': 0,
      'params': {
        'mode': FeedMode.ltp.code,
        'tokenList': _groupByExchange(subs),
      },
    });
    for (final sub in subs) {
      _subscribed.remove(sub.id);
    }
  }

  /// `[{"exchangeType":1,"tokens":["3045","…"]}]` — grouped per segment, which is
  /// the shape the server expects.
  List<Map<String, Object?>> _groupByExchange(List<FeedSubscription> subs) {
    final grouped = <int, List<String>>{};
    for (final sub in subs) {
      grouped.putIfAbsent(sub.exchange.wsType, () => []).add(sub.token);
    }
    return grouped.entries
        .map((e) => <String, Object?>{
              'exchangeType': e.key,
              'tokens': e.value,
            })
        .toList(growable: false);
  }

  bool _send(Map<String, Object?> message) {
    final socket = _socket;
    if (socket == null || _status != FeedStatus.connected) return false;
    try {
      socket.send(jsonEncode(message));
      return true;
    } catch (e) {
      _onSocketLost('send failed: $e');
      return false;
    }
  }

  /// 10-character alphanumeric correlation id (the server echoes it in errors).
  String _correlationId() {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    final rand = math.Random();
    return List.generate(10, (_) => chars[rand.nextInt(chars.length)]).join();
  }

  // -------------------------------------------------------------------------
  // Incoming frames
  // -------------------------------------------------------------------------

  void _onFrame(dynamic message) {
    _lastServerMessageAt = DateTime.now();

    // Text frames: only the heartbeat is expected.
    if (message is String) {
      if (message.toLowerCase().contains('pong')) return;
      return;
    }
    if (message is! List<int>) return;

    final frame = FeedDecoder.decode(
      message is Uint8List ? message : Uint8List.fromList(message),
    );

    switch (frame.kind) {
      case FeedFrameKind.control:
        // Server ping (1) needs no reply; the app's own "ping" keeps the
        // connection warm. A pong just proves liveness, already recorded above.
        return;
      case FeedFrameKind.malformed:
        _malformedFrames++;
        return;
      case FeedFrameKind.packet:
        _handleTick(frame.tick!);
    }
  }

  void _handleTick(LiveTick tick) {
    _ticksReceived++;
    _lastTickAt = tick.receivedAt;

    // Route the token → price key. Unknown tokens are counted, not stored: the
    // server can keep sending a segment after we unsubscribed in a race.
    final subscription = _desired['${tick.exchange.wsType}:${tick.token}'] ??
        _subscribed['${tick.exchange.wsType}:${tick.token}'];
    if (subscription == null) {
      _unmappedTicks++;
      return;
    }

    final previous = _byPriceKey[subscription.priceKey];
    // Drop out-of-order packets (the sequence number is monotonic per token).
    if (previous != null &&
        previous.sequence != null &&
        tick.sequence != null &&
        tick.sequence! < previous.sequence!) {
      return;
    }

    _ticks[subscription.id] = tick;
    _byPriceKey[subscription.priceKey] = tick;

    if (!_tickController.isClosed) _tickController.add(tick);
    _notifyThrottled();
  }

  /// `notifyListeners()` at most every [minGap]: the tick *stream* stays
  /// real-time for the trading engine, while the UI is spared a rebuild storm
  /// during a busy session (60+ packets/second is normal on a volatile day).
  void _notifyThrottled({
    Duration minGap = const Duration(milliseconds: 250),
  }) {
    final now = DateTime.now();
    final last = _lastNotifyAt;
    if (last != null && now.difference(last) < minGap) return;
    _lastNotifyAt = now;
    notifyListeners();
  }

  // -------------------------------------------------------------------------
  // Heartbeat + reconnect
  // -------------------------------------------------------------------------

  void _startPingTimer() {
    _pingTimer?.cancel();
    _pingTimer = Timer.periodic(_pingInterval, (_) {
      if (_status != FeedStatus.connected) return;

      // Half-open detection: no traffic for N intervals means the socket is dead
      // even though the OS has not told us yet (typical after a tunnel/underground
      // signal loss).
      final last = _lastServerMessageAt;
      if (last != null &&
          DateTime.now().difference(last) > _pingInterval * pingTimeoutIntervals) {
        _onSocketLost('no feed traffic for '
            '${_pingInterval.inSeconds * pingTimeoutIntervals}s');
        return;
      }

      final socket = _socket;
      if (socket == null) return;
      try {
        socket.send('ping'); // the documented app-level heartbeat
      } catch (_) {
        _onSocketLost('ping failed');
      }
    });
  }

  void _onSocketLost(String reason) {
    if (_disposed || _stopping) return;
    _teardownSocket();
    if (_desired.isEmpty) {
      _setStatus(FeedStatus.idle);
      return;
    }

    _reconnects++;
    _reconnectAttempt++;
    _setStatus(FeedStatus.reconnecting, error: null);

    // Exponential backoff with a *proportional* jitter: a fleet of devices that
    // reconnects after an outage must not hammer the endpoint in lockstep, but
    // the jitter has to stay small relative to the delay (a flat 400 ms on top
    // of a 2 s delay is noise; on a 10 ms delay it is a different timer).
    final baseMs = _reconnectBase.inMilliseconds * (1 << (_reconnectAttempt - 1));
    final cappedMs = math.min(baseMs, _reconnectMax.inMilliseconds);
    final jitter = math.Random().nextInt(math.max(1, cappedMs ~/ 4) + 1);
    final delay = Duration(milliseconds: cappedMs + jitter);

    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(delay, _connect);
  }

  void _teardownSocket() {
    _pingTimer?.cancel();
    _pingTimer = null;
    _frameSub?.cancel();
    _frameSub = null;
    _closeSocket();
    _subscribed.clear();
    _connectedAt = null;
  }

  Future<void> _closeSocket() async {
    final socket = _socket;
    _socket = null;
    if (socket == null) return;
    await socket.close();
  }

  void _fail(String message) {
    _teardownSocket();
    _setStatus(FeedStatus.error, error: message);
  }

  void _setStatus(FeedStatus status, {String? error}) {
    _status = status;
    _error = error ?? (status == FeedStatus.error ? _error : null);
    if (!_disposed) notifyListeners();
  }

  // -------------------------------------------------------------------------
  // Lifecycle
  // -------------------------------------------------------------------------

  /// Closes the socket and forgets the watch list. Prices stay cached so the UI
  /// can keep showing the last known value (clearly labelled as stale).
  Future<void> stop({bool clearPrices = false}) async {
    _stopping = true;
    _reconnectTimer?.cancel();
    _reconnectTimer = null;
    _reconnectAttempt = 0;
    _desired.clear();
    _teardownSocket();
    if (clearPrices) clearPriceCache();
    _stopping = false;
    _setStatus(FeedStatus.idle);
  }

  void clearPriceCache() {
    _ticks.clear();
    _byPriceKey.clear();
    _lastTickAt = null;
    notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _reconnectTimer?.cancel();
    _pingTimer?.cancel();
    _frameSub?.cancel();
    // Fire-and-forget: closing a socket during teardown must not throw into the
    // widget tree.
    unawaited(_closeSocket());
    unawaited(_tickController.close());
    super.dispose();
  }
}
