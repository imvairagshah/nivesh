// ---------------------------------------------------------------------------
// main.dart — application entry point.
//
// Everything (IPO database, scrip master, cache, P&L) lives on the device. The
// only outbound traffic is to Angel One SmartAPI (login, prices, candles) and,
// optionally, the TradingView chart page the user taps through to.
//
// There is NO server component and NO real order is ever placed: the
// paper-trading module is a simulation (Feature 3).
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';

import 'app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // A widget that throws while building is replaced by Flutter's error widget.
  // In a debug build that is a loud red box; **in a release build it is an
  // empty grey rectangle** — which is exactly what a user sees as "pura blank
  // screen", with nothing to report back. (This bit us in 1.5.21: a page read a
  // provider the app never installed, and the release APK said nothing.)
  //
  // So the error widget is replaced with one that always says what broke, in
  // every build. A visible failure is a bug report; a blank screen is not.
  ErrorWidget.builder = (FlutterErrorDetails details) =>
      _CrashBox(message: '${details.exception}');

  runApp(const AngelTraderApp());
}

/// What stands in for a widget that could not build.
///
/// Deliberately loud: cream-on-red, the exception's first lines, and a hint to
/// send it along. It renders inside the app's own tree, so it is visible in
/// release builds with no logcat and no debugger attached.
class _CrashBox extends StatelessWidget {
  const _CrashBox({required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    // Directionality is not optional here: this widget stands in for whatever
    // failed, and failures happen most often exactly where no MaterialApp has
    // been built yet (see the splash in app.dart). A Text without it throws —
    // so the error widget would throw while reporting the error, and the user
    // would be back to a screen that shows nothing at all.
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Container(
      color: const Color(0xFFB00020),
      padding: const EdgeInsets.all(14),
      margin: const EdgeInsets.all(8),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.error_outline_rounded,
                  color: Colors.white, size: 18),
              const SizedBox(width: 8),
              const Expanded(
                child: Text(
                  'Is screen me kuch tooti hai',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 13.5,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            message,
            maxLines: 8,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 11,
              height: 1.35,
              fontFamily: 'monospace',
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'NiveshDesk — ye likh kar bhej do, isi se theek hoga.',
            style: TextStyle(color: Colors.white70, fontSize: 10.5),
          ),
        ],
      ),
      ),
    );
  }
}
