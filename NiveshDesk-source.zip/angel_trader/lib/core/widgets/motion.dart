// ---------------------------------------------------------------------------
// motion.dart — the small, shared animation kit.
//
// House rules (so the app feels consistent and never gimmicky):
//   * every effect is short and eased — no bouncing, no spinning logos;
//   * loops exist only where they carry meaning: [PulseDot] = "this price is
//     live", [Shimmer] = "this is still loading";
//   * nothing here changes layout or hit-testing, so it is safe to drop into
//     lists, cards and headers.
//
// Durations and curves all come from [AppMotion] in app_theme.dart.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

// ---------------------------------------------------------------------------
// Numbers
// ---------------------------------------------------------------------------

/// A number that animates whenever it changes (and counts up on first paint).
///
/// Used for the dashboard P&L tiles: when a tick moves the portfolio value, the
/// figure rolls instead of snapping, which makes the change readable at a
/// glance.
class NumberTicker extends StatefulWidget {
  const NumberTicker({
    super.key,
    required this.value,
    required this.format,
    this.style,
    this.duration = const Duration(milliseconds: 520),
    this.curve = Curves.easeOutCubic,
    this.countUpOnFirstBuild = true,
    this.textAlign,
    this.maxLines,
    this.overflow,
  });

  final double value;

  /// Turns the in-flight double into the final string (usually `Fmt.money`).
  final String Function(double value) format;

  final TextStyle? style;
  final Duration duration;
  final Curve curve;

  /// `true` ⇒ the very first build counts up from 0.
  final bool countUpOnFirstBuild;

  final TextAlign? textAlign;
  final int? maxLines;
  final TextOverflow? overflow;

  @override
  State<NumberTicker> createState() => _NumberTickerState();
}

class _NumberTickerState extends State<NumberTicker>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: widget.duration,
  );

  late double _from;
  late double _to;

  @override
  void initState() {
    super.initState();
    _to = widget.value;
    _from = widget.countUpOnFirstBuild ? 0 : widget.value;
    if (_from == _to) {
      _controller.value = 1;
    } else {
      _controller.forward();
    }
  }

  @override
  void didUpdateWidget(NumberTicker old) {
    super.didUpdateWidget(old);
    if (widget.value == _to) return;
    // Continue from wherever the running animation is, so a burst of ticks
    // still produces one smooth roll rather than a stutter.
    _from = _value;
    _to = widget.value;
    _controller
      ..duration = widget.duration
      ..forward(from: 0);
  }

  double get _value =>
      _from + (_to - _from) * widget.curve.transform(_controller.value);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) => Text(
        widget.format(_value),
        style: widget.style,
        textAlign: widget.textAlign,
        maxLines: widget.maxLines,
        overflow: widget.overflow,
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Entrances
// ---------------------------------------------------------------------------

/// Fades + slides its child in once, after a per-index delay.
///
/// Wrap list items with `index:` and the list assembles itself top-to-bottom in
/// ~45 ms steps — enough to feel alive, short enough to never look like a
/// loading state.
class FadeSlideIn extends StatefulWidget {
  const FadeSlideIn({
    super.key,
    required this.child,
    this.index = 0,
    this.offsetY = AppMotion.slideY,
    this.duration = AppMotion.base,
    this.enabled = true,
  });

  final Widget child;
  final int index;
  final double offsetY;
  final Duration duration;

  /// Set `false` to render the child immediately (used when a list is refreshed
  /// and re-animating every row would be distracting).
  final bool enabled;

  @override
  State<FadeSlideIn> createState() => _FadeSlideInState();
}

class _FadeSlideInState extends State<FadeSlideIn>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: widget.duration,
  );

  @override
  void initState() {
    super.initState();
    if (!widget.enabled) {
      _controller.value = 1;
      return;
    }
    final steps = widget.index.clamp(0, AppMotion.maxStaggerIndex);
    final delay = AppMotion.stagger * steps;
    if (delay == Duration.zero) {
      _controller.forward();
    } else {
      Future<void>.delayed(delay, () {
        if (mounted) _controller.forward();
      });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final curved = CurvedAnimation(parent: _controller, curve: AppMotion.enter);
    return FadeTransition(
      opacity: curved,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: Offset(0, widget.offsetY / 100),
          end: Offset.zero,
        ).animate(curved),
        child: widget.child,
      ),
    );
  }
}

/// A cross-fade (with a whisper of scale) between two layouts — used when a tab
/// or a filter swaps the content below it.
class SwapFade extends StatelessWidget {
  const SwapFade({
    super.key,
    required this.child,
    this.duration = AppMotion.base,
  });

  final Widget child;
  final Duration duration;

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: duration,
      switchInCurve: AppMotion.enter,
      switchOutCurve: AppMotion.exit,
      transitionBuilder: (child, animation) => FadeTransition(
        opacity: animation,
        child: ScaleTransition(
          scale: Tween<double>(begin: 0.985, end: 1).animate(animation),
          child: child,
        ),
      ),
      child: child,
    );
  }
}

// ---------------------------------------------------------------------------
// Loops (information, not decoration)
// ---------------------------------------------------------------------------

/// A soft pulsing dot. Goes next to anything that is genuinely live: the
/// WebSocket price, an active scan, the feed status chip.
class PulseDot extends StatefulWidget {
  const PulseDot({
    super.key,
    required this.color,
    this.size = 8,
    this.period = const Duration(milliseconds: 1400),
  });

  final Color color;
  final double size;
  final Duration period;

  @override
  State<PulseDot> createState() => _PulseDotState();
}

class _PulseDotState extends State<PulseDot>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: widget.period,
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.size,
      height: widget.size,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) {
          final t = Curves.easeInOut.transform(_controller.value);
          // Ring expands and fades; the core stays solid so it never disappears.
          final ringScale = 1.0 + t * 1.5;
          final ringAlpha = (1 - t) * 0.5;
          return Stack(
            alignment: Alignment.center,
            children: [
              Transform.scale(
                scale: ringScale,
                child: Container(
                  width: widget.size,
                  height: widget.size,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: widget.color.withOpacity(ringAlpha),
                  ),
                ),
              ),
              Container(
                width: widget.size * 0.62,
                height: widget.size * 0.62,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: widget.color,
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

/// Skeleton placeholder with a travelling sheen — shown while the first page of
/// data loads, instead of an empty screen or a bare spinner.
class ShimmerBox extends StatefulWidget {
  const ShimmerBox({
    super.key,
    this.width,
    this.height = 14,
    this.radius = AppRadius.sm,
  });

  final double? width;
  final double height;
  final double radius;

  @override
  State<ShimmerBox> createState() => _ShimmerBoxState();
}

class _ShimmerBoxState extends State<ShimmerBox>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1500),
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final base = scheme.surfaceContainerHighest.withOpacity(0.65);
    final highlight = scheme.surfaceContainerHighest.withOpacity(0.15);

    return SizedBox(
      width: widget.width,
      height: widget.height,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) {
          final slide = _controller.value * 2 - 1; // -1 → 1
          return DecoratedBox(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(widget.radius),
              gradient: LinearGradient(
                begin: Alignment(slide - 1, 0),
                end: Alignment(slide + 1, 0),
                colors: [base, highlight, base],
                stops: const [0.35, 0.5, 0.65],
              ),
            ),
          );
        },
      ),
    );
  }
}

/// A few shimmer lines shaped like a card, for list placeholders.
class ShimmerCard extends StatelessWidget {
  const ShimmerCard({super.key, this.lines = 3});

  final int lines;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.md),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: const [
                ShimmerBox(width: 44, height: 44, radius: AppRadius.md),
                SizedBox(width: AppSpacing.md),
                Expanded(child: ShimmerBox(height: 16)),
              ],
            ),
            const SizedBox(height: AppSpacing.md),
            for (var i = 0; i < lines; i++) ...[
              ShimmerBox(width: i.isEven ? null : 180, height: 11),
              const SizedBox(height: AppSpacing.sm),
            ],
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Touch feedback
// ---------------------------------------------------------------------------

/// Scales its child down very slightly while pressed. Cards that already have an
/// InkWell still ripple; this just adds the tactile "lift".
class PressScale extends StatefulWidget {
  const PressScale({
    super.key,
    required this.child,
    this.scale = 0.985,
    this.enabled = true,
  });

  final Widget child;
  final double scale;
  final bool enabled;

  @override
  State<PressScale> createState() => _PressScaleState();
}

class _PressScaleState extends State<PressScale> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    if (!widget.enabled) return widget.child;
    return Listener(
      onPointerDown: (_) => setState(() => _down = true),
      onPointerUp: (_) => setState(() => _down = false),
      onPointerCancel: (_) => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? widget.scale : 1,
        duration: AppMotion.fast,
        curve: AppMotion.enter,
        child: widget.child,
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Progress
// ---------------------------------------------------------------------------

/// A thin progress bar that animates to its new value (scans, imports).
class SmoothProgressBar extends StatelessWidget {
  const SmoothProgressBar({
    super.key,
    required this.value,
    this.height = 6,
    this.color,
  });

  /// `0 → 1`.
  final double value;
  final double height;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return ClipRRect(
      borderRadius: BorderRadius.circular(height),
      child: TweenAnimationBuilder<double>(
        tween: Tween<double>(begin: 0, end: value.clamp(0.0, 1.0)),
        duration: AppMotion.slow,
        curve: AppMotion.enter,
        builder: (context, animated, _) => LinearProgressIndicator(
          value: animated,
          minHeight: height,
          color: color ?? scheme.primary,
          backgroundColor: scheme.surfaceContainerHighest,
        ),
      ),
    );
  }
}
