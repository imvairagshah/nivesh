// ---------------------------------------------------------------------------
// page_scroll.dart — 1.5.92 "ek page = ek scroll" (desktop fix).
//
// Problem (PC build): screens ke andar header fixed + andar ka list apna scroll
// → do scroll areas, mouse-wheel/drag confusing, aur page ka content ek saath
// nahi dikhta.
//
// Solution: [PageScroll] — poori page ke liye **ek hi** vertical scroll.
// Content ki height auto (jitna content, utni height), header + rows sab ek
// saath scroll hote hain.
//
// [AppScrollBehavior] — desktop par mouse se **drag** karke scroll + hamesha
// dikhne wala scrollbar (Flutter ka default sirf touch-drag allow karta hai,
// isliye PC par "scroll kaam nahi karta" jaisa lagta tha).
// ---------------------------------------------------------------------------

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

/// Desktop-friendly scroll behaviour: mouse drag + trackpad + visible bar.
class AppScrollBehavior extends MaterialScrollBehavior {
  const AppScrollBehavior();

  @override
  Set<PointerDeviceKind> get dragDevices => const {
        PointerDeviceKind.touch,
        PointerDeviceKind.mouse,
        PointerDeviceKind.trackpad,
        PointerDeviceKind.stylus,
        PointerDeviceKind.invertedStylus,
        PointerDeviceKind.unknown,
      };

  @override
  ScrollPhysics getScrollPhysics(BuildContext context) =>
      // Clamping: PC par overscroll bounce nahi, smooth stop.
      const ClampingScrollPhysics();
}

/// Ek page, ek scroll.
///
/// `PageScroll.children` — chhote/medium content ke liye: ek hi
/// `SingleChildScrollView`, height content ke hisaab se auto.
///
/// `PageScroll.builder` — bade lists ke liye: ek hi `ListView.builder`
/// (lazy), jisme header widgets pehle items hain — isliye header bhi usi
/// scroll me chalta hai (koi fixed header + nested list nahi).
class PageScroll extends StatefulWidget {
  const PageScroll._({
    super.key,
    this.children,
    this.itemCount = 0,
    this.itemBuilder,
    this.header = const [],
    this.footer = const [],
    this.padding = const EdgeInsets.fromLTRB(12, 10, 12, 28),
    this.onRefresh,
  });

  /// Poora content ek scroll me (auto height).
  const PageScroll.children(
    List<Widget> children, {
    EdgeInsets padding = const EdgeInsets.fromLTRB(12, 10, 12, 28),
    Future<void> Function()? onRefresh,
    Key? key,
  }) : this._(
          children: children,
          padding: padding,
          onRefresh: onRefresh,
          key: key,
        );

  /// Lazy list — header/footer bhi isi scroll ke items hain.
  const PageScroll.builder({
    required int itemCount,
    required IndexedWidgetBuilder itemBuilder,
    List<Widget> header = const [],
    List<Widget> footer = const [],
    EdgeInsets padding = const EdgeInsets.fromLTRB(12, 10, 12, 28),
    Future<void> Function()? onRefresh,
    Key? key,
  }) : this._(
          itemCount: itemCount,
          itemBuilder: itemBuilder,
          header: header,
          footer: footer,
          padding: padding,
          onRefresh: onRefresh,
          key: key,
        );

  final List<Widget>? children;
  final int itemCount;
  final IndexedWidgetBuilder? itemBuilder;
  final List<Widget> header;
  final List<Widget> footer;
  final EdgeInsets padding;
  final Future<void> Function()? onRefresh;

  @override
  State<PageScroll> createState() => _PageScrollState();
}

class _PageScrollState extends State<PageScroll> {
  final _controller = ScrollController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final desktop = Theme.of(context).platform == TargetPlatform.windows ||
        Theme.of(context).platform == TargetPlatform.linux ||
        Theme.of(context).platform == TargetPlatform.macOS;

    Widget child;
    if (widget.children != null) {
      child = SingleChildScrollView(
        controller: _controller,
        primary: false,
        physics: const ClampingScrollPhysics(),
        padding: widget.padding,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: widget.children!,
        ),
      );
    } else {
      final headerCount = widget.header.length;
      final footerCount = widget.footer.length;
      child = ListView.builder(
        controller: _controller,
        primary: false,
        physics: const ClampingScrollPhysics(),
        padding: widget.padding,
        itemCount: headerCount + widget.itemCount + footerCount,
        itemBuilder: (context, index) {
          if (index < headerCount) return widget.header[index];
          final i = index - headerCount;
          if (i < widget.itemCount) {
            return widget.itemBuilder!(context, i);
          }
          return widget.footer[i - widget.itemCount];
        },
      );
    }

    final scrolled = widget.onRefresh == null
        ? child
        : RefreshIndicator(onRefresh: widget.onRefresh!, child: child);

    return Scrollbar(
      controller: _controller,
      thumbVisibility: desktop,
      trackVisibility: desktop,
      child: scrolled,
    );
  }
}
