// ---------------------------------------------------------------------------
// ui.dart — the shared design pieces (1.5.58 redesign): every number gets its
// own labelled box so values never run together, short emoji labels with a
// tooltip carrying the full meaning, clean section cards, and press-feedback
// chips. Simple, calm, consistent — used across the whole app.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';

/// One value in its own labelled box: `emoji label` on top, the value under
/// it, an optional small [sub] line. [tooltip] (long-press/hover) carries the
/// full meaning so the label can stay short. The box never wraps into its
/// neighbours — that is the whole point of the redesign.
class MetricBox extends StatelessWidget {
  const MetricBox({
    super.key,
    required this.label,
    required this.value,
    this.emoji = '',
    this.sub,
    this.tooltip,
    this.valueColor,
    this.strong = false,
    this.expand = false,
    this.fontSize,
  });

  /// Short label — e.g. '3M High', 'ATR'. Full meaning goes in [tooltip].
  final String label;

  /// The one value this box shows.
  final String value;

  /// Small emoji marker (📈, 📉, ⚡…) — symbols instead of long text.
  final String emoji;

  /// Optional secondary line inside the box (kept visually quieter).
  final String? sub;

  /// Full meaning, shown on long-press/hover.
  final String? tooltip;

  final Color? valueColor;
  final bool strong;

  /// Take the full row width (wide boxes like a headline number).
  final bool expand;

  final double? fontSize;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final box = Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest.withOpacity(0.5),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: scheme.outlineVariant.withOpacity(0.35)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (emoji.isNotEmpty) ...[
                Text(emoji, style: const TextStyle(fontSize: 9.5)),
                const SizedBox(width: 3),
              ],
              Flexible(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 9.5,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.2,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 3),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: fontSize ?? 13,
              fontWeight: strong ? FontWeight.w800 : FontWeight.w700,
              color: valueColor ?? scheme.onSurface,
            ),
          ),
          if (sub != null) ...[
            const SizedBox(height: 2),
            Text(
              sub!,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 9.5,
                color: scheme.onSurfaceVariant,
              ),
            ),
          ],
        ],
      ),
    );
    if (tooltip == null || tooltip!.isEmpty) return box;
    return Tooltip(message: tooltip!, child: box);
  }
}

/// A responsive grid of [MetricBox]es — equal-width boxes per row, and every
/// box in a row stretches to the SAME height (1.5.59 fix: heights must not
/// jump up/down inside a row). A box with `expand: true` takes the full row.
class MetricGrid extends StatelessWidget {
  const MetricGrid({super.key, required this.children});

  final List<Widget> children;

  static const double _spacing = 8;
  static const double _boxWidth = 108;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final maxWidth =
            constraints.maxWidth.isFinite ? constraints.maxWidth : 360.0;
        final perRow = ((maxWidth + _spacing) / (_boxWidth + _spacing))
            .floor()
            .clamp(1, 6);

        final rows = <Widget>[];
        var current = <Widget>[];

        void flush() {
          if (current.isEmpty) return;
          final chunk = List<Widget>.of(current);
          current = <Widget>[];
          rows.add(
            Padding(
              padding: const EdgeInsets.only(bottom: _spacing),
              child: IntrinsicHeight(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    for (var i = 0; i < chunk.length; i++) ...[
                      if (i > 0) const SizedBox(width: _spacing),
                      Expanded(child: chunk[i]),
                    ],
                  ],
                ),
              ),
            ),
          );
        }

        for (final child in children) {
          if (child is MetricBox && child.expand) {
            flush();
            rows.add(
              Padding(
                padding: const EdgeInsets.only(bottom: _spacing),
                child: IntrinsicHeight(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [Expanded(child: child)],
                  ),
                ),
              ),
            );
            continue;
          }
          current.add(child);
          if (current.length >= perRow) flush();
        }
        flush();
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: rows,
        );
      },
    );
  }
}

/// A quiet section card: emoji + short title (tooltip = full meaning) over a
/// grid/column of content. Sections are visually distinct — the "ek dusre se
/// alag lage" rule.
class InfoSection extends StatelessWidget {
  const InfoSection({
    super.key,
    required this.title,
    required this.children,
    this.emoji = '',
    this.tooltip,
  });

  final String title;
  final String emoji;
  final String? tooltip;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final header = Row(
      children: [
        if (emoji.isNotEmpty) ...[
          Text(emoji, style: const TextStyle(fontSize: 12)),
          const SizedBox(width: 5),
        ],
        Expanded(
          child: Text(
            title,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.3,
              color: scheme.primary,
            ),
          ),
        ),
      ],
    );
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.fromLTRB(11, 9, 11, 11),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerLow.withOpacity(0.7),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: scheme.outlineVariant.withOpacity(0.4)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (tooltip == null || tooltip!.isEmpty)
            header
          else
            Tooltip(message: tooltip!, child: header),
          const SizedBox(height: 8),
          ...children,
        ],
      ),
    );
  }
}

/// A chip with press feedback (scale/ink) — for trend/verdict/status chips.
class TapChip extends StatelessWidget {
  const TapChip({
    super.key,
    required this.label,
    this.emoji = '',
    this.color,
    this.onTap,
    this.tooltip,
    this.fontSize = 10,
    this.filled = false,
  });

  final String label;
  final String emoji;
  final Color? color;
  final VoidCallback? onTap;
  final String? tooltip;
  final double fontSize;
  final bool filled;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final fg = color ?? scheme.onSurfaceVariant;
    final chip = Material(
      color: filled ? fg.withOpacity(0.14) : Colors.transparent,
      borderRadius: BorderRadius.circular(7),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(7),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2.5),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(7),
            border: Border.all(color: fg.withOpacity(filled ? 0.25 : 0.35)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (emoji.isNotEmpty) ...[
                Text(emoji, style: TextStyle(fontSize: fontSize)),
                const SizedBox(width: 3),
              ],
              Flexible(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: fontSize,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.2,
                    color: fg,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
    if (tooltip == null || tooltip!.isEmpty) return chip;
    return Tooltip(message: tooltip!, child: chip);
  }
}

/// Wraps [child] in a smooth size animation — detail panels open/close with
/// a soft grow/shrink instead of a hard pop. Subtle by design.
class SmoothExpand extends StatelessWidget {
  const SmoothExpand({
    super.key,
    required this.child,
    this.duration = const Duration(milliseconds: 220),
  });

  final Widget child;
  final Duration duration;

  @override
  Widget build(BuildContext context) {
    return AnimatedSize(
      duration: duration,
      curve: Curves.easeOutCubic,
      alignment: Alignment.topCenter,
      child: AnimatedSwitcher(
        duration: duration,
        switchInCurve: Curves.easeOutCubic,
        switchOutCurve: Curves.easeInCubic,
        transitionBuilder: (child, animation) => FadeTransition(
          opacity: animation,
          child: SizeTransition(sizeFactor: animation, child: child),
        ),
        child: child,
      ),
    );
  }
}
