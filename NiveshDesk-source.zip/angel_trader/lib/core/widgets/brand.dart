// ---------------------------------------------------------------------------
// brand.dart — the NiveshDesk logo, drawn in code.
//
// WHY A PAINTER (and not a PNG/SVG asset):
//   * it stays razor sharp at every size — launcher icon (1024), app bar (26),
//     empty-state watermark (120) — with no asset variants to keep in sync;
//   * it follows the theme, so it never looks stuck-on in dark mode;
//   * it can *animate itself* (bars rise, trend line draws) for the splash,
//     which is where the brand gets its one moment of motion.
//
// The same geometry is reproduced by tool/generate_icon.py for the Android /
// iOS launcher assets, so the home-screen icon and the in-app mark match.
//
// The mark: three ascending bars (the screener's candles) with a gold trend
// line breaking through them — analysis + momentum, nothing more.
// ---------------------------------------------------------------------------

import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

/// Geometry shared by the painter and the launcher-icon generator.
///
/// All values are fractions of the mark's side, so the same numbers work at
/// any size. Keep in sync with `tool/generate_icon.py`.
class BrandGeometry {
  BrandGeometry._();

  /// Corner radius of the plate.
  static const double plateRadius = 0.28;

  /// Bar centres (x), width and height, all as fractions of the side.
  static const List<double> barCenters = [0.300, 0.475, 0.650];
  static const List<double> barHeights = [0.220, 0.330, 0.440];
  static const double barWidth = 0.105;

  /// Baseline every bar sits on.
  static const double barBaseline = 0.775;

  /// The trend line: an up-down-up zig-zag that breaks out of the bar cluster,
  /// plus the dot that marks "the latest price".
  static const List<Offset> trendPoints = [
    Offset(0.205, 0.655),
    Offset(0.375, 0.495),
    Offset(0.505, 0.575),
    Offset(0.775, 0.285),
  ];
  static const double trendWidth = 0.058;
  static const double tipDotRadius = 0.052;
}

/// Paints the mark. [progress] `0 → 1` plays the draw-in animation:
/// plate, then bars (staggered), then the trend line, then the tip dot.
class BrandMarkPainter extends CustomPainter {
  const BrandMarkPainter({
    this.progress = 1,
    required this.dark,
    this.showBackground = true,
    this.monochrome = false,
  });

  final double progress;
  final bool dark;
  final bool showBackground;
  final bool monochrome;

  @override
  void paint(Canvas canvas, Size size) {
    final s = size.shortestSide;
    final p = progress.clamp(0.0, 1.0);

    // The plate scales in very slightly, which makes the entrance feel placed
    // rather than just faded.
    final plateT = Curves.easeOutCubic.transform((p / 0.30).clamp(0.0, 1.0));
    if (showBackground) {
      canvas.save();
      final scale = 0.92 + 0.08 * plateT;
      canvas.translate(s / 2, s / 2);
      canvas.scale(scale);
      canvas.translate(-s / 2, -s / 2);
      canvas.saveLayer(Offset.zero & Size(s, s), Paint());

      final rrect = RRect.fromRectAndRadius(
        Rect.fromLTWH(0, 0, s, s),
        Radius.circular(s * BrandGeometry.plateRadius),
      );
      // Base gradient (alpha-faded by the entrance progress).
      canvas.drawRRect(
        rrect,
        Paint()
          ..shader = _fade(
            Brand.heroGradient(dark: dark),
            plateT,
          ).createShader(Rect.fromLTWH(0, 0, s, s)),
      );
      // Gold wash from the top-right — gives the flat plate some depth.
      canvas.drawRRect(
        rrect,
        Paint()
          ..shader = _fade(
            Brand.goldGlow(),
            plateT,
          ).createShader(Rect.fromLTWH(0, 0, s, s)),
      );
      // Hairline highlight along the top edge.
      canvas.drawRRect(
        rrect.deflate(s * 0.012),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = s * 0.012
          ..color = Colors.white.withOpacity(0.10 * plateT),
      );
      canvas.restore();
      canvas.restore();
    }

    final barColor = monochrome
        ? Colors.white
        : (showBackground
            ? const Color(0xFFF7FBF9)
            : (dark ? const Color(0xFFE6F4EF) : Brand.greenDeep));

    // ---- bars, staggered bottom-up
    final barWidth = s * BrandGeometry.barWidth;
    final baseline = s * BrandGeometry.barBaseline;
    for (var i = 0; i < BrandGeometry.barCenters.length; i++) {
      final local = ((p - 0.12 - i * 0.08) / 0.34).clamp(0.0, 1.0);
      if (local <= 0) continue;
      final grown = Curves.easeOutBack.transform(local);
      final height = s * BrandGeometry.barHeights[i] * grown;
      final centerX = s * BrandGeometry.barCenters[i];
      final alpha = monochrome ? (0.55 + 0.15 * i) : (0.72 + 0.09 * i);
      final rect = RRect.fromRectAndRadius(
        Rect.fromLTWH(
          centerX - barWidth / 2,
          baseline - height,
          barWidth,
          height,
        ),
        Radius.circular(barWidth / 2),
      );
      canvas.drawRRect(
        rect,
        Paint()..color = barColor.withOpacity(alpha.clamp(0.0, 1.0)),
      );
    }

    // ---- trend line, drawn on top so it reads as the "signal"
    final lineT = ((p - 0.58) / 0.42).clamp(0.0, 1.0);
    if (lineT > 0) {
      final points = BrandGeometry.trendPoints
          .map((o) => Offset(o.dx * s, o.dy * s))
          .toList(growable: false);

      final path = Path()..moveTo(points.first.dx, points.first.dy);
      for (final point in points.skip(1)) {
        path.lineTo(point.dx, point.dy);
      }

      final linePaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = s * BrandGeometry.trendWidth
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..color = monochrome ? Colors.white : Brand.gold;

      // Draw only the first `lineT` of the route, so it appears to travel.
      final metric = path.computeMetrics().first;
      final drawn = metric.extractPath(0, metric.length * lineT);
      canvas.drawPath(drawn, linePaint);

      // Tip dot — the "latest price" marker.
      if (lineT > 0.985 && !monochrome) {
        final tip = points.last;
        canvas.drawCircle(
          tip,
          s * BrandGeometry.tipDotRadius,
          Paint()..color = Brand.gold,
        );
        canvas.drawCircle(
          tip,
          s * BrandGeometry.tipDotRadius * 1.9,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = s * 0.014
            ..color = Brand.gold.withOpacity(0.35),
        );
      }
    }
  }

  /// Same gradient, every stop multiplied by [alpha] — a Canvas has no global
  /// alpha in Flutter, so the fade has to live in the colours themselves.
  static LinearGradient _fade(LinearGradient gradient, double alpha) =>
      LinearGradient(
        begin: gradient.begin,
        end: gradient.end,
        colors: [
          for (final color in gradient.colors) color.withOpacity(alpha),
        ],
        stops: gradient.stops,
      );

  @override
  bool shouldRepaint(BrandMarkPainter old) =>
      old.progress != progress ||
      old.dark != dark ||
      old.showBackground != showBackground ||
      old.monochrome != monochrome;
}

/// The static brand mark. Use it in app bars, list headers, About cards.
class BrandMark extends StatelessWidget {
  const BrandMark({
    super.key,
    this.size = 40,
    this.showBackground = true,
    this.monochrome = false,
  });

  final double size;
  final bool showBackground;
  final bool monochrome;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: '${Brand.name} logo',
      child: SizedBox(
        width: size,
        height: size,
        child: CustomPaint(
          painter: BrandMarkPainter(
            dark: Theme.of(context).brightness == Brightness.dark,
            showBackground: showBackground,
            monochrome: monochrome,
          ),
        ),
      ),
    );
  }
}

/// The mark with its draw-in animation. Plays once on mount; [delay] pushes it
/// slightly later so a splash layout can settle first.
class AnimatedBrandMark extends StatefulWidget {
  const AnimatedBrandMark({
    super.key,
    this.size = 96,
    this.delay = Duration.zero,
    this.duration = const Duration(milliseconds: 1150),
  });

  final double size;
  final Duration delay;
  final Duration duration;

  @override
  State<AnimatedBrandMark> createState() => _AnimatedBrandMarkState();
}

class _AnimatedBrandMarkState extends State<AnimatedBrandMark>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: widget.duration,
  );

  @override
  void initState() {
    super.initState();
    if (widget.delay == Duration.zero) {
      _controller.forward();
    } else {
      Future<void>.delayed(widget.delay, () {
        if (mounted) _controller.forward();
      });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return SizedBox(
      width: widget.size,
      height: widget.size,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) => CustomPaint(
          painter: BrandMarkPainter(progress: _controller.value, dark: dark),
        ),
      ),
    );
  }
}

/// Mark + two-tone wordmark (+ optional tagline). [axis] switches between the
/// app-bar layout (mark left of the text) and the splash layout (stacked).
class BrandLogo extends StatelessWidget {
  const BrandLogo({
    super.key,
    this.markSize = 36,
    this.axis = Axis.horizontal,
    this.showTagline = false,
    this.alignment = CrossAxisAlignment.start,
    this.textAlign = TextAlign.start,
  });

  /// Side of the mark; the wordmark scales with it.
  final double markSize;
  final Axis axis;
  final bool showTagline;
  final CrossAxisAlignment alignment;
  final TextAlign textAlign;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final fontSize = markSize * 0.58;

    final wordmark = BrandWordmark(fontSize: fontSize, textAlign: textAlign);

    final text = Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: alignment,
      children: [
        wordmark,
        if (showTagline) ...[
          SizedBox(height: markSize * 0.10),
          Text(
            Brand.tagline,
            textAlign: textAlign,
            style: TextStyle(
              fontSize: math.max(8.5, markSize * 0.16),
              fontWeight: FontWeight.w700,
              letterSpacing: 0.9,
              color: scheme.onSurfaceVariant,
            ),
          ),
        ],
      ],
    );

    if (axis == Axis.vertical) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: alignment == CrossAxisAlignment.start
            ? CrossAxisAlignment.center
            : alignment,
        children: [
          BrandMark(size: markSize),
          SizedBox(height: markSize * 0.28),
          text,
        ],
      );
    }

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        BrandMark(size: markSize),
        SizedBox(width: markSize * 0.30),
        Flexible(child: text),
      ],
    );
  }
}

/// Just the two-tone wordmark ("Nivesh" + brand-green "Desk"). Sizes with
/// [fontSize] so callers can pair it with any mark size.
class BrandWordmark extends StatelessWidget {
  const BrandWordmark({
    super.key,
    this.fontSize = 20,
    this.textAlign = TextAlign.start,
  });

  final double fontSize;
  final TextAlign textAlign;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Text.rich(
      TextSpan(
        children: [
          TextSpan(
            text: Brand.namePrefix,
            style: TextStyle(
              color: scheme.onSurface,
              fontWeight: FontWeight.w700,
              letterSpacing: -0.8,
            ),
          ),
          TextSpan(
            text: Brand.nameSuffix,
            style: TextStyle(
              color: scheme.primary,
              fontWeight: FontWeight.w800,
              letterSpacing: -0.8,
            ),
          ),
        ],
      ),
      textAlign: textAlign,
      style: TextStyle(fontSize: fontSize, height: 1.05),
    );
  }
}

/// A very faint mark used behind empty states — brand presence without noise.
class BrandWatermark extends StatelessWidget {
  const BrandWatermark({super.key, this.size = 120, this.opacity = 0.06});

  final double size;
  final double opacity;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Opacity(
        opacity: opacity,
        child: BrandMark(size: size),
      ),
    );
  }
}
