// ---------------------------------------------------------------------------
// app_version.dart — shows the *installed* build's version, read from the
// platform package metadata (PackageManager on Android). The About screen
// must never carry a hard-coded version string again: it would go stale the
// moment a new APK is installed (1.5.27 was shown by 1.5.34 builds).
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';

class AppVersionLabel extends StatelessWidget {
  const AppVersionLabel({super.key, this.placeholder = '…'});

  /// Shown until the platform metadata resolves.
  final String placeholder;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<PackageInfo>(
      // Resolved from the installed package; mocked in widget tests via
      // PackageInfo.setMockInitialValues.
      future: PackageInfo.fromPlatform(),
      builder: (context, snapshot) {
        final info = snapshot.data;
        return Text(
          info == null
              ? placeholder
              : '${info.version} (build ${info.buildNumber})',
          textAlign: TextAlign.end,
          style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600),
        );
      },
    );
  }
}
