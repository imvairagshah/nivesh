// ---------------------------------------------------------------------------
// json_array_scanner.dart — streaming parser for a top-level JSON *array*.
//
// Why: Angel One's scrip master is a single 40–60 MB JSON array of ~100k small
// objects. `jsonDecode`ing it on a phone spikes RAM (the string + parsed tree can
// exceed 400 MB) and risks an OOM kill.
//
// This scanner consumes the download stream as text, tracks brace depth and
// string state, and emits **one decoded object at a time**, so the caller can
// insert rows into SQLite in batches while the download is still in flight.
// Peak memory becomes one object + one chunk.
//
// It is deliberately dependency-free and unit-tested in
// test/core/json_array_scanner_test.dart (including braces inside strings,
// escaped quotes and nested arrays of objects).
// ---------------------------------------------------------------------------

import 'dart:convert';

class JsonArrayScanner {
  /// Objects completed so far (diagnostics / progress reporting).
  int objectCount = 0;

  /// Text of the object currently being captured.
  final StringBuffer _buffer = StringBuffer();

  /// Brace depth of the object being captured (0 = between objects).
  int _depth = 0;

  /// Set once the current object has been fully captured.
  bool _inString = false;
  bool _escaped = false;

  /// Rows that failed to decode (kept so the caller can log rather than crash).
  int decodeFailures = 0;

  /// Feeds one chunk of text (UTF-8 decoding is the caller's job, so multi-byte
  /// characters split across network chunks are already handled upstream).
  ///
  /// Returns every object that *completed* inside this chunk.
  List<Map<String, dynamic>> feed(String chunk) {
    final completed = <Map<String, dynamic>>[];

    for (var i = 0; i < chunk.length; i++) {
      final ch = chunk[i];

      // ---- scanning for the start of the next object -----------------------
      if (_depth == 0) {
        if (ch == '{') {
          _depth = 1;
          _buffer.clear();
          _buffer.write('{');
        }
        continue; // ignore ',', '[', whitespace and newlines between objects
      }

      // ---- inside an object -----------------------------------------------
      if (_inString) {
        _buffer.write(ch);
        if (_escaped) {
          _escaped = false;
        } else if (ch == r'\') {
          _escaped = true;
        } else if (ch == '"') {
          _inString = false;
        }
        continue;
      }

      switch (ch) {
        case '"':
          _inString = true;
          _buffer.write(ch);
        case '{':
          _depth++;
          _buffer.write(ch);
        case '}':
          _depth--;
          _buffer.write(ch);
          if (_depth == 0) {
            final object = _decode(_buffer.toString());
            if (object != null) {
              completed.add(object);
              objectCount++;
            } else {
              decodeFailures++;
            }
            _buffer.clear();
          }
        default:
          _buffer.write(ch);
      }
    }

    return completed;
  }

  /// Number of characters currently buffered for a partially received object.
  /// Non-zero at the end of a stream means the payload was truncated.
  int get bufferedChars => _buffer.length;

  Map<String, dynamic>? _decode(String text) {
    try {
      final decoded = jsonDecode(text);
      return decoded is Map<String, dynamic> ? decoded : null;
    } catch (_) {
      return null;
    }
  }
}
