// ---------------------------------------------------------------------------
// link_opener.dart — opens external URLs (TradingView charts).
//
// Every screener card has a "Chart" button that must open
//   https://in.tradingview.com/chart/?symbol=NSE:SYMBOL
// in the phone's browser / TradingView app. Failures are swallowed into a
// boolean so the UI can show a snackbar instead of throwing.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class LinkOpener {
  LinkOpener._();

  /// Opens [url] in an external application.
  ///
  /// Returns `false` when the platform refused to launch it (no browser, or the
  /// URL scheme is not allowed by the manifests' `<queries>` block).
  static Future<bool> open(String url, {BuildContext? context}) async {
    final uri = Uri.tryParse(url);
    if (uri == null) {
      _toast(context, 'That chart link is not valid.');
      return false;
    }

    try {
      final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!launched) _toast(context, 'No app can open $url');
      return launched;
    } catch (e) {
      _toast(context, 'Could not open the chart: $e');
      return false;
    }
  }

  /// TradingView chart URL for an exchange + ticker, e.g.
  /// `NSE:SBIN` → https://in.tradingview.com/chart/?symbol=NSE%3ASBIN
  static String tradingViewUrl(String exchange, String symbol) =>
      'https://in.tradingview.com/chart/?symbol='
      '${Uri.encodeComponent('$exchange:$symbol')}';

  static void _toast(BuildContext? context, String message) {
    if (context == null || !context.mounted) return;
    ScaffoldMessenger.maybeOf(context)?.showSnackBar(
      SnackBar(content: Text(message)),
    );
  }
}
