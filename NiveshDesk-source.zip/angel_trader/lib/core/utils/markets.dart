// ---------------------------------------------------------------------------
// markets.dart — market session rules, exchange codes and the trading calendar.
//
// Everything in this app is displayed in IST. The phone may be in any timezone,
// so all "is the market open / is data stale / has the 6 PM job window arrived"
// decisions go through this file (never through DateTime.now().hour).
// ---------------------------------------------------------------------------

import 'package:intl/intl.dart';

/// NSE/BSE equity market timings (regular session).
class MarketSession {
  static const int openHour = 9; // 09:15 IST
  static const int openMinute = 15;
  static const int closeHour = 15; // 15:30 IST
  static const int closeMinute = 30;

  /// Daily background scan window requested by the product spec: after 6 PM IST.
  static const int jobHour = 18;
  static const int jobMinute = 0;

  /// Pre-market starts 09:00 IST — useful to know for "LTP is the previous close".
  static const int preOpenHour = 9;
  static const int preOpenMinute = 0;
}

/// Angel One `exchange` enum used by REST + WebSocket calls.
enum Exchange {
  nse('NSE', 'nse_cm', 1),
  bse('BSE', 'bse_cm', 3),

  /// NSE's derivatives segment — stock/ index futures and options. Added for the
  /// F&O module: option contracts live here, and the SmartAPI quote endpoint
  /// takes `exchange: "NFO"` for them.
  nfo('NFO', 'nfo_cm', 2),

  /// BSE's derivatives segment (1.5.83). **BANKEX options** yahan quote hote
  /// hain — NSE ke NFO me nahi. Bankex module ke live quotes/candles isi
  /// segment se jaate hain. Cash-market chips (IPO screener) ise filter karte
  /// hain, isliye UI par naya option nahi dikhta.
  bfo('BFO', 'bfo_cm', 2);

  const Exchange(this.code, this.wsName, this.wsType);

  /// Value used in REST payloads (e.g. `"exchange": "NSE"`).
  final String code;

  /// Human-readable name of the streaming segment.
  final String wsName;

  /// `exchangeType` used by the SmartAPI WebSocket (1 = nse_cm, 3 = bse_cm).
  final int wsType;

  static Exchange fromCode(String code) => switch (code.toUpperCase()) {
        'BSE' => Exchange.bse,
        'NFO' => Exchange.nfo,
        'BFO' => Exchange.bfo,
        _ => Exchange.nse,
      };

  /// `true` for the cash-market exchanges (the F&O segment is not one).
  bool get isCash => this == Exchange.nse || this == Exchange.bse;
}

/// Which boundary of the listing-day range the current price is hugging.
enum LevelType {
  high('Near High'),
  low('Near Low');

  const LevelType(this.label);
  final String label;
}

/// Verdict for "where is LTP relative to listing-day range" — powers the little
/// status chip on each card in the IPO screener.
enum PriceBand {
  aboveRange('Above listing range'),
  nearHigh('Near listing high'),
  insideRange('Inside listing range'),
  nearLow('Near listing low'),
  belowRange('Below listing range');

  const PriceBand(this.label);
  final String label;
}

// ---------------------------------------------------------------------------
// Trading calendar
// ---------------------------------------------------------------------------

/// NSE/BSE trading-holiday calendar.
///
/// The calendar only needs to be *good enough* for UI wording ("latest trading
/// day"), because the actual scan works off real candle data returned by the
/// broker: a holiday simply has no rows. Keeping it here means the app can say
/// "market closed today" without an extra network call.
///
/// Entries are listed through 2026 (last known published list). Add the next
/// year's list from https://www.nseindia.com/resources/exchange-communication-holidays
/// update the `holidays` set and bump [calendarYear] — nothing else changes.
class MarketCalendar {
  MarketCalendar._();

  static const int calendarYear = 2026;

  /// ISO-8601 `yyyy-MM-dd` dates on which the equity segment is closed.
  static const Set<String> holidays = <String>{
    // ---------------- 2024 ----------------
    '2024-01-22', '2024-01-26', '2024-03-08', '2024-03-25', '2024-03-29',
    '2024-04-11', '2024-04-17', '2024-05-01', '2024-05-20', '2024-06-17',
    '2024-07-17', '2024-08-15', '2024-10-02', '2024-11-01', '2024-11-15',
    '2024-12-25',
    // ---------------- 2025 ----------------
    '2025-02-26', '2025-03-14', '2025-03-31', '2025-04-10', '2025-04-14',
    '2025-04-18', '2025-05-01', '2025-08-15', '2025-08-27', '2025-10-02',
    '2025-10-21', '2025-10-22', '2025-11-05', '2025-12-25',
    // ---------------- 2026 ----------------
    '2026-01-26', '2026-03-04', '2026-03-27', '2026-04-03', '2026-04-14',
    '2026-05-01', '2026-05-28', '2026-08-15', '2026-10-02', '2026-10-21',
    '2026-11-10', '2026-12-25',
  };

  /// `true` when [date] is a Saturday or Sunday.
  static bool isWeekend(DateTime date) =>
      date.weekday == DateTime.saturday || date.weekday == DateTime.sunday;

  /// `true` when the equity market is closed for the whole day.
  static bool isHoliday(DateTime date) {
    final key = DateFormat('yyyy-MM-dd').format(date);
    return holidays.contains(key);
  }

  /// `true` on Mon-Fri that is not in [holidays].
  static bool isTradingDay(DateTime date) =>
      !isWeekend(date) && !isHoliday(date);

  /// Most recent trading session **on or before** [from].
  ///
  /// Used as the default "scan date" for the Golden Cross screener so a Sunday
  /// refresh looks at Friday's candles instead of failing.
  static DateTime latestTradingDay({DateTime? from}) {
    var cursor = _dateOnly(from ?? nowIst());
    // Bounded loop: the longest holiday cluster in India is < 10 days.
    for (var i = 0; i < 30; i++) {
      if (isTradingDay(cursor)) return cursor;
      cursor = cursor.subtract(const Duration(days: 1));
    }
    return cursor;
  }

  /// Wall-clock "now" in IST, independent of the phone's timezone.
  static DateTime nowIst() {
    final utc = DateTime.now().toUtc();
    return utc.add(const Duration(hours: 5, minutes: 30));
  }

  /// The IST wall-clock as a *naive* DateTime (we never re-convert this).
  static DateTime istFromUtc(DateTime utcTime) =>
      utcTime.toUtc().add(const Duration(hours: 5, minutes: 30));

  /// `true` between 09:15 and 15:30 IST on a trading day.
  static bool isMarketOpen({DateTime? at}) {
    final now = at ?? nowIst();
    if (!isTradingDay(now)) return false;
    final minutes = now.hour * 60 + now.minute;
    return minutes >= MarketSession.openHour * 60 + MarketSession.openMinute &&
        minutes <= MarketSession.closeHour * 60 + MarketSession.closeMinute;
  }

  /// `true` after 18:00 IST on a trading day — the window in which the daily
  /// Golden Cross scan is allowed to run.
  static bool isDailyJobWindow({DateTime? at}) {
    final now = at ?? nowIst();
    if (!isTradingDay(now)) return false;
    return now.hour >= MarketSession.jobHour;
  }

  /// Short human label used across the UI, e.g. `Mon 29 Sep 2025 15:30 IST`.
  static String describeNow({DateTime? at}) {
    final now = at ?? nowIst();
    return '${DateFormat('EEE dd MMM yyyy HH:mm').format(now)} IST';
  }

  static DateTime _dateOnly(DateTime d) => DateTime(d.year, d.month, d.day);
}

/// Number of candles the Golden Cross maths needs.
class CandleRequirement {
  /// 200-day SMA needs the current bar plus 199 previous bars.
  static const int barsForSma200 = 200;

  /// Extra head-room requested from the broker so that a long holiday gap,
  /// a stock that was suspended for a while or a freshly listed stock still
  /// yields a complete 200-bar series when one exists.
  static const int lookbackCalendarDays = 400;

  /// Minimum bars below which we refuse to compute a 200 SMA (rather than
  /// producing a misleading value from a short history).
  static const int minimumBars = 205;
}
