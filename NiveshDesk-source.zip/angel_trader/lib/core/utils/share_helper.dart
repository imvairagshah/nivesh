// ---------------------------------------------------------------------------
// share_helper.dart — desktop-aware sharing (1.5.72).
//
// Mobile par share sheet (WhatsApp etc.) — wahi purana behaviour. Desktop
// (Windows/Linux) par share sheet hota hi nahi, to file seedha **Downloads**
// folder me save hoti hai aur path lautata hai. Kabhi koi share fail hone par
// app crash nahi hoti — hamesha ek honest message.
// ---------------------------------------------------------------------------

import 'dart:io';
import 'dart:typed_data';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

typedef ShareOutcome = ({bool ok, String message});

class ShareHelper {
  ShareHelper._();

  static bool get isDesktopNoShareSheet =>
      !Platform.isAndroid && !Platform.isIOS && !Platform.isMacOS;

  /// Desktop: text ko .txt bana ke Downloads me; mobile: share sheet.
  static Future<ShareOutcome> shareText(String text, {String subject = 'NiveshDesk'}) async {
    if (isDesktopNoShareSheet) {
      return _saveBytes(
        Uint8List.fromList(text.codeUnits),
        '${_slug(subject)}.txt',
      );
    }
    try {
      final result = await SharePlus.instance.share(ShareParams(text: text));
      return (
        ok: result.status != ShareResultStatus.unavailable,
        message: result.status == ShareResultStatus.unavailable
            ? 'Share sheet available nahi — file save karke dete hain.'
            : 'Share sheet khul gaya.',
      );
    } catch (e) {
      return (ok: false, message: 'Share fail: $e');
    }
  }

  /// Desktop: file copy → Downloads; mobile: share sheet.
  static Future<ShareOutcome> shareFile(File file, String subject) async {
    if (isDesktopNoShareSheet) {
      try {
        final bytes = await file.readAsBytes();
        return await _saveBytes(bytes, p.basename(file.path));
      } catch (e) {
        return (ok: false, message: 'File save fail: $e');
      }
    }
    try {
      final result = await SharePlus.instance.share(
        ShareParams(files: [XFile(file.path)], subject: subject),
      );
      return (
        ok: result.status != ShareResultStatus.unavailable,
        message: result.status == ShareResultStatus.unavailable
            ? 'Share sheet available nahi — file ${file.path} me padi hai.'
            : 'Share sheet khul gaya.',
      );
    } catch (e) {
      return (ok: false, message: 'Share fail: $e');
    }
  }

  static Future<ShareOutcome> _saveBytes(Uint8List bytes, String name) async {
    try {
      Directory dir;
      try {
        dir = await getDownloadsDirectory() ??
            await getApplicationDocumentsDirectory();
      } catch (_) {
        dir = Directory(p.join(Directory.systemTemp.path, 'NiveshDesk-exports'));
      }
      await dir.create(recursive: true);
      final stamp = DateTime.now()
          .toIso8601String()
          .replaceAll(':', '-')
          .split('.')
          .first;
      final file = File(p.join(dir.path, '${_stampName(name, stamp)}'));
      await file.writeAsBytes(bytes, flush: true);
      return (ok: true, message: 'Save ho gaya: ${file.path}');
    } catch (e) {
      return (ok: false, message: 'Save fail: $e');
    }
  }

  static String _stampName(String name, String stamp) {
    final dot = name.lastIndexOf('.');
    if (dot <= 0) return '${name}_$stamp';
    return '${name.substring(0, dot)}_$stamp${name.substring(dot)}';
  }

  static String _slug(String s) =>
      s.replaceAll(RegExp(r'[^A-Za-z0-9 _-]'), '').trim().replaceAll(' ', '_');
}

/// Wakelock (screen-on) — desktop par koi implementation nahi, call chup-chaap
/// ignore hoti hai. Mobile par waisa hi jaisa pehle tha.
Future<void> setWakelock(Future<void> Function() fn) async {
  try {
    await fn();
  } catch (_) {
    // Desktop/web: not supported — perfectly fine.
  }
}
