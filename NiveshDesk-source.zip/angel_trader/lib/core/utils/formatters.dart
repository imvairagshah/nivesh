// ---------------------------------------------------------------------------
// formatters.dart — ₹ / % / date formatting helpers shared by every screen.
// ---------------------------------------------------------------------------

import 'package:intl/intl.dart';

class Fmt {
  Fmt._();

  static final NumberFormat _inr = NumberFormat.currency(
    locale: 'en_IN',
    symbol: '₹',
    decimalDigits: 2,
  );

  static final NumberFormat _inrCompact = NumberFormat.compactCurrency(
    locale: 'en_IN',
    symbol: '₹',
    decimalDigits: 2,
  );

  static final NumberFormat _plain = NumberFormat('#,##0.00', 'en_IN');

  /// `₹1,00,000.00` — Indian digit grouping, used for money in cards/tables.
  static String money(num? value) =>
      value == null ? '—' : _inr.format(value.toDouble());

  /// `₹1.05L` / `₹12.4Cr` — for dense dashboard tiles.
  static String moneyCompact(num? value) =>
      value == null ? '—' : _inrCompact.format(value.toDouble());

  /// `₹1,234.50` without the currency symbol (column alignment in tables).
  static String number(num? value) =>
      value == null ? '—' : _plain.format(value.toDouble());

  /// Price with 2 decimals, e.g. `1,245.60`.
  static String price(num? value, {int decimals = 2}) {
    if (value == null) return '—';
    return NumberFormat('#,##0.${'0' * decimals}', 'en_IN')
        .format(value.toDouble());
  }

  /// `+12.35%` / `-4.10%`.
  static String signedPct(num? value, {int decimals = 2}) {
    if (value == null) return '—';
    final v = value.toDouble();
    final sign = v > 0 ? '+' : '';
    return '$sign${v.toStringAsFixed(decimals)}%';
  }

  /// `12.35%` (no sign) — used for "distance from listing high" text.
  static String pct(num? value, {int decimals = 2}) =>
      value == null ? '—' : '${value.toDouble().toStringAsFixed(decimals)}%';

  /// `+₹4,820.50` / `-₹2,110.00`.
  static String signedMoney(num? value) {
    if (value == null) return '—';
    final v = value.toDouble();
    final sign = v > 0 ? '+' : '';
    return '$sign${_inr.format(v)}';
  }

  /// Quantity as an integer with grouping (`1,200`).
  static String qty(num? value) =>
      value == null ? '—' : NumberFormat('#,##0', 'en_IN').format(value);

  static final DateFormat _dmy = DateFormat('dd MMM yyyy');
  static final DateFormat _dmyShort = DateFormat('dd MMM yy');
  static final DateFormat _iso = DateFormat('yyyy-MM-dd');
  static final DateFormat _dt = DateFormat('dd MMM yyyy, HH:mm');
  static final DateFormat _monthKey = DateFormat('MMM yyyy');
  static final DateFormat _hm = DateFormat('HH:mm:ss');

  /// `29 Sep 2025`.
  static String date(DateTime? d) => d == null ? '—' : _dmy.format(d);

  /// `29 Sep 25` (tight card chips).
  static String dateShort(DateTime? d) => d == null ? '—' : _dmyShort.format(d);

  /// `2025-09-29` (SQLite / CSV / SmartAPI wire format for dates).
  static String isoDate(DateTime? d) => d == null ? '—' : _iso.format(d);

  /// `29 Sep 2025, 15:30`.
  static String dateTime(DateTime? d) => d == null ? '—' : _dt.format(d);

  /// `Sep 2025` — monthly P&L buckets.
  static String monthLabel(DateTime d) => _monthKey.format(d);

  /// `15:42:07` — "last tick received" clock in the live dashboard.
  static String clock(DateTime? d) => d == null ? '—' : _hm.format(d);

  /// Relative freshness label: `live`, `2m ago`, `3h ago`, `4d ago`.
  static String relative(DateTime? when, {DateTime? now}) {
    if (when == null) return 'never';
    final ref = now ?? DateTime.now();
    final diff = ref.difference(when);
    if (diff.inSeconds < 45) return 'just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }

  /// Parses the date formats SmartAPI + our CSV use.
  /// Accepts `yyyy-MM-dd`, `dd-MMM-yyyy`, `dd/MM/yyyy`, ISO-8601 and
  /// (optionally) `yyyy-MM-ddTHH:mm:ss` timestamps from candle payloads.
  static DateTime? parseDate(String? raw) {
    if (raw == null) return null;
    final s = raw.trim();
    if (s.isEmpty) return null;

    // SmartAPI candle timestamps can look like "2025-09-29T00:00:00+05:30".
    final iso = DateTime.tryParse(s);
    if (iso != null) return iso;

    for (final pattern in const ['dd-MMM-yyyy', 'dd MMM yyyy', 'dd/MM/yyyy', 'MM/dd/yyyy']) {
      try {
        return DateFormat(pattern).parseStrict(s);
      } catch (_) {
        // try the next pattern
      }
    }
    return null;
  }

  /// `1.05x` for a gain factor (used on the "Best/Worst" tiles).
  static String factor(num? value) =>
      value == null ? '—' : '${value.toDouble().toStringAsFixed(2)}x';
}
