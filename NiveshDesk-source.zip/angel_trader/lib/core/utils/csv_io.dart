// ---------------------------------------------------------------------------
// csv_io.dart — small RFC-4180 CSV reader/writer.
//
// Hand-rolled (≈70 lines) instead of a dependency so the exact same code path is
// used for the bundled seed file, for user imports and for exported trade books.
// Handles: quoted fields, embedded commas / quotes / newlines, CRLF, UTF-8 BOM.
// ---------------------------------------------------------------------------

class CsvCodec {
  CsvCodec._();

  /// Parses [input] into a list of rows (list of cells). Fully empty rows are
  /// dropped.
  static List<List<String>> parse(String input) {
    var text = input;
    if (text.startsWith('\uFEFF')) text = text.substring(1); // strip BOM

    final rows = <List<String>>[];
    var row = <String>[];
    final field = StringBuffer();
    var inQuotes = false;
    var i = 0;

    while (i < text.length) {
      final ch = text[i];

      if (inQuotes) {
        if (ch == '"') {
          if (i + 1 < text.length && text[i + 1] == '"') {
            field.write('"'); // escaped quote
            i += 2;
            continue;
          }
          inQuotes = false;
          i++;
          continue;
        }
        field.write(ch);
        i++;
        continue;
      }

      if (ch == '"') {
        inQuotes = true;
        i++;
        continue;
      }
      if (ch == ',') {
        row.add(field.toString());
        field.clear();
        i++;
        continue;
      }
      if (ch == '\r') {
        i++; // swallow, `\n` ends the row
        continue;
      }
      if (ch == '\n') {
        row.add(field.toString());
        field.clear();
        rows.add(row);
        row = <String>[];
        i++;
        continue;
      }
      field.write(ch);
      i++;
    }

    // Flush the trailing field/row (file not ending in a newline).
    if (field.isNotEmpty || row.isNotEmpty) {
      row.add(field.toString());
      rows.add(row);
    }

    return rows
        .where((r) => r.any((c) => c.trim().isNotEmpty))
        .toList(growable: false);
  }

  /// Parses [input] into header-keyed records. Column names are matched
  /// case-insensitively and with underscores/spaces removed, so
  /// `Listing Date`, `listing_date` and `LISTINGDATE` all work.
  static List<Map<String, String>> parseRecords(String input) {
    final rows = parse(input);
    if (rows.isEmpty) return const [];

    final header = rows.first
        .map((h) => h.trim().toLowerCase().replaceAll(RegExp(r'[\s_\-]'), ''))
        .toList(growable: false);

    final records = <Map<String, String>>[];
    for (final row in rows.skip(1)) {
      final map = <String, String>{};
      for (var c = 0; c < header.length; c++) {
        map[header[c]] = c < row.length ? row[c].trim() : '';
      }
      records.add(map);
    }
    return records;
  }

  /// Encodes [rows] back into CSV text (CRLF line endings, quotes when needed).
  static String encode(List<List<String>> rows) {
    final buffer = StringBuffer();
    for (final row in rows) {
      buffer.write(row.map(escape).join(','));
      buffer.write('\r\n');
    }
    return buffer.toString();
  }

  /// Quotes a single cell when it contains a delimiter, quote or newline.
  static String escape(String value) {
    final needsQuotes = value.contains(',') ||
        value.contains('"') ||
        value.contains('\n') ||
        value.contains('\r');
    if (!needsQuotes) return value;
    return '"${value.replaceAll('"', '""')}"';
  }
}
