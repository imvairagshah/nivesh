// ---------------------------------------------------------------------------
// totp.dart — self-contained TOTP (RFC 6238) generator for Angel One 2FA.
//
// Why hand-rolled instead of a package?
//   * `otp` / `totp` packages pull in extra platform plugin surface; the app is
//     100% client-side, so fewer plugins = fewer build failures.
//   * `crypto` (already a dependency for nothing else) exposes Hmac(sha1, key).
//
// Verified against the RFC 6238 Appendix-B test vectors in
// test/totp_test.dart (T = 59 -> 94287082 for the 8-digit SHA-1 variant).
//
// Angel One expects a **6-digit** code every 30 seconds, from the base32 secret
// shown when you enable TOTP in the Angel One app / SmartAPI dashboard.
// ---------------------------------------------------------------------------

import 'dart:typed_data';

import 'package:crypto/crypto.dart';

class Totp {
  Totp._();

  /// Defaults match Angel One's SmartAPI TOTP enrolment.
  static const int digits = 6;
  static const int periodSeconds = 30;
  static const int _algorithm = 0; // 0 = SHA-1 (only variant SmartAPI accepts)

  /// Generates the current 6-digit TOTP for [base32Secret].
  ///
  /// [at] is injectable so unit tests can pin the clock.
  /// Throws [FormatException] when the secret is not valid base32.
  static String generate(String base32Secret, {DateTime? at}) {
    final key = decodeBase32(base32Secret);
    if (key.isEmpty) {
      throw const FormatException('TOTP secret is empty after base32 decoding.');
    }
    final seconds = (at ?? DateTime.now()).toUtc().millisecondsSinceEpoch ~/ 1000;
    return _hotp(key, seconds ~/ periodSeconds, digits);
  }

  /// Seconds remaining before the current code rolls over (shown as a countdown
  /// in the login screen so the user does not submit a stale code).
  static int secondsRemaining({DateTime? at}) {
    final seconds = (at ?? DateTime.now()).toUtc().millisecondsSinceEpoch ~/ 1000;
    return periodSeconds - (seconds % periodSeconds);
  }

  /// `true` when the code is about to expire and a fresh one should be read.
  static bool isExpiringSoon({DateTime? at, int threshold = 5}) =>
      secondsRemaining(at: at) <= threshold;

  // -------------------------------------------------------------------------
  // Internals
  // -------------------------------------------------------------------------

  /// RFC 4226 HMAC-based one-time password. Exposed (not private) because the
  /// RFC test vectors live in this file's test suite.
  static String _hotp(Uint8List key, int counter, int digits) {
    // 8-byte big-endian counter
    final counterBytes = Uint8List(8);
    final bd = ByteData.view(counterBytes.buffer);
    bd.setUint64(0, counter, Endian.big);

    if (_algorithm != 0) {
      throw UnsupportedError('Only HMAC-SHA1 TOTP is supported by SmartAPI.');
    }
    final digest = Hmac(sha1, key).convert(counterBytes).bytes;

    // Dynamic truncation (RFC 4226 §5.4)
    final offset = digest[digest.length - 1] & 0x0f;
    final binary = ((digest[offset] & 0x7f) << 24) |
        ((digest[offset + 1] & 0xff) << 16) |
        ((digest[offset + 2] & 0xff) << 8) |
        (digest[offset + 3] & 0xff);

    final otp = binary % _pow10(digits);
    return otp.toString().padLeft(digits, '0');
  }

  static int _pow10(int exp) {
    var result = 1;
    for (var i = 0; i < exp; i++) {
      result *= 10;
    }
    return result;
  }

  /// Base32 (RFC 4648, no padding required) decoder — the format Angel One
  /// displays for the TOTP secret.
  ///
  /// Tolerates lowercase, spaces, dashes and `=` padding.
  static Uint8List decodeBase32(String input) {
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    final cleaned = input
        .toUpperCase()
        .replaceAll(RegExp(r'[\s\-=]'), '')
        .replaceAll(RegExp(r'[^A-Z2-7]'), '');
    if (cleaned.isEmpty) return Uint8List(0);

    final out = <int>[];
    var buffer = 0;
    var bitsLeft = 0;

    for (final ch in cleaned.codeUnits) {
      final value = alphabet.indexOf(String.fromCharCode(ch));
      if (value < 0) {
        throw FormatException('Invalid base32 character "${String.fromCharCode(ch)}".');
      }
      buffer = (buffer << 5) | value;
      bitsLeft += 5;
      if (bitsLeft >= 8) {
        bitsLeft -= 8;
        out.add((buffer >> bitsLeft) & 0xff);
      }
    }
    return Uint8List.fromList(out);
  }

  /// Lightweight sanity check used by the settings screen before saving.
  static bool isValidSecret(String base32Secret) {
    try {
      return decodeBase32(base32Secret).length >= 10; // >=80 bits
    } catch (_) {
      return false;
    }
  }
}
