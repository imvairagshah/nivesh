// ---------------------------------------------------------------------------
// app_theme.dart — the design system.
//
// Everything visual is decided here so no screen has to invent a colour, a
// radius or a duration:
//
//   * colours    — brand green + gold, tuned Material 3 schemes for both
//                  brightnesses, plus [MarketColors] for P&L semantics
//   * spacing    — [AppSpacing], [AppRadius] tokens
//   * type       — a tuned [TextTheme] (tighter tracking on headings, Indian
//                  money is rendered by Fmt, not here)
//   * motion     — [AppMotion] durations/curves; the widgets live in
//                  lib/core/widgets/motion.dart and only read these
//   * components — app bar, cards, inputs, buttons, chips, nav bar, sheets,
//                  dialogs, snackbars … styled once, consistently
//
// NOTE ON FLUTTER VERSIONS
// Flutter normalised several component themes: `CardTheme` → `CardThemeData`
// (3.27), `AppBarTheme` → `AppBarThemeData` and `InputDecorationTheme` →
// `InputDecorationThemeData` (3.35). The names below target Flutter 3.35+.
// ---------------------------------------------------------------------------

import 'package:flutter/cupertino.dart' show CupertinoPageTransitionsBuilder;
import 'package:flutter/material.dart';

// ---------------------------------------------------------------------------
// Brand
// ---------------------------------------------------------------------------

/// The brand — "NiveshDesk": निवेश (investment) + desk. Chosen to avoid any
/// implied affiliation with Angel One, whose API this app merely reads.
class Brand {
  Brand._();

  /// Product name, as shown in the app bar, the launcher and the About card.
  static const String name = 'NiveshDesk';

  /// Two-tone wordmark halves (see [BrandLogo]).
  static const String namePrefix = 'Nivesh';
  static const String nameSuffix = 'Desk';

  /// Short promise used on the splash + login screens.
  static const String tagline = 'SCREENER · TRENDS · PAPER TRADING';

  /// Slightly longer, plain-language description.
  static const String blurb =
      'Screen new listings, catch Golden / Death crosses, and practise trades '
      'with realistic charges — all on your phone, no real orders.';

  /// Deep market green — the primary seed.
  static const Color green = Color(0xFF0B6B4F);
  static const Color greenBright = Color(0xFF12A67C);
  static const Color greenDeep = Color(0xFF074434);

  /// Warm gold, reserved for accents (the brand mark's trend line, highlights).
  static const Color gold = Color(0xFFE8B242);
  static const Color goldDeep = Color(0xFFB9822A);

  /// Gradient used by hero surfaces (dashboard card, splash mark plate).
  static LinearGradient heroGradient({bool dark = false}) => LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: dark
            ? const [Color(0xFF0A5C45), Color(0xFF0B6B4F), Color(0xFF084C3A)]
            : const [Color(0xFF0B6B4F), Color(0xFF12876A), Color(0xFF0A5C45)],
      );

  /// A faint gold wash laid over a hero surface for depth.
  static LinearGradient goldGlow() => LinearGradient(
        begin: Alignment.topRight,
        end: Alignment.bottomLeft,
        colors: [
          gold.withOpacity(0.30),
          gold.withOpacity(0.02),
        ],
      );
}

// ---------------------------------------------------------------------------
// Tokens
// ---------------------------------------------------------------------------

/// Spacing scale (multiples of 4).
class AppSpacing {
  AppSpacing._();
  static const double xxs = 2;
  static const double xs = 4;
  static const double sm = 8;
  static const double md = 12;
  static const double lg = 16;
  static const double xl = 24;
  static const double xxl = 32;
}

/// Corner radii.
class AppRadius {
  AppRadius._();
  static const double sm = 10;
  static const double md = 14;
  static const double lg = 18;
  static const double xl = 24;
  static const double pill = 999;
}

/// Motion: one place to keep animations feeling like the same product.
///
/// Everything is deliberately quick — "lite", not showy: 150–420 ms, gentle
/// easing, and no looping animation anywhere near a data card (the only looping
/// effects are the live pulse and loading shimmer, which are *information*).
class AppMotion {
  AppMotion._();

  static const Duration fast = Duration(milliseconds: 150);
  static const Duration base = Duration(milliseconds: 260);
  static const Duration slow = Duration(milliseconds: 420);

  /// Delay between successive list items in a staggered entrance.
  static const Duration stagger = Duration(milliseconds: 45);

  /// Longest stagger delay, so a long list never feels sluggish at the bottom.
  static const int maxStaggerIndex = 8;

  static const Curve enter = Curves.easeOutCubic;
  static const Curve exit = Curves.easeInCubic;
  static const Curve emphasized = Cubic(0.2, 0, 0, 1);

  /// Entrance slide distance for [FadeSlideIn].
  static const double slideY = 14;
}

// ---------------------------------------------------------------------------
// Market colours
// ---------------------------------------------------------------------------

/// Market-specific colours that have to work in both brightnesses.
///
/// Exposed as a [ThemeExtension] so widgets can simply call
/// `MarketColors.of(context).loss` and get the right shade in dark mode too.
@immutable
class MarketColors extends ThemeExtension<MarketColors> {
  final Color gain;
  final Color loss;
  final Color flat;

  /// "Near listing high" chip (spec: closest to the top of the listing range).
  final Color nearHigh;

  /// "Near listing low" chip.
  final Color nearLow;

  /// Warning tint for cached / stale prices.
  final Color stale;

  const MarketColors({
    required this.gain,
    required this.loss,
    required this.flat,
    required this.nearHigh,
    required this.nearLow,
    required this.stale,
  });

  static const MarketColors light = MarketColors(
    gain: Color(0xFF15803D),
    loss: Color(0xFFB91C1C),
    flat: Color(0xFF475569),
    nearHigh: Color(0xFF0E7490),
    nearLow: Color(0xFF7C3AED),
    stale: Color(0xFFB45309),
  );

  static const MarketColors dark = MarketColors(
    gain: Color(0xFF4ADE80),
    loss: Color(0xFFF87171),
    flat: Color(0xFF94A3B8),
    nearHigh: Color(0xFF67E8F9),
    nearLow: Color(0xFFC4B5FD),
    stale: Color(0xFFFBBF24),
  );

  static MarketColors of(BuildContext context) =>
      Theme.of(context).extension<MarketColors>() ?? light;

  /// Convenience: colour for a signed number.
  Color forValue(num? value) {
    if (value == null || value == 0) return flat;
    return value > 0 ? gain : loss;
  }

  @override
  MarketColors copyWith({
    Color? gain,
    Color? loss,
    Color? flat,
    Color? nearHigh,
    Color? nearLow,
    Color? stale,
  }) =>
      MarketColors(
        gain: gain ?? this.gain,
        loss: loss ?? this.loss,
        flat: flat ?? this.flat,
        nearHigh: nearHigh ?? this.nearHigh,
        nearLow: nearLow ?? this.nearLow,
        stale: stale ?? this.stale,
      );

  @override
  MarketColors lerp(ThemeExtension<MarketColors>? other, double t) {
    if (other is! MarketColors) return this;
    return MarketColors(
      gain: Color.lerp(gain, other.gain, t)!,
      loss: Color.lerp(loss, other.loss, t)!,
      flat: Color.lerp(flat, other.flat, t)!,
      nearHigh: Color.lerp(nearHigh, other.nearHigh, t)!,
      nearLow: Color.lerp(nearLow, other.nearLow, t)!,
      stale: Color.lerp(stale, other.stale, t)!,
    );
  }
}

/// Colours for the eight trade-group tags (Feature 3).
///
/// Kept separate from [MarketColors] because a group colour is an *identity*,
/// not a signal: it must stay the same in light and dark mode and must never be
/// mistaken for a P&L colour. `TradeGroup.colorIndex` indexes this list
/// (modulo its length), which is why it lives next to the theme.
class GroupPalette {
  GroupPalette._();

  static const List<Color> colors = [
    Color(0xFF2563EB), // blue
    Color(0xFF7C3AED), // violet
    Color(0xFF0E7490), // teal
    Color(0xFFB45309), // amber
    Color(0xFFBE185D), // pink
    Color(0xFF15803D), // green
    Color(0xFF4338CA), // indigo
    Color(0xFF6D28D9), // purple
  ];

  /// Colour for a group's `colorIndex` (never throws, wraps the palette).
  static Color colorAt(int index) => colors[index.abs() % colors.length];

  /// A soft background version for chips.
  static Color tintAt(int index, Brightness brightness) =>
      colorAt(index).withOpacity(brightness == Brightness.dark ? 0.26 : 0.14);
}

// ---------------------------------------------------------------------------
// Themes
// ---------------------------------------------------------------------------

class AppTheme {
  AppTheme._();

  /// Brand seed — a deep market green that reads well on both backgrounds.
  static const Color seed = Brand.green;

  /// Soft, wide shadow used by hero surfaces and floating cards. Deliberately
  /// low-alpha so it reads as depth, not as a drop shadow.
  static List<BoxShadow> softShadow(Brightness brightness, {double y = 8}) => [
        BoxShadow(
          color: Colors.black.withOpacity(brightness == Brightness.dark ? 0.30 : 0.06),
          blurRadius: 22,
          offset: Offset(0, y),
        ),
      ];

  static ThemeData light() => _base(Brightness.light, MarketColors.light);
  static ThemeData dark() => _base(Brightness.dark, MarketColors.dark);

  static ThemeData _base(Brightness brightness, MarketColors market) {
    final isLight = brightness == Brightness.light;

    // Start from the seed, then pin the few roles that must be exact brand
    // values rather than tonal derivations.
    final scheme = ColorScheme.fromSeed(
      seedColor: seed,
      brightness: brightness,
    ).copyWith(
      primary: isLight ? Brand.green : Brand.greenBright,
      onPrimary: isLight ? Colors.white : const Color(0xFF00301F),
      primaryContainer:
          isLight ? const Color(0xFFC9EBDD) : const Color(0xFF0C4B39),
      onPrimaryContainer:
          isLight ? const Color(0xFF04291D) : const Color(0xFFC9EBDD),
      secondary: isLight ? Brand.goldDeep : Brand.gold,
      surface: isLight ? Colors.white : const Color(0xFF101A17),
      surfaceContainerLowest: isLight ? const Color(0xFFFFFFFF) : const Color(0xFF0B1210),
      surfaceContainerLow: isLight ? const Color(0xFFF7F9F8) : const Color(0xFF131F1B),
      surfaceContainer: isLight ? const Color(0xFFF1F3F2) : const Color(0xFF16241F),
      surfaceContainerHigh: isLight ? const Color(0xFFEAEEEC) : const Color(0xFF1B2B25),
      surfaceContainerHighest:
          isLight ? const Color(0xFFE3E8E6) : const Color(0xFF20332C),
    );

    final text = _textTheme(scheme);

    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: scheme,
      extensions: [market],
      textTheme: text,
      scaffoldBackgroundColor:
          isLight ? const Color(0xFFF5F7F6) : const Color(0xFF0A1210),
      canvasColor: isLight ? const Color(0xFFF5F7F6) : const Color(0xFF0A1210),
      visualDensity: VisualDensity.standard,
      splashFactory: InkRipple.splashFactory,

      // Page changes cross-fade + slide instead of the default zoom — reads
      // calmer on a data app.
      pageTransitionsTheme: const PageTransitionsTheme(
        builders: {
          // Material 3's fade-through: the outgoing page fades while the new
          // one slides in a few pixels. Calmer than the platform zoom for an
          // app that pushes detail screens a lot.
          TargetPlatform.android: FadeForwardsPageTransitionsBuilder(),
          TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
          TargetPlatform.macOS: CupertinoPageTransitionsBuilder(),
        },
      ),

      appBarTheme: AppBarThemeData(
        centerTitle: false,
        elevation: 0,
        scrolledUnderElevation: 0,
        backgroundColor: isLight ? const Color(0xFFF5F7F6) : const Color(0xFF0A1210),
        surfaceTintColor: Colors.transparent,
        foregroundColor: scheme.onSurface,
        titleSpacing: 8,
        titleTextStyle: text.titleLarge?.copyWith(fontSize: 19),
      ),

      cardTheme: CardThemeData(
        elevation: 0,
        margin: EdgeInsets.zero,
        clipBehavior: Clip.antiAlias,
        color: isLight ? Colors.white : const Color(0xFF131F1B),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.lg),
          side: BorderSide(
            color: scheme.outlineVariant.withOpacity(isLight ? 0.55 : 0.30),
          ),
        ),
      ),

      listTileTheme: ListTileThemeData(
        dense: true,
        iconColor: scheme.onSurfaceVariant,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.md),
        ),
        titleTextStyle: text.bodyLarge?.copyWith(fontWeight: FontWeight.w600),
        subtitleTextStyle: text.bodySmall?.copyWith(
          color: scheme.onSurfaceVariant,
        ),
      ),

      inputDecorationTheme: InputDecorationThemeData(
        filled: true,
        fillColor: scheme.surfaceContainerHighest.withOpacity(isLight ? 0.55 : 0.45),
        isDense: true,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
        hintStyle: text.bodyMedium?.copyWith(
          color: scheme.onSurfaceVariant.withOpacity(0.7),
        ),
        labelStyle: text.bodyMedium?.copyWith(color: scheme.onSurfaceVariant),
        helperStyle: text.labelSmall?.copyWith(
          color: scheme.onSurfaceVariant,
          fontWeight: FontWeight.w500,
        ),
        prefixIconColor: scheme.onSurfaceVariant,
        suffixIconColor: scheme.onSurfaceVariant,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadius.md),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadius.md),
          borderSide: BorderSide(
            color: scheme.outlineVariant.withOpacity(isLight ? 0.7 : 0.35),
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadius.md),
          borderSide: BorderSide(color: scheme.primary, width: 1.6),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadius.md),
          borderSide: BorderSide(color: scheme.error, width: 1.2),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadius.md),
          borderSide: BorderSide(color: scheme.error, width: 1.6),
        ),
      ),

      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size(0, 46),
          padding: const EdgeInsets.symmetric(horizontal: 20),
          textStyle: text.labelLarge,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppRadius.md),
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size(0, 44),
          padding: const EdgeInsets.symmetric(horizontal: 16),
          textStyle: text.labelLarge,
          side: BorderSide(color: scheme.outlineVariant),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppRadius.md),
          ),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(textStyle: text.labelLarge),
      ),
      segmentedButtonTheme: SegmentedButtonThemeData(
        style: ButtonStyle(
          textStyle: WidgetStatePropertyAll(text.labelLarge),
          visualDensity: VisualDensity.compact,
          side: WidgetStatePropertyAll(
            BorderSide(color: scheme.outlineVariant.withOpacity(0.8)),
          ),
          shape: WidgetStatePropertyAll(
            RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(AppRadius.md),
            ),
          ),
        ),
      ),

      chipTheme: ChipThemeData(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.pill),
        ),
        side: BorderSide(color: scheme.outlineVariant.withOpacity(0.7)),
        labelStyle: text.labelMedium,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      ),

      iconTheme: IconThemeData(color: scheme.onSurfaceVariant, size: 20),

      dividerTheme: DividerThemeData(
        color: scheme.outlineVariant.withOpacity(0.6),
        space: 1,
        thickness: 1,
      ),

      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        showCloseIcon: true,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.md),
        ),
        contentTextStyle: text.bodyMedium?.copyWith(color: scheme.onInverseSurface),
      ),

      dialogTheme: DialogThemeData(
        elevation: 0,
        backgroundColor: scheme.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.xl),
        ),
        titleTextStyle: text.titleLarge,
        contentTextStyle: text.bodyMedium?.copyWith(
          color: scheme.onSurfaceVariant,
        ),
      ),

      bottomSheetTheme: BottomSheetThemeData(
        showDragHandle: true,
        elevation: 0,
        backgroundColor: scheme.surface,
        surfaceTintColor: Colors.transparent,
        dragHandleColor: scheme.outlineVariant,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            top: Radius.circular(AppRadius.xl),
          ),
        ),
      ),

      popupMenuTheme: PopupMenuThemeData(
        elevation: 3,
        color: scheme.surfaceContainerLow,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.md),
        ),
        textStyle: text.bodyMedium,
      ),

      navigationBarTheme: NavigationBarThemeData(
        height: 68,
        elevation: 0,
        backgroundColor: isLight ? Colors.white : const Color(0xFF101A17),
        surfaceTintColor: Colors.transparent,
        indicatorColor: scheme.primaryContainer,
        indicatorShape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.md),
        ),
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
        labelTextStyle: WidgetStateProperty.resolveWith(
          (states) => states.contains(WidgetState.selected)
              ? text.labelSmall?.copyWith(
                  color: scheme.primary,
                  fontWeight: FontWeight.w800,
                )
              : text.labelSmall?.copyWith(color: scheme.onSurfaceVariant),
        ),
        iconTheme: WidgetStateProperty.resolveWith(
          (states) => IconThemeData(
            size: 22,
            color: states.contains(WidgetState.selected)
                ? scheme.onPrimaryContainer
                : scheme.onSurfaceVariant,
          ),
        ),
      ),

      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: isLight ? Colors.white : const Color(0xFF101A17),
        elevation: 0,
      ),

      sliderTheme: SliderThemeData(
        activeTrackColor: scheme.primary,
        inactiveTrackColor: scheme.surfaceContainerHighest,
        thumbColor: scheme.primary,
        overlayShape: const RoundSliderOverlayShape(overlayRadius: 16),
      ),

      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith(
          (states) => states.contains(WidgetState.selected)
              ? Colors.white
              : scheme.outline,
        ),
        trackColor: WidgetStateProperty.resolveWith(
          (states) => states.contains(WidgetState.selected)
              ? scheme.primary
              : scheme.surfaceContainerHighest,
        ),
        trackOutlineColor: WidgetStatePropertyAll(
          scheme.outlineVariant.withOpacity(0.6),
        ),
      ),

      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: scheme.primary,
        linearTrackColor: scheme.surfaceContainerHighest,
        circularTrackColor: Colors.transparent,
      ),

      tooltipTheme: TooltipThemeData(
        decoration: BoxDecoration(
          color: scheme.inverseSurface,
          borderRadius: BorderRadius.circular(AppRadius.sm),
        ),
        textStyle: text.labelMedium?.copyWith(color: scheme.onInverseSurface),
      ),

      badgeTheme: BadgeThemeData(
        backgroundColor: scheme.primary,
        textColor: scheme.onPrimary,
        textStyle: text.labelSmall,
      ),
    );
  }

  /// A tight, editorial type scale. Headings get negative tracking (they read
  /// "designed" rather than default), body text stays at comfortable sizes for
  /// a phone, and labels are small caps-ish for metadata rows.
  static TextTheme _textTheme(ColorScheme scheme) => TextTheme(
        displaySmall: TextStyle(
          fontSize: 30,
          fontWeight: FontWeight.w800,
          letterSpacing: -0.8,
          color: scheme.onSurface,
        ),
        headlineMedium: TextStyle(
          fontSize: 24,
          fontWeight: FontWeight.w700,
          letterSpacing: -0.5,
          color: scheme.onSurface,
        ),
        headlineSmall: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.w700,
          letterSpacing: -0.3,
          color: scheme.onSurface,
        ),
        titleLarge: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w700,
          letterSpacing: -0.2,
          color: scheme.onSurface,
        ),
        titleMedium: TextStyle(
          fontSize: 15.5,
          fontWeight: FontWeight.w600,
          letterSpacing: -0.1,
          color: scheme.onSurface,
        ),
        titleSmall: TextStyle(
          fontSize: 13.5,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.1,
          color: scheme.onSurface,
        ),
        bodyLarge: TextStyle(
          fontSize: 14.5,
          height: 1.35,
          color: scheme.onSurface,
        ),
        bodyMedium: TextStyle(
          fontSize: 13.5,
          height: 1.35,
          color: scheme.onSurface,
        ),
        bodySmall: TextStyle(
          fontSize: 12,
          height: 1.35,
          color: scheme.onSurfaceVariant,
        ),
        labelLarge: TextStyle(
          fontSize: 13.5,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.1,
          color: scheme.onSurface,
        ),
        labelMedium: TextStyle(
          fontSize: 11.5,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.2,
          color: scheme.onSurface,
        ),
        labelSmall: TextStyle(
          fontSize: 10.5,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.4,
          color: scheme.onSurfaceVariant,
        ),
      );
}
