// ---------------------------------------------------------------------------
// desktop_layout.dart — 1.5.73 desktop design mode.
//
// Mobile (APK) hamesha compact layout use karta hai — wahan kuch nahi badla.
// Desktop (Windows/Linux) par window chaudi hoti hai, to layout khud wide
// ho jaata hai: sidebar navigation, multi-column grids, saans ka content.
//
//   UiMode.of(context)  → compact | medium | expanded
//   DesktopGrid.count() → Wrap/GridView ke liye column count
//   CenteredWidth       → forms/menus ko wide screen par beech me rakhta hai
// ---------------------------------------------------------------------------

import 'dart:io' show Platform;

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';

enum UiMode { compact, medium, expanded }

class DesktopLayout {
  DesktopLayout._();

  /// True on the desktop builds (Windows/Linux/macOS). Phones/tablets = false.
  /// Web par width hi decide karta hai (koi hard platform block nahi).
  static bool get isDesktopPlatform =>
      !kIsWeb && (Platform.isWindows || Platform.isLinux || Platform.isMacOS);

  static UiMode modeOf(BuildContext context) {
    final w = MediaQuery.sizeOf(context).width;
    if (w >= 1120) return UiMode.expanded;
    if (w >= 760) return UiMode.medium;
    return UiMode.compact;
  }

  /// Wide = desktop-style multi-column layout chahiye.
  static bool isWide(BuildContext context) =>
      modeOf(context) != UiMode.compact;

  /// Grid columns for a Wrap/GridView of cards at this width.
  /// [minTile] se chhota koi card nahi hota; [max] se zyada columns nahi.
  static int columns(
    BuildContext context, {
    double minTile = 340,
    int max = 4,
  }) {
    final w = MediaQuery.sizeOf(context).width;
    final n = (w / minTile).floor();
    return n < 1 ? 1 : (n > max ? max : n);
  }
}

/// Forms, menus, single-column content — wide screen par beech me, ek
/// comfortable width tak. Mobile par kuch nahi badalta.
class CenteredWidth extends StatelessWidget {
  const CenteredWidth({super.key, this.max = 720, required this.child});

  final double max;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: max),
        child: child,
      ),
    );
  }
}
