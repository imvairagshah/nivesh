// ---------------------------------------------------------------------------
// paper_trade.dart — the three records the paper-trading module persists.
//
//   PaperOrder  a *submitted* order. MARKET orders fill in the same instant, so
//               their row is written already FILLED; LIMIT orders whose price
//               has not been reached yet rest here as PENDING and are matched
//               against the live feed until they fill or are cancelled.
//   Trade       a *filled* leg — one buy or one sell. The account ledger is the
//               sum of these rows' cash flows, and the Reports tab is computed
//               from their `realizedPnl`. Closing legs (sells) carry a non-null
//               `realizedPnl`; opening legs (buys) carry null, which is how the
//               group P&L queries in TradeGroupDao tell the two apart.
//   Position    the net holding of one symbol. Long-only: a buy opens or adds
//               to it, a sell reduces it, quantity 0 closes it.
//
// Money always flows through `ChargeBreakdown` (see
// lib/features/paper_trading/charges.dart) so that realised P&L is *net* of
// brokerage/STT/GST — the number a real broker statement would show.
// ---------------------------------------------------------------------------

import '../../../core/utils/markets.dart';
import '../../remote/dto/scrip.dart' show Scrip;

/// Which way an order trades. The app is long-only, so BUY opens/adds to a
/// position and SELL reduces/closes one (no short selling).
enum OrderSide {
  buy('BUY', 'Buy'),
  sell('SELL', 'Sell');

  const OrderSide(this.code, this.label);

  /// Wire/storage value (`BUY` / `SELL`), matching the `trades.side` column.
  final String code;

  /// Title-case label for buttons and chips.
  final String label;

  OrderSide get opposite => this == OrderSide.buy ? OrderSide.sell : OrderSide.buy;

  static OrderSide fromName(String? name) => (name ?? '').toUpperCase() == 'SELL'
      ? OrderSide.sell
      : OrderSide.buy;
}

/// How the fill price is decided.
enum PaperOrderType {
  /// Fills immediately at the best available price (the live LTP).
  market('MARKET', 'Market'),

  /// Fills only when the market trades through the requested price.
  limit('LIMIT', 'Limit');

  const PaperOrderType(this.code, this.label);

  final String code;
  final String label;

  static PaperOrderType fromName(String? name) =>
      (name ?? '').toUpperCase() == 'LIMIT'
          ? PaperOrderType.limit
          : PaperOrderType.market;
}

/// Lifecycle of a [PaperOrder].
enum OrderStatus {
  /// Resting in the book, waiting for the limit price to trade.
  pending('PENDING', 'Pending'),
  filled('FILLED', 'Filled'),
  cancelled('CANCELLED', 'Cancelled'),

  /// Rejected on submission (bad symbol, no live price, insufficient cash …).
  /// Kept so the Orders tab can explain *why* nothing happened.
  rejected('REJECTED', 'Rejected');

  const OrderStatus(this.code, this.label);

  final String code;
  final String label;

  static OrderStatus fromName(String? name) => OrderStatus.values.firstWhere(
        (s) => s.code == (name ?? '').toUpperCase(),
        orElse: () => OrderStatus.rejected,
      );
}

/// Lifecycle of a [Position].
enum PositionStatus {
  open('OPEN', 'Open'),
  closed('CLOSED', 'Closed');

  const PositionStatus(this.code, this.label);

  final String code;
  final String label;

  static PositionStatus fromName(String? name) =>
      (name ?? '').toUpperCase() == 'CLOSED'
          ? PositionStatus.closed
          : PositionStatus.open;
}

/// Base shared by the trade/order/position records: a reference to one
/// instrument.
mixin InstrumentRef {
  String get symbol; // broker symbol, e.g. `SBIN-EQ` (NSE) or `SBIN` (BSE)
  Exchange get exchange;
  String get token;

  /// `SBIN-EQ` → `SBIN`, for display and TradingView links.
  String get displaySymbol => Scrip.plainSymbol(symbol);

  /// `NSE:SBIN` — the key used by the price cache and the feed router.
  String get priceKey => '${exchange.code}:$displaySymbol';

  /// TradingView chart for this instrument (same URL scheme as Features 1–2).
  String get chartUrl =>
      'https://in.tradingview.com/chart/?symbol=${exchange.code}:$displaySymbol';
}

// ---------------------------------------------------------------------------
// Trade — one filled leg
// ---------------------------------------------------------------------------

class Trade with InstrumentRef {
  final int? id;

  @override
  final String symbol;
  @override
  final Exchange exchange;
  @override
  final String token;

  final OrderSide side;
  final int quantity;

  /// Actual fill price (not the requested limit price).
  final double price;

  final PaperOrderType orderType;

  /// Position this leg belongs to (`null` for a rejected/unlinked record).
  final int? positionId;

  /// Strategy tag; `null` == Ungrouped.
  final int? groupId;

  /// Net P&L booked by this leg, **after all charges** — only set on closing
  /// (sell) legs. `realizedByGroup` / `monthlyByGroup` in TradeGroupDao rely on
  /// `NULL` meaning "opening leg".
  final double? realizedPnl;

  /// Charges for this leg alone (see [ChargeBreakdown.total]).
  final double charges;

  /// IST wall-clock time the fill was booked.
  final DateTime executedAt;

  final String note;

  const Trade({
    this.id,
    required this.symbol,
    required this.exchange,
    this.token = '',
    required this.side,
    required this.quantity,
    required this.price,
    this.orderType = PaperOrderType.market,
    this.positionId,
    this.groupId,
    this.realizedPnl,
    this.charges = 0,
    required this.executedAt,
    this.note = '',
  });

  /// Gross value of the leg (`price × quantity`), before charges.
  double get value => price * quantity;

  /// Signed cash flow: negative when buying (money leaves), positive when
  /// selling (money arrives). Excludes the opening leg's charge for the sake of
  /// the ledger — [cashFlowNet] is the one the account actually uses.
  double get cashFlow =>
      side == OrderSide.buy ? -(value + charges) : value - charges;

  /// Same as [cashFlow]; kept as an explicit name for readability in the
  /// portfolio maths.
  double get cashFlowNet => cashFlow;

  /// `true` when this leg closed (part of) a position.
  bool get isClosingLeg => realizedPnl != null;

  /// Net P&L for a closing leg, `null` for an opening leg.
  double? get netPnl => realizedPnl;

  factory Trade.fromDb(Map<String, Object?> row) => Trade(
        id: (row['id'] as num?)?.toInt(),
        symbol: '${row['symbol'] ?? ''}',
        exchange: Exchange.fromCode('${row['exchange'] ?? 'NSE'}'),
        token: '${row['token'] ?? ''}',
        side: OrderSide.fromName('${row['side']}'),
        quantity: (row['quantity'] as num?)?.toInt() ?? 0,
        price: (row['price'] as num?)?.toDouble() ?? 0,
        orderType: PaperOrderType.fromName('${row['order_type']}'),
        positionId: (row['position_id'] as num?)?.toInt(),
        groupId: (row['group_id'] as num?)?.toInt(),
        realizedPnl: (row['realized_pnl'] as num?)?.toDouble(),
        charges: (row['charges'] as num?)?.toDouble() ?? 0,
        executedAt: DateTime.fromMillisecondsSinceEpoch(
          (row['executed_at'] as num?)?.toInt() ?? 0,
        ),
        note: '${row['note'] ?? ''}',
      );

  Map<String, Object?> toDb() => {
        if (id != null) 'id': id,
        'symbol': symbol,
        'exchange': exchange.code,
        'token': token,
        'side': side.code,
        'quantity': quantity,
        'price': price,
        'order_type': orderType.code,
        'position_id': positionId,
        'group_id': groupId,
        'realized_pnl': realizedPnl,
        'charges': charges,
        'executed_at': executedAt.millisecondsSinceEpoch,
        'note': note,
      };

  Trade copyWith({
    int? id,
    String? symbol,
    Exchange? exchange,
    String? token,
    OrderSide? side,
    int? quantity,
    double? price,
    PaperOrderType? orderType,
    int? positionId,
    int? groupId,
    double? realizedPnl,
    double? charges,
    DateTime? executedAt,
    String? note,
  }) =>
      Trade(
        id: id ?? this.id,
        symbol: symbol ?? this.symbol,
        exchange: exchange ?? this.exchange,
        token: token ?? this.token,
        side: side ?? this.side,
        quantity: quantity ?? this.quantity,
        price: price ?? this.price,
        orderType: orderType ?? this.orderType,
        positionId: positionId ?? this.positionId,
        groupId: groupId ?? this.groupId,
        realizedPnl: realizedPnl ?? this.realizedPnl,
        charges: charges ?? this.charges,
        executedAt: executedAt ?? this.executedAt,
        note: note ?? this.note,
      );

  @override
  String toString() =>
      'Trade(${side.code} $quantity $symbol @ ${price.toStringAsFixed(2)}'
      '${realizedPnl == null ? '' : ', pnl=${realizedPnl!.toStringAsFixed(2)}'})';
}

// ---------------------------------------------------------------------------
// Position — the net holding
// ---------------------------------------------------------------------------

/// Which way the position is open.
///
/// Added for the F&O module: an option **sell** with nothing held is a *short*
/// (writing the contract), which is a normal F&O trade but was impossible while
/// the book was long-only. `quantity` stays a positive number either way — the
/// direction lives here, so every P&L site has to say which way it is computing
/// instead of silently relying on a sign.
enum PositionSide {
  long('long', 'L'),
  short('short', 'S');

  const PositionSide(this.code, this.letter);

  final String code;

  /// One-letter tag used on badges (L / S).
  final String letter;

  static PositionSide fromName(String? name) => PositionSide.values.firstWhere(
        (s) => s.code == name,
        orElse: () => PositionSide.long,
      );
}

class Position with InstrumentRef {
  final int? id;

  @override
  final String symbol;
  @override
  final Exchange exchange;
  @override
  final String token;

  /// Shares/lots-qty currently open (always positive). Reaching 0 closes it.
  final int quantity;

  /// Long (bought first) or short (sold first). Defaults to long so every
  /// pre-1.5.11 row keeps its meaning.
  final PositionSide side;

  /// Weighted average buy price of the shares still held.
  final double avgPrice;

  /// Absolute stop-loss price (`null` = no stop).
  final double? stopLoss;

  /// Optional target price — informational plus an optional auto-exit.
  final double? target;

  /// Strategy tag inherited from the entry trade; `null` == Ungrouped.
  final int? groupId;

  /// Charges already paid on the opening legs of this position, so that an exit
  /// can book a P&L net of *both* legs (pro-rated for a partial exit).
  final double chargesPaid;

  final DateTime openedAt;
  final DateTime? closedAt;
  final PositionStatus status;

  const Position({
    this.id,
    required this.symbol,
    required this.exchange,
    this.token = '',
    required this.quantity,
    this.side = PositionSide.long,
    required this.avgPrice,
    this.stopLoss,
    this.target,
    this.groupId,
    this.chargesPaid = 0,
    required this.openedAt,
    this.closedAt,
    this.status = PositionStatus.open,
  });

  bool get isOpen => status == PositionStatus.open && quantity > 0;

  /// `true` for a short (option-writing style) position.
  bool get isShort => side == PositionSide.short;

  /// Book value of the holding (`avgPrice × quantity`).
  double get investedValue => avgPrice * quantity;

  /// Stop-loss distance as a percentage **below** the average price.
  /// `null` when there is no stop; always positive for a sane long stop.
  double? get stopLossPct {
    final sl = stopLoss;
    if (sl == null || avgPrice <= 0) return null;
    return (avgPrice - sl) / avgPrice * 100;
  }

  /// Target distance as a percentage **above** the average price.
  double? get targetPct {
    final t = target;
    if (t == null || avgPrice <= 0) return null;
    return (t - avgPrice) / avgPrice * 100;
  }

  /// Rupees at risk if the stop is hit (positive number), `null` without a stop.
  double? get riskAmount {
    final sl = stopLoss;
    if (sl == null) return null;
    return (avgPrice - sl) * quantity;
  }

  /// Unrealised P&L **before** exit charges — the honest "if I could sell at
  /// this price for free" number. Reports subtract the estimated exit cost.
  ///
  /// A short makes money when the premium *falls*: its direction is inverted,
  /// which is exactly the sign bug this getter exists to prevent.
  double unrealizedAt(double ltp) =>
      isShort ? (avgPrice - ltp) * quantity : (ltp - avgPrice) * quantity;

  double unrealizedPctAt(double ltp) {
    if (avgPrice == 0) return 0;
    final move = (ltp - avgPrice) / avgPrice * 100;
    return isShort ? -move : move;
  }

  /// Current market value at [ltp].
  double marketValueAt(double ltp) => ltp * quantity;

  /// `true` when the stop-loss is breached by [ltp] — below the entry for a
  /// long, above it for a short.
  bool stopHit(double ltp) {
    final sl = stopLoss;
    if (sl == null || ltp <= 0) return false;
    return isShort ? ltp >= sl : ltp <= sl;
  }

  /// `true` when the target is reached by [ltp] — above the entry for a long,
  /// below it for a short.
  bool targetHit(double ltp) {
    final t = target;
    if (t == null || ltp <= 0) return false;
    return isShort ? ltp <= t : ltp >= t;
  }

  factory Position.fromDb(Map<String, Object?> row) => Position(
        id: (row['id'] as num?)?.toInt(),
        symbol: '${row['symbol'] ?? ''}',
        exchange: Exchange.fromCode('${row['exchange'] ?? 'NSE'}'),
        token: '${row['token'] ?? ''}',
        quantity: (row['quantity'] as num?)?.toInt() ?? 0,
        side: PositionSide.fromName(row['side'] as String?),
        avgPrice: (row['avg_price'] as num?)?.toDouble() ?? 0,
        stopLoss: (row['stop_loss'] as num?)?.toDouble(),
        target: (row['target'] as num?)?.toDouble(),
        groupId: (row['group_id'] as num?)?.toInt(),
        chargesPaid: (row['charges_paid'] as num?)?.toDouble() ?? 0,
        openedAt: DateTime.fromMillisecondsSinceEpoch(
          (row['opened_at'] as num?)?.toInt() ?? 0,
        ),
        closedAt: (row['closed_at'] as num?) == null
            ? null
            : DateTime.fromMillisecondsSinceEpoch(
                (row['closed_at'] as num).toInt(),
              ),
        status: PositionStatus.fromName('${row['status']}'),
      );

  Map<String, Object?> toDb() => {
        if (id != null) 'id': id,
        'symbol': symbol,
        'exchange': exchange.code,
        'token': token,
        'quantity': quantity,
        'side': side.code,
        'avg_price': avgPrice,
        'stop_loss': stopLoss,
        'target': target,
        'group_id': groupId,
        'charges_paid': chargesPaid,
        'opened_at': openedAt.millisecondsSinceEpoch,
        'closed_at': closedAt?.millisecondsSinceEpoch,
        'status': status.code,
      };

  Position copyWith({
    int? id,
    String? symbol,
    Exchange? exchange,
    String? token,
    int? quantity,
    PositionSide? side,
    double? avgPrice,
    double? stopLoss,
    double? target,
    int? groupId,
    double? chargesPaid,
    DateTime? openedAt,
    DateTime? closedAt,
    PositionStatus? status,
    bool clearStopLoss = false,
    bool clearTarget = false,
    bool clearGroup = false,
  }) =>
      Position(
        id: id ?? this.id,
        symbol: symbol ?? this.symbol,
        exchange: exchange ?? this.exchange,
        token: token ?? this.token,
        quantity: quantity ?? this.quantity,
        side: side ?? this.side,
        avgPrice: avgPrice ?? this.avgPrice,
        stopLoss: clearStopLoss ? null : (stopLoss ?? this.stopLoss),
        target: clearTarget ? null : (target ?? this.target),
        groupId: clearGroup ? null : (groupId ?? this.groupId),
        chargesPaid: chargesPaid ?? this.chargesPaid,
        openedAt: openedAt ?? this.openedAt,
        closedAt: closedAt ?? this.closedAt,
        status: status ?? this.status,
      );

  @override
  String toString() =>
      'Position($id, $quantity $symbol @ ${avgPrice.toStringAsFixed(2)}, '
      '${status.code}${stopLoss == null ? '' : ', sl=${stopLoss!.toStringAsFixed(2)}'})';
}

// ---------------------------------------------------------------------------
// PaperOrder — a submitted order (filled instantly or resting)
// ---------------------------------------------------------------------------

class PaperOrder with InstrumentRef {
  final int? id;

  @override
  final String symbol;
  @override
  final Exchange exchange;
  @override
  final String token;

  final OrderSide side;
  final int quantity;
  final PaperOrderType orderType;

  /// Requested price for a LIMIT order (`null` for MARKET).
  final double? limitPrice;

  /// Stop-loss requested with the order — applied to the position on fill.
  final double? stopLoss;
  final double? target;

  final int? groupId;

  final OrderStatus status;

  final DateTime createdAt;

  /// Fill details, present once [status] is [OrderStatus.filled].
  final DateTime? filledAt;
  final double? filledPrice;

  /// Position this order opened/added to (see also `trades.position_id`).
  final int? positionId;

  /// Why a rejected order was rejected — shown in the Orders tab.
  final String note;

  const PaperOrder({
    this.id,
    required this.symbol,
    required this.exchange,
    this.token = '',
    required this.side,
    required this.quantity,
    this.orderType = PaperOrderType.market,
    this.limitPrice,
    this.stopLoss,
    this.target,
    this.groupId,
    this.status = OrderStatus.pending,
    required this.createdAt,
    this.filledAt,
    this.filledPrice,
    this.positionId,
    this.note = '',
  });

  bool get isPending => status == OrderStatus.pending;
  bool get isFilled => status == OrderStatus.filled;

  /// Price the order is waiting for (limit) or would trade at (market).
  double? get referencePrice => limitPrice ?? filledPrice;

  /// Order value at the reference price.
  double get referenceValue => (referencePrice ?? 0) * quantity;

  factory PaperOrder.fromDb(Map<String, Object?> row) => PaperOrder(
        id: (row['id'] as num?)?.toInt(),
        symbol: '${row['symbol'] ?? ''}',
        exchange: Exchange.fromCode('${row['exchange'] ?? 'NSE'}'),
        token: '${row['token'] ?? ''}',
        side: OrderSide.fromName('${row['side']}'),
        quantity: (row['quantity'] as num?)?.toInt() ?? 0,
        orderType: PaperOrderType.fromName('${row['order_type']}'),
        limitPrice: (row['limit_price'] as num?)?.toDouble(),
        stopLoss: (row['stop_loss'] as num?)?.toDouble(),
        target: (row['target'] as num?)?.toDouble(),
        groupId: (row['group_id'] as num?)?.toInt(),
        status: OrderStatus.fromName('${row['status']}'),
        createdAt: DateTime.fromMillisecondsSinceEpoch(
          (row['created_at'] as num?)?.toInt() ?? 0,
        ),
        filledAt: (row['filled_at'] as num?) == null
            ? null
            : DateTime.fromMillisecondsSinceEpoch(
                (row['filled_at'] as num).toInt(),
              ),
        filledPrice: (row['filled_price'] as num?)?.toDouble(),
        positionId: (row['position_id'] as num?)?.toInt(),
        note: '${row['note'] ?? ''}',
      );

  Map<String, Object?> toDb() => {
        if (id != null) 'id': id,
        'symbol': symbol,
        'exchange': exchange.code,
        'token': token,
        'side': side.code,
        'quantity': quantity,
        'order_type': orderType.code,
        'limit_price': limitPrice,
        'stop_loss': stopLoss,
        'target': target,
        'group_id': groupId,
        'status': status.code,
        'created_at': createdAt.millisecondsSinceEpoch,
        'filled_at': filledAt?.millisecondsSinceEpoch,
        'filled_price': filledPrice,
        'position_id': positionId,
        'note': note,
      };

  PaperOrder copyWith({
    int? id,
    String? symbol,
    Exchange? exchange,
    String? token,
    OrderSide? side,
    int? quantity,
    PaperOrderType? orderType,
    double? limitPrice,
    double? stopLoss,
    double? target,
    int? groupId,
    OrderStatus? status,
    DateTime? createdAt,
    DateTime? filledAt,
    double? filledPrice,
    int? positionId,
    String? note,
  }) =>
      PaperOrder(
        id: id ?? this.id,
        symbol: symbol ?? this.symbol,
        exchange: exchange ?? this.exchange,
        token: token ?? this.token,
        side: side ?? this.side,
        quantity: quantity ?? this.quantity,
        orderType: orderType ?? this.orderType,
        limitPrice: limitPrice ?? this.limitPrice,
        stopLoss: stopLoss ?? this.stopLoss,
        target: target ?? this.target,
        groupId: groupId ?? this.groupId,
        status: status ?? this.status,
        createdAt: createdAt ?? this.createdAt,
        filledAt: filledAt ?? this.filledAt,
        filledPrice: filledPrice ?? this.filledPrice,
        positionId: positionId ?? this.positionId,
        note: note ?? this.note,
      );

  @override
  String toString() =>
      'PaperOrder($id, ${side.code} $quantity $symbol '
      '${orderType.code}${limitPrice == null ? '' : ' @ ${limitPrice!.toStringAsFixed(2)}'}, '
      '${status.code})';
}
