// ---------------------------------------------------------------------------
// result_stamp.dart — ek NSE-announced result ki tareekh + quarter.
//
// `date` = NSE filing/announcement ka din (UI me yahi dikhate hain).
// `reactionDate` = woh pehla market session jisme price ko result par react
// karne ka mauka mila. After-close filing (15:30 IST ke baad) ka reaction
// agle trading session me hota hai; `buildPlaybook` first candle on/after
// reactionDate leta hai. Null purane/legacy rows ke liye hai, aur tab filing
// day hi use hota hai.
// ---------------------------------------------------------------------------

class ResultStamp {
  const ResultStamp({
    required this.date,
    required this.period,
    this.reactionDate,
  });

  final DateTime date;
  final String period;
  final DateTime? reactionDate;
}
