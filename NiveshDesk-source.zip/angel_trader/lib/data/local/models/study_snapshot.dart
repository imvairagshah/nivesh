// ---------------------------------------------------------------------------
// study_snapshot.dart — study ka ek din ka natija, yaad rakha hua.
//
// "Mera hisaab" (kaunsa setup fayda deta hai) tabhi sach bol sakta hai jab
// pata ho ki trade lene ke waqt study ne us stock ke baare me KYA KAHA THA.
// Aaj ka nateeja batana aasan hai — par aaj ka nateeja us din pata nahi tha,
// isliye purane nateeje save karne padte hain.
//
// Ek run me poore universe ki ~250 line likhi jati hai (~30 KB). Har scan ke
// baad purani line mita kar nayi likhi jati hai — itihaas ka matlab yahan
// "pichla scan" hai, na ki har roz ka record.
// ---------------------------------------------------------------------------

/// Ek stock ka, ek run ka natija.
class StudySnapshotRow {
  const StudySnapshotRow({
    required this.symbol,
    required this.savedAt,
    required this.score,
    required this.trend,
    required this.ivRank,
  });

  /// Plain symbol (`RELIANCE`) — trade book wale symbol se milaya jata hai.
  final String symbol;

  /// Ye natija kab save hua (IST wall clock).
  final DateTime savedAt;

  /// 3-month study ka score (0–12).
  final double score;

  /// Trend ka label (`STRONG UP`, `SIDEWAYS`, …).
  final String trend;

  /// IV rank ka label (`LOW`, `MEDIUM`, `HIGH`, …).
  final String ivRank;

  Map<String, Object?> toDb() => {
        'symbol': symbol.toUpperCase(),
        'saved_at': savedAt.millisecondsSinceEpoch,
        'score': score,
        'trend': trend,
        'iv_rank': ivRank,
      };

  factory StudySnapshotRow.fromDb(Map<String, Object?> row) => StudySnapshotRow(
        symbol: '${row['symbol'] ?? ''}',
        savedAt: DateTime.fromMillisecondsSinceEpoch(
          (row['saved_at'] as num?)?.toInt() ?? 0,
        ),
        score: (row['score'] as num?)?.toDouble() ?? 0,
        trend: '${row['trend'] ?? ''}',
        ivRank: '${row['iv_rank'] ?? ''}',
      );

  @override
  String toString() => 'StudySnapshot($symbol, score=$score, $trend, IV $ivRank)';
}
