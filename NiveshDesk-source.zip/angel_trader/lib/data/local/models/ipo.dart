// ---------------------------------------------------------------------------
// ipo.dart — domain model for a mainboard IPO listing.
//
// One row of the `ipos` SQLite table == one IPO. Listing High/Low are the
// *listing day* (day-1) high and low, which is what the proximity screener
// compares the live LTP against.
// ---------------------------------------------------------------------------

import '../../../core/utils/formatters.dart';
import '../../../core/utils/markets.dart';

class Ipo {
  /// SQLite `AUTOINCREMENT` primary key. `null` for an unsaved object.
  final int? id;

  /// Trading symbol as displayed (e.g. `SBIN`, `IDEA`, `NYKAA`). The exchange
  /// is stored separately because Angel One resolves a token per exchange.
  final String symbol;

  /// Company name for display / search (e.g. `FSN E-Commerce Ventures Ltd`).
  final String companyName;

  final Exchange exchange;

  /// The security's ISIN — its *identity*, unlike [symbol] which is just a
  /// label the exchange can change (LTIM → LTM, AMIORG → ACUTAAS, ZOMATO →
  /// ETERNAL). Everything that survives a rename is keyed off this: the app
  /// refreshes [symbol] from ISIN instead of guessing from names.
  ///
  /// `''` when unknown (a delisted name that no longer appears in the exchange
  /// master, or a row the user typed without one).
  final String isin;

  /// First day of trading on the exchange.
  final DateTime listingDate;

  /// High traded on the listing day (₹).
  final double listingHigh;

  /// Low traded on the listing day (₹).
  final double listingLow;

  /// Optional sector tag — purely for the search box / future filters.
  final String sector;

  /// Free-text note (e.g. "IPO price ₹1,390, listed at 80% premium").
  final String notes;

  /// `true` when the user added the row manually (shown with a small badge and
  /// preserved across "reset to bundled CSV" operations).
  final bool isCustom;

  /// Where [listingHigh]/[listingLow] came from — see `LevelsSource` in
  /// `services/listing_levels_service.dart`: `''` pending, `seed`, `user`,
  /// `auto` (fetched from daily candles) or `missing` (nothing available yet).
  final String levelsSource;

  const Ipo({
    this.id,
    required this.symbol,
    required this.companyName,
    required this.exchange,
    required this.listingDate,
    required this.listingHigh,
    required this.listingLow,
    this.isin = '',
    this.sector = '',
    this.notes = '',
    this.isCustom = false,
    this.levelsSource = '',
  });

  /// `true` when the listing-day range is known and usable for the ±band test.
  bool get hasLevels => listingHigh > 0 && listingLow > 0;

  /// Levels the app could not obtain (delisted / renamed symbol, or the market
  /// data simply has no bar for the listing window).
  bool get levelsUnavailable => !hasLevels && levelsSource == 'missing';

  // -------------------------------------------------------------------------
  // Derived helpers used by the screener
  // -------------------------------------------------------------------------

  /// Width of the listing-day range in rupees.
  double get listingRange => listingHigh - listingLow;

  /// Mid-point of the listing-day range — a handy "neutral" reference price.
  double get listingMid => (listingHigh + listingLow) / 2;

  /// Distance of [price] from the listing high, in %.
  double distanceFromHigh(double price) =>
      listingHigh == 0 ? 0 : (price - listingHigh) / listingHigh * 100;

  /// Distance of [price] from the listing low, in %.
  double distanceFromLow(double price) =>
      listingLow == 0 ? 0 : (price - listingLow) / listingLow * 100;

  /// TradingView deep-link symbol. NSE stocks use `NSE:SBIN`, BSE `BSE:SBIN`.
  String get tradingViewSymbol => '${exchange.code}:$symbol';

  /// URL opened by the card's "Chart" button.
  String get tradingViewUrl =>
      'https://in.tradingview.com/chart/?symbol=${Uri.encodeComponent(tradingViewSymbol)}';

  /// Unique key used by price caches / WebSocket token maps.
  String get priceKey => '${exchange.code}:$symbol';

  // -------------------------------------------------------------------------
  // Persistence
  // -------------------------------------------------------------------------

  factory Ipo.fromDb(Map<String, Object?> row) => Ipo(
        id: row['id'] as int?,
        symbol: (row['symbol'] as String? ?? '').toUpperCase(),
        companyName: row['company_name'] as String? ?? '',
        exchange: Exchange.fromCode(row['exchange'] as String? ?? 'NSE'),
        listingDate:
            Fmt.parseDate(row['listing_date'] as String?) ?? DateTime(2015),
        listingHigh: (row['listing_high'] as num? ?? 0).toDouble(),
        listingLow: (row['listing_low'] as num? ?? 0).toDouble(),
        isin: (row['isin'] as String? ?? '').toUpperCase(),
        sector: row['sector'] as String? ?? '',
        notes: row['notes'] as String? ?? '',
        isCustom: (row['is_custom'] as int? ?? 0) == 1,
        levelsSource: row['levels_source'] as String? ??
            ((row['listing_high'] as num? ?? 0) > 0 ? 'seed' : ''),
      );

  Map<String, Object?> toDb() => {
        if (id != null) 'id': id,
        'symbol': symbol,
        'company_name': companyName,
        'exchange': exchange.code,
        'listing_date': Fmt.isoDate(listingDate),
        'listing_high': listingHigh,
        'listing_low': listingLow,
        'isin': isin,
        'sector': sector,
        'notes': notes,
        'is_custom': isCustom ? 1 : 0,
        'levels_source': levelsSource,
      };

  /// `true` for a well-formed ISIN: two letters, nine alphanumerics and a check
  /// digit (e.g. `INE214T01019`). Only the shape is checked — the check digit
  /// itself is not verified, so a typo like `INE214T0101X` is still caught by
  /// the length/alphabet rule.
  static bool isValidIsin(String value) =>
      RegExp(r'^[A-Z]{2}[A-Z0-9]{9}[0-9]$').hasMatch(value.trim().toUpperCase());

  /// Builds an [Ipo] from a CSV record (see `assets/data/ipos.csv`).
  ///
  /// Throws [ArgumentError] when the mandatory fields are missing/invalid so the
  /// import dialog can report the offending line instead of silently skipping it.
  factory Ipo.fromCsvRecord(Map<String, String> record, {int? lineNumber}) {
    String pick(List<String> keys) {
      for (final k in keys) {
        final v = record[k];
        if (v != null && v.trim().isNotEmpty) return v.trim();
      }
      return '';
    }

    final rawSymbol = pick(['symbol', 'tradingsymbol', 'ticker']);
    final symbol = rawSymbol
        .toUpperCase()
        .replaceFirst(RegExp(r'^(NSE|BSE)[:\-]'), '') // tolerate "NSE:IDEA"
        .trim();

    final rawExchange = pick(['exchange']);
    final exchangeText = rawExchange.isNotEmpty
        ? rawExchange
        : (rawSymbol.contains(':') ? rawSymbol.split(':').first : 'NSE');

    final date = Fmt.parseDate(pick(['listingdate', 'listingdt', 'date']));
    final high = double.tryParse(pick(['listinghigh', 'high', 'dayhigh']));
    final low = double.tryParse(pick(['listinglow', 'low', 'daylow']));

    final problems = <String>[];
    if (symbol.isEmpty) problems.add('symbol');
    if (date == null) problems.add('listing date');
    // Levels are optional now: a row can be imported with just symbol + date and
    // the app fetches the listing-day high/low itself (ListingLevelsService).
    if (high != null && low != null && high > 0 && low > 0 && low > high) {
      problems.add('listing low greater than listing high');
    }
    if (problems.isNotEmpty) {
      // The message is shown in the import report, so it names the row and the
      // ticker — "Line 12 (BADROW): listing date, listing high …" is actionable,
      // "invalid row" is not.
      final where = lineNumber == null ? '' : ' (line $lineNumber)';
      final who = symbol.isEmpty ? 'unknown symbol' : symbol;
      throw ArgumentError(
        'Invalid IPO row$where — $who: ${problems.join(', ')} missing or invalid.',
      );
    }

    return Ipo(
      symbol: symbol,
      companyName: pick(['companyname', 'company', 'name']),
      exchange: Exchange.fromCode(exchangeText),
      listingDate: date!,
      listingHigh: high ?? 0,
      listingLow: low ?? 0,
      isin: pick(['isin', 'isinnumber', 'isincode']).toUpperCase(),
      sector: pick(['sector']),
      notes: pick(['notes']),
      isCustom: true,
      // Levels that arrived with a CSV are treated as provided/verified data
      // ('seed'); rows without them are pending and get filled in by
      // ListingLevelsService.
      levelsSource:
          (high != null && low != null && high > 0 && low > 0) ? 'seed' : '',
    );
  }

  // -------------------------------------------------------------------------
  // Validation (used by the add/edit form)
  // -------------------------------------------------------------------------

  /// Returns a list of human-readable problems; empty means the row is valid.
  ///
  /// [requireLevels] is `true` for the manual add/edit form (where the user is
  /// typing the numbers anyway) and `false` for CSV seeds/imports, where a row
  /// may legitimately arrive without its listing-day high/low — the app then
  /// fetches them from the broker (see `ListingLevelsService`).
  List<String> validate({bool requireLevels = true}) {
    final errors = <String>[];
    if (symbol.trim().isEmpty) errors.add('Symbol is required.');
    if (companyName.trim().isEmpty) errors.add('Company name is required.');
    if (requireLevels) {
      if (listingHigh <= 0) errors.add('Listing high must be greater than 0.');
      if (listingLow <= 0) errors.add('Listing low must be greater than 0.');
    }
    if (listingHigh > 0 && listingLow > 0 && listingLow > listingHigh) {
      errors.add('Listing low cannot exceed listing high.');
    }
    if (listingDate.isAfter(DateTime.now())) {
      errors.add('Listing date cannot be in the future.');
    }
    if (listingDate.isBefore(DateTime(2015, 1, 1))) {
      errors.add('This database covers IPOs listed after 1 Jan 2015.');
    }
    if (isin.isNotEmpty && !isValidIsin(isin)) {
      errors.add('ISIN should look like INE214T01019 (12 characters).');
    }
    return errors;
  }

  Ipo copyWith({
    int? id,
    String? symbol,
    String? companyName,
    Exchange? exchange,
    DateTime? listingDate,
    double? listingHigh,
    double? listingLow,
    String? isin,
    String? sector,
    String? notes,
    bool? isCustom,
    String? levelsSource,
  }) =>
      Ipo(
        id: id ?? this.id,
        symbol: symbol ?? this.symbol,
        companyName: companyName ?? this.companyName,
        exchange: exchange ?? this.exchange,
        listingDate: listingDate ?? this.listingDate,
        listingHigh: listingHigh ?? this.listingHigh,
        listingLow: listingLow ?? this.listingLow,
        isin: isin ?? this.isin,
        sector: sector ?? this.sector,
        notes: notes ?? this.notes,
        isCustom: isCustom ?? this.isCustom,
        levelsSource: levelsSource ?? this.levelsSource,
      );

  @override
  String toString() => 'Ipo(${exchange.code}:$symbol, listed ${Fmt.isoDate(listingDate)})';
}
