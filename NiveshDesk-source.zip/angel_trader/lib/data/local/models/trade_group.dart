// ---------------------------------------------------------------------------
// trade_group.dart — a user-defined tag for paper trades.
//
// WHY GROUPS EXIST
//   A trader thinks in strategies/themes ("Momentum", "IPO base", "Result play",
//   "Long term") rather than in single symbols. Groups let one paper trade carry
//   that context, and let the Reports tab answer "which of my baskets actually
//   made money?" instead of only "which stock did?".
//
// DESIGN NOTES
//   * Groups are created up front (Settings → Paper trading → Groups, or inline
//     with "+ New group" while placing a trade), so the same name is reused
//     instead of being retyped for every trade.
//   * A trade/position may have NO group — that is the implicit "Ungrouped"
//     bucket (rendered from a NULL group_id). There is deliberately no row in the
//     table for it, so the reserved name cannot be created twice by accident.
//   * Groups are flat (no nesting) and are never really destroyed if they carry
//     history: [archive] hides them from the picker while their P&L stays
//     reportable. A hard delete reassigns rows to another group / Ungrouped.
// ---------------------------------------------------------------------------

/// Number of colours the UI palette provides; [colorIndex] is taken modulo this.
const int kTradeGroupPaletteSize = 8;

/// Label used everywhere for rows with no group (NULL `group_id`).
const String kUngroupedLabel = 'Ungrouped';

class TradeGroup {
  /// SQLite primary key. `null` before the row is saved.
  final int? id;

  /// Display name — unique, case-insensitive ("momentum" == "Momentum").
  final String name;

  /// Index into the UI colour palette (0 … kTradeGroupPaletteSize-1).
  final int colorIndex;

  /// Optional free text ("only for swing entries above 200 DMA").
  final String notes;

  final DateTime createdAt;

  /// Archived groups keep their history but disappear from the trade form.
  final bool archived;

  const TradeGroup({
    this.id,
    required this.name,
    this.colorIndex = 0,
    this.notes = '',
    required this.createdAt,
    this.archived = false,
  });

  // -------------------------------------------------------------------------
  // Helpers
  // -------------------------------------------------------------------------

  /// Longest practical name for a chip on a phone screen.
  static const int maxNameLength = 24;

  /// Names that would collide with the implicit bucket.
  static const Set<String> reservedNames = {'ungrouped', 'none', 'no group'};

  /// `true` when [name] can be saved (length + reserved words). Uniqueness is
  /// enforced by the database and checked with [TradeGroupDao.nameExists].
  static List<String> validateName(String name) {
    final trimmed = name.trim();
    final errors = <String>[];
    if (trimmed.isEmpty) errors.add('Group name is required.');
    if (trimmed.length > maxNameLength) {
      errors.add('Keep the name under $maxNameLength characters.');
    }
    if (reservedNames.contains(trimmed.toLowerCase())) {
      errors.add('"$trimmed" is reserved — trades without a group use it.');
    }
    return errors;
  }

  /// Picks a colour for a brand-new group, cycling the palette so consecutive
  /// groups never share a colour.
  static int suggestColorIndex(int existingGroupCount) =>
      existingGroupCount % kTradeGroupPaletteSize;

  // -------------------------------------------------------------------------
  // Persistence
  // -------------------------------------------------------------------------

  factory TradeGroup.fromDb(Map<String, Object?> row) => TradeGroup(
        id: row['id'] as int?,
        name: '${row['name'] ?? ''}',
        colorIndex: (row['color_index'] as num?)?.toInt() ?? 0,
        notes: '${row['notes'] ?? ''}',
        createdAt: DateTime.fromMillisecondsSinceEpoch(
          (row['created_at'] as num?)?.toInt() ?? 0,
        ),
        archived: ((row['archived'] as num?)?.toInt() ?? 0) == 1,
      );

  Map<String, Object?> toDb() => {
        if (id != null) 'id': id,
        'name': name.trim(),
        'color_index': colorIndex % kTradeGroupPaletteSize,
        'notes': notes.trim(),
        'created_at': createdAt.millisecondsSinceEpoch,
        'archived': archived ? 1 : 0,
      };

  TradeGroup copyWith({
    int? id,
    String? name,
    int? colorIndex,
    String? notes,
    DateTime? createdAt,
    bool? archived,
  }) =>
      TradeGroup(
        id: id ?? this.id,
        name: name ?? this.name,
        colorIndex: colorIndex ?? this.colorIndex,
        notes: notes ?? this.notes,
        createdAt: createdAt ?? this.createdAt,
        archived: archived ?? this.archived,
      );

  bool matches(String query) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return true;
    return name.toLowerCase().contains(q) || notes.toLowerCase().contains(q);
  }

  @override
  String toString() => 'TradeGroup($id, "$name", colour=$colorIndex)';
}

/// One row of the group-wise P&L table (Reports → "By group").
///
/// Everything here is derived from local tables; the live unrealised part is
/// filled in by the paper-trading service once it has WebSocket prices.
class GroupPnlSummary {
  /// `null` == the implicit Ungrouped bucket.
  final int? groupId;

  /// Display name (never empty — falls back to [kUngroupedLabel]).
  final String groupName;

  /// Colour index carried through from the group (UI only).
  final int colorIndex;

  /// Sum of `trades.realized_pnl` for closing legs in this group.
  final double realizedPnl;

  /// Number of round-trips (closing legs) that produced this P&L.
  final int closedTrades;

  final int wins;
  final int losses;

  /// Sum of all winning round-trips / all losing round-trips (used for averages).
  final double grossProfit;
  final double grossLoss;

  /// Best and worst single round-trip in the group.
  final double biggestWin;
  final double biggestLoss;

  /// Open positions right now (quantity × average price).
  final double openInvestedValue;
  final int openPositionCount;

  const GroupPnlSummary({
    required this.groupId,
    required this.groupName,
    this.colorIndex = 0,
    this.realizedPnl = 0,
    this.closedTrades = 0,
    this.wins = 0,
    this.losses = 0,
    this.grossProfit = 0,
    this.grossLoss = 0,
    this.biggestWin = 0,
    this.biggestLoss = 0,
    this.openInvestedValue = 0,
    this.openPositionCount = 0,
  });

  /// Win rate in percent (0 when there is nothing closed yet).
  double get winRate =>
      closedTrades == 0 ? 0 : wins / closedTrades * 100;

  /// Average size of a winning round-trip (0 when there were none).
  double get averageWin => wins == 0 ? 0 : grossProfit / wins;

  /// Average size of a losing round-trip, as a positive number (0 when none).
  double get averageLoss => losses == 0 ? 0 : grossLoss.abs() / losses;

  /// Profit factor — gross profit ÷ gross loss. `null` when there were no losses
  /// (which is a different statement from "infinitely good").
  double? get profitFactor =>
      grossLoss == 0 ? null : grossProfit / grossLoss.abs();

  bool get isEmpty => closedTrades == 0 && openPositionCount == 0;

  Map<String, dynamic> toJson() => {
        'groupId': groupId,
        'groupName': groupName,
        'colorIndex': colorIndex,
        'realizedPnl': realizedPnl,
        'closedTrades': closedTrades,
        'wins': wins,
        'losses': losses,
        'winRate': winRate,
        'grossProfit': grossProfit,
        'grossLoss': grossLoss,
        'averageWin': averageWin,
        'averageLoss': averageLoss,
        'biggestWin': biggestWin,
        'biggestLoss': biggestLoss,
        'openInvestedValue': openInvestedValue,
        'openPositionCount': openPositionCount,
      };

  @override
  String toString() =>
      'GroupPnlSummary($groupName, realized=${realizedPnl.toStringAsFixed(2)}, '
      'closed=$closedTrades)';
}
