// ---------------------------------------------------------------------------
// app_settings.dart — user-tunable app settings (persisted in SQLite).
//
// Deliberately a plain Dart class (no Flutter import) so it can be unit-tested
// and re-serialised without a widget binding.
// ---------------------------------------------------------------------------

class AppSettings {
  /// Virtual capital for the paper trading module (Feature 3).
  final double startingCapital;

  /// Proximity band used by the IPO screener: |LTP − level| ≤ proximityPct%.
  /// Spec default is ±3%.
  final int proximityPct;

  /// Show Death Cross rows as well as Golden Cross rows (Feature 2).
  final bool deathCrossEnabled;

  /// How often the live feed + screener auto-refresh, in seconds.
  final int autoRefreshSeconds;

  /// Golden Cross scan universe key (`nifty50` | `ipos` | `master_nse` |
  /// `master_all`), see `UniverseCatalog`.
  final String goldenCrossUniverse;

  /// RSI scanner universe key (`fno` | `nifty50` | `ipos` | `master_nse` |
  /// `master_all`), see `UniverseCatalog`.
  final String rsiUniverse;

  /// Wilder period used by the RSI scanner (classic 14).
  final int rsiPeriod;

  /// RSI above this is listed as overbought (brief default: 67).
  final double rsiUpper;

  /// RSI below this is listed as oversold (brief default: 33).
  final double rsiLower;

  // ---- F&O module: 3-Month Study ---------------------------------------

  /// Telegram bot token — when set together with [telegramChatId], the study's
  /// overflow menu can send the XLSX straight to that chat.
  final String telegramBotToken;
  final String telegramChatId;

  /// `system` | `light` | `dark` — mapped to ThemeMode in the shell.
  final String themeMode;

  /// Keep the screen awake while the paper-trading live feed is streaming.
  final bool keepScreenAwake;

  /// Optional HTTPS webhook (ntfy / Telegram bot / own server) that the daily
  /// job pings when new Golden Cross hits are found. Empty = disabled.
  final String notifyWebhookUrl;

  // ---- Paper trading (Feature 3) -----------------------------------------

  /// `delivery` | `intraday` — which cost model the simulated fills use. It
  /// changes brokerage, STT and stamp duty (see charges.dart).
  final String chargesMode;

  /// Charge the ₹13.5 + GST depository fee on delivery sells. Off for users who
  /// square off through a different broker and do not want to see it.
  final bool includeDpCharges;

  /// Run the live WebSocket feed while positions/orders are open. Off means
  /// prices come from the REST snapshot refresh (slower, but gentler on quota).
  final bool liveFeedEnabled;

  /// `auto` | `broker` | `blackScholes` — where the 3-Month Study may take
  /// implied volatility from (B1). `auto` (the default) asks the broker and
  /// falls back to our own Black-Scholes solve; `blackScholes` skips the
  /// broker's per-stock greek call entirely, which is the difference between
  /// ~213 requests and zero on a full F&O scan.
  final String studyIvSource;

  /// Also exit automatically when a position's *target* is reached. The spec
  /// requires stop-loss exits only, so this defaults to off.
  final bool autoExitOnTarget;

  // ---- F&O module: AI Suggestion (local rule engine) --------------------

  /// RSI at or below this counts as oversold (the brief's example: 30 → 35).
  final double aiRsiOversold;

  /// RSI at or above this counts as overbought.
  final double aiRsiOverbought;

  /// Last session's volume must be at least this multiple of the 20-session
  /// average to count as a spike.
  final double aiVolumeSpike;

  /// "Near the 52-week high" band, in percent.
  final double aiNearHighPct;

  /// Minimum 3-month study score (0…12) to reach the shortlist.
  final double aiMinStudyScore;

  /// Minimum momentum score (0…100) to reach the list.
  final double aiMinScore;

  /// Minimum average cash turnover (₹ crore/day) — thin names are refused.
  final double aiMinTurnoverCrore;

  /// How close a confirmed result may be before no new position is suggested.
  final int aiEventBlockDays;

  /// Paper capital one trade may risk, in percent (sizing).
  final double aiRiskPct;

  /// Fewest days to expiry a bought option may have.
  final int aiBuyMinDte;

  /// Most days to expiry a sold strangle may have.
  final int aiSellMaxDte;

  /// How many rows the AI Suggestion screen shows (the brief asks for 20).
  final int aiTopN;

  const AppSettings({
    this.startingCapital = 100000,
    this.proximityPct = 3,
    this.deathCrossEnabled = false,
    this.autoRefreshSeconds = 60,
    this.goldenCrossUniverse = 'nifty50',
    this.rsiUniverse = 'fno',
    this.telegramBotToken = '',
    this.telegramChatId = '',
    this.rsiPeriod = 14,
    this.rsiUpper = 67,
    this.rsiLower = 33,
    this.themeMode = 'system',
    this.keepScreenAwake = false,
    this.notifyWebhookUrl = '',
    this.chargesMode = 'delivery',
    this.includeDpCharges = true,
    this.liveFeedEnabled = true,
    this.studyIvSource = 'auto',
    this.autoExitOnTarget = false,
    this.aiRsiOversold = 35,
    this.aiRsiOverbought = 65,
    this.aiVolumeSpike = 1.5,
    this.aiNearHighPct = 5,
    this.aiMinStudyScore = 5,
    this.aiMinScore = 45,
    this.aiMinTurnoverCrore = 10,
    this.aiEventBlockDays = 5,
    this.aiRiskPct = 1.5,
    this.aiBuyMinDte = 7,
    this.aiSellMaxDte = 20,
    this.aiTopN = 20,
  });

  AppSettings copyWith({
    double? startingCapital,
    int? proximityPct,
    bool? deathCrossEnabled,
    int? autoRefreshSeconds,
    String? goldenCrossUniverse,
    String? rsiUniverse,
    String? telegramBotToken,
    String? telegramChatId,
    int? rsiPeriod,
    double? rsiUpper,
    double? rsiLower,
    String? themeMode,
    bool? keepScreenAwake,
    String? notifyWebhookUrl,
    String? chargesMode,
    bool? includeDpCharges,
    bool? liveFeedEnabled,
    String? studyIvSource,
    bool? autoExitOnTarget,
    double? aiRsiOversold,
    double? aiRsiOverbought,
    double? aiVolumeSpike,
    double? aiNearHighPct,
    double? aiMinStudyScore,
    double? aiMinScore,
    double? aiMinTurnoverCrore,
    int? aiEventBlockDays,
    double? aiRiskPct,
    int? aiBuyMinDte,
    int? aiSellMaxDte,
    int? aiTopN,
  }) =>
      AppSettings(
        startingCapital: startingCapital ?? this.startingCapital,
        proximityPct: proximityPct ?? this.proximityPct,
        deathCrossEnabled: deathCrossEnabled ?? this.deathCrossEnabled,
        autoRefreshSeconds: autoRefreshSeconds ?? this.autoRefreshSeconds,
        goldenCrossUniverse: goldenCrossUniverse ?? this.goldenCrossUniverse,
        rsiUniverse: rsiUniverse ?? this.rsiUniverse,
        telegramBotToken: telegramBotToken ?? this.telegramBotToken,
        telegramChatId: telegramChatId ?? this.telegramChatId,
        rsiPeriod: rsiPeriod ?? this.rsiPeriod,
        rsiUpper: rsiUpper ?? this.rsiUpper,
        rsiLower: rsiLower ?? this.rsiLower,
        themeMode: themeMode ?? this.themeMode,
        keepScreenAwake: keepScreenAwake ?? this.keepScreenAwake,
        notifyWebhookUrl: notifyWebhookUrl ?? this.notifyWebhookUrl,
        chargesMode: chargesMode ?? this.chargesMode,
        includeDpCharges: includeDpCharges ?? this.includeDpCharges,
        liveFeedEnabled: liveFeedEnabled ?? this.liveFeedEnabled,
        studyIvSource: studyIvSource ?? this.studyIvSource,
        autoExitOnTarget: autoExitOnTarget ?? this.autoExitOnTarget,
        aiRsiOversold: aiRsiOversold ?? this.aiRsiOversold,
        aiRsiOverbought: aiRsiOverbought ?? this.aiRsiOverbought,
        aiVolumeSpike: aiVolumeSpike ?? this.aiVolumeSpike,
        aiNearHighPct: aiNearHighPct ?? this.aiNearHighPct,
        aiMinStudyScore: aiMinStudyScore ?? this.aiMinStudyScore,
        aiMinScore: aiMinScore ?? this.aiMinScore,
        aiMinTurnoverCrore: aiMinTurnoverCrore ?? this.aiMinTurnoverCrore,
        aiEventBlockDays: aiEventBlockDays ?? this.aiEventBlockDays,
        aiRiskPct: aiRiskPct ?? this.aiRiskPct,
        aiBuyMinDte: aiBuyMinDte ?? this.aiBuyMinDte,
        aiSellMaxDte: aiSellMaxDte ?? this.aiSellMaxDte,
        aiTopN: aiTopN ?? this.aiTopN,
      );

  /// Settings are stored as flat key/value rows in the `settings` table.
  static const Map<String, String> defaults = {
    'starting_capital': '100000',
    'proximity_pct': '3',
    'death_cross_enabled': '0',
    'auto_refresh_seconds': '60',
    'golden_cross_universe': 'nifty50',
    'theme_mode': 'system',
    'keep_screen_awake': '0',
    'notify_webhook_url': '',
    'charges_mode': 'delivery',
    'include_dp_charges': '1',
    'live_feed_enabled': '1',
    'auto_exit_on_target': '0',
    'telegram_bot_token': '',
    'telegram_chat_id': '',
    'ai_rsi_oversold': '35',
    'ai_rsi_overbought': '65',
    'ai_volume_spike': '1.5',
    'ai_near_high_pct': '5',
    'ai_min_study_score': '5',
    'ai_min_score': '45',
    'ai_min_turnover_cr': '10',
    'ai_event_block_days': '5',
    'ai_risk_pct': '1.5',
    'ai_buy_min_dte': '7',
    'ai_sell_max_dte': '20',
    'ai_top_n': '20',
  };

  factory AppSettings.fromMap(Map<String, String> raw) {
    double dbl(String key, double fallback) =>
        double.tryParse(raw[key] ?? '') ?? fallback;
    int integer(String key, int fallback) =>
        int.tryParse(raw[key] ?? '') ?? fallback;
    bool flag(String key, bool fallback) {
      final v = raw[key];
      if (v == null) return fallback;
      return v == '1' || v.toLowerCase() == 'true';
    }

    return AppSettings(
      startingCapital: dbl('starting_capital', 100000),
      proximityPct: integer('proximity_pct', 3).clamp(1, 25),
      deathCrossEnabled: flag('death_cross_enabled', false),
      autoRefreshSeconds: integer('auto_refresh_seconds', 60).clamp(15, 900),
      goldenCrossUniverse: raw['golden_cross_universe'] ?? 'nifty50',
      rsiUniverse: raw['rsi_universe'] ?? 'fno',
      telegramBotToken: raw['telegram_bot_token'] ?? '',
      telegramChatId: raw['telegram_chat_id'] ?? '',
      rsiPeriod: integer('rsi_period', 14).clamp(2, 200),
      rsiUpper: dbl('rsi_upper', 67).clamp(1, 99),
      rsiLower: dbl('rsi_lower', 33).clamp(1, 99),
      themeMode: raw['theme_mode'] ?? 'system',
      keepScreenAwake: flag('keep_screen_awake', false),
      notifyWebhookUrl: raw['notify_webhook_url'] ?? '',
      chargesMode: raw['charges_mode'] == 'intraday' ? 'intraday' : 'delivery',
      includeDpCharges: flag('include_dp_charges', true),
      liveFeedEnabled: flag('live_feed_enabled', true),
      studyIvSource: raw['study_iv_source'] ?? 'auto',
      autoExitOnTarget: flag('auto_exit_on_target', false),
      aiRsiOversold: dbl('ai_rsi_oversold', 35).clamp(1, 99),
      aiRsiOverbought: dbl('ai_rsi_overbought', 65).clamp(1, 99),
      aiVolumeSpike: dbl('ai_volume_spike', 1.5).clamp(0.1, 20),
      aiNearHighPct: dbl('ai_near_high_pct', 5).clamp(1, 50),
      aiMinStudyScore: dbl('ai_min_study_score', 5).clamp(0, 12),
      aiMinScore: dbl('ai_min_score', 45).clamp(0, 100),
      aiMinTurnoverCrore: dbl('ai_min_turnover_cr', 10).clamp(0, 500),
      aiEventBlockDays: integer('ai_event_block_days', 5).clamp(0, 30),
      aiRiskPct: dbl('ai_risk_pct', 1.5).clamp(0.1, 10),
      aiBuyMinDte: integer('ai_buy_min_dte', 7).clamp(0, 60),
      aiSellMaxDte: integer('ai_sell_max_dte', 20).clamp(3, 90),
      aiTopN: integer('ai_top_n', 20).clamp(5, 50),
    );
  }

  Map<String, String> toMap() => {
        'starting_capital': startingCapital.toStringAsFixed(2),
        'proximity_pct': '$proximityPct',
        'death_cross_enabled': deathCrossEnabled ? '1' : '0',
        'auto_refresh_seconds': '$autoRefreshSeconds',
        'golden_cross_universe': goldenCrossUniverse,
        'rsi_universe': rsiUniverse,
        'telegram_bot_token': telegramBotToken,
        'telegram_chat_id': telegramChatId,
        'rsi_period': '$rsiPeriod',
        'rsi_upper': rsiUpper.toStringAsFixed(1),
        'rsi_lower': rsiLower.toStringAsFixed(1),
        'theme_mode': themeMode,
        'keep_screen_awake': keepScreenAwake ? '1' : '0',
        'notify_webhook_url': notifyWebhookUrl,
        'charges_mode': chargesMode,
        'include_dp_charges': includeDpCharges ? '1' : '0',
        'live_feed_enabled': liveFeedEnabled ? '1' : '0',
        'study_iv_source': studyIvSource,
        'auto_exit_on_target': autoExitOnTarget ? '1' : '0',
        'ai_rsi_oversold': aiRsiOversold.toStringAsFixed(0),
        'ai_rsi_overbought': aiRsiOverbought.toStringAsFixed(0),
        'ai_volume_spike': aiVolumeSpike.toStringAsFixed(1),
        'ai_near_high_pct': aiNearHighPct.toStringAsFixed(0),
        'ai_min_study_score': aiMinStudyScore.toStringAsFixed(1),
        'ai_min_score': aiMinScore.toStringAsFixed(0),
        'ai_min_turnover_cr': aiMinTurnoverCrore.toStringAsFixed(0),
        'ai_event_block_days': '$aiEventBlockDays',
        'ai_risk_pct': aiRiskPct.toStringAsFixed(1),
        'ai_buy_min_dte': '$aiBuyMinDte',
        'ai_sell_max_dte': '$aiSellMaxDte',
        'ai_top_n': '$aiTopN',
      };
}
