// ---------------------------------------------------------------------------
// candle_dao.dart — the local candle cache that makes the cross screener cheap.
//
// Angel One allows only 3 `getCandleData` calls per second (180/min, 5000/hour),
// so re-downloading 400 daily bars for every instrument on every refresh is not
// an option. Daily bars are immutable once the session closes, so the first scan
// of a trading day fetches each instrument once and every later scan (opening
// the app again, changing a filter, switching the cross direction) is served
// from here with zero network calls.
//
// Storage: one row per (exchange, symbol, interval, bar time) — see the
// `candles` table in app_database.dart.
// ---------------------------------------------------------------------------

import 'package:sqflite/sqflite.dart';

import '../app_database.dart';
import '../../remote/dto/candle.dart';
import '../../../core/utils/markets.dart';

class CandleDao {
  CandleDao(this._db);

  final AppDatabase _db;

  static const String _table = AppDatabase.tableCandles;

  /// Interval code used by SmartAPI (`ONE_DAY`); kept as a column so intraday
  /// intervals could be cached later without a migration.
  static const String dailyInterval = 'ONE_DAY';

  // -------------------------------------------------------------------------
  // Writes
  // -------------------------------------------------------------------------

  /// Upserts [bars] for one instrument.
  ///
  /// With [replaceWindow] the stored bars inside [windowFrom]…[windowTo] are
  /// deleted first: that is how a refresh drops stale/duplicate rows when the
  /// broker re-sends a window (e.g. after a symbol change or a bad cached fetch).
  Future<int> saveBars({
    required String exchange,
    required String symbol,
    required List<Candle> bars,
    String interval = dailyInterval,
    bool replaceWindow = false,
    DateTime? windowFrom,
    DateTime? windowTo,
  }) async {
    if (bars.isEmpty) return 0;
    final db = await _db.database;

    return db.transaction<int>((txn) async {
      if (replaceWindow && windowFrom != null && windowTo != null) {
        await txn.delete(
          _table,
          where: 'exchange = ? AND symbol = ? AND interval = ? '
              'AND bar_time >= ? AND bar_time <= ?',
          whereArgs: [
            exchange.toUpperCase(),
            symbol.toUpperCase(),
            interval,
            windowFrom.millisecondsSinceEpoch,
            windowTo.millisecondsSinceEpoch,
          ],
        );
      }

      final batch = txn.batch();
      for (final bar in bars) {
        batch.insert(
          _table,
          {
            'exchange': exchange.toUpperCase(),
            'symbol': symbol.toUpperCase(),
            'interval': interval,
            'bar_time': bar.time.millisecondsSinceEpoch,
            'open': bar.open,
            'high': bar.high,
            'low': bar.low,
            'close': bar.close,
            'volume': bar.volume,
          },
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }
      await batch.commit(noResult: true);
      return bars.length;
    });
  }

  /// Deletes every cached bar for one instrument (Settings → diagnostics).
  Future<void> deleteFor(String exchange, String symbol,
      {String interval = dailyInterval}) async {
    final db = await _db.database;
    await db.delete(
      _table,
      where: 'exchange = ? AND symbol = ? AND interval = ?',
      whereArgs: [exchange.toUpperCase(), symbol.toUpperCase(), interval],
    );
  }

  /// Drops bars older than [before] across every instrument.
  ///
  /// Sweeping after a scan keeps the cache bounded: the screener never looks
  /// further back than ~400 calendar days, so anything older is dead weight.
  Future<int> prune({required DateTime before}) async {
    final db = await _db.database;
    return db.delete(
      _table,
      where: 'bar_time < ?',
      whereArgs: [before.millisecondsSinceEpoch],
    );
  }

  Future<void> clear() async {
    final db = await _db.database;
    await db.delete(_table);
  }

  // -------------------------------------------------------------------------
  // Reads
  // -------------------------------------------------------------------------

  /// Cached bars for one instrument, oldest → newest.
  ///
  /// [from] / [to] are inclusive IST dates; both are optional so callers can ask
  /// for "everything I have" when diagnosing.
  Future<List<Candle>> barsFor({
    required String exchange,
    required String symbol,
    String interval = dailyInterval,
    DateTime? from,
    DateTime? to,
  }) async {
    final db = await _db.database;
    final where = StringBuffer('exchange = ? AND symbol = ? AND interval = ?');
    final args = <Object?>[
      exchange.toUpperCase(),
      symbol.toUpperCase(),
      interval,
    ];
    if (from != null) {
      // 00:00 IST on the first requested day.
      where.write(' AND bar_time >= ?');
      args.add(_istMidnight(from).millisecondsSinceEpoch);
    }
    if (to != null) {
      where.write(' AND bar_time <= ?');
      args.add(_istEndOfDay(to).millisecondsSinceEpoch);
    }

    final rows = await db.query(
      _table,
      where: where.toString(),
      whereArgs: args,
      orderBy: 'bar_time ASC',
    );
    return rows.map(_fromDb).toList(growable: false);
  }

  /// Jin instruments ke daily candles phone me maujood hain.
  ///
  /// Offline analysis (IVP/IVR, DP, trend) universe resolve kiye bina yahi se
  /// shuru hota hai: jis stock ka itihaas hai, usi ka hisaab. Koi network nahi.
  Future<List<({String exchange, String symbol})>> cachedSeries({
    String interval = dailyInterval,
    int limit = 2000,
  }) async {
    final db = await _db.database;
    final rows = await db.query(
      _table,
      columns: ['exchange', 'symbol'],
      where: 'interval = ?',
      whereArgs: [interval],
      groupBy: 'exchange, symbol',
      orderBy: 'symbol ASC',
      limit: limit,
    );
    return [
      for (final row in rows)
        (exchange: '${row['exchange'] ?? ''}', symbol: '${row['symbol'] ?? ''}'),
    ];
  }


  Future<int> barCount({
    required String exchange,
    required String symbol,
    String interval = dailyInterval,
  }) async {
    final db = await _db.database;
    final rows = await db.rawQuery(
      'SELECT COUNT(*) AS c FROM $_table '
      'WHERE exchange = ? AND symbol = ? AND interval = ?',
      [exchange.toUpperCase(), symbol.toUpperCase(), interval],
    );
    return Sqflite.firstIntValue(rows) ?? 0;
  }

  /// Date of the newest cached bar for one instrument (null when none).
  ///
  /// The scanner uses this to decide whether the cache already reaches the
  /// as-of date, i.e. whether a network fetch can be skipped.
  ///
  /// Returns the bar's **IST trading date** (naive midnight), matching
  /// [Candle.istDate] — the raw epoch is shifted by +05:30 before the date is
  /// taken, so the answer does not depend on the phone's timezone.
  Future<DateTime?> lastBarDate(
    String exchange,
    String symbol, {
    String interval = dailyInterval,
  }) async {
    final db = await _db.database;
    final rows = await db.rawQuery(
      'SELECT MAX(bar_time) AS m FROM $_table '
      'WHERE exchange = ? AND symbol = ? AND interval = ?',
      [exchange.toUpperCase(), symbol.toUpperCase(), interval],
    );
    final value = rows.isEmpty ? null : rows.first['m'];
    if (value == null) return null;
    final ist = DateTime.fromMillisecondsSinceEpoch(
      (value as num).toInt(),
      isUtc: true,
    ).add(const Duration(hours: 5, minutes: 30));
    return DateTime(ist.year, ist.month, ist.day);
  }

  /// Total rows in the cache (Settings → Diagnostics).
  Future<int> count() async {
    final db = await _db.database;
    final rows = await db.rawQuery('SELECT COUNT(*) AS c FROM $_table');
    return Sqflite.firstIntValue(rows) ?? 0;
  }

  /// Distinct instruments with at least one cached bar.
  Future<int> instrumentCount() async {
    final db = await _db.database;
    final rows = await db.rawQuery(
      'SELECT COUNT(*) AS c FROM (SELECT DISTINCT exchange, symbol FROM $_table)',
    );
    return Sqflite.firstIntValue(rows) ?? 0;
  }

  // -------------------------------------------------------------------------
  // Internals
  // -------------------------------------------------------------------------

  Candle _fromDb(Map<String, Object?> row) => Candle(
        time: DateTime.fromMillisecondsSinceEpoch(
          (row['bar_time'] as num).toInt(),
        ),
        open: (row['open'] as num).toDouble(),
        high: (row['high'] as num).toDouble(),
        low: (row['low'] as num).toDouble(),
        close: (row['close'] as num).toDouble(),
        volume: (row['volume'] as num?)?.toInt() ?? 0,
      );

  static DateTime _istMidnight(DateTime d) =>
      DateTime.utc(d.year, d.month, d.day).subtract(const Duration(hours: 5, minutes: 30));

  static DateTime _istEndOfDay(DateTime d) =>
      DateTime.utc(d.year, d.month, d.day, 23, 59, 59)
          .subtract(const Duration(hours: 5, minutes: 30));

  /// Kept public for the scanner's logging: `NSE:SBIN-EQ`.
  static String keyFor(Exchange exchange, String brokerSymbol) =>
      '${exchange.code}:${brokerSymbol.toUpperCase()}';
}
