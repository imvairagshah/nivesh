// ---------------------------------------------------------------------------
// settings_dao.dart — key/value settings storage + app-level metadata.
// ---------------------------------------------------------------------------

import 'package:sqflite/sqflite.dart';

import '../../local/app_database.dart';
import '../models/app_settings.dart';

class SettingsDao {
  SettingsDao(this._db);

  final AppDatabase _db;

  static const String _table = AppDatabase.tableSettings;
  static const String _metaTable = AppDatabase.tableScripMeta;

  /// Raw key/value map with defaults filled in.
  Future<Map<String, String>> raw() async {
    final db = await _db.database;
    final rows = await db.query(_table);
    final map = <String, String>{...AppSettings.defaults};
    for (final row in rows) {
      map['${row['key']}'] = '${row['value']}';
    }
    return map;
  }

  /// Typed settings object used by the providers.
  Future<AppSettings> load() async => AppSettings.fromMap(await raw());

  Future<void> save(AppSettings settings) => putAll(settings.toMap());

  Future<void> put(String key, String value) async {
    final db = await _db.database;
    await db.insert(
      _table,
      {'key': key, 'value': value},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> putAll(Map<String, String> values) async {
    final db = await _db.database;
    final batch = db.batch();
    values.forEach((key, value) {
      batch.insert(
        _table,
        {'key': key, 'value': value},
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    });
    await batch.commit(noResult: true);
  }

  // -------------------------------------------------------------------------
  // Scrip-master metadata (download timestamp, row count, source)
  // -------------------------------------------------------------------------

  Future<String?> meta(String key) async {
    final db = await _db.database;
    final rows =
        await db.query(_metaTable, where: 'key = ?', whereArgs: [key], limit: 1);
    return rows.isEmpty ? null : '${rows.first['value']}';
  }

  Future<void> putMeta(String key, String value) async {
    final db = await _db.database;
    await db.insert(
      _metaTable,
      {'key': key, 'value': value},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }
}
