// ---------------------------------------------------------------------------
// scan_cache_dao.dart — cached screener output + last-known prices.
//
// Two jobs:
//   * `scan_runs`  – the last result of each screener per trading day, so the
//                    app opens instantly and works with no network.
//   * `price_cache`– last LTP per symbol, so cards keep showing a price (clearly
//                    marked "cached") when the market feed is unavailable.
// ---------------------------------------------------------------------------

import 'dart:convert';

import 'package:sqflite/sqflite.dart';

import '../../../data/remote/dto/quote.dart';
import '../app_database.dart';

/// Kind identifiers for [ScanCacheDao.saveRun].
class ScanKind {
  ScanKind._();
  static const String ipoProximity = 'ipo_proximity';
  static const String goldenCross = 'golden_cross';

  /// RSI extremes scan (Feature 4 — the RSI scanner tab).
  static const String rsi = 'rsi';

  /// 3-Month Study (F&O module) — trend + ATR + ATM option edge per stock.
  static const String fnoStudy = 'fno_study';
}

class ScanRun {
  final String kind;
  final String asOf; // yyyy-MM-dd
  final List<Map<String, dynamic>> rows;
  final DateTime createdAt;

  const ScanRun({
    required this.kind,
    required this.asOf,
    required this.rows,
    required this.createdAt,
  });

  int get rowCount => rows.length;
}

class ScanCacheDao {
  ScanCacheDao(this._db);

  final AppDatabase _db;

  // -------------------------------------------------------------------------
  // Scanner output
  // -------------------------------------------------------------------------

  /// Persists a scan result, replacing any earlier run of the same kind/date.
  Future<void> saveRun({
    required String kind,
    required String asOf,
    required List<Map<String, dynamic>> rows,
  }) async {
    final db = await _db.database;
    await db.insert(
      AppDatabase.tableScanRuns,
      {
        'kind': kind,
        'as_of': asOf,
        'payload': jsonEncode(rows),
        'created_at': DateTime.now().millisecondsSinceEpoch,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  /// Latest run for [kind], or the run for [asOf] when supplied.
  Future<ScanRun?> latestRun(String kind, {String? asOf}) async {
    final db = await _db.database;
    final rows = await db.query(
      AppDatabase.tableScanRuns,
      where: asOf == null ? 'kind = ?' : 'kind = ? AND as_of = ?',
      whereArgs: asOf == null ? [kind] : [kind, asOf],
      orderBy: 'created_at DESC',
      limit: 1,
    );
    if (rows.isEmpty) return null;
    final row = rows.first;
    final payload = jsonDecode('${row['payload']}');
    return ScanRun(
      kind: '${row['kind']}',
      asOf: '${row['as_of']}',
      rows: payload is List
          ? payload.whereType<Map>().map((e) => e.cast<String, dynamic>()).toList()
          : const [],
      createdAt: DateTime.fromMillisecondsSinceEpoch(
        (row['created_at'] as num?)?.toInt() ?? 0,
      ),
    );
  }

  Future<void> clearRuns(String kind) async {
    final db = await _db.database;
    await db.delete(AppDatabase.tableScanRuns, where: 'kind = ?', whereArgs: [kind]);
  }

  // -------------------------------------------------------------------------
  // Last known prices
  // -------------------------------------------------------------------------

  /// Bulk-upserts a price map keyed by `EXCHANGE:SYMBOL`.
  Future<void> savePrices(Map<String, PricedValue> prices) async {
    if (prices.isEmpty) return;
    final db = await _db.database;
    final batch = db.batch();
    prices.forEach((key, value) {
      batch.insert(
        AppDatabase.tablePriceCache,
        {
          'price_key': key.toUpperCase(),
          'token': '',
          'ltp': value.value,
          'change_pct': value.changePct,
          'as_of': value.asOf.millisecondsSinceEpoch,
        },
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    });
    await batch.commit(noResult: true);
  }

  /// Reads back the cached prices. Returned values are marked `isLive: false`
  /// so the UI can label them as cached rather than live.
  Future<Map<String, PricedValue>> loadPrices() async {
    final db = await _db.database;
    final rows = await db.query(AppDatabase.tablePriceCache);
    final result = <String, PricedValue>{};
    for (final row in rows) {
      result['${row['price_key']}'] = PricedValue(
        value: (row['ltp'] as num?)?.toDouble() ?? 0,
        changePct: (row['change_pct'] as num?)?.toDouble(),
        asOf: DateTime.fromMillisecondsSinceEpoch(
          (row['as_of'] as num?)?.toInt() ?? 0,
        ),
        isLive: false,
      );
    }
    return result;
  }

  /// Newest price timestamp in the cache — the "as of" label in the app bar.
  Future<DateTime?> lastPriceTimestamp() async {
    final db = await _db.database;
    final rows = await db
        .rawQuery('SELECT MAX(as_of) AS m FROM ${AppDatabase.tablePriceCache}');
    final value = rows.isEmpty ? null : rows.first['m'];
    if (value == null) return null;
    return DateTime.fromMillisecondsSinceEpoch((value as num).toInt());
  }

  Future<void> clearPrices() async {
    final db = await _db.database;
    await db.delete(AppDatabase.tablePriceCache);
  }
}
