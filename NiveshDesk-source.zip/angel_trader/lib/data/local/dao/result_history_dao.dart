// ---------------------------------------------------------------------------
// result_history_dao.dart — har stock ke **pichle announced results**.
//
// `earnings` table me ek stock ki ek hi line hoti hai (aakhiri result). Playbook
// ("pichle 6 result me kya hua tha") ke liye *kai* dates chahiye, isliye alag
// taalika: ek stock = har announced result ki ek line.
//
// KYUN ALAG TABLE: `earnings` ka PRIMARY KEY symbol hai — wahin history dalne
// ka matlab hoga "sirf aakhiri result yaad rakho", jo theek wahi nuksan hai
// jise door karna hai.
//
// ANDAZA NAHIN: yahan sirf wahi dates aati hain jo NSE ne announce ki hain
// (financial-results feed). Ek bhi "lagbhag 91 din pichhe" wali date nahi.
// ---------------------------------------------------------------------------

import 'package:sqflite/sqflite.dart';

import '../app_database.dart';
import '../models/result_stamp.dart';
import '../../../core/utils/formatters.dart' show Fmt;

class ResultHistoryDao {
  const ResultHistoryDao(this._db);

  final AppDatabase _db;

  /// Ek stock ke pichle results — **naye se purane**.
  ///
  /// [limit] se jyada purane chhod diye jate hain (playbook ko 6 se jyada
  /// ki zarurat nahi, aur table bina wajah badi na ho).
  Future<List<ResultStamp>> forSymbol(String symbol, {int limit = 8}) async {
    final db = await _db.database;
    final rows = await db.query(
      AppDatabase.tableResultHistory,
      where: 'symbol = ?',
      whereArgs: [symbol.trim().toUpperCase()],
      orderBy: 'result_date DESC',
      limit: limit,
    );
    return [for (final row in rows) _fromDb(row)];
  }

  /// Poora itihaas — `symbol → uske results` (naye se purane).
  Future<Map<String, List<ResultStamp>>> all({int perSymbol = 8}) async {
    final db = await _db.database;
    final rows = await db.query(
      AppDatabase.tableResultHistory,
      orderBy: 'symbol ASC, result_date DESC',
    );

    final out = <String, List<ResultStamp>>{};
    for (final row in rows) {
      final symbol = '${row['symbol']}'.trim().toUpperCase();
      final list = out.putIfAbsent(symbol, () => <ResultStamp>[]);
      if (list.length >= perSymbol) continue;
      list.add(_fromDb(row));
    }
    return out;
  }

  /// Kitne stock ka itihaas pada hai (Diagnostics / khali state batane ke liye).
  Future<int> countSymbols() async {
    final db = await _db.database;
    return Sqflite.firstIntValue(
          await db.rawQuery(
            'SELECT COUNT(DISTINCT symbol) FROM ${AppDatabase.tableResultHistory}',
          ),
        ) ??
        0;
  }

  /// Ek stock ki suchi bilkul badal deta hai (purane mit jate hain).
  Future<void> replaceFor(String symbol, List<ResultStamp> stamps) async {
    final db = await _db.database;
    final key = symbol.trim().toUpperCase();
    await db.transaction((txn) async {
      await txn.delete(
        AppDatabase.tableResultHistory,
        where: 'symbol = ?',
        whereArgs: [key],
      );
      for (final stamp in stamps) {
        await txn.insert(
          AppDatabase.tableResultHistory,
          _toDb(key, stamp),
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }
    });
  }

  /// Poora itihaas ek saath likhta hai (NSE refresh ke baad).
  ///
  /// Pehle purani taalika saaf hoti hai — warna NSE se kisi symbol ka data
  /// hatne par purani line reh jayegi aur purana din sach lagne lagega.
  Future<void> replaceAll(Map<String, List<ResultStamp>> bySymbol) async {
    final db = await _db.database;
    await db.transaction((txn) async {
      await txn.delete(AppDatabase.tableResultHistory);
      final batch = txn.batch();
      for (final entry in bySymbol.entries) {
        final key = entry.key.trim().toUpperCase();
        if (key.isEmpty) continue;
        for (final stamp in entry.value) {
          batch.insert(
            AppDatabase.tableResultHistory,
            _toDb(key, stamp),
            conflictAlgorithm: ConflictAlgorithm.replace,
          );
        }
      }
      await batch.commit(noResult: true);
    });
  }

  ResultStamp _fromDb(Map<String, Object?> row) => ResultStamp(
    date:
        Fmt.parseDate(row['result_date'] as String?) ??
        DateTime.fromMillisecondsSinceEpoch(0),
    period: '${row['period'] ?? ''}',
    reactionDate: Fmt.parseDate(row['reaction_date'] as String?),
  );

  Map<String, Object?> _toDb(String symbol, ResultStamp stamp) =>
      <String, Object?>{
        'symbol': symbol,
        'result_date': Fmt.isoDate(stamp.date),
        'period': stamp.period,
        'reaction_date': stamp.reactionDate == null
            ? null
            : Fmt.isoDate(stamp.reactionDate),
      };
}
