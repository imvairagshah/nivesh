// ---------------------------------------------------------------------------
// ipo_dao.dart — all reads/writes for the `ipos` table (Feature 1 database).
// ---------------------------------------------------------------------------

import 'package:sqflite/sqflite.dart';

import '../../../core/utils/csv_io.dart';
import '../../../core/utils/markets.dart';
import '../app_database.dart';
import '../models/ipo.dart';

/// Result of a CSV seeding / import operation.
class IpoImportReport {
  final int inserted;
  final int skipped;
  final int failed;
  final List<String> errors;

  const IpoImportReport({
    this.inserted = 0,
    this.skipped = 0,
    this.failed = 0,
    this.errors = const [],
  });

  String get summary =>
      '$inserted added, $skipped already present, $failed failed.';
}

/// The string values stored in `ipos.levels_source`. Kept here (not only in the
/// levels service) so SQL in this DAO can reference them without importing a
/// service.
class LevelsSourceNames {
  LevelsSourceNames._();

  static const String pending = '';
  static const String seed = 'seed';
  static const String user = 'user';
  static const String auto = 'auto';
  static const String missing = 'missing';
}

class IpoDao {
  IpoDao(this._db);

  final AppDatabase _db;

  Future<Database> get _database => _db.database;

  static const String _table = AppDatabase.tableIpos;

  // -------------------------------------------------------------------------
  // Reads
  // -------------------------------------------------------------------------

  Future<int> count() async {
    final db = await _database;
    final rows = await db.rawQuery('SELECT COUNT(*) AS c FROM $_table');
    return Sqflite.firstIntValue(rows) ?? 0;
  }

  /// Every row, newest listing first (the default order of the database screen).
  Future<List<Ipo>> all() async {
    final db = await _database;
    final rows = await db.query(_table, orderBy: 'listing_date DESC, symbol ASC');
    return rows.map(Ipo.fromDb).toList(growable: false);
  }

  /// Server-side filtered read. Used by the search box so that a 1,000-row
  /// database does not have to be filtered in Dart.
  Future<List<Ipo>> search({
    String query = '',
    Exchange? exchange,
    int? listingYear,
    int limit = 2000,
  }) async {
    final db = await _database;
    final where = <String>[];
    final args = <Object?>[];

    if (query.trim().isNotEmpty) {
      where.add('(symbol LIKE ? OR company_name LIKE ? OR sector LIKE ?)');
      final like = '%${query.trim()}%';
      args.addAll([like, like, like]);
    }
    if (exchange != null) {
      where.add('exchange = ?');
      args.add(exchange.code);
    }
    if (listingYear != null) {
      where.add("substr(listing_date, 1, 4) = ?");
      args.add('$listingYear');
    }

    final rows = await db.query(
      _table,
      where: where.isEmpty ? null : where.join(' AND '),
      whereArgs: args.isEmpty ? null : args,
      orderBy: 'listing_date DESC, symbol ASC',
      limit: limit,
    );
    return rows.map(Ipo.fromDb).toList(growable: false);
  }

  Future<Ipo?> byId(int id) async {
    final db = await _database;
    final rows = await db.query(_table, where: 'id = ?', whereArgs: [id], limit: 1);
    return rows.isEmpty ? null : Ipo.fromDb(rows.first);
  }

  /// Distinct listing years, newest first (drives the year filter chips).
  Future<List<int>> listingYears() async {
    final db = await _database;
    final rows = await db.rawQuery(
      'SELECT DISTINCT substr(listing_date, 1, 4) AS y FROM $_table ORDER BY y DESC',
    );
    return rows
        .map((r) => int.tryParse('${r['y']}'))
        .whereType<int>()
        .toList(growable: false);
  }

  // -------------------------------------------------------------------------
  // Writes
  // -------------------------------------------------------------------------

  Future<int> insert(Ipo ipo) async {
    final db = await _database;
    final values = ipo.toDb()
      ..['updated_at'] = DateTime.now().millisecondsSinceEpoch;
    values.remove('id');
    return db.insert(_table, values);
  }

  Future<void> update(Ipo ipo) async {
    final db = await _database;
    final values = ipo.toDb()
      ..['updated_at'] = DateTime.now().millisecondsSinceEpoch;
    values.remove('id');
    await db.update(_table, values, where: 'id = ?', whereArgs: [ipo.id]);
  }

  Future<void> delete(int id) async {
    final db = await _database;
    await db.delete(_table, where: 'id = ?', whereArgs: [id]);
  }

  /// Deletes everything. [keepUserAdded] preserves rows the user created by hand.
  Future<int> deleteAll({bool keepUserAdded = false}) async {
    final db = await _database;
    return db.delete(
      _table,
      where: keepUserAdded ? 'is_custom = 0' : null,
    );
  }

  /// Stores the listing-day high/low discovered by [ListingLevelsService],
  /// together with where they came from. Touches nothing else on the row, so a
  /// background fetch can never clobber the user's notes or company name.
  Future<void> setLevels(
    int id,
    double high,
    double low,
    String source,
  ) async {
    final db = await _database;
    await db.update(
      _table,
      {
        'listing_high': high,
        'listing_low': low,
        'levels_source': source,
        'updated_at': DateTime.now().millisecondsSinceEpoch,
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  /// Moves a row to the exchange's new ticker after a rename.
  ///
  /// The seed merge is `INSERT … DO NOTHING`, so it can add a renamed company as
  /// a *new* row but can never correct the row an older install already has —
  /// which is exactly how a ticker that stopped existing (LTIM → LTM, AMIORG →
  /// ACUTAAS) ends up stuck at "token not found" forever. This is the repair
  /// path for that, run once per seed revision.
  ///
  /// Rows the user added themselves are never touched, and if the new ticker is
  /// already present the stale row is removed (same company, duplicated).
  Future<int> renameSymbol({
    required String from,
    required String to,
    String companyName = '',
    String note = '',
  }) async {
    final db = await _database;
    final stale = await db.query(
      _table,
      where: 'symbol = ? AND is_custom = 0',
      whereArgs: [from],
      limit: 1,
    );
    if (stale.isEmpty) return 0;

    final row = stale.first;
    final target = await db.query(
      _table,
      where: 'symbol = ? AND exchange = ?',
      whereArgs: [to, row['exchange']],
      limit: 1,
    );
    if (target.isNotEmpty) {
      await db.delete(_table, where: 'id = ?', whereArgs: [row['id']]);
      return 1;
    }

    final notes = '${row['notes'] ?? ''}'.trim();
    await db.update(
      _table,
      {
        'symbol': to,
        if (companyName.isNotEmpty) 'company_name': companyName,
        if (note.isNotEmpty && !notes.contains(note))
          'notes': notes.isEmpty ? note : '$notes; $note',
        'updated_at': DateTime.now().millisecondsSinceEpoch,
      },
      where: 'id = ?',
      whereArgs: [row['id']],
    );
    return 1;
  }

  /// The row that owns [isin], if any (identity lookup that survives renames).
  Future<Ipo?> byIsin(String isin) async {
    final wanted = isin.trim().toUpperCase();
    if (wanted.isEmpty) return null;
    final db = await _database;
    final rows = await db.query(
      _table,
      where: 'isin = ?',
      whereArgs: [wanted],
      limit: 1,
    );
    return rows.isEmpty ? null : Ipo.fromDb(rows.first);
  }

  /// Stores an ISIN without touching anything else on the row.
  Future<void> setIsin(int id, String isin) async {
    final db = await _database;
    await db.update(
      _table,
      {
        'isin': isin.trim().toUpperCase(),
        'updated_at': DateTime.now().millisecondsSinceEpoch,
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  /// Fills `isin` from a seed file for rows that do not have one yet.
  ///
  /// The identity column arrived after the rest of the table, so every install
  /// that predates it has rows with an empty ISIN — and an empty identity is
  /// exactly what makes a future rename unrepairable. Only blanks are written;
  /// a value the user typed (or a previous run resolved) is never overwritten.
  Future<int> backfillIsinsFromCsv(String csvText) async {
    final records = CsvCodec.parseRecords(csvText);
    final db = await _database;
    final batch = db.batch();
    var candidates = 0;

    for (var i = 0; i < records.length; i++) {
      final Ipo ipo;
      try {
        ipo = Ipo.fromCsvRecord(records[i], lineNumber: i + 2);
      } catch (_) {
        continue;
      }
      if (ipo.isin.isEmpty) continue;
      candidates++;
      batch.rawUpdate(
        'UPDATE $_table SET isin = ?, updated_at = ? '
        "WHERE symbol = ? AND exchange = ? AND isin = ''",
        [
          ipo.isin,
          DateTime.now().millisecondsSinceEpoch,
          ipo.symbol,
          ipo.exchange.code,
        ],
      );
    }

    if (candidates == 0) return 0;
    final results = await batch.commit(noResult: false);
    var updated = 0;
    for (final result in results) {
      if (result is int) updated += result;
    }
    return updated;
  }

  /// Fills blank listing levels from a seed file **without touching anything
  /// else on the row**.
  ///
  /// Why this exists: `seedFromCsv` inserts with `ON CONFLICT DO NOTHING`, so an
  /// app update can add rows but never enrich existing ones. When the shipped
  /// master grew listing levels for every row (1.3.3 pre-filled them from NSE's
  /// bhavcopy), an install coming from an earlier version would still sit on
  /// blank levels and burn ~500 broker candle calls re-fetching what the APK
  /// already knows.
  ///
  /// Only rows that are *both* pending (`levels_source = ''`) and level-less are
  /// updated — anything the user typed, the broker fetched, or the file curated
  /// keeps its value untouched.
  Future<int> backfillLevelsFromCsv(String csvText) async {
    final records = CsvCodec.parseRecords(csvText);
    final db = await _database;
    final batch = db.batch();
    var candidates = 0;

    for (var i = 0; i < records.length; i++) {
      final Ipo ipo;
      try {
        ipo = Ipo.fromCsvRecord(records[i], lineNumber: i + 2);
      } catch (_) {
        continue; // a malformed seed line never blocks the enrichment pass
      }
      if (!ipo.hasLevels) continue;
      candidates++;
      batch.rawUpdate(
        'UPDATE $_table SET listing_high = ?, listing_low = ?, '
        "levels_source = 'seed', updated_at = ? "
        "WHERE symbol = ? AND exchange = ? AND levels_source = '' "
        'AND (listing_high <= 0 OR listing_low <= 0)',
        [
          ipo.listingHigh,
          ipo.listingLow,
          DateTime.now().millisecondsSinceEpoch,
          ipo.symbol,
          ipo.exchange.code,
        ],
      );
    }

    if (candidates == 0) return 0;
    final results = await batch.commit(noResult: false);
    var updated = 0;
    for (final result in results) {
      if (result is int) updated += result;
    }
    return updated;
  }

  /// Rows still waiting for their listing-day levels, newest listings first.
  Future<List<Ipo>> awaitingLevels({bool includeMissing = false}) async {
    final db = await _database;
    final rows = await db.query(
      _table,
      where: includeMissing
          ? "(listing_high <= 0 OR listing_low <= 0)"
          : "(listing_high <= 0 OR listing_low <= 0) AND levels_source = ''",
      orderBy: 'listing_date DESC',
    );
    return rows.map(Ipo.fromDb).toList(growable: false);
  }

  /// How many rows have no usable listing-day range yet.
  /// Rows still *waiting* for their listing levels.
  ///
  /// Must stay in sync with `awaitingLevels()`: a row that was already tried and
  /// could not be answered (`levels_source = 'missing'`) is finished business,
  /// not pending work. Counting it here was a real bug — the scan bar kept
  /// showing "N IPOs need listing-day high/low" forever, which reads as a hang.
  /// Those rows are reported instead through the screener's attention list.
  Future<int> countAwaitingLevels() async {
    final db = await _database;
    final result = await db.rawQuery(
      'SELECT COUNT(*) AS n FROM $_table '
      'WHERE (listing_high <= 0 OR listing_low <= 0) AND levels_source = \'\'',
    );
    return (result.first['n'] as int?) ?? 0;
  }

  /// Rows whose levels will never arrive (the symbol is not in the broker
  /// master). Surfaced as "needs attention" rather than as pending work.
  Future<int> countLevelsUnavailable() async {
    final db = await _database;
    final result = await db.rawQuery(
      'SELECT COUNT(*) AS n FROM $_table '
      'WHERE (listing_high <= 0 OR listing_low <= 0) AND levels_source = ?',
      [LevelsSourceNames.missing],
    );
    return (result.first['n'] as int?) ?? 0;
  }

  /// Inserts or updates a row keyed on (symbol, exchange).
  ///
  /// Used by CSV import and by the bundled seed, so re-running an import is
  /// idempotent instead of creating duplicates.
  Future<bool> upsert(Ipo ipo, {bool overwrite = true}) async {
    final db = await _database;
    final values = ipo.toDb()
      ..['updated_at'] = DateTime.now().millisecondsSinceEpoch;
    values.remove('id');

    final columns = values.keys.toList();
    final placeholders = List.filled(columns.length, '?').join(', ');
    final conflict = overwrite
        ? 'DO UPDATE SET ${columns.where((c) => c != 'symbol' && c != 'exchange').map((c) => '$c = excluded.$c').join(', ')}'
        : 'DO NOTHING';

    await db.rawInsert(
      'INSERT INTO $_table (${columns.join(', ')}) VALUES ($placeholders) '
      'ON CONFLICT(symbol, exchange) $conflict',
      values.values.toList(),
    );
    return true;
  }

  // -------------------------------------------------------------------------
  // Bulk operations
  // -------------------------------------------------------------------------

  /// Seeds the table from CSV text.
  ///
  /// Called on first launch with `assets/data/ipos.csv`, which is why it never
  /// overwrites existing rows by default ([overwrite] = false): the user's own
  /// edits must survive an app update.
  ///
  /// Runs as a single batch transaction — a few thousand rows insert in well
  /// under a second and the UI can call it during first-run setup.
  Future<IpoImportReport> seedFromCsv(
    String csvText, {
    bool overwrite = false,
  }) async {
    final records = CsvCodec.parseRecords(csvText);
    final parsed = <Ipo>[];
    final errors = <String>[];
    var failed = 0;

    for (var i = 0; i < records.length; i++) {
      try {
        final ipo = Ipo.fromCsvRecord(records[i], lineNumber: i + 2);
        if (ipo.validate(requireLevels: false).isEmpty) {
          parsed.add(ipo);
        } else {
          failed++;
          errors.add('Line ${i + 2} (${ipo.symbol}): ${ipo.validate().join(' ')}');
        }
      } catch (e) {
        failed++;
        errors.add('$e');
      }
    }

    if (parsed.isEmpty) {
      return IpoImportReport(failed: failed, errors: errors);
    }

    final before = await count();
    final db = await _database;
    final batch = db.batch();
    for (final ipo in parsed) {
      final values = ipo.toDb()
        ..['updated_at'] = DateTime.now().millisecondsSinceEpoch;
      values.remove('id');
      final columns = values.keys.toList();
      final placeholders = List.filled(columns.length, '?').join(', ');
      final conflict = overwrite
          ? 'DO UPDATE SET ${columns.where((c) => c != 'symbol' && c != 'exchange').map((c) => '$c = excluded.$c').join(', ')}'
          : 'DO NOTHING';
      batch.rawInsert(
        'INSERT INTO $_table (${columns.join(', ')}) VALUES ($placeholders) '
        'ON CONFLICT(symbol, exchange) $conflict',
        values.values.toList(),
      );
    }
    await batch.commit(noResult: true);

    final after = await count();
    final inserted = after - before;
    return IpoImportReport(
      inserted: inserted,
      skipped: parsed.length - inserted,
      failed: failed,
      errors: errors.take(20).toList(growable: false),
    );
  }
}
