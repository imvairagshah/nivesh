import 'package:sqflite/sqflite.dart';

import '../../../features/magic_formula/magic_formula_models.dart';
import '../app_database.dart';

/// Local one-hour cache for verified Magic Formula inputs.
class MagicFormulaDao {
  MagicFormulaDao(this._db);

  final AppDatabase _db;

  Future<Map<String, MagicFormulaFundamental>> all() async {
    final db = await _db.database;
    final rows = await db.query(AppDatabase.tableMagicFormulaFundamentals);
    return {
      for (final row in rows)
        '${row['security_key']}': MagicFormulaFundamental.fromDb(row),
    };
  }

  Future<MagicFormulaFundamental?> find(String securityKey) async {
    final db = await _db.database;
    final rows = await db.query(
      AppDatabase.tableMagicFormulaFundamentals,
      where: 'security_key = ?',
      whereArgs: [securityKey],
      limit: 1,
    );
    return rows.isEmpty ? null : MagicFormulaFundamental.fromDb(rows.first);
  }

  Future<void> saveAll(Iterable<MagicFormulaFundamental> fundamentals) async {
    final rows = fundamentals.toList(growable: false);
    if (rows.isEmpty) return;
    final db = await _db.database;
    await db.transaction((txn) async {
      final batch = txn.batch();
      for (final row in rows) {
        batch.insert(
          AppDatabase.tableMagicFormulaFundamentals,
          row.toDb(),
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }
      await batch.commit(noResult: true);
    });
  }

  Future<int> count() async {
    final db = await _db.database;
    final rows = await db.rawQuery(
      'SELECT COUNT(*) AS c FROM ${AppDatabase.tableMagicFormulaFundamentals}',
    );
    return Sqflite.firstIntValue(rows) ?? 0;
  }

  Future<void> clear() async {
    final db = await _db.database;
    await db.delete(AppDatabase.tableMagicFormulaFundamentals);
  }
}
