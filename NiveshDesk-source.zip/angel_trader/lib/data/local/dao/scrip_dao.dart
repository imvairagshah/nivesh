// ---------------------------------------------------------------------------
// scrip_dao.dart — the local mirror of Angel One's scrip master.
//
// The master (~100k rows, ~50 MB JSON) is downloaded once a day, filtered to
// cash-market equities and stored here. Token lookups then hit SQLite instead of
// the network.
// ---------------------------------------------------------------------------

import 'package:sqflite/sqflite.dart';

import '../../../data/remote/dto/scrip.dart';
import '../app_database.dart';

class ScripDao {
  ScripDao(this._db);

  final AppDatabase _db;

  static const String _table = AppDatabase.tableScrips;

  Future<int> count({String? exchange}) async {
    final db = await _db.database;
    final rows = exchange == null
        ? await db.rawQuery('SELECT COUNT(*) AS c FROM $_table')
        : await db.rawQuery(
            'SELECT COUNT(*) AS c FROM $_table WHERE exchange = ?',
            [exchange.toUpperCase()],
          );
    return Sqflite.firstIntValue(rows) ?? 0;
  }

  /// Loads every equity into memory for [TokenResolver] (≈5k rows on NSE+BSE,
  /// which is a few hundred KB of Dart objects — safe to keep resident).
  Future<List<Scrip>> allEquities() async {
    final db = await _db.database;
    final rows = await db.query(_table);
    return rows.map(Scrip.fromDb).toList(growable: false);
  }

  /// Exact lookup on exchange + broker symbol (e.g. `NSE` + `SBIN-EQ`).
  Future<Scrip?> findBySymbol(String symbol, {String? exchange}) async {
    final db = await _db.database;
    final where = StringBuffer('symbol = ?');
    final args = <Object?>[symbol.toUpperCase()];
    if (exchange != null) {
      where.write(' AND exchange = ?');
      args.add(exchange.toUpperCase());
    }
    final rows = await db.query(_table, where: where.toString(), whereArgs: args, limit: 1);
    return rows.isEmpty ? null : Scrip.fromDb(rows.first);
  }

  Future<Scrip?> findByToken(String token) async {
    final db = await _db.database;
    final rows =
        await db.query(_table, where: 'token = ?', whereArgs: [token], limit: 1);
    return rows.isEmpty ? null : Scrip.fromDb(rows.first);
  }

  /// Free-text search for the instrument picker dialog.
  Future<List<Scrip>> search(String query, {int limit = 30}) async {
    final q = query.trim().toUpperCase();
    if (q.isEmpty) return const [];
    final db = await _db.database;
    final rows = await db.query(
      _table,
      where: 'symbol LIKE ? OR name LIKE ?',
      whereArgs: ['%$q%', '%$q%'],
      orderBy: 'length(symbol) ASC, symbol ASC',
      limit: limit,
    );
    return rows.map(Scrip.fromDb).toList(growable: false);
  }

  /// Replaces the cached master with a freshly downloaded one.
  ///
  /// Rows are written in batches inside a single transaction; [onProgress] is
  /// called after each batch so the UI can show "inserting 40,000/52,000".
  Future<int> replaceAll(
    List<Scrip> scrips, {
    void Function(int done, int total)? onProgress,
    int batchSize = 1000,
  }) async {
    if (scrips.isEmpty) return 0;
    final db = await _db.database;

    await db.transaction((txn) async {
      await txn.delete(_table);
      final batch = txn.batch();
      var pending = 0;
      var written = 0;

      for (final scrip in scrips) {
        batch.insert(
          _table,
          scrip.toDb(),
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
        pending++;
        if (pending >= batchSize) {
          await batch.commit(noResult: true);
          written += pending;
          onProgress?.call(written, scrips.length);
          pending = 0;
        }
      }
      if (pending > 0) {
        await batch.commit(noResult: true);
        written += pending;
        onProgress?.call(written, scrips.length);
      }
    });

    return scrips.length;
  }

  /// Upserts one batch of instruments during a **streaming** master download.
  ///
  /// Unlike [replaceAll] it never deletes: the caller clears the table once,
  /// then feeds batches as they come off the network, so a 50 MB download is
  /// never held in memory.
  Future<void> replaceAllIncremental(
    List<Scrip> scrips, {
    int batchSize = 500,
  }) async {
    if (scrips.isEmpty) return;
    final db = await _db.database;

    await db.transaction((txn) async {
      var batch = txn.batch();
      var pending = 0;
      for (final scrip in scrips) {
        batch.insert(
          _table,
          scrip.toDb(),
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
        pending++;
        if (pending >= batchSize) {
          await batch.commit(noResult: true);
          batch = txn.batch();
          pending = 0;
        }
      }
      if (pending > 0) await batch.commit(noResult: true);
    });
  }

  /// Deletes the cache (Settings → "Refresh scrip master" with `force`).
  Future<void> clear() async {
    final db = await _db.database;
    await db.delete(_table);
  }
}
