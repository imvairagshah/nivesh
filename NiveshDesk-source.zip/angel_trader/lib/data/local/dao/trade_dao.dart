// ---------------------------------------------------------------------------
// trade_dao.dart — persistence for the paper-trading module (Feature 3).
//
// Three tables, all local:
//   paper_orders  submitted orders (pending LIMIT orders live here until they
//                 fill, are cancelled, or are rejected)
//   trades        one row per *filled leg* — the account ledger
//   positions     the net long holding per symbol
//
// Everything the Reports tab needs is derived from these three tables; nothing
// is duplicated into aggregates, so a correction (say, re-tagging a trade's
// group) is instantly reflected everywhere.
//
// Query conventions
//   * Group filters accept an explicit [groupId] **and** an `ungroupedOnly`
//     flag, because "Ungrouped" is `group_id IS NULL` rather than a row.
//   * Date filters compare on `executed_at` (milliseconds since epoch, local
//     wall-clock at the moment of the fill).
//   * Lists are always ordered deterministically (newest first) so the UI never
//     jitters between rebuilds.
// ---------------------------------------------------------------------------

import 'package:sqflite/sqflite.dart';

import '../app_database.dart';
import '../models/paper_trade.dart';
import '../models/study_snapshot.dart';

class TradeDao {
  TradeDao(this._db);

  final AppDatabase _db;

  static const String _trades = AppDatabase.tableTrades;
  static const String _positions = AppDatabase.tablePositions;
  static const String _orders = AppDatabase.tablePaperOrders;
  static const String _snapshots = AppDatabase.tableStudySnapshots;

  /// Guard for every "give me everything" query — the UI pages through history
  /// instead of loading a decade of trades into memory.
  static const int defaultLimit = 500;

  // -------------------------------------------------------------------------
  // Positions
  // -------------------------------------------------------------------------

  Future<int> insertPosition(Position position) async {
    final db = await _db.database;
    return db.insert(_positions, position.toDb());
  }

  Future<void> updatePosition(Position position) async {
    final id = position.id;
    if (id == null) return;
    final db = await _db.database;
    await db.update(
      _positions,
      position.toDb(),
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<Position?> positionById(int id) async {
    final db = await _db.database;
    final rows =
        await db.query(_positions, where: 'id = ?', whereArgs: [id], limit: 1);
    return rows.isEmpty ? null : Position.fromDb(rows.first);
  }

  /// The open position for one instrument — the lookup every order does before
  /// it decides between "open", "add" and "reduce".
  Future<Position?> openPositionFor(String symbol, String exchange) async {
    final db = await _db.database;
    final rows = await db.query(
      _positions,
      where: 'symbol = ? AND exchange = ? AND status = ?',
      whereArgs: [symbol, exchange, PositionStatus.open.code],
      orderBy: 'opened_at DESC',
      limit: 1,
    );
    return rows.isEmpty ? null : Position.fromDb(rows.first);
  }

  /// Open positions, newest first, optionally filtered by strategy group.
  ///
  /// [ungroupedOnly] wins over [groupId] (passing both is a caller bug, but the
  /// useful interpretation is "just the untagged ones").
  Future<List<Position>> openPositions({
    int? groupId,
    bool ungroupedOnly = false,
    int limit = defaultLimit,
  }) async {
    final db = await _db.database;
    final where = <String>['status = ?'];
    final args = <Object?>[PositionStatus.open.code];

    if (ungroupedOnly) {
      where.add('group_id IS NULL');
    } else if (groupId != null) {
      where.add('group_id = ?');
      args.add(groupId);
    }

    final rows = await db.query(
      _positions,
      where: where.join(' AND '),
      whereArgs: args,
      orderBy: 'opened_at DESC',
      limit: limit,
    );
    return rows.map(Position.fromDb).toList(growable: false);
  }

  /// Every open position regardless of group — used by the stop-loss watcher
  /// and the dashboard.
  Future<List<Position>> allOpenPositions() => openPositions(limit: 5000);

  /// Closed positions, newest close first (Trade Book → "closed" summary view).
  Future<List<Position>> closedPositions({int limit = defaultLimit}) async {
    final db = await _db.database;
    final rows = await db.query(
      _positions,
      where: 'status = ?',
      whereArgs: [PositionStatus.closed.code],
      orderBy: 'closed_at DESC',
      limit: limit,
    );
    return rows.map(Position.fromDb).toList(growable: false);
  }

  Future<int> countOpenPositions() async {
    final db = await _db.database;
    final rows = await db.rawQuery(
      'SELECT COUNT(*) AS c FROM $_positions WHERE status = ?',
      [PositionStatus.open.code],
    );
    return (rows.first['c'] as num?)?.toInt() ?? 0;
  }

  /// Re-tags a position (and, by the caller's choice, its trades) — used by the
  /// group manager when a group is deleted or a holding is re-bucketed.
  Future<void> setPositionGroup(int positionId, int? groupId) async {
    final db = await _db.database;
    await db.update(
      _positions,
      {'group_id': groupId},
      where: 'id = ?',
      whereArgs: [positionId],
    );
  }

  // -------------------------------------------------------------------------
  // Trades (the ledger)
  // -------------------------------------------------------------------------

  Future<int> insertTrade(Trade trade) async {
    final db = await _db.database;
    return db.insert(_trades, trade.toDb());
  }

  /// All legs of one position, oldest first (entry → exits).
  Future<List<Trade>> tradesForPosition(int positionId) async {
    final db = await _db.database;
    final rows = await db.query(
      _trades,
      where: 'position_id = ?',
      whereArgs: [positionId],
      orderBy: 'executed_at ASC, id ASC',
    );
    return rows.map(Trade.fromDb).toList(growable: false);
  }

  /// The trade book: every leg, newest first.
  ///
  /// [symbolQuery] is a case-insensitive substring match on the broker symbol
  /// (`SBIN` finds `SBIN-EQ`), matching how the rest of the app searches.
  Future<List<Trade>> tradeBook({
    int? groupId,
    bool ungroupedOnly = false,
    DateTime? from,
    DateTime? to,
    String symbolQuery = '',
    int limit = defaultLimit,
  }) async {
    final db = await _db.database;
    final where = <String>[];
    final args = <Object?>[];

    if (ungroupedOnly) {
      where.add('group_id IS NULL');
    } else if (groupId != null) {
      where.add('group_id = ?');
      args.add(groupId);
    }
    if (from != null) {
      where.add('executed_at >= ?');
      args.add(from.millisecondsSinceEpoch);
    }
    if (to != null) {
      where.add('executed_at <= ?');
      args.add(to.millisecondsSinceEpoch);
    }
    final query = symbolQuery.trim().toUpperCase();
    if (query.isNotEmpty) {
      where.add('UPPER(symbol) LIKE ?');
      args.add('%$query%');
    }

    final rows = await db.query(
      _trades,
      where: where.isEmpty ? null : where.join(' AND '),
      whereArgs: args.isEmpty ? null : args,
      orderBy: 'executed_at DESC, id DESC',
      limit: limit,
    );
    return rows.map(Trade.fromDb).toList(growable: false);
  }

  /// Re-tags one leg (used when a holding is moved to another group, so the
  /// trade book and the reports do not disagree with the position).
  Future<void> updateTradeGroup(int? tradeId, int? groupId) async {
    if (tradeId == null) return;
    final db = await _db.database;
    await db.update(
      _trades,
      {'group_id': groupId},
      where: 'id = ?',
      whereArgs: [tradeId],
    );
  }

  /// Only the legs that booked P&L (i.e. the exits) — the input to every
  /// realised-P&L report.
  Future<List<Trade>> closingLegs({
    DateTime? from,
    DateTime? to,
    int? groupId,
    bool ungroupedOnly = false,
    int limit = 5000,
  }) async {
    final db = await _db.database;
    final where = <String>['realized_pnl IS NOT NULL'];
    final args = <Object?>[];

    if (ungroupedOnly) {
      where.add('group_id IS NULL');
    } else if (groupId != null) {
      where.add('group_id = ?');
      args.add(groupId);
    }
    if (from != null) {
      where.add('executed_at >= ?');
      args.add(from.millisecondsSinceEpoch);
    }
    if (to != null) {
      where.add('executed_at <= ?');
      args.add(to.millisecondsSinceEpoch);
    }

    final rows = await db.query(
      _trades,
      where: where.join(' AND '),
      whereArgs: args,
      orderBy: 'executed_at DESC, id DESC',
      limit: limit,
    );
    return rows.map(Trade.fromDb).toList(growable: false);
  }

  /// Every leg — the cash ledger used by the dashboard snapshot.
  Future<List<Trade>> allTrades({int limit = 20000}) async {
    final db = await _db.database;
    final rows = await db.query(
      _trades,
      orderBy: 'executed_at ASC, id ASC',
      limit: limit,
    );
    return rows.map(Trade.fromDb).toList(growable: false);
  }

  Future<int> countTrades() async {
    final db = await _db.database;
    final rows = await db.rawQuery('SELECT COUNT(*) AS c FROM $_trades');
    return (rows.first['c'] as num?)?.toInt() ?? 0;
  }

  /// Distinct symbols ever traded — diagnostics + "which instruments do I need
  /// feed subscriptions for".
  Future<List<String>> tradedSymbols() async {
    final db = await _db.database;
    final rows = await db.rawQuery(
      'SELECT DISTINCT symbol FROM $_trades ORDER BY symbol ASC',
    );
    return rows.map((r) => '${r['symbol']}').toList(growable: false);
  }

  // -------------------------------------------------------------------------
  // Study snapshots ("Mera hisaab")
  // -------------------------------------------------------------------------

  /// Ek scan ke natije likhta hai (purane sab mit jaate hain — "itihaas" ka
  /// matlab yahan pichla scan hai, har roz ka record nahi).
  Future<int> replaceStudySnapshots(List<StudySnapshotRow> rows) async {
    final db = await _db.database;
    final written = await db.transaction((txn) async {
      await txn.delete(_snapshots);
      for (final row in rows) {
        await txn.insert(
          _snapshots,
          row.toDb(),
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }
      return rows.length;
    });
    return written;
  }

  /// Har stock ke snapshots, symbol ke hisaab se (purane se naye).
  Future<Map<String, List<StudySnapshotRow>>> allStudySnapshots() async {
    final db = await _db.database;
    final rows = await db.query(_snapshots, orderBy: 'symbol ASC, saved_at ASC');
    final out = <String, List<StudySnapshotRow>>{};
    for (final row in rows) {
      final snapshot = StudySnapshotRow.fromDb(row);
      out.putIfAbsent(snapshot.symbol.toUpperCase(), () => <StudySnapshotRow>[])
          .add(snapshot);
    }
    return out;
  }

  Future<int> countStudySnapshots() async {
    final db = await _db.database;
    final rows = await db.rawQuery('SELECT COUNT(*) AS c FROM $_snapshots');
    return (rows.first['c'] as num?)?.toInt() ?? 0;
  }

  // -------------------------------------------------------------------------
  // Orders
  // -------------------------------------------------------------------------

  Future<int> insertOrder(PaperOrder order) async {
    final db = await _db.database;
    return db.insert(_orders, order.toDb());
  }

  Future<void> updateOrder(PaperOrder order) async {
    final id = order.id;
    if (id == null) return;
    final db = await _db.database;
    await db.update(_orders, order.toDb(), where: 'id = ?', whereArgs: [id]);
  }

  Future<PaperOrder?> orderById(int id) async {
    final db = await _db.database;
    final rows =
        await db.query(_orders, where: 'id = ?', whereArgs: [id], limit: 1);
    return rows.isEmpty ? null : PaperOrder.fromDb(rows.first);
  }

  /// Resting limit orders, oldest first — the order in which they are checked
  /// against every tick.
  Future<List<PaperOrder>> pendingOrders() async {
    final db = await _db.database;
    final rows = await db.query(
      _orders,
      where: 'status = ?',
      whereArgs: [OrderStatus.pending.code],
      orderBy: 'created_at ASC, id ASC',
    );
    return rows.map(PaperOrder.fromDb).toList(growable: false);
  }

  Future<List<PaperOrder>> pendingOrdersForSymbol(String symbol) async {
    final db = await _db.database;
    final rows = await db.query(
      _orders,
      where: 'status = ? AND symbol = ?',
      whereArgs: [OrderStatus.pending.code, symbol],
      orderBy: 'created_at ASC',
    );
    return rows.map(PaperOrder.fromDb).toList(growable: false);
  }

  Future<int> countPendingOrders() async {
    final db = await _db.database;
    final rows = await db.rawQuery(
      'SELECT COUNT(*) AS c FROM $_orders WHERE status = ?',
      [OrderStatus.pending.code],
    );
    return (rows.first['c'] as num?)?.toInt() ?? 0;
  }

  /// Full order history for the Orders tab, newest first.
  Future<List<PaperOrder>> orders({int limit = defaultLimit}) async {
    final db = await _db.database;
    final rows = await db.query(
      _orders,
      orderBy: 'created_at DESC, id DESC',
      limit: limit,
    );
    return rows.map(PaperOrder.fromDb).toList(growable: false);
  }

  // -------------------------------------------------------------------------
  // Maintenance
  // -------------------------------------------------------------------------

  /// Wipes the paper account (orders, trades, positions) but leaves the
  /// instrument master, IPO database and settings intact.
  Future<void> clearPaperAccount() async {
    final db = await _db.database;
    final batch = db.batch();
    batch.delete(_trades);
    batch.delete(_positions);
    batch.delete(_orders);
    await batch.commit(noResult: true);
  }

  /// How much has been folded into the account — shown in Settings → Data as
  /// "paper account: N trades · M positions".
  Future<({int trades, int positions, int orders})> accountSize() async {
    final db = await _db.database;
    Future<int> count(String table) async {
      final rows = await db.rawQuery('SELECT COUNT(*) AS c FROM $table');
      return (rows.first['c'] as num?)?.toInt() ?? 0;
    }

    return (
      trades: await count(_trades),
      positions: await count(_positions),
      orders: await count(_orders),
    );
  }
}
