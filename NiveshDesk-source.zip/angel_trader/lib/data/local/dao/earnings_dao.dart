// ---------------------------------------------------------------------------
// earnings_dao.dart — the cached results calendar (schema v8).
//
// One row per symbol: when its last result was filed and — only if NSE carries
// a board-meeting intimation — when the next one is due. (Builds ≤ 1.5.12 also
// stored a *guessed* next date, flagged `estimated`; those are dropped here on
// read so an old cache can never show a made-up date again.)
// Written by EarningsCalendarService once a day; read by the study panel.
// ---------------------------------------------------------------------------

import 'package:sqflite/sqflite.dart';

import '../../../core/utils/formatters.dart' show Fmt;
import '../app_database.dart';
import '../../../services/earnings_calendar_service.dart' show EarningsInfo;

class EarningsDao {
  EarningsDao(this._db);

  final AppDatabase _db;

  static const String _table = AppDatabase.tableEarnings;

  /// The whole table — a few hundred rows for the F&O list, so this is cheap.
  Future<Map<String, EarningsInfo>> all() async {
    final db = await _db.database;
    final rows = await db.query(_table);
    final out = <String, EarningsInfo>{};
    for (final row in rows) {
      final symbol = '${row['symbol'] ?? ''}'.trim().toUpperCase();
      if (symbol.isEmpty) continue;
      final confirmed = (row['next_confirmed'] as num? ?? 0) == 1;
      final guessed = (row['estimated'] as num? ?? 0) == 1;
      // A next date NSE never announced is not a fact — drop it, keep the last
      // result. (Legacy rows only: nothing guesses any more.)
      final keepNext = confirmed && !guessed;
      out[symbol] = EarningsInfo(
        lastDate: Fmt.parseDate(row['last_date'] as String?),
        lastLabel: row['last_label'] as String? ?? '',
        nextDate: keepNext ? Fmt.parseDate(row['next_date'] as String?) : null,
        nextLabel: keepNext ? row['next_label'] as String? ?? '' : '',
        nextConfirmed: keepNext,
      );
    }
    return out;
  }

  /// Replaces the calendar in one transaction.
  Future<int> replaceAll(Map<String, EarningsInfo> calendar) async {
    final db = await _db.database;
    await db.transaction((txn) async {
      await txn.delete(_table);
      if (calendar.isEmpty) return;
      final batch = txn.batch();
      for (final entry in calendar.entries) {
        batch.insert(
          _table,
          {
            'symbol': entry.key.toUpperCase(),
            'last_date': _iso(entry.value.lastDate),
            'last_label': entry.value.lastLabel,
            'next_date': _iso(entry.value.nextDate),
            'next_label': entry.value.nextLabel,
            'next_confirmed': entry.value.nextConfirmed ? 1 : 0,
            'estimated': entry.value.estimated ? 1 : 0,
          },
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }
      await batch.commit(noResult: true);
    });
    return calendar.length;
  }

  Future<int> count() async {
    final db = await _db.database;
    return Sqflite.firstIntValue(
          await db.rawQuery('SELECT COUNT(*) FROM $_table'),
        ) ??
        0;
  }

  Future<void> clear() async {
    final db = await _db.database;
    await db.delete(_table);
  }

  static String? _iso(DateTime? date) => date == null ? null : Fmt.isoDate(date);
}
