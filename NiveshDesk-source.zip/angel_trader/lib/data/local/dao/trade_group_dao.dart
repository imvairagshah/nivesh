// ---------------------------------------------------------------------------
// trade_group_dao.dart — CRUD for trade groups + the group-wise P&L queries.
//
// Used by:
//   * the trade/order sheet        → the group picker ("+ New group" inline)
//   * Settings → Paper trading     → manage groups (add / rename / recolour /
//                                    archive / delete)
//   * Reports → "By group" tab     → [realizedByGroup], [monthlyByGroup],
//                                    [openExposureByGroup]
//
// Design points
//   * `group_id = NULL` is a real, reportable bucket: "Ungrouped". It has no row
//     in `trade_groups`, so it can never be renamed into a duplicate.
//   * Deleting a group never destroys trade history: its trades and positions are
//     reassigned (to another group, or to Ungrouped).
//   * Month bucketing happens in Dart against the IST calendar rather than in SQL
//     (`strftime` would silently use UTC and shift trades made before 05:30 IST
//     into the previous month).
// ---------------------------------------------------------------------------

import 'package:sqflite/sqflite.dart';

import '../../../core/utils/markets.dart';
import '../app_database.dart';
import '../models/trade_group.dart';

/// Realised P&L for one group in one month (powers the grouped bar chart).
class GroupMonthPnl {
  /// First day of the month, IST.
  final DateTime month;

  /// `null` == Ungrouped.
  final int? groupId;
  final String groupName;
  final int colorIndex;

  final double realizedPnl;
  final int closedTrades;

  const GroupMonthPnl({
    required this.month,
    required this.groupId,
    required this.groupName,
    required this.colorIndex,
    required this.realizedPnl,
    required this.closedTrades,
  });

  /// `2025-09` — stable key for chart series.
  String get monthKey =>
      '${month.year}-${month.month.toString().padLeft(2, '0')}';

  @override
  String toString() =>
      'GroupMonthPnl($monthKey, $groupName, ${realizedPnl.toStringAsFixed(2)})';
}

class TradeGroupDao {
  TradeGroupDao(this._db);

  final AppDatabase _db;

  static String get _groups => AppDatabase.tableTradeGroups;
  static String get _trades => AppDatabase.tableTrades;
  static String get _positions => AppDatabase.tablePositions;

  // -------------------------------------------------------------------------
  // Reads
  // -------------------------------------------------------------------------

  /// All groups, alphabetically. Archived groups are omitted unless asked for.
  Future<List<TradeGroup>> all({bool includeArchived = false}) async {
    final db = await _db.database;
    final rows = await db.query(
      _groups,
      where: includeArchived ? null : 'archived = 0',
      orderBy: 'archived ASC, name COLLATE NOCASE ASC',
    );
    return rows.map(TradeGroup.fromDb).toList(growable: false);
  }

  /// Groups ordered by recent usage — the order the trade sheet shows them in,
  /// so the ones you actually use are always at the top of the picker.
  Future<List<TradeGroup>> byUsage({bool includeArchived = false}) async {
    final db = await _db.database;
    final rows = await db.rawQuery('''
      SELECT g.*, COUNT(t.id) AS used
      FROM $_groups g
      LEFT JOIN $_trades t ON t.group_id = g.id
      ${includeArchived ? '' : 'WHERE g.archived = 0'}
      GROUP BY g.id
      ORDER BY used DESC, g.name COLLATE NOCASE ASC
    ''');
    return rows.map(TradeGroup.fromDb).toList(growable: false);
  }

  Future<TradeGroup?> byId(int id) async {
    final db = await _db.database;
    final rows = await db.query(_groups, where: 'id = ?', whereArgs: [id], limit: 1);
    return rows.isEmpty ? null : TradeGroup.fromDb(rows.first);
  }

  /// Case-insensitive duplicate check, used before insert/rename so the UI can
  /// show "you already have a group called Momentum" instead of a raw SQL error.
  Future<bool> nameExists(String name, {int? excludingId}) async {
    final db = await _db.database;
    final where = excludingId == null
        ? 'name = ? COLLATE NOCASE'
        : 'name = ? COLLATE NOCASE AND id <> ?';
    final args = excludingId == null ? <Object?>[name.trim()] : <Object?>[name.trim(), excludingId];
    final rows = await db.query(_groups, where: where, whereArgs: args, limit: 1);
    return rows.isNotEmpty;
  }

  /// How many trades/positions reference a group — drives the delete dialog
  /// ("12 trades will move to Ungrouped").
  Future<({int trades, int positions})> usageCount(int groupId) async {
    final db = await _db.database;
    final trades = Sqflite.firstIntValue(await db.rawQuery(
          'SELECT COUNT(*) FROM $_trades WHERE group_id = ?',
          [groupId],
        )) ??
        0;
    final positions = Sqflite.firstIntValue(await db.rawQuery(
          'SELECT COUNT(*) FROM $_positions WHERE group_id = ?',
          [groupId],
        )) ??
        0;
    return (trades: trades, positions: positions);
  }

  // -------------------------------------------------------------------------
  // Writes
  // -------------------------------------------------------------------------

  /// Creates a group. Throws [ArgumentError] on an invalid or duplicate name so
  /// the caller can surface a precise message.
  Future<int> create(TradeGroup group) async {
    final errors = TradeGroup.validateName(group.name);
    if (errors.isNotEmpty) throw ArgumentError(errors.first);
    if (await nameExists(group.name)) {
      throw ArgumentError('A group called "${group.name.trim()}" already exists.');
    }

    final db = await _db.database;
    final values = group.toDb()..remove('id');
    values['created_at'] = DateTime.now().millisecondsSinceEpoch;
    return db.insert(_groups, values);
  }

  /// Convenience used by the trade sheet's "+ New group": creates the group and
  /// returns it ready to be selected.
  Future<TradeGroup> createNamed(
    String name, {
    String notes = '',
    int? colorIndex,
  }) async {
    final existing = await all(includeArchived: true);
    final id = await create(TradeGroup(
      name: name.trim(),
      notes: notes,
      colorIndex: colorIndex ?? TradeGroup.suggestColorIndex(existing.length),
      createdAt: DateTime.now(),
    ));
    return (await byId(id))!;
  }

  /// Renames / recolours / re-notes an existing group.
  Future<void> update(TradeGroup group) async {
    final id = group.id;
    if (id == null) throw ArgumentError('Cannot update an unsaved group.');
    final errors = TradeGroup.validateName(group.name);
    if (errors.isNotEmpty) throw ArgumentError(errors.first);
    if (await nameExists(group.name, excludingId: id)) {
      throw ArgumentError('A group called "${group.name.trim()}" already exists.');
    }

    final db = await _db.database;
    final values = group.toDb()..remove('id');
    await db.update(_groups, values, where: 'id = ?', whereArgs: [id]);
  }

  /// Hides a group from the picker without touching its history.
  Future<void> archive(int id, {bool archived = true}) async {
    final db = await _db.database;
    await db.update(_groups, {'archived': archived ? 1 : 0},
        where: 'id = ?', whereArgs: [id]);
  }

  /// Deletes a group and reassigns its trades/positions.
  ///
  /// [reassignTo] = another group id, or `null` for Ungrouped (the default).
  /// Returns how many rows were moved, for the confirmation message.
  Future<({int trades, int positions})> delete(
    int id, {
    int? reassignTo,
  }) async {
    final db = await _db.database;
    final before = await usageCount(id);

    await db.transaction((txn) async {
      await txn.update(_trades, {'group_id': reassignTo},
          where: 'group_id = ?', whereArgs: [id]);
      await txn.update(_positions, {'group_id': reassignTo},
          where: 'group_id = ?', whereArgs: [id]);
      await txn.delete(_groups, where: 'id = ?', whereArgs: [id]);
    });

    return before;
  }

  // -------------------------------------------------------------------------
  // Group-wise P&L
  // -------------------------------------------------------------------------

  /// Realised P&L per group for the whole book (or a date window).
  ///
  /// Only closing legs count: a trade contributes when `realized_pnl` is set,
  /// which the paper-trading service fills on the sell that closes a position.
  Future<List<GroupPnlSummary>> realizedByGroup({
    DateTime? from,
    DateTime? to,
  }) async {
    final db = await _db.database;
    final where = <String>['t.realized_pnl IS NOT NULL'];
    final args = <Object?>[];
    if (from != null) {
      where.add('t.executed_at >= ?');
      args.add(from.millisecondsSinceEpoch);
    }
    if (to != null) {
      where.add('t.executed_at <= ?');
      args.add(to.millisecondsSinceEpoch);
    }

    final rows = await db.rawQuery('''
      SELECT t.group_id                                   AS gid,
             COALESCE(g.name, '$kUngroupedLabel')         AS gname,
             COALESCE(g.color_index, 0)                   AS color,
             SUM(t.realized_pnl)                          AS realized,
             COUNT(*)                                     AS closed,
             SUM(CASE WHEN t.realized_pnl > 0 THEN 1 ELSE 0 END) AS wins,
             SUM(CASE WHEN t.realized_pnl < 0 THEN 1 ELSE 0 END) AS losses,
             SUM(CASE WHEN t.realized_pnl > 0 THEN t.realized_pnl ELSE 0 END) AS gross_profit,
             SUM(CASE WHEN t.realized_pnl < 0 THEN t.realized_pnl ELSE 0 END) AS gross_loss,
             MAX(t.realized_pnl)                          AS best,
             MIN(t.realized_pnl)                          AS worst
      FROM $_trades t
      LEFT JOIN $_groups g ON g.id = t.group_id
      WHERE ${where.join(' AND ')}
      GROUP BY t.group_id
      ORDER BY realized DESC
    ''', args);

    final summaries = <GroupPnlSummary>[];
    for (final row in rows) {
      final groupId = (row['gid'] as num?)?.toInt();
      final exposure = await _openExposure(db, groupId);
      summaries.add(GroupPnlSummary(
        groupId: groupId,
        groupName: '${row['gname']}',
        colorIndex: (row['color'] as num?)?.toInt() ?? 0,
        realizedPnl: (row['realized'] as num?)?.toDouble() ?? 0,
        closedTrades: (row['closed'] as num?)?.toInt() ?? 0,
        wins: (row['wins'] as num?)?.toInt() ?? 0,
        losses: (row['losses'] as num?)?.toInt() ?? 0,
        grossProfit: (row['gross_profit'] as num?)?.toDouble() ?? 0,
        grossLoss: (row['gross_loss'] as num?)?.toDouble() ?? 0,
        biggestWin: (row['best'] as num?)?.toDouble() ?? 0,
        biggestLoss: (row['worst'] as num?)?.toDouble() ?? 0,
        openInvestedValue: exposure.invested,
        openPositionCount: exposure.count,
      ));
    }
    return summaries;
  }

  /// Groups that currently hold open positions but have no realised P&L yet
  /// (a freshly opened basket) — merged into the report so it does not look like
  /// the group "disappeared".
  Future<List<GroupPnlSummary>> openExposureByGroup() async {
    final db = await _db.database;
    final rows = await db.rawQuery('''
      SELECT p.group_id                            AS gid,
             COALESCE(g.name, '$kUngroupedLabel')  AS gname,
             COALESCE(g.color_index, 0)            AS color,
             SUM(p.quantity * p.avg_price)         AS invested,
             COUNT(*)                              AS cnt
      FROM $_positions p
      LEFT JOIN $_groups g ON g.id = p.group_id
      WHERE p.status = 'OPEN'
      GROUP BY p.group_id
      ORDER BY invested DESC
    ''');

    return rows
        .map((row) => GroupPnlSummary(
              groupId: (row['gid'] as num?)?.toInt(),
              groupName: '${row['gname']}',
              colorIndex: (row['color'] as num?)?.toInt() ?? 0,
              openInvestedValue: (row['invested'] as num?)?.toDouble() ?? 0,
              openPositionCount: (row['cnt'] as num?)?.toInt() ?? 0,
            ))
        .toList(growable: false);
  }

  /// Realised P&L per group **per month** — the data behind the grouped bar
  /// chart in Reports.
  ///
  /// Bucketing is done in Dart so month boundaries follow IST, matching every
  /// other date in the app.
  Future<List<GroupMonthPnl>> monthlyByGroup({
    DateTime? from,
    DateTime? to,
    bool includeUngrouped = true,
  }) async {
    final db = await _db.database;
    final where = <String>['t.realized_pnl IS NOT NULL'];
    final args = <Object?>[];
    if (from != null) {
      where.add('t.executed_at >= ?');
      args.add(from.millisecondsSinceEpoch);
    }
    if (to != null) {
      where.add('t.executed_at <= ?');
      args.add(to.millisecondsSinceEpoch);
    }

    final rows = await db.rawQuery('''
      SELECT t.group_id                            AS gid,
             COALESCE(g.name, '$kUngroupedLabel')  AS gname,
             COALESCE(g.color_index, 0)            AS color,
             t.executed_at                         AS at,
             t.realized_pnl                        AS pnl
      FROM $_trades t
      LEFT JOIN $_groups g ON g.id = t.group_id
      WHERE ${where.join(' AND ')}
      ORDER BY t.executed_at ASC
    ''', args);

    // monthKey|groupId → running totals
    final buckets = <String, GroupMonthPnl>{};
    for (final row in rows) {
      final executedAt = DateTime.fromMillisecondsSinceEpoch(
        (row['at'] as num).toInt(),
        isUtc: true,
      );
      final ist = MarketCalendar.istFromUtc(executedAt);
      final month = DateTime(ist.year, ist.month);
      final groupId = (row['gid'] as num?)?.toInt();
      if (groupId == null && !includeUngrouped) continue;

      final key = '${month.year}-${month.month}|$groupId';
      final existing = buckets[key];
      final pnl = (row['pnl'] as num?)?.toDouble() ?? 0;

      buckets[key] = GroupMonthPnl(
        month: month,
        groupId: groupId,
        groupName: '${row['gname']}',
        colorIndex: (row['color'] as num?)?.toInt() ?? 0,
        realizedPnl: (existing?.realizedPnl ?? 0) + pnl,
        closedTrades: (existing?.closedTrades ?? 0) + 1,
      );
    }

    final list = buckets.values.toList()
      ..sort((a, b) {
        final byMonth = a.month.compareTo(b.month);
        return byMonth != 0 ? byMonth : a.groupName.compareTo(b.groupName);
      });
    return list;
  }

  /// Open exposure (invested value + position count) for one group — `null`
  /// groupId means Ungrouped.
  Future<({double invested, int count})> _openExposure(
    Database db,
    int? groupId,
  ) async {
    final where = groupId == null ? 'status = ? AND group_id IS NULL' : 'status = ? AND group_id = ?';
    final args = groupId == null ? <Object?>['OPEN'] : <Object?>['OPEN', groupId];
    final rows = await db.rawQuery(
      'SELECT COALESCE(SUM(quantity * avg_price), 0) AS invested, COUNT(*) AS cnt '
      'FROM $_positions WHERE $where',
      args,
    );
    if (rows.isEmpty) return (invested: 0.0, count: 0);
    return (
      invested: (rows.first['invested'] as num?)?.toDouble() ?? 0,
      count: (rows.first['cnt'] as num?)?.toInt() ?? 0,
    );
  }
}
