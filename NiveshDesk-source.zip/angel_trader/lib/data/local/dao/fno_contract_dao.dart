// ---------------------------------------------------------------------------
// fno_contract_dao.dart — the local option-contract book.
//
// Angel's scrip master lists every option contract the exchange trades
// (~100k+ rows). The F&O module needs exactly three questions answered, fast and
// offline:
//
//   1. which expiries exist for RELIANCE?          → [expiries]
//   2. what does its chain look like on that date? → [chainOn]
//   3. which token is the 2650 CE?                 → [contract]
//
// So the master refresh keeps only the *near* expiries per underlying (see
// `FnoContractCollector`) and writes them here. Everything below is a plain
// SQLite read — the study never waits for the network to pick a strike.
// ---------------------------------------------------------------------------

import 'package:sqflite/sqflite.dart';

import '../../../core/utils/formatters.dart';
import '../../../core/utils/markets.dart' show Exchange, MarketCalendar;
import '../../remote/dto/scrip.dart' show Scrip;
import '../app_database.dart';

/// One option contract as stored.
class FnoContract {
  final int? id;
  final String underlying;

  /// Broker format (`26JAN2026`) — what the greeks endpoint wants.
  ///
  /// **Not stored**: it is a pure function of [expiryDate] (see [labelFor]).
  final String expiryLabel;

  /// `2026-01-26` — what sorting and expiry maths want.
  final DateTime expiryDate;

  /// Strike in **rupees** (`2650.0`).
  final double strike;

  /// `CE` | `PE`.
  final String optionType;

  final String token;

  /// Broker symbol (`RELIANCE26JAN2650CE`).
  final String symbol;

  final int lotSize;

  const FnoContract({
    required this.underlying,
    required this.expiryLabel,
    required this.expiryDate,
    required this.strike,
    required this.optionType,
    required this.token,
    this.symbol = '',
    this.lotSize = 0,
    this.id,
  });

  bool get isCall => optionType == 'CE';

  /// The [Scrip] to hand to the quote / greeks layer.
  Scrip asScrip() => Scrip(
    token: token,
    symbol: symbol.isEmpty ? '$underlying$optionType' : symbol,
    name: underlying,
    exchange: Exchange.nfo,
  );

  Map<String, Object?> toDb() => {
    if (id != null) 'id': id,
    'underlying': underlying,
    'expiry_date': Fmt.isoDate(expiryDate),
    'strike': strike,
    'option_type': optionType,
    'token': token,
    'symbol': symbol,
    'lot_size': lotSize,
  };

  /// `2026-01-26` → `26JAN2026`, the exact string the broker's greeks endpoint
  /// expects as `expirydate`.
  ///
  /// The label used to be a stored column, which was pure waste: the master's
  /// label is *parsed* into [expiryDate] in the first place, so reassembling it
  /// is lossless for every label the master can produce
  /// (`labelFor(parseExpiry('26JAN2026')) == '26JAN2026'`).
  static String labelFor(DateTime date) =>
      '${date.day.toString().padLeft(2, '0')}'
      '${_monthNames[date.month - 1]}'
      '${date.year.toString().padLeft(4, '0')}';

  static const List<String> _monthNames = [
    'JAN',
    'FEB',
    'MAR',
    'APR',
    'MAY',
    'JUN',
    'JUL',
    'AUG',
    'SEP',
    'OCT',
    'NOV',
    'DEC',
  ];

  static FnoContract fromDb(Map<String, Object?> row) {
    final expiry =
        Fmt.parseDate(row['expiry_date'] as String?) ?? DateTime(2015);
    return FnoContract(
      id: row['id'] as int?,
      underlying: (row['underlying'] as String? ?? '').toUpperCase(),
      expiryLabel: labelFor(expiry),
      expiryDate: expiry,
      strike: (row['strike'] as num? ?? 0).toDouble(),
      optionType: (row['option_type'] as String? ?? 'CE').toUpperCase(),
      token: row['token'] as String? ?? '',
      symbol: row['symbol'] as String? ?? '',
      lotSize: (row['lot_size'] as num? ?? 0).toInt(),
    );
  }

  @override
  String toString() => '$underlying $expiryLabel $strike$optionType';
}

/// The two legs of one ATM strike.
class AtmPair {
  final double strike;
  final String expiryLabel;
  final DateTime expiryDate;
  final FnoContract? ce;
  final FnoContract? pe;

  const AtmPair({
    required this.strike,
    required this.expiryLabel,
    required this.expiryDate,
    this.ce,
    this.pe,
  });

  bool get isComplete => ce != null && pe != null;
  int get lotSize => ce?.lotSize ?? pe?.lotSize ?? 0;

  /// Stock ticker (also the option chain's `name` field).
  String get underlying => ce?.underlying ?? pe?.underlying ?? '';
}

class FnoContractDao {
  FnoContractDao(this._db);

  final AppDatabase _db;

  static const String _table = AppDatabase.tableFnoContracts;

  Future<int> count() async {
    final db = await _db.database;
    final rows = await db.rawQuery('SELECT COUNT(*) AS c FROM $_table');
    return Sqflite.firstIntValue(rows) ?? 0;
  }

  /// How many underlyings the book covers (the picker shows "chain ready" only
  /// when this is non-zero).
  Future<int> underlyingCount() async {
    final db = await _db.database;
    final rows = await db.rawQuery(
      'SELECT COUNT(DISTINCT underlying) AS c FROM $_table',
    );
    return Sqflite.firstIntValue(rows) ?? 0;
  }

  /// Distinct underlyings — the F&O stock universe (news filter, 1.5.68).
  Future<List<String>> allUnderlyings() async {
    final db = await _db.database;
    final rows = await db.rawQuery(
      'SELECT DISTINCT underlying FROM $_table ORDER BY underlying ASC',
    );
    return [for (final row in rows) '${row['underlying']}'];
  }

  /// Replaces the whole book (a master refresh rebuilds it from scratch).
  ///
  /// Inserted in batches inside one transaction: the table holds tens of
  /// thousands of rows and a per-row transaction would take minutes.
  Future<int> replaceAll(
    List<FnoContract> contracts, {
    int batchSize = 500,
  }) async {
    final db = await _db.database;
    await db.delete(_table);
    if (contracts.isEmpty) return 0;

    var written = 0;
    for (var i = 0; i < contracts.length; i += batchSize) {
      final end = (i + batchSize) > contracts.length
          ? contracts.length
          : i + batchSize;
      final slice = contracts.sublist(i, end);
      await db.transaction((txn) async {
        final batch = txn.batch();
        for (final contract in slice) {
          batch.insert(
            _table,
            contract.toDb(),
            conflictAlgorithm: ConflictAlgorithm.replace,
          );
        }
        await batch.commit(noResult: true);
      });
      written += slice.length;
    }
    return written;
  }

  /// Expiry dates available for [underlying], soonest first.
  ///
  /// [from] defaults to today's IST date so an expired series is never selected.
  Future<List<DateTime>> expiries(String underlying, {DateTime? from}) async {
    final db = await _db.database;
    final cutoff = Fmt.isoDate(from ?? MarketCalendar.nowIst());
    final rows = await db.rawQuery(
      'SELECT DISTINCT expiry_date FROM $_table '
      'WHERE underlying = ? AND expiry_date >= ? ORDER BY expiry_date ASC',
      [underlying.toUpperCase(), cutoff],
    );
    return [
      for (final row in rows)
        Fmt.parseDate(row['expiry_date'] as String?) ?? DateTime(2015),
    ];
  }

  /// The next stock-option expiries in the local book, soonest first.
  ///
  /// The book is populated only from NFO `OPTSTK` rows; index weekly expiries
  /// are excluded by the scrip-master collector. The 3-Month Study uses the
  /// first three dates for its selector.
  Future<List<DateTime>> upcomingStockExpiries({
    DateTime? from,
    int limit = 3,
  }) async {
    if (limit <= 0) return const [];
    final db = await _db.database;
    final cutoff = Fmt.isoDate(from ?? MarketCalendar.nowIst());
    final rows = await db.rawQuery(
      'SELECT DISTINCT expiry_date FROM $_table '
      'WHERE expiry_date >= ? ORDER BY expiry_date ASC LIMIT ?',
      [cutoff, limit],
    );
    final dates = <DateTime>[];
    for (final row in rows) {
      final date = Fmt.parseDate(row['expiry_date'] as String?);
      if (date != null) dates.add(date);
    }
    return dates;
  }

  /// Every contract of one expiry, strikes ascending.
  Future<List<FnoContract>> chainOn(String underlying, DateTime expiry) async {
    final db = await _db.database;
    final rows = await db.query(
      _table,
      where: 'underlying = ? AND expiry_date = ?',
      whereArgs: [underlying.toUpperCase(), Fmt.isoDate(expiry)],
      orderBy: 'strike ASC, option_type ASC',
    );
    return rows.map(FnoContract.fromDb).toList(growable: false);
  }

  /// A single contract, if the book has it.
  Future<FnoContract?> contract({
    required String underlying,
    required DateTime expiry,
    required double strike,
    required String optionType,
  }) async {
    final db = await _db.database;
    final rows = await db.query(
      _table,
      where:
          'underlying = ? AND expiry_date = ? AND strike = ? AND option_type = ?',
      whereArgs: [
        underlying.toUpperCase(),
        Fmt.isoDate(expiry),
        strike,
        optionType.toUpperCase(),
      ],
      limit: 1,
    );
    return rows.isEmpty ? null : FnoContract.fromDb(rows.first);
  }

  /// The selected (or, when omitted, nearest) expiry's ATM CE/PE pair for
  /// [underlying].
  ///
  /// The strike is chosen against [spot]: the closest strike at or around the
  /// money, exactly as the spec defines ATM. A requested expiry is never
  /// silently replaced by another one; a missing chain returns `null` so the
  /// caller can keep the stock in degraded mode.
  Future<AtmPair?> atmPair({
    required String underlying,
    required double spot,
    DateTime? asOf,
    DateTime? selectedExpiry,
  }) async {
    final dates = await expiries(underlying, from: asOf);
    if (dates.isEmpty) return null;

    DateTime? expiry;
    if (selectedExpiry == null) {
      expiry = dates.first;
    } else {
      final selectedKey = Fmt.isoDate(selectedExpiry);
      for (final candidate in dates) {
        if (Fmt.isoDate(candidate) == selectedKey) {
          expiry = candidate;
          break;
        }
      }
    }
    if (expiry == null) return null;

    final chain = await chainOn(underlying, expiry);
    if (chain.isEmpty) return null;

    FnoContract? nearest;
    var bestDistance = double.infinity;
    for (final contract in chain) {
      final distance = (contract.strike - spot).abs();
      if (distance < bestDistance) {
        bestDistance = distance;
        nearest = contract;
      }
    }
    if (nearest == null) return null;

    final strike = nearest.strike;
    FnoContract? ce;
    FnoContract? pe;
    for (final contract in chain) {
      if (contract.strike != strike) continue;
      if (contract.isCall) ce = contract;
      if (!contract.isCall) pe = contract;
    }

    return AtmPair(
      strike: strike,
      expiryLabel: nearest.expiryLabel,
      expiryDate: expiry,
      ce: ce,
      pe: pe,
    );
  }

  /// Drops contracts whose expiry has passed (housekeeping after a refresh).
  Future<int> pruneExpired({DateTime? before}) async {
    final db = await _db.database;
    return db.delete(
      _table,
      where: 'expiry_date < ?',
      whereArgs: [Fmt.isoDate(before ?? MarketCalendar.nowIst())],
    );
  }
}
