import 'package:sqflite/sqflite.dart';

import '../../../features/magic_formula/magic_formula_models.dart';
import '../app_database.dart';

/// A user-named basket: a list of chosen stocks (NSE and/or BSE) that the
/// Magic Formula screen can scan on its own. Purely local — SQLite only.
class MagicBasket {
  const MagicBasket({
    required this.id,
    required this.name,
    required this.createdAt,
    this.itemCount = 0,
  });

  final int id;
  final String name;

  /// Epoch millis — when the basket was created.
  final int createdAt;

  /// Denormalized count for list rows (joined on read).
  final int itemCount;

  MagicBasket copyWith({String? name, int? itemCount}) => MagicBasket(
    id: id,
    name: name ?? this.name,
    createdAt: createdAt,
    itemCount: itemCount ?? this.itemCount,
  );

  factory MagicBasket.fromDb(Map<String, dynamic> row) => MagicBasket(
    id: (row['id'] as num?)?.toInt() ?? 0,
    name: '${row['name']}',
    createdAt: (row['created_at'] as num?)?.toInt() ?? 0,
    itemCount: (row['item_count'] as num?)?.toInt() ?? 0,
  );
}

/// One stock inside a basket. The exchange + symbol pair identifies it;
/// [isin]/[scripCode] are carried when known so a scan can go straight to the
/// official feeds without re-resolving.
class MagicBasketItem {
  const MagicBasketItem({
    required this.id,
    required this.basketId,
    required this.symbol,
    required this.exchange,
    required this.companyName,
    this.isin = '',
    this.scripCode = '',
    required this.addedAt,
  });

  final int id;
  final int basketId;
  final String symbol;

  /// 'NSE' or 'BSE'.
  final String exchange;
  final String companyName;
  final String isin;

  /// BSE six-digit scrip code when the row is a BSE row (or dual-listed).
  final String scripCode;
  final int addedAt;

  /// The scan identity of this row: `EXCHANGE:SYMBOL` (see
  /// [MagicFormulaCandidate.cacheKey]).
  String get cacheKey => '$exchange:$symbol';

  /// Candidate for the official-data scan pipeline.
  MagicFormulaCandidate toCandidate() => MagicFormulaCandidate(
    symbol: symbol,
    companyName: companyName,
    exchange: exchange,
    sector: '',
    industry: '',
    isin: isin,
    // The BSE pipeline resolves the six-digit scrip code from the data
    // symbol; NSE rows use their ticker as the data symbol. (Dropping the
    // scrip code here once cost every basket-added BSE row its filings.)
    dataSymbol: exchange == 'NSE' ? symbol : scripCode,
    dataCompanyName: companyName,
  );

  factory MagicBasketItem.fromDb(Map<String, dynamic> row) => MagicBasketItem(
    id: (row['id'] as num?)?.toInt() ?? 0,
    basketId: (row['basket_id'] as num?)?.toInt() ?? 0,
    symbol: '${row['symbol']}',
    exchange: '${row['exchange']}',
    companyName: '${row['company_name'] ?? ''}',
    isin: '${row['isin'] ?? ''}',
    scripCode: '${row['scrip_code'] ?? ''}',
    addedAt: (row['added_at'] as num?)?.toInt() ?? 0,
  );
}

/// CRUD for baskets and their items. Every method is local — no network.
class MagicBasketDao {
  MagicBasketDao(this._db);

  final AppDatabase _db;

  Future<List<MagicBasket>> allBaskets() async {
    final db = await _db.database;
    final rows = await db.rawQuery(
      'SELECT b.*, (SELECT COUNT(*) FROM ${AppDatabase.tableMagicBasketItems} '
      'i WHERE i.basket_id = b.id) AS item_count '
      'FROM ${AppDatabase.tableMagicBaskets} b ORDER BY b.id',
    );
    return rows.map(MagicBasket.fromDb).toList(growable: false);
  }

  Future<MagicBasket?> basket(int id) async {
    final db = await _db.database;
    final rows = await db.rawQuery(
      'SELECT b.*, (SELECT COUNT(*) FROM ${AppDatabase.tableMagicBasketItems} '
      'i WHERE i.basket_id = b.id) AS item_count '
      'FROM ${AppDatabase.tableMagicBaskets} b WHERE b.id = ?',
      [id],
    );
    return rows.isEmpty ? null : MagicBasket.fromDb(rows.first);
  }

  Future<MagicBasket> createBasket(String name) async {
    final db = await _db.database;
    final id = await db.insert(AppDatabase.tableMagicBaskets, {
      'name': name.trim(),
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
    return MagicBasket(
      id: id,
      name: name.trim(),
      createdAt: DateTime.now().millisecondsSinceEpoch,
    );
  }

  Future<void> renameBasket(int id, String name) async {
    final db = await _db.database;
    await db.update(
      AppDatabase.tableMagicBaskets,
      {'name': name.trim()},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> deleteBasket(int id) async {
    final db = await _db.database;
    await db.delete(
      AppDatabase.tableMagicBaskets,
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<List<MagicBasketItem>> items(int basketId) async {
    final db = await _db.database;
    final rows = await db.query(
      AppDatabase.tableMagicBasketItems,
      where: 'basket_id = ?',
      whereArgs: [basketId],
      orderBy: 'id',
    );
    return rows.map(MagicBasketItem.fromDb).toList(growable: false);
  }

  /// Adds a stock; an existing (basket, exchange, symbol) row is returned as
  /// `false` and left untouched — no duplicates.
  Future<bool> addItem(MagicBasketItem item) async {
    final db = await _db.database;
    try {
      final id = await db.insert(
        AppDatabase.tableMagicBasketItems,
        {
          'basket_id': item.basketId,
          'symbol': item.symbol,
          'exchange': item.exchange,
          'company_name': item.companyName,
          'isin': item.isin,
          'scrip_code': item.scripCode,
          'added_at': item.addedAt,
        },
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
      return id != 0;
    } on DatabaseException {
      return false;
    }
  }

  Future<void> removeItem(int itemId) async {
    final db = await _db.database;
    await db.delete(
      AppDatabase.tableMagicBasketItems,
      where: 'id = ?',
      whereArgs: [itemId],
    );
  }

  Future<void> clearItems(int basketId) async {
    final db = await _db.database;
    await db.delete(
      AppDatabase.tableMagicBasketItems,
      where: 'basket_id = ?',
      whereArgs: [basketId],
    );
  }
}
