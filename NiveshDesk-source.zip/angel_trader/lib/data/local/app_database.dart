// ---------------------------------------------------------------------------
// app_database.dart — SQLite schema + connection for the whole app.
//
// Everything the app knows lives here (no server):
//   ipos        – the IPO database the screener works from (seed CSV + manual)
//   scrips      – cached Angel One scrip master (token lookup)
//   settings    – user preferences (capital, band %, theme …)
//   price_cache – last known LTP per symbol, so the UI works offline
//   scan_runs   – cached screener output (offline view + "as of" labels)
//   candles     – daily bars cached by the Golden Cross screener
//   trades / positions – paper-trading ledger (Feature 3)
//   paper_orders – submitted paper orders, incl. resting LIMIT orders (v3)
// ---------------------------------------------------------------------------

import 'dart:io';

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

class AppDatabase {
  AppDatabase._();

  static final AppDatabase instance = AppDatabase._();

  static const String dbFileName = 'angel_trader.db';
  static const int schemaVersion = 16;

  /// Table names, so DAOs never hard-code strings twice.
  static const String tableIpos = 'ipos';
  static const String tableScrips = 'scrips';

  /// Option contracts (underlying · expiry · strike · CE/PE) parsed out of the
  /// broker's scrip master — what the F&O module needs to turn an ATM strike
  /// into a tradeable token. Only the near expiries are kept; see
  /// `FnoContractCollector`.
  static const String tableFnoContracts = 'fno_contracts';

  /// Results calendar (last/next quarterly result per symbol) — v8.
  static const String tableEarnings = 'earnings';

  static const String tableScripMeta = 'scrip_meta';
  static const String tableSettings = 'settings';
  static const String tablePriceCache = 'price_cache';
  static const String tableScanRuns = 'scan_runs';
  static const String tableCandles = 'candles';
  static const String tableTradeGroups = 'trade_groups';
  static const String tableTrades = 'trades';
  static const String tablePositions = 'positions';
  static const String tablePaperOrders = 'paper_orders';

  /// Har stock ke **pichle announced results** ki suchi (naye se purane) —
  /// "is stock ke pichle result din me kya hua tha?" (Result playbook) ke liye.
  /// Ek stock = kai line (har result ek line), isliye alag taalika.
  static const String tableResultHistory = 'result_history';

  /// Study snapshots — "us din study ne kya kaha tha", "Mera hisaab" ke liye.
  /// Ek run = poore universe ki ek line per stock; agla run purana mita deta hai.
  static const String tableStudySnapshots = 'study_snapshots';

  /// Cached Magic Formula inputs from official filing/market data (v12+).
  static const String tableMagicFormulaFundamentals =
      'magic_formula_fundamentals';

  /// User baskets for the Magic Formula screen (v15): a named list of chosen
  /// stocks (NSE and/or BSE) that can be scanned on its own.
  static const String tableMagicBaskets = 'magic_baskets';
  static const String tableMagicBasketItems = 'magic_basket_items';

  /// Options Calls Board (v16, standalone module): user-added public Telegram
  /// channels and the buy/sell calls captured from them.
  static const String tableCallsChannels = 'calls_channels';
  static const String tableOptionCalls = 'option_calls';

  Database? _db;
  String? _path;

  /// Test seam: when set, the database opens at this path instead of the
  /// platform's databases directory. DAO tests point this at
  /// `inMemoryDatabasePath` (see test/data/dao_test.dart).
  static String? overridePath;

  /// Full path of the database file (shown in Settings → Diagnostics).
  String? get path => _path;

  Future<Database> get database async => _db ??= await _open();

  /// Desktop (Windows/Linux/macOS) — 1.5.72 exe build. Mobile par sqflite ka
  /// apna platform engine hai; desktop par ffi factory + bundled sqlite3, aur
  /// database user ke AppSupport folder me (reinstall me bhi safe).
  static bool get _isDesktop {
    if (kIsWeb) return false;
    return Platform.isWindows || Platform.isLinux || Platform.isMacOS;
  }

  Future<Database> _open() async {
    if (overridePath == null && _isDesktop) {
      sqfliteFfiInit();
      databaseFactory = databaseFactoryFfi;
      String dirPath;
      try {
        dirPath = (await getApplicationSupportDirectory()).path;
      } catch (_) {
        // path_provider ke bina (tests/desktop smoke) — system temp.
        dirPath = Directory.systemTemp.path;
      }
      final folder = Directory(p.join(dirPath, 'niveshdesk'));
      await folder.create(recursive: true);
      _path = p.join(folder.path, dbFileName);
    } else {
      _path = overridePath ?? p.join(await getDatabasesPath(), dbFileName);
    }
    final file = _path!;

    return openDatabase(
      file,
      version: schemaVersion,
      onConfigure: (db) async {
        // Needed for the trades → positions cascade in Feature 3.
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: (db, version) async {
        await createSchema(db);
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        // Migrations are additive; Feature 3's tables ship in v1 already, so
        // v2 will simply append another case here. A step is either a SQL
        // string or a callback for the rare migration that needs to look at the
        // database first (v7 rewrites tables that do not exist in very old
        // builds, and an upgrade from v1 must still work).
        for (var v = oldVersion + 1; v <= newVersion; v++) {
          for (final step in _migrations[v] ?? const <Object>[]) {
            if (step is String) {
              await db.execute(step);
            } else if (step is Future<void> Function(Database)) {
              await step(db);
            }
          }
        }
      },
    );
  }

  /// Builds the whole schema inside an already-open (empty) database.
  ///
  /// Seam for the paper-trading "DB file" export: a filtered export creates a
  /// brand-new file and needs the exact same tables before it can copy the
  /// chosen rows into it.
  static Future<void> createSchema(Database db) async {
    final batch = db.batch();
    for (final statement in _createStatements) {
      batch.execute(statement);
    }
    await batch.commit(noResult: true);
  }

  /// Closes the connection (used by "Clear local data" and on logout).
  Future<void> close() async {
    await _db?.close();
    _db = null;
  }

  /// Deletes the database file and reopens a fresh one.
  Future<void> wipe() async {
    await close();
    final file = _path;
    if (file != null) await deleteDatabase(file);
    _db = null;
    await database; // recreate the schema immediately
  }

  /// On-disk size of the database file (pages × page size).
  ///
  /// Used by Settings → Storage so the user can see what the app actually
  /// costs instead of guessing from the 34 MB master download.
  Future<int> sizeBytes() async {
    final db = await database;
    final pageCount =
        Sqflite.firstIntValue(await db.rawQuery('PRAGMA page_count')) ?? 0;
    final pageSize =
        Sqflite.firstIntValue(await db.rawQuery('PRAGMA page_size')) ?? 0;
    return pageCount * pageSize;
  }

  /// Rebuilds the file, reclaiming the pages freed by deleted rows and dropped
  /// columns, and returns the bytes saved.
  ///
  /// Called after a master refresh (which clears and rewrites ~40k rows) and
  /// from the Settings → Storage button. SQLite refuses to VACUUM inside a
  /// transaction, so this must never be called from a migration or from inside
  /// a DAO transaction.
  Future<int> vacuum() async {
    final before = await sizeBytes();
    final db = await database;
    await db.execute('VACUUM');
    final after = await sizeBytes();
    // A rebuild can round the file up a page or two on a tiny database — the
    // caller only ever prints this, so a freeing that freed nothing is a 0.
    final freed = before - after;
    return freed > 0 ? freed : 0;
  }

  // -------------------------------------------------------------------------
  // Schema
  // -------------------------------------------------------------------------

  static const List<String> _createStatements = [
    // ---- IPO database (Feature 1) -----------------------------------------
    '''
    CREATE TABLE $tableIpos (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      symbol        TEXT    NOT NULL,
      company_name  TEXT    NOT NULL DEFAULT '',
      exchange      TEXT    NOT NULL DEFAULT 'NSE',
      listing_date  TEXT    NOT NULL,              -- yyyy-MM-dd
      listing_high  REAL    NOT NULL,
      listing_low   REAL    NOT NULL,
      -- The security's stable identity: an exchange may rename a company and
      -- its ticker (LTIM → LTM, AMIORG → ACUTAAS) but the ISIN stays. Empty for
      -- rows where no master knows one (delisted names).
      isin          TEXT    NOT NULL DEFAULT '',
      sector        TEXT    NOT NULL DEFAULT '',
      notes         TEXT    NOT NULL DEFAULT '',
      is_custom     INTEGER NOT NULL DEFAULT 0,    -- 1 = added/edited by the user
      -- '' pending · 'seed' shipped+verified · 'user' typed · 'auto' fetched
      -- from daily candles · 'missing' market data had nothing (see
      -- ListingLevelsService).
      levels_source TEXT    NOT NULL DEFAULT '',
      updated_at    INTEGER NOT NULL DEFAULT 0
    )
    ''',
    'CREATE UNIQUE INDEX idx_ipos_symbol ON $tableIpos(symbol, exchange)',
    'CREATE INDEX idx_ipos_listing_date ON $tableIpos(listing_date)',
    'CREATE INDEX idx_ipos_isin ON $tableIpos(isin)',

    // ---- F&O option contracts (F&O module) --------------------------------
    '''
    CREATE TABLE $tableFnoContracts (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      underlying   TEXT    NOT NULL,             -- RELIANCE (broker's `name` field)
      expiry_date  TEXT    NOT NULL,             -- 2026-01-26, for sorting/expiry math
      strike       REAL    NOT NULL,             -- rupees (master's paise × 100 removed)
      option_type  TEXT    NOT NULL,             -- CE | PE
      token        TEXT    NOT NULL,
      symbol       TEXT    NOT NULL DEFAULT '',  -- RELIANCE26JAN2650CE
      lot_size     INTEGER NOT NULL DEFAULT 0
    )
    ''',
    'CREATE UNIQUE INDEX idx_fno_contract ON '
        '$tableFnoContracts(underlying, expiry_date, strike, option_type)',
    'CREATE INDEX idx_fno_underlying ON '
        '$tableFnoContracts(underlying, expiry_date)',

    // ---- Results calendar (v8) --------------------------------------------
    // `estimated` = 1 only on rows written by builds <= 1.5.12, whose "next"
    // date was a guess. Nothing guesses now: EarningsDao drops it on read.
    '''
    CREATE TABLE $tableEarnings (
      symbol         TEXT PRIMARY KEY,
      last_date      TEXT,
      last_label     TEXT NOT NULL DEFAULT '',
      next_date      TEXT,
      next_label     TEXT NOT NULL DEFAULT '',
      next_confirmed INTEGER NOT NULL DEFAULT 0,
      estimated      INTEGER NOT NULL DEFAULT 0
    )
    ''',

    // ---- Pichle results ka itihaas (v11) -----------------------------------
    // Result playbook ("pichle 6 result me kya hua tha") isi se banta hai.
    // Sirf NSE ki announced dates — ek bhi andaza wali date yahan nahi aati.
    '''
    CREATE TABLE $tableResultHistory (
      symbol      TEXT NOT NULL,
      result_date   TEXT NOT NULL,
      period        TEXT NOT NULL DEFAULT '',
      reaction_date TEXT,
      PRIMARY KEY (symbol, result_date)
    )
    ''',
    'CREATE INDEX idx_result_history_symbol ON $tableResultHistory(symbol)',

    // ---- Scrip master cache ----------------------------------------------
    '''
    CREATE TABLE $tableScrips (
      token      TEXT PRIMARY KEY,
      symbol     TEXT NOT NULL,
      name       TEXT NOT NULL DEFAULT '',
      exchange   TEXT NOT NULL,
      tick_size  REAL NOT NULL DEFAULT 0.05
    )
    ''',
    'CREATE INDEX idx_scrips_symbol ON $tableScrips(exchange, symbol)',
    'CREATE INDEX idx_scrips_name ON $tableScrips(name)',

    // Small key/value table for scrip-master metadata (download date, row count)
    '''
    CREATE TABLE $tableScripMeta (
      key   TEXT PRIMARY KEY,
      value TEXT NOT NULL
    )
    ''',

    // ---- Settings ---------------------------------------------------------
    '''
    CREATE TABLE $tableSettings (
      key   TEXT PRIMARY KEY,
      value TEXT NOT NULL
    )
    ''',

    // ---- Last known prices (offline view) --------------------------------
    '''
    CREATE TABLE $tablePriceCache (
      price_key  TEXT PRIMARY KEY,          -- 'NSE:SBIN'
      token      TEXT NOT NULL DEFAULT '',
      ltp        REAL NOT NULL,
      change_pct REAL,
      as_of      INTEGER NOT NULL
    )
    ''',

    // ---- Cached scanner output -------------------------------------------
    '''
    CREATE TABLE $tableScanRuns (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      kind       TEXT NOT NULL,             -- 'ipo_proximity' | 'golden_cross'
      as_of      TEXT NOT NULL,             -- yyyy-MM-dd
      payload    TEXT NOT NULL,             -- JSON array of result rows
      created_at INTEGER NOT NULL,
      UNIQUE(kind, as_of) ON CONFLICT REPLACE
    )
    ''',

    // ---- Daily candles (Feature 2 cache) ---------------------------------
    '''
    CREATE TABLE $tableCandles (
      exchange  TEXT NOT NULL,
      symbol    TEXT NOT NULL,
      interval  TEXT NOT NULL DEFAULT 'ONE_DAY',
      bar_time  INTEGER NOT NULL,           -- epoch millis (IST bar open)
      open      REAL NOT NULL,
      high      REAL NOT NULL,
      low       REAL NOT NULL,
      close     REAL NOT NULL,
      volume    INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (exchange, symbol, interval, bar_time)
    )
    ''',

    // ---- Paper trading (Feature 3) ---------------------------------------
    '''
    CREATE TABLE $tableTrades (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      symbol        TEXT NOT NULL,
      exchange      TEXT NOT NULL DEFAULT 'NSE',
      token         TEXT NOT NULL DEFAULT '',
      side          TEXT NOT NULL,                -- BUY | SELL
      quantity      INTEGER NOT NULL,
      price         REAL NOT NULL,
      order_type    TEXT NOT NULL DEFAULT 'MARKET',
      position_id   INTEGER,
      group_id      INTEGER,                      -- trade group / strategy tag
      realized_pnl  REAL,                         -- filled on the closing leg
      charges       REAL NOT NULL DEFAULT 0,
      executed_at   INTEGER NOT NULL,
      note          TEXT NOT NULL DEFAULT ''
    )
    ''',
    'CREATE INDEX idx_trades_executed ON $tableTrades(executed_at)',
    'CREATE INDEX idx_trades_group ON $tableTrades(group_id)',
    '''
    CREATE TABLE $tablePositions (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      symbol        TEXT NOT NULL,
      exchange      TEXT NOT NULL DEFAULT 'NSE',
      token         TEXT NOT NULL DEFAULT '',
      quantity      INTEGER NOT NULL,
      side          TEXT NOT NULL DEFAULT 'long', -- long | short (v9)
      avg_price     REAL NOT NULL,
      stop_loss     REAL,                         -- absolute SL price
      target        REAL,
      group_id      INTEGER,                      -- inherited from the entry trade
      charges_paid  REAL NOT NULL DEFAULT 0,      -- opening-leg charges (v3)
      opened_at     INTEGER NOT NULL,
      closed_at     INTEGER,
      status        TEXT NOT NULL DEFAULT 'OPEN'  -- OPEN | CLOSED
    )
    ''',
    'CREATE INDEX idx_positions_status ON $tablePositions(status)',
    'CREATE INDEX idx_positions_group ON $tablePositions(group_id)',

    // ---- Paper orders (Feature 3, v3) ------------------------------------
    // One row per *submitted* order. MARKET orders are written already FILLED;
    // LIMIT orders rest as PENDING until the feed sees the level trade.
    '''
    CREATE TABLE $tablePaperOrders (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      symbol        TEXT NOT NULL,
      exchange      TEXT NOT NULL DEFAULT 'NSE',
      token         TEXT NOT NULL DEFAULT '',
      side          TEXT NOT NULL,                -- BUY | SELL
      quantity      INTEGER NOT NULL,
      order_type    TEXT NOT NULL DEFAULT 'MARKET',
      limit_price   REAL,
      stop_loss     REAL,
      target        REAL,
      group_id      INTEGER,
      status        TEXT NOT NULL DEFAULT 'PENDING',
      created_at    INTEGER NOT NULL,
      filled_at     INTEGER,
      filled_price  REAL,
      position_id   INTEGER,
      note          TEXT NOT NULL DEFAULT ''
    )
    ''',
    'CREATE INDEX idx_paper_orders_status ON $tablePaperOrders(status)',
    'CREATE INDEX idx_paper_orders_created ON $tablePaperOrders(created_at)',
    'CREATE INDEX idx_paper_orders_group ON $tablePaperOrders(group_id)',

    // ---- Trade groups (Feature 3: strategy / basket tagging) --------------
    // "Ungrouped" is NOT a row here: trades with group_id = NULL render as
    // Ungrouped, which is why the name is reserved in the model.
    '''
    CREATE TABLE $tableTradeGroups (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      name        TEXT    NOT NULL,
      color_index INTEGER NOT NULL DEFAULT 0,
      notes       TEXT    NOT NULL DEFAULT '',
      archived    INTEGER NOT NULL DEFAULT 0,
      created_at  INTEGER NOT NULL DEFAULT 0
    )
    ''',
    'CREATE UNIQUE INDEX idx_trade_groups_name ON $tableTradeGroups(name COLLATE NOCASE)',

    // ---- Study snapshots ("Mera hisaab") ----------------------------------
    // Ek run me har stock ki ek line; UNIQUE(symbol) ka matlab hai ki agla run
    // purani line ko hi badal deta hai. Itihaas ka matlab yahan "pichla scan".
    '''
    CREATE TABLE $tableStudySnapshots (
      symbol   TEXT    NOT NULL,
      saved_at INTEGER NOT NULL,
      score    REAL    NOT NULL DEFAULT 0,
      trend    TEXT    NOT NULL DEFAULT '',
      iv_rank  TEXT    NOT NULL DEFAULT ''
    )
    ''',
    'CREATE UNIQUE INDEX idx_study_snapshots_symbol '
        'ON $tableStudySnapshots(symbol)',
    'CREATE INDEX idx_study_snapshots_saved ON $tableStudySnapshots(saved_at)',

    // ---- Magic Formula fundamentals cache (v12+) -------------------------
    '''
    CREATE TABLE $tableMagicFormulaFundamentals (
      security_key          TEXT PRIMARY KEY,
      symbol                TEXT NOT NULL,
      company_name          TEXT NOT NULL DEFAULT '',
      exchange              TEXT NOT NULL DEFAULT 'NSE',
      sector                TEXT NOT NULL DEFAULT '',
      industry              TEXT NOT NULL DEFAULT '',
      isin                  TEXT NOT NULL DEFAULT '',
      data_symbol           TEXT NOT NULL DEFAULT '',
      data_company_name     TEXT NOT NULL DEFAULT '',
      market_cap_cr         REAL,
      ebit_ttm_cr           REAL,
      total_debt_cr         REAL,
      cash_cr               REAL,
      total_assets_cr       REAL,
      current_liabilities_cr REAL,
      market_price_as_of     TEXT,
      statement_basis       TEXT NOT NULL DEFAULT '',
      earnings_basis        TEXT NOT NULL DEFAULT '',
      period_start          TEXT,
      period_end            TEXT,
      balance_sheet_date    TEXT,
      fetched_at            INTEGER,
      source                TEXT NOT NULL DEFAULT 'NSE filings',
      missing_reason        TEXT NOT NULL DEFAULT ''
    )
    ''',
    'CREATE INDEX idx_magic_formula_sector '
        'ON $tableMagicFormulaFundamentals(sector)',
    'CREATE INDEX idx_magic_formula_fetched '
        'ON $tableMagicFormulaFundamentals(fetched_at)',
    // ---- Magic Formula baskets (v15) -------------------------------------
    '''
    CREATE TABLE $tableMagicBaskets (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      name        TEXT    NOT NULL,
      created_at  INTEGER NOT NULL
    )
    ''',
    '''
    CREATE TABLE $tableMagicBasketItems (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      basket_id    INTEGER NOT NULL
                   REFERENCES $tableMagicBaskets(id) ON DELETE CASCADE,
      symbol       TEXT    NOT NULL,
      exchange     TEXT    NOT NULL DEFAULT 'NSE',
      company_name TEXT    NOT NULL DEFAULT '',
      isin         TEXT    NOT NULL DEFAULT '',
      scrip_code   TEXT    NOT NULL DEFAULT '',
      added_at     INTEGER NOT NULL,
      UNIQUE (basket_id, exchange, symbol)
    )
    ''',
    'CREATE INDEX idx_magic_basket_items_basket '
        'ON $tableMagicBasketItems(basket_id)',

    // ---- Options Calls Board (v16) ---------------------------------------
    // User-added public Telegram call channels + their parsed calls.
    '''
    CREATE TABLE $tableCallsChannels (
      handle     TEXT NOT NULL PRIMARY KEY,
      added_at   TEXT NOT NULL,
      enabled    INTEGER NOT NULL DEFAULT 1,
      last_error TEXT
    )
    ''',
    '''
    CREATE TABLE $tableOptionCalls (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      channel      TEXT NOT NULL,
      msg_id       TEXT NOT NULL,
      ts           TEXT NOT NULL,
      raw_text     TEXT NOT NULL DEFAULT '',
      symbol       TEXT NOT NULL,
      kind         TEXT NOT NULL DEFAULT 'equity',
      option_type  TEXT NOT NULL DEFAULT '',
      strike       REAL,
      expiry_label TEXT NOT NULL DEFAULT '',
      side         TEXT NOT NULL DEFAULT 'buy',
      entry        REAL,
      sl           REAL,
      target1      REAL,
      target2      REAL,
      status       TEXT NOT NULL DEFAULT 'open',
      exit_price   REAL,
      exit_ts      TEXT,
      points       REAL,
      note         TEXT NOT NULL DEFAULT '',
      last_ltp     REAL,
      UNIQUE (channel, msg_id)
    )
    ''',
    'CREATE INDEX idx_option_calls_status ON $tableOptionCalls(status)',
    'CREATE INDEX idx_option_calls_channel ON $tableOptionCalls(channel)',
  ];

  /// Migrations for databases created by an earlier build.
  /// v1 shipped the paper-trading tables without group support; v2 adds it.
  /// Every statement is idempotent so a partially-applied upgrade is harmless.
  ///
  /// A step is a SQL string, or a callback (`Future<void> Function(Database)`)
  /// when the migration has to inspect the database first.
  static final Map<int, List<Object>> _migrations = {
    16: [
      '''
      CREATE TABLE IF NOT EXISTS $tableCallsChannels (
        handle     TEXT NOT NULL PRIMARY KEY,
        added_at   TEXT NOT NULL,
        enabled    INTEGER NOT NULL DEFAULT 1,
        last_error TEXT
      )
      ''',
      '''
      CREATE TABLE IF NOT EXISTS $tableOptionCalls (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        channel      TEXT NOT NULL,
        msg_id       TEXT NOT NULL,
        ts           TEXT NOT NULL,
        raw_text     TEXT NOT NULL DEFAULT '',
        symbol       TEXT NOT NULL,
        kind         TEXT NOT NULL DEFAULT 'equity',
        option_type  TEXT NOT NULL DEFAULT '',
        strike       REAL,
        expiry_label TEXT NOT NULL DEFAULT '',
        side         TEXT NOT NULL DEFAULT 'buy',
        entry        REAL,
        sl           REAL,
        target1      REAL,
        target2      REAL,
        status       TEXT NOT NULL DEFAULT 'open',
        exit_price   REAL,
        exit_ts      TEXT,
        points       REAL,
        note         TEXT NOT NULL DEFAULT '',
        last_ltp     REAL,
        UNIQUE (channel, msg_id)
      )
      ''',
      'CREATE INDEX IF NOT EXISTS idx_option_calls_status ON $tableOptionCalls(status)',
      'CREATE INDEX IF NOT EXISTS idx_option_calls_channel ON $tableOptionCalls(channel)',
    ],
    15: [
      '''
      CREATE TABLE IF NOT EXISTS $tableMagicBaskets (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        name        TEXT    NOT NULL,
        created_at  INTEGER NOT NULL
      )
      ''',
      '''
      CREATE TABLE IF NOT EXISTS $tableMagicBasketItems (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        basket_id    INTEGER NOT NULL
                     REFERENCES $tableMagicBaskets(id) ON DELETE CASCADE,
        symbol       TEXT    NOT NULL,
        exchange     TEXT    NOT NULL DEFAULT 'NSE',
        company_name TEXT    NOT NULL DEFAULT '',
        isin         TEXT    NOT NULL DEFAULT '',
        scrip_code   TEXT    NOT NULL DEFAULT '',
        added_at     INTEGER NOT NULL,
        UNIQUE (basket_id, exchange, symbol)
      )
      ''',
      'CREATE INDEX IF NOT EXISTS idx_magic_basket_items_basket '
          'ON $tableMagicBasketItems(basket_id)',
    ],
    14: [
      (Database db) async {
        final columns = await db.rawQuery(
          'PRAGMA table_info($tableMagicFormulaFundamentals)',
        );
        final hasEarningsBasis = columns.any(
          (column) => column['name'] == 'earnings_basis',
        );
        if (!hasEarningsBasis) {
          await db.execute(
            'ALTER TABLE $tableMagicFormulaFundamentals '
            "ADD COLUMN earnings_basis TEXT NOT NULL DEFAULT ''",
          );
        }
      },
    ],
    13: [
      (Database db) async {
        final columns = await db.rawQuery(
          'PRAGMA table_info($tableMagicFormulaFundamentals)',
        );
        final hasPriceDate = columns.any(
          (column) => column['name'] == 'market_price_as_of',
        );
        if (!hasPriceDate) {
          await db.execute(
            'ALTER TABLE $tableMagicFormulaFundamentals '
            'ADD COLUMN market_price_as_of TEXT',
          );
        }
      },
    ],
    12: [
      '''
      CREATE TABLE IF NOT EXISTS $tableMagicFormulaFundamentals (
        security_key           TEXT PRIMARY KEY,
        symbol                 TEXT NOT NULL,
        company_name           TEXT NOT NULL DEFAULT '',
        exchange               TEXT NOT NULL DEFAULT 'NSE',
        sector                 TEXT NOT NULL DEFAULT '',
        industry               TEXT NOT NULL DEFAULT '',
        isin                   TEXT NOT NULL DEFAULT '',
        data_symbol            TEXT NOT NULL DEFAULT '',
        data_company_name      TEXT NOT NULL DEFAULT '',
        market_cap_cr          REAL,
        ebit_ttm_cr            REAL,
        total_debt_cr          REAL,
        cash_cr                REAL,
        total_assets_cr        REAL,
        current_liabilities_cr REAL,
        statement_basis        TEXT NOT NULL DEFAULT '',
        period_start           TEXT,
        period_end             TEXT,
        balance_sheet_date     TEXT,
        fetched_at             INTEGER,
        source                 TEXT NOT NULL DEFAULT 'NSE filings',
        missing_reason         TEXT NOT NULL DEFAULT ''
      )
      ''',
      'CREATE INDEX IF NOT EXISTS idx_magic_formula_sector '
          'ON $tableMagicFormulaFundamentals(sector)',
      'CREATE INDEX IF NOT EXISTS idx_magic_formula_fetched '
          'ON $tableMagicFormulaFundamentals(fetched_at)',
    ],
    11: [
      '''
      CREATE TABLE IF NOT EXISTS $tableResultHistory (
        symbol      TEXT NOT NULL,
        result_date   TEXT NOT NULL,
        period        TEXT NOT NULL DEFAULT '',
        reaction_date TEXT,
        PRIMARY KEY (symbol, result_date)
      )
      ''',
      'CREATE INDEX IF NOT EXISTS idx_result_history_symbol '
          'ON $tableResultHistory(symbol)',
    ],
    2: [
      '''
      CREATE TABLE IF NOT EXISTS $tableTradeGroups (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        name        TEXT    NOT NULL,
        color_index INTEGER NOT NULL DEFAULT 0,
        notes       TEXT    NOT NULL DEFAULT '',
        archived    INTEGER NOT NULL DEFAULT 0,
        created_at  INTEGER NOT NULL DEFAULT 0
      )
      ''',
      'CREATE UNIQUE INDEX IF NOT EXISTS idx_trade_groups_name '
          'ON $tableTradeGroups(name COLLATE NOCASE)',
      'ALTER TABLE $tableTrades ADD COLUMN group_id INTEGER',
      'ALTER TABLE $tablePositions ADD COLUMN group_id INTEGER',
      'CREATE INDEX IF NOT EXISTS idx_trades_group ON $tableTrades(group_id)',
      'CREATE INDEX IF NOT EXISTS idx_positions_group ON $tablePositions(group_id)',
    ],
    // v3 adds the paper-order book and lets a position carry the charges its
    // opening legs already paid (so an exit can book P&L net of both legs).
    // NOTE: unlike the v2 block, `ALTER TABLE ADD COLUMN` is *not* idempotent —
    // it is safe only because the loop below runs each version exactly once.
    3: [
      '''
      CREATE TABLE IF NOT EXISTS $tablePaperOrders (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        symbol        TEXT NOT NULL,
        exchange      TEXT NOT NULL DEFAULT 'NSE',
        token         TEXT NOT NULL DEFAULT '',
        side          TEXT NOT NULL,
        quantity      INTEGER NOT NULL,
        order_type    TEXT NOT NULL DEFAULT 'MARKET',
        limit_price   REAL,
        stop_loss     REAL,
        target        REAL,
        group_id      INTEGER,
        status        TEXT NOT NULL DEFAULT 'PENDING',
        created_at    INTEGER NOT NULL,
        filled_at     INTEGER,
        filled_price  REAL,
        position_id   INTEGER,
        note          TEXT NOT NULL DEFAULT ''
      )
      ''',
      'CREATE INDEX IF NOT EXISTS idx_paper_orders_status '
          'ON $tablePaperOrders(status)',
      'CREATE INDEX IF NOT EXISTS idx_paper_orders_created '
          'ON $tablePaperOrders(created_at)',
      'CREATE INDEX IF NOT EXISTS idx_paper_orders_group '
          'ON $tablePaperOrders(group_id)',
      'ALTER TABLE $tablePositions ADD COLUMN charges_paid REAL NOT NULL DEFAULT 0',
    ],
    // v4 lets a row exist without listing-day levels: the bundled master ships
    // every mainboard IPO since 2015 (~550 rows) and the app fills each row's
    // high/low itself from the broker's daily candles (ListingLevelsService),
    // remembering where each level came from.
    6: [
      // F&O module: option contracts table (created by the block above on a
      // fresh install; this migration adds it to existing databases).
      '''
      CREATE TABLE IF NOT EXISTS $tableFnoContracts (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        underlying   TEXT    NOT NULL,
        expiry_label TEXT    NOT NULL,
        expiry_date  TEXT    NOT NULL,
        strike       REAL    NOT NULL,
        option_type  TEXT    NOT NULL,
        token        TEXT    NOT NULL,
        symbol       TEXT    NOT NULL DEFAULT '',
        lot_size     INTEGER NOT NULL DEFAULT 0,
        trading_symbol TEXT  NOT NULL DEFAULT ''
      )
      ''',
      'CREATE UNIQUE INDEX IF NOT EXISTS idx_fno_contract ON '
          '$tableFnoContracts(underlying, expiry_date, strike, option_type)',
      'CREATE INDEX IF NOT EXISTS idx_fno_underlying ON '
          '$tableFnoContracts(underlying, expiry_date)',
    ],
    5: [
      "ALTER TABLE $tableIpos ADD COLUMN isin TEXT NOT NULL DEFAULT ''",
      'CREATE INDEX IF NOT EXISTS idx_ipos_isin ON $tableIpos(isin)',
    ],
    4: [
      "ALTER TABLE $tableIpos ADD COLUMN levels_source TEXT NOT NULL DEFAULT ''",
      'CREATE INDEX IF NOT EXISTS idx_ipos_levels_source ON $tableIpos(levels_source)',
      // Backfill: rows written before v4 that already carry listing-day levels
      // are verified data — mark them so the background fetcher never replaces
      // them. Everything else (including the new level-less universe rows) stays
      // '' = pending.
      "UPDATE $tableIpos SET levels_source = 'seed' "
          'WHERE (listing_high > 0 AND listing_low > 0) AND levels_source = \'\'',
    ],
    // v7 — storage diet (see [_v7StorageDiet]).
    7: [_v7StorageDiet],
    // v10 — study snapshots: "Mera hisaab" (kaunsa setup fayda deta hai) ko
    // pata hona chahiye ki trade ke waqt study ne kya kaha tha. Purane install
    // me table nahi hai, isliye IF NOT EXISTS.
    10: [
      '''
      CREATE TABLE IF NOT EXISTS $tableStudySnapshots (
        symbol   TEXT    NOT NULL,
        saved_at INTEGER NOT NULL,
        score    REAL    NOT NULL DEFAULT 0,
        trend    TEXT    NOT NULL DEFAULT '',
        iv_rank  TEXT    NOT NULL DEFAULT ''
      )
      ''',
      'CREATE UNIQUE INDEX IF NOT EXISTS idx_study_snapshots_symbol '
          'ON $tableStudySnapshots(symbol)',
      'CREATE INDEX IF NOT EXISTS idx_study_snapshots_saved '
          'ON $tableStudySnapshots(saved_at)',
    ],
    // v9 — F&O option selling: a position can be short (see PositionSide).
    // A callback (not a bare SQL string) because very old / partial fixtures may
    // not have the table at all, and `ALTER TABLE` is not idempotent.
    9: [_v9PositionSide],
    8: [
      // `estimated` is legacy (see the v8 create above): 1 = guessed date.
      '''
      CREATE TABLE IF NOT EXISTS $tableEarnings (
        symbol         TEXT PRIMARY KEY,
        last_date      TEXT,
        last_label     TEXT NOT NULL DEFAULT '',
        next_date      TEXT,
        next_label     TEXT NOT NULL DEFAULT '',
        next_confirmed INTEGER NOT NULL DEFAULT 0,
        estimated      INTEGER NOT NULL DEFAULT 0
      )
      ''',
    ],
  };

  /// v7 — storage diet.
  ///
  /// Measured against the real broker master: the option book carried two
  /// columns nothing reads (`trading_symbol` was a byte-for-byte duplicate of
  /// `symbol`; `expiry_label` is a pure function of `expiry_date`) and `scrips`
  /// carried a write-only `updated_at`. Dropping all three saves ~0.8 MB on a
  /// full book — and the rows are *copied*, so upgrading never costs the user
  /// another 34 MB master download.
  ///
  /// Each table is rewritten only when it exists: a database from a build that
  /// never had an F&O book must still upgrade cleanly.
  static Future<void> _v7StorageDiet(Database db) async {
    if (await _tableExists(db, tableFnoContracts)) {
      await db.execute('''
        CREATE TABLE fno_contracts_v7 (
          id           INTEGER PRIMARY KEY AUTOINCREMENT,
          underlying   TEXT    NOT NULL,
          expiry_date  TEXT    NOT NULL,
          strike       REAL    NOT NULL,
          option_type  TEXT    NOT NULL,
          token        TEXT    NOT NULL,
          symbol       TEXT    NOT NULL DEFAULT '',
          lot_size     INTEGER NOT NULL DEFAULT 0
        )
      ''');
      await db.execute(
        'INSERT OR REPLACE INTO fno_contracts_v7 '
        '(id, underlying, expiry_date, strike, option_type, token, symbol, lot_size) '
        'SELECT id, underlying, expiry_date, strike, option_type, token, symbol, lot_size '
        'FROM $tableFnoContracts',
      );
      await db.execute('DROP TABLE $tableFnoContracts');
      await db.execute(
        'ALTER TABLE fno_contracts_v7 RENAME TO $tableFnoContracts',
      );
      await db.execute(
        'CREATE UNIQUE INDEX IF NOT EXISTS idx_fno_contract ON '
        '$tableFnoContracts(underlying, expiry_date, strike, option_type)',
      );
      await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_fno_underlying ON '
        '$tableFnoContracts(underlying, expiry_date)',
      );
    }

    if (await _tableExists(db, tableScrips)) {
      await db.execute('''
        CREATE TABLE scrips_v7 (
          token      TEXT PRIMARY KEY,
          symbol     TEXT NOT NULL,
          name       TEXT NOT NULL DEFAULT '',
          exchange   TEXT NOT NULL,
          tick_size  REAL NOT NULL DEFAULT 0.05
        )
      ''');
      await db.execute(
        'INSERT OR REPLACE INTO scrips_v7 (token, symbol, name, exchange, tick_size) '
        'SELECT token, symbol, name, exchange, tick_size FROM $tableScrips',
      );
      await db.execute('DROP TABLE $tableScrips');
      await db.execute('ALTER TABLE scrips_v7 RENAME TO $tableScrips');
      await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_scrips_symbol ON '
        '$tableScrips(exchange, symbol)',
      );
      await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_scrips_name ON $tableScrips(name)',
      );
    }
  }

  /// v9: adds `side` (`long` | `short`) to the positions book.
  ///
  /// Existing rows default to `long`, which is exactly what they were, so an
  /// upgrade never changes the meaning of a historical trade.
  static Future<void> _v9PositionSide(Database db) async {
    if (!await _tableExists(db, tablePositions)) return;
    if (await _columnExists(db, tablePositions, 'side')) return;
    await db.execute(
      "ALTER TABLE $tablePositions ADD COLUMN side TEXT NOT NULL DEFAULT 'long'",
    );
  }

  /// `true` when [table] already has a column called [column].
  static Future<bool> _columnExists(
    Database db,
    String table,
    String column,
  ) async {
    final rows = await db.rawQuery('PRAGMA table_info($table)');
    return rows.any((row) => row['name'] == column);
  }

  static Future<bool> _tableExists(Database db, String table) async {
    final rows = await db.rawQuery(
      "SELECT name FROM sqlite_master WHERE type = 'table' AND name = ?",
      [table],
    );
    return rows.isNotEmpty;
  }
}
