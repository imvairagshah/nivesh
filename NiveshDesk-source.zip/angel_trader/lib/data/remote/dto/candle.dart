// ---------------------------------------------------------------------------
// candle.dart — OHLCV bar returned by
//   POST /rest/secure/angelbroking/historical/v1/getCandleData
// (and the same shape is reused for any locally cached bars).
//
// SmartAPI returns a positional array per bar:
//   [ "2025-09-29T00:00:00+05:30", open, high, low, close, volume ]
// ---------------------------------------------------------------------------

class Candle {
  /// Bar open time (the exchange's own timestamp, IST).
  final DateTime time;
  final double open;
  final double high;
  final double low;
  final double close;
  final int volume;

  const Candle({
    required this.time,
    required this.open,
    required this.high,
    required this.low,
    required this.close,
    required this.volume,
  });

  /// Parses one row of the `getCandleData` payload.
  ///
  /// Tolerates numeric strings ("1234.5") as well as numbers — the API mixes
  /// both depending on the endpoint/segment.
  factory Candle.fromSmartApiRow(List<dynamic> row) {
    if (row.length < 5) {
      throw ArgumentError('Malformed candle row: $row');
    }
    final time = DateTime.tryParse('${row[0]}');
    if (time == null) {
      throw ArgumentError('Unparseable candle timestamp: ${row[0]}');
    }

    double toDouble(dynamic value) => value is num
        ? value.toDouble()
        : double.tryParse('$value') ?? 0;

    final volume = row.length > 5
        ? (row[5] is num
            ? (row[5] as num).toInt()
            : int.tryParse('${row[5]}') ?? 0)
        : 0;

    return Candle(
      time: time,
      open: toDouble(row[1]),
      high: toDouble(row[2]),
      low: toDouble(row[3]),
      close: toDouble(row[4]),
      volume: volume,
    );
  }

  /// The bar's trading **date** in IST (daily bars come back stamped 00:00 IST;
  /// intraday intervals carry a time component — both are normalised here).
  DateTime get istDate {
    final ist = time.toUtc().add(const Duration(hours: 5, minutes: 30));
    return DateTime(ist.year, ist.month, ist.day);
  }

  /// Cached bars are stored as `[isoTime, o, h, l, c, v]` in SQLite.
  List<Object?> toJsonRow() => [
        time.toIso8601String(),
        open,
        high,
        low,
        close,
        volume,
      ];

  factory Candle.fromJsonRow(List<dynamic> row) =>
      Candle.fromSmartApiRow(row);

  @override
  String toString() =>
      'Candle(${time.toIso8601String()}, O=$open H=$high L=$low C=$close V=$volume)';
}
