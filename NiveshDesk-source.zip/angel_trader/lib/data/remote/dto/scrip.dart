// ---------------------------------------------------------------------------
// scrip.dart — one tradable instrument from the SmartAPI scrip master.
//
// The scrip master is a ~50 MB JSON array that Angel One publishes daily:
//   https://margincalculator.angelbroking.com/OpenAPI_File/files/OpenAPIScripMaster.json
// Every quote / candle / WebSocket subscription needs the numeric `token`,
// which is why the app downloads this file (and caches it in SQLite).
// ---------------------------------------------------------------------------

import '../../../core/utils/markets.dart';

class Scrip {
  /// Numeric instrument token, stored as a string (SmartAPI sends strings).
  final String token;

  /// Broker symbol, e.g. `SBIN-EQ` on NSE or `SBIN` on BSE.
  final String symbol;

  /// Company / instrument name from the master.
  final String name;

  final Exchange exchange;

  /// Tick size in **rupees**, converted from the master's paise encoding
  /// (`"5.000000"` means 5 paise → ₹0.05, the standard NSE equity tick).
  final double tickSize;

  const Scrip({
    required this.token,
    required this.symbol,
    required this.name,
    required this.exchange,
    this.tickSize = 0.05,
  });

  factory Scrip.fromScripMaster(Map<String, dynamic> row) => Scrip(
        token: '${row['token']}'.trim(),
        symbol: '${row['symbol']}'.trim().toUpperCase(),
        name: '${row['name'] ?? ''}'.trim(),
        exchange: Exchange.fromCode('${row['exch_seg'] ?? 'NSE'}'),
        tickSize: parseTickSize(row['tick_size']),
      );

  /// The master encodes tick sizes in **paise**: NSE equity rows carry
  /// `"tick_size":"5.000000"`, which is ₹0.05. Used when rounding limit prices
  /// in the paper-trading module, so getting the scale right matters.
  static double parseTickSize(dynamic raw) {
    final value = raw is num ? raw.toDouble() : double.tryParse('$raw') ?? 0;
    if (value <= 0) return 0.05; // sane NSE default
    final rupees = value / 100;
    return rupees < 0.01 ? 0.01 : rupees;
  }

  Map<String, Object?> toDb() => {
        'token': token,
        'symbol': symbol,
        'name': name,
        'exchange': exchange.code,
        'tick_size': tickSize,
      };

  factory Scrip.fromDb(Map<String, Object?> row) => Scrip(
        token: row['token'] as String,
        symbol: row['symbol'] as String,
        name: row['name'] as String? ?? '',
        exchange: Exchange.fromCode(row['exchange'] as String? ?? 'NSE'),
        tickSize: (row['tick_size'] as num? ?? 0.05).toDouble(),
      );

  /// Best-effort match from a search query (used by the scrip search field).
  bool matches(String query) {
    final q = query.trim().toUpperCase();
    if (q.isEmpty) return true;
    return symbol.contains(q) || name.toUpperCase().contains(q);
  }

  /// TradingView link for this instrument.
  String get tradingViewUrl =>
      'https://in.tradingview.com/chart/?symbol=${exchange.code}:${symbol.replaceAll('-EQ', '')}';

  /// Stable key used by the price cache: `NSE:SBIN-EQ`.
  String get key => '${exchange.code}:$symbol';

  // -------------------------------------------------------------------------
  // Master-file filtering
  // -------------------------------------------------------------------------

  /// `true` when [row] of the scrip master is a **cash-market equity**.
  ///
  /// The master mixes equities, derivatives, indices, commodity and currency
  /// contracts. Equity rows are the only ones this app screens/trades:
  ///   * exchange segment must be NSE or BSE (cash),
  ///   * derivatives always carry an `expiry`, equities never do,
  ///   * NSE cash symbols end with `-EQ` (or `-BE`/`-BZ` for trade-to-trade),
  ///   * indices have `instrumenttype` such as `AMXIDX`.
  static bool isEquityRow(Map<String, dynamic> row) {
    final segment = '${row['exch_seg'] ?? ''}'.trim().toUpperCase();
    if (segment != 'NSE' && segment != 'BSE') return false;

    final expiry = '${row['expiry'] ?? ''}'.trim();
    if (expiry.isNotEmpty) return false;

    final symbol = '${row['symbol'] ?? ''}'.trim().toUpperCase();
    if (symbol.isEmpty) return false;

    final instrumentType = '${row['instrumenttype'] ?? ''}'.trim().toUpperCase();

    if (segment == 'NSE') {
      if (instrumentType.isNotEmpty) return false;
      return RegExp(r'-(EQ|BE|BZ|SM|ST|IL)$').hasMatch(symbol);
    }

    // BSE cash equities come through without an instrument type.
    return instrumentType.isEmpty || instrumentType == 'EQUITY';
  }

  /// Normalises an exchange symbol into the plain ticker the UI shows
  /// (`SBIN-EQ` → `SBIN`). The scrip master keeps the suffix, TradingView does
  /// not.
  static String plainSymbol(String exchangeSymbol) =>
      exchangeSymbol.toUpperCase().replaceAll(RegExp(r'-(EQ|BE|BZ|SM|ST|IL)$'), '');

  @override
  String toString() => 'Scrip(${exchange.code}:$symbol, token=$token)';
}
