// ---------------------------------------------------------------------------
// session.dart — SmartAPI login/session models.
//
// Auth flow (POST /rest/auth/angelbroking/user/v1/loginByPassword):
//   request  { clientcode, password, totp }
//   response { data: { jwtToken, refreshToken, feedToken, ... } }
//
// SmartAPI JWTs are valid until 05:00 IST the following day; the `exp` claim is
// read straight out of the token so the app knows exactly when to refresh via
// /rest/auth/angelbroking/jwt/v1/generateTokens (refreshToken).
// ---------------------------------------------------------------------------

import 'dart:convert';

/// The four things the user types into the login screen.
class AngelCredentials {
  final String apiKey; // from smartapi.angelbroking.com → My Apps
  final String clientCode; // Angel One client id, e.g. A123456
  final String password; // 4-digit MPIN or login password
  final String totpSecret; // base32 secret behind the 6-digit TOTP

  const AngelCredentials({
    required this.apiKey,
    required this.clientCode,
    required this.password,
    required this.totpSecret,
  });

  Map<String, String> toJson() => {
        'apiKey': apiKey,
        'clientCode': clientCode,
        'password': password,
        'totpSecret': totpSecret,
      };

  factory AngelCredentials.fromJson(Map<String, dynamic> json) =>
      AngelCredentials(
        apiKey: '${json['apiKey'] ?? ''}',
        clientCode: '${json['clientCode'] ?? ''}',
        password: '${json['password'] ?? ''}',
        totpSecret: '${json['totpSecret'] ?? ''}',
      );

  List<String> validate() {
    final errors = <String>[];
    if (apiKey.trim().isEmpty) errors.add('API key is required.');
    if (clientCode.trim().isEmpty) errors.add('Client code is required.');
    if (password.isEmpty) errors.add('Password / MPIN is required.');
    if (totpSecret.trim().isEmpty) {
      errors.add('TOTP secret is required (or enter a 6-digit code manually).');
    }
    return errors;
  }
}

/// An authenticated session: everything needed to sign REST calls and to open
/// the WebSocket feed.
class AngelSession {
  final String apiKey;
  final String clientCode;
  final String jwtToken;
  final String refreshToken;
  final String feedToken;
  final DateTime generatedAt;

  const AngelSession({
    required this.apiKey,
    required this.clientCode,
    required this.jwtToken,
    required this.refreshToken,
    required this.feedToken,
    required this.generatedAt,
  });

  /// Parses the `loginByPassword` response body.
  ///
  /// The API wraps payloads as `{ status, message, errorcode, data: {...} }`;
  /// [LoginException] carries `message + errorcode` for the UI.
  factory AngelSession.fromLoginResponse(
    Map<String, dynamic> body, {
    required String apiKey,
    required String clientCode,
  }) {
    if (body['status'] != true) {
      throw LoginException(
        message: '${body['message'] ?? 'Login failed'}',
        errorCode: '${body['errorcode'] ?? ''}',
      );
    }
    final data = body['data'] as Map<String, dynamic>? ?? const {};
    final jwt = '${data['jwtToken'] ?? ''}';
    if (jwt.isEmpty) {
      throw const LoginException(
        message: 'Login succeeded but no JWT token was returned.',
      );
    }
    return AngelSession(
      apiKey: apiKey,
      clientCode: clientCode,
      jwtToken: jwt,
      refreshToken: '${data['refreshToken'] ?? ''}',
      feedToken: '${data['feedToken'] ?? ''}',
      generatedAt: DateTime.now(),
    );
  }

  // -------------------------------------------------------------------------
  // Expiry handling
  // -------------------------------------------------------------------------

  /// The `exp` claim of the JWT (UTC), or `null` when it cannot be decoded.
  DateTime? get jwtExpiry {
    try {
      final parts = jwtToken.split('.');
      if (parts.length < 2) return null;
      var payload = parts[1].replaceAll('-', '+').replaceAll('_', '/');
      // Restore base64 padding.
      payload = payload.padRight((payload.length + 3) ~/ 4 * 4, '=');
      final json = jsonDecode(utf8.decode(base64.decode(payload)));
      final exp = (json is Map && json['exp'] is num)
          ? (json['exp'] as num).toInt()
          : null;
      if (exp == null) return null;
      return DateTime.fromMillisecondsSinceEpoch(exp * 1000, isUtc: true);
    } catch (_) {
      return null;
    }
  }

  /// When the token dies: `exp` when readable, else next 05:00 IST after login
  /// (SmartAPI's documented daily expiry).
  DateTime get expiresAt {
    final exp = jwtExpiry;
    if (exp != null) return exp;
    final ist = generatedAt.toUtc().add(const Duration(hours: 5, minutes: 30));
    var next = DateTime.utc(ist.year, ist.month, ist.day, 5, 0).subtract(
      const Duration(hours: 5, minutes: 30),
    );
    if (!next.isAfter(generatedAt.toUtc())) {
      next = next.add(const Duration(days: 1));
    }
    return next;
  }

  bool get isExpired => DateTime.now().toUtc().isAfter(expiresAt);

  Duration get timeToExpiry => expiresAt.difference(DateTime.now().toUtc());

  /// Refresh ahead of expiry so a long-running screen never hits a 401.
  bool get shouldRefresh => timeToExpiry < const Duration(minutes: 20);

  /// Small `Bearer …` header value used by every secure REST call.
  String get bearer => 'Bearer $jwtToken';

  // -------------------------------------------------------------------------
  // Storage helpers (persisted in flutter_secure_storage)
  // -------------------------------------------------------------------------

  Map<String, dynamic> toJson() => {
        'apiKey': apiKey,
        'clientCode': clientCode,
        'jwtToken': jwtToken,
        'refreshToken': refreshToken,
        'feedToken': feedToken,
        'generatedAt': generatedAt.toIso8601String(),
      };

  factory AngelSession.fromJson(Map<String, dynamic> json) => AngelSession(
        apiKey: '${json['apiKey'] ?? ''}',
        clientCode: '${json['clientCode'] ?? ''}',
        jwtToken: '${json['jwtToken'] ?? ''}',
        refreshToken: '${json['refreshToken'] ?? ''}',
        feedToken: '${json['feedToken'] ?? ''}',
        generatedAt:
            DateTime.tryParse('${json['generatedAt']}') ?? DateTime.now(),
      );

  /// Builds a session from a `generateTokens` response (auto-refresh path).
  AngelSession refreshedWith(Map<String, dynamic> body) {
    if (body['status'] != true) {
      throw LoginException(
        message: '${body['message'] ?? 'Token refresh failed'}',
        errorCode: '${body['errorcode'] ?? ''}',
      );
    }
    final data = body['data'] as Map<String, dynamic>? ?? const {};
    return AngelSession(
      apiKey: apiKey,
      clientCode: clientCode,
      jwtToken: '${data['jwtToken'] ?? jwtToken}',
      refreshToken: '${data['refreshToken'] ?? refreshToken}',
      feedToken: '${data['feedToken'] ?? ''}',
      generatedAt: DateTime.now(),
    );
  }
}

/// Minimal profile payload from `/getProfile` (shown on the auth/settings tab).
class AngelProfile {
  final String clientCode;
  final String name;
  final String email;
  final List<String> exchanges;

  const AngelProfile({
    required this.clientCode,
    required this.name,
    required this.email,
    this.exchanges = const [],
  });

  factory AngelProfile.fromApi(Map<String, dynamic> body) {
    final data = body['data'] as Map<String, dynamic>? ?? const {};
    final rawExchanges = data['exchanges'];
    return AngelProfile(
      clientCode: '${data['clientcode'] ?? ''}',
      name: '${data['name'] ?? ''}',
      email: '${data['email'] ?? ''}',
      exchanges: rawExchanges is List
          ? rawExchanges.map((e) => '$e').toList(growable: false)
          : const [],
    );
  }
}

/// Raised for every SmartAPI auth failure so the UI can show `errorcode`.
class LoginException implements Exception {
  final String message;
  final String errorCode;

  const LoginException({required this.message, this.errorCode = ''});

  /// Common SmartAPI auth codes → friendly hints.
  String get hint {
    switch (errorCode) {
      case 'AB1004':
        return 'Looks like an invalid API key or client code.';
      case 'AB1050':
      case 'AB1051':
      case 'AB1052':
        return 'The TOTP did not match. Check that the phone clock is accurate '
            'and that the secret is from the same SmartAPI app.';
      case 'AB2003':
        return 'Re-login required — the access token expired.';
      default:
        return '';
    }
  }

  @override
  String toString() =>
      'LoginException($errorCode${errorCode.isEmpty ? '' : ': '}$message)';
}
