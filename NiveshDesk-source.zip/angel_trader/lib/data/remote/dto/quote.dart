// ---------------------------------------------------------------------------
// quote.dart — market-data payloads.
//
//  * MarketQuote  : one row from POST /rest/secure/angelbroking/market/v1/quote/
//                   (modes LTP / OHLC / FULL). Used by the batch refresher in
//                   the IPO screener (up to 50 tokens per call).
//  * LiveTick     : one decoded packet from the WebSocket 2.0 feed
//                   (wss://smartapisocket.angelone.in/smart-stream).
//                   Used by the paper-trading module for live P&L + stop-loss.
// ---------------------------------------------------------------------------

import '../../../core/utils/markets.dart';

/// A latest-price snapshot for a single instrument.
class MarketQuote {
  /// Numeric instrument token (string form, as SmartAPI sends it).
  final String token;
  final String tradingSymbol;
  final Exchange exchange;
  final double ltp;

  final double? open;
  final double? high;
  final double? low;

  /// Previous session close — used to compute % change when the API omits it.
  final double? previousClose;

  final double? percentChange;
  final double? netChange;
  final int? volume;

  const MarketQuote({
    required this.token,
    required this.tradingSymbol,
    required this.exchange,
    required this.ltp,
    this.open,
    this.high,
    this.low,
    this.previousClose,
    this.percentChange,
    this.netChange,
    this.volume,
  });

  factory MarketQuote.fromSmartApi(Map<String, dynamic> json) {
    double? opt(String key) {
      final v = json[key];
      if (v == null) return null;
      if (v is num) return v.toDouble();
      return double.tryParse('$v');
    }

    return MarketQuote(
      token: '${json['symbolToken'] ?? ''}',
      tradingSymbol: '${json['tradingSymbol'] ?? ''}',
      exchange: Exchange.fromCode('${json['exchange'] ?? 'NSE'}'),
      ltp: opt('ltp') ?? 0,
      open: opt('open'),
      high: opt('high'),
      low: opt('low'),
      previousClose: opt('close'),
      percentChange: opt('percentChange'),
      netChange: opt('netChange'),
      volume: json['tradeVolume'] is num
          ? (json['tradeVolume'] as num).toInt()
          : null,
    );
  }

  /// Percentage change vs previous close, computed locally when the API omits
  /// `percentChange` (LTP mode does).
  double? get changePct {
    if (percentChange != null) return percentChange;
    final prev = previousClose;
    if (prev == null || prev == 0) return null;
    return (ltp - prev) / prev * 100;
  }

  @override
  String toString() =>
      'MarketQuote(${exchange.code}:$tradingSymbol, ltp=$ltp)';
}

/// Subscription modes supported by the streaming feed.
enum FeedMode {
  ltp(1, 'LTP'),
  quote(2, 'Quote'),
  snapQuote(3, 'Snap Quote');

  const FeedMode(this.code, this.label);
  final int code;
  final String label;
}

/// One decoded packet from the SmartAPI WebSocket feed.
class LiveTick {
  /// Subscription mode the packet was delivered in (1 = LTP … 3 = Snap Quote).
  final FeedMode mode;
  final Exchange exchange;

  /// Instrument token this packet belongs to (string key into the token map).
  final String token;

  final double ltp;

  /// Exchange feed timestamp (converted from epoch millis to IST wall clock).
  final DateTime? exchangeTime;

  /// Monotonic sequence number — lets a consumer drop out-of-order packets.
  final int? sequence;

  // Fields only populated for quote/snap-quote modes.
  final double? open;
  final double? high;
  final double? low;
  final double? previousClose;
  final int? volume;

  /// When *this app* received the packet (used for "live 2s ago" labels).
  final DateTime receivedAt;

  LiveTick({
    required this.mode,
    required this.exchange,
    required this.token,
    required this.ltp,
    this.exchangeTime,
    this.sequence,
    this.open,
    this.high,
    this.low,
    this.previousClose,
    this.volume,
    DateTime? receivedAt,
  }) : receivedAt = receivedAt ?? DateTime.now();

  /// % change vs previous close (available in quote/snap-quote modes).
  double? get changePct {
    final prev = previousClose;
    if (prev == null || prev == 0) return null;
    return (ltp - prev) / prev * 100;
  }

  @override
  String toString() =>
      'LiveTick(${exchange.code}/$token, ltp=$ltp, mode=${mode.label})';
}

/// A price the app can safely show together with its provenance.
class PricedValue {
  final double value;

  /// `true` when this came off the live WebSocket, `false` when it came from a
  /// cached/offline snapshot.
  final bool isLive;
  final DateTime asOf;

  /// Day change %, when the source knew the previous close.
  final double? changePct;

  const PricedValue({
    required this.value,
    required this.asOf,
    this.isLive = false,
    this.changePct,
  });

  PricedValue copyWith({double? value, bool? isLive, DateTime? asOf, double? changePct}) =>
      PricedValue(
        value: value ?? this.value,
        isLive: isLive ?? this.isLive,
        asOf: asOf ?? this.asOf,
        changePct: changePct ?? this.changePct,
      );
}
