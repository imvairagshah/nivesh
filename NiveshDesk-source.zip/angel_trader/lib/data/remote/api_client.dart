// ---------------------------------------------------------------------------
// api_client.dart — the single place that talks HTTP to SmartAPI.
//
// Responsibilities:
//   * attach the six mandatory SmartAPI headers to every request,
//   * decode the `{status, message, errorcode, data}` envelope,
//   * enforce the documented rate limits (3 req/s, 180 req/min on the historical
//     endpoint; 10 req/s on quotes) with a small token-bucket limiter,
//   * retry the "Access denied because of exceeding access rate" response with
//     exponential backoff (SmartAPI returns it inside a 200-status body).
// ---------------------------------------------------------------------------

import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

/// Base host for every SmartAPI REST call.
const String kApiHost = 'https://apiconnect.angelone.in';

/// Raised for any non-success SmartAPI response.
class ApiException implements Exception {
  final String message;
  final String errorCode;
  final int? httpStatus;
  final bool isRateLimited;
  final bool isAuthError;

  const ApiException({
    required this.message,
    this.errorCode = '',
    this.httpStatus,
    this.isRateLimited = false,
    this.isAuthError = false,
  });

  @override
  String toString() =>
      'ApiException($httpStatus ${errorCode.isEmpty ? '' : '$errorCode '}$message)';
}

/// Token-bucket style limiter — keeps calls under SmartAPI's per-second caps.
class RateLimiter {
  /// Minimum gap between two calls (350 ms ≈ 2.8 req/s, just under the 3 req/s
  /// ceiling on `getCandleData`).
  final Duration minGap;

  DateTime? _lastCall;

  RateLimiter({this.minGap = const Duration(milliseconds: 350)});

  /// Completes once it is safe to make the next call.
  Future<void> acquire() async {
    final now = DateTime.now();
    final last = _lastCall;
    if (last != null) {
      final elapsed = now.difference(last);
      if (elapsed < minGap) {
        await Future<void>.delayed(minGap - elapsed);
      }
    }
    _lastCall = DateTime.now();
  }
}

class ApiClient {
  ApiClient({http.Client? httpClient, RateLimiter? limiter})
      : _http = httpClient ?? http.Client(),
        _limiter = limiter ?? RateLimiter();

  final http.Client _http;
  final RateLimiter _limiter;

  /// How many times a rate-limited request is retried.
  static const int maxRetries = 3;

  /// Default per-request timeout (the scrip master uses a longer one).
  static const Duration defaultTimeout = Duration(seconds: 30);

  /// Builds the mandatory header set.
  ///
  /// Note `X-ClientLocalIP` / `X-ClientPublicIP` / `X-MACAddress` are validated
  /// for *presence* by SmartAPI; `127.0.0.1` is accepted (and is what the
  /// official Python SDK sends by default when it cannot detect them).
  static Map<String, String> headers({
    required String apiKey,
    String? bearerToken,
    String clientCode = '',
  }) =>
      {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'X-UserType': 'USER',
        'X-SourceID': 'WEB',
        'X-ClientLocalIP': '127.0.0.1',
        'X-ClientPublicIP': '127.0.0.1',
        'X-MACAddress': '00:00:00:00:00:00',
        'X-PrivateKey': apiKey,
        if (clientCode.isNotEmpty) 'X-ClientCode': clientCode,
        'Authorization': bearerToken == null ? '' : 'Bearer $bearerToken',
      };

  /// POST [path] (relative to [kApiHost]) with a JSON [body].
  Future<Map<String, dynamic>> postJson(
    String path,
    Map<String, dynamic> body, {
    required String apiKey,
    String? bearerToken,
    String clientCode = '',
    Duration timeout = defaultTimeout,
    bool requiresAuth = true,
  }) async {
    Object? lastError;

    for (var attempt = 0; attempt <= maxRetries; attempt++) {
      await _limiter.acquire();
      try {
        final response = await _http
            .post(
              Uri.parse('$kApiHost$path'),
              headers: headers(
                apiKey: apiKey,
                bearerToken: requiresAuth ? bearerToken : null,
                clientCode: clientCode,
              ),
              body: jsonEncode(body),
            )
            .timeout(timeout);

        final decoded = _decodeBody(response.body);

        // SmartAPI signals rate limiting inside a normal HTTP 200 body.
        final message = '${decoded['message'] ?? ''}';
        if (message.toLowerCase().contains('exceeding access rate') ||
            message.toLowerCase().contains('too many requests') ||
            response.statusCode == 429) {
          if (attempt < maxRetries) {
            // 500 ms, 1 s, 2 s …
            await Future<void>.delayed(
              Duration(milliseconds: 500 * (1 << attempt)),
            );
            continue;
          }
          throw ApiException(
            message: 'SmartAPI rate limit reached. Try again in a minute.',
            errorCode: '${decoded['errorcode'] ?? ''}',
            httpStatus: response.statusCode,
            isRateLimited: true,
          );
        }

        if (response.statusCode == 401 || response.statusCode == 403) {
          throw ApiException(
            message: message.isEmpty ? 'Session expired.' : message,
            errorCode: '${decoded['errorcode'] ?? ''}',
            httpStatus: response.statusCode,
            isAuthError: true,
          );
        }

        if (response.statusCode >= 400) {
          throw ApiException(
            message: message.isEmpty
                ? 'SmartAPI returned HTTP ${response.statusCode}.'
                : message,
            errorCode: '${decoded['errorcode'] ?? ''}',
            httpStatus: response.statusCode,
          );
        }

        return decoded;
      } on ApiException {
        rethrow; // already classified
      } on TimeoutException {
        lastError = const ApiException(
          message: 'The request timed out. Check your connection.',
        );
      } catch (error) {
        lastError = ApiException(message: 'Network error: $error');
      }

      // Transient failure → small backoff, then retry.
      if (attempt < maxRetries) {
        await Future<void>.delayed(Duration(milliseconds: 300 * (1 << attempt)));
      }
    }

    throw lastError is ApiException
        ? lastError
        : const ApiException(message: 'Request failed.');
  }

  /// Streams a large GET body (used for the ~50 MB scrip master).
  ///
  /// The caller receives raw byte chunks and pipes them through a UTF-8 decoder
  /// and [JsonArrayScanner] so memory stays flat.
  Future<http.StreamedResponse> streamGet(
    Uri uri, {
    Duration timeout = const Duration(minutes: 5),
  }) async {
    final request = http.Request('GET', uri);
    request.headers['Accept'] = 'application/json';
    final response = await _http.send(request).timeout(timeout);
    if (response.statusCode >= 400) {
      throw ApiException(
        message: 'Download failed with HTTP ${response.statusCode}.',
        httpStatus: response.statusCode,
      );
    }
    return response;
  }

  /// Asks a file host for its `Last-Modified` **without downloading it**.
  ///
  /// Angel's scrip master is ~34 MB and is republished once a day; on weekends
  /// and holidays it is often byte-identical to yesterday's. This sends a
  /// ranged GET for the first 1 KB (every CDN/ELB in front of the file honours
  /// `Range`, verified against the live host) and reads the response headers —
  /// about 1 KB on the wire, a fraction of a second.
  ///
  /// Returns `null` when the host does not answer the way we expect: callers
  /// then fall back to the normal download.
  Future<DateTime?> probeLastModified(Uri uri) async {
    try {
      final request = http.Request('GET', uri);
      request.headers['Range'] = 'bytes=0-1023';
      request.headers['Accept'] = 'application/json';

      final response = await _http
          .send(request)
          .timeout(const Duration(seconds: 20));
      // Drain the (tiny) body so the connection can be reused.
      await response.stream.drain<void>();

      if (response.statusCode != 200 && response.statusCode != 206) return null;
      final raw = response.headers['last-modified'];
      if (raw == null || raw.trim().isEmpty) return null;
      return parseHttpDate(raw);
    } catch (_) {
      return null; // no probe, no problem: the caller downloads as usual
    }
  }

  /// Parses an RFC-1123 date (`Tue, 06 Oct 2026 02:30:05 GMT`) without pulling
  /// `dart:io` into this file.
  static DateTime? parseHttpDate(String raw) {
    final text = raw.trim();
    final comma = text.indexOf(',');
    if (comma < 0) return null;
    final parts = text.substring(comma + 1).trim().split(RegExp(r'\s+'));
    if (parts.length < 5) return null;

    const months = [
      'jan', 'feb', 'mar', 'apr', 'may', 'jun',
      'jul', 'aug', 'sep', 'oct', 'nov', 'dec',
    ];
    final day = int.tryParse(parts[0]);
    final month = months.indexOf(parts[1].toLowerCase());
    final year = int.tryParse(parts[2]);
    final clock = parts[3].split(':');
    final hour = clock.isNotEmpty ? int.tryParse(clock[0]) : null;
    final minute = clock.length > 1 ? int.tryParse(clock[1]) : null;
    final second = clock.length > 2 ? int.tryParse(clock[2]) : null;

    if (day == null || month < 0 || year == null || hour == null) return null;
    return DateTime.utc(year, month + 1, day, hour, minute ?? 0, second ?? 0);
  }

  /// Decodes a body defensively: SmartAPI occasionally returns HTML/plain text
  /// (e.g. gateway errors) where JSON is expected.
  Map<String, dynamic> _decodeBody(String body) {
    if (body.isEmpty) return const {};
    try {
      final decoded = jsonDecode(body);
      return decoded is Map<String, dynamic> ? decoded : {'data': decoded};
    } catch (_) {
      return {'message': body.length > 300 ? '${body.substring(0, 300)}…' : body};
    }
  }

  void dispose() => _http.close();
}
