// ---------------------------------------------------------------------------
// rsi_scanner_screen.dart — the RSI Scanner tab.
//
// What the screen does, top to bottom:
//
//   • scan bar   — Scan now / cancel, progress (N/M, current ticker, ETA) and
//                  the two chips that configure the scan (universe, thresholds)
//   • summary    — overbought / oversold / fresh-cross counts + which day the
//                  table belongs to (and whether it is a cached run)
//   • segmented  — "RSI > 67" ⇄ "RSI < 33" (one scan fills both lists)
//   • table      — Stock (ticker + company name) · Price (last daily close and
//                  day change) · RSI (value, zone chip, "naya" cross badge)
//
// Everything visual comes from the design system: no colour, radius or duration
// is invented here. Rows animate in with the 45 ms stagger, tapping a row opens
// the chart link, and skipped symbols are always reachable from the "N skip"
// chip — a short table is never unexplained.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../core/widgets/motion.dart';
import '../../services/universe_catalog.dart';
import 'rsi_engine.dart';
import 'rsi_screener_provider.dart';
import 'widgets/rsi_sheets.dart';

class RsiScannerScreen extends StatefulWidget {
  const RsiScannerScreen({super.key, this.active = true});

  /// `true` while this is the visible tab (the shell passes it through).
  final bool active;

  @override
  State<RsiScannerScreen> createState() => _RsiScannerScreenState();
}

class _RsiScannerScreenState extends State<RsiScannerScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final provider = context.read<RsiScreenerProvider>();
      if (!provider.hasResult && provider.isLoadingCache) {
        provider.bootstrap();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<RsiScreenerProvider>();
    final thresholds = provider.thresholds;

    return RefreshIndicator(
      onRefresh: () => provider.run(),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(
          AppSpacing.lg,
          AppSpacing.md,
          AppSpacing.lg,
          AppSpacing.xxl,
        ),
        children: [
          _ScanBar(provider: provider, thresholds: thresholds),
          const SizedBox(height: AppSpacing.md),
          if (provider.error != null) ...[
            _Banner(
              icon: Icons.error_outline_rounded,
              text: provider.error!,
              tone: _BannerTone.error,
            ),
            const SizedBox(height: AppSpacing.md),
          ],
          if (provider.isStale && !provider.isViewingCached) ...[
            _Banner(
              icon: Icons.schedule_rounded,
              text: 'Yeh table ${Fmt.date(provider.result?.asOf)} ki hai — '
                  'Scan now se aaj ka RSI lein.',
              tone: _BannerTone.warning,
            ),
            const SizedBox(height: AppSpacing.md),
          ],
          if (provider.isViewingCached) ...[
            _Banner(
              icon: Icons.history_rounded,
              text: 'Cached result — Scan now dabane par taaza RSI aayega.',
              tone: _BannerTone.info,
            ),
            const SizedBox(height: AppSpacing.md),
          ],
          _SummaryCard(provider: provider, thresholds: thresholds),
          const SizedBox(height: AppSpacing.md),
          _ZoneSwitch(provider: provider, thresholds: thresholds),
          const SizedBox(height: AppSpacing.md),
          _Table(provider: provider, thresholds: thresholds),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Scan bar
// ---------------------------------------------------------------------------

class _ScanBar extends StatelessWidget {
  const _ScanBar({required this.provider, required this.thresholds});

  final RsiScreenerProvider provider;
  final RsiThresholds thresholds;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final progress = provider.progress;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.md),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: Wrap(
                    spacing: AppSpacing.sm,
                    runSpacing: AppSpacing.sm,
                    children: [
                      _ConfigChip(
                        icon: Icons.filter_alt_outlined,
                        label: UniverseCatalog.byKey(provider.universeKey).label,
                        sub: provider.universe.hasMissing
                            ? '${provider.universe.size} of '
                                '${provider.universe.size + provider.universe.missing.length}'
                            : '${provider.universe.size} instruments',
                        onTap: provider.isScanning
                            ? null
                            : () => showRsiUniverseSheet(context),
                      ),
                      _ConfigChip(
                        icon: Icons.tune_rounded,
                        label: thresholds.label,
                        sub: 'period · upar / neeche',
                        onTap: provider.isScanning
                            ? null
                            : () => showRsiThresholdsSheet(
                                  context,
                                  initial: thresholds,
                                  onSaved: provider.setThresholds,
                                ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.md),
            Row(
              children: [
                Expanded(
                  child: provider.isScanning
                      ? FilledButton.icon(
                          onPressed: provider.cancel,
                          icon: const Icon(Icons.stop_circle_outlined, size: 18),
                          label: const Text('Cancel'),
                        )
                      : FilledButton.icon(
                          onPressed:
                              provider.canScan ? () => provider.run() : null,
                          icon: const Icon(Icons.radar_rounded, size: 18),
                          label: const Text('Scan now'),
                        ),
                ),
                const SizedBox(width: AppSpacing.md),
                if (!provider.isScanning && provider.universe.size > 0)
                  Text(
                    provider.scanEstimate,
                    style: Theme.of(context).textTheme.labelMedium?.copyWith(
                          color: scheme.onSurfaceVariant,
                        ),
                  ),
              ],
            ),
            if (provider.isScanning) ...[
              const SizedBox(height: AppSpacing.md),
              SmoothProgressBar(value: progress?.fraction ?? 0),
              const SizedBox(height: AppSpacing.sm),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      progress == null
                          ? 'Shuru ho raha hai…'
                          : '${progress.done}/${progress.total} · ${progress.current}',
                      style: Theme.of(context).textTheme.labelMedium,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  if (progress != null)
                    Text(
                      '${progress.overbought}↑ ${progress.oversold}↓ · '
                      'ETA ${_eta(progress.eta)}',
                      style: Theme.of(context).textTheme.labelSmall,
                    ),
                ],
              ),
            ] else if (provider.isResolvingUniverse) ...[
              const SizedBox(height: AppSpacing.sm),
              Text(
                'Instruments resolve ho rahe hain…',
                style: Theme.of(context).textTheme.labelSmall,
              ),
            ] else ...[
              const SizedBox(height: AppSpacing.sm),
              Text(
                provider.statusLine,
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
            if (provider.skipCount > 0 && !provider.isScanning) ...[
              const SizedBox(height: AppSpacing.sm),
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton.icon(
                  onPressed: () => _showSkips(context, provider),
                  icon: const Icon(Icons.info_outline_rounded, size: 16),
                  label: Text('${provider.skipCount} instrument skip hue — dekhein'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  static String _eta(Duration d) {
    if (d.inSeconds <= 1) return 'ab';
    if (d.inSeconds < 60) return '${d.inSeconds}s';
    return '${d.inMinutes}m ${d.inSeconds % 60}s';
  }
}

class _ConfigChip extends StatelessWidget {
  const _ConfigChip({
    required this.icon,
    required this.label,
    required this.sub,
    this.onTap,
  });

  final IconData icon;
  final String label;
  final String sub;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return PressScale(
      enabled: onTap != null,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppRadius.md),
        child: Container(
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.md,
            vertical: AppSpacing.sm,
          ),
          decoration: BoxDecoration(
            color: scheme.surfaceContainerHighest.withOpacity(0.55),
            borderRadius: BorderRadius.circular(AppRadius.md),
            border: Border.all(
              color: scheme.outlineVariant.withOpacity(0.7),
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 16, color: scheme.onSurfaceVariant),
              const SizedBox(width: AppSpacing.sm),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    label,
                    style: Theme.of(context).textTheme.labelLarge,
                  ),
                  Text(
                    sub,
                    style: Theme.of(context).textTheme.labelSmall,
                  ),
                ],
              ),
              if (onTap != null) ...[
                const SizedBox(width: AppSpacing.xs),
                Icon(Icons.expand_more_rounded,
                    size: 16, color: scheme.onSurfaceVariant),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Summary
// ---------------------------------------------------------------------------

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({required this.provider, required this.thresholds});

  final RsiScreenerProvider provider;
  final RsiThresholds thresholds;

  @override
  Widget build(BuildContext context) {
    final market = MarketColors.of(context);
    final scheme = Theme.of(context).colorScheme;
    final result = provider.result;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  'RSI SCAN',
                  style: Theme.of(context).textTheme.labelSmall,
                ),
                const Spacer(),
                Text(
                  result == null ? '—' : Fmt.date(result.asOf),
                  style: Theme.of(context).textTheme.labelSmall,
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.md),
            Row(
              children: [
                _Stat(
                  label: 'RSI > ${_num(thresholds.upper)}',
                  value: provider.overboughtCount,
                  color: market.loss,
                  hint: 'overbought',
                ),
                _Stat(
                  label: 'RSI < ${_num(thresholds.lower)}',
                  value: provider.oversoldCount,
                  color: market.gain,
                  hint: 'oversold',
                ),
                _Stat(
                  label: 'Aaj naya',
                  value: provider.freshCount,
                  color: scheme.primary,
                  hint: 'naya cross',
                ),
              ],
            ),
            if (result != null) ...[
              const SizedBox(height: AppSpacing.md),
              Text(
                provider.isViewingCached
                    ? 'Cached table · ${thresholds.label}'
                    : '${result.scanned}/${result.universeSize} instruments · '
                        '${thresholds.label} · '
                        '${result.duration.inSeconds}s',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ],
        ),
      ),
    );
  }

  static String _num(double v) =>
      v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toStringAsFixed(1);
}

class _Stat extends StatelessWidget {
  const _Stat({
    required this.label,
    required this.value,
    required this.color,
    required this.hint,
  });

  final String label;
  final int value;
  final Color color;
  final String hint;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: Theme.of(context).textTheme.labelSmall),
          const SizedBox(height: AppSpacing.xs),
          NumberTicker(
            value: value.toDouble(),
            format: (v) => v.round().toString(),
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: color,
                  fontWeight: FontWeight.w800,
                ),
          ),
          Text(hint, style: Theme.of(context).textTheme.labelSmall),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Zone switch
// ---------------------------------------------------------------------------

class _ZoneSwitch extends StatelessWidget {
  const _ZoneSwitch({required this.provider, required this.thresholds});

  final RsiScreenerProvider provider;
  final RsiThresholds thresholds;

  @override
  Widget build(BuildContext context) {
    final market = MarketColors.of(context);
    return SegmentedButton<RsiZone>(
      segments: [
        ButtonSegment(
          value: RsiZone.overbought,
          icon: const Icon(Icons.trending_up_rounded, size: 16),
          label: Text('RSI > ${_SummaryCard._num(thresholds.upper)} · '
              '${provider.overboughtCount}'),
        ),
        ButtonSegment(
          value: RsiZone.oversold,
          icon: const Icon(Icons.trending_down_rounded, size: 16),
          label: Text('RSI < ${_SummaryCard._num(thresholds.lower)} · '
              '${provider.oversoldCount}'),
        ),
      ],
      selected: {provider.zone},
      onSelectionChanged: (set) => provider.setZone(set.first),
      style: ButtonStyle(
        visualDensity: VisualDensity.compact,
        textStyle: WidgetStatePropertyAll(
          Theme.of(context).textTheme.labelMedium,
        ),
        foregroundColor: WidgetStateProperty.resolveWith(
          (states) => states.contains(WidgetState.selected)
              ? market.flat
              : Theme.of(context).colorScheme.onSurfaceVariant,
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Table
// ---------------------------------------------------------------------------

class _Table extends StatelessWidget {
  const _Table({required this.provider, required this.thresholds});

  final RsiScreenerProvider provider;
  final RsiThresholds thresholds;

  @override
  Widget build(BuildContext context) {
    if (provider.isLoadingCache) {
      return const Column(
        children: [
          ShimmerCard(lines: 3),
          SizedBox(height: AppSpacing.md),
          ShimmerCard(lines: 3),
        ],
      );
    }

    final rows = provider.rows;
    if (rows.isEmpty) {
      return _EmptyState(provider: provider, thresholds: thresholds);
    }

    return SwapFade(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _HeaderRow(zone: provider.zone, thresholds: thresholds),
          const SizedBox(height: AppSpacing.xs),
          for (var i = 0; i < rows.length; i++)
            FadeSlideIn(
              index: i,
              child: Padding(
                padding: const EdgeInsets.only(bottom: AppSpacing.sm),
                child: _RsiRow(
                  reading: rows[i],
                  zone: provider.zone,
                  thresholds: thresholds,
                  fresh: rows[i].isFreshIn(thresholds),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _HeaderRow extends StatelessWidget {
  const _HeaderRow({required this.zone, required this.thresholds});

  final RsiZone zone;
  final RsiThresholds thresholds;

  @override
  Widget build(BuildContext context) {
    final style = Theme.of(context).textTheme.labelSmall;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md),
      child: Row(
        children: [
          Expanded(flex: 5, child: Text('STOCK', style: style)),
          Expanded(
            flex: 3,
            child: Text('PRICE', style: style, textAlign: TextAlign.right),
          ),
          Expanded(
            flex: 3,
            child: Text('RSI(${thresholds.period})',
                style: style, textAlign: TextAlign.right),
          ),
        ],
      ),
    );
  }
}

class _RsiRow extends StatelessWidget {
  const _RsiRow({
    required this.reading,
    required this.zone,
    required this.thresholds,
    required this.fresh,
  });

  final RsiReading reading;
  final RsiZone zone;
  final RsiThresholds thresholds;
  final bool fresh;

  @override
  Widget build(BuildContext context) {
    final market = MarketColors.of(context);
    final scheme = Theme.of(context).colorScheme;
    final text = Theme.of(context).textTheme;

    // Red for overbought, green for oversold — the same colours the rest of the
    // app uses for direction, used here as *signal*, never as decoration.
    final accent = zone == RsiZone.overbought ? market.loss : market.gain;
    final dayUp = reading.changePct >= 0;
    final dayColor = reading.changePct == 0
        ? market.flat
        : (dayUp ? market.gain : market.loss);

    return PressScale(
      child: InkWell(
        onTap: () => _showReadingSheet(context, reading, thresholds),
        borderRadius: BorderRadius.circular(AppRadius.lg),
        child: Container(
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.md,
            vertical: AppSpacing.md,
          ),
          decoration: BoxDecoration(
            color: scheme.surface,
            borderRadius: BorderRadius.circular(AppRadius.lg),
            border: Border.all(
              color: scheme.outlineVariant.withOpacity(0.55),
            ),
          ),
          child: Row(
            children: [
              Expanded(
                flex: 5,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            reading.symbol,
                            style: text.titleSmall,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (fresh) ...[
                          const SizedBox(width: AppSpacing.xs),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: accent.withOpacity(0.14),
                              borderRadius:
                                  BorderRadius.circular(AppRadius.pill),
                            ),
                            child: Text(
                              'NAYA',
                              style: text.labelSmall?.copyWith(
                                color: accent,
                                fontSize: 9.5,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                    Text(
                      reading.companyName.isEmpty
                          ? '${reading.exchange.code} · ${reading.bars} bars'
                          : reading.companyName,
                      style: text.bodySmall,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              Expanded(
                flex: 3,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      '₹${Fmt.price(reading.price)}',
                      style: text.titleSmall?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    Text(
                      Fmt.signedPct(reading.changePct),
                      style: text.labelSmall?.copyWith(color: dayColor),
                    ),
                  ],
                ),
              ),
              Expanded(
                flex: 3,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      reading.rsi.toStringAsFixed(1),
                      style: text.titleMedium?.copyWith(
                        color: accent,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Text(
                      reading.prevRsi == null
                          ? '—'
                          : 'prev ${reading.prevRsi!.toStringAsFixed(1)}',
                      style: text.labelSmall,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Empty state
// ---------------------------------------------------------------------------

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.provider, required this.thresholds});

  final RsiScreenerProvider provider;
  final RsiThresholds thresholds;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final text = Theme.of(context).textTheme;

    final hasResult = provider.hasResult;
    final zoneLabel = provider.zone == RsiZone.overbought
        ? 'RSI ${_SummaryCard._num(thresholds.upper)} ke upar'
        : 'RSI ${_SummaryCard._num(thresholds.lower)} ke neeche';

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.xl),
        child: Column(
          children: [
            Icon(Icons.speed_rounded, size: 34, color: scheme.onSurfaceVariant),
            const SizedBox(height: AppSpacing.md),
            Text(
              hasResult
                  ? 'Aaj koi stock $zoneLabel nahi hai'
                  : 'Abhi tak scan nahi hua',
              style: text.titleSmall,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: AppSpacing.xs),
            Text(
              hasResult
                  ? 'Scanner ne ${provider.universe.size} instruments dekhe. '
                      'Dusra zone ya dusra universe try kariye.'
                  : 'Universe chuniye (F&O ya saare stocks) aur Scan now '
                      'dabaiye — 213 F&O names ka fresh scan ~80 second leta hai.',
              style: text.bodySmall,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: AppSpacing.lg),
            OutlinedButton.icon(
              onPressed: provider.canScan ? () => provider.run() : null,
              icon: const Icon(Icons.radar_rounded, size: 18),
              label: const Text('Scan now'),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Sheets
// ---------------------------------------------------------------------------

void _showSkips(BuildContext context, RsiScreenerProvider provider) {
  showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (context) => DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.55,
      maxChildSize: 0.9,
      builder: (context, controller) => ListView(
        controller: controller,
        padding: const EdgeInsets.fromLTRB(
          AppSpacing.lg,
          AppSpacing.sm,
          AppSpacing.lg,
          AppSpacing.xl,
        ),
        children: [
          Text('Skip hue instruments', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: AppSpacing.xs),
          Text(
            'Yeh rows table me nahi aa sakti — wajah ke saath. Inhe chhupaya '
            'nahi jata, taaki counter kabhi chup-chaap kam na lage.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          const SizedBox(height: AppSpacing.lg),
          for (final skip in provider.skips)
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(skip.symbol),
              subtitle: Text(skip.reason),
              leading: Icon(
                Icons.block_rounded,
                size: 18,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
        ],
      ),
    ),
  );
}

void _showReadingSheet(
  BuildContext context,
  RsiReading reading,
  RsiThresholds thresholds,
) {
  final market = MarketColors.of(context);
  final text = Theme.of(context).textTheme;

  showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    builder: (context) => Padding(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.lg,
        0,
        AppSpacing.lg,
        AppSpacing.xl,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(reading.symbol, style: text.titleLarge),
          if (reading.companyName.isNotEmpty)
            Text(reading.companyName, style: text.bodySmall),
          const SizedBox(height: AppSpacing.lg),
          _KeyValue(
            label: 'RSI(${thresholds.period})',
            value: reading.rsi.toStringAsFixed(2),
            color: reading.zoneIn(thresholds) == RsiZone.overbought
                ? market.loss
                : market.gain,
          ),
          _KeyValue(
            label: 'Kal ka RSI',
            value: reading.prevRsi?.toStringAsFixed(2) ?? '—',
          ),
          _KeyValue(
            label: 'Zone',
            value: reading.zoneIn(thresholds).label +
                ' · ${reading.zoneAge} bar se',
          ),
          _KeyValue(
            label: 'Close (${Fmt.date(reading.barDate)})',
            value: '₹${Fmt.price(reading.price)}',
            color: reading.changePct >= 0 ? market.gain : market.loss,
          ),
          _KeyValue(
            label: 'Day change',
            value: Fmt.signedPct(reading.changePct),
          ),
          _KeyValue(label: 'Bars used', value: '${reading.bars}'),
          _KeyValue(
            label: 'Instrument',
            value: '${reading.brokerSymbol} · ${reading.exchange.code}',
          ),
        ],
      ),
    ),
  );
}

class _KeyValue extends StatelessWidget {
  const _KeyValue({required this.label, required this.value, this.color});

  final String label;
  final String value;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: AppSpacing.xs),
      child: Row(
        children: [
          Expanded(
            child: Text(label, style: text.bodySmall),
          ),
          Text(
            value,
            style: text.titleSmall?.copyWith(color: color),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Banner
// ---------------------------------------------------------------------------

enum _BannerTone { info, warning, error }

class _Banner extends StatelessWidget {
  const _Banner({required this.icon, required this.text, required this.tone});

  final IconData icon;
  final String text;
  final _BannerTone tone;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final market = MarketColors.of(context);

    final color = switch (tone) {
      _BannerTone.info => scheme.primary,
      _BannerTone.warning => market.stale,
      _BannerTone.error => scheme.error,
    };

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.md,
        vertical: AppSpacing.md,
      ),
      decoration: BoxDecoration(
        color: color.withOpacity(0.10),
        borderRadius: BorderRadius.circular(AppRadius.md),
        border: Border.all(color: color.withOpacity(0.35)),
      ),
      child: Row(
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(width: AppSpacing.sm),
          Expanded(
            child: Text(
              text,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: scheme.onSurface,
                  ),
            ),
          ),
        ],
      ),
    );
  }
}
