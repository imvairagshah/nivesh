// ---------------------------------------------------------------------------
// rsi_screener_provider.dart — state for the RSI scanner tab.
//
// Mirrors the Golden Cross provider on purpose (same lifecycle, same failure
// language, same "cached first, scan on demand" behaviour) so the two tabs feel
// like one product:
//
//   bootstrap()          → last cached table, then the universe is resolved
//   run()                → rate-limited scan with progress + cancel
//   setUniverse()        → switch F&O ⇄ all stocks, persisted in settings
//   setThresholds()      → period / upper / lower, persisted in settings
//   rowsFor(RsiZone)     → the two tables (overbought, oversold)
//
// One deliberate difference: this scanner computes *both* sides in a single
// pass, so switching between the "67 ke upar" and "33 ke neeche" lists never
// costs another API call.
// ---------------------------------------------------------------------------

import 'package:flutter/foundation.dart';

import '../../data/local/dao/ipo_dao.dart';
import '../../data/local/dao/scrip_dao.dart';
import '../../data/remote/api_client.dart';
import '../../data/remote/dto/scrip.dart';
import '../../services/fno_universe.dart';
import '../../services/rsi_scan_service.dart';
import '../../services/scrip_master_service.dart';
import '../../services/universe_catalog.dart';
import '../../core/utils/markets.dart';
import '../settings/settings_provider.dart';
import 'rsi_engine.dart';

class RsiScreenerProvider extends ChangeNotifier {
  RsiScreenerProvider({
    required RsiScanService scan,
    required SettingsProvider settings,
    required ScripDao scripDao,
    required IpoDao ipoDao,
    required ScripMasterService scripMaster,
    FnoUniverse? fnoUniverse,
  })  : _scan = scan,
        _settings = settings,
        _scripDao = scripDao,
        _ipoDao = ipoDao,
        _scripMaster = scripMaster,
        _fno = fnoUniverse {
    _settings.addListener(onSettingsChanged);
  }

  final RsiScanService _scan;
  final SettingsProvider _settings;
  final ScripDao _scripDao;
  final IpoDao _ipoDao;
  final ScripMasterService _scripMaster;

  FnoUniverse? _fno;

  RsiScanResult? _result;
  RsiScanProgress? _progress;
  UniverseResolution _universe = UniverseResolution.empty;
  RsiZone _zone = RsiZone.overbought;

  bool _scanning = false;
  bool _cancelled = false;
  bool _loadingCache = true;
  bool _resolvingUniverse = false;
  String? _error;

  // -------------------------------------------------------------------------
  // Read-only state
  // -------------------------------------------------------------------------

  RsiScanResult? get result => _result;
  bool get isLoadingCache => _loadingCache;
  bool get isScanning => _scanning;
  bool get isResolvingUniverse => _resolvingUniverse;
  RsiScanProgress? get progress => _progress;
  String? get error => _error;
  UniverseResolution get universe => _universe;
  RsiZone get zone => _zone;

  /// Thresholds in force: exactly the persisted ones (period, upper, lower).
  RsiThresholds get thresholds => RsiThresholds(
        period: _settings.settings.rsiPeriod,
        upper: _settings.settings.rsiUpper,
        lower: _settings.settings.rsiLower,
      ).sanitised();

  String get universeKey => _settings.settings.rsiUniverse;
  String get universeLabel => _universe.label;

  /// How many F&O names the shipped list holds (for the picker subtitle).
  int get fnoCount => _fno?.length ?? 0;

  bool get hasResult => _result != null;
  bool get isViewingCached => _result?.fromCacheOnly ?? false;
  bool get isStale =>
      _result != null && _result!.isStaleFor(MarketCalendar.latestTradingDay());
  bool get canScan => !_scanning && !_universe.isEmpty;

  // These read through the result's own getters, so a settings change that
  // re-labels the table (see setThresholds) is reflected in the counts too.
  int get overboughtCount => _result?.overboughtCount ?? 0;
  int get oversoldCount => _result?.oversoldCount ?? 0;
  int get freshCount => _result?.freshCount ?? 0;
  int get hitCount => _result?.hitCount ?? 0;

  /// Rows currently shown (the selected zone's table).
  List<RsiReading> get rows => _result?.rowsFor(_zone) ?? const [];

  List<RsiReading> rowsFor(RsiZone zone) => _result?.rowsFor(zone) ?? const [];

  /// Skips are never hidden — the sheet behind the "N skips" chip lists them.
  List<RsiSkip> get skips => _result?.skips ?? const [];
  int get skipCount => _result?.skips.length ?? 0;

  /// Above this many instruments the UI asks for confirmation first.
  bool get needsConfirmation =>
      _universe.size > RsiScanService.confirmAbove && !hasResult;

  /// `~80 s` for 213 F&O names, `~12 min` for the whole NSE master — shown next
  /// to the Scan button before the user commits.
  String get scanEstimate {
    final size = _universe.size;
    if (size == 0) return '';
    // 360 ms per symbol when everything has to be downloaded; a warm candle
    // cache (the Golden Cross tab shares it) makes a re-scan seconds.
    final seconds = (size * 0.36).round();
    if (seconds < 90) return '~${seconds}s';
    return '~${(seconds / 60).round()} min';
  }

  /// One-line status used under the scan bar.
  String get statusLine {
    if (_resolvingUniverse) return 'Instruments resolve ho rahe hain…';
    final result = _result;
    if (result == null) return 'Abhi tak koi scan nahi — Scan now dabaiye.';
    if (result.fromCacheOnly) {
      return 'Cached result (${result.overbought.length + result.oversold.length} '
          'rows) — Scan now se taaza karein.';
    }
    return result.summary;
  }

  // -------------------------------------------------------------------------
  // Lifecycle
  // -------------------------------------------------------------------------

  Future<void> bootstrap() async {
    _loadingCache = true;
    notifyListeners();

    try {
      final cached = await _scan.loadCached();
      if (cached != null) _result = cached;
    } catch (e) {
      _error = 'Cached scan padha nahi ja saka: $e';
    } finally {
      _loadingCache = false;
      notifyListeners();
    }

    await resolveUniverse();
  }

  /// Resolves the configured universe against local data (no network).
  Future<void> resolveUniverse({String? key}) async {
    final wanted = key ?? universeKey;
    _resolvingUniverse = true;
    notifyListeners();

    try {
      final universe = UniverseCatalog.byKey(wanted);

      // The F&O list comes from the shipped CSV (broker-sourced, 213 names).
      final fno = universe.key == UniverseCatalog.fno
          ? (_fno ??= await FnoUniverse.load())
          : null;

      final resolver = universe.dynamic == false
          ? await _scripMaster.resolver()
          : null;

      _universe = await UniverseCatalog.resolve(
        wanted,
        scripDao: _scripDao,
        ipoDao: _ipoDao,
        resolver: resolver,
        fnoSymbols: fno?.symbols,
      );

      if (fno != null && fno.isEmpty) {
        _error = 'F&O list nahi mili — dusra universe chuniye.';
      }
    } catch (e) {
      _error = 'Universe resolve nahi hua: $e';
    } finally {
      _resolvingUniverse = false;
      notifyListeners();
    }
  }

  // -------------------------------------------------------------------------
  // Scanning
  // -------------------------------------------------------------------------

  Future<void> run({DateTime? asOf}) async {
    if (_scanning) return;

    final day = asOf ?? MarketCalendar.latestTradingDay();
    _error = null;
    _scanning = true;
    _cancelled = false;
    _progress = null;
    notifyListeners();

    try {
      if (_universe.isEmpty) await resolveUniverse();
      if (_universe.isEmpty) {
        throw StateError(
          'Is universe me koi instrument resolve nahi hua '
          '("${UniverseCatalog.byKey(universeKey).label}"). Picker se dusra '
          'universe chuniye.',
        );
      }

      final result = await _scan.scan(
        universe: _universe.scrips,
        asOf: day,
        thresholds: thresholds,
        universeKey: universeKey,
        companyNames: _companyNames,
        onProgress: (p) {
          _progress = p;
          notifyListeners();
        },
        isCancelled: () => _cancelled,
      );

      _result = result;
      // Nothing hit on one side? Show the side that did — an empty table with
      // 0/0 next to it reads like a broken screen.
      if (result.rowsFor(_zone).isEmpty && result.hitCount > 0) {
        _zone = result.overbought.isNotEmpty ? RsiZone.overbought : RsiZone.oversold;
      }
    } on ApiException catch (e) {
      _error = e.isAuthError
          ? '${e.message} Settings me dobara login karein.'
          : e.message;
    } catch (e) {
      _error = '$e';
    } finally {
      _scanning = false;
      _progress = null;
      notifyListeners();
    }
  }

  /// Asks the running scan to stop after the current instrument.
  void cancel() {
    if (!_scanning) return;
    _cancelled = true;
    notifyListeners();
  }

  /// Drops the rendered table (candles stay cached, so the next scan is quick).
  Future<void> clearScanCache() async {
    _result = null;
    notifyListeners();
    await _scan.clearCache();
  }

  // -------------------------------------------------------------------------
  // Settings
  // -------------------------------------------------------------------------

  Future<void> setZone(RsiZone zone) async {
    if (_zone == zone) return;
    _zone = zone;
    notifyListeners();
  }

  Future<void> setUniverse(String key) async {
    await _settings.setRsiUniverse(key);
    await resolveUniverse(key: key);
    notifyListeners();
  }

  /// Persists the three threshold values together, then re-labels the cached
  /// table with them (no API call — the RSI numbers themselves are unchanged).
  Future<void> setThresholds(RsiThresholds next) async {
    final clean = next.sanitised();
    await _settings.setRsiThresholds(
      period: clean.period,
      upper: clean.upper,
      lower: clean.lower,
    );
    final result = _result;
    if (result != null) {
      // Only the *labels* change: the scan's rows are kept as they are and the
      // active thresholds decide which of them are shown (see RsiScanResult).
      // That makes tightening and loosening the levels fully reversible.
      _result = RsiScanResult(
        asOf: result.asOf,
        runAt: result.runAt,
        universeKey: result.universeKey,
        thresholds: clean,
        duration: result.duration,
        universeSize: result.universeSize,
        scanned: result.scanned,
        fromCache: result.fromCache,
        fetched: result.fetched,
        cancelled: result.cancelled,
        fromCacheOnly: result.fromCacheOnly,
        overbought: result.overbought,
        oversold: result.oversold,
        skips: result.skips,
      );
    }
    notifyListeners();
  }

  Future<void> onSettingsChanged() async {
    notifyListeners();
  }

  /// Cheap size hints for the picker — plain row counts, no network.
  Future<Map<String, int>> universeSizeHints() async {
    try {
      final results = await Future.wait([
        _ipoDao.count(),
        _scripDao.count(exchange: 'NSE'),
        _scripDao.count(),
      ]);
      return {
        UniverseCatalog.fno: _fno?.length ?? 0,
        UniverseCatalog.nifty50: UniverseCatalog.nifty50Symbols.length,
        UniverseCatalog.ipos: results[0],
        UniverseCatalog.masterNse: results[1],
        UniverseCatalog.masterAll: results[2],
      };
    } catch (_) {
      return const {};
    }
  }

  /// Scrips behind the current universe — exposed for tests and for the
  /// "resolved" line in the picker.
  List<Scrip> get scrips => _universe.scrips;

  /// `TICKER → company name`: what the shipped F&O list knows. Companies it does
  /// not know fall back to the ticker in the table (never a made-up name).
  Map<String, String> get _companyNames =>
      _fno?.companyNames ?? const <String, String>{};

  @override
  void dispose() {
    _settings.removeListener(onSettingsChanged);
    super.dispose();
  }
}
