// ---------------------------------------------------------------------------
// rsi_sheets.dart — the two configuration sheets of the RSI scanner.
//
//   • universe  — F&O stocks (default) ⇄ Nifty 50 ⇄ IPO database ⇄ all NSE
//                 equities ⇄ NSE + BSE. Counts are row counts, not resolutions,
//                 so opening this sheet never costs a network call.
//   • thresholds — Wilder period and the two levels (defaults 14 / 67 / 33),
//                 validated before saving: upper must stay above lower, period
//                 between 2 and 200.
//
// Both are plain bottom sheets using the design system's shapes (radius 24,
// drag handle, flat) — no new visual vocabulary.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../services/cross_scan_service.dart' show ScanUniverse;
import '../../../services/universe_catalog.dart';
import '../rsi_engine.dart';
import '../rsi_screener_provider.dart';

// ---------------------------------------------------------------------------
// Universe
// ---------------------------------------------------------------------------

Future<void> showRsiUniverseSheet(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (_) => const _RsiUniverseSheet(),
  );
}

class _RsiUniverseSheet extends StatefulWidget {
  const _RsiUniverseSheet();

  @override
  State<_RsiUniverseSheet> createState() => _RsiUniverseSheetState();
}

class _RsiUniverseSheetState extends State<_RsiUniverseSheet> {
  Map<String, int> _hints = const {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      final hints = await context.read<RsiScreenerProvider>().universeSizeHints();
      if (mounted) setState(() => _hints = hints);
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<RsiScreenerProvider>();
    final text = Theme.of(context).textTheme;
    final scheme = Theme.of(context).colorScheme;
    final selected = provider.universeKey;

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(
          AppSpacing.lg,
          0,
          AppSpacing.lg,
          AppSpacing.xl,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Kaun se stocks scan karne hain?', style: text.titleMedium),
            const SizedBox(height: AppSpacing.xs),
            Text(
              'Scan har instrument ka daily candle mangta hai (3 request/second) '
              '— bada universe pehli baar slow hai, dobara scan cache se turant.',
              style: text.bodySmall,
            ),
            const SizedBox(height: AppSpacing.lg),
            for (final universe in UniverseCatalog.all)
              _UniverseTile(
                universe: universe,
                selected: universe.key == selected,
                count: _hints[universe.key],
                onTap: provider.isScanning
                    ? null
                    : () async {
                        Navigator.of(context).pop();
                        await provider.setUniverse(universe.key);
                      },
              ),
            const SizedBox(height: AppSpacing.md),
            Row(
              children: [
                Icon(Icons.info_outline_rounded,
                    size: 15, color: scheme.onSurfaceVariant),
                const SizedBox(width: AppSpacing.sm),
                Expanded(
                  child: Text(
                    'F&O list broker ke scrip master se banti hai (stock futures '
                    'jis company ke hote hain) — abhi ${provider.fnoCount} naam, '
                    'aur symbol hamesha ISIN se resolve hota hai.',
                    style: text.labelSmall,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _UniverseTile extends StatelessWidget {
  const _UniverseTile({
    required this.universe,
    required this.selected,
    required this.onTap,
    this.count,
  });

  final ScanUniverse universe;
  final bool selected;
  final VoidCallback? onTap;
  final int? count;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final text = Theme.of(context).textTheme;

    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.sm),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppRadius.md),
        child: Container(
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.md,
            vertical: AppSpacing.md,
          ),
          decoration: BoxDecoration(
            color: selected
                ? scheme.primaryContainer.withOpacity(0.45)
                : scheme.surfaceContainerHighest.withOpacity(0.35),
            borderRadius: BorderRadius.circular(AppRadius.md),
            border: Border.all(
              color: selected
                  ? scheme.primary.withOpacity(0.55)
                  : scheme.outlineVariant.withOpacity(0.6),
            ),
          ),
          child: Row(
            children: [
              Icon(
                selected
                    ? Icons.radio_button_checked_rounded
                    : Icons.radio_button_unchecked_rounded,
                size: 18,
                color: selected ? scheme.primary : scheme.onSurfaceVariant,
              ),
              const SizedBox(width: AppSpacing.md),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(universe.label, style: text.titleSmall),
                        ),
                        if (count != null) ...[
                          const SizedBox(width: AppSpacing.sm),
                          Text('$count', style: text.labelSmall),
                        ],
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(universe.description, style: text.bodySmall),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Thresholds
// ---------------------------------------------------------------------------

Future<void> showRsiThresholdsSheet(
  BuildContext context, {
  required RsiThresholds initial,
  required Future<void> Function(RsiThresholds) onSaved,
}) {
  return showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (_) => Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: _RsiThresholdsSheet(initial: initial, onSaved: onSaved),
    ),
  );
}

class _RsiThresholdsSheet extends StatefulWidget {
  const _RsiThresholdsSheet({required this.initial, required this.onSaved});

  final RsiThresholds initial;
  final Future<void> Function(RsiThresholds) onSaved;

  @override
  State<_RsiThresholdsSheet> createState() => _RsiThresholdsSheetState();
}

class _RsiThresholdsSheetState extends State<_RsiThresholdsSheet> {
  late final TextEditingController _period =
      TextEditingController(text: '${widget.initial.period}');
  late final TextEditingController _upper =
      TextEditingController(text: _trim(widget.initial.upper));
  late final TextEditingController _lower =
      TextEditingController(text: _trim(widget.initial.lower));

  String? _error;
  bool _saving = false;

  static String _trim(double v) =>
      v == v.roundToDouble() ? v.toStringAsFixed(0) : '$v';

  @override
  void dispose() {
    _period.dispose();
    _upper.dispose();
    _lower.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final period = int.tryParse(_period.text.trim());
    final upper = double.tryParse(_upper.text.trim());
    final lower = double.tryParse(_lower.text.trim());

    if (period == null || upper == null || lower == null) {
      setState(() => _error = 'Teeno values number me likhiye.');
      return;
    }
    if (period < 2 || period > 200) {
      setState(() => _error = 'Period 2 se 200 ke beech rakhiye.');
      return;
    }
    if (upper <= lower) {
      setState(() => _error = 'Upar wala level neeche wale se bada hona chahiye.');
      return;
    }
    if (upper > 100 || lower < 0) {
      setState(() => _error = 'RSI 0 se 100 ke beech hota hai.');
      return;
    }

    setState(() {
      _saving = true;
      _error = null;
    });

    await widget.onSaved(RsiThresholds(period: period, upper: upper, lower: lower));
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    final scheme = Theme.of(context).colorScheme;

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(
          AppSpacing.lg,
          0,
          AppSpacing.lg,
          AppSpacing.xl,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('RSI settings', style: text.titleMedium),
            const SizedBox(height: AppSpacing.xs),
            Text(
              'Standard Wilder RSI hai (14 period). Level badalne par table turant '
              're-label ho jati hai — dobara scan ki zaroorat nahi.',
              style: text.bodySmall,
            ),
            const SizedBox(height: AppSpacing.lg),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _period,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Period',
                      helperText: 'Wilder (14)',
                    ),
                  ),
                ),
                const SizedBox(width: AppSpacing.md),
                Expanded(
                  child: TextField(
                    controller: _upper,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                      labelText: 'Upar',
                      helperText: 'Overbought',
                    ),
                  ),
                ),
                const SizedBox(width: AppSpacing.md),
                Expanded(
                  child: TextField(
                    controller: _lower,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                      labelText: 'Neeche',
                      helperText: 'Oversold',
                    ),
                  ),
                ),
              ],
            ),
            if (_error != null) ...[
              const SizedBox(height: AppSpacing.sm),
              Text(
                _error!,
                style: text.bodySmall?.copyWith(color: scheme.error),
              ),
            ],
            const SizedBox(height: AppSpacing.lg),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: _saving
                        ? null
                        : () {
                            _period.text = '14';
                            _upper.text = '67';
                            _lower.text = '33';
                            setState(() => _error = null);
                          },
                    child: const Text('Default (14 · 67 · 33)'),
                  ),
                ),
                const SizedBox(width: AppSpacing.md),
                Expanded(
                  child: FilledButton(
                    onPressed: _saving ? null : _save,
                    child: Text(_saving ? 'Save…' : 'Save'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.md),
            Row(
              children: [
                Icon(Icons.lightbulb_outline_rounded,
                    size: 15, color: scheme.onSurfaceVariant),
                const SizedBox(width: AppSpacing.sm),
                Expanded(
                  child: Text(
                    'Bars chahiye: period × 4 '
                    '(14 ke liye ~56 din) — itni history na ho to woh symbol '
                    '"skip" list me dikhta hai, chup-chaap gayab nahi hota.',
                    style: text.labelSmall,
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.xs),
            Text(
              'Last scan: ${Fmt.date(DateTime.now())} tak ka data.',
              style: text.labelSmall,
            ),
          ],
        ),
      ),
    );
  }
}
