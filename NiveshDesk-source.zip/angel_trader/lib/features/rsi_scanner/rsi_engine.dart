// ---------------------------------------------------------------------------
// rsi_engine.dart — Relative Strength Index over daily candles.
//
// Pure Dart on purpose: no Flutter, no network, no database. Everything here can
// be unit-tested against hand-checked numbers, which is exactly what a technical
// indicator needs — a scanner that is 0.5 % wrong is a scanner you cannot trust.
//
// The maths is **Wilder's original smoothing** (the one every charting package
// and broker screen uses), not a simple moving average:
//
//   change[i] = close[i] − close[i-1]
//   seed      = simple mean of the first `period` gains / losses
//   avgGain   = (avgGain × (period − 1) + gain) / period      ← every bar after
//   RS        = avgGain / avgLoss
//   RSI       = 100 − 100 / (1 + RS)
//
// Edge cases that actually show up in a scan, handled explicitly:
//   • a window with no losses at all  → RSI 100
//   • a window with no gains at all   → RSI 0
//   • a dead-flat window (no change)  → RSI 50 (neutral, not 100)
//   • too few bars                    → no value at all (never a guess)
// ---------------------------------------------------------------------------

import '../../core/utils/markets.dart';
import '../../data/remote/dto/candle.dart';
import '../../data/remote/dto/scrip.dart';

/// Which side of the thresholds a reading falls on.
enum RsiZone {
  /// RSI above the upper threshold (default 67) — "overbought".
  overbought,

  /// RSI below the lower threshold (default 33) — "oversold".
  oversold,

  /// Between the two thresholds — not a scan hit.
  neutral;

  bool get isHit => this != RsiZone.neutral;

  String get label => switch (this) {
        RsiZone.overbought => 'Overbought',
        RsiZone.oversold => 'Oversold',
        RsiZone.neutral => 'Neutral',
      };

  /// Gujarati/Hinglish label used in the UI.
  String get hint => switch (this) {
        RsiZone.overbought => 'RSI {{upper}} ke upar',
        RsiZone.oversold => 'RSI {{lower}} ke neeche',
        RsiZone.neutral => 'Beech me',
      };
}

/// The RSI series for one instrument.
///
/// [values] is aligned to the candles it was computed from: `values[i]` is the
/// RSI for candle index `firstIndex + i`, so `values.last` is *today's* RSI and
/// the second-last value is yesterday's — which is what makes "aaj RSI 67 ke
/// upar aaya" (crossed today) checkable instead of a guess.
class RsiSeries {
  const RsiSeries({
    required this.period,
    required this.values,
    required this.firstIndex,
  });

  final int period;
  final List<double> values;
  final int firstIndex;

  bool get isEmpty => values.isEmpty;

  /// RSI on the newest bar.
  double? get latest => values.isEmpty ? null : values.last;

  /// RSI on the bar before that (used for cross detection).
  double? get previous => values.length < 2 ? null : values[values.length - 2];

  static const RsiSeries empty = RsiSeries(period: 14, values: [], firstIndex: 0);
}

/// The thresholds the scanner runs with (brief's defaults: 67 / 33).
class RsiThresholds {
  /// Look-back period. Wilder's classic is 14; 9 (fast) and 21 (slow) are the
  /// usual alternatives.
  final int period;

  /// RSI above this is reported as overbought.
  final double upper;

  /// RSI below this is reported as oversold.
  final double lower;

  const RsiThresholds({
    this.period = 14,
    this.upper = 67,
    this.lower = 33,
  });

  bool get isValid =>
      period >= 2 && period <= 200 && upper > lower && lower >= 0 && upper <= 100;

  /// Clamps to something computable instead of throwing on a bad setting.
  RsiThresholds sanitised() {
    final p = period.clamp(2, 200);
    var lo = lower.clamp(1.0, 99.0);
    var hi = upper.clamp(1.0, 99.0);
    if (hi <= lo) {
      lo = 33;
      hi = 67;
    }
    return RsiThresholds(period: p, upper: hi, lower: lo);
  }

  /// Bars needed before a value is produced at all, plus head-room so Wilder's
  /// smoothed average has actually converged (4 × period ≈ 3 months at 14).
  int get minimumBars => period * 4;

  RsiZone zoneFor(double rsi) {
    if (rsi > upper) return RsiZone.overbought;
    if (rsi < lower) return RsiZone.oversold;
    return RsiZone.neutral;
  }

  RsiThresholds copyWith({int? period, double? upper, double? lower}) =>
      RsiThresholds(
        period: period ?? this.period,
        upper: upper ?? this.upper,
        lower: lower ?? this.lower,
      );

  /// `RSI(14) · 67 / 33` — used on chips and in the settings sheet. Whole
  /// numbers are printed without a trailing `.0` (67, not 67.0).
  String get label => 'RSI($period) · ${_plain(upper)} / ${_plain(lower)}';

  static String _plain(double v) =>
      v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toStringAsFixed(1);

  @override
  String toString() => label;
}

/// One instrument's reading, ready for the table.
class RsiReading {
  /// Plain ticker, e.g. `SBIN` (broker suffixes stripped for display).
  final String symbol;

  /// Company name from the master, shown under the ticker.
  final String companyName;

  final Exchange exchange;

  /// Broker symbol (`SBIN-EQ`) and numeric token — kept so a row can be opened
  /// on a chart without resolving the symbol again.
  final String brokerSymbol;
  final String token;

  /// Last daily close (this scan is candle-based, so it is the close — exactly
  /// the price the RSI was computed from — not a live LTP).
  final double price;

  final double prevClose;

  final double rsi;

  /// Yesterday's RSI — `null` when the series was too short to say.
  final double? prevRsi;

  /// Date of the newest bar used (IST date).
  final DateTime barDate;

  /// Bars the value was computed from.
  final int bars;

  /// Consecutive newest bars already in this reading's zone (1 = today is the
  /// first bar in the zone).
  final int zoneAge;

  const RsiReading({
    required this.symbol,
    required this.companyName,
    required this.exchange,
    required this.brokerSymbol,
    required this.token,
    required this.price,
    required this.prevClose,
    required this.rsi,
    required this.barDate,
    required this.bars,
    this.prevRsi,
    this.zoneAge = 1,
  });

  double get change => prevClose > 0 ? price - prevClose : 0;

  double get changePct =>
      prevClose > 0 ? (price - prevClose) / prevClose * 100 : 0;

  RsiZone zoneIn(RsiThresholds t) => t.zoneFor(rsi);

  /// `true` when RSI moved from at-or-below the upper threshold to above it on
  /// the newest bar — the "aaj 67 ke upar aaya" case.
  bool crossedAbove(double upper) =>
      prevRsi != null && prevRsi! <= upper && rsi > upper;

  /// Mirrored case for the oversold side.
  bool crossedBelow(double lower) =>
      prevRsi != null && prevRsi! >= lower && rsi < lower;

  /// `true` when this row only just entered the zone it is listed under.
  bool isFreshIn(RsiThresholds t) => switch (t.zoneFor(rsi)) {
        RsiZone.overbought => crossedAbove(t.upper),
        RsiZone.oversold => crossedBelow(t.lower),
        RsiZone.neutral => false,
      };

  /// `true` when the reading is outside its zone's extreme part (RSI > 75 or
  /// < 25) — worth a stronger chip colour in the table.
  bool isExtreme(RsiThresholds t) =>
      rsi > t.upper + (100 - t.upper) / 2 || rsi < t.lower / 2;

  @override
  String toString() =>
      '$symbol ₹${price.toStringAsFixed(2)} RSI ${rsi.toStringAsFixed(1)}';

  /// Row written to the scan cache (`scan_runs.payload`).
  Map<String, dynamic> toRow() => {
        'symbol': symbol,
        'name': companyName,
        'exch': exchange.code,
        'broker': brokerSymbol,
        'token': token,
        'price': price,
        'prev': prevClose,
        'rsi': rsi,
        'prevRsi': prevRsi,
        'bar': barDate.toIso8601String(),
        'bars': bars,
        'age': zoneAge,
      };

  static RsiReading fromRow(Map<String, dynamic> row) => RsiReading(
        symbol: '${row['symbol']}',
        companyName: '${row['name'] ?? ''}',
        exchange: Exchange.fromCode('${row['exch'] ?? 'NSE'}'),
        brokerSymbol: '${row['broker'] ?? ''}',
        token: '${row['token'] ?? ''}',
        price: (row['price'] as num? ?? 0).toDouble(),
        prevClose: (row['prev'] as num? ?? 0).toDouble(),
        rsi: (row['rsi'] as num? ?? 0).toDouble(),
        prevRsi: (row['prevRsi'] as num?)?.toDouble(),
        barDate: DateTime.tryParse('${row['bar']}') ?? DateTime(2015),
        bars: (row['bars'] as num? ?? 0).toInt(),
        zoneAge: (row['age'] as num? ?? 1).toInt(),
      );
}

/// Wilder's RSI series for [candles] (oldest → newest).
///
/// Returns [RsiSeries.empty] when there is not enough history — the scanner then
/// reports the row as skipped ("only N daily bars") instead of printing a
/// meaningless number.
RsiSeries wilderRsiSeries(List<Candle> candles, {int period = 14}) {
  if (period < 2 || candles.length < period + 1) return RsiSeries.empty;

  final closes = [for (final c in candles) c.close];
  final gains = <double>[];
  final losses = <double>[];

  for (var i = 1; i < closes.length; i++) {
    final change = closes[i] - closes[i - 1];
    gains.add(change > 0 ? change : 0);
    losses.add(change < 0 ? -change : 0);
  }

  // Seed: simple mean of the first `period` moves…
  var avgGain = 0.0;
  var avgLoss = 0.0;
  for (var i = 0; i < period; i++) {
    avgGain += gains[i];
    avgLoss += losses[i];
  }
  avgGain /= period;
  avgLoss /= period;

  final values = <double>[_rsiFrom(avgGain, avgLoss)];

  // …then Wilder's smoothing for every bar after that.
  for (var i = period; i < gains.length; i++) {
    avgGain = (avgGain * (period - 1) + gains[i]) / period;
    avgLoss = (avgLoss * (period - 1) + losses[i]) / period;
    values.add(_rsiFrom(avgGain, avgLoss));
  }

  return RsiSeries(period: period, values: values, firstIndex: period);
}

/// `100 − 100 / (1 + RS)`, with the degenerate cases pinned down.
double _rsiFrom(double avgGain, double avgLoss) {
  if (avgLoss == 0) return avgGain == 0 ? 50 : 100;
  if (avgGain == 0) return 0;
  final rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
}

/// Builds a table row for [scrip] from its candles, or `null` when the history
/// is too short to produce a trustworthy RSI.
///
/// [asOf] (inclusive) lets a scan be re-run for an older session; bars after it
/// are ignored, so a scan for yesterday can never accidentally use today's bar.
RsiReading? rsiReadingFor({
  required Scrip scrip,
  required List<Candle> candles,
  required RsiThresholds thresholds,
  DateTime? asOf,
  String? companyName,
}) {
  final bars = _upto(candles, asOf);
  if (bars.length < thresholds.minimumBars) return null;

  final series = wilderRsiSeries(bars, period: thresholds.period);
  final rsi = series.latest;
  if (rsi == null) return null;

  final last = bars.last;
  final prev = bars.length >= 2 ? bars[bars.length - 2] : last;

  return RsiReading(
    symbol: Scrip.plainSymbol(scrip.symbol),
    companyName: (companyName ?? scrip.name).trim(),
    exchange: scrip.exchange,
    brokerSymbol: scrip.symbol,
    token: scrip.token,
    price: last.close,
    prevClose: prev.close,
    rsi: rsi,
    prevRsi: series.previous,
    barDate: last.istDate,
    bars: bars.length,
    zoneAge: _zoneAge(series, thresholds),
  );
}

/// Bars up to and including [asOf]'s session (every bar when [asOf] is null).
List<Candle> _upto(List<Candle> candles, DateTime? asOf) {
  if (asOf == null) return candles;
  final day = DateTime(asOf.year, asOf.month, asOf.day);
  return [
    for (final c in candles)
      if (!c.istDate.isAfter(day)) c,
  ];
}

/// How many consecutive newest bars sit in the same zone (capped at 60 so a
/// long-running trend cannot make this unbounded).
int _zoneAge(RsiSeries series, RsiThresholds t) {
  final latest = series.latest;
  if (latest == null) return 0;
  final zone = t.zoneFor(latest);
  var age = 1;
  for (var i = series.values.length - 2; i >= 0 && age < 60; i--) {
    if (t.zoneFor(series.values[i]) != zone) break;
    age++;
  }
  return age;
}

/// Table order: the strongest overbought first, the deepest oversold first, then
/// today's fresh crosses, then alphabetical — a stable, explainable order that
/// does not shuffle between rebuilds.
int compareReadings(
  RsiReading a,
  RsiReading b,
  RsiZone zone,
  RsiThresholds thresholds,
) {
  final primary = zone == RsiZone.oversold
      ? a.rsi.compareTo(b.rsi)
      : b.rsi.compareTo(a.rsi);
  if (primary != 0) return primary;
  final fresh = (b.isFreshIn(thresholds) ? 1 : 0)
      .compareTo(a.isFreshIn(thresholds) ? 1 : 0);
  if (fresh != 0) return fresh;
  return a.symbol.compareTo(b.symbol);
}
