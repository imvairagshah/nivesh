// ---------------------------------------------------------------------------
// reports_screen.dart — the Reports tab.
//
// Three views over the same data the Trade Book holds (no extra DB work, so the
// numbers can never disagree with the Paper Trading tab):
//
//   Overall  → headline stats + the 12-month realised P&L bar chart
//   Monthly  → the same months as a table, with win rate and best/worst trade
//   By group → month × group bar chart, plus per-group realised and the live
//              unrealised P&L of whatever is still open
//
// The group filter from the Paper Trading tab applies here too.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/csv_io.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/markets.dart';
import '../../core/widgets/page_scroll.dart';
import '../../data/local/models/paper_trade.dart';
import '../../data/local/models/trade_group.dart';
import '../paper_trading/paper_trading_provider.dart';
import '../paper_trading/report_math.dart';
import '../paper_trading/widgets/group_chips.dart';

enum _ReportView { overall, monthly, byGroup }

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  _ReportView _view = _ReportView.overall;
  String? _selectedMonthKey;

  /// Timestamps in this app are IST wall-clock (see MarketCalendar).
  final DateTime _now = MarketCalendar.nowIst();

  @override
  Widget build(BuildContext context) {
    final paper = context.watch<PaperTradingProvider>();
    final filter = paper.filter;

    // Apply the shared filter locally: Reports always reads the full trade book.
    final trades = paper.tradeBook
        .where((trade) {
          if (filter.ungroupedOnly && trade.groupId != null) return false;
          if (!filter.ungroupedOnly &&
              filter.groupId != null &&
              trade.groupId != filter.groupId) {
            return false;
          }
          final query = filter.query.trim().toUpperCase();
          if (query.isEmpty) return true;
          return trade.displaySymbol.toUpperCase().contains(query);
        })
        .toList(growable: false);

    final holdings = paper.allHoldings
        .where((view) {
          if (filter.ungroupedOnly) return view.position.groupId == null;
          if (filter.groupId != null)
            return view.position.groupId == filter.groupId;
          return true;
        })
        .toList(growable: false);

    final months = ReportMath.monthly(trades, now: _now);
    final overall = ReportMath.overall(trades, now: _now);
    final groups = ReportMath.byGroup(
      trades: trades,
      groups: paper.groups,
      holdings: holdings,
    );

    return Scaffold(
      backgroundColor: Colors.transparent,
      // 1.5.92 — PC fix: poora page ek hi scroll (segmented + filter + cards).
      body: PageScroll.children(
        padding: EdgeInsets.zero,
        onRefresh: () async {
          await paper.refreshPricesViaRest(force: true);
          await paper.refresh(reloadLists: true);
        },
        [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 6),
            child: SegmentedButton<_ReportView>(
              showSelectedIcon: false,
              segments: const [
                ButtonSegment(
                  value: _ReportView.overall,
                  label: Text('Overall'),
                ),
                ButtonSegment(
                  value: _ReportView.monthly,
                  label: Text('Monthly'),
                ),
                ButtonSegment(
                  value: _ReportView.byGroup,
                  label: Text('By group'),
                ),
              ],
              selected: {_view},
              onSelectionChanged: (set) => setState(() => _view = set.first),
            ),
          ),
          const GroupFilterBar(),
          if (paper.tradeBook.isEmpty)
            const _EmptyReports()
          else
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 40),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: switch (_view) {
                  _ReportView.overall => [
                    _SummaryTiles(overall: overall),
                    const SizedBox(height: 12),
                    _MonthlyChart(
                      months: months,
                      selectedKey: _selectedMonthKey,
                      onSelect: (key) =>
                          setState(() => _selectedMonthKey = key),
                    ),
                    const SizedBox(height: 12),
                    _MonthDetail(
                      month: _pickMonth(months, _selectedMonthKey),
                      trades: trades,
                    ),
                    const SizedBox(height: 12),
                    _ExportTile(trades: trades, groups: paper.groups),
                  ],
                  _ReportView.monthly => [
                    _MonthlyTable(months: months),
                    const SizedBox(height: 12),
                    _MonthDetail(
                      month: _pickMonth(months, _selectedMonthKey),
                      trades: trades,
                    ),
                  ],
                  _ReportView.byGroup => [
                    _GroupMonthChart(
                      months: months,
                      groups: groups,
                      trades: trades,
                    ),
                    const SizedBox(height: 12),
                    _GroupTable(groups: groups),
                  ],
                },
              ),
            ),
        ],
      ),
    );
  }

  /// The month selected by tapping a bar, or the newest month that has trades.
  MonthPnl? _pickMonth(List<MonthPnl> months, String? key) {
    if (key != null) {
      for (final month in months) {
        if (month.monthKey == key) return month;
      }
    }
    for (final month in months.reversed) {
      if (!month.isEmpty) return month;
    }
    return null;
  }
}

// ---------------------------------------------------------------------------
// Overall
// ---------------------------------------------------------------------------

class _SummaryTiles extends StatelessWidget {
  const _SummaryTiles({required this.overall});

  final OverallStats overall;

  @override
  Widget build(BuildContext context) {
    final market = MarketColors.of(context);
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        _Tile(
          label: 'Realised P&L',
          value: Fmt.signedMoney(overall.realized),
          color: market.forValue(overall.realized),
          hint: 'net of charges',
        ),
        _Tile(
          label: 'Win rate',
          value: '${(overall.winRate * 100).toStringAsFixed(0)}%',
          hint:
              '${overall.wins}W · ${overall.losses}L of '
              '${overall.closedTrades} closed',
        ),
        _Tile(
          label: 'Charges paid',
          value: Fmt.money(overall.charges),
          hint: 'brokerage + taxes',
        ),
        _Tile(
          label: 'Expectancy / trade',
          value: Fmt.signedMoney(overall.expectancy),
          color: market.forValue(overall.expectancy),
        ),
        _Tile(
          label: 'Best trade',
          value: Fmt.signedMoney(overall.biggestWin),
          color: market.gain,
        ),
        _Tile(
          label: 'Worst trade',
          value: Fmt.signedMoney(overall.biggestLoss),
          color: market.loss,
        ),
        _Tile(
          label: 'Profit factor',
          value: overall.profitFactor == null
              ? '—'
              : overall.profitFactor!.toStringAsFixed(2),
          hint: overall.profitFactor == null
              ? 'no losing trades yet'
              : 'wins ÷ losses',
        ),
        _Tile(
          label: 'Best month',
          value: overall.bestMonth == null
              ? '—'
              : '${overall.bestMonth!.label} · '
                    '${Fmt.signedMoney(overall.bestMonth!.realized)}',
          color: market.gain,
        ),
      ],
    );
  }
}

class _Tile extends StatelessWidget {
  const _Tile({
    required this.label,
    required this.value,
    this.hint,
    this.color,
  });

  final String label;
  final String value;
  final String? hint;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      width: 158,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest.withOpacity(0.5),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
          if (hint != null)
            Text(
              hint!,
              style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant),
            ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Charts
// ---------------------------------------------------------------------------

/// Twelve months of realised P&L. Green bars made money, red bars lost.
class _MonthlyChart extends StatelessWidget {
  const _MonthlyChart({
    required this.months,
    required this.selectedKey,
    required this.onSelect,
  });

  final List<MonthPnl> months;
  final String? selectedKey;
  final ValueChanged<String> onSelect;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final market = MarketColors.of(context);

    var minValue = 0.0;
    var maxValue = 0.0;
    for (final month in months) {
      if (month.realized < minValue) minValue = month.realized;
      if (month.realized > maxValue) maxValue = month.realized;
    }
    // Never let a flat month produce a degenerate axis.
    if (maxValue == 0 && minValue == 0) maxValue = 1000;
    final span = (maxValue - minValue).abs();
    final maxY = maxValue + span * 0.18 + 1;
    final minY = minValue - span * 0.18 - 1;

    return _ChartCard(
      title: 'Monthly realised P&L',
      subtitle: 'Tap a bar for that month\'s detail',
      child: SizedBox(
        height: 190,
        child: BarChart(
          BarChartData(
            alignment: BarChartAlignment.spaceAround,
            maxY: maxY,
            minY: minY,
            gridData: FlGridData(
              show: true,
              drawVerticalLine: false,
              horizontalInterval: _axisStep(maxY - minY),
              getDrawingHorizontalLine: (_) => FlLine(
                color: scheme.outlineVariant.withOpacity(0.4),
                strokeWidth: 1,
              ),
            ),
            borderData: FlBorderData(show: false),
            extraLinesData: ExtraLinesData(
              horizontalLines: [
                HorizontalLine(
                  y: 0,
                  color: scheme.outline.withOpacity(0.7),
                  strokeWidth: 1,
                ),
              ],
            ),
            titlesData: FlTitlesData(
              topTitles: const AxisTitles(
                sideTitles: SideTitles(showTitles: false),
              ),
              rightTitles: const AxisTitles(
                sideTitles: SideTitles(showTitles: false),
              ),
              leftTitles: AxisTitles(
                sideTitles: SideTitles(
                  showTitles: true,
                  reservedSize: 44,
                  interval: _axisStep(maxY - minY),
                  getTitlesWidget: (value, meta) => SideTitleWidget(
                    meta: meta,
                    child: Text(
                      _compact(value),
                      style: TextStyle(
                        fontSize: 9,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                  ),
                ),
              ),
              bottomTitles: AxisTitles(
                sideTitles: SideTitles(
                  showTitles: true,
                  reservedSize: 24,
                  getTitlesWidget: (value, meta) {
                    final index = value.round();
                    if (index < 0 || index >= months.length) {
                      return const SizedBox.shrink();
                    }
                    final month = months[index];
                    final selected = month.monthKey == selectedKey;
                    return SideTitleWidget(
                      meta: meta,
                      child: Text(
                        month.label.split(' ').first,
                        style: TextStyle(
                          fontSize: 9,
                          fontWeight: selected
                              ? FontWeight.w700
                              : FontWeight.w400,
                          color: selected
                              ? scheme.primary
                              : scheme.onSurfaceVariant,
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
            barTouchData: BarTouchData(
              handleBuiltInTouches: true,
              touchCallback: (event, response) {
                if (!event.isInterestedForInteractions) return;
                final index = response?.spot?.touchedBarGroupIndex;
                if (index == null || index < 0 || index >= months.length)
                  return;
                onSelect(months[index].monthKey);
              },
              touchTooltipData: BarTouchTooltipData(
                getTooltipColor: (_) => scheme.inverseSurface,
                getTooltipItem: (group, groupIndex, rod, rodIndex) {
                  final month = months[group.x];
                  return BarTooltipItem(
                    '${month.label}\n'
                    '${Fmt.signedMoney(month.realized)}\n'
                    '${month.closedTrades} closed · '
                    '${(month.winRate * 100).toStringAsFixed(0)}% win',
                    TextStyle(fontSize: 11, color: scheme.onInverseSurface),
                  );
                },
              ),
            ),
            barGroups: [
              for (var i = 0; i < months.length; i++)
                BarChartGroupData(
                  x: i,
                  barRods: [
                    BarChartRodData(
                      toY: months[i].realized,
                      fromY: 0,
                      width: 16,
                      color: months[i].isEmpty
                          ? scheme.outlineVariant
                          : market.forValue(months[i].realized),
                      borderRadius: BorderRadius.circular(3),
                      borderSide: months[i].monthKey == selectedKey
                          ? BorderSide(color: scheme.primary, width: 1.6)
                          : BorderSide.none,
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Month × group: for each of the last six months, one bar per group that
/// traded in it, coloured from the shared group palette.
class _GroupMonthChart extends StatelessWidget {
  const _GroupMonthChart({
    required this.months,
    required this.groups,
    required this.trades,
  });

  final List<MonthPnl> months;

  /// Groups with realised history (already sorted best-first).
  final List<GroupReport> groups;

  /// Every leg the Reports tab is looking at (already filtered).
  final List<Trade> trades;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final chartGroups = ReportMath.chartGroups(groups);
    final window = months.length > 6
        ? months.sublist(months.length - 6)
        : months;

    // Per (month, group) realised totals. An ungrouped leg is keyed -1 because
    // `null` cannot be a Map<int, double> key.
    final matrix = <String, Map<int, double>>{};
    for (final month in window) {
      matrix[month.monthKey] = <int, double>{};
    }
    for (final trade in trades) {
      final pnl = trade.realizedPnl;
      if (pnl == null) continue; // opening legs have no result
      final bucket = matrix[ReportMath.monthKeyOf(trade.executedAt)];
      if (bucket == null) continue; // older than the window
      final key = trade.groupId ?? -1;
      bucket[key] = (bucket[key] ?? 0) + pnl;
    }

    if (chartGroups.isEmpty) {
      return _ChartCard(
        title: 'Month × group',
        subtitle: 'Nothing realised yet',
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 26),
          child: Text(
            'Close a paper trade in a group to see how each basket performs '
            'month by month.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant),
          ),
        ),
      );
    }

    return _ChartCard(
      title: 'Month × group',
      subtitle: 'Realised P&L per basket, last ${window.length} months',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: 190,
            child: _GroupBars(
              window: window,
              chartGroups: chartGroups,
              matrix: matrix,
            ),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 10,
            runSpacing: 4,
            children: [
              for (final group in chartGroups)
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 9,
                      height: 9,
                      decoration: BoxDecoration(
                        color: GroupPalette.colorAt(group.colorIndex),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    const SizedBox(width: 4),
                    Text(group.name, style: const TextStyle(fontSize: 10.5)),
                  ],
                ),
            ],
          ),
        ],
      ),
    );
  }
}

/// The bar chart itself. Split out so it can be built after the month → group
/// matrix has been filled by the caller.
class _GroupBars extends StatelessWidget {
  const _GroupBars({
    required this.window,
    required this.chartGroups,
    required this.matrix,
  });

  final List<MonthPnl> window;
  final List<GroupReport> chartGroups;
  final Map<String, Map<int, double>> matrix;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    // Values arrive pre-computed by the caller in [matrix] (month → group →
    // realised). This widget only scales and draws them.
    var minValue = 0.0;
    var maxValue = 0.0;
    for (final month in window) {
      for (final group in chartGroups) {
        final value = matrix[month.monthKey]?[group.groupId ?? -1] ?? 0;
        if (value < minValue) minValue = value;
        if (value > maxValue) maxValue = value;
      }
    }
    if (maxValue == 0 && minValue == 0) maxValue = 1000;
    final span = (maxValue - minValue).abs();
    final maxY = maxValue + span * 0.2 + 1;
    final minY = minValue - span * 0.2 - 1;

    return BarChart(
      BarChartData(
        alignment: BarChartAlignment.spaceAround,
        maxY: maxY,
        minY: minY,
        gridData: FlGridData(
          show: true,
          drawVerticalLine: false,
          horizontalInterval: _axisStep(maxY - minY),
          getDrawingHorizontalLine: (_) => FlLine(
            color: scheme.outlineVariant.withOpacity(0.4),
            strokeWidth: 1,
          ),
        ),
        borderData: FlBorderData(show: false),
        extraLinesData: ExtraLinesData(
          horizontalLines: [
            HorizontalLine(
              y: 0,
              color: scheme.outline.withOpacity(0.7),
              strokeWidth: 1,
            ),
          ],
        ),
        titlesData: FlTitlesData(
          topTitles: const AxisTitles(
            sideTitles: SideTitles(showTitles: false),
          ),
          rightTitles: const AxisTitles(
            sideTitles: SideTitles(showTitles: false),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 44,
              interval: _axisStep(maxY - minY),
              getTitlesWidget: (value, meta) => SideTitleWidget(
                meta: meta,
                child: Text(
                  _compact(value),
                  style: TextStyle(fontSize: 9, color: scheme.onSurfaceVariant),
                ),
              ),
            ),
          ),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 24,
              getTitlesWidget: (value, meta) {
                final index = value.round();
                if (index < 0 || index >= window.length) {
                  return const SizedBox.shrink();
                }
                return SideTitleWidget(
                  meta: meta,
                  child: Text(
                    window[index].label.split(' ').first,
                    style: TextStyle(
                      fontSize: 9,
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
                );
              },
            ),
          ),
        ),
        barTouchData: BarTouchData(
          handleBuiltInTouches: true,
          touchTooltipData: BarTouchTooltipData(
            getTooltipColor: (_) => scheme.inverseSurface,
            getTooltipItem: (group, groupIndex, rod, rodIndex) {
              final month = window[group.x];
              final report = rodIndex < chartGroups.length
                  ? chartGroups[rodIndex]
                  : null;
              return BarTooltipItem(
                '${month.label}${report == null ? '' : ' · ${report.name}'}\n'
                '${Fmt.signedMoney(rod.toY)}',
                TextStyle(fontSize: 11, color: scheme.onInverseSurface),
              );
            },
          ),
        ),
        barGroups: [
          for (var i = 0; i < window.length; i++)
            BarChartGroupData(
              x: i,
              barsSpace: 2,
              barRods: [
                for (final report in chartGroups)
                  BarChartRodData(
                    toY: matrix[window[i].monthKey]?[report.groupId ?? -1] ?? 0,
                    fromY: 0,
                    width: chartGroups.length > 4 ? 5 : 8,
                    color: GroupPalette.colorAt(report.colorIndex),
                    borderRadius: BorderRadius.circular(2),
                  ),
              ],
            ),
        ],
      ),
    );
  }
}

class _ChartCard extends StatelessWidget {
  const _ChartCard({
    required this.title,
    required this.subtitle,
    required this.child,
  });

  final String title;
  final String subtitle;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest.withOpacity(0.35),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700),
          ),
          Text(
            subtitle,
            style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
          ),
          const SizedBox(height: 10),
          child,
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Month detail + table
// ---------------------------------------------------------------------------

class _MonthDetail extends StatelessWidget {
  const _MonthDetail({required this.month, required this.trades});

  final MonthPnl? month;
  final List<Trade> trades;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final market = MarketColors.of(context);
    final selected = month;
    if (selected == null) return const SizedBox.shrink();

    final legs = trades
        .where((t) => ReportMath.monthKeyOf(t.executedAt) == selected.monthKey)
        .toList(growable: false);
    final opening = legs.where((t) => !t.isClosingLeg).length;

    return _ChartCard(
      title: '${selected.label} · ${Fmt.signedMoney(selected.realized)}',
      subtitle:
          '${selected.closedTrades} closed · $opening opened · '
          'charges ${Fmt.money(selected.charges)}',
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: _MiniStat(
                  label: 'Wins',
                  value: '${selected.wins}',
                  color: market.gain,
                ),
              ),
              Expanded(
                child: _MiniStat(
                  label: 'Losses',
                  value: '${selected.losses}',
                  color: market.loss,
                ),
              ),
              Expanded(
                child: _MiniStat(
                  label: 'Win rate',
                  value: '${(selected.winRate * 100).toStringAsFixed(0)}%',
                ),
              ),
              Expanded(
                child: _MiniStat(
                  label: 'Best / worst',
                  value: selected.isEmpty
                      ? '—'
                      : '${Fmt.moneyCompact(selected.biggestWin)} / '
                            '${Fmt.moneyCompact(selected.biggestLoss)}',
                ),
              ),
            ],
          ),
          if (selected.isEmpty) ...[
            const SizedBox(height: 8),
            Text(
              'No trades closed in this month.',
              style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
            ),
          ],
        ],
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  const _MiniStat({required this.label, required this.value, this.color});

  final String label;
  final String value;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant),
        ),
        Text(
          value,
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: color,
          ),
        ),
      ],
    );
  }
}

class _MonthlyTable extends StatelessWidget {
  const _MonthlyTable({required this.months});

  final List<MonthPnl> months;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final market = MarketColors.of(context);
    final rows = months.reversed.toList(growable: false);

    return _ChartCard(
      title: 'Month by month',
      subtitle: 'Newest first, including months with no trades',
      child: Column(
        children: [
          for (final month in rows)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(
                children: [
                  SizedBox(
                    width: 52,
                    child: Text(
                      month.label,
                      style: const TextStyle(fontSize: 11.5),
                    ),
                  ),
                  SizedBox(
                    width: 74,
                    child: Text(
                      Fmt.signedMoney(month.realized),
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: month.isEmpty
                            ? null
                            : market.forValue(month.realized),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Text(
                      month.isEmpty
                          ? '—'
                          : '${month.closedTrades} closed · '
                                '${month.wins}W/${month.losses}L · '
                                '${Fmt.moneyCompact(month.charges)} charges',
                      style: TextStyle(
                        fontSize: 10.5,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Group table
// ---------------------------------------------------------------------------

class _GroupTable extends StatelessWidget {
  const _GroupTable({required this.groups});

  final List<GroupReport> groups;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final market = MarketColors.of(context);

    if (groups.isEmpty) {
      return _ChartCard(
        title: 'By group',
        subtitle: 'No groups in play',
        child: Text(
          'Tag a paper trade with a group (Buy/Sell sheet → Group) to break your '
          'P&L down by strategy.',
          style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant),
        ),
      );
    }

    return _ChartCard(
      title: 'By group',
      subtitle: 'Realised so far + live unrealised of open positions',
      child: Column(
        children: [
          for (final group in groups)
            Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: scheme.surface.withOpacity(0.6),
                borderRadius: BorderRadius.circular(10),
                border: Border(
                  left: BorderSide(
                    color: GroupPalette.colorAt(group.colorIndex),
                    width: 4,
                  ),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Row(
                          children: [
                            Flexible(
                              child: Text(
                                group.name,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                            if (group.archived) ...[
                              const SizedBox(width: 5),
                              Icon(
                                Icons.inventory_2_outlined,
                                size: 12,
                                color: scheme.onSurfaceVariant,
                              ),
                            ],
                          ],
                        ),
                      ),
                      Text(
                        Fmt.signedMoney(group.realized),
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: group.hasHistory
                              ? market.forValue(group.realized)
                              : scheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 3),
                  Text(
                    group.hasHistory
                        ? '${group.closedTrades} closed · ${group.wins}W/'
                              '${group.losses}L · '
                              '${(group.winRate * 100).toStringAsFixed(0)}% win rate'
                        : 'No trades closed yet',
                    style: TextStyle(
                      fontSize: 10.5,
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
                  if (group.hasOpen) ...[
                    const SizedBox(height: 5),
                    Row(
                      children: [
                        Icon(
                          Icons.account_balance_wallet_outlined,
                          size: 12,
                          color: scheme.onSurfaceVariant,
                        ),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            '${group.openCount} open · invested '
                            '${Fmt.moneyCompact(group.openInvested)}'
                            '${group.openUnrealized == null ? ' · awaiting a price' : ''}',
                            style: TextStyle(
                              fontSize: 10.5,
                              color: scheme.onSurfaceVariant,
                            ),
                          ),
                        ),
                        if (group.openUnrealized != null)
                          Text(
                            '${Fmt.signedMoney(group.openUnrealized)} live',
                            style: TextStyle(
                              fontSize: 11.5,
                              fontWeight: FontWeight.w600,
                              color: market.forValue(group.openUnrealized),
                            ),
                          ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
          const SizedBox(height: 4),
          Text(
            'Group totals include every leg that carried the tag, even after a '
            'position was closed or the group was archived.',
            style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Export
// ---------------------------------------------------------------------------

class _ExportTile extends StatelessWidget {
  const _ExportTile({required this.trades, required this.groups});

  final List<Trade> trades;
  final List<TradeGroup> groups;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return OutlinedButton.icon(
      onPressed: () async {
        final csv = _buildCsv();
        await Clipboard.setData(ClipboardData(text: csv));
        if (!context.mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${trades.length} legs copied as CSV.')),
        );
      },
      icon: const Icon(Icons.table_view_outlined, size: 18),
      label: Text(
        'Export ${trades.length} legs as CSV',
        style: TextStyle(color: scheme.onSurface),
      ),
    );
  }

  String _buildCsv() {
    final rows = <List<String>>[
      [
        'Month',
        'Group',
        'Symbol',
        'Exchange',
        'Side',
        'Qty',
        'Price',
        'Value',
        'Charges',
        'Realised PnL',
        'Executed At',
        'Note',
      ],
    ];
    for (final trade in trades) {
      final groupName = _groupName(trade.groupId);
      rows.add([
        ReportMath.monthKeyOf(trade.executedAt),
        groupName,
        trade.displaySymbol,
        trade.exchange.code,
        trade.side.label.toUpperCase(),
        '${trade.quantity}',
        trade.price.toStringAsFixed(2),
        trade.value.toStringAsFixed(2),
        trade.charges.toStringAsFixed(2),
        (trade.realizedPnl ?? 0).toStringAsFixed(2),
        Fmt.isoDate(trade.executedAt),
        trade.note,
      ]);
    }
    return CsvCodec.encode(rows);
  }

  String _groupName(int? id) {
    if (id == null) return 'Ungrouped';
    for (final group in groups) {
      if (group.id == id) return group.name;
    }
    return 'Ungrouped';
  }
}

// ---------------------------------------------------------------------------
// Helpers + empty state
// ---------------------------------------------------------------------------

class _EmptyReports extends StatelessWidget {
  const _EmptyReports();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return ListView(
      padding: const EdgeInsets.fromLTRB(28, 60, 28, 40),
      children: [
        Icon(Icons.insights_outlined, size: 46, color: scheme.onSurfaceVariant),
        const SizedBox(height: 12),
        const Text(
          'No results yet',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 6),
        Text(
          'Close a paper trade in the Paper Trading tab and this page fills with '
          'your monthly P&L, win rate and a per-group breakdown.',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 12.5, color: scheme.onSurfaceVariant),
        ),
      ],
    );
  }
}

/// `₹1.2L` style label for chart axes (compact, no decimals under ₹100).
String _compact(double value) => Fmt.moneyCompact(value).replaceAll('₹', '');

/// A round-ish axis interval that yields 4–6 gridlines for [span].
double _axisStep(double span) {
  if (span <= 0) return 1;
  final rough = span / 5;
  final magnitude = _pow10((rough.abs().toString().length - 1));
  final candidates = [1.0, 2.0, 5.0, 10.0];
  for (final candidate in candidates) {
    if (rough <= candidate * magnitude) return candidate * magnitude;
  }
  return 10 * magnitude;
}

double _pow10(int exponent) {
  var value = 1.0;
  for (var i = 0; i < exponent; i++) {
    value *= 10;
  }
  return value;
}
