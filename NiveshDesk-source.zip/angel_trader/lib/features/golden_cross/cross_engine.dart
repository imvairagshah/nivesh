// ---------------------------------------------------------------------------
// cross_engine.dart — the maths behind Feature 2 (Golden Cross / Death Cross).
//
// A **Golden Cross** is the classic long-term bullish signal: the 50-day simple
// moving average crosses *above* the 200-day SMA. The **Death Cross** is its
// mirror image (50-day crossing *below* the 200-day) and is screened with the
// same code, only the direction changes.
//
// Given daily candles [c1 … cn] this file computes
//
//   SMA(p)[i] = (close[i-p+1] + … + close[i]) / p            (null for i < p-1)
//
// and then looks for a bar `j` where the two averages swapped sides:
//
//   Golden :  SMA(50)[j-1] <= SMA(200)[j-1]  AND  SMA(50)[j] >  SMA(200)[j]
//   Death  :  SMA(50)[j-1] >= SMA(200)[j-1]  AND  SMA(50)[j] <  SMA(200)[j]
//
// Nothing here touches Flutter, the network or the database: it is a pure
// function of (candles, as-of date) and is covered by
// test/features/golden_cross/cross_engine_test.dart.
//
// Two other rules that matter for a *screener* rather than a chart indicator:
//
//   * A 200-day average is only meaningful with 200+ bars of history, so a
//     freshly listed stock simply has no signal (we never extrapolate).
//   * Users want to see signals that fired *recently*, not only on the exact
//     as-of bar, which is what [maxAgeBars] expresses: 0 = "crossed on the
//     selected day", 5 = "crossed within the last 5 sessions".
// ---------------------------------------------------------------------------

import '../../core/utils/markets.dart';
import '../../data/remote/dto/candle.dart';

/// Which way the fast average crossed the slow one.
enum CrossDirection {
  /// 50-SMA climbs above the 200-SMA — bullish.
  golden,

  /// 50-SMA drops below the 200-SMA — bearish.
  death;

  String get label => this == CrossDirection.golden ? 'Golden Cross' : 'Death Cross';

  /// One-word chip text used on the compact list rows.
  String get shortLabel => this == CrossDirection.golden ? 'GOLDEN' : 'DEATH';

  bool get isBullish => this == CrossDirection.golden;

  /// Stable code persisted in SQLite / the scan cache.
  String get code => this == CrossDirection.golden ? 'golden' : 'death';

  /// Tolerant parser for cached rows (`'golden'`, `'GOLDEN'`, …).
  static CrossDirection fromCode(String? raw) =>
      (raw ?? '').trim().toLowerCase().startsWith('d')
          ? CrossDirection.death
          : CrossDirection.golden;
}

// ---------------------------------------------------------------------------
// Moving averages
// ---------------------------------------------------------------------------

/// Simple moving average of [values].
///
/// Index `i` of the result is the average of the `period` values ending at `i`,
/// or `null` while there is not enough history yet — the nulls are what stop a
/// card from showing a fake SMA value for a recently listed stock.
List<double?> simpleMovingAverage(List<double> values, int period) {
  final out = List<double?>.filled(values.length, null, growable: false);
  if (period <= 0 || values.length < period) return out;

  var sum = 0.0;
  for (var i = 0; i < values.length; i++) {
    sum += values[i];
    if (i >= period) sum -= values[i - period];
    if (i >= period - 1) out[i] = sum / period;
  }
  return out;
}

/// Closes of [candles], oldest → newest.
List<double> closesOf(List<Candle> candles) =>
    [for (final c in candles) c.close];

// ---------------------------------------------------------------------------
// The signal
// ---------------------------------------------------------------------------

/// One detected crossover, ready to be rendered on a card or persisted.
class CrossSignal {
  final CrossDirection direction;

  /// Plain ticker the user knows (`SBIN`), without the broker's `-EQ` suffix.
  final String symbol;

  /// Broker symbol used by the data endpoints (`SBIN-EQ`).
  final String brokerSymbol;

  final String companyName;
  final Exchange exchange;

  /// SmartAPI instrument token (kept so the card can re-price without a lookup).
  final String token;

  /// IST date of the bar on which the cross was confirmed.
  final DateTime crossDate;

  /// Completed bars between the cross bar and the as-of bar.
  /// `0` = the cross happened on the as-of bar itself.
  final int ageBars;

  /// Close of the cross bar.
  final double crossClose;

  /// Close of the as-of bar (the latest bar in the series).
  final double lastClose;

  /// SMA values on the cross bar and on the bar before it.
  final double fast;
  final double slow;
  final double prevFast;
  final double prevSlow;

  final int fastPeriod;
  final int slowPeriod;

  /// Number of daily bars the averages were computed from.
  final int barsUsed;

  /// Sparkline material — last [_sparkBars] closes plus the two SMA series over
  /// the same window. Persisted with the signal so a cached card looks exactly
  /// like a freshly scanned one.
  final List<double> spark;
  final List<double?> sparkFast;
  final List<double?> sparkSlow;

  /// Index of the cross bar inside [spark], or -1 when it sits further back.
  final int sparkCrossIndex;

  const CrossSignal({
    required this.direction,
    required this.symbol,
    required this.brokerSymbol,
    required this.companyName,
    required this.exchange,
    required this.token,
    required this.crossDate,
    required this.ageBars,
    required this.crossClose,
    required this.lastClose,
    required this.fast,
    required this.slow,
    required this.prevFast,
    required this.prevSlow,
    required this.barsUsed,
    this.fastPeriod = kFastPeriod,
    this.slowPeriod = kSlowPeriod,
    this.spark = const [],
    this.sparkFast = const [],
    this.sparkSlow = const [],
    this.sparkCrossIndex = -1,
  });

  /// Default screen parameters (the classic 50/200 pair).
  static const int kFastPeriod = 50;
  static const int kSlowPeriod = 200;

  /// How much history the sparkline shows (≈ 3 months of sessions).
  static const int sparkBars = 60;

  /// How far the fast average sits above (golden) / below (death) the slow one,
  /// in percent of the slow average. On a death cross this is negative.
  double get gapPct => slow == 0 ? 0 : (fast - slow) / slow * 100;

  /// `true` when the cross fired on the as-of bar.
  bool get isFresh => ageBars == 0;

  /// Day-over-day change of the latest bar, used for the card's tint.
  double get lastChangePct => crossClose == 0
      ? 0
      : (lastClose - crossClose) / crossClose * 100;

  /// Price-cache key, same contract as the IPO screener: `NSE:SBIN`.
  String get priceKey => '${exchange.code}:$symbol';

  /// `Crossed today` / `Crossed yesterday` / `Crossed 4 sessions ago`.
  String get ageLabel {
    if (ageBars == 0) return 'Crossed on this session';
    if (ageBars == 1) return 'Crossed 1 session earlier';
    return 'Crossed $ageBars sessions earlier';
  }

  // -------------------------------------------------------------------------
  // Persistence (scan_runs.payload rows)
  // -------------------------------------------------------------------------

  Map<String, dynamic> toRow() => {
        'dir': direction.code,
        'symbol': symbol,
        'broker': brokerSymbol,
        'name': companyName,
        'exchange': exchange.code,
        'token': token,
        'cross_date': _isoDate(crossDate),
        'age': ageBars,
        'cross_close': crossClose,
        'last_close': lastClose,
        'fast': fast,
        'slow': slow,
        'prev_fast': prevFast,
        'prev_slow': prevSlow,
        'fast_period': fastPeriod,
        'slow_period': slowPeriod,
        'bars': barsUsed,
        'spark': _round(spark),
        'spark_fast': _roundNullable(sparkFast),
        'spark_slow': _roundNullable(sparkSlow),
        'spark_cross': sparkCrossIndex,
      };

  factory CrossSignal.fromRow(Map<String, dynamic> row) {
    double d(String key, [double fallback = 0]) {
      final v = row[key];
      if (v is num) return v.toDouble();
      return double.tryParse('$v') ?? fallback;
    }

    List<double> series(String key) {
      final raw = row[key];
      if (raw is! List) return const [];
      return [
        for (final v in raw) v is num ? v.toDouble() : double.tryParse('$v') ?? 0,
      ];
    }

    List<double?> nullableSeries(String key) {
      final raw = row[key];
      if (raw is! List) return const [];
      return [
        for (final v in raw) v == null ? null : (v is num ? v.toDouble() : double.tryParse('$v')),
      ];
    }

    return CrossSignal(
      direction: CrossDirection.fromCode('${row['dir']}'),
      symbol: '${row['symbol'] ?? ''}',
      brokerSymbol: '${row['broker'] ?? row['symbol'] ?? ''}',
      companyName: '${row['name'] ?? ''}',
      exchange: Exchange.fromCode('${row['exchange'] ?? 'NSE'}'),
      token: '${row['token'] ?? ''}',
      crossDate: DateTime.tryParse('${row['cross_date']}') ?? DateTime(1970),
      ageBars: (row['age'] as num?)?.toInt() ?? 0,
      crossClose: d('cross_close'),
      lastClose: d('last_close'),
      fast: d('fast'),
      slow: d('slow'),
      prevFast: d('prev_fast'),
      prevSlow: d('prev_slow'),
      fastPeriod: (row['fast_period'] as num?)?.toInt() ?? kFastPeriod,
      slowPeriod: (row['slow_period'] as num?)?.toInt() ?? kSlowPeriod,
      barsUsed: (row['bars'] as num?)?.toInt() ?? 0,
      spark: series('spark'),
      sparkFast: nullableSeries('spark_fast'),
      sparkSlow: nullableSeries('spark_slow'),
      sparkCrossIndex: (row['spark_cross'] as num?)?.toInt() ?? -1,
    );
  }

  @override
  String toString() => 'CrossSignal(${direction.code} ${exchange.code}:$symbol '
      'on ${_isoDate(crossDate)} age=$ageBars fast=${fast.toStringAsFixed(2)} '
      'slow=${slow.toStringAsFixed(2)})';

  static String _isoDate(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-'
      '${d.month.toString().padLeft(2, '0')}-'
      '${d.day.toString().padLeft(2, '0')}';

  static List<double> _round(List<double> values) =>
      [for (final v in values) double.parse(v.toStringAsFixed(3))];

  static List<double?> _roundNullable(List<double?> values) => [
        for (final v in values)
          v == null ? null : double.parse(v.toStringAsFixed(3)),
      ];
}

// ---------------------------------------------------------------------------
// Detection
// ---------------------------------------------------------------------------

/// Bars of [candles] that are **not newer than** [asOf] (IST dates), oldest
/// first. Selecting a date in the past therefore screens exactly the data the
/// market had on that day.
List<Candle> candlesUpTo(List<Candle> candles, DateTime asOf) {
  final limit = DateTime(asOf.year, asOf.month, asOf.day);
  final bars = [
    for (final c in candles)
      if (!c.istDate.isAfter(limit)) c,
  ]..sort((a, b) => a.time.compareTo(b.time));
  return bars;
}

/// Looks for the most recent [direction] cross on or before [asOf].
///
/// [maxAgeBars] is how far back the search may walk: `0` only accepts a cross
/// confirmed by the very last bar, `5` accepts one that happened up to five
/// sessions earlier. The closest cross wins, so a fresh signal always outranks
/// an older one for the same instrument.
///
/// Returns `null` when the instrument has too little history (< `slowPeriod + 1`
/// bars) or when no cross happened inside the window.
CrossSignal? findCross({
  required List<Candle> candles,
  required DateTime asOf,
  required String symbol,
  CrossDirection direction = CrossDirection.golden,
  Exchange exchange = Exchange.nse,
  String brokerSymbol = '',
  String companyName = '',
  String token = '',
  int fastPeriod = CrossSignal.kFastPeriod,
  int slowPeriod = CrossSignal.kSlowPeriod,
  int maxAgeBars = 5,
  int sparkBars = CrossSignal.sparkBars,
}) {
  final bars = candlesUpTo(candles, asOf);
  if (bars.length < slowPeriod + 1) return null;

  final closes = closesOf(bars);
  final fast = simpleMovingAverage(closes, fastPeriod);
  final slow = simpleMovingAverage(closes, slowPeriod);

  final last = bars.length - 1;
  final oldestAllowed = (last - maxAgeBars).clamp(1, last);

  for (var j = last; j >= oldestAllowed; j--) {
    final f = fast[j];
    final s = slow[j];
    final pf = fast[j - 1];
    final ps = slow[j - 1];
    if (f == null || s == null || pf == null || ps == null) continue;

    final isGolden = pf <= ps && f > s;
    final isDeath = pf >= ps && f < s;
    final hit = direction == CrossDirection.golden ? isGolden : isDeath;
    if (!hit) continue;

    final windowStart = (last - sparkBars + 1).clamp(0, last);
    return CrossSignal(
      direction: direction,
      symbol: symbol,
      brokerSymbol: brokerSymbol.isEmpty ? symbol : brokerSymbol,
      companyName: companyName,
      exchange: exchange,
      token: token,
      crossDate: bars[j].istDate,
      ageBars: last - j,
      crossClose: bars[j].close,
      lastClose: bars[last].close,
      fast: f,
      slow: s,
      prevFast: pf,
      prevSlow: ps,
      fastPeriod: fastPeriod,
      slowPeriod: slowPeriod,
      barsUsed: bars.length,
      spark: closes.sublist(windowStart),
      sparkFast: fast.sublist(windowStart),
      sparkSlow: slow.sublist(windowStart),
      sparkCrossIndex: j >= windowStart ? j - windowStart : -1,
    );
  }
  return null;
}

/// Every cross of [direction] present in [candles], oldest first.
///
/// The screener itself only needs the latest one ([findCross]); this is used by
/// the tests to prove the detection rule against hand-built series, and is a
/// natural building block for a future "cross history" chart.
List<CrossSignal> scanSeries({
  required List<Candle> candles,
  required String symbol,
  CrossDirection direction = CrossDirection.golden,
  Exchange exchange = Exchange.nse,
  String brokerSymbol = '',
  String companyName = '',
  String token = '',
  int fastPeriod = CrossSignal.kFastPeriod,
  int slowPeriod = CrossSignal.kSlowPeriod,
  DateTime? ignoreBefore,
}) {
  final bars = candlesUpTo(candles, DateTime(2100));
  if (bars.length < slowPeriod + 1) return const [];

  final closes = closesOf(bars);
  final fast = simpleMovingAverage(closes, fastPeriod);
  final slow = simpleMovingAverage(closes, slowPeriod);
  final floor = ignoreBefore == null
      ? null
      : DateTime(ignoreBefore.year, ignoreBefore.month, ignoreBefore.day);

  final out = <CrossSignal>[];
  for (var j = 1; j < bars.length; j++) {
    final f = fast[j];
    final s = slow[j];
    final pf = fast[j - 1];
    final ps = slow[j - 1];
    if (f == null || s == null || pf == null || ps == null) continue;

    final isGolden = pf <= ps && f > s;
    final isDeath = pf >= ps && f < s;
    if (direction == CrossDirection.golden ? !isGolden : !isDeath) continue;
    if (floor != null && bars[j].istDate.isBefore(floor)) continue;

    out.add(CrossSignal(
      direction: direction,
      symbol: symbol,
      brokerSymbol: brokerSymbol.isEmpty ? symbol : brokerSymbol,
      companyName: companyName,
      exchange: exchange,
      token: token,
      crossDate: bars[j].istDate,
      ageBars: bars.length - 1 - j,
      crossClose: bars[j].close,
      lastClose: bars.last.close,
      fast: f,
      slow: s,
      prevFast: pf,
      prevSlow: ps,
      fastPeriod: fastPeriod,
      slowPeriod: slowPeriod,
      barsUsed: bars.length,
    ));
  }
  return out;
}
