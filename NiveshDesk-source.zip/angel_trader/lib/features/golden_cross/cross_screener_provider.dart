// ---------------------------------------------------------------------------
// cross_screener_provider.dart — state for the Golden Cross / Death Cross tab.
//
// Owns everything the screen needs and nothing it doesn't:
//   * the cached scan of the day (so the tab opens instantly, offline),
//   * the resolved universe (Nifty 50 / IPO DB / all instruments),
//   * the live scan with progress, cancellation and error handling,
//   * filters (golden / death / fresh + text search),
//   * the automatic after-6-PM-IST run and the optional webhook ping.
//
// The provider never touches the network itself — CrossScanService does that —
// so the whole tab is testable with fakes.
// ---------------------------------------------------------------------------

import 'package:flutter/foundation.dart';

import '../../core/utils/markets.dart';
import '../../data/local/dao/ipo_dao.dart';
import '../../data/local/dao/scrip_dao.dart';
import '../../data/remote/api_client.dart';
import '../../services/auth_service.dart';
import '../../services/cross_scan_service.dart';
import '../../services/scan_notifier.dart';
import '../../services/scrip_master_service.dart';
import '../settings/settings_provider.dart';
import 'cross_engine.dart';
import '../../services/universe_catalog.dart';

/// Quick filters above the result list.
enum CrossFilter {
  all('All'),
  golden('Golden'),
  death('Death'),
  fresh('This session');

  const CrossFilter(this.label);
  final String label;
}

/// How far back a cross may sit and still count as a hit.
class CrossAgeWindow {
  final int bars;
  final String label;

  const CrossAgeWindow(this.bars, this.label);

  /// The window a scan uses when the user has not chosen one: a week of
  /// sessions catches a signal that fired while they were away without
  /// flooding the list with month-old crosses.
  static const CrossAgeWindow defaultWindow = CrossAgeWindow(5, 'Last 5 sessions');

  static const List<CrossAgeWindow> choices = [
    CrossAgeWindow(0, 'On the day'),
    CrossAgeWindow(5, 'Last 5 sessions'),
    CrossAgeWindow(10, 'Last 10 sessions'),
    CrossAgeWindow(20, 'Last 20 sessions'),
  ];
}

class CrossScreenerProvider extends ChangeNotifier {
  CrossScreenerProvider({
    required CrossScanService scan,
    required ScripDao scripDao,
    required IpoDao ipoDao,
    required SettingsProvider settings,
    required AuthService auth,
    required ScripMasterService scripMaster,
    ScanNotifier? notifier,
    DateTime Function()? clock,
  })  : _scan = scan,
        _scripDao = scripDao,
        _ipoDao = ipoDao,
        _settings = settings,
        _auth = auth,
        _scripMaster = scripMaster,
        _notifier = notifier ?? ScanNotifier(),
        _clock = clock ?? DateTime.now;

  final CrossScanService _scan;
  final ScripDao _scripDao;
  final IpoDao _ipoDao;
  final SettingsProvider _settings;
  final AuthService _auth;
  final ScripMasterService _scripMaster;
  final ScanNotifier _notifier;
  final DateTime Function() _clock;

  // -------------------------------------------------------------------------
  // State
  // -------------------------------------------------------------------------

  CrossScanResult? _result;
  bool _loadingCache = true;
  bool _scanning = false;
  bool _cancelled = false;
  bool _resolvingUniverse = false;
  bool _autoJobAttempted = false;
  CrossScanProgress? _progress;
  String? _error;
  String? _lastNotifyMessage;
  UniverseResolution _universe = UniverseResolution.empty;
  CrossFilter _filter = CrossFilter.all;
  String _query = '';
  CrossAgeWindow _window = CrossAgeWindow.defaultWindow;
  DateTime _viewDate = MarketCalendar.latestTradingDay();

  // -------------------------------------------------------------------------
  // Getters
  // -------------------------------------------------------------------------

  CrossScanResult? get result => _result;
  bool get isLoadingCache => _loadingCache;
  bool get isScanning => _scanning;
  bool get isCancelled => _cancelled;
  bool get isResolvingUniverse => _resolvingUniverse;
  CrossScanProgress? get progress => _progress;
  String? get error => _error;
  String? get lastNotifyMessage => _lastNotifyMessage;
  UniverseResolution get universe => _universe;
  CrossFilter get filter => _filter;
  String get query => _query;
  CrossAgeWindow get window => _window;

  /// Date the current view is about (the last scan's date, or today's session).
  DateTime get viewDate => _result?.asOf ?? _viewDate;

  /// Session the next scan would cover.
  DateTime get latestSession => MarketCalendar.latestTradingDay();

  bool get includeDeath => _settings.settings.deathCrossEnabled;
  String get universeKey => _settings.settings.goldenCrossUniverse;
  String get universeLabel => _universe.label;

  /// `true` when the optional webhook is configured (Settings → Golden Cross).
  bool get webhookConfigured =>
      _settings.settings.notifyWebhookUrl.trim().isNotEmpty;

  bool get hasResult => _result != null;
  bool get isStale => _result != null && _result!.isStaleFor(latestSession);
  bool get isViewingCached => _result?.fromCacheOnly ?? false;
  bool get canScan => !_scanning && !_universe.isEmpty;

  /// Golden / death / fresh counts of the *current* result (unfiltered).
  int get goldenCount => _result?.goldenCount ?? 0;
  int get deathCount => _result?.deathCount ?? 0;
  int get freshCount => _result?.freshCount ?? 0;

  /// Signals after the active filter + search, already sorted freshest-first.
  List<CrossSignal> get visibleSignals {
    final all = _result?.signals ?? const <CrossSignal>[];
    final q = _query.trim().toUpperCase();

    return [
      for (final s in all)
        if (_matchesFilter(s) &&
            (q.isEmpty ||
                s.symbol.contains(q) ||
                s.companyName.toUpperCase().contains(q)))
          s,
    ];
  }

  bool _matchesFilter(CrossSignal s) => switch (_filter) {
        CrossFilter.all => true,
        CrossFilter.golden => s.direction == CrossDirection.golden,
        CrossFilter.death => s.direction == CrossDirection.death,
        CrossFilter.fresh => s.isFresh,
      };

  /// `50 instruments · ~20 s` — shown under the scan button.
  ///
  /// One uncached instrument costs a single rate-limited `getCandleData` call
  /// (~0.4 s at 3 req/s); a re-scan of the same day is served from the candle
  /// cache and takes a couple of seconds in total.
  String get scanEstimate {
    final size = _universe.size;
    if (size == 0) return 'No instruments resolved yet.';
    final seconds = (size * 0.4).round().clamp(2, 1800);
    return '$size instruments · ~${seconds}s when nothing is cached';
  }

  bool get needsConfirmation =>
      _universe.size >= CrossScanService.confirmAbove && _result == null;

  // -------------------------------------------------------------------------
  // Lifecycle
  // -------------------------------------------------------------------------

  /// Loads the cached scan and resolves the universe. Safe to call twice.
  Future<void> bootstrap() async {
    _loadingCache = true;
    notifyListeners();

    try {
      final cached = await _scan.loadCached();
      if (cached != null) _result = cached;
    } catch (e) {
      _error = 'Could not read the cached scan: $e';
    } finally {
      _loadingCache = false;
      notifyListeners();
    }

    await resolveUniverse();
  }

  /// Resolves the configured universe against local data.
  Future<void> resolveUniverse({String? key}) async {
    final wanted = key ?? universeKey;
    _resolvingUniverse = true;
    notifyListeners();

    try {
      // The resolver gives the IPO universe its company-name fallback; building
      // it lazily means the other universes never pay for it.
      final resolver = wanted == UniverseCatalog.ipos
          ? await _scripMaster.resolver()
          : null;

      _universe = await UniverseCatalog.resolve(
        wanted,
        scripDao: _scripDao,
        ipoDao: _ipoDao,
        resolver: resolver,
      );
    } catch (e) {
      _error = 'Could not resolve that universe: $e';
    } finally {
      _resolvingUniverse = false;
      notifyListeners();
    }
  }

  // -------------------------------------------------------------------------
  // Scanning
  // -------------------------------------------------------------------------

  /// Runs a scan for [asOf] (default: the selected view date).
  ///
  /// [notify] pings the configured webhook when hits are found; [silent] skips
  /// the error snackbar path used by the automatic after-6-PM run.
  Future<void> run({
    DateTime? asOf,
    bool notify = false,
    bool silent = false,
  }) async {
    if (_scanning) return;

    final day = asOf ?? _viewDate;
    _error = null;
    _lastNotifyMessage = null;
    _scanning = true;
    _cancelled = false;
    _progress = null;
    notifyListeners();

    try {
      if (_universe.isEmpty) await resolveUniverse();
      if (_universe.isEmpty) {
        throw StateError(
          'No instruments resolved for "${UniverseCatalog.byKey(universeKey).label}". '
          'Try another universe from the picker.',
        );
      }

      final result = await _scan.scan(
        universe: _universe.scrips,
        asOf: day,
        includeDeath: includeDeath,
        maxAgeBars: _window.bars,
        universeKey: universeKey,
        onProgress: (p) {
          _progress = p;
          notifyListeners();
        },
        isCancelled: () => _cancelled,
      );

      _result = result;
      _viewDate = result.asOf;

      if (notify && result.hitCount > 0) {
        final report = await _notifier.send(
          webhookUrl: _settings.settings.notifyWebhookUrl,
          result: result,
          universeLabel: _universe.label,
        );
        if (report.outcome != NotifyOutcome.skipped) {
          _lastNotifyMessage = report.detail;
        }
      }
    } on ApiException catch (e) {
      _error = e.isAuthError
          ? '${e.message} Log in again from Settings to scan live data.'
          : e.message;
    } catch (e) {
      if (!silent) _error = '$e';
    } finally {
      _scanning = false;
      _progress = null;
      notifyListeners();
    }
  }

  /// Asks the running scan to stop after the current instrument.
  void cancel() {
    if (!_scanning) return;
    _cancelled = true;
    notifyListeners();
  }

  /// Drops the cached scan output (the candles are kept, so the next scan is
  /// still fast — this only clears the rendered results).
  Future<void> clearScanCache() async {
    _result = null;
    notifyListeners();
    await _scan.clearCache();
  }

  /// Cheap size hints for the universe picker — plain row counts, no resolution,
  /// so opening the sheet never costs a network call.
  Future<Map<String, int>> universeSizeHints() async {
    try {
      final results = await Future.wait([
        _ipoDao.count(),
        _scripDao.count(exchange: 'NSE'),
        _scripDao.count(),
      ]);
      return {
        UniverseCatalog.nifty50: UniverseCatalog.nifty50Symbols.length,
        UniverseCatalog.ipos: results[0],
        UniverseCatalog.masterNse: results[1],
        UniverseCatalog.masterAll: results[2],
      };
    } catch (_) {
      return const {};
    }
  }

  /// Runs the daily job when its window has arrived (after 18:00 IST on a
  /// trading day) and today's scan is not already cached.
  ///
  /// Returns the result when a scan actually ran. Called from the tab's
  /// initState / app resume; it is idempotent per app launch.
  Future<CrossScanResult?> maybeRunDailyJob() async {
    if (_autoJobAttempted || _scanning || !_auth.isLoggedIn) return null;

    // The clock is injectable so the daily-job window can be tested without
    // waiting for 6 PM IST.
    final istNow = _clock().toUtc().add(const Duration(hours: 5, minutes: 30));
    final today = MarketCalendar.latestTradingDay(from: istNow);
    if (!MarketCalendar.isDailyJobWindow(at: istNow)) return null;

    final cachedIsCurrent = _result != null &&
        !_result!.fromCacheOnly &&
        !_result!.isStaleFor(today);
    if (cachedIsCurrent) {
      _autoJobAttempted = true;
      return null;
    }

    _autoJobAttempted = true;
    await run(asOf: today, notify: true, silent: true);
    return _result;
  }

  // -------------------------------------------------------------------------
  // View controls
  // -------------------------------------------------------------------------

  void setFilter(CrossFilter filter) {
    if (_filter == filter) return;
    _filter = filter;
    notifyListeners();
  }

  void setQuery(String query) {
    _query = query;
    notifyListeners();
  }

  void setWindow(CrossAgeWindow window) {
    if (_window.bars == window.bars) return;
    _window = window;
    notifyListeners();
  }

  /// Switches the universe in settings and resolves it immediately.
  Future<void> setUniverse(String key) async {
    if (key == universeKey && !_universe.isEmpty) return;
    await _settings.setGoldenCrossUniverse(key);
    await resolveUniverse(key: key);
  }

  /// Picks the date being screened.
  ///
  /// If a scan for that trading day is already cached it is shown right away
  /// (no network); otherwise the view date moves and the next scan targets it.
  Future<void> setViewDate(DateTime date) async {
    final session = MarketCalendar.latestTradingDay(from: date);
    _viewDate = session;
    notifyListeners();

    final cached = await _scan.loadCached(asOf: session);
    if (cached != null && cached.signals.isNotEmpty) {
      _result = cached;
      notifyListeners();
    }
  }

  void clearFilters() {
    _filter = CrossFilter.all;
    _query = '';
    notifyListeners();
  }

  void clearError() {
    if (_error == null) return;
    _error = null;
    notifyListeners();
  }

  /// Reacts to a settings change made elsewhere (death-cross switch, universe).
  Future<void> onSettingsChanged() async {
    notifyListeners();
    if (UniverseCatalog.byKey(universeKey).key != _universe.universe.key) {
      await resolveUniverse();
    }
  }

  @override
  void dispose() {
    _notifier.dispose();
    super.dispose();
  }
}
