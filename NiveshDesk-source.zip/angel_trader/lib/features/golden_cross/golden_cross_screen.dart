// ---------------------------------------------------------------------------
// golden_cross_screen.dart — Feature 2 tab: 50/200 SMA crossover screener.
//
// Everything the spec asked for, on one screen:
//   • scans daily candles for a 50-SMA crossing the 200-SMA,
//   • Golden Cross by default, Death Cross behind the toggle chip,
//   • a selectable as-of date (defaults to the latest trading session),
//   • cached results per trading day, so the tab opens instantly and offline,
//   • the daily run after 6 PM IST (started automatically when the tab is
//     opened inside that window — there is no server in this app),
//   • cards with symbol, cross date, both SMAs, price and a TradingView link.
//
// The screen is intentionally thin: all state lives in [CrossScreenerProvider].
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../core/widgets/motion.dart';
import '../../core/utils/link_opener.dart';
import '../../core/utils/markets.dart';
import '../../services/auth_service.dart';
import '../../services/cross_scan_service.dart';
import '../settings/settings_provider.dart';
import 'cross_engine.dart';
import 'cross_screener_provider.dart';
import 'widgets/cross_signal_card.dart';
import 'widgets/universe_sheet.dart';

/// Shared snack helper: the header card is a separate widget, so it cannot use
/// the screen state's private method.
void _snack(BuildContext context, String message) {
  ScaffoldMessenger.maybeOf(context)?.showSnackBar(
    SnackBar(content: Text(message), duration: const Duration(seconds: 4)),
  );
}

class GoldenCrossScreen extends StatefulWidget {
  const GoldenCrossScreen({super.key, this.active = true});

  /// `true` while this tab is the visible one.
  ///
  /// The daily scan is started on the first activation inside the 6 PM window
  /// instead of at app launch, so the tab never spends the user's API quota
  /// while it sits unopened in the background stack.
  final bool active;

  @override
  State<GoldenCrossScreen> createState() => _GoldenCrossScreenState();
}

class _GoldenCrossScreenState extends State<GoldenCrossScreen>
    with WidgetsBindingObserver {
  final TextEditingController _search = TextEditingController();
  bool _searchOpen = false;
  bool _bootstrapped = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    if (widget.active) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _activate());
    }
  }

  @override
  void didUpdateWidget(covariant GoldenCrossScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.active && !oldWidget.active) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _activate());
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Coming back to the app after 6 PM is the second chance to run the job.
    if (state == AppLifecycleState.resumed && widget.active) {
      _activate();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _search.dispose();
    super.dispose();
  }

  /// Bootstrap once, then try the daily job. Failures never reach the user as
  /// exceptions — the provider turns them into an inline banner.
  Future<void> _activate() async {
    if (!mounted) return;
    final provider = context.read<CrossScreenerProvider>();

    if (!_bootstrapped) {
      _bootstrapped = true;
      await provider.bootstrap();
    }
    if (!mounted) return;

    final result = await provider.maybeRunDailyJob();
    if (!mounted || result == null) return;

    if (result.hitCount > 0) {
      _snack(
        'Daily scan done: ${result.goldenCount} golden, '
        '${result.deathCount} death cross.',
      );
    }
    if (provider.lastNotifyMessage != null) {
      _snack('Webhook: ${provider.lastNotifyMessage}');
    }
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.maybeOf(context)?.showSnackBar(
      SnackBar(content: Text(message), duration: const Duration(seconds: 4)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<CrossScreenerProvider>();

    return RefreshIndicator(
      onRefresh: () => provider.run(notify: provider.webhookConfigured),
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 32),
        children: [
          _StatusCard(provider: provider),
          const SizedBox(height: 10),
          _FilterBar(
            provider: provider,
            searchController: _search,
            searchOpen: _searchOpen,
            onToggleSearch: () => setState(() => _searchOpen = !_searchOpen),
          ),
          const SizedBox(height: 6),
          ..._buildResults(context, provider),
        ],
      ),
    );
  }

  List<Widget> _buildResults(
    BuildContext context,
    CrossScreenerProvider provider,
  ) {
    // First open of a session: skeletons rather than a bare spinner, so the
    // layout the data will land in is already visible.
    if (provider.isLoadingCache && !provider.hasResult) {
      return const [
        ShimmerCard(),
        SizedBox(height: 10),
        ShimmerCard(),
        SizedBox(height: 10),
        ShimmerCard(),
      ];
    }

    final result = provider.result;
    final signals = provider.visibleSignals;

    return [
      if (result != null && result.skips.isNotEmpty && !result.fromCacheOnly)
        _SkippedTile(result: result),
      if (signals.isEmpty)
        _EmptyState(provider: provider)
      else
        for (var i = 0; i < signals.length; i++)
          FadeSlideIn(
            index: i,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 2),
              child: CrossSignalCard(
                signal: signals[i],
                onTap: () => _showDetail(context, signals[i]),
              ),
            ),
          ),
    ];
  }

  void _showDetail(BuildContext context, CrossSignal signal) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) {
        final theme = Theme.of(sheetContext);
        final market = MarketColors.of(sheetContext);
        final accent =
            signal.direction.isBullish ? market.gain : market.loss;

        Widget row(String label, String value) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 5),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      label,
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ),
                  Text(
                    value,
                    style: theme.textTheme.bodyMedium
                        ?.copyWith(fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            );

        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        '${signal.symbol} · ${signal.exchange.code}',
                        style: theme.textTheme.titleLarge
                            ?.copyWith(fontWeight: FontWeight.w700),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: accent.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        signal.direction.label,
                        style: TextStyle(
                          color: accent,
                          fontWeight: FontWeight.w700,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ],
                ),
                if (signal.companyName.isNotEmpty) ...[
                  const SizedBox(height: 2),
                  Text(
                    signal.companyName,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
                const SizedBox(height: 14),
                row('Cross date', Fmt.date(signal.crossDate)),
                row('Sessions since cross', '${signal.ageBars}'),
                row('Close on cross day', Fmt.money(signal.crossClose)),
                row('Latest close', Fmt.money(signal.lastClose)),
                const Divider(height: 20),
                row(
                  'SMA ${signal.fastPeriod} now',
                  Fmt.price(signal.fast),
                ),
                row(
                  'SMA ${signal.slowPeriod} now',
                  Fmt.price(signal.slow),
                ),
                row(
                  'SMA ${signal.fastPeriod} before',
                  Fmt.price(signal.prevFast),
                ),
                row(
                  'SMA ${signal.slowPeriod} before',
                  Fmt.price(signal.prevSlow),
                ),
                row('Fast vs slow', Fmt.signedPct(signal.gapPct)),
                row('Bars used', '${signal.barsUsed}'),
                if (signal.token.isNotEmpty) row('SmartAPI token', signal.token),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.tonalIcon(
                    onPressed: () {
                      Navigator.of(sheetContext).pop();
                      _openChart(context, signal);
                    },
                    icon: const Icon(Icons.show_chart_rounded),
                    label: const Text('Open TradingView chart'),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'A 50/200 crossover is a lagging, long-horizon signal. '
                  'It is screened here for study and paper trading only.',
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  /// One place builds TradingView URLs for the whole tab ([LinkOpener], shared
  /// with the IPO screener), so the card and the detail sheet cannot drift.
  void _openChart(BuildContext context, CrossSignal signal) {
    LinkOpener.open(
      LinkOpener.tradingViewUrl(signal.exchange.code, signal.symbol),
      context: context,
    );
  }
}

// ---------------------------------------------------------------------------
// Header / status card
// ---------------------------------------------------------------------------

class _StatusCard extends StatelessWidget {
  const _StatusCard({required this.provider});

  final CrossScreenerProvider provider;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final market = MarketColors.of(context);
    final result = provider.result;
    final auth = context.watch<AuthService>();

    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: scheme.primaryContainer,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    Icons.timeline_rounded,
                    size: 22,
                    color: scheme.onPrimaryContainer,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Golden / Death Cross',
                        style: theme.textTheme.titleMedium
                            ?.copyWith(fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        _subtitle(result),
                        style: theme.textTheme.bodySmall
                            ?.copyWith(color: scheme.onSurfaceVariant),
                        maxLines: 2,
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),

            // ---- Parameters -------------------------------------------
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                ActionChip(
                  avatar: const Icon(Icons.event_rounded, size: 16),
                  label: Text(Fmt.date(provider.viewDate)),
                  onPressed: () => _pickDate(context, provider),
                ),
                ActionChip(
                  avatar: const Icon(Icons.travel_explore_rounded, size: 16),
                  label: Text(provider.universe.universe.label),
                  onPressed: () => showUniverseSheet(context),
                ),
                ActionChip(
                  avatar: const Icon(Icons.history_rounded, size: 16),
                  label: Text(provider.window.label),
                  onPressed: () => _pickWindow(context, provider),
                ),
                FilterChip(
                  selected: provider.includeDeath,
                  avatar: Icon(
                    Icons.trending_down_rounded,
                    size: 16,
                    color: provider.includeDeath
                        ? market.loss
                        : scheme.onSurfaceVariant,
                  ),
                  label: const Text('Death cross'),
                  onSelected: (value) async {
                    await context
                        .read<SettingsProvider>()
                        .setDeathCrossEnabled(value);
                    await provider.onSettingsChanged();
                  },
                ),
              ],
            ),

            const SizedBox(height: 14),

            // ---- Counts ------------------------------------------------
            Row(
              children: [
                Expanded(
                  child: _Stat(
                    label: 'Golden',
                    value: provider.goldenCount,
                    color: market.gain,
                    selected: provider.filter == CrossFilter.golden,
                    onTap: () => provider.setFilter(
                      provider.filter == CrossFilter.golden
                          ? CrossFilter.all
                          : CrossFilter.golden,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _Stat(
                    label: 'Death',
                    value: provider.deathCount,
                    color: market.loss,
                    selected: provider.filter == CrossFilter.death,
                    onTap: () => provider.setFilter(
                      provider.filter == CrossFilter.death
                          ? CrossFilter.all
                          : CrossFilter.death,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _Stat(
                    label: 'This session',
                    value: provider.freshCount,
                    color: scheme.primary,
                    selected: provider.filter == CrossFilter.fresh,
                    onTap: () => provider.setFilter(
                      provider.filter == CrossFilter.fresh
                          ? CrossFilter.all
                          : CrossFilter.fresh,
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 14),

            // ---- Run / progress ----------------------------------------
            if (provider.isScanning)
              _ScanProgress(provider: provider)
            else
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: provider.canScan
                          ? () => _startScan(context, provider)
                          : null,
                      icon: const Icon(Icons.radar_rounded),
                      label: Text(
                        provider.isStale ? 'Scan for today' : 'Run scan',
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filledTonal(
                    tooltip: 'Clear the cached scan',
                    onPressed: provider.hasResult
                        ? () async {
                            await provider.clearScanCache();
                            if (!context.mounted) return;
                            _snack(
                              context,
                              'Cached scan cleared — the candles are kept.',
                            );
                          }
                        : null,
                    icon: const Icon(Icons.delete_outline_rounded),
                  ),
                ],
              ),

            if (!provider.isScanning) ...[
              const SizedBox(height: 6),
              Text(
                provider.scanEstimate,
                style: theme.textTheme.labelSmall
                    ?.copyWith(color: scheme.onSurfaceVariant),
              ),
            ],

            // ---- Banners ------------------------------------------------
            if (!auth.isLoggedIn && !provider.isViewingCached)
              _Banner(
                icon: Icons.cloud_off_rounded,
                color: market.stale,
                text:
                    'Not logged in — showing the cached scan. Log in from the '
                    'gear icon to fetch fresh candles.',
              ),
            if (provider.isStale && !provider.isScanning)
              _Banner(
                icon: Icons.update_rounded,
                color: scheme.primary,
                text:
                    'Results are for ${Fmt.date(provider.viewDate)}. Today\'s '
                    'session (${Fmt.date(provider.latestSession)}) has not been '
                    'scanned yet.',
              ),
            if (provider.needsConfirmation && !provider.isScanning)
              _Banner(
                icon: Icons.speed_rounded,
                color: market.stale,
                text:
                    'This universe has ${provider.universe.size} instruments — '
                    'a first scan can take several minutes at Angel One\'s '
                    '3 requests/second limit.',
              ),
            if (provider.error != null)
              _Banner(
                icon: Icons.error_outline_rounded,
                color: scheme.error,
                text: provider.error!,
                onDismiss: provider.clearError,
              ),
          ],
        ),
      ),
    );
  }

  String _subtitle(CrossScanResult? result) {
    if (result == null) {
      return 'No scan cached yet — run one to fill this tab.';
    }
    final when = Fmt.relative(result.runAt);
    final source = result.fromCacheOnly
        ? 'cached'
        : '${result.scanned} scanned, ${result.fromCache} from cache, '
            '${result.fetched} downloaded';
    return '${Fmt.date(result.asOf)} · $source · $when';
  }

  Future<void> _pickDate(
    BuildContext context,
    CrossScreenerProvider provider,
  ) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: provider.viewDate.isAfter(MarketCalendar.nowIst())
          ? MarketCalendar.nowIst()
          : provider.viewDate,
      firstDate: DateTime(2015, 1, 1),
      lastDate: MarketCalendar.nowIst(),
      helpText: 'Screen a session',
      fieldLabelText: 'Session date',
    );
    if (picked == null) return;
    await provider.setViewDate(picked);
  }

  Future<void> _pickWindow(
    BuildContext context,
    CrossScreenerProvider provider,
  ) async {
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
              child: Text(
                'How recent must the cross be?',
                style: Theme.of(sheetContext).textTheme.titleMedium,
              ),
            ),
            for (final choice in CrossAgeWindow.choices)
              ListTile(
                title: Text(choice.label),
                subtitle: Text(
                  choice.bars == 0
                      ? 'Only crosses confirmed by the selected session.'
                      : 'Crosses from the last ${choice.bars} sessions.',
                ),
                trailing: provider.window.bars == choice.bars
                    ? const Icon(Icons.check_rounded)
                    : null,
                onTap: () {
                  provider.setWindow(choice);
                  Navigator.of(sheetContext).pop();
                },
              ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  Future<void> _startScan(
    BuildContext context,
    CrossScreenerProvider provider,
  ) async {
    if (provider.needsConfirmation) {
      final go = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Start a long scan?'),
          content: Text(
            '${provider.universe.size} instruments have to be fetched once '
            '(about ${(provider.universe.size * 0.4).round()} seconds at Angel '
            'One\'s rate limit). Later scans of the same session come from the '
            'local candle cache and take a few seconds.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Start'),
            ),
          ],
        ),
      );
      if (go != true) return;
    }

    await provider.run(asOf: provider.viewDate);
    if (!context.mounted) return;

    final result = provider.result;
    if (provider.error != null) return;
    if (result != null && result.cancelled) {
      _snack(context, 'Scan stopped after ${result.scanned} instruments.');
    } else if (result != null) {
      _snack(
        context,
        'Scan complete: ${result.goldenCount} golden, ${result.deathCount} '
        'death cross · ${result.signals.length} cards.',
      );
      if (provider.lastNotifyMessage != null) {
        _snack(context, 'Webhook: ${provider.lastNotifyMessage}');
      }
    }
  }
}

// ---------------------------------------------------------------------------
// Pieces of the header
// ---------------------------------------------------------------------------

class _Stat extends StatelessWidget {
  const _Stat({
    required this.label,
    required this.value,
    required this.color,
    required this.onTap,
    this.selected = false,
  });

  final String label;
  final int value;
  final Color color;
  final VoidCallback onTap;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
        decoration: BoxDecoration(
          color: color.withValues(alpha: selected ? 0.18 : 0.07),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: color.withValues(alpha: selected ? 0.6 : 0.18),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '$value',
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w700,
                color: color,
              ),
            ),
            Text(
              label,
              style: theme.textTheme.labelSmall?.copyWith(
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ScanProgress extends StatelessWidget {
  const _ScanProgress({required this.provider});

  final CrossScreenerProvider provider;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final progress = provider.progress;
    final eta = progress?.eta ?? Duration.zero;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                progress == null
                    ? 'Starting scan…'
                    : '${progress.done}/${progress.total} · ${progress.current} · '
                        '${progress.hits} hits',
                style: theme.textTheme.bodySmall
                    ?.copyWith(fontWeight: FontWeight.w600),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            if (eta > Duration.zero)
              Text(
                '~${eta.inSeconds}s left',
                style: theme.textTheme.labelSmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            TextButton(
              onPressed: provider.cancel,
              child: const Text('Stop'),
            ),
          ],
        ),
        const SizedBox(height: 4),
        ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: LinearProgressIndicator(
            value: progress?.fraction,
            minHeight: 6,
          ),
        ),
        const SizedBox(height: 6),
        if (progress != null)
          Text(
            '${progress.fromCache} from cache · ${progress.fetched} downloaded · '
            '${progress.failures} skipped',
            style: theme.textTheme.labelSmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
      ],
    );
  }
}

class _Banner extends StatelessWidget {
  const _Banner({
    required this.icon,
    required this.color,
    required this.text,
    this.onDismiss,
  });

  final IconData icon;
  final Color color;
  final String text;
  final VoidCallback? onDismiss;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Container(
        padding: const EdgeInsets.fromLTRB(10, 8, 6, 8),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.09),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withValues(alpha: 0.35)),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 17, color: color),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                text,
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ),
            if (onDismiss != null)
              IconButton(
                visualDensity: VisualDensity.compact,
                tooltip: 'Dismiss',
                icon: const Icon(Icons.close_rounded, size: 16),
                onPressed: onDismiss,
              ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Filters + results
// ---------------------------------------------------------------------------

class _FilterBar extends StatelessWidget {
  const _FilterBar({
    required this.provider,
    required this.searchController,
    required this.searchOpen,
    required this.onToggleSearch,
  });

  final CrossScreenerProvider provider;
  final TextEditingController searchController;
  final bool searchOpen;
  final VoidCallback onToggleSearch;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    for (final filter in CrossFilter.values)
                      Padding(
                        padding: const EdgeInsets.only(right: 6),
                        child: FilterChip(
                          label: Text(filter.label),
                          selected: provider.filter == filter,
                          onSelected: (_) => provider.setFilter(filter),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            IconButton(
              tooltip: searchOpen ? 'Hide search' : 'Search',
              icon: Icon(searchOpen ? Icons.close_rounded : Icons.search_rounded),
              onPressed: onToggleSearch,
            ),
          ],
        ),
        if (searchOpen)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: TextField(
              controller: searchController,
              autofocus: true,
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                isDense: true,
                hintText: 'Filter by symbol or company',
                prefixIcon: const Icon(Icons.search_rounded, size: 18),
                suffixIcon: provider.query.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.clear_rounded, size: 18),
                        onPressed: () {
                          searchController.clear();
                          provider.setQuery('');
                        },
                      ),
              ),
              onChanged: provider.setQuery,
            ),
          ),
      ],
    );
  }
}

class _SkippedTile extends StatelessWidget {
  const _SkippedTile({required this.result});

  final CrossScanResult result;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      elevation: 0,
      color: scheme.surfaceContainerHighest.withValues(alpha: 0.4),
      child: ListTile(
        dense: true,
        leading: const Icon(Icons.info_outline_rounded, size: 20),
        title: Text('${result.skips.length} instruments skipped'),
        subtitle: const Text('Not enough history, or the fetch failed.'),
        trailing: const Icon(Icons.chevron_right_rounded),
        onTap: () => showModalBottomSheet<void>(
          context: context,
          showDragHandle: true,
          isScrollControlled: true,
          builder: (sheetContext) => SafeArea(
            child: SizedBox(
              height: MediaQuery.of(sheetContext).size.height * 0.6,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
                    child: Text(
                      'Skipped instruments',
                      style: Theme.of(sheetContext).textTheme.titleMedium,
                    ),
                  ),
                  Expanded(
                    child: ListView.builder(
                      itemCount: result.skips.length,
                      itemBuilder: (_, i) {
                        final skip = result.skips[i];
                        return ListTile(
                          dense: true,
                          title: Text(skip.symbol),
                          subtitle: Text(skip.reason),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.provider});

  final CrossScreenerProvider provider;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    final hasResult = provider.hasResult;
    final filtered =
        hasResult && (provider.filter != CrossFilter.all || provider.query.isNotEmpty);

    final title = filtered
        ? 'Nothing matches this filter'
        : hasResult
            ? 'No cross found'
            : 'No scan yet';
    final body = filtered
        ? 'Try clearing the filter or the search text.'
        : hasResult
            ? 'No ${provider.includeDeath ? 'golden or death' : 'golden'} cross '
                'within ${provider.window.label.toLowerCase()} in '
                '${provider.universe.universe.label}. Try a wider window.'
            : 'Run a scan to look for 50/200 SMA crossovers in '
                '${provider.universe.universe.label}.';

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 40, 16, 16),
      child: Column(
        children: [
          Icon(Icons.show_chart_rounded, size: 40, color: scheme.outline),
          const SizedBox(height: 12),
          Text(title, style: theme.textTheme.titleMedium),
          const SizedBox(height: 6),
          Text(
            body,
            textAlign: TextAlign.center,
            style: theme.textTheme.bodySmall
                ?.copyWith(color: scheme.onSurfaceVariant),
          ),
          if (filtered) ...[
            const SizedBox(height: 14),
            OutlinedButton(
              onPressed: provider.clearFilters,
              child: const Text('Clear filters'),
            ),
          ],
        ],
      ),
    );
  }
}
