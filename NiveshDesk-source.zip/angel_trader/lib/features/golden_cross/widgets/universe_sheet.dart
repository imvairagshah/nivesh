// ---------------------------------------------------------------------------
// universe_sheet.dart — "what should the scanner look at?"
//
// Four options, cheapest first, each showing how many instruments it will
// resolve and how long a first scan therefore takes. The counts come from plain
// row counts in SQLite (no resolution, no network), so the sheet opens instantly
// and the numbers stay honest even before the full scrip master is downloaded.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../services/cross_scan_service.dart' show ScanUniverse;
import '../cross_screener_provider.dart';
import '../../../services/universe_catalog.dart';

Future<void> showUniverseSheet(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (_) => const _UniverseSheet(),
  );
}

class _UniverseSheet extends StatelessWidget {
  const _UniverseSheet();

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<CrossScreenerProvider>();
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Scan universe',
              style: theme.textTheme.titleLarge
                  ?.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 4),
            Text(
              'Resolved from the instrument list already on this phone — '
              'switching costs nothing and works offline.',
              style: theme.textTheme.bodySmall
                  ?.copyWith(color: scheme.onSurfaceVariant),
            ),
            const SizedBox(height: 14),
            FutureBuilder<Map<String, int>>(
              future: provider.universeSizeHints(),
              builder: (context, snapshot) {
                final counts = snapshot.data ?? const <String, int>{};
                return Column(
                  children: [
                    for (final ScanUniverse universe in UniverseCatalog.all)
                      _UniverseTile(
                        universe: universe,
                        count: counts[universe.key],
                        selected:
                            universe.key == provider.universe.universe.key,
                        onTap: () async {
                          Navigator.of(context).pop();
                          await provider.setUniverse(universe.key);
                        },
                      ),
                  ],
                );
              },
            ),
            const SizedBox(height: 8),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.speed_rounded, size: 16, color: scheme.onSurfaceVariant),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Angel One allows 3 candle requests per second. Whatever gets '
                    'fetched is cached per session, so a second scan of the same '
                    'day takes a few seconds.',
                    style: theme.textTheme.labelSmall
                        ?.copyWith(color: scheme.onSurfaceVariant),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _UniverseTile extends StatelessWidget {
  const _UniverseTile({
    required this.universe,
    required this.count,
    required this.selected,
    required this.onTap,
  });

  final ScanUniverse universe;
  final int? count;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    final estimate = count == null || count == 0
        ? 'not downloaded yet'
        : '~${(count! * 0.4).round().clamp(2, 3600)}s first scan';

    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 8),
      color: selected
          ? scheme.primaryContainer.withValues(alpha: 0.55)
          : scheme.surfaceContainerHighest.withValues(alpha: 0.35),
      child: ListTile(
        onTap: onTap,
        leading: Icon(
          selected ? Icons.radio_button_checked : Icons.radio_button_off,
          color: selected ? scheme.primary : scheme.onSurfaceVariant,
        ),
        title: Text(
          universe.label,
          style: theme.textTheme.titleSmall
              ?.copyWith(fontWeight: FontWeight.w600),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 2),
            Text(universe.description, style: theme.textTheme.bodySmall),
            const SizedBox(height: 4),
            Text(
              count == null
                  ? 'counting…'
                  : '$count instruments · $estimate',
              style: theme.textTheme.labelSmall?.copyWith(
                color: scheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
        isThreeLine: true,
      ),
    );
  }
}
