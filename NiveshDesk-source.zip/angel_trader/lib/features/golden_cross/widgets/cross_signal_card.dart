// ---------------------------------------------------------------------------
// cross_signal_card.dart — one detected cross, rendered the way the spec asks:
//
//   • symbol (+ exchange, company name)
//   • cross date and how many sessions ago it fired
//   • both moving averages (50 / 200) and the gap between them
//   • the current price
//   • a "Chart" button that opens TradingView
//
// Plus a 60-session sparkline with the two averages drawn over it and a marker
// on the cross bar — the same shape a trader would eyeball on a chart, shrunk to
// card size. The sparkline data travels with the signal (and is cached with it),
// so a cached card looks identical to a freshly scanned one.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/utils/link_opener.dart';
import '../cross_engine.dart';

class CrossSignalCard extends StatelessWidget {
  const CrossSignalCard({
    super.key,
    required this.signal,
    this.onTap,
    this.onOpenChart,
  });

  final CrossSignal signal;

  /// Opens the detail sheet (optional).
  final VoidCallback? onTap;

  /// Overrides the chart button behaviour (used by tests).
  final VoidCallback? onOpenChart;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final market = MarketColors.of(context);

    final isGolden = signal.direction.isBullish;
    final accent = isGolden ? market.gain : market.loss;

    return Card(
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ---- Symbol · direction · price ----------------------------
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Flexible(
                              child: Text(
                                signal.symbol,
                                style: theme.textTheme.titleMedium
                                    ?.copyWith(fontWeight: FontWeight.w700),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            const SizedBox(width: 6),
                            _Tag(
                              text: signal.exchange.code,
                              color: scheme.onSurfaceVariant,
                            ),
                          ],
                        ),
                        const SizedBox(height: 2),
                        Text(
                          signal.companyName.isEmpty
                              ? signal.priceKey
                              : signal.companyName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: theme.textTheme.bodySmall
                              ?.copyWith(color: scheme.onSurfaceVariant),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      _DirectionChip(
                        direction: signal.direction,
                        color: accent,
                        fresh: signal.isFresh,
                      ),
                      const SizedBox(height: 6),
                      Text(
                        Fmt.money(signal.lastClose),
                        style: theme.textTheme.titleMedium
                            ?.copyWith(fontWeight: FontWeight.w700),
                      ),
                    ],
                  ),
                ],
              ),

              if (signal.spark.length >= 2) ...[
                const SizedBox(height: 12),
                SizedBox(
                  height: 56,
                  width: double.infinity,
                  child: CustomPaint(
                    painter: CrossSparkPainter(
                      closes: signal.spark,
                      fast: signal.sparkFast,
                      slow: signal.sparkSlow,
                      crossIndex: signal.sparkCrossIndex,
                      priceColor: scheme.onSurface.withValues(alpha: 0.75),
                      fastColor: accent,
                      slowColor: scheme.onSurfaceVariant.withValues(alpha: 0.55),
                      markerColor: accent,
                      gridColor: scheme.outlineVariant.withValues(alpha: 0.5),
                      isUp: isGolden,
                    ),
                  ),
                ),
                const SizedBox(height: 10),
              ],

              // ---- Cross date · age --------------------------------------
              Row(
                children: [
                  Icon(Icons.event_available_rounded, size: 15, color: accent),
                  const SizedBox(width: 5),
                  Expanded(
                    child: Text(
                      '${Fmt.date(signal.crossDate)} · ${signal.ageLabel}',
                      style: theme.textTheme.bodySmall
                          ?.copyWith(fontWeight: FontWeight.w600),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  if (signal.sparkCrossIndex >= 0)
                    Text(
                      'close ${Fmt.price(signal.crossClose)}',
                      style: theme.textTheme.labelSmall
                          ?.copyWith(color: scheme.onSurfaceVariant),
                    ),
                ],
              ),

              const SizedBox(height: 10),

              // ---- The two averages -------------------------------------
              Row(
                children: [
                  Expanded(
                    child: _SmaTile(
                      label: 'SMA ${signal.fastPeriod}',
                      value: signal.fast,
                      color: accent,
                      bold: true,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _SmaTile(
                      label: 'SMA ${signal.slowPeriod}',
                      value: signal.slow,
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _SmaTile(
                      label: 'Gap',
                      value: null,
                      text: Fmt.signedPct(signal.gapPct),
                      color: accent,
                      bold: true,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 4),

              Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  onPressed: onOpenChart ??
                      () => LinkOpener.open(
                            LinkOpener.tradingViewUrl(
                              signal.exchange.code,
                              signal.symbol,
                            ),
                            context: context,
                          ),
                  icon: const Icon(Icons.show_chart_rounded, size: 18),
                  label: const Text('Chart'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Small building blocks
// ---------------------------------------------------------------------------

class _DirectionChip extends StatelessWidget {
  const _DirectionChip({
    required this.direction,
    required this.color,
    required this.fresh,
  });

  final CrossDirection direction;
  final Color color;
  final bool fresh;

  @override
  Widget build(BuildContext context) {
    final isGolden = direction.isBullish;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.45)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            isGolden ? Icons.trending_up_rounded : Icons.trending_down_rounded,
            size: 14,
            color: color,
          ),
          const SizedBox(width: 4),
          Text(
            direction.shortLabel,
            style: TextStyle(
              fontSize: 10.5,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.4,
              color: color,
            ),
          ),
          if (fresh) ...[
            const SizedBox(width: 4),
            Container(
              width: 5,
              height: 5,
              decoration: BoxDecoration(color: color, shape: BoxShape.circle),
            ),
          ],
        ],
      ),
    );
  }
}

class _SmaTile extends StatelessWidget {
  const _SmaTile({
    required this.label,
    required this.value,
    required this.color,
    this.bold = false,
    this.text,
  });

  final String label;
  final double? value;
  final String? text;
  final Color color;
  final bool bold;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.07),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: theme.textTheme.labelSmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
              fontSize: 10,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            text ?? Fmt.price(value),
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: bold ? FontWeight.w700 : FontWeight.w500,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

class _Tag extends StatelessWidget {
  const _Tag({required this.text, required this.color});

  final String text;
  final Color color;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: color.withValues(alpha: 0.4)),
        ),
        child: Text(
          text,
          style: TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w600,
            color: color,
          ),
        ),
      );
}

// ---------------------------------------------------------------------------
// Sparkline
// ---------------------------------------------------------------------------

/// Draws the last ~60 closes with the two SMAs on top and a marker on the bar
/// where the averages swapped sides.
class CrossSparkPainter extends CustomPainter {
  CrossSparkPainter({
    required this.closes,
    required this.fast,
    required this.slow,
    required this.crossIndex,
    required this.priceColor,
    required this.fastColor,
    required this.slowColor,
    required this.markerColor,
    required this.gridColor,
    this.isUp = true,
  });

  final List<double> closes;
  final List<double?> fast;
  final List<double?> slow;
  final int crossIndex;
  final Color priceColor;
  final Color fastColor;
  final Color slowColor;
  final Color markerColor;
  final Color gridColor;
  final bool isUp;

  @override
  void paint(Canvas canvas, Size size) {
    if (closes.length < 2) return;

    // ---- Scale: every visible series shares one price axis --------------
    var min = double.infinity;
    var max = double.negativeInfinity;
    void consider(double? v) {
      if (v == null) return;
      if (v < min) min = v;
      if (v > max) max = v;
    }

    for (final v in closes) {
      consider(v);
    }
    for (final v in fast) {
      consider(v);
    }
    for (final v in slow) {
      consider(v);
    }
    if (min == double.infinity || max == double.negativeInfinity) return;
    if (max - min < 1e-9) {
      max += 1;
      min -= 1;
    }
    // A little head/foot room so the extremes do not touch the edges.
    final span = max - min;
    min -= span * 0.08;
    max += span * 0.08;

    final dx = size.width / (closes.length - 1);
    double yFor(double value) =>
        size.height - ((value - min) / (max - min)) * size.height;

    // ---- Baseline grid ---------------------------------------------------
    final grid = Paint()
      ..color = gridColor
      ..strokeWidth = 1;
    for (final fraction in const [0.25, 0.75]) {
      final y = size.height * fraction;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    // ---- Cross marker (behind the lines) --------------------------------
    if (crossIndex >= 0 && crossIndex < closes.length) {
      final x = crossIndex * dx;
      _dashedVertical(
        canvas,
        x,
        size,
        Paint()
          ..color = markerColor.withValues(alpha: 0.35)
          ..strokeWidth = 1.2,
      );
    }

    // ---- The three series ------------------------------------------------
    _polyline(
      canvas,
      [for (var i = 0; i < slow.length; i++) slow[i]],
      dx,
      yFor,
      Paint()
        ..color = slowColor
        ..strokeWidth = 1.3
        ..style = PaintingStyle.stroke
        ..strokeJoin = StrokeJoin.round,
    );
    _polyline(
      canvas,
      [for (var i = 0; i < fast.length; i++) fast[i]],
      dx,
      yFor,
      Paint()
        ..color = fastColor
        ..strokeWidth = 1.4
        ..style = PaintingStyle.stroke
        ..strokeJoin = StrokeJoin.round,
    );

    // Price last so it stays readable where the lines overlap.
    final pricePath = Path();
    for (var i = 0; i < closes.length; i++) {
      final point = Offset(i * dx, yFor(closes[i]));
      i == 0 ? pricePath.moveTo(point.dx, point.dy) : pricePath.lineTo(point.dx, point.dy);
    }
    canvas.drawPath(
      pricePath,
      Paint()
        ..color = priceColor
        ..strokeWidth = 1.7
        ..style = PaintingStyle.stroke
        ..strokeJoin = StrokeJoin.round
        ..strokeCap = StrokeCap.round,
    );

    // ---- Marker dot on the cross bar ------------------------------------
    if (crossIndex >= 0 && crossIndex < closes.length) {
      final point = Offset(crossIndex * dx, yFor(closes[crossIndex]));
      canvas.drawCircle(
        point,
        4,
        Paint()..color = markerColor.withValues(alpha: 0.22),
      );
      canvas.drawCircle(point, 2.2, Paint()..color = markerColor);
    }
  }

  void _polyline(
    Canvas canvas,
    List<double?> values,
    double dx,
    double Function(double) yFor,
    Paint paint,
  ) {
    final path = Path();
    var started = false;
    for (var i = 0; i < values.length; i++) {
      final v = values[i];
      if (v == null) {
        started = false; // gap: the average did not exist yet
        continue;
      }
      final point = Offset(i * dx, yFor(v));
      if (!started) {
        path.moveTo(point.dx, point.dy);
        started = true;
      } else {
        path.lineTo(point.dx, point.dy);
      }
    }
    canvas.drawPath(path, paint);
  }

  void _dashedVertical(Canvas canvas, double x, Size size, Paint paint) {
    const dash = 3.0;
    const gap = 3.0;
    var y = 0.0;
    while (y < size.height) {
      final end = (y + dash).clamp(0, size.height);
      canvas.drawLine(Offset(x, y), Offset(x, end.toDouble()), paint);
      y += dash + gap;
    }
  }

  @override
  bool shouldRepaint(covariant CrossSparkPainter old) =>
      old.closes != closes ||
      old.fast != fast ||
      old.slow != slow ||
      old.crossIndex != crossIndex ||
      old.priceColor != priceColor ||
      old.fastColor != fastColor ||
      old.slowColor != slowColor ||
      old.isUp != isUp;
}
