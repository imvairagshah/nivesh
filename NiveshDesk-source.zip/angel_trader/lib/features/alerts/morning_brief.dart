// ---------------------------------------------------------------------------
// morning_brief.dart — 1.5.75 Daily 8:30 AM "Top 20 stocks" brief.
//
// Rules (user-approved):
//   • Top 20 = 3-Month Study ke rank se (rank 1 = best) — plain Top 20.
//   • Sirf trading days (Mon–Fri, NSE holidays MarketCalendar se).
//   • 8:30 AM par notification = summary (Top 5 naam + "+N aur"); tap/kholne
//     par poora 20 ka list (MorningBriefScreen).
//
// Execution:
//   • Android  — android_alarm_manager_plus exact alarm 8:30, background
//                isolate me khud services banata hai (cached candles se scan
//                offline bhi chalta hai; fail = last cached scan se brief).
//   • Desktop  — app chalte hue Timer; app band = notification nahi (honest).
//   • Dono     — app khulte hi catch-up: agar aaj ka brief nahi bana (app band
//                tha) to abhi bana kar notification deta hai.
// ---------------------------------------------------------------------------

import 'dart:async';
import 'dart:convert';
import 'dart:io' show Platform;

import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

import '../../data/local/app_database.dart';
import '../../data/local/dao/candle_dao.dart';
import '../../data/local/dao/fno_contract_dao.dart';
import '../../data/local/dao/ipo_dao.dart';
import '../../data/local/dao/scan_cache_dao.dart';
import '../../data/local/dao/scrip_dao.dart';
import '../../data/local/dao/settings_dao.dart';
import '../../services/auth_service.dart';
import '../../services/fno_study_service.dart';
import '../../services/fno_universe.dart';
import '../../services/market_data_service.dart';
import '../../services/notification_service.dart';
import '../../services/secure_store.dart';
import '../../services/universe_catalog.dart';
import '../../core/utils/markets.dart' show MarketCalendar;

class MorningBrief {
  const MorningBrief({required this.date, required this.entries, this.note});

  /// yyyy-MM-dd (IST) — kab generate hua.
  final String date;

  /// (rank, symbol, score) — study rank order me, Top 20.
  final List<({int rank, String symbol, double score})> entries;
  final String? note;

  List<String> get symbols => [for (final e in entries) e.symbol];

  String get summaryLine {
    final top = symbols.take(5).join(', ');
    final rest = symbols.length - 5;
    return rest > 0 ? '$top + $rest aur' : top;
  }

  Map<String, dynamic> toJson() => {
        'date': date,
        'note': note,
        'entries': [
          for (final e in entries)
            {'rank': e.rank, 'symbol': e.symbol, 'score': e.score},
        ],
      };

  static MorningBrief? fromJson(Map<String, dynamic> j) {
    try {
      return MorningBrief(
        date: j['date'] as String? ?? '',
        note: j['note'] as String?,
        entries: [
          for (final r in (j['entries'] as List? ?? const []))
            (
              rank: (r['rank'] as num?)?.toInt() ?? 0,
              symbol: r['symbol'] as String? ?? '',
              score: (r['score'] as num?)?.toDouble() ?? 0,
            ),
        ],
      );
    } catch (_) {
      return null;
    }
  }
}

class MorningBriefRunner {
  MorningBriefRunner._();

  static const briefKey = 'morning_brief_last';
  static const int topCount = 20;

  /// Study result se Top 20 (rank order) — pure function, tested.
  static List<({int rank, String symbol, double score})> topEntries(
      FnoStudyResult result, int count) {
    final rows = [...result.rows]..sort((a, b) => a.rank.compareTo(b.rank));
    return [
      for (final r in rows.take(count))
        (rank: r.rank, symbol: r.symbol, score: r.score),
    ];
  }

  /// Brief generate + save + OS notification. Fresh scan; fail = cached.
  static Future<MorningBrief?> generate({
    required FnoStudyService study,
    required ScripDao scripDao,
    required IpoDao ipoDao,
    required SettingsDao dao,
  }) async {
    FnoStudyResult? result;
    String? note;
    try {
      final universe = await FnoUniverse.load();
      final resolved = await UniverseCatalog.resolve(
        UniverseCatalog.fno,
        scripDao: scripDao,
        ipoDao: ipoDao,
        fnoSymbols: universe.symbols,
      );
      if (resolved.scrips.isNotEmpty) {
        result = await study.run(
          universe: resolved.scrips,
          companyNames: universe.companyNames,
        );
      }
    } catch (_) {
      // Fresh scan fail — cached se chalayenge.
    }
    if (result == null) {
      try {
        result = await study.loadCached();
        note = 'Cached scan (last run) se.';
      } catch (_) {
        return null;
      }
    }
    if (result == null || result.rows.isEmpty) return null;

    final entries = topEntries(result, topCount);
    if (entries.isEmpty) return null;

    final brief = MorningBrief(
      date: _today(),
      entries: entries,
      note: note,
    );
    try {
      await dao.putMeta(briefKey, jsonEncode(brief.toJson()));
    } catch (_) {}

    await NotificationService.instance.show(
      '☀️ Top 20 stocks — 8:30 brief',
      'Best 20 (study rank): ${brief.summaryLine}. '
      'Poora list dekhne ke liye app kholo.',
      payload: 'morning_brief',
    );
    return brief;
  }

  /// Load last saved brief.
  static Future<MorningBrief?> loadLast(SettingsDao dao) async {
    try {
      final raw = await dao.meta(briefKey);
      if (raw == null || raw.isEmpty) return null;
      return MorningBrief.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return null;
    }
  }

  /// Aaj trading day hai + 8:30 ho gaye + aaj ka brief nahi bana = due.
  static Future<bool> isDue(SettingsDao dao) async {
    final now = DateTime.now();
    if (!MarketCalendar.isTradingDay(now)) return false;
    if (now.hour * 60 + now.minute < 8 * 60 + 30) return false;
    final last = await loadLast(dao);
    return last?.date != _today();
  }

  static String _today() {
    final n = DateTime.now();
    return '${n.year.toString().padLeft(4, '0')}-'
        '${n.month.toString().padLeft(2, '0')}-'
        '${n.day.toString().padLeft(2, '0')}';
  }

  // ---- Background alarm entry (Android, separate isolate) -------------------

  @pragma('vm:entry-point')
  static Future<void> alarmEntry(int id) async {
    try {
      await NotificationService.instance.init();
      final database = AppDatabase.instance;
      final settingsDao = SettingsDao(database);
      if (!await isDue(settingsDao)) return;
      final auth = AuthService(store: SecureStore());
      final marketData = MarketDataService(auth: auth);
      final study = FnoStudyService(
        source: marketData,
        candles: CandleDao(database),
        cache: ScanCacheDao(database),
        contracts: FnoContractDao(database),
        marketData: marketData,
      );
      await generate(
        study: study,
        scripDao: ScripDao(database),
        ipoDao: IpoDao(database),
        dao: settingsDao,
      );
    } catch (_) {
      // Background brief fail = kal phir try; app-open catch-up bhi hai.
    }
    // Chain: agla alarm (re-arm idhar se — reboot-safe reschedule ke saath).
    await MorningBriefScheduler.arm();
  }
}

class MorningBriefScheduler {
  MorningBriefScheduler._();

  static const int alarmId = 830;
  static Timer? _timer;

  /// In-app run path (full services) — app.dart set karta hai; catch-up ise
  /// use karta hai. Nahi hai to background wala khud-sufficient builder.
  static Future<void> Function()? inAppRun;

  /// App start par: alarm arm + catch-up. Idempotent.
  static Future<void> start() async {
    await arm();
    unawaited(catchUp());
  }

  /// Agla 8:30 (trading day) — alarm/timer.
  static Future<void> arm() async {
    if (kIsWeb) return;
    final at = nextBriefTime();
    if (Platform.isAndroid) {
      try {
        await AndroidAlarmManager.oneShotAt(
          at,
          alarmId,
          MorningBriefRunner.alarmEntry,
          exact: true,
          wakeup: true,
          allowWhileIdle: true,
          alarmClock: true,
          rescheduleOnReboot: true,
        );
      } catch (_) {
        // Alarm arm fail — catch-up path app-open par chalta rahega.
      }
    } else {
      // Desktop: app chalte hue Timer (band = catch-up handle karega).
      _timer?.cancel();
      _timer = Timer(at.difference(DateTime.now()), () {
        unawaited(catchUp());
        unawaited(arm());
      });
    }
  }

  /// Agla 8:30 AM (trading day skip nahi karte weekends/holidays).
  static DateTime nextBriefTime({DateTime? now}) {
    var day = now ?? DateTime.now();
    var at = DateTime(day.year, day.month, day.day, 8, 30);
    if (at.isBefore(day) || !MarketCalendar.isTradingDay(at)) {
      do {
        at = at.add(const Duration(days: 1));
      } while (!MarketCalendar.isTradingDay(at));
    }
    return at;
  }

  /// Due hai to brief banao (app open path — full services se).
  static Future<void> catchUp() async {
    final run = inAppRun;
    if (run == null) return;
    try {
      final database = AppDatabase.instance;
      if (!await MorningBriefRunner.isDue(SettingsDao(database))) return;
      await run();
    } catch (_) {
      // Catch-up best-effort.
    }
  }
}
