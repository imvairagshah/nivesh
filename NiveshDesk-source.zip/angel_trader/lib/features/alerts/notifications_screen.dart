// ---------------------------------------------------------------------------
// notifications_screen.dart — 1.5.74 Notification Center (bell icon se khulta).
//
//   🔔 Alerts   — calls SL/target, price, study/scanner signals ki history
//   🎯 Prices   — apne price alerts add/remove (one-shot)
//
// Design = 1.5.58 rules: labelled boxes, emoji + tooltips, subtle motion.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/layout/desktop_layout.dart';
import '../../core/widgets/ui.dart';
import '../../data/local/dao/settings_dao.dart';
import 'alerts_center.dart';
import 'morning_brief.dart';
import 'morning_brief_screen.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  @override
  void initState() {
    super.initState();
    // Kholte hi sab read — badge zero.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) context.read<AlertsCenter>().markAllRead();
    });
  }

  @override
  Widget build(BuildContext context) {
    final center = context.watch<AlertsCenter>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
        actions: [
          if (center.alerts.isNotEmpty)
            IconButton(
              tooltip: 'Sab alerts hataao',
              icon: const Icon(Icons.delete_sweep_outlined),
              onPressed: () async {
                final ok = await showDialog<bool>(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: const Text('Sab alerts hataayein?'),
                    content: const Text('History saaf ho jayegi. '
                        'Price alerts waise ke waise rahenge.'),
                    actions: [
                      TextButton(
                          onPressed: () => Navigator.pop(ctx, false),
                          child: const Text('Cancel')),
                      FilledButton(
                          onPressed: () => Navigator.pop(ctx, true),
                          child: const Text('Haan, hataao')),
                    ],
                  ),
                );
                if (ok == true && context.mounted) {
                  await context.read<AlertsCenter>().clearAll();
                }
              },
            ),
          const SizedBox(width: 4),
        ],
      ),
      body: CenteredWidth(
        max: DesktopLayout.isWide(context) ? 860 : double.infinity,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 24),
          children: [
            const _MorningBriefBox(),
            const SizedBox(height: 12),
            _PriceAlertsBox(center: center),
            const SizedBox(height: 12),
            _AlertsHistory(center: center),
            const SizedBox(height: 12),
            const Text(
              'Alerts mechanical rules se bante hain (SL/target outcome, IVP '
              'extreme, scanner shortlist) — ye suggestion nahi hai. Trading '
              'se pehle khud verify karo.',
              style: TextStyle(fontSize: 10.5, height: 1.5),
            ),
          ],
        ),
      ),
    );
  }
}

class _MorningBriefBox extends StatelessWidget {
  const _MorningBriefBox();

  @override
  Widget build(BuildContext context) {
    final dao = context.read<SettingsDao>();
    return InfoSection(
      emoji: '☀️',
      title: 'Morning brief — Top 20',
      tooltip: 'Har trading day 8:30 AM par 3-Month Study ka Top 20 — '
          'notification + yahan list.',
      children: [
        FutureBuilder<MorningBrief?>(
          future: MorningBriefRunner.loadLast(dao),
          builder: (context, snap) {
            final brief = snap.data;
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  brief == null
                      ? 'Aaj ka brief abhi nahi bana — 8:30 AM par automatic '
                          'ban jaata hai.'
                      : '${brief.date} — ${brief.entries.length} stocks: '
                          '${brief.summaryLine}',
                  style: const TextStyle(fontSize: 12),
                ),
                const SizedBox(height: 8),
                FilledButton.tonalIcon(
                  icon: const Icon(Icons.wb_sunny_outlined, size: 18),
                  label: const Text('Poora Top 20 list dekho'),
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                        builder: (_) => const MorningBriefScreen()),
                  ),
                ),
              ],
            );
          },
        ),
      ],
    );
  }
}

class _PriceAlertsBox extends StatelessWidget {
  const _PriceAlertsBox({required this.center});
  final AlertsCenter center;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return InfoSection(
      emoji: '🎯',
      title: 'Price alerts',
      tooltip: 'Apna level set karo — LTP pahunchte hi alert. One-shot: '
          'fire hone ke baad khud band ho jaata hai (dobara add kar sakte ho). '
          'Market hours + Angel login chahiye.',
      children: [
        for (final alert in center.priceAlerts)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: Row(
              children: [
                Text(
                  alert.active ? '🔔' : '🔕',
                  style: const TextStyle(fontSize: 13),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    '${alert.symbol} — ${alert.label}'
                    '${alert.active ? '' : '  (fire ho chuka)'}',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: alert.active ? null : scheme.onSurfaceVariant,
                    ),
                  ),
                ),
                IconButton(
                  tooltip: 'Hataao',
                  icon: const Icon(Icons.close_rounded, size: 16),
                  onPressed: () => context
                      .read<AlertsCenter>()
                      .removePriceAlert(alert),
                ),
              ],
            ),
          ),
        const SizedBox(height: 6),
        FilledButton.tonalIcon(
          icon: const Icon(Icons.add_alert_rounded, size: 18),
          label: const Text('Naya price alert'),
          onPressed: () => _addAlertSheet(context),
        ),
      ],
    );
  }

  void _addAlertSheet(BuildContext context) {
    final symbolCtrl = TextEditingController();
    final valueCtrl = TextEditingController();
    var direction = PriceDirection.above;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (sheetContext, setSheet) => Padding(
          padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: 4,
            bottom: MediaQuery.viewInsetsOf(sheetContext).bottom + 24,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('Naya price alert',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              TextField(
                controller: symbolCtrl,
                textCapitalization: TextCapitalization.characters,
                decoration: const InputDecoration(
                  labelText: 'Symbol (e.g. RELIANCE)',
                  prefixIcon: Icon(Icons.show_chart_rounded),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: valueCtrl,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                  labelText: 'Price level (₹)',
                  prefixIcon: Icon(Icons.currency_rupee_rounded),
                ),
              ),
              const SizedBox(height: 10),
              SegmentedButton<PriceDirection>(
                segments: const [
                  ButtonSegment(
                      value: PriceDirection.above,
                      label: Text('⬆ Upar jaaye to')),
                  ButtonSegment(
                      value: PriceDirection.below,
                      label: Text('⬇ Neeche jaaye to')),
                ],
                selected: {direction},
                onSelectionChanged: (s) => setSheet(() => direction = s.first),
              ),
              const SizedBox(height: 14),
              FilledButton(
                onPressed: () {
                  final symbol = symbolCtrl.text.trim().toUpperCase();
                  final value = double.tryParse(valueCtrl.text.trim());
                  if (symbol.isEmpty || value == null || value <= 0) return;
                  Navigator.pop(sheetContext);
                  context.read<AlertsCenter>().addPriceAlert(
                        symbol: symbol,
                        direction: direction,
                        value: value,
                      );
                },
                child: const Text('Alert save karo'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AlertsHistory extends StatelessWidget {
  const _AlertsHistory({required this.center});
  final AlertsCenter center;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return InfoSection(
      emoji: '🔔',
      title: 'Alert history',
      tooltip: 'Calls ke SL/target hits, price alerts, IVP/IVR extremes aur '
          'scanner shortlist updates — sab yahan.',
      children: center.alerts.isEmpty
          ? [
              const Text(
                'Abhi koi alert nahi. Alerts yahan aayenge:\n'
                '• 📞 Calls Board — tracked call ka SL/target hit\n'
                '• 🎯 Price alert — aapka set kiya hua level\n'
                '• 💎🏷️ Study — IVP premium sasta/mehenga\n'
                '• 📡 Scanner — daily shortlist ready',
                style: TextStyle(fontSize: 12, height: 1.6),
              ),
            ]
          : [
              for (final alert in center.alerts.take(60))
                Container(
                  margin: const EdgeInsets.symmetric(vertical: 3),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                  decoration: BoxDecoration(
                    color: scheme.surfaceContainerLow,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(_emojiFor(alert.kind),
                          style: const TextStyle(fontSize: 15)),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(alert.title,
                                style: const TextStyle(
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w800)),
                            const SizedBox(height: 2),
                            Text(alert.body,
                                style: TextStyle(
                                    fontSize: 11.5, height: 1.45)),
                            const SizedBox(height: 3),
                            Text(_ago(alert.at),
                                style: TextStyle(
                                    fontSize: 9.5,
                                    color: scheme.onSurfaceVariant)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
            ],
    );
  }

  String _emojiFor(AlertKind kind) => switch (kind) {
        AlertKind.callOutcome => '📞',
        AlertKind.price => '🎯',
        AlertKind.signal => '📡',
      };

  String _ago(DateTime at) {
    final d = DateTime.now().difference(at);
    if (d.inMinutes < 1) return 'abhi abhi';
    if (d.inMinutes < 60) return '${d.inMinutes} min pehle';
    if (d.inHours < 24) return '${d.inHours} ghante pehle';
    return '${d.inDays} din pehle';
  }
}
