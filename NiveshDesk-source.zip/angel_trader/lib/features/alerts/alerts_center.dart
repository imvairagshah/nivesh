// ---------------------------------------------------------------------------
// alerts_center.dart — 1.5.74 Notification Center ka engine.
//
// Teen tarah ke alerts:
//   • callOutcome — tracked call ka SL/target hit (classifyOutcome se)
//   • price       — user-ka apna level (e.g. RELIANCE ≥ 3000), one-shot
//   • signal      — IVP/IVR extremes (premium sasta/mehenga) + F&O shortlist
//
// AlertsCenter ek singleton hai (services se seedha access) + ChangeNotifier
// (UI bell badge live update). Log + price alerts SettingsDao meta me persist.
// OS pop-up ke liye NotificationService — best effort, kabhi crash nahi.
// ---------------------------------------------------------------------------

import 'dart:convert';

import 'package:flutter/foundation.dart';

import '../../data/local/dao/settings_dao.dart';
import '../../services/notification_service.dart';

enum AlertKind { callOutcome, price, signal }

enum PriceDirection { above, below }

class AppAlert {
  const AppAlert({
    required this.id,
    required this.kind,
    required this.title,
    required this.body,
    required this.at,
    this.symbol,
    this.read = false,
  });

  final int id;
  final AlertKind kind;
  final String title;
  final String body;
  final String? symbol;
  final DateTime at;
  final bool read;

  AppAlert copyWith({bool? read}) => AppAlert(
        id: id,
        kind: kind,
        title: title,
        body: body,
        symbol: symbol,
        at: at,
        read: read ?? this.read,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'kind': kind.name,
        'title': title,
        'body': body,
        'symbol': symbol,
        'at': at.toIso8601String(),
        'read': read,
      };

  static AppAlert? fromJson(Map<String, dynamic> j) {
    try {
      return AppAlert(
        id: (j['id'] as num?)?.toInt() ?? 0,
        kind: AlertKind.values.firstWhere(
          (k) => k.name == j['kind'],
          orElse: () => AlertKind.signal,
        ),
        title: j['title'] as String? ?? '',
        body: j['body'] as String? ?? '',
        symbol: j['symbol'] as String?,
        at: DateTime.tryParse(j['at'] as String? ?? '') ?? DateTime.now(),
        read: j['read'] == true,
      );
    } catch (_) {
      return null;
    }
  }
}

class PriceAlert {
  const PriceAlert({
    required this.symbol,
    required this.direction,
    required this.value,
    this.active = true,
  });

  final String symbol;
  final PriceDirection direction;
  final double value;
  final bool active;

  bool triggeredBy(double ltp) => direction == PriceDirection.above
      ? ltp >= value
      : ltp <= value;

  String get label =>
      '₹${value.toStringAsFixed(2)} ke ${direction == PriceDirection.above ? 'upar' : 'neeche'}';

  PriceAlert copyWith({bool? active}) => PriceAlert(
        symbol: symbol,
        direction: direction,
        value: value,
        active: active ?? this.active,
      );

  Map<String, dynamic> toJson() => {
        'symbol': symbol,
        'direction': direction.name,
        'value': value,
        'active': active,
      };

  static PriceAlert? fromJson(Map<String, dynamic> j) {
    try {
      return PriceAlert(
        symbol: (j['symbol'] as String? ?? '').toUpperCase(),
        direction: PriceDirection.values.firstWhere(
          (d) => d.name == j['direction'],
          orElse: () => PriceDirection.above,
        ),
        value: (j['value'] as num?)?.toDouble() ?? 0,
        active: j['active'] != false,
      );
    } catch (_) {
      return null;
    }
  }
}

class AlertsCenter extends ChangeNotifier {
  AlertsCenter._();
  static final AlertsCenter instance = AlertsCenter._();

  static const _logKey = 'notif_log';
  static const _priceKey = 'notif_price_alerts';
  static const _extremesKey = 'notif_prev_extremes';
  static const _shortlistKey = 'notif_prev_shortlist';
  static const _maxLog = 200;

  SettingsDao? _dao;
  bool _loaded = false;

  final List<AppAlert> _alerts = [];
  final List<PriceAlert> _priceAlerts = [];
  Set<String> _prevExtremes = {};
  Set<String> _prevShortlist = {};
  int _nextId = 1;

  /// Price-alert checking ke liye main() se inject hota hai
  /// (Angel login + scrip resolution wahan se aata hai).
  Future<Map<String, double>> Function(List<String> symbols)? priceFetcher;

  List<AppAlert> get alerts => List.unmodifiable(_alerts);
  List<PriceAlert> get priceAlerts => List.unmodifiable(_priceAlerts);
  int get unreadCount => _alerts.where((a) => !a.read).length;

  Future<void> load(SettingsDao dao) async {
    _dao = dao;
    if (_loaded) return;
    _loaded = true;
    try {
      final logRaw = await dao.meta(_logKey);
      if (logRaw != null && logRaw.isNotEmpty) {
        for (final j in (jsonDecode(logRaw) as List)) {
          final a = AppAlert.fromJson(j as Map<String, dynamic>);
          if (a != null) _alerts.add(a);
        }
        _alerts.sort((x, y) => y.at.compareTo(x.at));
        if (_alerts.isNotEmpty) _nextId = _alerts.first.id + 1;
      }
      final priceRaw = await dao.meta(_priceKey);
      if (priceRaw != null && priceRaw.isNotEmpty) {
        for (final j in (jsonDecode(priceRaw) as List)) {
          final p = PriceAlert.fromJson(j as Map<String, dynamic>);
          if (p != null) _priceAlerts.add(p);
        }
      }
      final exRaw = await dao.meta(_extremesKey);
      if (exRaw != null && exRaw.isNotEmpty) {
        _prevExtremes = Set<String>.from(jsonDecode(exRaw) as List);
      }
      final slRaw = await dao.meta(_shortlistKey);
      if (slRaw != null && slRaw.isNotEmpty) {
        _prevShortlist = Set<String>.from(jsonDecode(slRaw) as List);
      }
    } catch (_) {
      // Corrupt meta = fresh start, app chalti rahe.
    }
    notifyListeners();
  }

  Future<void> _persistLog() async {
    final dao = _dao;
    if (dao == null) return;
    try {
      await dao.putMeta(
        _logKey,
        jsonEncode(_alerts.take(_maxLog).map((a) => a.toJson()).toList()),
      );
    } catch (_) {}
  }

  Future<void> _persistPrices() async {
    final dao = _dao;
    if (dao == null) return;
    try {
      await dao.putMeta(
        _priceKey,
        jsonEncode(_priceAlerts.map((p) => p.toJson()).toList()),
      );
    } catch (_) {}
  }

  /// Naya alert: log me (top par) + OS pop-up (best effort).
  Future<void> raise({
    required AlertKind kind,
    required String title,
    required String body,
    String? symbol,
  }) async {
    final alert = AppAlert(
      id: _nextId++,
      kind: kind,
      title: title,
      body: body,
      symbol: symbol,
      at: DateTime.now(),
    );
    _alerts.insert(0, alert);
    if (_alerts.length > _maxLog) _alerts.removeRange(_maxLog, _alerts.length);
    notifyListeners();
    await _persistLog();
    // Pop-up async — ise await nahi karte (UI kabhi block nahi).
    NotificationService.instance.show(title, body);
  }

  Future<void> markAllRead() async {
    for (var i = 0; i < _alerts.length; i++) {
      if (!_alerts[i].read) _alerts[i] = _alerts[i].copyWith(read: true);
    }
    notifyListeners();
    await _persistLog();
  }

  Future<void> clearAll() async {
    _alerts.clear();
    notifyListeners();
    await _persistLog();
  }

  // ---- Price alerts --------------------------------------------------------

  Future<void> addPriceAlert({
    required String symbol,
    required PriceDirection direction,
    required double value,
  }) async {
    _priceAlerts.removeWhere(
        (p) => p.symbol == symbol.toUpperCase() && p.direction == direction);
    _priceAlerts.add(PriceAlert(
      symbol: symbol.toUpperCase(),
      direction: direction,
      value: value,
    ));
    notifyListeners();
    await _persistPrices();
  }

  Future<void> removePriceAlert(PriceAlert alert) async {
    _priceAlerts.removeWhere(
        (p) => p.symbol == alert.symbol && p.direction == alert.direction);
    notifyListeners();
    await _persistPrices();
  }

  /// Market hours me checker bulata hai. Fetcher fail/na-mila = skip.
  Future<void> checkPriceAlerts() async {
    final fetcher = priceFetcher;
    if (fetcher == null) return;
    final active = _priceAlerts.where((p) => p.active).toList();
    if (active.isEmpty) return;
    final symbols = active.map((p) => p.symbol).toSet().toList();
    Map<String, double> prices;
    try {
      prices = await fetcher(symbols);
    } catch (_) {
      return;
    }
    for (final alert in active) {
      final ltp = prices[alert.symbol];
      if (ltp == null || ltp <= 0) continue;
      if (alert.triggeredBy(ltp)) {
        // One-shot: fire karke band.
        _priceAlerts[_priceAlerts.indexOf(alert)] = alert.copyWith(active: false);
        await raise(
          kind: AlertKind.price,
          symbol: alert.symbol,
          title: '🎯 Price alert — ${alert.symbol}',
          body: '${alert.symbol} ₹${ltp.toStringAsFixed(2)} — ${alert.label} '
              'pahunch gaya.',
        );
      }
    }
    await _persistPrices();
    notifyListeners();
  }

  // ---- Study / Scanner signals ---------------------------------------------

  /// 3-Month Study scan ke baad: IVP ≥ 80 (mehenga) / ≤ 20 (sasta) — jo ab
  /// extreme me aaye (pehle nahi the) wahi alert; har scan par repeat nahi.
  Future<void> checkIvExtremes(List<(String, double, double)> rows) async {
    // rows: (symbol, ivp, ivr)
    final now = <String>{};
    final titles = <String, String>{};
    for (final (symbol, ivp, _) in rows) {
      if (ivp >= 80) {
        now.add('$symbol:rich');
        titles['$symbol:rich'] =
            '💎 $symbol — premium MEHENGA (IVP ${ivp.toStringAsFixed(0)})';
      } else if (ivp <= 20) {
        now.add('$symbol:cheap');
        titles['$symbol:cheap'] =
            '🏷️ $symbol — premium SASTA (IVP ${ivp.toStringAsFixed(0)})';
      }
    }
    final fresh = now.difference(_prevExtremes);
    _prevExtremes = now;
    for (final key in fresh) {
      await raise(
        kind: AlertKind.signal,
        symbol: key.split(':').first,
        title: titles[key] ?? 'IV extreme — $key',
        body: '3-Month Study scan me IVP extreme. IV/IVR details app me '
            'Study screen dekho. (Signal hai — suggestion nahi.)',
      );
    }
    final dao = _dao;
    if (dao != null) {
      try {
        await dao.putMeta(_extremesKey, jsonEncode(now.toList()));
      } catch (_) {}
    }
  }

  /// F&O Scanner daily scan ke baad: shortlist ready + naye symbols.
  Future<void> checkShortlist(List<String> symbols) async {
    final now = symbols.map((s) => s.toUpperCase()).toSet();
    final fresh = now.difference(_prevShortlist);
    final hadBefore = _prevShortlist.isNotEmpty;
    _prevShortlist = now;
    if (now.isNotEmpty && (!hadBefore || fresh.isNotEmpty)) {
      // Pehli baar ya naye symbols aaye — ek summary alert.
      await raise(
        kind: AlertKind.signal,
        title: '📡 F&O Scanner — shortlist ready',
        body: '${now.length} stock${now.length == 1 ? '' : 's'} shortlist me'
            '${fresh.isEmpty ? '' : ' — naye: ${fresh.join(', ')}'}. '
            'Rank-points score + trade plan app me Scanner screen dekho.',
      );
    }
    final dao = _dao;
    if (dao != null) {
      try {
        await dao.putMeta(_shortlistKey, jsonEncode(now.toList()));
      } catch (_) {}
    }
  }
}
