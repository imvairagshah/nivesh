// ---------------------------------------------------------------------------
// morning_brief_screen.dart — 1.5.75 "☀️ Top 20 stocks" ka poora list.
// Notification tap se ya Notifications screen ke box se khulta hai.
// Ranking = 3-Month Study ka rank — mechanical, suggestion nahi.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/layout/desktop_layout.dart';
import '../../core/widgets/ui.dart';
import '../../data/local/dao/settings_dao.dart';
import 'morning_brief.dart';

class MorningBriefScreen extends StatelessWidget {
  const MorningBriefScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final dao = context.read<SettingsDao>();
    final scheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(title: const Text('☀️ Morning brief — Top 20')),
      body: CenteredWidth(
        max: DesktopLayout.isWide(context) ? 860 : double.infinity,
        child: FutureBuilder<MorningBrief?>(
          future: MorningBriefRunner.loadLast(dao),
          builder: (context, snap) {
            final brief = snap.data;
            if (brief == null) {
              return const Center(
                child: Padding(
                  padding: EdgeInsets.all(24),
                  child: Text(
                    'Abhi tak aaj ka brief nahi bana.\n'
                    '8:30 AM par automatic ban jaata hai (trading days) — '
                    'app band raha ho to khulte hi ban jaayega.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 13, height: 1.6),
                  ),
                ),
              );
            }
            return ListView(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 24),
              children: [
                InfoSection(
                  emoji: '☀️',
                  title: 'Top 20 — ${brief.date}',
                  tooltip: '3-Month Study ka rank (1 = best). Ye mechanical '
                      'ranking hai — suggestion/advice nahi.',
                  children: [
                    if (brief.note != null)
                      Text(brief.note!,
                          style: TextStyle(
                              fontSize: 11, color: scheme.onSurfaceVariant)),
                    const SizedBox(height: 6),
                    for (final e in brief.entries)
                      Container(
                        margin: const EdgeInsets.symmetric(vertical: 2.5),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 7),
                        decoration: BoxDecoration(
                          color: scheme.surfaceContainerLow,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          children: [
                            SizedBox(
                              width: 30,
                              child: Text('#${e.rank}',
                                  style: TextStyle(
                                      fontSize: 11.5,
                                      fontWeight: FontWeight.w800,
                                      color: scheme.onSurfaceVariant)),
                            ),
                            Expanded(
                              child: Text(e.symbol,
                                  style: const TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w800)),
                            ),
                            Text('score ${e.score.toStringAsFixed(1)}',
                                style: TextStyle(
                                    fontSize: 11,
                                    color: scheme.onSurfaceVariant)),
                          ],
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                const Text(
                  'Ranking = 3-Month Study ka score — ye mechanical list hai, '
                  'BUY suggestion nahi. Har stock khud verify karo (levels, '
                  'risk, news) trade se pehle.',
                  style: TextStyle(fontSize: 10.5, height: 1.5),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
