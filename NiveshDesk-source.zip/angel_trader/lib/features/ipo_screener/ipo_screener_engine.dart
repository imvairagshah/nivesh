// ---------------------------------------------------------------------------
// ipo_screener_engine.dart — the pure logic behind Feature 1.
//
// THE RULE (from the spec):
//   "If the current price is within ±3% of the Listing Day High OR the Listing
//    Day Low → include the stock in the results."
//
// The engine is intentionally free of Flutter, HTTP and SQLite so it can be
// unit-tested to the rupee (see test/features/ipo_screener/engine_test.dart).
//
// It is used in two steps because the middle one is a network call:
//   1. `resolveAll(ipos)`  → which instruments (tokens) need prices
//   2. (caller fetches LTPs for those tokens, batched 50 per SmartAPI request)
//   3. `evaluate(...)`     → filter + sort + label the matches
// ---------------------------------------------------------------------------

import '../../core/utils/markets.dart';
import '../../data/local/models/ipo.dart';
import '../../data/remote/dto/quote.dart';
import '../../data/remote/dto/scrip.dart';
import '../../services/token_resolver.dart';

/// Tunables for one screening run.
class IpoScreenerConfig {
  /// ± band around the listing high/low, in percent. Spec default: 3 %.
  final double proximityPct;

  /// A price older than this (while the market is open) is flagged stale so the
  /// user knows the card is not live.
  final Duration staleAfter;

  /// Hard cap on rows kept after sorting (protects very long lists).
  final int maxResults;

  /// `true` (spec behaviour) = only rows inside the ±band become matches.
  ///
  /// `false` keeps every *priced* row, each labelled with the level it is
  /// closest to and flagged `isInBand: false`. The screener uses this for its
  /// "All screened" view and for the "closest right now" list, so the screen
  /// can always show something concrete instead of an unexplained empty list.
  final bool inBandOnly;

  const IpoScreenerConfig({
    this.proximityPct = 3,
    this.staleAfter = const Duration(minutes: 30),
    this.maxResults = 500,
    this.inBandOnly = true,
  });
}

/// An IPO row paired with the instrument token it resolves to.
class ResolvedIpo {
  final Ipo ipo;
  final TokenResolution resolution;

  const ResolvedIpo({required this.ipo, required this.resolution});

  bool get isResolved => resolution.isResolved;
  String? get token => resolution.token;
  Exchange get effectiveExchange =>
      resolution.scrip?.exchange ?? ipo.exchange;
}

/// User-driven filters from the screener's filter sheet.
class IpoFilters {
  /// `null` = both exchanges.
  final Exchange? exchange;

  /// `null` = every year.
  final int? listingYear;

  /// Empty = both levels.
  final Set<LevelType> levels;

  /// Free-text search over symbol, company name and sector.
  final String query;

  const IpoFilters({
    this.exchange,
    this.listingYear,
    this.levels = const {},
    this.query = '',
  });

  bool get isActive =>
      exchange != null || listingYear != null || levels.isNotEmpty || query.trim().isNotEmpty;

  IpoFilters copyWith({
    Exchange? exchange,
    bool clearExchange = false,
    int? listingYear,
    bool clearListingYear = false,
    Set<LevelType>? levels,
    String? query,
  }) =>
      IpoFilters(
        exchange: clearExchange ? null : (exchange ?? this.exchange),
        listingYear: clearListingYear ? null : (listingYear ?? this.listingYear),
        levels: levels ?? this.levels,
        query: query ?? this.query,
      );
}

/// One screened result — everything the card needs, pre-computed.
class IpoMatch {
  final Ipo ipo;

  /// Exchange actually used for the price (may differ from the IPO row when the
  /// ticker resolved on the other exchange).
  final Exchange exchange;
  final String? token;

  final double ltp;

  /// The level the price is hugging.
  final LevelType level;

  /// The price of that level (listing high or listing low).
  final double levelPrice;

  /// Signed % distance from [levelPrice]: `-1.2` means 1.2 % below the level.
  final double diffPct;

  /// `|diffPct|` — what the ±band is compared against.
  final double distancePct;

  final PriceBand band;

  /// Day change % when the price source knew the previous close.
  final double? changePct;

  final DateTime pricedAt;

  /// `true` when the price did not come from a fresh live source.
  final bool isStale;

  /// True when the LTP has moved beyond the listing-day range entirely
  /// (a "new high above listing high" is common for hot IPOs).
  final bool isAboveListingRange;
  final bool isBelowListingRange;

  /// `true` when this row passed the spec's ±band test. Rows with
  /// `isInBand: false` only appear in the "All screened" view.
  final bool isInBand;

  const IpoMatch({
    required this.ipo,
    required this.exchange,
    required this.token,
    required this.ltp,
    required this.level,
    required this.levelPrice,
    required this.diffPct,
    required this.distancePct,
    required this.band,
    required this.pricedAt,
    this.changePct,
    this.isStale = false,
    this.isAboveListingRange = false,
    this.isBelowListingRange = false,
    this.isInBand = true,
  });

  /// TradingView symbol for the "Chart" button.
  String get tradingViewSymbol => '${exchange.code}:${ipo.symbol}';
  String get tradingViewUrl =>
      'https://in.tradingview.com/chart/?symbol=${Uri.encodeComponent(tradingViewSymbol)}';

  /// One-line explanation rendered under the price.
  /// e.g. `1.24% below listing high (₹412.50)`.
  String get proximityLabel {
    final direction = diffPct >= 0 ? 'above' : 'below';
    final levelName = level == LevelType.high ? 'listing high' : 'listing low';
    return '${distancePct.toStringAsFixed(2)}% $direction $levelName';
  }

  @override
  String toString() =>
      'IpoMatch(${ipo.symbol}, ${level.label}, ${distancePct.toStringAsFixed(2)}%)';
}

/// Why an IPO row produced no match — surfaced in a collapsible footer so the
/// user can fix bad rows instead of silently losing them.
/// Why a row did not make it into the match list. The screener needs this to
/// tell two very different situations apart:
///
///   • "the row is fine, the market just isn't near its level" (normal — most of
///     the database, every scan), and
///   • "this row can never be screened until something is fixed" (a ticker that
///     no longer exists, a symbol the broker does not quote, levels that could
///     not be fetched). Those are surfaced in the UI as *needs attention*.
enum IpoSkipKind {
  /// The symbol did not resolve to a broker instrument token.
  notResolved,

  /// Token found, but the quote came back without a price for it.
  noPrice,

  /// Listing-day high/low have not been fetched yet (still queued).
  levelsPending,

  /// Listing-day high/low could not be fetched at all (symbol gone).
  levelsUnavailable,

  /// Dropped by the user's filters (exchange / year / search text).
  filtered,

  /// Resolved and priced, simply outside the ±band right now.
  outsideBand,
}

class IpoSkip {
  final Ipo ipo;
  final String reason;

  /// Which gate dropped the row — see [IpoSkipKind].
  final IpoSkipKind kind;

  final List<Scrip> candidates;

  const IpoSkip({
    required this.ipo,
    required this.reason,
    this.kind = IpoSkipKind.outsideBand,
    this.candidates = const [],
  });

  /// `true` when the row cannot be screened until the user (or the app) fixes
  /// something — as opposed to simply not being near its level today.
  bool get needsAttention =>
      kind == IpoSkipKind.notResolved ||
      kind == IpoSkipKind.noPrice ||
      kind == IpoSkipKind.levelsUnavailable;
}

/// Outcome of one screening run.
class IpoScreenerResult {
  final List<IpoMatch> matches;
  final List<IpoSkip> skipped;

  /// Rows in the database that passed the *filters* (before the ±band test).
  final int considered;
  final int totalRows;

  /// Rows whose token could be resolved (i.e. that could be priced).
  final int resolvedCount;

  /// Rows for which a price was available in [prices].
  final int pricedCount;

  final int nearHighCount;
  final int nearLowCount;
  final int staleCount;

  final double proximityPct;
  final DateTime generatedAt;

  /// `true` when the caller served this from cache instead of the network.
  final bool isFromCache;

  const IpoScreenerResult({
    required this.matches,
    required this.skipped,
    required this.considered,
    required this.totalRows,
    required this.resolvedCount,
    required this.pricedCount,
    required this.nearHighCount,
    required this.nearLowCount,
    required this.staleCount,
    required this.proximityPct,
    required this.generatedAt,
    this.isFromCache = false,
  });

  bool get isEmpty => matches.isEmpty;

  factory IpoScreenerResult.empty() => IpoScreenerResult(
        matches: const [],
        skipped: const [],
        considered: 0,
        totalRows: 0,
        resolvedCount: 0,
        pricedCount: 0,
        nearHighCount: 0,
        nearLowCount: 0,
        staleCount: 0,
        proximityPct: 3,
        generatedAt: DateTime.now(),
      );
}

/// Sort orders offered in the UI.
enum IpoSortMode {
  closest('Closest to level'),
  symbol('Symbol (A–Z)'),
  newestListing('Newest listing'),
  biggestDayMove('Biggest day move');

  const IpoSortMode(this.label);
  final String label;
}

class IpoScreenerEngine {
  final TokenResolver resolver;

  IpoScreenerEngine(this.resolver);

  /// Floating-point slack so an *exactly* 3.00 % boundary value is not excluded
  /// by binary rounding (0.03 * 100 == 3.0000000000000004 in IEEE-754).
  static const double bandEpsilon = 1e-9;

  // -------------------------------------------------------------------------
  // Step 1 — resolution
  // -------------------------------------------------------------------------

  /// Resolves every IPO row to an instrument token (cached by the caller, so
  /// this normally runs once per new/edited row rather than per refresh).
  List<ResolvedIpo> resolveAll(List<Ipo> ipos) => ipos
      .map((ipo) => ResolvedIpo(
            ipo: ipo,
            resolution: resolver.resolve(
              ipo.symbol,
              preferredExchange: ipo.exchange,
              companyName: ipo.companyName,
            ),
          ))
      .toList(growable: false);

  /// Distinct SmartAPI tokens that need an LTP fetch.
  List<String> tokensFor(Iterable<ResolvedIpo> items) {
    final tokens = <String>{};
    for (final item in items) {
      final token = item.token;
      if (token != null && token.isNotEmpty) tokens.add(token);
    }
    return tokens.toList(growable: false);
  }

  // -------------------------------------------------------------------------
  // Step 3 — filtering / scoring
  // -------------------------------------------------------------------------

  IpoScreenerResult evaluate({
    required List<ResolvedIpo> items,
    required Map<String, PricedValue> prices,
    IpoScreenerConfig config = const IpoScreenerConfig(),
    IpoFilters filters = const IpoFilters(),
    IpoSortMode sort = IpoSortMode.closest,
    DateTime? now,
    bool isFromCache = false,
  }) {
    final clock = now ?? DateTime.now();
    final matches = <IpoMatch>[];
    final skipped = <IpoSkip>[];
    var resolvedCount = 0;
    var pricedCount = 0;
    var considered = 0;

    for (final item in items) {
      final ipo = item.ipo;

      // ---- Resolution gate -------------------------------------------------
      if (!item.isResolved) {
        skipped.add(IpoSkip(
          ipo: ipo,
          kind: IpoSkipKind.notResolved,
          reason: item.resolution.note.isEmpty
              ? 'Instrument token not found.'
              : item.resolution.note,
          candidates: item.resolution.candidates,
        ));
        continue;
      }
      resolvedCount++;

      // ---- Levels gate -----------------------------------------------------
      // The ±band test needs the listing-day high and low. Rows that do not have
      // them yet (bundled rows whose levels the app still has to fetch from the
      // broker) are reported instead of being silently dropped — that is what
      // makes the "fetching levels 120/551" progress in the UI meaningful.
      if (!ipo.hasLevels) {
        skipped.add(IpoSkip(
          ipo: ipo,
          kind: ipo.levelsUnavailable
              ? IpoSkipKind.levelsUnavailable
              : IpoSkipKind.levelsPending,
          reason: ipo.levelsUnavailable
              ? 'Listing-day high/low could not be fetched for this symbol '
                  '(symbol not found on the exchange).'
              : 'Listing-day high/low not fetched yet.',
        ));
        continue;
      }

      // ---- User filters (cheap, before the price lookup) -------------------
      if (!_passesFilters(ipo, filters)) continue;

      // ---- Price gate ------------------------------------------------------
      final price = prices[ipo.priceKey] ?? prices[priceKeyFor(item)];
      if (price == null || price.value <= 0) {
        skipped.add(IpoSkip(
          ipo: ipo,
          kind: IpoSkipKind.noPrice,
          reason: 'No price received (market closed, or the token no longer trades).',
        ));
        continue;
      }
      pricedCount++;
      considered++;

      // ---- The ±band test --------------------------------------------------
      final diffHigh = ipo.distanceFromHigh(price.value); // signed %
      final diffLow = ipo.distanceFromLow(price.value);

      LevelType? level;
      double diffPct = 0;

      final limit = config.proximityPct + bandEpsilon;
      final nearHigh = diffHigh.abs() <= limit;
      final nearLow = diffLow.abs() <= limit;

      if (nearHigh && nearLow) {
        // Extremely rare (a ₹2 band on a ₹200 stock); take the closer level.
        if (diffHigh.abs() <= diffLow.abs()) {
          level = LevelType.high;
          diffPct = diffHigh;
        } else {
          level = LevelType.low;
          diffPct = diffLow;
        }
      } else if (nearHigh) {
        level = LevelType.high;
        diffPct = diffHigh;
      } else if (nearLow) {
        level = LevelType.low;
        diffPct = diffLow;
      }

      if (level == null) {
        // Not near either level. The spec drops these rows — unless the caller
        // asked for the full picture ("All screened" / "closest right now"),
        // in which case the row is kept, labelled with the closer level.
        if (config.inBandOnly) continue;
        level = diffHigh.abs() <= diffLow.abs() ? LevelType.high : LevelType.low;
        diffPct = level == LevelType.high ? diffHigh : diffLow;
      }
      final inBand = nearHigh || nearLow;

      final isStale = !price.isLive && clock.difference(price.asOf) > config.staleAfter;

      matches.add(IpoMatch(
        ipo: ipo,
        exchange: item.effectiveExchange,
        token: item.token,
        ltp: price.value,
        level: level,
        levelPrice: level == LevelType.high ? ipo.listingHigh : ipo.listingLow,
        diffPct: diffPct,
        distancePct: diffPct.abs(),
        band: _bandFor(ipo, price.value, diffHigh, nearHigh, nearLow, config.proximityPct),
        changePct: price.changePct,
        pricedAt: price.asOf,
        isStale: isStale,
        isAboveListingRange: price.value > ipo.listingHigh,
        isBelowListingRange: price.value < ipo.listingLow,
        isInBand: inBand,
      ));
    }

    // Level filter (Near High / Near Low chips) is applied last, because it can
    // only be evaluated once we know which level each row is hugging.
    final levelFiltered = filters.levels.isEmpty
        ? matches
        : matches.where((m) => filters.levels.contains(m.level)).toList();

    _sort(levelFiltered, sort);
    final limited = levelFiltered.length > config.maxResults
        ? levelFiltered.sublist(0, config.maxResults)
        : levelFiltered;

    return IpoScreenerResult(
      matches: List.unmodifiable(limited),
      skipped: List.unmodifiable(skipped),
      considered: considered,
      totalRows: items.length,
      resolvedCount: resolvedCount,
      pricedCount: pricedCount,
      nearHighCount:
          limited.where((m) => m.isInBand && m.level == LevelType.high).length,
      nearLowCount:
          limited.where((m) => m.isInBand && m.level == LevelType.low).length,
      staleCount: limited.where((m) => m.isStale).length,
      proximityPct: config.proximityPct,
      generatedAt: clock,
      isFromCache: isFromCache,
    );
  }

  // -------------------------------------------------------------------------
  // Internals
  // -------------------------------------------------------------------------

  /// Price keys are written by the data layer as `EXCHANGE:SYMBOL` using the
  /// **IPO row's** exchange, because that is how the UI names the stock.
  static String priceKeyFor(ResolvedIpo item) =>
      '${item.ipo.exchange.code}:${item.ipo.symbol.toUpperCase()}';

  bool _passesFilters(Ipo ipo, IpoFilters filters) {
    if (filters.exchange != null && ipo.exchange != filters.exchange) return false;
    if (filters.listingYear != null && ipo.listingDate.year != filters.listingYear) {
      return false;
    }
    final q = filters.query.trim().toUpperCase();
    if (q.isNotEmpty) {
      final haystack =
          '${ipo.symbol} ${ipo.companyName} ${ipo.sector}'.toUpperCase();
      if (!haystack.contains(q)) return false;
    }
    return true; // level filter is applied after the band test
  }

  PriceBand _bandFor(
    Ipo ipo,
    double ltp,
    double diffHigh,
    bool nearHigh,
    bool nearLow,
    double proximityPct,
  ) {
    if (nearHigh) return PriceBand.nearHigh;
    if (nearLow) return PriceBand.nearLow;
    if (ltp > ipo.listingHigh) return PriceBand.aboveRange;
    if (ltp < ipo.listingLow) return PriceBand.belowRange;
    return PriceBand.insideRange;
  }

  void _sort(List<IpoMatch> matches, IpoSortMode mode) {
    switch (mode) {
      case IpoSortMode.closest:
        matches.sort((a, b) {
          final byLevel = a.level.index.compareTo(b.level.index); // High first
          if (byLevel != 0) return byLevel;
          return a.distancePct.compareTo(b.distancePct);
        });
      case IpoSortMode.symbol:
        matches.sort((a, b) => a.ipo.symbol.compareTo(b.ipo.symbol));
      case IpoSortMode.newestListing:
        matches.sort((a, b) => b.ipo.listingDate.compareTo(a.ipo.listingDate));
      case IpoSortMode.biggestDayMove:
        matches.sort((a, b) =>
            (b.changePct ?? double.negativeInfinity)
                .compareTo(a.changePct ?? double.negativeInfinity));
    }
  }

  /// Level filter applied post-match (used by the UI toggle chips).
  static List<IpoMatch> applyLevelFilter(
    List<IpoMatch> matches,
    Set<LevelType> levels,
  ) =>
      levels.isEmpty
          ? matches
          : matches.where((m) => levels.contains(m.level)).toList(growable: false);

  /// Distinct listing years, newest first — populates the year filter chip row.
  static List<int> availableYears(List<Ipo> ipos) {
    final years = ipos.map((e) => e.listingDate.year).toSet().toList()..sort((a, b) => b - a);
    return years;
  }
}
