// ---------------------------------------------------------------------------
// ipo_form_sheet.dart — add / edit one IPO row.
//
// Validation comes from `Ipo.validate()` so the same rules apply here, in the CSV
// importer and in the database layer.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../core/utils/formatters.dart';
import '../../../core/utils/markets.dart';
import '../../../data/local/models/ipo.dart';
import '../ipo_screener_provider.dart';

Future<bool> showIpoFormSheet({
  required BuildContext context,
  required IpoScreenerProvider provider,
  Ipo? existing,
}) async {
  final saved = await showModalBottomSheet<bool>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (_) => _IpoFormSheet(provider: provider, existing: existing),
  );
  return saved ?? false;
}

class _IpoFormSheet extends StatefulWidget {
  const _IpoFormSheet({required this.provider, this.existing});

  final IpoScreenerProvider provider;
  final Ipo? existing;

  @override
  State<_IpoFormSheet> createState() => _IpoFormSheetState();
}

class _IpoFormSheetState extends State<_IpoFormSheet> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController _symbol;
  late final TextEditingController _company;
  late final TextEditingController _high;
  late final TextEditingController _low;
  late final TextEditingController _sector;
  late final TextEditingController _notes;

  late Exchange _exchange;
  late DateTime _listingDate;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    final ipo = widget.existing;
    _symbol = TextEditingController(text: ipo?.symbol ?? '');
    _company = TextEditingController(text: ipo?.companyName ?? '');
    _high = TextEditingController(
      text: ipo == null ? '' : ipo.listingHigh.toStringAsFixed(2),
    );
    _low = TextEditingController(
      text: ipo == null ? '' : ipo.listingLow.toStringAsFixed(2),
    );
    _sector = TextEditingController(text: ipo?.sector ?? '');
    _notes = TextEditingController(text: ipo?.notes ?? '');
    _exchange = ipo?.exchange ?? Exchange.nse;
    _listingDate = ipo?.listingDate ?? DateTime.now();
  }

  @override
  void dispose() {
    _symbol.dispose();
    _company.dispose();
    _high.dispose();
    _low.dispose();
    _sector.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _listingDate,
      firstDate: DateTime(2015, 1, 1),
      lastDate: DateTime.now(),
      helpText: 'Listing date',
    );
    if (picked != null) setState(() => _listingDate = picked);
  }

  Future<void> _save() async {
    FocusScope.of(context).unfocus();
    if (!(_formKey.currentState?.validate() ?? false)) return;

    final ipo = Ipo(
      id: widget.existing?.id,
      symbol: _symbol.text.trim().toUpperCase(),
      companyName: _company.text.trim(),
      exchange: _exchange,
      listingDate: _listingDate,
      listingHigh: double.tryParse(_high.text.trim()) ?? 0,
      listingLow: double.tryParse(_low.text.trim()) ?? 0,
      sector: _sector.text.trim(),
      notes: _notes.text.trim(),
      // Rows typed by hand are marked so "restore sample data" keeps them.
      isCustom: true,
      // The numbers came from the user, so the background level fetcher must
      // never touch them.
      levelsSource: 'user',
    );

    final errors = ipo.validate();
    if (errors.isNotEmpty) {
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Please fix these'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: errors
                .map((e) => Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Text('• $e'),
                    ))
                .toList(),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('OK'),
            ),
          ],
        ),
      );
      return;
    }

    setState(() => _busy = true);
    await widget.provider.saveIpo(ipo);
    if (!mounted) return;
    Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existing != null;

    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                isEdit ? 'Edit IPO' : 'Add IPO',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
              ),
              const SizedBox(height: 4),
              Text(
                'Listing-day high and low are what the screener compares the '
                'live price against.',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 18),
              TextFormField(
                controller: _symbol,
                textCapitalization: TextCapitalization.characters,
                decoration: const InputDecoration(
                  labelText: 'Symbol',
                  hintText: 'e.g. NYKAA (without -EQ)',
                  prefixIcon: Icon(Icons.tag),
                ),
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Symbol is required' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _company,
                textCapitalization: TextCapitalization.words,
                decoration: const InputDecoration(
                  labelText: 'Company name',
                  hintText: 'e.g. FSN E-Commerce Ventures Ltd',
                  prefixIcon: Icon(Icons.business_outlined),
                ),
                validator: (v) => (v == null || v.trim().isEmpty)
                    ? 'Company name is required'
                    : null,
              ),
              const SizedBox(height: 12),
              SegmentedButton<Exchange>(
                segments: const [
                  ButtonSegment(value: Exchange.nse, label: Text('NSE')),
                  ButtonSegment(value: Exchange.bse, label: Text('BSE')),
                ],
                selected: {_exchange},
                onSelectionChanged: (value) =>
                    setState(() => _exchange = value.first),
              ),
              const SizedBox(height: 12),
              InkWell(
                onTap: _pickDate,
                borderRadius: BorderRadius.circular(12),
                child: InputDecorator(
                  decoration: const InputDecoration(
                    labelText: 'Listing date',
                    prefixIcon: Icon(Icons.event_outlined),
                  ),
                  child: Text(Fmt.date(_listingDate)),
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _high,
                      keyboardType:
                          const TextInputType.numberWithOptions(decimal: true),
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(RegExp(r'[0-9.]')),
                      ],
                      decoration: const InputDecoration(
                        labelText: 'Listing high',
                        prefixText: '₹ ',
                      ),
                      validator: _validatePrice,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextFormField(
                      controller: _low,
                      keyboardType:
                          const TextInputType.numberWithOptions(decimal: true),
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(RegExp(r'[0-9.]')),
                      ],
                      decoration: const InputDecoration(
                        labelText: 'Listing low',
                        prefixText: '₹ ',
                      ),
                      validator: _validatePrice,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _sector,
                textCapitalization: TextCapitalization.words,
                decoration: const InputDecoration(
                  labelText: 'Sector (optional)',
                  prefixIcon: Icon(Icons.category_outlined),
                ),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _notes,
                maxLines: 2,
                decoration: const InputDecoration(
                  labelText: 'Notes (optional)',
                  prefixIcon: Icon(Icons.notes),
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _busy ? null : () => Navigator.of(context).pop(),
                      child: const Text('Cancel'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: _busy ? null : _save,
                      icon: _busy
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.check),
                      label: Text(isEdit ? 'Save changes' : 'Add IPO'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  String? _validatePrice(String? value) {
    final parsed = double.tryParse((value ?? '').trim());
    if (parsed == null || parsed <= 0) return 'Enter a price';
    return null;
  }
}
