// ---------------------------------------------------------------------------
// ipo_filter_sheet.dart — the screener's filter sheet.
//
// Communicates *only* through the provider, so the list updates the moment a
// chip is tapped (no network call — the last price map is reused).
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';

import '../../../core/utils/markets.dart';
import '../../settings/settings_provider.dart';
import '../ipo_screener_engine.dart';
import '../ipo_screener_provider.dart';

Future<void> showIpoFilterSheet({
  required BuildContext context,
  required IpoScreenerProvider provider,
  required SettingsProvider settings,
}) {
  return showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (_) => _IpoFilterSheet(provider: provider, settings: settings),
  );
}

class _IpoFilterSheet extends StatefulWidget {
  const _IpoFilterSheet({required this.provider, required this.settings});

  final IpoScreenerProvider provider;
  final SettingsProvider settings;

  @override
  State<_IpoFilterSheet> createState() => _IpoFilterSheetState();
}

class _IpoFilterSheetState extends State<_IpoFilterSheet> {
  @override
  Widget build(BuildContext context) {
    final provider = widget.provider;
    final filters = provider.filters;
    final years = provider.availableYears;
    final band = widget.settings.settings.proximityPct.toDouble();
    final scheme = Theme.of(context).colorScheme;

    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Filters',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
            const SizedBox(height: 4),
            Text(
              'Screening ${provider.totalRows} IPO rows · '
              '${provider.result.pricedCount} priced',
              style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant),
            ),
            const SizedBox(height: 20),

            // ---- Level ---------------------------------------------------
            _Label('Level to watch'),
            Wrap(
              spacing: 8,
              children: [
                FilterChip(
                  label: const Text('Near high'),
                  selected: filters.levels.contains(LevelType.high),
                  onSelected: (_) {
                    provider.toggleLevel(LevelType.high);
                    setState(() {});
                  },
                ),
                FilterChip(
                  label: const Text('Near low'),
                  selected: filters.levels.contains(LevelType.low),
                  onSelected: (_) {
                    provider.toggleLevel(LevelType.low);
                    setState(() {});
                  },
                ),
                ActionChip(
                  label: const Text('Both'),
                  onPressed: () {
                    provider.setFilters(filters.copyWith(levels: const {}));
                    setState(() {});
                  },
                ),
              ],
            ),
            const SizedBox(height: 18),

            // ---- Exchange ------------------------------------------------
            _Label('Exchange'),
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'ALL', label: Text('All')),
                ButtonSegment(value: 'NSE', label: Text('NSE')),
                ButtonSegment(value: 'BSE', label: Text('BSE')),
              ],
              selected: {filters.exchange?.code ?? 'ALL'},
              onSelectionChanged: (value) {
                final code = value.first;
                provider.setExchange(code == 'ALL' ? null : Exchange.fromCode(code));
                setState(() {});
              },
            ),
            const SizedBox(height: 18),

            // ---- Listing year --------------------------------------------
            _Label('Listing year'),
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: [
                ChoiceChip(
                  label: const Text('All'),
                  selected: filters.listingYear == null,
                  onSelected: (_) {
                    provider.setListingYear(null);
                    setState(() {});
                  },
                ),
                ...years.map(
                  (year) => ChoiceChip(
                    label: Text('$year'),
                    selected: filters.listingYear == year,
                    onSelected: (_) {
                      provider.setListingYear(year);
                      setState(() {});
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),

            // ---- Proximity band -----------------------------------------
            _Label('Proximity band (± from listing high/low)'),
            Row(
              children: [
                Expanded(
                  child: Slider(
                    value: band.clamp(0.5, 10),
                    min: 0.5,
                    max: 10,
                    divisions: 19,
                    label: '${band.toStringAsFixed(1)}%',
                    onChanged: (value) async {
                      await widget.settings.setProximityPct(value.round());
                      provider.reapplyConfig();
                      setState(() {});
                    },
                  ),
                ),
                SizedBox(
                  width: 56,
                  child: Text(
                    '±${band.toStringAsFixed(1)}%',
                    textAlign: TextAlign.end,
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
            Text(
              'Spec default is ±3%. A stock is listed when its live price is '
              'within this band of the listing-day high or low.',
              style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
            ),
            const SizedBox(height: 18),

            // ---- Sort ----------------------------------------------------
            // Plain tappable tiles instead of RadioListTile: the Radio API is
            // mid-migration (RadioGroup in Flutter 3.32+), and this has no
            // version-specific surface at all.
            _Label('Sort by'),
            ...IpoSortMode.values.map(
              (mode) => ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                title: Text(mode.label, style: const TextStyle(fontSize: 14)),
                trailing: provider.sortMode == mode
                    ? Icon(Icons.check_circle, size: 20, color: scheme.primary)
                    : const Icon(Icons.circle_outlined, size: 20),
                onTap: () {
                  provider.setSortMode(mode);
                  setState(() {});
                },
              ),
            ),
            const SizedBox(height: 12),

            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      provider.clearFilters();
                      setState(() {});
                    },
                    icon: const Icon(Icons.filter_alt_off_outlined, size: 18),
                    label: const Text('Reset filters'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FilledButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: Text('Show ${provider.matches.length} results'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _Label extends StatelessWidget {
  const _Label(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        text,
        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
      ),
    );
  }
}
