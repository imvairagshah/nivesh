// ---------------------------------------------------------------------------
// ipo_database_screen.dart — manage the local IPO database (Feature 1).
//
//   • search + browse every row
//   • add / edit / delete (swipe or long-press)
//   • import a CSV (file picker) — same columns as assets/data/ipos.csv
//   • export the whole table back to CSV (copied to the clipboard)
//   • restore the bundled 2015-onwards list without losing hand-added rows
// ---------------------------------------------------------------------------

import 'dart:convert';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../../core/utils/formatters.dart';
import '../../../core/widgets/page_scroll.dart';
import '../../../data/local/dao/ipo_dao.dart';
import '../../../data/local/models/ipo.dart';
import '../ipo_screener_provider.dart';
import 'ipo_form_sheet.dart';

class IpoDatabaseScreen extends StatefulWidget {
  const IpoDatabaseScreen({super.key});

  @override
  State<IpoDatabaseScreen> createState() => _IpoDatabaseScreenState();
}

class _IpoDatabaseScreenState extends State<IpoDatabaseScreen> {
  final _searchController = TextEditingController();
  List<Ipo> _rows = const [];
  bool _loading = true;
  String _query = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _reload());
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _reload() async {
    final provider = context.read<IpoScreenerProvider>();
    setState(() => _loading = true);
    final rows = await provider.allRows();
    if (!mounted) return;
    setState(() {
      _rows = rows;
      _loading = false;
    });
  }

  List<Ipo> get _visible {
    if (_query.trim().isEmpty) return _rows;
    final q = _query.trim().toUpperCase();
    return _rows
        .where(
          (r) =>
              r.symbol.contains(q) ||
              r.companyName.toUpperCase().contains(q) ||
              r.sector.toUpperCase().contains(q),
        )
        .toList(growable: false);
  }

  // -------------------------------------------------------------------------
  // Actions
  // -------------------------------------------------------------------------

  Future<void> _importCsv() async {
    final provider = context.read<IpoScreenerProvider>();
    try {
      // file_picker 13: `pickFiles` is static and returns the picked files
      // directly (empty list = user cancelled); bytes are read from the file
      // object rather than requested up front via `withData`.
      final picked = await FilePicker.pickFiles(
        dialogTitle: 'Select an IPO CSV',
        type: FileType.custom,
        allowedExtensions: const ['csv', 'txt'],
      );
      if (picked.isEmpty) return;

      final file = picked.single;
      final bytes = await file.readAsBytes();
      if (bytes.isEmpty) {
        _snack('That file is empty.');
        return;
      }
      final text = utf8.decode(bytes, allowMalformed: true);
      final report = await provider.importCsvText(text);
      await _reload();
      if (!mounted) return;
      _showReport(report);
    } catch (e) {
      _snack('Import failed: $e');
    }
  }

  Future<void> _exportCsv() async {
    final provider = context.read<IpoScreenerProvider>();
    final csv = await provider.exportCsv();
    await Clipboard.setData(ClipboardData(text: csv));
    if (!mounted) return;
    _snack('${_rows.length} rows copied to the clipboard as CSV.');
  }

  Future<void> _restoreSample() async {
    final provider = context.read<IpoScreenerProvider>();
    final confirmed = await _confirm(
      title: 'Restore sample data?',
      message:
          'The bundled 2015-onwards IPO list is re-added. Rows you created '
          'or edited yourself are kept.',
      confirmLabel: 'Restore',
    );
    if (!confirmed) return;
    final report = await provider.seedFromAsset(overwrite: false);
    await _reload();
    if (!mounted) return;
    _showReport(report);
  }

  Future<void> _deleteAll() async {
    final provider = context.read<IpoScreenerProvider>();
    final confirmed = await _confirm(
      title: 'Delete every IPO row?',
      message:
          'This clears the whole local database, including rows you added. '
          'You can restore the bundled sample afterwards.',
      confirmLabel: 'Delete all',
      destructive: true,
    );
    if (!confirmed) return;
    await provider.resetDatabase(keepUserAdded: false);
    await _reload();
    if (!mounted) return;
    _snack('Database cleared.');
  }

  Future<void> _deleteRow(Ipo ipo) async {
    final provider = context.read<IpoScreenerProvider>();
    await provider.deleteIpo(ipo);
    await _reload();
    if (!mounted) return;
    _snack('${ipo.symbol} deleted.');
  }

  Future<void> _edit(Ipo ipo) async {
    final provider = context.read<IpoScreenerProvider>();
    final saved = await showIpoFormSheet(
      context: context,
      provider: provider,
      existing: ipo,
    );
    if (saved) await _reload();
  }

  Future<void> _add() async {
    final provider = context.read<IpoScreenerProvider>();
    final saved = await showIpoFormSheet(context: context, provider: provider);
    if (saved) await _reload();
  }

  // -------------------------------------------------------------------------
  // UI
  // -------------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    final rows = _visible;

    return Scaffold(
      appBar: AppBar(
        title: Text('IPO database (${_rows.length})'),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) {
              switch (value) {
                case 'import':
                  _importCsv();
                case 'export':
                  _exportCsv();
                case 'restore':
                  _restoreSample();
                case 'clear':
                  _deleteAll();
              }
            },
            itemBuilder: (context) => const [
              PopupMenuItem(
                value: 'import',
                child: ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(Icons.upload_file_outlined),
                  title: Text('Import CSV'),
                ),
              ),
              PopupMenuItem(
                value: 'export',
                child: ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(Icons.content_copy_outlined),
                  title: Text('Copy as CSV'),
                ),
              ),
              PopupMenuItem(
                value: 'restore',
                child: ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(Icons.restore),
                  title: Text('Restore sample data'),
                ),
              ),
              PopupMenuItem(
                value: 'clear',
                child: ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(Icons.delete_sweep_outlined),
                  title: Text('Delete all rows'),
                ),
              ),
            ],
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _add,
        icon: const Icon(Icons.add),
        label: const Text('Add IPO'),
      ),
      // 1.5.92 — PC fix: ek hi scroll (search + rows saath chalte hain).
      body: PageScroll.builder(
        padding: const EdgeInsets.fromLTRB(12, 6, 12, 96),
        itemCount: _loading || rows.isEmpty ? 0 : rows.length,
        header: [
          Padding(
            padding: const EdgeInsets.fromLTRB(0, 6, 0, 6),
            child: TextField(
              controller: _searchController,
              onChanged: (value) => setState(() => _query = value),
              decoration: InputDecoration(
                hintText: 'Search ${_rows.length} rows',
                prefixIcon: const Icon(Icons.search, size: 20),
                suffixIcon: _query.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.clear, size: 18),
                        onPressed: () {
                          _searchController.clear();
                          setState(() => _query = '');
                        },
                      ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Icon(
                  Icons.info_outline,
                  size: 14,
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    'Swipe a row left to delete · tap to edit. Columns must match '
                    'the sample CSV.',
                    style: TextStyle(
                      fontSize: 11,
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 6),
          if (_loading)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 48),
              child: Center(child: CircularProgressIndicator()),
            )
          else if (rows.isEmpty)
            _empty(context),
        ],
        itemBuilder: (context, index) {
          final ipo = rows[index];
          return Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Dismissible(
              key: ValueKey('${ipo.id}-${ipo.symbol}'),
              direction: DismissDirection.endToStart,
              background: Container(
                alignment: Alignment.centerRight,
                padding: const EdgeInsets.only(right: 20),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.errorContainer,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Icon(Icons.delete_outline),
              ),
              confirmDismiss: (_) => _confirm(
                title: 'Delete ${ipo.symbol}?',
                message:
                    '${ipo.companyName} will be removed from the '
                    'local database.',
                confirmLabel: 'Delete',
                destructive: true,
              ),
              onDismissed: (_) => _deleteRow(ipo),
              child: _IpoRow(ipo: ipo, onTap: () => _edit(ipo)),
            ),
          );
        },
      ),
    );
  }

  Widget _empty(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.inbox_outlined, size: 40),
          const SizedBox(height: 12),
          Text(
            _query.isEmpty ? 'No IPO rows yet' : 'Nothing matches "$_query"',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 8),
          const Text(
            'Restore the bundled list or import your own CSV from the menu.',
            textAlign: TextAlign.center,
          ),
        ],
      ),
    ),
  );

  // -------------------------------------------------------------------------
  // Helpers
  // -------------------------------------------------------------------------

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  void _showReport(IpoImportReport report) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Import finished'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(report.summary),
            if (report.errors.isNotEmpty) ...[
              const SizedBox(height: 12),
              const Text(
                'Rows that were skipped:',
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 6),
              ...report.errors
                  .take(8)
                  .map(
                    (e) => Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: Text(e, style: const TextStyle(fontSize: 12)),
                    ),
                  ),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  Future<bool> _confirm({
    required String title,
    required String message,
    required String confirmLabel,
    bool destructive = false,
  }) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: destructive
                ? FilledButton.styleFrom(
                    backgroundColor: Theme.of(dialogContext).colorScheme.error,
                  )
                : null,
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: Text(confirmLabel),
          ),
        ],
      ),
    );
    return result ?? false;
  }
}

class _IpoRow extends StatelessWidget {
  const _IpoRow({required this.ipo, required this.onTap});

  final Ipo ipo;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 12, 12),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          ipo.symbol,
                          style: const TextStyle(fontWeight: FontWeight.w700),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          ipo.exchange.code,
                          style: TextStyle(
                            fontSize: 10,
                            color: scheme.onSurfaceVariant,
                          ),
                        ),
                        if (ipo.isCustom) ...[
                          const SizedBox(width: 6),
                          Icon(
                            Icons.edit_note,
                            size: 14,
                            color: scheme.primary,
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      ipo.companyName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 12,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${Fmt.dateShort(ipo.listingDate)} · H ${Fmt.price(ipo.listingHigh)}'
                      ' · L ${Fmt.price(ipo.listingLow)}',
                      style: TextStyle(
                        fontSize: 11,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, size: 20),
            ],
          ),
        ),
      ),
    );
  }
}
