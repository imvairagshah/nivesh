// ---------------------------------------------------------------------------
// ipo_match_card.dart — one compact table row (1.5.60 redesign).
//
// The old big card is now a single fixed-width table row (the screen puts the
// header and all rows in one horizontal scroller, like the AI Jodi table):
// symbol · price · Near High/Low badge · listing levels · mini range bar ·
// actions. Every detail is kept — the row tap opens the same detail sheet the
// card used to open, and the Near High/Near Low badge is a click link that
// opens that very sheet too.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/utils/link_opener.dart';
import '../../../core/utils/markets.dart';
import '../ipo_screener_engine.dart';

/// The table's total width — header and every row use this.
const double kIpoRowWidth =
    _wSymbol + _wLtp + _wLevel + _wListed + _wHigh + _wLow + _wRange + _wActions;

const double _wSymbol = 132;
const double _wLtp = 96;
const double _wLevel = 156;
const double _wListed = 84;
const double _wHigh = 84;
const double _wLow = 84;
const double _wRange = 92;
const double _wActions = 152;

/// One table row. [onTap] opens the detail sheet — the same one the card used
/// to open (1.5.60: "same ae rite j open thay").
class IpoMatchCard extends StatelessWidget {
  const IpoMatchCard({super.key, required this.match, this.onTap});

  final IpoMatch match;

  /// Opens the detail sheet (optional).
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final market = MarketColors.of(context);
    final scheme = Theme.of(context).colorScheme;
    final isNearHigh = match.level == LevelType.high;
    final levelColor = isNearHigh ? market.nearHigh : market.nearLow;

    return SizedBox(
      width: kIpoRowWidth,
      height: 62,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 7),
            child: Row(
              children: [
                // ---- Symbol · exchange · company -------------------------
                _cell(
                  _wSymbol,
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child: Text(
                              match.ipo.symbol,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 12.5,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                          if (match.ipo.isCustom) ...[
                            const SizedBox(width: 3),
                            Icon(
                              Icons.edit_note,
                              size: 12,
                              color: scheme.onSurfaceVariant,
                            ),
                          ],
                        ],
                      ),
                      const SizedBox(height: 1),
                      Text(
                        match.ipo.companyName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 9,
                          color: scheme.onSurfaceVariant,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Row(
                        children: [
                          _Tag(
                            text: match.exchange.code,
                            color: scheme.onSurfaceVariant,
                          ),
                          if (match.isStale) ...[
                            const SizedBox(width: 4),
                            _Tag(text: 'cached', color: market.stale),
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
                // ---- Price + day change ---------------------------------
                _cell(
                  _wLtp,
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        Fmt.money(match.ltp),
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      if (match.changePct != null)
                        Text(
                          Fmt.signedPct(match.changePct),
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                            color: market.forValue(match.changePct),
                          ),
                        ),
                    ],
                  ),
                ),
                // ---- Near High / Near Low — the click link in the row ----
                // Distance moves to its own line (1.5.61) — level upar,
                // "kitna dur" neeche.
                _cell(
                  _wLevel,
                  GestureDetector(
                    // Same detail sheet as the row tap — a link, not a filter.
                    onTap: onTap,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: levelColor.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(10),
                        border:
                            Border.all(color: levelColor.withOpacity(0.35)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Row(
                            children: [
                              Icon(
                                isNearHigh
                                    ? Icons.vertical_align_top
                                    : Icons.vertical_align_bottom,
                                size: 11,
                                color: levelColor,
                              ),
                              const SizedBox(width: 3),
                              Flexible(
                                child: Text(
                                  match.level.label,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w800,
                                    color: levelColor,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 1),
                          Text(
                            '${match.distancePct.toStringAsFixed(2)}% '
                            '${match.diffPct >= 0 ? 'above' : 'below'}',
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 9.5,
                              fontWeight: FontWeight.w600,
                              color: levelColor.withOpacity(0.9),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                // Listing levels — labels sirf column header me (1.5.61).
                _cell(
                  _wListed,
                  _value(Fmt.dateShort(match.ipo.listingDate)),
                ),
                _cell(
                  _wHigh,
                  _value(Fmt.price(match.ipo.listingHigh)),
                ),
                _cell(
                  _wLow,
                  _value(Fmt.price(match.ipo.listingLow)),
                ),
                // ---- Actions --------------------------------------------
                _cell(
                  _wActions,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      IconButton(
                        visualDensity: VisualDensity.compact,
                        constraints: const BoxConstraints(),
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        tooltip: 'Copy symbol',
                        icon: const Icon(Icons.copy_all_outlined, size: 15),
                        onPressed: () {
                          // Kept dependency-free: shown in a snackbar.
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                '${match.tradingViewSymbol} — '
                                '₹${Fmt.price(match.ltp)}',
                              ),
                            ),
                          );
                        },
                      ),
                      FilledButton.tonalIcon(
                        onPressed: () => LinkOpener.open(match.tradingViewUrl,
                            context: context),
                        icon: const Icon(Icons.show_chart, size: 14),
                        label: const Text('Chart'),
                        style: FilledButton.styleFrom(
                          visualDensity: VisualDensity.compact,
                          minimumSize: const Size(0, 30),
                          padding: const EdgeInsets.symmetric(horizontal: 7),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// A listing value — bold number only (labels live in the header).
  Widget _value(String value) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            value,
            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
          ),
        ],
      );
}

/// Fixed-width table cell — content vertically centered.
Widget _cell(double width, Widget child) => SizedBox(
      width: width,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 3),
        child: child,
      ),
    );

/// The table header — one shared horizontal scroller holds this and the rows,
/// so the columns never misalign (same pattern as the AI Jodi table).
class IpoTableHeader extends StatelessWidget {
  const IpoTableHeader({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final style = TextStyle(
      fontSize: 10,
      fontWeight: FontWeight.w800,
      letterSpacing: 0.3,
      color: scheme.onSurfaceVariant,
    );
    return Container(
      color: scheme.surfaceContainerHighest.withOpacity(0.45),
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
      child: Row(
        children: [
          _cell(_wSymbol, Text('Stock', style: style)),
          _cell(_wLtp,
              Text('Price', style: style, textAlign: TextAlign.right)),
          _cell(_wLevel, Text('Near High/Low', style: style)),
          _cell(_wListed, Text('Listed', style: style)),
          _cell(_wHigh, Text('High', style: style)),
          _cell(_wLow, Text('Low', style: style)),
          _cell(_wActions,
              Text('Actions', style: style, textAlign: TextAlign.right)),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Small building blocks
// ---------------------------------------------------------------------------

class _Tag extends StatelessWidget {
  const _Tag({required this.text, required this.color});

  final String text;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 8.5,
          fontWeight: FontWeight.w700,
          color: color,
        ),
      ),
    );
  }
}
