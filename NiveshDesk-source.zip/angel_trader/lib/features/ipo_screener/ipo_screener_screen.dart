// ---------------------------------------------------------------------------
// ipo_screener_screen.dart — Feature 1: IPO High/Low proximity screener.
//
// Screen anatomy:
//   • toolbar   — search, filter sheet, sort menu, manual refresh
//   • status    — live/cached banner, counters (matches, near high, near low)
//   • quick chips — All / Near High / Near Low · exchange · listing year
//   • list      — pull-to-refresh cards (Near High first, closest first)
//   • footer    — rows that could not be screened (with the reason) and a link
//                 into the IPO database manager
// ---------------------------------------------------------------------------

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../core/widgets/motion.dart';
import '../../core/widgets/page_scroll.dart';
import '../../core/utils/link_opener.dart';
import '../../core/utils/markets.dart';
import '../../services/auth_service.dart';
import '../auth/login_screen.dart';
import '../settings/settings_provider.dart';
import 'ipo_screener_engine.dart';
import 'ipo_screener_provider.dart';
import 'widgets/ipo_database_screen.dart';
import 'widgets/ipo_filter_sheet.dart';
import 'widgets/ipo_form_sheet.dart';
import 'widgets/ipo_match_card.dart';

class IpoScreenerScreen extends StatefulWidget {
  const IpoScreenerScreen({super.key});

  @override
  State<IpoScreenerScreen> createState() => _IpoScreenerScreenState();
}

class _IpoScreenerScreenState extends State<IpoScreenerScreen> {
  final _searchController = TextEditingController();
  Timer? _autoRefresh;
  bool _bootstrapped = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _bootstrap());
  }

  Future<void> _bootstrap() async {
    if (_bootstrapped || !mounted) return;
    _bootstrapped = true;

    final screener = context.read<IpoScreenerProvider>();
    await screener.bootstrap();
    if (!mounted) return;
    _scheduleAutoRefresh();
  }

  /// Periodic background refresh — only while the market is open and only when a
  /// session exists, so the app never burns SmartAPI quota on a closed market.
  void _scheduleAutoRefresh() {
    _autoRefresh?.cancel();
    final seconds = context.read<SettingsProvider>().settings.autoRefreshSeconds;
    _autoRefresh = Timer.periodic(Duration(seconds: seconds), (_) {
      if (!mounted) return;
      final screener = context.read<IpoScreenerProvider>();
      final auth = context.read<AuthService>();
      if (screener.isRefreshing || !auth.isLoggedIn) return;
      if (!MarketCalendar.isMarketOpen()) return;
      screener.refresh(silent: true);
    });
  }

  @override
  void dispose() {
    _autoRefresh?.cancel();
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screener = context.watch<IpoScreenerProvider>();
    final isFirstLoad = screener.phase == ScreenerPhase.loading && !screener.hasData;

    // 1.5.92 — PC fix: POORI page ke liye ek hi scroll (height auto).
    // Pehle: fixed toolbar + andar ka Expanded(ListView) → do scroll areas,
    // isliye mouse-wheel/drag confusing tha. Ab header + table + footer sab
    // ek hi vertical scroll me hain.
    return PageScroll.children(
      onRefresh: () => screener.refresh(force: true),
      [
        _Toolbar(
          controller: _searchController,
          onSearchChanged: screener.setQuery,
          onFilterTap: () => showIpoFilterSheet(
            context: context,
            provider: screener,
            settings: context.read<SettingsProvider>(),
          ),
          onManageTap: () => Navigator.of(context).push(
            MaterialPageRoute<void>(builder: (_) => const IpoDatabaseScreen()),
          ),
        ),
        if (screener.notice != null && !isFirstLoad)
          _NoticeBanner(provider: screener)
        else if (screener.error != null && !isFirstLoad)
          _ErrorBanner(
            message: screener.error!,
            onRetry: () => screener.refresh(force: true),
            onDismiss: screener.clearError,
          ),
        if (screener.isOffline && screener.hasData) const _OfflineBanner(),
        _DiscoveryBanner(provider: screener),
        _ScanBar(provider: screener),
        _QuickChips(provider: screener),
        _SummaryStrip(provider: screener),
        const SizedBox(height: 8),
        if (isFirstLoad)
          const _LoadingState()
        else if (screener.matches.isEmpty)
          _EmptyState(provider: screener)
        else
          // Table ka apna sirf **horizontal** scroll (narrow window ke liye) —
          // vertical scroll page ka hi hai, isliye sab kuch ek saath chalta hai.
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: SizedBox(
              width: kIpoRowWidth,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const IpoTableHeader(),
                  const Divider(height: 1),
                  for (var i = 0; i < screener.matches.length; i++) ...[
                    FadeSlideIn(
                      index: i,
                      child: IpoMatchCard(
                        match: screener.matches[i],
                        onTap: () => _showDetail(context, screener.matches[i]),
                      ),
                    ),
                    const Divider(height: 1),
                  ],
                ],
              ),
            ),
          ),
        if (!isFirstLoad && screener.matches.isNotEmpty)
          _ListFooter(provider: screener),
        const SizedBox(height: 12),
      ],
    );
  }

  /// Detail sheet with the exact numbers behind the card.
  void _showDetail(BuildContext context, IpoMatch match) {
    final market = MarketColors.of(context);
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${match.exchange.code}:${match.ipo.symbol}',
              style: Theme.of(sheetContext)
                  .textTheme
                  .titleLarge
                  ?.copyWith(fontWeight: FontWeight.w700),
            ),
            Text(match.ipo.companyName),
            const SizedBox(height: 16),
            _DetailRow('Current price', Fmt.money(match.ltp)),
            _DetailRow('Day change', Fmt.signedPct(match.changePct)),
            _DetailRow('Listing date', Fmt.date(match.ipo.listingDate)),
            _DetailRow('Listing high', Fmt.money(match.ipo.listingHigh)),
            _DetailRow('Listing low', Fmt.money(match.ipo.listingLow)),
            _DetailRow('Listing range', Fmt.money(match.ipo.listingRange)),
            _DetailRow(
              'Vs listing high',
              Fmt.signedPct(match.ipo.distanceFromHigh(match.ltp)),
              color: market.forValue(match.ipo.distanceFromHigh(match.ltp)),
            ),
            _DetailRow(
              'Vs listing low',
              Fmt.signedPct(match.ipo.distanceFromLow(match.ltp)),
              color: market.forValue(match.ipo.distanceFromLow(match.ltp)),
            ),
            _DetailRow('Closest level', match.level.label),
            _DetailRow('Distance', Fmt.pct(match.distancePct)),
            _DetailRow('Instrument token', match.token ?? '—'),
            _DetailRow('Price as of', Fmt.dateTime(match.pricedAt)),
            if (match.ipo.notes.isNotEmpty) _DetailRow('Notes', match.ipo.notes),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => Navigator.of(sheetContext).pop(),
                    icon: const Icon(Icons.close, size: 18),
                    label: const Text('Close'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: FilledButton.icon(
                    onPressed: () =>
                        LinkOpener.open(match.tradingViewUrl, context: context),
                    icon: const Icon(Icons.show_chart, size: 18),
                    label: const Text('Open chart'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Toolbar
// ---------------------------------------------------------------------------

class _Toolbar extends StatelessWidget {
  const _Toolbar({
    required this.controller,
    required this.onSearchChanged,
    required this.onFilterTap,
    required this.onManageTap,
  });

  final TextEditingController controller;
  final ValueChanged<String> onSearchChanged;
  final VoidCallback onFilterTap;
  final VoidCallback onManageTap;

  @override
  Widget build(BuildContext context) {
    final screener = context.watch<IpoScreenerProvider>();

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 10, 8, 4),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: controller,
              onChanged: onSearchChanged,
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                hintText: 'Search symbol, company or sector',
                prefixIcon: const Icon(Icons.search, size: 20),
                suffixIcon: controller.text.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.clear, size: 18),
                        onPressed: () {
                          controller.clear();
                          onSearchChanged('');
                        },
                      ),
              ),
            ),
          ),
          IconButton(
            tooltip: 'Filters',
            icon: Badge(
              isLabelVisible: screener.filters.isActive,
              child: const Icon(Icons.tune),
            ),
            onPressed: onFilterTap,
          ),
          PopupMenuButton<IpoSortMode>(
            tooltip: 'Sort',
            icon: const Icon(Icons.sort),
            initialValue: screener.sortMode,
            onSelected: screener.setSortMode,
            itemBuilder: (context) => IpoSortMode.values
                .map(
                  (mode) => PopupMenuItem<IpoSortMode>(
                    value: mode,
                    child: Text(mode.label),
                  ),
                )
                .toList(),
          ),
          IconButton(
            tooltip: screener.isRefreshing ? 'Refreshing…' : 'Refresh prices',
            icon: screener.isRefreshing
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.refresh),
            onPressed: screener.isRefreshing
                ? null
                : () => screener.refresh(force: true),
          ),
          IconButton(
            tooltip: 'IPO database',
            icon: const Icon(Icons.storage_outlined),
            onPressed: onManageTap,
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Scan affordance
// ---------------------------------------------------------------------------

/// Explicit "Scan now" button + progress line.
///
/// The scan runs by itself on open and on a timer while the market is live, but
/// a visible button means "did it start?" is never a question — and the line
/// underneath says when the last pass ran and whether the market is open.
class _ScanBar extends StatelessWidget {
  const _ScanBar({required this.provider});

  final IpoScreenerProvider provider;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final scanning = provider.isScanning;

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 6, 12, 0),
      child: Row(
        children: [
          FilledButton.tonalIcon(
            onPressed: scanning ? null : () => provider.refresh(force: true),
            icon: scanning
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.bolt, size: 18),
            label: Text(scanning ? 'Scanning…' : 'Scan now'),
          ),
          const SizedBox(width: 4),
          // Discovery runs on its own at launch; this is for the impatient day —
          // a fresh listing is worth one tap.
          IconButton(
            tooltip: 'Naye IPO check karo (Angel + NSE)',
            onPressed: provider.isDiscovering
                ? null
                : () => provider.discoverNewListings(force: true),
            icon: provider.isDiscovering
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.new_releases_outlined, size: 20),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  provider.scanSummary,
                  style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant),
                ),
                Text(
                  provider.marketClosed
                      ? 'Market closed · last traded prices'
                      : provider.statusLabel,
                  style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
                ),
                if (provider.attentionCount > 0) ...[
                  const SizedBox(height: 4),
                  InkWell(
                    onTap: () => showIpoAttentionSheet(
                      context: context,
                      provider: provider,
                    ),
                    borderRadius: BorderRadius.circular(6),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 2),
                      child: Row(
                        children: [
                          Icon(Icons.error_outline,
                              size: 13, color: scheme.error),
                          const SizedBox(width: 4),
                          Flexible(
                            child: Text(
                              provider.attentionLabel,
                              style: TextStyle(
                                fontSize: 10.5,
                                color: scheme.error,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          Icon(Icons.chevron_right, size: 14, color: scheme.error),
                        ],
                      ),
                    ),
                  ),
                ],
                if (!provider.levelsComplete) ...[
                  const SizedBox(height: 3),
                  SizedBox(
                    width: 180,
                    child: LinearProgressIndicator(
                      value: provider.isFetchingLevels
                          ? provider.levelsProgress
                          : null,
                      minHeight: 3,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(height: 2),
                  GestureDetector(
                    onTap: provider.isFetchingLevels
                        ? null
                        : () => provider.fetchListingLevels(all: true),
                    child: Text(
                      provider.isFetchingLevels
                          ? provider.levelsLabel
                          : '${provider.levelsLabel} · tap to fetch',
                      style: TextStyle(
                        fontSize: 10.5,
                        color: scheme.primary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ] else
                  Text(
                    'Listing levels ready for every IPO',
                    style: TextStyle(
                      fontSize: 10.5,
                      color: MarketColors.of(context).gain,
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}


// ---------------------------------------------------------------------------
// Banners
// ---------------------------------------------------------------------------

/// Turns a [ScreenerNotice] into something the user can act on.
/// "N naye IPO mile aur add ho gaye" — shown once after a discovery run that
/// actually added rows. Auto-added rows are never silent: the user sees which
/// symbols arrived (renames and demergers can look like new listings) and can
/// delete a wrong one from the IPO database screen.
class _DiscoveryBanner extends StatelessWidget {
  const _DiscoveryBanner({required this.provider});

  final IpoScreenerProvider provider;

  @override
  Widget build(BuildContext context) {
    final label = provider.discoveryLabel;
    if (label == null) return const SizedBox.shrink();

    final colors = MarketColors.of(context);
    final scheme = Theme.of(context).colorScheme;

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
      child: Container(
        padding: const EdgeInsets.fromLTRB(12, 10, 6, 10),
        decoration: BoxDecoration(
          color: colors.gain.withValues(alpha: 0.10),
          borderRadius: BorderRadius.circular(AppRadius.md),
          border: Border.all(color: colors.gain.withValues(alpha: 0.35)),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(Icons.auto_awesome, size: 18, color: colors.gain),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w600,
                      color: scheme.onSurface,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    'Scanner me shamil ho gaye. Galti se koi rename/demerger aaya ho '
                    'to IPO database screen se delete kar sakte ho.',
                    style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
                  ),
                ],
              ),
            ),
            IconButton(
              tooltip: 'Chhupao',
              onPressed: provider.dismissDiscovery,
              icon: const Icon(Icons.close, size: 18),
              visualDensity: VisualDensity.compact,
            ),
          ],
        ),
      ),
    );
  }
}

class _NoticeBanner extends StatelessWidget {
  const _NoticeBanner({required this.provider});

  final IpoScreenerProvider provider;

  void _handleAction(BuildContext context) {
    switch (provider.notice!) {
      case ScreenerNotice.loggedOut:
      case ScreenerNotice.sessionExpired:
        Navigator.of(context).push(
          MaterialPageRoute<void>(builder: (_) => const _LoginRoute()),
        );
      case ScreenerNotice.noTokens:
        provider.updateInstrumentMasterAndRescreen();
      case ScreenerNotice.levelsNeeded:
        provider.fetchListingLevels(all: true);
      case ScreenerNotice.noPrices:
      case ScreenerNotice.failed:
        provider.refresh(force: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final notice = provider.notice!;
    final scheme = Theme.of(context).colorScheme;
    final isError = notice == ScreenerNotice.sessionExpired ||
        notice == ScreenerNotice.failed;
    final tint = isError ? scheme.errorContainer : scheme.primaryContainer;
    final onTint = isError ? scheme.onErrorContainer : scheme.onPrimaryContainer;

    final (title, body, action) = switch (notice) {
      ScreenerNotice.loggedOut => (
          'Live prices need an Angel One session',
          'Log in to fetch LTPs. Search, filters, the ± band and the IPO '
              'database all work offline meanwhile.',
          'Log in',
        ),
      ScreenerNotice.sessionExpired => (
          'Your SmartAPI session expired',
          'Angel One tokens last one trading day. Log in again to resume '
              'live prices — your paper-trading data is untouched.',
          'Log in',
        ),
      ScreenerNotice.noPrices => (
          'The broker returned no prices',
          'The LTP call succeeded but came back empty (out of hours, or the '
              'token was de-listed). Try again in a moment.',
          'Retry',
        ),
      ScreenerNotice.noTokens => (
          'No instrument tokens yet',
          'Nothing in the IPO database resolved to a SmartAPI token, so there '
              'is nothing to price. Download the daily instrument master.',
          'Update master',
        ),
      ScreenerNotice.levelsNeeded => (
          'Fetching listing-day levels',
          'The ± band compares today\'s price with each IPO\'s listing-day '
              'high and low. Every mainboard IPO since 2015 is listed, and the '
              'app downloads those levels from the broker in the background — '
              '${provider.levelsPending} still to go.',
          'Fetch now',
        ),
      ScreenerNotice.failed => (
          'Could not reach the broker',
          'Check the connection and try again — cached prices stay on screen '
              'in the meantime.',
          'Retry',
        ),
    };

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(12, 4, 12, 0),
      padding: const EdgeInsets.fromLTRB(12, 10, 6, 10),
      decoration: BoxDecoration(
        color: tint,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            isError ? Icons.error_outline : Icons.info_outline,
            size: 18,
            color: onTint,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                    color: onTint,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  body,
                  style: TextStyle(fontSize: 11.5, color: onTint),
                ),
                const SizedBox(height: 4),
                TextButton(
                  onPressed: () => _handleAction(context),
                  style: TextButton.styleFrom(
                    foregroundColor: onTint,
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    minimumSize: const Size(0, 30),
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                  child: Text(action),
                ),
              ],
            ),
          ),
          IconButton(
            tooltip: 'Dismiss',
            icon: Icon(Icons.close, size: 16, color: onTint),
            onPressed: provider.dismissNotice,
          ),
        ],
      ),
    );
  }
}

/// Pushes the login screen and pops it as soon as a session exists, so the user
/// lands back on the tab they started from.
class _LoginRoute extends StatefulWidget {
  const _LoginRoute();

  @override
  State<_LoginRoute> createState() => _LoginRouteState();
}

class _LoginRouteState extends State<_LoginRoute> {
  @override
  Widget build(BuildContext context) {
    final loggedIn = context.select<AuthService, bool>((a) => a.isLoggedIn);
    if (loggedIn) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        final navigator = Navigator.of(context);
        if (mounted && navigator.canPop()) navigator.pop();
      });
    }
    return LoginScreen(onBrowseOffline: () => Navigator.of(context).maybePop());
  }
}

class _ErrorBanner extends StatelessWidget {
  const _ErrorBanner({
    required this.message,
    required this.onRetry,
    required this.onDismiss,
  });

  final String message;
  final VoidCallback onRetry;
  final VoidCallback onDismiss;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(12, 4, 12, 0),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: scheme.errorContainer,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(Icons.error_outline, size: 18, color: scheme.onErrorContainer),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              message,
              style: TextStyle(color: scheme.onErrorContainer, fontSize: 12.5),
            ),
          ),
          TextButton(
            onPressed: onRetry,
            child: const Text('Retry', style: TextStyle(fontSize: 12)),
          ),
        ],
      ),
    );
  }
}

class _OfflineBanner extends StatelessWidget {
  const _OfflineBanner();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final market = MarketColors.of(context);
    final screener = context.watch<IpoScreenerProvider>();

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(12, 6, 12, 0),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: market.stale.withOpacity(0.12),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(Icons.cloud_off_outlined, size: 16, color: market.stale),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              screener.statusLabel,
              style: TextStyle(fontSize: 12, color: scheme.onSurface),
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Filters, summary, states
// ---------------------------------------------------------------------------

class _QuickChips extends StatelessWidget {
  const _QuickChips({required this.provider});

  final IpoScreenerProvider provider;

  @override
  Widget build(BuildContext context) {
    final levels = provider.filters.levels;
    final years = provider.availableYears;

    return SizedBox(
      height: 46,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        children: [
          FilterChip(
            label: const Text('All levels'),
            selected: levels.isEmpty,
            onSelected: (_) => provider.setFilters(
              provider.filters.copyWith(levels: const {}),
            ),
          ),
          const SizedBox(width: 6),
          FilterChip(
            avatar: const Icon(Icons.vertical_align_top, size: 16),
            label: const Text('Near high'),
            selected: levels.contains(LevelType.high),
            onSelected: (_) => provider.toggleLevel(LevelType.high),
          ),
          const SizedBox(width: 6),
          FilterChip(
            avatar: const Icon(Icons.vertical_align_bottom, size: 16),
            label: const Text('Near low'),
            selected: levels.contains(LevelType.low),
            onSelected: (_) => provider.toggleLevel(LevelType.low),
          ),
          const SizedBox(width: 6),
          Tooltip(
            message: 'Ignore the ±band and list every priced IPO',
            child: FilterChip(
              avatar: const Icon(Icons.list_alt, size: 16),
              label: const Text('All screened'),
              selected: !provider.bandOnly,
              onSelected: (selected) => provider.setBandOnly(!selected),
            ),
          ),
          const SizedBox(width: 12),
          // Derivative segments (NFO/BFO) IPO screener me nahi aate —
          // 1.5.83 me BFO add hone par chips waisi hi rahen.
          for (final exchange in Exchange.values.where((e) => e.isCash)) ...[
            ChoiceChip(
              label: Text(exchange.code),
              selected: provider.filters.exchange == exchange,
              onSelected: (selected) =>
                  provider.setExchange(selected ? exchange : null),
            ),
            const SizedBox(width: 6),
          ],
          if (years.length > 1) ...[
            const SizedBox(width: 6),
            PopupMenuButton<int?>(
              tooltip: 'Listing year',
              onSelected: provider.setListingYear,
              itemBuilder: (context) => [
                const PopupMenuItem<int?>(value: null, child: Text('All years')),
                ...years.map(
                  (year) => PopupMenuItem<int?>(value: year, child: Text('$year')),
                ),
              ],
              child: Chip(
                avatar: const Icon(Icons.event_outlined, size: 16),
                label: Text(
                  provider.filters.listingYear == null
                      ? 'All years'
                      : '${provider.filters.listingYear}',
                ),
              ),
            ),
          ],
          const SizedBox(width: 12),
          if (provider.filters.isActive)
            ActionChip(
              avatar: const Icon(Icons.filter_alt_off_outlined, size: 16),
              label: const Text('Clear'),
              onPressed: provider.clearFilters,
            ),
        ],
      ),
    );
  }
}

class _SummaryStrip extends StatelessWidget {
  const _SummaryStrip({required this.provider});

  final IpoScreenerProvider provider;

  @override
  Widget build(BuildContext context) {
    final market = MarketColors.of(context);
    final scheme = Theme.of(context).colorScheme;
    final result = provider.result;

    return Container(
      margin: const EdgeInsets.fromLTRB(12, 4, 12, 0),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest.withOpacity(0.35),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: _Stat(
                  label: 'Matches',
                  value: '${result.matches.length}',
                  hint: 'of ${provider.totalRows} IPOs',
                ),
              ),
              Expanded(
                child: _Stat(
                  label: 'Near high',
                  value: '${result.nearHighCount}',
                  color: market.nearHigh,
                ),
              ),
              Expanded(
                child: _Stat(
                  label: 'Near low',
                  value: '${result.nearLowCount}',
                  color: market.nearLow,
                ),
              ),
              Expanded(
                child: _Stat(
                  label: '± band',
                  value: '${provider.proximityPct.toStringAsFixed(1)}%',
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(
                provider.isOffline ? Icons.cloud_off_outlined : Icons.bolt,
                size: 13,
                color: provider.isOffline ? market.stale : scheme.primary,
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  provider.statusLabel,
                  style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
                ),
              ),
              if (provider.staleCount > 0)
                Text(
                  '${provider.staleCount} cached',
                  style: TextStyle(fontSize: 11, color: market.stale),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat({
    required this.label,
    required this.value,
    this.hint,
    this.color,
  });

  final String label;
  final String value;
  final String? hint;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant),
        ),
        Text(
          value,
          style: TextStyle(
            fontSize: 17,
            fontWeight: FontWeight.w700,
            color: color,
          ),
        ),
        if (hint != null)
          Text(
            hint!,
            style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant),
          ),
      ],
    );
  }
}

class _LoadingState extends StatelessWidget {
  const _LoadingState();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(),
          SizedBox(height: 14),
          Text('Loading the IPO database and prices…'),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.provider});

  final IpoScreenerProvider provider;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final filtered = provider.filters.isActive;
    final hasRows = provider.totalRows > 0;

    // ListView (not Center) so pull-to-refresh still works on an empty list.
    return ListView(
      padding: const EdgeInsets.fromLTRB(24, 60, 24, 24),
      children: [
        Icon(
          filtered ? Icons.filter_alt_off_outlined : Icons.search_off,
          size: 44,
          color: scheme.onSurfaceVariant,
        ),
        const SizedBox(height: 14),
        Text(
          !hasRows
              ? 'The IPO database is empty'
              : filtered
                  ? 'No matches with these filters'
                  : 'No IPO is within ±${provider.proximityPct.toStringAsFixed(1)}% right now',
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.titleMedium,
        ),
        const SizedBox(height: 8),
        Text(
          !hasRows
              ? 'Restore the bundled 2015-onwards list from the database screen, '
                  'or import your own CSV.'
              : filtered
                  ? 'Try clearing the filters, or widen the ± band from the '
                      'filter sheet.'
                  : 'The screen only lists stocks hugging their listing-day high '
                      'or low. Pull down to refresh prices.',
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.bodySmall,
        ),
        const SizedBox(height: 20),
        if (filtered)
          Center(
            child: FilledButton.tonal(
              onPressed: provider.clearFilters,
              child: const Text('Clear filters'),
            ),
          ),
        // Priced, unfiltered, but nothing inside the band: show the runners-up
        // so the screen still answers "where do I stand today?".
        if (!filtered && hasRows && provider.result.pricedCount > 0)
          _NearbySection(provider: provider),
      ],
    );
  }
}

/// "Closest right now" — the rows nearest a level even though none is inside
/// the ±band, plus the one-tap switch to the full list.
class _NearbySection extends StatelessWidget {
  const _NearbySection({required this.provider});

  final IpoScreenerProvider provider;

  @override
  Widget build(BuildContext context) {
    final market = MarketColors.of(context);
    final scheme = Theme.of(context).colorScheme;
    final nearby = provider.nearestOutsideBand();
    if (nearby.isEmpty) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 8),
        Align(
          alignment: Alignment.centerLeft,
          child: Text(
            'CLOSEST RIGHT NOW',
            style: TextStyle(
              fontSize: 10.5,
              letterSpacing: 1.1,
              fontWeight: FontWeight.w700,
              color: scheme.onSurfaceVariant,
            ),
          ),
        ),
        const SizedBox(height: 6),
        for (final match in nearby)
          Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: Row(
              children: [
                Icon(
                  match.level == LevelType.high
                      ? Icons.vertical_align_top
                      : Icons.vertical_align_bottom,
                  size: 15,
                  color: match.level == LevelType.high
                      ? market.nearHigh
                      : market.nearLow,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    match.ipo.symbol,
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Text(
                  match.proximityLabel,
                  style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant),
                ),
                const SizedBox(width: 10),
                Text(
                  Fmt.money(match.ltp),
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
        const SizedBox(height: 12),
        Center(
          child: FilledButton.tonalIcon(
            onPressed: () => provider.setBandOnly(false),
            icon: const Icon(Icons.list_alt, size: 18),
            label: Text('Show all ${provider.totalRows} screened IPOs'),
          ),
        ),
      ],
    );
  }
}

/// Bottom of the list: what fell out of the screen and why.
class _ListFooter extends StatelessWidget {
  const _ListFooter({required this.provider});

  final IpoScreenerProvider provider;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final skipped = provider.skipped;

    return Padding(
      padding: const EdgeInsets.only(top: 4),
      child: Column(
        children: [
          if (skipped.isNotEmpty)
            Card(
              child: ListTile(
                leading: Icon(Icons.report_gmailerrorred_outlined,
                    color: scheme.onSurfaceVariant),
                title: Text('${skipped.length} rows were not screened'),
                subtitle: Text(
                  'Missing instrument token or price. Tap for the list.',
                  style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant),
                ),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _showSkipped(context, provider),
              ),
            ),
          const SizedBox(height: 10),
          Text(
            'Screened ${provider.result.pricedCount} priced instruments · '
            'level rule ±${provider.proximityPct.toStringAsFixed(1)}%',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
          ),
        ],
      ),
    );
  }

  void _showSkipped(BuildContext context, IpoScreenerProvider provider) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (_) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.65,
        builder: (context, controller) => ListView.builder(
          controller: controller,
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          itemCount: provider.skipped.length + 2,
          itemBuilder: (context, index) {
            if (index == 0) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Not screened',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    Text(
                      'Usually a missing instrument token (the bundled starter '
                      'master only holds a few symbols) or a market that is '
                      'closed. Add or fix rows from the IPO database screen.',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              );
            }
            if (index == provider.skipped.length + 1) {
              // Self-healing action: pull the full master and re-screen.
              return Padding(
                padding: const EdgeInsets.only(top: 12),
                child: FilledButton.icon(
                  onPressed: () async {
                    Navigator.of(context).pop();
                    final messenger = ScaffoldMessenger.of(context);
                    await provider.updateInstrumentMasterAndRescreen();
                    messenger.showSnackBar(
                      const SnackBar(
                        content: Text(
                          'Instrument master updated and the scan re-run.',
                        ),
                      ),
                    );
                  },
                  icon: const Icon(Icons.cloud_download_outlined, size: 18),
                  label: const Text('Download instrument master & re-screen'),
                ),
              );
            }
            final skip = provider.skipped[index - 1];
            return ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text('${skip.ipo.exchange.code}:${skip.ipo.symbol}'),
              subtitle: Text(skip.reason, style: const TextStyle(fontSize: 11.5)),
            );
          },
        ),
      ),
    );
  }
}

/// One label/value row inside the detail sheet.
class _DetailRow extends StatelessWidget {
  const _DetailRow(this.label, this.value, {this.color});

  final String label;
  final String value;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: TextStyle(fontSize: 13, color: scheme.onSurfaceVariant),
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

/// Bottom sheet behind the "N rows need attention" line on the scan bar.
///
/// The screener can only price a row whose symbol exists in the broker's
/// instrument master, and can only test the ±band once it knows the listing-day
/// levels. When a company renames itself (LTIM → LTM, AMIORG → ACUTAAS) the
/// database keeps the old ticker and that row never resolves — the counter stops
/// short of the total and, without this sheet, looks stuck. Here the user can see
/// exactly which rows those are and fix each one: edit the symbol, or delete the
/// row if the company is gone.
Future<void> showIpoAttentionSheet({
  required BuildContext context,
  required IpoScreenerProvider provider,
}) {
  return showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (_) => _AttentionSheet(provider: provider),
  );
}

class _AttentionSheet extends StatelessWidget {
  const _AttentionSheet({required this.provider});

  final IpoScreenerProvider provider;

  IconData _iconFor(IpoSkipKind kind) => switch (kind) {
        IpoSkipKind.notResolved => Icons.search_off,
        IpoSkipKind.noPrice => Icons.money_off,
        IpoSkipKind.levelsUnavailable => Icons.trending_flat,
        _ => Icons.info_outline,
      };

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return ListenableBuilder(
      listenable: provider,
      builder: (context, _) {
        final rows = provider.attentionRows;
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Dhyan dene wale rows (${rows.length})',
                    style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 4),
                Text(
                  'Ye rows scan me nahi aa sakte jab tak inka symbol theek na ho. '
                  'Company ka naam badal jaye to ticker bhi badal jata hai '
                  '(jaise LTIM → LTM, AMIORG → ACUTAAS) — naya ticker daal do, '
                  'ya row delete kar do.',
                  style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant),
                ),
                const SizedBox(height: 12),
                if (rows.isEmpty)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 24),
                    child: Row(
                      children: [
                        Icon(Icons.check_circle_outline,
                            size: 18, color: MarketColors.of(context).gain),
                        const SizedBox(width: 8),
                        const Text('Sab theek — ab koi row pending nahi.'),
                      ],
                    ),
                  )
                else
                  ConstrainedBox(
                    constraints: BoxConstraints(
                      maxHeight: MediaQuery.of(context).size.height * 0.6,
                    ),
                    child: ListView.separated(
                      shrinkWrap: true,
                      itemCount: rows.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (context, index) {
                        final skip = rows[index];
                        final ipo = skip.ipo;
                        return ListTile(
                          dense: true,
                          contentPadding: EdgeInsets.zero,
                          leading: Icon(_iconFor(skip.kind),
                              size: 18, color: scheme.error),
                          title: Text(
                            '${ipo.symbol} · ${ipo.exchange.code}',
                            style: const TextStyle(
                                fontSize: 13, fontWeight: FontWeight.w600),
                          ),
                          subtitle: Text(
                            '${ipo.companyName}\n${skip.reason}',
                            style: const TextStyle(fontSize: 11),
                          ),
                          isThreeLine: true,
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                tooltip: 'Symbol theek karo',
                                icon: const Icon(Icons.edit_outlined, size: 18),
                                onPressed: () async {
                                  await showIpoFormSheet(
                                    context: context,
                                    provider: provider,
                                    existing: ipo,
                                  );
                                  await provider.refresh(force: true, silent: true);
                                },
                              ),
                              IconButton(
                                tooltip: 'Row delete karo',
                                icon: const Icon(Icons.delete_outline, size: 18),
                                onPressed: () async {
                                  final confirm = await showDialog<bool>(
                                    context: context,
                                    builder: (context) => AlertDialog(
                                      title: Text('${ipo.symbol} delete karein?'),
                                      content: const Text(
                                        'Ye row database se hat jayegi. Baad me '
                                        '"Import CSV"/manual add se wapas aa sakti hai.',
                                      ),
                                      actions: [
                                        TextButton(
                                          onPressed: () =>
                                              Navigator.pop(context, false),
                                          child: const Text('Cancel'),
                                        ),
                                        FilledButton(
                                          onPressed: () =>
                                              Navigator.pop(context, true),
                                          child: const Text('Delete'),
                                        ),
                                      ],
                                    ),
                                  );
                                  if (confirm == true) {
                                    await provider.deleteIpo(ipo);
                                    await provider.refresh(force: true, silent: true);
                                  }
                                },
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }
}
