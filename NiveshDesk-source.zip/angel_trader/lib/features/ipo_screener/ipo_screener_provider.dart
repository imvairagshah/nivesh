// ---------------------------------------------------------------------------
// ipo_screener_provider.dart — orchestrates Feature 1.
//
// Sequence on a refresh:
//   ipos table ──▶ token resolution (scrip master, cached) ──▶ LTP batch fetch
//        ──▶ IpoScreenerEngine.evaluate (±band, filters, sort) ──▶ UI
//        └──▶ prices + result cached in SQLite (offline view)
//
// Filtering never triggers a network call: the price map from the last refresh is
// kept in memory, so switching "Near High / Near Low" or the year filter is
// instant and consistent with the counters shown in the header.
// ---------------------------------------------------------------------------

import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;

import '../../core/utils/csv_io.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/markets.dart';
import '../../data/local/dao/ipo_dao.dart';
import '../../data/local/dao/scan_cache_dao.dart';
import '../../data/local/dao/settings_dao.dart';
import '../../data/local/models/ipo.dart';
import '../../data/remote/api_client.dart';
import '../../data/remote/dto/quote.dart';
import '../../data/remote/dto/scrip.dart';
import '../../services/auth_service.dart';
import '../../services/ipo_discovery_service.dart';
import '../../services/listing_levels_service.dart';
import '../../services/market_data_service.dart';
import '../../services/scrip_master_service.dart';
import '../settings/settings_provider.dart';
import 'ipo_screener_engine.dart';

/// Where the currently-displayed data came from — drives the status banner.
enum ScreenerSource { none, cache, live, error }

enum ScreenerPhase { idle, loading, ready }

/// Why the screener cannot show live prices right now.
///
/// Rendered as a friendly, actionable banner: an empty screen must always come
/// with a reason the user can act on ("Log in", "Retry", "Update master").
enum ScreenerNotice {
  /// No SmartAPI session — the app cannot ask for LTPs.
  loggedOut,

  /// The broker rejected the token (daily expiry, key rotated).
  sessionExpired,

  /// Logged in and the call succeeded, but no prices came back.
  noPrices,

  /// Nothing resolved against the scrip master, so nothing could be priced.
  noTokens,

  /// Rows are loaded but their listing-day high/low still has to be fetched from
  /// the broker before the ±band test can run.
  levelsNeeded,

  /// Network / broker failure while prices had not been fetched yet.
  failed,
}

class IpoScreenerProvider extends ChangeNotifier {
  IpoScreenerProvider({
    required IpoDao ipoDao,
    required ScanCacheDao cacheDao,
    required ScripMasterService scripMaster,
    required MarketDataService marketData,
    required AuthService auth,
    required SettingsProvider settings,
    SettingsDao? settingsDao,
    ListingLevelsService? levels,
    IpoDiscoveryService? discovery,
  })  : _ipoDao = ipoDao,
        _settingsDao = settingsDao,
        _cacheDao = cacheDao,
        _scripMaster = scripMaster,
        _marketData = marketData,
        _auth = auth,
        _settings = settings,
        _levels = levels,
        _discovery = discovery;

  final IpoDao _ipoDao;

  /// Optional: remembers which revision of the bundled IPO master has been
  /// merged into this install, so an app update can ship a bigger universe and
  /// existing users still receive it (without resurrecting rows they deleted).
  final SettingsDao? _settingsDao;
  final ScanCacheDao _cacheDao;
  final ScripMasterService _scripMaster;
  final MarketDataService _marketData;
  final AuthService _auth;
  final SettingsProvider _settings;

  /// Fills in listing-day high/low for rows shipped without them (the bundled
  /// master carries every mainboard IPO since 2015, so most rows start empty —
  /// see [ListingLevelsService]). Optional so tests can leave it out.
  final ListingLevelsService? _levels;

  /// Finds IPOs that listed *after* the newest row in the database and adds them
  /// automatically (broker candles first, official NSE listing dates as backup —
  /// see [IpoDiscoveryService]). Optional so tests can leave it out.
  final IpoDiscoveryService? _discovery;

  // ---- Automatically discovered listings -----------------------------------

  List<Ipo> _discovered = const <Ipo>[];
  List<IdentityRepair> _repaired = const <IdentityRepair>[];
  bool _isDiscovering = false;

  /// Rows the last discovery run added — shown once in the screener so new
  /// listings are never added invisibly (and can be deleted in one tap).
  List<Ipo> get discoveredRows => _discovered;

  bool get isDiscovering => _isDiscovering;

  /// One-line summary for the banner; `null` when there is nothing to show.
  String? get discoveryLabel {
    final parts = <String>[];
    if (_discovered.isNotEmpty) {
      final names = _discovered.take(3).map((row) => row.symbol).join(', ');
      final more =
          _discovered.length > 3 ? ' +${_discovered.length - 3} more' : '';
      parts.add('${_discovered.length} naya IPO mila aur add ho gaya: $names$more');
    }
    if (_repaired.isNotEmpty) {
      final pairs = _repaired
          .take(3)
          .map((repair) => '${repair.from} → ${repair.to}')
          .join(', ');
      final more = _repaired.length > 3 ? ' +${_repaired.length - 3} more' : '';
      parts.add(
          '${_repaired.length} ticker repair (company ka naam badla tha): $pairs$more');
    }
    if (parts.isEmpty) return null;
    return parts.join('\n');
  }

  /// Hides the discovery banner (the rows themselves stay in the database).
  void dismissDiscovery() {
    if (_discovered.isEmpty && _repaired.isEmpty) return;
    _discovered = const <Ipo>[];
    _repaired = const <IdentityRepair>[];
    notifyListeners();
  }

  /// Asks [IpoDiscoveryService] for listings newer than the newest row.
  ///
  /// Runs automatically on launch (rate-limited inside the service, so opening
  /// the app ten times a day does not probe ten times) and on demand from the
  /// screener's "check for new IPOs" action.
  Future<void> discoverNewListings({bool force = false}) async {
    final service = _discovery;
    if (service == null || _isDiscovering || _disposed) return;
    _isDiscovering = true;
    notifyListeners();
    try {
      final report = await service.discoverNewListings(force: force);
      if (_disposed) return;
      if (report.didAdd) {
        _discovered = report.added;
        _repaired = report.identity.repairs;
        // The database grew: re-read, re-resolve and re-screen so the new rows
        // are scanned in the very next pass.
        await _loadRowsAndResolve();
        await _refreshLevelsCount();
        if (_prices.isNotEmpty) _result = _evaluate(isFromCache: true);
      }
    } finally {
      _isDiscovering = false;
      if (!_disposed) notifyListeners();
    }
  }

  // ---- Listing-levels progress ---------------------------------------------

  int _levelsPending = 0;
  int _levelsDone = 0;
  int _levelsTotal = 0;
  bool _isFetchingLevels = false;

  /// Seed file bundled with the app (mainboard IPOs listed after 1 Jan 2015).
  static const String seedCsvAsset = 'assets/data/ipos.csv';

  /// Bump this whenever the bundled master changes in a way users should get on
  /// update (e.g. 1.3.2 grew it from 39 hand-picked rows to the full post-2015
  /// mainboard universe).
  static const String seedRevisionKey = 'ipo_seed_revision';
  static const String seedRevision = '5-isin-identity';

  /// Tickers that changed on the exchange *after* the bundled master was cut.
  /// The merge itself is `INSERT … DO NOTHING`, so an existing install keeps the
  /// old row forever — this map is the repair path (applied once per revision).
  /// Without it those rows stay "token not found" and the scan counter never
  /// reaches the total, which looks like a hang.
  static const Map<String, ({String symbol, String company, String note})>
      renamedSymbols = {
    'LTIM': (
      symbol: 'LTM',
      company: 'Ltm Limited',
      note: 'renamed LTIM → LTM (Feb 2026)',
    ),
    'AMIORG': (
      symbol: 'ACUTAAS',
      company: 'Acutaas Chemicals Limited',
      note: 'renamed AMIORG → ACUTAAS (Jun 2025)',
    ),
  };

  // ---- State ---------------------------------------------------------------

  ScreenerPhase _phase = ScreenerPhase.idle;
  ScreenerSource _source = ScreenerSource.none;
  bool _isRefreshing = false;
  String? _error;
  ScreenerNotice? _notice;

  /// `false` = "All screened": every priced row is listed, not just the rows
  /// inside the ±band. Resets to the spec view on `clearFilters()`.
  bool _bandOnly = true;

  /// When the last real scan attempt finished.
  DateTime? _lastScanAt;

  IpoScreenerEngine? _engine;
  List<ResolvedIpo> _resolved = const [];
  Map<String, PricedValue> _prices = const {};
  Map<String, Scrip> _scripByKey = const {};
  IpoScreenerResult _result = IpoScreenerResult.empty();

  IpoFilters _filters = const IpoFilters();
  IpoSortMode _sort = IpoSortMode.closest;

  List<int> _years = const [];
  DateTime? _lastLiveAt;
  DateTime? _lastCachedAt;

  // ---- Reads ---------------------------------------------------------------

  ScreenerPhase get phase => _phase;
  ScreenerSource get source => _source;
  bool get isRefreshing => _isRefreshing;
  String? get error => _error;

  /// Set when the screener knows *why* it has no live data (see [ScreenerNotice]).
  ScreenerNotice? get notice => _notice;

  /// `true` while a scan is running — drives the Scan button's spinner.
  bool get isScanning => _isRefreshing;

  /// `true` while the ±band filter is lifted ("All screened" view).
  bool get bandOnly => _bandOnly;

  /// When the last scan attempt ran (null until the first one).
  DateTime? get lastScanAt => _lastScanAt;

  /// `true` outside NSE/BSE trading hours — prices are then the last close, and
  /// the screen says so instead of looking frozen.
  bool get marketClosed => !MarketCalendar.isMarketOpen();

  /// Rows with no usable listing-day high/low yet.
  int get levelsPending => _levelsPending;

  /// `true` while the background/foreground level fetch is running.
  bool get isFetchingLevels => _isFetchingLevels;

  /// Levels fetched so far in the current run (0 when idle).
  int get levelsDone => _levelsDone;
  int get levelsTotal => _levelsTotal;

  /// Progress of the current level run, clamped to 0…1.
  double get levelsProgress =>
      _levelsTotal == 0 ? 0 : (_levelsDone / _levelsTotal).clamp(0.0, 1.0);

  /// `true` when every row has its listing-day range.
  bool get levelsComplete => _levelsPending == 0;

  /// One line under the Scan button, e.g. `Scanned 39 of 39 · 12:04`.
  String get scanSummary {
    if (_isRefreshing) return 'Scanning ${_resolved.length} IPOs…';
    final at = _lastScanAt;
    if (at == null) return 'Not scanned yet — tap Scan';
    return 'Scanned ${_result.pricedCount} of ${_result.totalRows} · ${Fmt.clock(at)}';
  }

  IpoScreenerResult get result => _result;
  List<IpoMatch> get matches => _result.matches;
  List<IpoSkip> get skipped => _result.skipped;

  IpoFilters get filters => _filters;
  IpoSortMode get sortMode => _sort;
  List<int> get availableYears => _years;

  int get totalRows => _result.totalRows;
  int get unresolvedCount => _result.totalRows - _result.resolvedCount;

  /// Rows that can never be screened until something is fixed: a ticker the
  /// broker no longer lists, a symbol without a quote, or levels that could not
  /// be fetched. Rows that are simply outside the ±band are *not* here — that is
  /// the normal state of most of the database.
  List<IpoSkip> get attentionRows =>
      _result.skipped.where((skip) => skip.needsAttention).toList(growable: false);

  int get attentionCount => attentionRows.length;

  /// Short line for the scan bar. Says the count *and* what it means, so a
  /// counter that stops short of the total never looks like a hang.
  String get attentionLabel {
    final rows = attentionRows;
    if (rows.isEmpty) return '';
    final missing = rows.where((r) => r.kind == IpoSkipKind.notResolved).length;
    final noPrice = rows.where((r) => r.kind == IpoSkipKind.noPrice).length;
    final parts = <String>[
      if (missing > 0) '$missing symbol exchange pe nahi',
      if (noPrice > 0) '$noPrice ka price nahi aaya',
      if (rows.length - missing - noPrice > 0)
        '${rows.length - missing - noPrice} ka levels nahi mila',
    ];
    return '${rows.length} rows need attention · ${parts.join(' · ')}';
  }
  int get staleCount => _result.staleCount;

  /// Band currently in force (from Settings; spec default ±3 %).
  double get proximityPct => _settings.settings.proximityPct.toDouble();

  /// `true` when prices came from the local cache rather than the broker.
  bool get isOffline => _source == ScreenerSource.cache || _source == ScreenerSource.none;

  DateTime? get lastLiveAt => _lastLiveAt;
  DateTime? get lastCachedAt => _lastCachedAt;

  bool get hasData => _result.matches.isNotEmpty || _result.totalRows > 0;

  /// Line under the scan summary, e.g. `Listing levels 37/551 · fetching…`.
  String get levelsLabel {
    if (_levelsPending == 0) return 'Listing levels complete';
    if (_isFetchingLevels) {
      return 'Fetching listing levels ${_levelsDone + 1}/$_levelsTotal…';
    }
    return '$_levelsPending IPOs need listing-day high/low';
  }

  /// One-line status for the app bar / banner.
  String get statusLabel {
    switch (_source) {
      case ScreenerSource.live:
        final at = _lastLiveAt;
        return at == null
            ? 'Live prices'
            : 'Live prices · updated ${Fmt.relative(at)}';
      case ScreenerSource.cache:
        final at = _lastCachedAt ?? _lastLiveAt;
        return at == null
            ? 'Cached data'
            : 'Cached data · ${Fmt.dateTime(at)}';
      case ScreenerSource.error:
        return _error ?? 'Could not refresh';
      case ScreenerSource.none:
        return 'No data yet';
    }
  }

  // -------------------------------------------------------------------------
  // Bootstrap
  // -------------------------------------------------------------------------

  /// Guards the one-shot background master download.
  bool _masterUpdateTriggered = false;

  /// First load: seeds the IPO database if empty, resolves tokens, paints the
  /// cached result immediately (so the screen is never blank), then refreshes
  /// from the network when a session exists.
  Future<void> bootstrap() async {
    if (_phase == ScreenerPhase.loading) return;
    _phase = ScreenerPhase.loading;
    _error = null;
    notifyListeners();

    try {
      await _ensureSeedMaster();
      await _refreshLevelsCount();
      await _loadRowsAndResolve();
      await _paintFromCache();
      _phase = ScreenerPhase.ready;
      notifyListeners();

      // Full instrument master is ~50 MB, so it is fetched in the background the
      // first time a session exists — the screener is usable meanwhile with the
      // bundled starter tokens.
      if (_auth.isLoggedIn &&
          !_masterUpdateTriggered &&
          _scripMaster.source != 'network') {
        _masterUpdateTriggered = true;
        unawaited(_downloadMasterThenRescreen());
      }

      // Live pass (non-fatal when offline / not logged in).
      await refresh(force: true, silent: true);

      // Then start filling in missing listing-day levels, one small batch per
      // app launch (and again on every screen open). 550 rows × 1 candle call
      // is a lot of API traffic to dump on the user at once, so it resumes
      // silently instead — the scan bar shows the running count.
      if (_auth.isLoggedIn && _levelsPending > 0) {
        // With the complete master already cached, unusable rows are marked once
        // so the "levels pending" counter can actually reach zero.
        if (_scripMaster.source == 'network') {
          final marked = await _levels?.markUnresolvableAsMissing();
          if ((marked ?? 0) > 0) await _refreshLevelsCount();
        }
        if (_levelsPending > 0) unawaited(fetchListingLevels());
      }

      // …and the same for listings newer than the newest row in the database:
      // discovery keeps the universe current without a new APK (one candle call
      // per candidate, capped and rate-limited inside the service).
      if (_auth.isLoggedIn) {
        unawaited(discoverNewListings());
      }
    } catch (e) {
      _error = 'Could not load the IPO database: $e';
      _source = ScreenerSource.error;
      _phase = ScreenerPhase.ready;
      notifyListeners();
    }
  }

  /// Makes sure this install holds the current bundled IPO master.
  ///
  /// Three cases:
  ///   • fresh install            → seed the whole file
  ///   • updated app (revision ↑) → merge the file in with `overwrite: false`
  ///     (INSERT … ON CONFLICT DO NOTHING), so rows the user added or edited
  ///     always keep their values; the merge runs once per revision
  ///   • already current          → nothing to do
  Future<void> _ensureSeedMaster() async {
    final dao = _settingsDao;
    final current = dao == null ? null : await dao.meta(seedRevisionKey);
    final empty = await _ipoDao.count() == 0;

    if (!empty && current == seedRevision) return;

    // Repair renamed tickers *before* merging: the merge would otherwise add the
    // new ticker as a second row and leave the stale one broken.
    final repaired = await _repairRenamedSymbols();

    final report = await seedFromAsset(overwrite: false);

    // An app update can add rows but not enrich them (the merge is
    // INSERT … DO NOTHING), so rows that shipped before this revision still have
    // blank listing levels. Fill those in from the file — never overwriting a
    // value the user typed or the broker fetched.
    final enriched = await _ipoDao.backfillLevelsFromCsv(await _seedCsvText());
    // The ISIN is the identity that survives renames, so older installs get it
    // filled in from the master as well — without it a future rename of that
    // company could not be detected automatically.
    final isins = await _ipoDao.backfillIsinsFromCsv(await _seedCsvText());
    await dao?.putMeta(seedRevisionKey, seedRevision);
    if (report.inserted > 0 || enriched > 0 || repaired > 0) {
      debugPrint('IPO master merged: +${report.inserted} rows, '
          '$enriched levels enriched, $isins ISINs filled, '
          '$repaired tickers repaired (${report.skipped} already present)');
    }
  }

  /// Applies [renamedSymbols] to rows an earlier install already has.
  Future<int> _repairRenamedSymbols() async {
    var repaired = 0;
    for (final entry in renamedSymbols.entries) {
      repaired += await _ipoDao.renameSymbol(
        from: entry.key,
        to: entry.value.symbol,
        companyName: entry.value.company,
        note: entry.value.note,
      );
    }
    return repaired;
  }

  /// The bundled master as text (asset → string), cached for the session so the
  /// merge and its level-enrichment pass share one read.
  String? _seedText;

  Future<String> _seedCsvText() async {
    return _seedText ??= await rootBundle.loadString(seedCsvAsset);
  }

  /// Downloads the daily scrip master, then re-resolves every IPO row so the
  /// previously "token not found" rows start working.
  Future<void> _downloadMasterThenRescreen() async {
    try {
      await _scripMaster.refresh(force: true);
      await _loadRowsAndResolve();
      // The full master is here: rows whose ticker it does not contain can never
      // be priced, so stop queueing them for levels forever.
      await _levels?.markUnresolvableAsMissing();
      await _refreshLevelsCount();
      _result = _evaluate(isFromCache: _source != ScreenerSource.live);
      notifyListeners();
      await refresh(force: false, silent: true); // prices for the new tokens
    } catch (e) {
      // Offline or throttled: keep the bundled tokens and carry on.
      debugPrint('Instrument master download skipped: $e');
    }
  }

  /// Manual version of the above (used by the "rows not screened" sheet).
  Future<void> updateInstrumentMasterAndRescreen() async {
    _masterUpdateTriggered = true;
    await _downloadMasterThenRescreen();
  }

  /// Loads `assets/data/ipos.csv` into the database (first run / "restore
  /// sample data"). Existing user edits are preserved.
  Future<IpoImportReport> seedFromAsset({bool overwrite = false}) async {
    final csv = await rootBundle.loadString(seedCsvAsset);
    final report = await _ipoDao.seedFromCsv(csv, overwrite: overwrite);
    await _loadRowsAndResolve();
    notifyListeners();
    return report;
  }

  /// Reads every row and resolves it against the scrip master.
  Future<void> _loadRowsAndResolve() async {
    final engine = IpoScreenerEngine(await _scripMaster.resolver());
    _engine = engine;

    final rows = await _ipoDao.all();
    _resolved = engine.resolveAll(rows);
    _years = IpoScreenerEngine.availableYears(rows);

    // Remember the instrument behind each price key so the fetch step knows
    // which tokens to ask for.
    final byKey = <String, Scrip>{};
    for (final item in _resolved) {
      final scrip = item.resolution.scrip;
      if (scrip == null) continue;
      byKey[item.ipo.priceKey] = scrip;
    }
    _scripByKey = byKey;
  }

  /// Shows the last cached scan (instant, offline-friendly).
  Future<void> _paintFromCache() async {
    final cached = await _cacheDao.latestRun(ScanKind.ipoProximity);
    final prices = await _cacheDao.loadPrices();
    _prices = prices.isEmpty ? _prices : prices;
    _lastCachedAt = cached?.createdAt ?? await _cacheDao.lastPriceTimestamp();

    if (cached == null) {
      // Evaluate even with no prices at all: the counters must show how many
      // IPOs are loaded ("0 of 39 today"), never "0 of 0" as if the database
      // were empty — that is what made the screen look broken.
      if (_engine != null) {
        _result = _evaluate(isFromCache: true);
      }
      return;
    }

    // Rebuild matches from the cached price map rather than replaying the cached
    // JSON: the database may have been edited since, and re-evaluating keeps the
    // cards, counters and filters exactly in sync.
    if (_engine == null) return;
    _result = _evaluate(isFromCache: true);

    // If the cache holds symbols we no longer have prices for, fall back to the
    // stored rows so the user still sees something.
    if (_result.matches.isEmpty && cached.rows.isNotEmpty) {
      _lastCachedAt = cached.createdAt;
    }
    _source = _result.matches.isEmpty && cached.rows.isEmpty
        ? ScreenerSource.none
        : ScreenerSource.cache;
  }

  // -------------------------------------------------------------------------
  // Refresh
  // -------------------------------------------------------------------------

  /// Resolves unresolved rows (if the master grew), fetches LTPs and re-screens.
  ///
  /// [silent] suppresses the error banner for background refreshes (e.g. the
  /// periodic timer or a pull-to-refresh while offline).
  Future<void> refresh({bool force = false, bool silent = false}) async {
    if (_isRefreshing) return;
    _isRefreshing = true;
    if (!silent) _error = null;
    notifyListeners();

    try {
      // A fresh token list can fix rows that failed to resolve earlier.
      if (_engine == null || force) {
        await _loadRowsAndResolve();
      }

      final scrips = _scripByKey.values.toList(growable: false);
      if (scrips.isEmpty) {
        // Explains itself through the notice banner — no raw error needed.
        _notice = ScreenerNotice.noTokens;
        _error = null;
        _source = ScreenerSource.error;
        _result = _evaluate(isFromCache: true); // still count the rows
        return;
      }

      if (!_auth.isLoggedIn) {
        // Every row needs an LTP, and an LTP needs a session: say so instead of
        // leaving the user with a blank list.
        _notice = ScreenerNotice.loggedOut;
        _error = null;
        // Always re-evaluate: without this the summary showed "0 of 0 IPOs"
        // and the screen looked empty even though the database was loaded.
        _result = _evaluate(isFromCache: true);
        if (_prices.isNotEmpty) _source = ScreenerSource.cache;
        return;
      }

      // Past the gates: this counts as a real scan from here on.
      _lastScanAt = DateTime.now();
      final fetched = await _marketData.fetchLtp(scrips);
      if (fetched.isNotEmpty) {
        _prices = {..._prices, ...fetched};
        _lastLiveAt = DateTime.now();
        _source = ScreenerSource.live;
        _notice = null;
        await _cacheDao.savePrices(fetched);
      } else {
        // Logged in, call succeeded, nothing came back: usually an out-of-hours
        // or de-listed token — not a crash, so report it as a state.
        _notice = ScreenerNotice.noPrices;
        _source = _prices.isEmpty ? ScreenerSource.error : ScreenerSource.cache;
      }

      await _refreshLevelsCount();
      _result = _evaluate(isFromCache: _source != ScreenerSource.live);
      _error = null;

      // An empty result right after a successful price fetch usually means the
      // rows simply have no listing-day range yet: say so instead of leaving the
      // user with "nothing is near its level today".
      if (_notice == null &&
          _result.matches.isEmpty &&
          _prices.isNotEmpty &&
          _levelsPending > 0) {
        _notice = ScreenerNotice.levelsNeeded;
      }

      await _cacheDao.saveRun(
        kind: ScanKind.ipoProximity,
        asOf: Fmt.isoDate(MarketCalendar.latestTradingDay()),
        rows: _result.matches
            .map((m) => {
                  'symbol': m.ipo.symbol,
                  'exchange': m.exchange.code,
                  'company': m.ipo.companyName,
                  'listingDate': Fmt.isoDate(m.ipo.listingDate),
                  'listingHigh': m.ipo.listingHigh,
                  'listingLow': m.ipo.listingLow,
                  'ltp': m.ltp,
                  'level': m.level.name,
                  'diffPct': m.diffPct,
                })
            .toList(growable: false),
      );
    } on ApiException catch (e) {
      _source = _prices.isEmpty ? ScreenerSource.error : ScreenerSource.cache;
      if (e.isAuthError) {
        // Daily token expiry is normal on SmartAPI — offer a re-login.
        _notice = ScreenerNotice.sessionExpired;
        _error = null;
      } else if (_prices.isEmpty) {
        _notice = ScreenerNotice.failed;
        _error = silent ? null : e.message;
      } else {
        _notice = null; // cached prices are still on screen
        _error = silent ? null : e.message;
      }
      if (_engine != null && _prices.isNotEmpty) {
        _result = _evaluate(isFromCache: true);
      }
    } catch (e) {
      _source = ScreenerSource.error;
      _notice = ScreenerNotice.failed;
      if (!silent) _error = 'Refresh failed: $e';
    } finally {
      _isRefreshing = false;
      _phase = ScreenerPhase.ready;
      notifyListeners();
    }
  }

  IpoScreenerResult _evaluate({required bool isFromCache}) {
    final engine = _engine;
    if (engine == null) return IpoScreenerResult.empty();
    return engine.evaluate(
      items: _resolved,
      prices: _prices,
      config: IpoScreenerConfig(
        proximityPct: _settings.settings.proximityPct.toDouble(),
        inBandOnly: _bandOnly,
      ),
      filters: _filters,
      sort: _sort,
      isFromCache: isFromCache,
    );
  }

  // -------------------------------------------------------------------------
  // Filters & sorting (no network)
  // -------------------------------------------------------------------------

  void setFilters(IpoFilters filters) {
    _filters = filters;
    _result = _evaluate(isFromCache: _source != ScreenerSource.live);
    notifyListeners();
  }

  void setQuery(String query) => setFilters(_filters.copyWith(query: query));

  void setExchange(Exchange? exchange) => setFilters(
        exchange == null
            ? _filters.copyWith(clearExchange: true)
            : _filters.copyWith(exchange: exchange),
      );

  void setListingYear(int? year) => setFilters(
        year == null
            ? _filters.copyWith(clearListingYear: true)
            : _filters.copyWith(listingYear: year),
      );

  void toggleLevel(LevelType level) {
    final levels = {..._filters.levels};
    if (!levels.remove(level)) levels.add(level);
    setFilters(_filters.copyWith(levels: levels));
  }

  void setSortMode(IpoSortMode mode) {
    _sort = mode;
    _result = _evaluate(isFromCache: _source != ScreenerSource.live);
    notifyListeners();
  }

  void clearFilters() {
    _bandOnly = true; // back to the spec view
    setFilters(const IpoFilters());
  }

  /// Lifts (or restores) the ±band filter — the "All screened" chip.
  void setBandOnly(bool value) {
    if (_bandOnly == value) return;
    _bandOnly = value;
    _result = _evaluate(isFromCache: _source != ScreenerSource.live);
    notifyListeners();
  }

  /// Hides the notice banner (the reason it described may still hold).
  /// Recomputes how many rows still lack a listing-day range.
  Future<void> _refreshLevelsCount() async {
    _levelsPending = await _ipoDao.countAwaitingLevels();
  }

  /// Fetches listing-day high/low for the rows that do not have them yet.
  ///
  /// [all] = keep going until every row is done (the explicit button); the
  /// default is one small batch, which is what the automatic pass uses.
  Future<void> fetchListingLevels({bool all = false}) async {
    final service = _levels;
    if (service == null || _isFetchingLevels) return;
    if (!_auth.isLoggedIn) {
      _notice = ScreenerNotice.loggedOut;
      notifyListeners();
      return;
    }

    _isFetchingLevels = true;
    _levelsDone = 0;
    _levelsTotal = all ? _levelsPending : (_levelsPending < 25 ? _levelsPending : 25);
    notifyListeners();

    try {
      final result = all
          ? await service.fetchAllPending(
              onProgress: (done, total) {
                _levelsDone = done;
                _levelsTotal = total;
                notifyListeners();
              },
              shouldStop: () => _disposed,
            )
          : await service.fetchPending(
              onProgress: (done, total) {
                _levelsDone = done;
                _levelsTotal = total;
                notifyListeners();
              },
              shouldStop: () => _disposed,
            );

      if (_disposed) return;
      await _refreshLevelsCount();
      if (result.updated > 0 || result.missing > 0) {
        // Rows just became screenable: re-resolve, re-price and re-evaluate so
        // the new levels show up immediately instead of on the next scan.
        await _loadRowsAndResolve();
        _result = _evaluate(isFromCache: _source != ScreenerSource.live);
        await refresh(force: false, silent: true);
      }
      if (result.error != null && _notice == null && _prices.isEmpty) {
        _notice = ScreenerNotice.failed;
      }
    } catch (e) {
      _notice = ScreenerNotice.failed;
      _error = 'Could not fetch listing levels: $e';
    } finally {
      _isFetchingLevels = false;
      notifyListeners();
    }
  }

  void dismissNotice() {
    if (_notice == null) return;
    _notice = null;
    notifyListeners();
  }

  /// The rows *closest* to a level even when none is inside the band — lets the
  /// empty state show real numbers instead of a bare "nothing found".
  List<IpoMatch> nearestOutsideBand({int limit = 5}) {
    final engine = _engine;
    if (engine == null || _prices.isEmpty) return const [];
    final out = engine.evaluate(
      items: _resolved,
      prices: _prices,
      config: IpoScreenerConfig(
        proximityPct: proximityPct,
        inBandOnly: false,
      ),
      filters: _filters,
      sort: IpoSortMode.closest,
      isFromCache: _source != ScreenerSource.live,
    );
    return out.matches
        .where((m) => !m.isInBand)
        .take(limit)
        .toList(growable: false);
  }

  /// Hides the error banner without discarding the data behind it.
  bool _disposed = false;

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }

  void clearError() {
    _error = null;
    if (_source == ScreenerSource.error) {
      _source = _prices.isEmpty ? ScreenerSource.none : ScreenerSource.cache;
    }
    notifyListeners();
  }

  /// Re-runs the ±band test with the current settings — used when the proximity
  /// slider in the filter sheet moves (prices stay as they are, no network call).
  void reapplyConfig() {
    _result = _evaluate(isFromCache: _source != ScreenerSource.live);
    notifyListeners();
  }

  // -------------------------------------------------------------------------
  // Database editing (add / edit / delete / import)
  // -------------------------------------------------------------------------

  /// Inserts or updates a row and re-screens with the prices already in hand.
  Future<void> saveIpo(Ipo ipo) async {
    if (ipo.id == null) {
      await _ipoDao.insert(ipo);
    } else {
      await _ipoDao.update(ipo);
    }
    await _reloadAfterEdit();
  }

  Future<void> deleteIpo(Ipo ipo) async {
    if (ipo.id == null) return;
    await _ipoDao.delete(ipo.id!);
    await _reloadAfterEdit();
  }

  /// Bulk import from a CSV the user picked (same column layout as the seed).
  Future<IpoImportReport> importCsvText(String csvText) async {
    final report = await _ipoDao.seedFromCsv(csvText, overwrite: true);
    await _reloadAfterEdit();
    return report;
  }

  /// Wipes the table and re-seeds the bundled list.
  Future<void> resetDatabase({bool keepUserAdded = true}) async {
    await _ipoDao.deleteAll(keepUserAdded: keepUserAdded);
    await seedFromAsset();
    await _reloadAfterEdit();
  }

  Future<void> _reloadAfterEdit() async {
    await _loadRowsAndResolve();
    _result = _evaluate(isFromCache: _source != ScreenerSource.live);
    notifyListeners();
  }

  /// All rows (used by the "manage database" screen).
  Future<List<Ipo>> allRows() => _ipoDao.all();

  /// Exports the full IPO table as CSV text — re-importable on another phone
  /// and in the same column order as the bundled seed file.
  Future<String> exportCsv() async {
    final rows = await _ipoDao.all();
    return CsvCodec.encode([
      const [
        'Symbol',
        'Company Name',
        'Exchange',
        'Listing Date',
        'Listing High',
        'Listing Low',
        'Sector',
        'Notes',
      ],
      ...rows.map((i) => [
            i.symbol,
            i.companyName,
            i.exchange.code,
            Fmt.isoDate(i.listingDate),
            i.listingHigh.toStringAsFixed(2),
            i.listingLow.toStringAsFixed(2),
            i.sector,
            i.notes,
          ]),
    ]);
  }
}
