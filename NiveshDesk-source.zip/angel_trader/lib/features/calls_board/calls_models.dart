// ---------------------------------------------------------------------------
// calls_models.dart — Options Calls Board (1.5.71): data shapes.
//
// A standalone module (F&O ke bahar) that follows buy/sell calls posted in
// user-added public Telegram channels: capture → paper-track (SL/target) →
// channel-wise accuracy scoreboard.
// ---------------------------------------------------------------------------

/// Lifecycle of one followed call. Outcomes are mechanical — SL/target from
/// the call's own numbers, nothing guessed.
enum CallStatus {
  open('Open', '🟡'),
  target1('Target 1 ✅', '🎯'),
  target2('Target 2 ✅', '🏆'),
  sl('SL hit ❌', '🛑'),
  expired('Expired ⏳', '⌛');

  const CallStatus(this.label, this.emoji);
  final String label;
  final String emoji;

  bool get isWin => this == target1 || this == target2;
}

enum CallSide {
  buy('BUY', '🟢'),
  sell('SELL', '🔴');

  const CallSide(this.label, this.emoji);
  final String label;
  final String emoji;
}

enum CallKind {
  option('Option'),
  equity('Equity'),
  future('Future');

  const CallKind(this.label);
  final String label;
}

/// One captured call (a parsed Telegram message), tracked over its life.
class CallRecord {
  CallRecord({
    required this.id,
    required this.channel,
    required this.msgId,
    required this.ts,
    required this.rawText,
    required this.symbol,
    required this.kind,
    this.optionType = '',
    this.strike,
    this.expiryLabel = '',
    required this.side,
    this.entry,
    this.sl,
    this.target1,
    this.target2,
    required this.status,
    this.exitPrice,
    this.exitTs,
    this.points,
    this.note = '',
    this.lastLtp,
  });

  final int id;
  final String channel;
  final String msgId;
  final DateTime ts;
  final String rawText;

  /// Upper-case underlying (NIFTY, BANKNIFTY, RELIANCE…).
  final String symbol;
  final CallKind kind;

  /// CE / PE for options, '' otherwise.
  final String optionType;
  final double? strike;
  final String expiryLabel;
  final CallSide side;

  /// Call ke apne numbers. Null = message me nahi tha (honest).
  final double? entry;
  final double? sl;
  final double? target1;
  final double? target2;

  CallStatus status;
  double? exitPrice;
  DateTime? exitTs;

  /// (+) points for a win, (−) for a loss — sell side mirrored.
  double? points;

  /// Parse note / tracking note — 'entry auto (LTP)', 'future track nahi', etc.
  final String note;

  /// Last live LTP seen while open (display only).
  double? lastLtp;

  String get instrumentLabel {
    switch (kind) {
      case CallKind.option:
        return '$symbol ${strike?.toStringAsFixed(0) ?? '—'} $optionType';
      case CallKind.equity:
        return symbol;
      case CallKind.future:
        return '$symbol FUT';
    }
  }
}

/// One user-added Telegram channel.
class ChannelRecord {
  ChannelRecord({
    required this.handle,
    required this.addedAt,
    this.enabled = true,
    this.lastError,
  });

  final String handle;
  final DateTime addedAt;
  bool enabled;
  String? lastError;

  String get title => '@$handle';
}

/// Per-channel accuracy — the scoreboard row.
class ChannelStats {
  const ChannelStats({
    required this.handle,
    required this.total,
    required this.open,
    required this.wins,
    required this.losses,
    required this.expired,
    required this.avgPoints,
  });

  final String handle;
  final int total;
  final int open;
  final int wins;
  final int losses;
  final int expired;
  final double avgPoints;

  /// Closed calls = wins + losses + expired.
  int get closed => wins + losses + expired;

  /// Win% over CLOSED calls — a tiny sample must not look like genius.
  double? get winPct => closed == 0 ? null : wins / closed * 100;

  /// Below 10 closed calls the % is noise; the UI says so.
  bool get smallSample => closed < 10;
}
