// ---------------------------------------------------------------------------
// calls_dao.dart — Options Calls Board (1.5.71) persistence.
//
// Two tables (DB v16):
//   * calls_channels — user-added public Telegram channels (handle, enabled).
//   * option_calls   — one row per parsed call, unique per (channel, msg_id)
//                      so rescans never duplicate. Outcomes update in place.
// ---------------------------------------------------------------------------

import 'package:sqflite/sqflite.dart';

import '../../data/local/app_database.dart';
import 'calls_models.dart';

class CallsDao {
  CallsDao(this._db);

  final AppDatabase _db;

  // -- channels ------------------------------------------------------------

  Future<void> addChannel(String handle) async {
    final db = await _db.database;
    await db.insert(
      AppDatabase.tableCallsChannels,
      {
        'handle': handle,
        'added_at': DateTime.now().toIso8601String(),
        'enabled': 1,
      },
      conflictAlgorithm: ConflictAlgorithm.ignore,
    );
  }

  Future<void> removeChannel(String handle) async {
    final db = await _db.database;
    await db.delete(
      AppDatabase.tableCallsChannels,
      where: 'handle = ?',
      whereArgs: [handle],
    );
  }

  Future<void> setChannelEnabled(String handle, bool enabled) async {
    final db = await _db.database;
    await db.update(
      AppDatabase.tableCallsChannels,
      {'enabled': enabled ? 1 : 0},
      where: 'handle = ?',
      whereArgs: [handle],
    );
  }

  Future<void> setChannelError(String handle, String? error) async {
    final db = await _db.database;
    await db.update(
      AppDatabase.tableCallsChannels,
      {'last_error': error},
      where: 'handle = ?',
      whereArgs: [handle],
    );
  }

  Future<List<ChannelRecord>> listChannels() async {
    final db = await _db.database;
    final rows = await db.query(
      AppDatabase.tableCallsChannels,
      orderBy: 'added_at ASC',
    );
    return [
      for (final r in rows)
        ChannelRecord(
          handle: '${r['handle']}',
          addedAt:
              DateTime.tryParse('${r['added_at']}') ?? DateTime.now(),
          enabled: (r['enabled'] as num? ?? 1) != 0,
          lastError: r['last_error'] as String?,
        ),
    ];
  }

  // -- calls ---------------------------------------------------------------

  /// Inserts new calls; (channel, msg_id) unique — returns how many were NEW.
  Future<int> insertCalls(List<CallRecord> calls) async {
    if (calls.isEmpty) return 0;
    final db = await _db.database;
    var added = 0;
    final batch = db.batch();
    for (final c in calls) {
      batch.insert(
        AppDatabase.tableOptionCalls,
        _toRow(c),
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
    }
    final results = await batch.commit(noResult: false, continueOnError: true);
    for (final r in results) {
      if (r is int && r > 0) added++;
    }
    return added;
  }

  Future<void> updateOutcome({
    required int id,
    required CallStatus status,
    double? exitPrice,
    DateTime? exitTs,
    double? points,
    double? lastLtp,
  }) async {
    final db = await _db.database;
    await db.update(
      AppDatabase.tableOptionCalls,
      {
        'status': status.name,
        'exit_price': exitPrice,
        'exit_ts': exitTs?.toIso8601String(),
        'points': points,
        'last_ltp': lastLtp,
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> saveLastLtp(int id, double ltp) async {
    final db = await _db.database;
    await db.update(
      AppDatabase.tableOptionCalls,
      {'last_ltp': ltp},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<List<CallRecord>> latestCalls({int limit = 300}) async {
    final db = await _db.database;
    final rows = await db.query(
      AppDatabase.tableOptionCalls,
      orderBy: 'ts DESC',
      limit: limit,
    );
    return [for (final r in rows) _fromRow(r)];
  }

  Future<List<CallRecord>> openCalls() async {
    final db = await _db.database;
    final rows = await db.query(
      AppDatabase.tableOptionCalls,
      where: "status = 'open'",
      orderBy: 'ts DESC',
    );
    return [for (final r in rows) _fromRow(r)];
  }

  /// Per-channel scoreboard rows, closed-call stats only.
  Future<List<ChannelStats>> channelStats() async {
    final db = await _db.database;
    final rows = await db.rawQuery('''
      SELECT channel,
             COUNT(*) AS total,
             SUM(CASE WHEN status = 'open' THEN 1 ELSE 0 END) AS open_n,
             SUM(CASE WHEN status IN ('target1','target2') THEN 1 ELSE 0 END) AS wins,
             SUM(CASE WHEN status = 'sl' THEN 1 ELSE 0 END) AS losses,
             SUM(CASE WHEN status = 'expired' THEN 1 ELSE 0 END) AS expired_n,
             AVG(points) AS avg_pts
      FROM ${AppDatabase.tableOptionCalls}
      GROUP BY channel
      ORDER BY avg_pts DESC
    ''');
    return [
      for (final r in rows)
        ChannelStats(
          handle: '${r['channel']}',
          total: (r['total'] as num? ?? 0).toInt(),
          open: (r['open_n'] as num? ?? 0).toInt(),
          wins: (r['wins'] as num? ?? 0).toInt(),
          losses: (r['losses'] as num? ?? 0).toInt(),
          expired: (r['expired_n'] as num? ?? 0).toInt(),
          avgPoints: (r['avg_pts'] as num? ?? 0).toDouble(),
        ),
    ];
  }

  // -- row maps ------------------------------------------------------------

  static Map<String, Object?> _toRow(CallRecord c) => {
        'channel': c.channel,
        'msg_id': c.msgId,
        'ts': c.ts.toIso8601String(),
        'raw_text': c.rawText,
        'symbol': c.symbol,
        'kind': c.kind.name,
        'option_type': c.optionType,
        'strike': c.strike,
        'expiry_label': c.expiryLabel,
        'side': c.side.name,
        'entry': c.entry,
        'sl': c.sl,
        'target1': c.target1,
        'target2': c.target2,
        'status': c.status.name,
        'exit_price': c.exitPrice,
        'exit_ts': c.exitTs?.toIso8601String(),
        'points': c.points,
        'note': c.note,
        'last_ltp': c.lastLtp,
      };

  static CallRecord _fromRow(Map<String, Object?> r) => CallRecord(
        id: (r['id'] as num? ?? 0).toInt(),
        channel: '${r['channel']}',
        msgId: '${r['msg_id']}',
        ts: DateTime.tryParse('${r['ts']}') ?? DateTime.now(),
        rawText: '${r['raw_text'] ?? ''}',
        symbol: '${r['symbol']}',
        kind: CallKind.values.firstWhere(
          (k) => k.name == '${r['kind']}',
          orElse: () => CallKind.equity,
        ),
        optionType: '${r['option_type'] ?? ''}',
        strike: (r['strike'] as num?)?.toDouble(),
        expiryLabel: '${r['expiry_label'] ?? ''}',
        side: '${r['side']}' == 'sell' ? CallSide.sell : CallSide.buy,
        entry: (r['entry'] as num?)?.toDouble(),
        sl: (r['sl'] as num?)?.toDouble(),
        target1: (r['target1'] as num?)?.toDouble(),
        target2: (r['target2'] as num?)?.toDouble(),
        status: CallStatus.values.firstWhere(
          (s) => s.name == '${r['status']}',
          orElse: () => CallStatus.open,
        ),
        exitPrice: (r['exit_price'] as num?)?.toDouble(),
        exitTs: r['exit_ts'] == null ? null : DateTime.tryParse('${r['exit_ts']}'),
        points: (r['points'] as num?)?.toDouble(),
        note: '${r['note'] ?? ''}',
        lastLtp: (r['last_ltp'] as num?)?.toDouble(),
      );
}
