// ---------------------------------------------------------------------------
// calls_provider.dart — Options Calls Board (1.5.71) state.
//
// A standalone module (F&O ke bahar): user adds public Telegram channel links
// (jitne chahe), the board polls `t.me/s/` previews, parses buy/sell calls,
// paper-follows them (SL/target/expiry — never auto-trades), and scores each
// channel by accuracy. Missing data stays missing: an unparseable message is
// skipped, a future call is shown but honestly not tracked.
// ---------------------------------------------------------------------------

import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../data/local/dao/fno_contract_dao.dart';
import '../../data/remote/dto/quote.dart';
import '../../data/remote/dto/scrip.dart';
import '../../services/scrip_master_service.dart';
import '../alerts/alerts_center.dart';
import '../../services/study_market_data.dart';
import '../fno/news/news_service.dart';
import 'calls_dao.dart';
import 'calls_models.dart';
import 'calls_parsers.dart';

/// Mechanical outcome of one open call at one LTP. SL wins ties (a gap that
/// blows through both sides is classified as the loss — conservative).
class CallOutcome {
  const CallOutcome({required this.status, required this.exitPrice, this.points});

  final CallStatus status;
  final double exitPrice;
  final double? points;
}

CallOutcome classifyOutcome({
  required CallSide side,
  required double entry,
  required double sl,
  double? target1,
  double? target2,
  required double ltp,
  required int daysHeld,
  int maxDays = 5,
}) {
  double pts(double exit) =>
      side == CallSide.buy ? exit - entry : entry - exit;
  final isBuy = side == CallSide.buy;

  if (sl > 0) {
    final slHit = isBuy ? ltp <= sl : ltp >= sl;
    if (slHit) {
      return CallOutcome(
        status: CallStatus.sl,
        exitPrice: sl,
        points: pts(sl),
      );
    }
  }
  if (target2 != null && target2 > 0) {
    final hit = isBuy ? ltp >= target2 : ltp <= target2;
    if (hit) {
      return CallOutcome(
        status: CallStatus.target2,
        exitPrice: target2,
        points: pts(target2),
      );
    }
  }
  if (target1 != null && target1 > 0) {
    final hit = isBuy ? ltp >= target1 : ltp <= target1;
    if (hit) {
      return CallOutcome(
        status: CallStatus.target1,
        exitPrice: target1,
        points: pts(target1),
      );
    }
  }
  if (daysHeld >= maxDays) {
    return CallOutcome(
      status: CallStatus.expired,
      exitPrice: ltp,
      points: pts(ltp),
    );
  }
  return CallOutcome(status: CallStatus.open, exitPrice: ltp, points: null);
}

class CallsProvider extends ChangeNotifier {
  CallsProvider({
    required CallsDao dao,
    required FnoContractDao contracts,
    required StudyMarketData marketData,
    required ScripMasterService scripMaster,
    NewsService? news,
    DateTime Function()? clock,
  })  : _dao = dao,
        _contracts = contracts,
        _marketData = marketData,
        _scripMaster = scripMaster,
        _news = news ?? NewsService(),
        _clock = clock ?? DateTime.now;

  final CallsDao _dao;
  final FnoContractDao _contracts;
  final StudyMarketData _marketData;
  final ScripMasterService _scripMaster;
  final NewsService _news;
  final DateTime Function() _clock;

  List<ChannelRecord> channels = [];
  List<CallRecord> calls = [];
  List<ChannelStats> stats = [];

  bool scanning = false;
  bool tracking = false;
  String? note;
  DateTime? lastScan;
  DateTime? lastTrack;
  Timer? _timer;

  Future<void> init() async {
    await _reload();
    notifyListeners();
  }

  Future<void> _reload() async {
    channels = await _dao.listChannels();
    calls = await _dao.latestCalls();
    stats = await _dao.channelStats();
  }

  /// Har 5 min: channel scan + open-call tracking (sirf jab channels ho).
  void startAuto() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(minutes: 5), (_) {
      if (!scanning && !tracking && channels.any((c) => c.enabled)) {
        scanAll();
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  // -- channels ------------------------------------------------------------

  /// Adds a channel from any link form (`https://t.me/xyz`, `@xyz`, `xyz`).
  /// Validates with one real fetch before saving — galat link DB me nahi.
  Future<String?> addChannel(String linkOrHandle) async {
    final handle = normalizeChannelLink(linkOrHandle);
    if (handle == null) {
      return 'Link sahi nahi — https://t.me/<channel> form me daalo.';
    }
    if (channels.any((c) => c.handle == handle)) {
      return 'Ye channel pehle se list me hai.';
    }
    final fetched = await _news.fetchTelegramChannel(handle);
    if (fetched.error != null && fetched.posts.isEmpty) {
      return 'Channel nahi mila ($handle) — public hona chahiye, '
          'link check karo.';
    }
    await _dao.addChannel(handle);
    await _reload();
    notifyListeners();
    // Naya channel: abhi ka backlog bhi capture karo.
    unawaited(scanAll());
    return null;
  }

  Future<void> removeChannel(String handle) async {
    await _dao.removeChannel(handle);
    await _reload();
    notifyListeners();
  }

  Future<void> setEnabled(String handle, bool enabled) async {
    await _dao.setChannelEnabled(handle, enabled);
    await _reload();
    notifyListeners();
  }

  // -- scanning (capture) --------------------------------------------------

  /// Fetches every enabled channel's recent posts; NEW parseable calls land in
  /// the board. Returns a human summary line.
  Future<String> scanAll() async {
    if (scanning) return 'Scan chal raha hai…';
    scanning = true;
    note = 'Channels check ho rahe hain…';
    notifyListeners();
    var newCalls = 0;
    try {
      for (final ch in channels.where((c) => c.enabled)) {
        final fetched = await _news.fetchTelegramChannel(ch.handle);
        if (fetched.error != null && fetched.posts.isEmpty) {
          await _dao.setChannelError(ch.handle, fetched.error);
          continue;
        }
        await _dao.setChannelError(ch.handle, null);
        final drafts = <CallRecord>[];
        for (final post in fetched.posts) {
          final draft = parseCallMessage(post.text);
          if (draft == null) continue;
          drafts.add(CallRecord(
            id: 0,
            channel: ch.handle,
            msgId: post.messageId,
            ts: post.published ?? _clock(),
            rawText: post.text,
            symbol: draft.symbol,
            kind: switch (draft.kind) {
              'option' => CallKind.option,
              'future' => CallKind.future,
              _ => CallKind.equity,
            },
            optionType: draft.optionType,
            strike: draft.strike,
            expiryLabel: draft.expiryLabel,
            side: draft.side == 'sell' ? CallSide.sell : CallSide.buy,
            entry: draft.entry,
            sl: draft.sl,
            target1: draft.target1,
            target2: draft.target2,
            status: CallStatus.open,
            note: draft.note,
          ));
        }
        newCalls += await _dao.insertCalls(drafts);
      }
      lastScan = _clock();
      note = newCalls > 0
          ? '$newCalls nayi calls mili.'
          : 'Koi nayi call nahi — sab pehle se captured.';
    } catch (e) {
      note = 'Scan fail — network check karo.';
    } finally {
      scanning = false;
      await _reload();
      notifyListeners();
    }
    return note ?? '';
  }

  // -- tracking (follow) ---------------------------------------------------

  /// Resolves open calls to live quotes and applies [classifyOutcome].
  /// Options = contract book (exact strike), equity = scrip master. Futures
  /// are honestly NOT tracked (no future token in the book).
  Future<void> trackNow() async {
    if (tracking) return;
    tracking = true;
    notifyListeners();
    try {
      final open = await _dao.openCalls();
      final scripByCallId = <int, Scrip>{};
      for (final call in open) {
        if (call.kind == CallKind.future) continue;
        try {
          if (call.kind == CallKind.option) {
            final contract = await _findOption(
                call.symbol, call.strike ?? 0, call.optionType);
            if (contract != null) scripByCallId[call.id] = contract.asScrip();
          } else {
            final scrip =
                (await _scripMaster.resolver()).resolve(call.symbol).scrip;
            if (scrip != null && scrip.token.isNotEmpty) {
              scripByCallId[call.id] = scrip;
            }
          }
        } catch (_) {
          // Resolve fail = this call waits for the next tick.
        }
      }
      var quotes = <String, MarketQuote>{};
      if (scripByCallId.isNotEmpty) {
        try {
          quotes =
              await _marketData.fetchQuotesFull([for (final s in scripByCallId.values) s]);
        } catch (_) {
          // Quote fail = honest stale board, no fake prices.
        }
      }
      final now = _clock();
      for (final call in open) {
        final scrip = scripByCallId[call.id];
        if (scrip == null) continue;
        final q = quotes[scrip.token];
        if (q == null) continue;
        final ltp = q.ltp;
        if (ltp <= 0) continue;
        final entry = call.entry ?? ltp;
        final daysHeld =
            now.difference(call.ts).inHours / 24.0;
        final outcome = classifyOutcome(
          side: call.side,
          entry: entry,
          sl: call.sl ?? 0,
          target1: call.target1,
          target2: call.target2,
          ltp: ltp,
          daysHeld: daysHeld.ceil(),
        );
        if (outcome.status == CallStatus.open) {
          await _dao.saveLastLtp(call.id, ltp);
        } else {
          // 1.5.74 — outcome resolve = notification (SL/target/expired).
          AlertsCenter.instance.raise(
            kind: AlertKind.callOutcome,
            symbol: call.symbol,
            title: '${outcome.status.emoji} ${call.symbol} — '
                '${outcome.status.label}',
            body: '${call.side.label} ${call.symbol}'
                '${call.kind == CallKind.option ? ' ${call.strike}${call.optionType}' : ''} '
                '— LTP ₹${ltp.toStringAsFixed(2)}, exit '
                '₹${outcome.exitPrice.toStringAsFixed(2)}'
                '${outcome.points != null ? ', ${outcome.points! >= 0 ? '+' : ''}${outcome.points!.toStringAsFixed(2)} pts' : ''}. '
                'Details Calls Board me.',
          );
          await _dao.updateOutcome(
            id: call.id,
            status: outcome.status,
            exitPrice: outcome.exitPrice,
            exitTs: now,
            points: outcome.points,
            lastLtp: ltp,
          );
        }
      }
      lastTrack = _clock();
      note = 'Tracking update — SL/target abhi ke rates pe.';
    } catch (_) {
      note = 'Tracking fail — purana data dikha rahe hain.';
    } finally {
      tracking = false;
      await _reload();
      notifyListeners();
    }
  }

  /// Nearest-expiry strike match in the local contract book; null = honestly
  /// untracked (book me nahi).
  Future<FnoContract?> _findOption(
      String underlying, double strike, String optionType) async {
    if (strike <= 0 || optionType.isEmpty) return null;
    final expiries = await _contracts.expiries(underlying);
    for (final expiry in expiries) {
      final c = await _contracts.contract(
        underlying: underlying,
        expiry: expiry,
        strike: strike,
        optionType: optionType,
      );
      if (c != null) return c;
    }
    return null;
  }
}
