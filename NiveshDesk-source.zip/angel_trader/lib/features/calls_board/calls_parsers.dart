// ---------------------------------------------------------------------------
// calls_parsers.dart — Telegram call-message → CallDraft (pure).
//
// Public call channels post free text in their own dialects. This parses the
// common Indian formats; a message that does not look like a call returns
// null (skipped honestly — never guessed):
//
//   NIFTY 25500 CE BUY ABOVE 120 SL 90 TGT 150/180
//   BUY NIFTY 25500 CE @120 SL 90 TARGET 150, 180
//   25500 pe sell at 80 sl 110 target 50/30
//   RELIANCE FUT BUY @2450 SL 2400 TGT 2600
//   BUY RELIANCE 2450 SL 2400 T1 2600 T2 2700
// ---------------------------------------------------------------------------

/// Parsed call — before it becomes a tracked [CallRecord].
class CallDraft {
  const CallDraft({
    required this.symbol,
    required this.kind,
    this.optionType = '',
    this.strike,
    this.expiryLabel = '',
    required this.side,
    this.entry,
    this.sl,
    this.target1,
    this.target2,
    this.note = '',
  });

  final String symbol;
  final String kind; // 'option' | 'equity' | 'future'
  final String optionType;
  final double? strike;
  final String expiryLabel;
  final String side; // 'buy' | 'sell'
  final double? entry;
  final double? sl;
  final double? target1;
  final double? target2;
  final String note;

  @override
  String toString() => 'CallDraft($symbol $strike $optionType $side '
      '@$entry SL $sl TGT $target1/$target2)';
}

/// Words that can never be the instrument name.
const Set<String> _stopWords = {
  'buy', 'sell', 'long', 'short', 'above', 'below', 'only', 'wait', 'book',
  'profit', 'loss', 'partial', 'full', 'exit', 'close', 'tgt', 'target',
  'targets', 'sl', 'stop', 'stoploss', 'entry', 'cmp', 'ltp', 'at',
  'now', 'immediate', 'immediately', 'fresh', 'new', 'update', 'levels',
  'level', 'zone', 'crossed', 'hits', 'hit', 'running', 'achieved', 'done',
  'call', 'put', 'fut', 'future', 'futures', 'eq', 'cash', 'spot', 'mone',
  'inthe', 'the', 'and', 'for', 'with', 'from', 't1', 't2', 't3', 'no',
  'trail', 'trailing', 'keep', 'holding', 'hold', 'booked', 'closed',
};

final RegExp _strikeRe = RegExp(
  r'(\d{3,7}(?:\.\d+)?)\s*(ce|pe|call|put)\b',
  caseSensitive: false,
);
final RegExp _sideRe = RegExp(r'\b(buy|long|sell|short)\b', caseSensitive: false);
final RegExp _slRe = RegExp(
  r'\b(?:sl|stoploss|stop\s*loss)\s*(?:@|:|is|of|at)?\s*(\d+(?:\.\d+)?)',
  caseSensitive: false,
);
final RegExp _tgtRe = RegExp(
  r'\b(?:tgts?|target\s*[12]?(?!\d)|goals?)\s*(?:@|:|is|of|at)?\s*'
  r'(\d+(?:\.\d+)?)(?:\s*[/,x×+-]\s*(\d+(?:\.\d+)?))?',
  caseSensitive: false,
);
final RegExp _t12Re = RegExp(
  r'\bt1\s*(?:@|:|is)?\s*(\d+(?:\.\d+)?).*?\bt2\s*(?:@|:|is)?\s*(\d+(?:\.\d+)?)',
  caseSensitive: false,
);
final RegExp _futRe = RegExp(r'\b(fut|futures?)\b', caseSensitive: false);
final RegExp _expiryRe = RegExp(
  r'\b(\d{1,2})\s*(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\w*',
  caseSensitive: false,
);

/// Parses one message into a [CallDraft]; null = not a parseable call.
CallDraft? parseCallMessage(String text) {
  final raw = text.replaceAll(RegExp(r'[\u200b\ufeff]'), ' ').trim();
  if (raw.isEmpty) return null;

  // EXIT / BOOK PROFIT messages are follow-ups, not new calls.
  final lower = raw.toLowerCase();
  if (RegExp(r'\b(exit|book(ed)?\s*(profit|loss)|close(d)?\s*(at|now)?)\b')
          .hasMatch(lower) &&
      !_sideRe.hasMatch(lower)) {
    return null;
  }

  final sideM = _sideRe.firstMatch(lower);
  if (sideM == null) return null;
  final side = (sideM.group(1) == 'buy' || sideM.group(1) == 'long')
      ? 'buy'
      : 'sell';

  // -- instrument ----------------------------------------------------------
  String symbol = '';
  String kind = 'equity';
  String optionType = '';
  double? strike;
  var expiryLabel = '';

  final strikeM = _strikeRe.firstMatch(lower);
  if (strikeM != null) {
    kind = 'option';
    strike = double.tryParse(strikeM.group(1)!);
    final t = strikeM.group(2)!;
    optionType = (t == 'ce' || t == 'call') ? 'CE' : 'PE';
    symbol = _symbolBefore(lower, strikeM.start);
  } else if (_futRe.hasMatch(lower)) {
    kind = 'future';
    final futM = _futRe.firstMatch(lower)!;
    symbol = _symbolBefore(lower, futM.start);
    if (symbol.isEmpty) symbol = _symbolAfter(lower, futM.end);
  } else {
    // Equity: word next to the side keyword.
    symbol = _symbolBefore(lower, sideM.start);
    if (symbol.isEmpty) symbol = _symbolAfter(lower, sideM.end);
  }
  symbol = symbol.toUpperCase();
  if (symbol.isEmpty) return null;
  if (symbol == 'TGT' || symbol == 'SL') return null;

  final expM = _expiryRe.firstMatch(lower);
  if (expM != null) {
    expiryLabel = '${expM.group(1)} ${expM.group(2)!.toUpperCase()}';
  }

  // -- prices --------------------------------------------------------------
  // SL/TGT segments nikaal do — unke numbers entry na ban jayein.
  final cleaned = lower
      .replaceAll(_slRe, ' ')
      .replaceAll(_t12Re, ' ')
      .replaceAll(_tgtRe, ' ');
  double? entry;
  final atM = RegExp(r'@\s*(\d+(?:\.\d+)?)').firstMatch(cleaned);
  if (atM != null) {
    entry = double.tryParse(atM.group(1)!);
  } else {
    // Side ke baad pehla number = entry; option ka strike number skip.
    final sideText = sideM.group(0)!;
    final sideIdx = cleaned.indexOf(sideText);
    final after = cleaned.substring(sideIdx + sideText.length);
    for (final m in RegExp(r'(\d+(?:\.\d+)?)').allMatches(after)) {
      final v = double.tryParse(m.group(1)!);
      if (v == null) continue;
      if (kind == 'option' && strike != null && v == strike) continue;
      entry = v;
      break;
    }
  }
  final slM = _slRe.firstMatch(lower);
  final sl = slM == null ? null : double.tryParse(slM.group(1)!);

  double? target1;
  double? target2;
  final t12M = _t12Re.firstMatch(lower);
  if (t12M != null) {
    target1 = double.tryParse(t12M.group(1)!);
    target2 = double.tryParse(t12M.group(2)!);
  } else {
    final tgtM = _tgtRe.firstMatch(lower);
    if (tgtM != null) {
      target1 = double.tryParse(tgtM.group(1)!);
      target2 =
          tgtM.group(2) == null ? null : double.tryParse(tgtM.group(2)!);
    }
  }

  // Side + instrument hai, kam se kam ek price chahiye (warna follow kya?).
  if (entry == null && sl == null && target1 == null) return null;

  final notes = <String>[
    if (entry == null) 'entry auto (LTP)',
    if (kind == 'future') 'future — tracking unavailable',
  ];

  return CallDraft(
    symbol: symbol,
    kind: kind,
    optionType: optionType,
    strike: strike,
    expiryLabel: expiryLabel,
    side: side,
    entry: entry,
    sl: sl,
    target1: target1,
    target2: target2,
    note: notes.join(' · '),
  );
}

/// The word just before [pos], skipping stop words (punctuation stripped).
String _symbolBefore(String lower, int pos) {
  final before = lower.substring(0, pos).trim();
  if (before.isEmpty) return '';
  final words = before
      .split(RegExp(r'[^a-z0-9&]+'))
      .where((w) => w.isNotEmpty)
      .toList();
  for (var i = words.length - 1; i >= 0; i--) {
    final w = words[i];
    if (_stopWords.contains(w)) continue;
    if (RegExp(r'^\d').hasMatch(w)) continue;
    return w;
  }
  return '';
}

String _symbolAfter(String lower, int pos) {
  final after = lower.substring(pos).trim();
  final words = after
      .split(RegExp(r'[^a-z0-9&]+'))
      .where((w) => w.isNotEmpty)
      .toList();
  for (final w in words) {
    if (_stopWords.contains(w)) continue;
    if (RegExp(r'^\d').hasMatch(w)) continue;
    return w;
  }
  return '';
}

/// `https://t.me/s/xyz`, `t.me/xyz`, `@xyz`, `xyz` → `xyz`; null = invalid.
String? normalizeChannelLink(String input) {
  var s = input.trim();
  s = s.replaceAll(RegExp(r'^https?://'), '');
  s = s.replaceAll(RegExp(r'^(www\.)?t\.me/'), '');
  s = s.replaceAll(RegExp(r'^t\.me/'), '');
  s = s.replaceAll(RegExp(r'^s/'), '');
  s = s.replaceAll(RegExp(r'^@'), '');
  s = s.split(RegExp(r'[/?#\s]')).first;
  if (!RegExp(r'^[A-Za-z0-9_]{4,}$').hasMatch(s)) return null;
  return s.toLowerCase();
}
