// ---------------------------------------------------------------------------
// paper_database_file.dart — poora app DB ek file me (backup / restore).
//
// DO TARAH KI FILE
//   * **ALL (poora DB)** — bilkul wahi file jo app use karta hai (candles,
//     scrip master, settings sab). Badi hoti hai (30–80 MB), isliye WhatsApp
//     se bhejne layak nahi — backup ke liye save karne layak hai.
//   * **Custom date** — chune hue dinon ke trades / positions / orders / groups
//     wali chhoti file. Schema bilkul wahi, par cache taalika khaali.
//
// IMPORT = SIRF JODNA (merge)
//   Purana data kabhi nahi mitta. Jo leg pehle se maujood hai (same symbol +
//   side + qty + price + time) woh chhod di jati hai. Baaki sab jud jata hai.
//   Cache wali taalikayein (scrip master, candles, price cache, settings)
//   chhod di jati hain — woh app khud dobara bana leta hai, aur settings ka
//   overwrite karna khatarnak hota (aapka capital/theme badal jayega).
//
//   Sanjeedagi se: agar file purane app version ki ho (schema alag), to kuch
//   bhi chhue bina saaf message milta hai.
// ---------------------------------------------------------------------------

import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

import '../../core/utils/formatters.dart';
import '../../data/local/app_database.dart';
import 'trade_range.dart';

/// Kin taalikaon ka data file me jata hai / file se aata hai.
const List<String> kPaperFileTables = <String>[
  AppDatabase.tableTradeGroups,
  AppDatabase.tableTrades,
  AppDatabase.tablePositions,
  AppDatabase.tablePaperOrders,
];

/// Jo taalikayein import me jaan-bujhkar chhod di jati hain (cache / settings).
const List<String> kSkippedOnImport = <String>[
  AppDatabase.tableScrips,
  AppDatabase.tableCandles,
  AppDatabase.tablePriceCache,
  AppDatabase.tableScanRuns,
  AppDatabase.tableSettings,
  AppDatabase.tableIpos,
  AppDatabase.tableFnoContracts,
  AppDatabase.tableScripMeta,
  AppDatabase.tableEarnings,
  AppDatabase.tableStudySnapshots,
];

/// Export ke waqt kitni line uthi.
class DbCopyStats {
  const DbCopyStats({
    this.groups = 0,
    this.trades = 0,
    this.positions = 0,
    this.orders = 0,
  });

  final int groups;
  final int trades;
  final int positions;
  final int orders;

  int get total => groups + trades + positions + orders;
}

/// Import ke baad ka hisaab — har taalika ke liye "kitna juda, kitna chhuta".
class DbMergeReport {
  const DbMergeReport({
    required this.groupsAdded,
    required this.groupsMatched,
    required this.tradesAdded,
    required this.tradesSkipped,
    required this.positionsAdded,
    required this.positionsMatched,
    required this.ordersAdded,
    required this.ordersSkipped,
    required this.openPositionsAdded,
    this.rangeLabel = 'Sab (ALL)',
  });

  final int groupsAdded;
  final int groupsMatched;
  final int tradesAdded;
  final int tradesSkipped;
  final int positionsAdded;
  final int positionsMatched;
  final int ordersAdded;
  final int ordersSkipped;

  /// Nayi **khol** (OPEN) position judi — Holdings me double count ka khatra
  /// isi ka hai, isliye alag se ginti.
  final int openPositionsAdded;

  final String rangeLabel;

  int get added =>
      groupsAdded + tradesAdded + positionsAdded + ordersAdded;

  int get skipped =>
      groupsMatched + tradesSkipped + positionsMatched + ordersSkipped;

  bool get isEmpty => added == 0;

  /// Seedha user ko dikhane layak Hinglish saaransh.
  String get message {
    if (isEmpty) {
      return 'Kuch naya nahi mila — file ke sabhi trades pehle se maujood hain '
          '($tradesSkipped duplicate chhode).';
    }
    final buffer = StringBuffer('Jod diya: $tradesAdded naye trade');
    if (positionsAdded > 0) buffer.write(', $positionsAdded position');
    if (ordersAdded > 0) buffer.write(', $ordersAdded order');
    if (groupsAdded > 0) buffer.write(', $groupsAdded group');
    buffer.write('.');
    if (tradesSkipped > 0) {
      buffer.write(' $tradesSkipped duplicate chhode (pehle se the).');
    }
    if (openPositionsAdded > 0) {
      buffer.write(' Dhyan: $openPositionsAdded khuli (OPEN) position bhi judi '
          '— Holdings tab me ek baar dekh lo.');
    }
    buffer.write(' Cache/settings chhode (app khud bana leta hai).');
    return buffer.toString();
  }
}

// ---------------------------------------------------------------------------
// File banaana / padhna
// ---------------------------------------------------------------------------

class PaperDatabaseFile {
  PaperDatabaseFile({
    AppDatabase? database,
    Directory? directory,
    this.now,
  })  : _database = database,
        _directory = directory;

  final AppDatabase? _database;
  final Directory? _directory;

  /// File naam me timestamp ke liye (test me fix kiya ja sake).
  final DateTime Function()? now;

  AppDatabase get _db => _database ?? AppDatabase.instance;

  /// Files app se dikhne layak jagah — wahi directory jahan study ki Excel
  /// jati hai, taaki "file kidhar gayi" ka jawab ek hi ho.
  Future<Directory> _dir() async =>
      _directory ?? await getApplicationDocumentsDirectory();

  // -------------------------------------------------------------------------
  // Export
  // -------------------------------------------------------------------------

  /// **ALL** — poora DB. Source file ki ek achhi (consistent) copy.
  Future<File> exportAll() async {
    final source = await _db.database;
    await source.rawQuery('PRAGMA wal_checkpoint(TRUNCATE)');
    final dir = await _dir();
    final stamp = _stamp();
    final target = p.join(dir.path, 'niveshdesk-db-all-$stamp.db');
    final targetFile = File(target);
    // Ek hi minute me do baar export karne par naam same ho jata hai —
    // VACUUM INTO maujooda file par likh nahi sakta.
    if (await targetFile.exists()) await targetFile.delete();

    // VACUUM INTO deta hai ek saaf, chhoti aur poori copy (SQLite 3.27+).
    // Purane Android par ye chal nahi sakta — tab seedhi copy.
    try {
      await source.execute('VACUUM INTO ?', [target]);
    } catch (_) {
      final current = _db.path;
      if (current == null) {
        throw StateError('DB file ka raasta nahi mila — export nahi ho sakta.');
      }
      await File(current).copy(target);
    }
    return targetFile;
  }

  /// **Custom date** — sirf chune hue dinon ka trading data.
  Future<File> exportRange({
    required TradeRange range,
    required DateTime now,
    int? groupId,
  }) async {
    final source = await _db.database;
    final from = range.resolveFrom(now)?.millisecondsSinceEpoch;
    final to = range.resolveTo(now)?.millisecondsSinceEpoch;

    final dir = await _dir();
    final stamp = _stamp();
    final target = p.join(dir.path, 'niveshdesk-db-${range.fileTag(now)}-$stamp.db');
    final targetFile = File(target);
    if (await targetFile.exists()) await targetFile.delete();

    final copy = await openDatabase(
      target,
      version: AppDatabase.schemaVersion,
      onCreate: (db, version) => AppDatabase.createSchema(db),
    );
    try {
      await copyTradingTables(source: source, target: copy, from: from, to: to);
    } finally {
      await copy.close();
    }
    return targetFile;
  }

  // -------------------------------------------------------------------------
  // Import
  // -------------------------------------------------------------------------

  /// SQLite header — file chunne me extension par bharosa nahi hota.
  static Future<bool> looksLikeSqlite(File file) async {
    if (!await file.exists()) return false;
    final handle = await file.open();
    try {
      final head = await handle.read(16);
      return head.length >= 16 &&
          String.fromCharCodes(head.sublist(0, 15)) == 'SQLite format 3';
    } finally {
      await handle.close();
    }
  }

  /// File padhta hai aur **jodta** hai (kuch mitata nahi).
  ///
  /// [range] sirf is liye hai ki report me likha ja sake "kaunse din".
  /// File me jo kuch hai woh sab padha jata hai.
  Future<DbMergeReport> import({
    required File file,
    TradeRange range = TradeRange.all,
    DateTime? now,
  }) async {
    final target = await _db.database;
    final queryNow = now ?? DateTime.now();

    // File ko cache me lao: file_picker ka raasta thodi der baad mar jata hai
    // (Android ka purana cache), isliye pehle apni jagah copy.
    final dir = await _dir();
    final working = File(p.join(
      dir.path,
      'import-${DateTime.now().microsecondsSinceEpoch}.db',
    ));
    await file.copy(working.path);

    Database? source;
    try {
      source = await openReadOnlyDatabase(working.path);

      final version = (Sqflite.firstIntValue(
                await source.rawQuery('PRAGMA user_version'),
              ) ??
          0);
      if (version != AppDatabase.schemaVersion) {
        throw PaperDatabaseFileException(
          'Ye file is version ke saath match nahi karti '
          '(file schema $version, app ${AppDatabase.schemaVersion}). '
          'Kuch bhi change nahi kiya gaya — same app version se export karo.',
        );
      }
      for (final table in kPaperFileTables) {
        final found = Sqflite.firstIntValue(await source.rawQuery(
          "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=?",
          [table],
        ));
        if (found == 0) {
          throw PaperDatabaseFileException(
            'Ye NiveshDesk ki DB file nahi lagti (andar "$table" taalika nahi '
            'mili). Kuch bhi change nahi kiya gaya.',
          );
        }
      }

      final report = await mergeTradingTables(source: source, target: target);
      return DbMergeReport(
        groupsAdded: report.groupsAdded,
        groupsMatched: report.groupsMatched,
        tradesAdded: report.tradesAdded,
        tradesSkipped: report.tradesSkipped,
        positionsAdded: report.positionsAdded,
        positionsMatched: report.positionsMatched,
        ordersAdded: report.ordersAdded,
        ordersSkipped: report.ordersSkipped,
        openPositionsAdded: report.openPositionsAdded,
        rangeLabel: range.describe(queryNow),
      );
    } finally {
      await source?.close();
      if (await working.exists()) await working.delete();
    }
  }

  String _stamp() {
    final at = now?.call() ?? DateTime.now();
    return '${at.year}${_two(at.month)}${_two(at.day)}-${_two(at.hour)}${_two(at.minute)}';
  }

  static String _two(int value) => value.toString().padLeft(2, '0');
}

/// Insaan ko padhne layak galti (UI seedha dikhata hai).
class PaperDatabaseFileException implements Exception {
  const PaperDatabaseFileException(this.message);

  final String message;

  @override
  String toString() => message;
}

// ---------------------------------------------------------------------------
// Core — do `Database` ke beech ka kaam (test ke liye yahi asli cheez hai)
// ---------------------------------------------------------------------------

/// Chune hue daayre ki taalikayein [source] se [target] me daalta hai.
Future<DbCopyStats> copyTradingTables({
  required Database source,
  required Database target,
  int? from,
  int? to,
}) async {
  final groupIds = <int>{};

  // ---- Trades ------------------------------------------------------------
  final tradeRows = await source.query(
    AppDatabase.tableTrades,
    where: _between('executed_at', from, to),
    whereArgs: _betweenArgs(from, to),
  );
  final positionIds = <int>{};
  for (final row in tradeRows) {
    final group = row['group_id'] as int?;
    if (group != null) groupIds.add(group);
    final position = row['position_id'] as int?;
    if (position != null) positionIds.add(position);
  }

  // ---- Orders (created_at par chhanta hai) --------------------------------
  final orderRows = await source.query(
    AppDatabase.tablePaperOrders,
    where: _between('created_at', from, to),
    whereArgs: _betweenArgs(from, to),
  );
  for (final row in orderRows) {
    final group = row['group_id'] as int?;
    if (group != null) groupIds.add(group);
    final position = row['position_id'] as int?;
    if (position != null) positionIds.add(position);
  }

  // ---- Positions (khulne ka din daayre me hona chahiye) -------------------
  // Range ke *andar* khuli ya band hui dono uthi hain, warna aaj ki khuli
  // position chhoot jayegi.
  final positionRows = await source.rawQuery(
    'SELECT * FROM ${AppDatabase.tablePositions} WHERE '
    '((? IS NULL OR opened_at >= ?) AND (? IS NULL OR opened_at <= ?)) '
    'OR id IN (${_placeholders(positionIds.length)})',
    <Object?>[
      from,
      from,
      to,
      to,
      ...positionIds,
    ],
  );
  for (final row in positionRows) {
    final group = row['group_id'] as int?;
    if (group != null) groupIds.add(group);
  }

  // ---- Groups -------------------------------------------------------------
  final groupRows = groupIds.isEmpty
      ? <Map<String, Object?>>[]
      : await source.rawQuery(
          'SELECT * FROM ${AppDatabase.tableTradeGroups} WHERE id IN '
          '(${_placeholders(groupIds.length)})',
          <Object?>[...groupIds],
        );

  final batch = target.batch();
  for (final row in groupRows) {
    batch.insert(AppDatabase.tableTradeGroups, _withoutId(row));
  }
  for (final row in positionRows) {
    batch.insert(AppDatabase.tablePositions, _withoutId(row));
  }
  for (final row in tradeRows) {
    batch.insert(AppDatabase.tableTrades, _withoutId(row));
  }
  for (final row in orderRows) {
    batch.insert(AppDatabase.tablePaperOrders, _withoutId(row));
  }
  await batch.commit(noResult: true);

  return DbCopyStats(
    groups: groupRows.length,
    trades: tradeRows.length,
    positions: positionRows.length,
    orders: orderRows.length,
  );
}

/// File ki taalikayein [target] me **jodta** hai; kuch mitata nahi.
///
/// Duplicate = same symbol + exchange + side + qty + price (+ time) — woh
/// chhod diya jata hai. Group ka milan naam se hota hai (id alag ho sakti
/// hai), aur trades/positions/orders ki nayi id ke saath purane group se
/// joda jata hai.
Future<DbMergeReport> mergeTradingTables({
  required Database source,
  required Database target,
}) async {
  // ---- 1. Groups (naam se milan) ----------------------------------------
  final existingGroups = await target.query(AppDatabase.tableTradeGroups);
  final nameToId = <String, int>{
    for (final row in existingGroups)
      (row['name'] as String).trim().toLowerCase(): row['id'] as int,
  };
  final groupMap = <int, int>{}; // purani id -> nayi/maujood id
  var groupsAdded = 0;
  var groupsMatched = 0;

  final sourceGroups =
      await source.query(AppDatabase.tableTradeGroups, orderBy: 'id ASC');
  for (final row in sourceGroups) {
    final oldId = row['id'] as int;
    final key = (row['name'] as String).trim().toLowerCase();
    final existing = nameToId[key];
    if (existing != null) {
      groupMap[oldId] = existing;
      groupsMatched++;
      continue;
    }
    final newId = await target.insert(
      AppDatabase.tableTradeGroups,
      _withoutId(row),
      conflictAlgorithm: ConflictAlgorithm.ignore,
    );
    if (newId == 0) {
      // Bahut hi kam: doosri taraf se beech me ban gaya.
      final again = await target.query(
        AppDatabase.tableTradeGroups,
        where: 'name = ? COLLATE NOCASE',
        whereArgs: [row['name']],
        limit: 1,
      );
      if (again.isNotEmpty) {
        groupMap[oldId] = again.first['id'] as int;
        groupsMatched++;
        continue;
      }
      continue;
    }
    groupMap[oldId] = newId;
    nameToId[key] = newId;
    groupsAdded++;
  }

  // ---- 2. Positions ------------------------------------------------------
  final existingPositions = await target.query(
    AppDatabase.tablePositions,
    columns: ['id', 'symbol', 'exchange', 'side', 'quantity', 'avg_price', 'opened_at'],
  );
  final positionKeys = <String>{
    for (final row in existingPositions) _positionKey(row),
  };
  final positionMap = <int, int>{};
  var positionsAdded = 0;
  var positionsMatched = 0;
  var openPositionsAdded = 0;

  final sourcePositions =
      await source.query(AppDatabase.tablePositions, orderBy: 'id ASC');
  for (final row in sourcePositions) {
    final oldId = row['id'] as int;
    final key = _positionKey(row);
    if (positionKeys.contains(key)) {
      final found = await target.query(
        AppDatabase.tablePositions,
        where: 'symbol = ? AND exchange = ? AND side = ? AND quantity = ? '
            'AND opened_at = ?',
        whereArgs: [
          row['symbol'],
          row['exchange'],
          row['side'],
          row['quantity'],
          row['opened_at'],
        ],
        limit: 1,
      );
      if (found.isNotEmpty) {
        positionMap[oldId] = found.first['id'] as int;
        positionsMatched++;
        continue;
      }
    }
    final newId = await target.insert(
      AppDatabase.tablePositions,
      _remap(_withoutId(row), groupMap: groupMap),
    );
    positionMap[oldId] = newId;
    positionKeys.add(key);
    positionsAdded++;
    if ('${row['status']}'.toUpperCase() == 'OPEN') openPositionsAdded++;
  }

  // ---- 3. Trades ---------------------------------------------------------
  final existingTrades = await target.query(
    AppDatabase.tableTrades,
    columns: ['symbol', 'exchange', 'side', 'quantity', 'price', 'executed_at'],
  );
  final tradeKeys = <String>{
    for (final row in existingTrades) _tradeKey(row),
  };
  var tradesAdded = 0;
  var tradesSkipped = 0;

  final sourceTrades =
      await source.query(AppDatabase.tableTrades, orderBy: 'id ASC');
  for (final row in sourceTrades) {
    if (tradeKeys.contains(_tradeKey(row))) {
      tradesSkipped++;
      continue;
    }
    await target.insert(
      AppDatabase.tableTrades,
      _remap(_withoutId(row), groupMap: groupMap, positionMap: positionMap),
    );
    tradeKeys.add(_tradeKey(row));
    tradesAdded++;
  }

  // ---- 4. Orders ---------------------------------------------------------
  final existingOrders = await target.query(
    AppDatabase.tablePaperOrders,
    columns: [
      'symbol',
      'exchange',
      'side',
      'quantity',
      'order_type',
      'limit_price',
      'created_at',
    ],
  );
  final orderKeys = <String>{
    for (final row in existingOrders) _orderKey(row),
  };
  var ordersAdded = 0;
  var ordersSkipped = 0;

  final sourceOrders =
      await source.query(AppDatabase.tablePaperOrders, orderBy: 'id ASC');
  for (final row in sourceOrders) {
    if (orderKeys.contains(_orderKey(row))) {
      ordersSkipped++;
      continue;
    }
    await target.insert(
      AppDatabase.tablePaperOrders,
      _remap(_withoutId(row), groupMap: groupMap, positionMap: positionMap),
    );
    orderKeys.add(_orderKey(row));
    ordersAdded++;
  }

  return DbMergeReport(
    groupsAdded: groupsAdded,
    groupsMatched: groupsMatched,
    tradesAdded: tradesAdded,
    tradesSkipped: tradesSkipped,
    positionsAdded: positionsAdded,
    positionsMatched: positionsMatched,
    ordersAdded: ordersAdded,
    ordersSkipped: ordersSkipped,
    openPositionsAdded: openPositionsAdded,
  );
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

Map<String, Object?> _withoutId(Map<String, Object?> row) =>
    Map<String, Object?>.from(row)..remove('id');

/// Foreign keys ko nayi ids se jodta hai; jo mapping nahi mili use khaali.
Map<String, Object?> _remap(
  Map<String, Object?> row, {
  required Map<int, int> groupMap,
  Map<int, int>? positionMap,
}) {
  final out = Map<String, Object?>.from(row);
  final group = out['group_id'] as int?;
  if (group != null) out['group_id'] = groupMap[group];
  final position = out['position_id'] as int?;
  if (position != null) out['position_id'] = positionMap?[position];
  return out;
}

String _tradeKey(Map<String, Object?> row) => [
      row['symbol'],
      row['exchange'],
      '${row['side']}'.toUpperCase(),
      row['quantity'],
      (row['price'] as num?)?.toDouble().toStringAsFixed(4),
      row['executed_at'],
    ].join('|');

String _positionKey(Map<String, Object?> row) => [
      row['symbol'],
      row['exchange'],
      '${row['side']}'.toLowerCase(),
      row['quantity'],
      (row['avg_price'] as num?)?.toDouble().toStringAsFixed(4),
      row['opened_at'],
    ].join('|');

String _orderKey(Map<String, Object?> row) => [
      row['symbol'],
      row['exchange'],
      '${row['side']}'.toUpperCase(),
      row['quantity'],
      row['order_type'],
      row['limit_price'],
      row['created_at'],
    ].join('|');

String? _between(String column, int? from, int? to) {
  final parts = <String>[];
  if (from != null) parts.add('$column >= ?');
  if (to != null) parts.add('$column <= ?');
  return parts.isEmpty ? null : parts.join(' AND ');
}

List<Object?> _betweenArgs(int? from, int? to) => [
      if (from != null) from,
      if (to != null) to,
    ];

/// `IN (?, ?, …)`. Khaali suchi ke liye `NULL` — `IN ()` SQL me galat hai.
String _placeholders(int count) =>
    count == 0 ? 'NULL' : List<String>.filled(count, '?').join(', ');

/// File ke naam me lagne wala stamp (UI ke liye bhi).
String dbFileStamp(DateTime at) =>
    '${Fmt.isoDate(at).replaceAll('-', '')}-${at.hour.toString().padLeft(2, '0')}'
    '${at.minute.toString().padLeft(2, '0')}';
