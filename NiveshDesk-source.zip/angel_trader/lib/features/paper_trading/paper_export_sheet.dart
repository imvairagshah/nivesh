// ---------------------------------------------------------------------------
// paper_export_sheet.dart — Trade Book ke upar wala Export / Import menu.
//
// Teen sawal, niche se upar:
//   1. **Kya banau?**  PDF (chhapne layak) · Excel (kaam wali) · DB (backup)
//   2. **Kaunse din?**  default **Sab (ALL)** — kuch chhune tak sab kuch
//   3. **Export** ya **Import**
//
// IMPORT HAMESHA JODTA HAI (merge): ek bhi purana record nahi mitta. Duplicate
// (same symbol + side + qty + price + time) chhod diya jata hai. Ye baat yahan
// likhi bhi hai — chupke se data badalna sabse bura surprise hota hai.
// ---------------------------------------------------------------------------

import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/utils/formatters.dart';
import '../../core/widgets/motion.dart';
import 'paper_export.dart';
import 'paper_trading_provider.dart';
import 'trade_range.dart';

/// Trade Book ke upar se ye sheet khulti hai.
Future<void> showPaperExportSheet(BuildContext context) =>
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      showDragHandle: true,
      builder: (_) => const _PaperExportSheet(),
    );

class _PaperExportSheet extends StatefulWidget {
  const _PaperExportSheet();

  @override
  State<_PaperExportSheet> createState() => _PaperExportSheetState();
}

class _PaperExportSheetState extends State<_PaperExportSheet> {
  PaperExportKind _kind = PaperExportKind.pdf;

  /// Default ALL — jab tak date na chunein, sab kuch.
  TradeRange _range = TradeRange.all;

  bool _busy = false;
  DateTime _now = DateTime.now();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final paper = context.watch<PaperTradingProvider>();

    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            _heading(scheme),
            const SizedBox(height: 14),
            _sectionLabel('1. Kya banau?'),
            const SizedBox(height: 8),
            ...PaperExportKind.values.map(
              (kind) => _KindTile(
                kind: kind,
                selected: _kind == kind,
                onTap: () => setState(() => _kind = kind),
              ),
            ),
            const SizedBox(height: 16),
            _sectionLabel('2. Kaunse din? (default: Sab)'),
            const SizedBox(height: 8),
            _RangeChips(
              range: _range,
              onChanged: (range) => setState(() => _range = range),
              onPickCustom: _pickCustomRange,
            ),
            if (_range.isCustom) ...[
              const SizedBox(height: 10),
              _CustomDates(
                range: _range,
                onFrom: () => _pickDate(isFrom: true),
                onTo: () => _pickDate(isFrom: false),
              ),
            ],
            const SizedBox(height: 14),
            _Preview(
              kind: _kind,
              range: _range,
              now: _now,
              paper: paper,
            ),
            const SizedBox(height: 14),
            _ImportNote(kind: _kind),
            const SizedBox(height: 14),
            _Actions(
              busy: _busy,
              kind: _kind,
              onExport: _busy ? null : _export,
              onImport: _busy ? null : _import,
            ),
          ],
        ),
      ),
    );
  }

  // -------------------------------------------------------------------------
  // Chrome
  // -------------------------------------------------------------------------

  Widget _heading(ColorScheme scheme) => Row(
        children: [
          Icon(Icons.import_export_rounded, size: 20, color: scheme.primary),
          const SizedBox(width: 8),
          const Text(
            'Export / Import',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
          ),
          const Spacer(),
          Text(
            'Paper trading',
            style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
          ),
        ],
      );

  Widget _sectionLabel(String text) => Text(
        text,
        style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600),
      );

  // -------------------------------------------------------------------------
  // Date picking
  // -------------------------------------------------------------------------

  Future<void> _pickCustomRange() async {
    final picked = await showDatePicker(
      context: context,
      helpText: 'Shuruat ki date',
      initialDate: _range.from ?? _now,
      firstDate: DateTime(2015),
      lastDate: _now,
    );
    if (picked == null || !mounted) return;
    setState(() => _range = _range.copyWith(
          preset: TradeRangePreset.custom,
          from: picked,
          to: _range.to ?? picked,
        ));
  }

  Future<void> _pickDate({required bool isFrom}) async {
    final current = isFrom ? _range.from : _range.to;
    final picked = await showDatePicker(
      context: context,
      helpText: isFrom ? 'Shuruat ki date' : 'Aakhir ki date',
      initialDate: current ?? _range.from ?? _now,
      firstDate: DateTime(2015),
      lastDate: _now,
    );
    if (picked == null || !mounted) return;
    setState(() {
      _range = _range.copyWith(
        preset: TradeRangePreset.custom,
        from: isFrom ? picked : (_range.from ?? picked),
        to: isFrom ? (_range.to ?? picked) : picked,
      );
      if (isFrom && _range.to != null && _range.to!.isBefore(picked)) {
        _range = _range.copyWith(to: picked);
      }
    });
  }

  // -------------------------------------------------------------------------
  // Actions
  // -------------------------------------------------------------------------

  Future<void> _export() async {
    if (_range.isCustom && _range.from == null) {
      _snack('Pehle date chuno (Custom me "se" khaali hai).');
      return;
    }
    final paper = context.read<PaperTradingProvider>();
    setState(() => _busy = true);
    try {
      _now = DateTime.now();
      final service = PaperExportService();
      final outcome = _kind == PaperExportKind.db
          ? await service.exportDatabase(range: _range, now: _now)
          : await service.exportLedger(
              kind: _kind,
              trades: await paper.tradeBookForRange(_range, _now),
              groups: paper.groups,
              range: _range,
              now: _now,
              groupLabel: paper.filterLabel,
              groupId: paper.filter.ungroupedOnly ? null : paper.filter.groupId,
              ungroupedOnly: paper.filter.ungroupedOnly,
            );
      if (!mounted) return;
      setState(() => _busy = false);
      _snack(outcome.message);
      if (!context.mounted) return;
      if (outcome.ok) Navigator.of(context).maybePop();
    } catch (error) {
      if (!mounted) return;
      setState(() => _busy = false);
      _snack('Export me dikkat: $error');
    }
  }

  Future<void> _import() async {
    // Provider ko awaits se pahle pakad lo — baad me `context` chhuta hua ho
    // sakta hai (sheet band ho chuki ho).
    final paper = context.read<PaperTradingProvider>();
    final navigator = Navigator.of(context);
    setState(() => _busy = true);
    try {
      // Cancel karne par `null` milta hai — koi error nahi dikhana.
      final picked = await FilePicker.pickFiles(
        dialogTitle: 'NiveshDesk .db file chuno',
        type: FileType.any,
      );
      final path = picked.isEmpty ? null : picked.single.path;
      if (path == null) {
        if (mounted) setState(() => _busy = false);
        if (picked.isNotEmpty) {
          _snack('File ka raasta nahi mila — Files app se dobara chuno.');
        }
        return;
      }

      final outcome =
          await PaperExportService().importDatabase(file: File(path));

      if (!mounted) return;
      setState(() => _busy = false);
      _snack(outcome.message);
      final added = outcome.report?.added ?? 0;
      if (!mounted) return;
      if (added > 0) {
        // Naye trade jude hain — list dobara padho.
        await paper.refresh(reloadLists: true);
      }
      if (outcome.ok) navigator.maybePop();
    } catch (error) {
      if (!mounted) return;
      setState(() => _busy = false);
      _snack('Import me dikkat: $error');
    }
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..clearSnackBars()
      ..showSnackBar(SnackBar(content: Text(message)));
  }
}

// ---------------------------------------------------------------------------
// Format tiles
// ---------------------------------------------------------------------------

class _KindTile extends StatelessWidget {
  const _KindTile({
    required this.kind,
    required this.selected,
    required this.onTap,
  });

  final PaperExportKind kind;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final on = selected;
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
          decoration: BoxDecoration(
            color: on
                ? scheme.primary.withValues(alpha: 0.12)
                : scheme.surfaceContainerHighest.withValues(alpha: 0.4),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: on ? scheme.primary : scheme.outlineVariant,
              width: on ? 1.4 : 1,
            ),
          ),
          child: Row(
            children: [
              Icon(
                switch (kind) {
                  PaperExportKind.pdf => Icons.picture_as_pdf_outlined,
                  PaperExportKind.excel => Icons.grid_on_outlined,
                  PaperExportKind.db => Icons.storage_rounded,
                },
                size: 18,
                color: on ? scheme.primary : scheme.onSurfaceVariant,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      kind.label,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: on ? scheme.primary : null,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      kind.help,
                      style: TextStyle(
                        fontSize: 10.5,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              if (on)
                Icon(Icons.check_circle_rounded, size: 18, color: scheme.primary),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Range chips
// ---------------------------------------------------------------------------

class _RangeChips extends StatelessWidget {
  const _RangeChips({
    required this.range,
    required this.onChanged,
    required this.onPickCustom,
  });

  final TradeRange range;
  final ValueChanged<TradeRange> onChanged;
  final VoidCallback onPickCustom;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 6,
      runSpacing: 6,
      children: [
        for (final preset in TradeRangePreset.values)
          ChoiceChip(
            label: Text(preset == TradeRangePreset.all ? 'Sab (ALL)' : preset.label),
            selected: range.preset == preset,
            onSelected: (_) {
              if (preset == TradeRangePreset.custom) {
                onPickCustom();
                return;
              }
              onChanged(TradeRange(preset: preset));
            },
          ),
      ],
    );
  }
}

class _CustomDates extends StatelessWidget {
  const _CustomDates({
    required this.range,
    required this.onFrom,
    required this.onTo,
  });

  final TradeRange range;
  final VoidCallback onFrom;
  final VoidCallback onTo;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Row(
      children: [
        Expanded(
          child: _DateButton(
            label: 'Se',
            value: range.from,
            onTap: onFrom,
          ),
        ),
        const SizedBox(width: 8),
        Icon(Icons.arrow_forward_rounded, size: 16, color: scheme.outline),
        const SizedBox(width: 8),
        Expanded(
          child: _DateButton(
            label: 'Tak',
            value: range.to,
            onTap: onTo,
          ),
        ),
      ],
    );
  }
}

class _DateButton extends StatelessWidget {
  const _DateButton({
    required this.label,
    required this.value,
    required this.onTap,
  });

  final String label;
  final DateTime? value;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return OutlinedButton.icon(
      onPressed: onTap,
      icon: const Icon(Icons.event_outlined, size: 16),
      label: Text(
        value == null ? '$label: chuno' : '$label: ${Fmt.date(value)}',
        style: TextStyle(
          fontSize: 12,
          color: value == null ? scheme.error : scheme.onSurface,
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Preview — "abhi kya chalega"
// ---------------------------------------------------------------------------

class _Preview extends StatelessWidget {
  const _Preview({
    required this.kind,
    required this.range,
    required this.now,
    required this.paper,
  });

  final PaperExportKind kind;
  final TradeRange range;
  final DateTime now;
  final PaperTradingProvider paper;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest.withValues(alpha: 0.45),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (kind == PaperExportKind.db) ...[
            Text(
              range.isAll
                  ? 'Poora app DB — scrip master + candles + settings sab. '
                      'Badi file (30–80 MB), isliye backup ki tarah rakho; '
                      'WhatsApp se bhejna mushkil hoga.'
                  : 'Sirf ${range.describe(now)} ke trades / positions / orders / '
                      'groups. Chhoti file — doosre phone par bhej sakte ho.',
              style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant),
            ),
          ] else ...[
            FutureBuilder<int>(
              key: ValueKey<String>('${kind.name}-${range.describe(now)}'),
              future: paper.tradeBookForRange(range, now).then((v) => v.length),
              builder: (context, snapshot) {
                final legs = snapshot.data ?? 0;
                final waiting =
                    snapshot.connectionState == ConnectionState.waiting;
                final text = waiting
                    ? 'Ginti ho rahi hai…'
                    : legs == 0
                        ? 'Is daayre me koi leg nahi mili.'
                        : '$legs leg milengi · ${range.describe(now)}';
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      text,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: (!waiting && legs == 0)
                            ? scheme.error
                            : scheme.onSurface,
                      ),
                    ),
                    if (!waiting && legs == 0) ...[
                      const SizedBox(height: 3),
                      Text(
                        'Khaali file banegi — Export se pahle range badlo ya '
                        '"Sab (ALL)" chuno.',
                        style: TextStyle(fontSize: 10.5, color: scheme.error),
                      ),
                    ],
                  ],
                );
              },
            ),
          ],
          const SizedBox(height: 6),
          Text(
            'File: ${PaperExportService.fileName(kind, range, now)}',
            style: TextStyle(fontSize: 10.5, color: scheme.outline),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Import note + buttons
// ---------------------------------------------------------------------------

class _ImportNote extends StatelessWidget {
  const _ImportNote({required this.kind});

  final PaperExportKind kind;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(Icons.info_outline_rounded, size: 15, color: scheme.outline),
        const SizedBox(width: 6),
        Expanded(
          child: Text(
            'Import sirf jodta hai — purana data kabhi nahi mitta. Duplicate '
            '(same symbol + qty + price + time) chhod diya jata hai. Cache aur '
            'settings chhode jate hain (app khud bana leta hai).',
            style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
          ),
        ),
      ],
    );
  }
}

class _Actions extends StatelessWidget {
  const _Actions({
    required this.busy,
    required this.kind,
    required this.onExport,
    required this.onImport,
  });

  final bool busy;
  final PaperExportKind kind;
  final VoidCallback? onExport;
  final VoidCallback? onImport;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: OutlinedButton.icon(
            onPressed: onImport,
            icon: busy
                ? const SizedBox(
                    width: 14,
                    height: 14,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.file_download_outlined, size: 18),
            label: const Text('Import'),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: FilledButton.icon(
            onPressed: onExport,
            icon: const Icon(Icons.ios_share_rounded, size: 18),
            label: Text('${kind.label} banao'),
          ),
        ),
      ],
    );
  }
}

/// Trade Book ke upar wali patti — Export / Import ka rasta.
class TradeBookTools extends StatelessWidget {
  const TradeBookTools({super.key, this.legs = 0});

  final int legs;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return FadeSlideIn(
      index: 0,
      child: Container(
        margin: const EdgeInsets.fromLTRB(12, 10, 12, 0),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        decoration: BoxDecoration(
          color: scheme.surfaceContainerHighest.withValues(alpha: 0.35),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: scheme.outlineVariant.withValues(alpha: 0.5)),
        ),
        child: Row(
          children: [
            Icon(Icons.import_export_rounded, size: 16, color: scheme.primary),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                legs == 0
                    ? 'Export / Import (PDF · Excel · DB)'
                    : '$legs leg · Export / Import',
                style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant),
              ),
            ),
            TextButton(
              onPressed: () => showPaperExportSheet(context),
              child: const Text('Kholo'),
            ),
          ],
        ),
      ),
    );
  }
}
