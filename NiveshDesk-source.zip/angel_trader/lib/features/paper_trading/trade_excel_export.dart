// ---------------------------------------------------------------------------
// trade_excel_export.dart — trade book ki Excel (.xlsx).
//
// KAAM WALI EXCEL: Excel isliye alag hai PDF se — yahan aap chhant sakte ho,
// apna formula laga sakte ho, pivot bana sakte ho. Isliye yahan har cheez
// **raw number** hai (₹ nahi, text nahi): qty, price, P&L seedhe calculate
// hote hain. Sirf date ko text rakha hai taaki Excel use samajh sake.
//
// Teen sheet:
//   1. Hisaab      — upar wala summary (range, group, kitna jeeta, charges)
//   2. Legs        — har leg ki ek line (asli data, jisme kaam hota hai)
//   3. Matlab      — har column ka matlab Hindi me, taaki file bhejne par
//                    doosra aadmi bhi samajh jaye
// ---------------------------------------------------------------------------

import 'dart:io';

import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';

import '../../core/utils/formatters.dart';
import 'trade_ledger.dart';

class TradeExcelExport {
  /// Directory jahan file likhi jaye (test me badla ja sakta hai).
  const TradeExcelExport({Directory? directory}) : _directory = directory;

  final Directory? _directory;

  /// Workbook banata hai aur file me likhta hai; file ka raasta lautata hai.
  Future<File> write({
    required TradeLedger ledger,
    required String fileName,
  }) async {
    final book = Excel.createExcel();

    _summarySheet(book, ledger);
    _ledgerSheet(book, ledger);
    _glossarySheet(book);

    // `createExcel()` ek khali 'Sheet1' bana deta hai — hatana padta hai.
    if (book.sheets.containsKey('Sheet1')) book.delete('Sheet1');

    final dir = _directory ?? await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/$fileName');
    await file.writeAsBytes(book.encode()!, flush: true);
    return file;
  }

  /// Kisi bhi banaye hue byte (jaise PDF) ko usi jagah likhta hai.
  ///
  /// Isliye alag rakha hai taaki PDF aur Excel dono ek hi directory me jayen —
  /// user ko "file kidhar gayi" sochna na pade.
  Future<File> writeBytes({
    required String name,
    required List<int> bytes,
  }) async {
    final dir = _directory ?? await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/$name');
    await file.writeAsBytes(bytes, flush: true);
    return file;
  }

  // -------------------------------------------------------------------------
  // Sheet 1 — Hisaab
  // -------------------------------------------------------------------------

  void _summarySheet(Excel book, TradeLedger ledger) {
    final sheet = book['Hisaab'];
    final summary = ledger.summary;

    void line(String label, Object value) =>
        sheet.appendRow([TextCellValue(label), _cell(value)]);

    sheet.appendRow([TextCellValue('NiveshDesk — Paper Trading Hisaab')]);
    sheet.appendRow([]);
    line('Range', summary.rangeLabel);
    line('Group', summary.groupLabel);
    line('Banaya (file)', Fmt.dateTime(summary.generatedAt));
    sheet.appendRow([]);
    line('Kul legs', summary.legs);
    line('Band hue (closed)', summary.closingLegs);
    line('Jeete (wins)', summary.wins);
    line('Win rate', summary.winRateText);
    line('Realised P&L', _round(summary.realized));
    line('Charges', _round(summary.charges));
    line('Net (realised − charges)', _round(summary.net));
    sheet.appendRow([]);
    sheet.appendRow([
      TextCellValue(
        'Ye sirf paper trading ka hisaab hai — isme koi asli paisa nahi laga.',
      ),
    ]);
  }

  // -------------------------------------------------------------------------
  // Sheet 2 — Legs (asli data)
  // -------------------------------------------------------------------------

  void _ledgerSheet(Excel book, TradeLedger ledger) {
    final sheet = book['Legs'];
    sheet.appendRow([
      for (final header in _headers) TextCellValue(header),
    ]);

    for (final row in ledger.rows) {
      sheet.appendRow([
        TextCellValue(Fmt.isoDate(row.executedAt)),
        TextCellValue(Fmt.clock(row.executedAt)),
        TextCellValue(row.symbol),
        TextCellValue(row.sideLabel),
        IntCellValue(row.quantity),
        DoubleCellValue(_round(row.price)),
        DoubleCellValue(_round(row.value)),
        DoubleCellValue(_round(row.charges)),
        row.realizedPnl == null
            ? TextCellValue('')
            : DoubleCellValue(_round(row.realizedPnl!)),
        TextCellValue(row.isClosing ? 'CLOSE' : 'OPEN'),
        TextCellValue(row.group),
      ]);
    }

    if (ledger.isEmpty) {
      sheet.appendRow([TextCellValue('Is range me koi leg nahi mili.')]);
    }
  }

  // -------------------------------------------------------------------------
  // Sheet 3 — Matlab
  // -------------------------------------------------------------------------

  void _glossarySheet(Excel book) {
    final sheet = book['Matlab'];
    sheet.appendRow([TextCellValue('Column'), TextCellValue('Matlab')]);
    for (final entry in _glossary.entries) {
      sheet.appendRow([
        TextCellValue(entry.key),
        TextCellValue(entry.value),
      ]);
    }
  }

  // -------------------------------------------------------------------------
  // Static data
  // -------------------------------------------------------------------------

  static const List<String> _headers = <String>[
    'Date',
    'Time',
    'Symbol',
    'Side',
    'Qty',
    'Price',
    'Value',
    'Charges',
    'Realised P&L',
    'Leg',
    'Group',
  ];

  static const Map<String, String> _glossary = <String, String>{
    'Date': 'Leg kab execute hui (YYYY-MM-DD).',
    'Time': 'Leg ka samay (HH:MM:SS).',
    'Symbol': 'Stock / contract ka naam.',
    'Side': 'BUY = kharida (position khuli/badhi), SELL = becha (ghati/band hui).',
    'Qty': 'Kitne share/contract (lot size ke baad).',
    'Price': 'Jis bhav par execute hua.',
    'Value': 'Qty × Price — charges se pahle ka amount.',
    'Charges': 'Brokerage + STT + GST + stamp — asli broker jaisa hisaab.',
    'Realised P&L':
        'Sirf band karne wali (SELL) leg par: kitna fayda/nuksan pakka hua. '
            'Kharidne wali leg par khaali.',
    'Leg': 'OPEN = position kholi/badhi, CLOSE = position band ya ghati.',
    'Group': 'Aapka strategy tag (momentum, result play …). Khaali = bina group.',
    'Win rate': 'Jeete ÷ band hue. Kuch band na hua to "-" dikhega.',
    'Net': 'Realised P&L − charges — haath me aaya hua number.',
  };

  CellValue _cell(Object value) => switch (value) {
        final int number => IntCellValue(number),
        final double number => DoubleCellValue(number),
        final String text => TextCellValue(text),
        _ => TextCellValue('$value'),
      };

  static double _round(double value) =>
      double.parse(value.toStringAsFixed(2));
}
