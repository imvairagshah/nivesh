// ---------------------------------------------------------------------------
// trade_pdf_export.dart — trade book ka PDF.
//
// PRINT KARNE LAYAK: ye "copy" nahi, ek chhapne layak report hai — upar
// hisaab, niche har leg ki line. Bank/CA/partner ko bhejne layak.
//
// ANGREEZI KYUN: app ke saath bundle hue font me rupaye ka nishan (₹) hai,
// par Hindi ke akshar nahi. Isliye PDF ki body Angreezi + ankdo me hai;
// Hindi sirf phone ki screen par (bheetar ke message) milti hai.
//
// KABHI JHATKA NAHI: ye class sirf bytes banata hai — file likhna, share
// karna, permission sab upar wale layer ka kaam. Isse test karna aasan hai.
// ---------------------------------------------------------------------------

import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../../core/utils/formatters.dart';
import 'trade_ledger.dart';

/// Font bytes kahan se layen — test me file se, app me assets se.
typedef AssetBytesLoader = Future<ByteData> Function(String path);

class TradePdfExport {
  TradePdfExport({AssetBytesLoader? loader}) : _loader = loader;

  final AssetBytesLoader? _loader;

  static const String regularFontPath = 'assets/fonts/NiveshSans-Regular.ttf';
  static const String boldFontPath = 'assets/fonts/NiveshSans-Bold.ttf';

  pw.Font? _cachedRegular;
  pw.Font? _cachedBold;

  Future<pw.Font> _load(bool bold) async {
    final cached = bold ? _cachedBold : _cachedRegular;
    if (cached != null) return cached;
    final path = bold ? boldFontPath : regularFontPath;
    final loader = _loader;
    final loaded = loader != null
        ? await loader(path)
        : await rootBundle.load(path);

    // PDF ka font reader seedhe `ByteData.buffer` ke *absolute* offset se
    // padhta hai; asset bundle ka ByteData aksar bade buffer ka hissa hota hai
    // (offset 0 nahi) — tab woh kachra padhta. Isliye hamesha apni copy.
    final data = loaded.offsetInBytes == 0 &&
            loaded.lengthInBytes == loaded.buffer.lengthInBytes
        ? loaded
        : ByteData.sublistView(
            Uint8List.fromList(
              loaded.buffer.asUint8List(
                loaded.offsetInBytes,
                loaded.lengthInBytes,
              ),
            ),
          );
    final font = pw.Font.ttf(data);
    if (bold) {
      _cachedBold = font;
    } else {
      _cachedRegular = font;
    }
    return font;
  }

  /// Poori kitaab ka PDF.
  Future<Uint8List> build(TradeLedger ledger) async {
    final regular = await _load(false);
    final bold = await _load(true);

    final doc = pw.Document(
      theme: pw.ThemeData.withFont(base: regular, bold: bold),
      title: 'NiveshDesk Paper Trading Report',
      author: 'NiveshDesk',
    );

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        // Default 20 hai — purani book me 20 se jyada page hone par PDF adhura
        // ban jata. Sadharan trade book ke liye jagah rakho.
        maxPages: 100000,
        margin: const pw.EdgeInsets.all(24),
        footer: (context) => _footer(context, regular),
        build: (context) => [
          _heading(regular, bold),
          pw.SizedBox(height: 4),
          _meta(ledger.summary, regular),
          pw.SizedBox(height: 12),
          _summaryCard(ledger.summary, regular, bold),
          pw.SizedBox(height: 14),
          _ledgerTable(ledger, regular, bold),
          pw.SizedBox(height: 10),
          _disclaimer(regular),
        ],
      ),
    );

    return doc.save();
  }

  // -------------------------------------------------------------------------
  // Pieces
  // -------------------------------------------------------------------------

  pw.Widget _heading(pw.Font regular, pw.Font bold) => pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        crossAxisAlignment: pw.CrossAxisAlignment.end,
        children: [
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text(
                'NiveshDesk',
                style: pw.TextStyle(font: bold, fontSize: 16),
              ),
              pw.Text(
                'Paper Trading Report',
                style: pw.TextStyle(
                  font: regular,
                  fontSize: 11,
                  color: PdfColors.grey700,
                ),
              ),
            ],
          ),
          pw.Text(
            'Practice / paper trades',
            style: pw.TextStyle(
              font: regular,
              fontSize: 9,
              color: PdfColors.grey600,
            ),
          ),
        ],
      );

  pw.Widget _meta(LedgerSummary summary, pw.Font regular) {
    final line =
        'Range: ${asciiSafe(summary.rangeLabel)}    |    Group: ${asciiSafe(summary.groupLabel)}    |    Generated: ${Fmt.dateTime(summary.generatedAt)}';
    return pw.Container(
      padding: const pw.EdgeInsets.symmetric(vertical: 6, horizontal: 8),
      decoration: pw.BoxDecoration(
        color: PdfColors.grey200,
        borderRadius: pw.BorderRadius.circular(4),
      ),
      child: pw.Text(
        line,
        style: pw.TextStyle(font: regular, fontSize: 8.5, height: 1.4),
      ),
    );
  }

  pw.Widget _summaryCard(
    LedgerSummary summary,
    pw.Font regular,
    pw.Font bold,
  ) {
    pw.Widget cell(String label, String value, {bool strong = false}) =>
        pw.Expanded(
          child: pw.Container(
            margin: const pw.EdgeInsets.only(right: 6),
            padding: const pw.EdgeInsets.all(8),
            decoration: pw.BoxDecoration(
              border: pw.Border.all(color: PdfColors.grey400, width: 0.5),
              borderRadius: pw.BorderRadius.circular(4),
            ),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text(
                  label,
                  style: pw.TextStyle(
                    font: regular,
                    fontSize: 7.5,
                    color: PdfColors.grey700,
                  ),
                ),
                pw.SizedBox(height: 3),
                pw.Text(
                  value,
                  style: pw.TextStyle(
                    font: strong ? bold : regular,
                    fontSize: 10.5,
                  ),
                ),
              ],
            ),
          ),
        );

    return pw.Row(
      children: [
        cell('Legs', '${summary.legs}'),
        cell('Closed', '${summary.closingLegs}'),
        cell('Win rate', summary.winRateText),
        cell('Realised', Fmt.signedMoney(summary.realized), strong: true),
        cell('Charges', Fmt.money(summary.charges)),
        cell('Net', Fmt.signedMoney(summary.net), strong: true),
      ],
    );
  }

  pw.Widget _ledgerTable(
    TradeLedger ledger,
    pw.Font regular,
    pw.Font bold,
  ) {
    final head = pw.TextStyle(
      font: bold,
      fontSize: 8,
      color: PdfColors.white,
    );
    final body = pw.TextStyle(font: regular, fontSize: 8);
    final bodyDim = pw.TextStyle(
      font: regular,
      fontSize: 8,
      color: PdfColors.grey600,
    );

    pw.Widget headCell(String text, {pw.TextAlign align = pw.TextAlign.left}) =>
        pw.Padding(
          padding: const pw.EdgeInsets.all(4),
          child: pw.Text(text, style: head, textAlign: align),
        );

    pw.Widget bodyCell(
      String text, {
      pw.TextAlign align = pw.TextAlign.left,
      bool dim = false,
      bool strong = false,
    }) =>
        pw.Padding(
          padding: const pw.EdgeInsets.all(4),
          child: pw.Text(
            asciiSafe(text),
            style: strong
                ? pw.TextStyle(font: bold, fontSize: 8)
                : (dim ? bodyDim : body),
            textAlign: align,
          ),
        );

    final rows = <pw.TableRow>[
      pw.TableRow(
        decoration: const pw.BoxDecoration(color: PdfColors.blueGrey800),
        children: [
          headCell('Date & time'),
          headCell('Symbol'),
          headCell('Side'),
          headCell('Qty', align: pw.TextAlign.right),
          headCell('Price', align: pw.TextAlign.right),
          headCell('Value', align: pw.TextAlign.right),
          headCell('Charges', align: pw.TextAlign.right),
          headCell('Realised P&L', align: pw.TextAlign.right),
          headCell('Group'),
        ],
      ),
    ];

    for (var i = 0; i < ledger.rows.length; i++) {
      final row = ledger.rows[i];
      final zebra = i.isOdd;
      rows.add(
        pw.TableRow(
          decoration: pw.BoxDecoration(
            color: zebra ? PdfColors.grey100 : PdfColors.white,
          ),
          children: [
            bodyCell(Fmt.dateTime(row.executedAt), dim: true),
            bodyCell(row.symbol, strong: true),
            bodyCell(row.sideLabel),
            bodyCell(Fmt.qty(row.quantity), align: pw.TextAlign.right),
            bodyCell(Fmt.price(row.price), align: pw.TextAlign.right),
            bodyCell(Fmt.price(row.value), align: pw.TextAlign.right),
            bodyCell(Fmt.price(row.charges), align: pw.TextAlign.right),
            bodyCell(
              row.realizedPnl == null ? '-' : Fmt.signedMoney(row.realizedPnl),
              align: pw.TextAlign.right,
              dim: row.realizedPnl == null,
            ),
            bodyCell(row.group, dim: true),
          ],
        ),
      );
    }

    if (ledger.isEmpty) {
      rows.add(
        pw.TableRow(
          children: [
            pw.Padding(
              padding: const pw.EdgeInsets.all(10),
              child: pw.Text(
                'Is range me koi leg nahi mili.',
                style: bodyDim,
              ),
            ),
          ],
        ),
      );
    }

    return pw.Table(
      border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.4),
      columnWidths: const <int, pw.TableColumnWidth>{
        0: pw.FlexColumnWidth(2.2),
        1: pw.FlexColumnWidth(2.0),
        2: pw.FlexColumnWidth(0.9),
        3: pw.FlexColumnWidth(1.1),
        4: pw.FlexColumnWidth(1.3),
        5: pw.FlexColumnWidth(1.4),
        6: pw.FlexColumnWidth(1.2),
        7: pw.FlexColumnWidth(1.6),
        8: pw.FlexColumnWidth(1.8),
      },
      children: rows,
    );
  }

  pw.Widget _disclaimer(pw.Font regular) => pw.Text(
        'Ye sirf paper trading ka hisaab hai - isme koi asli paisa nahi laga. '
        'Numbers app ke apne record se aaye hain, broker ke statement se nahi.',
        style: pw.TextStyle(
          font: regular,
          fontSize: 7.5,
          color: PdfColors.grey600,
        ),
      );

  pw.Widget _footer(pw.Context context, pw.Font regular) => pw.Container(
        alignment: pw.Alignment.centerRight,
        margin: const pw.EdgeInsets.only(top: 6),
        child: pw.Text(
          'Page ${context.pageNumber} of ${context.pagesCount}  -  NiveshDesk',
          style: pw.TextStyle(
            font: regular,
            fontSize: 7.5,
            color: PdfColors.grey600,
          ),
        ),
      );
}

// ---------------------------------------------------------------------------
// Font safety
// ---------------------------------------------------------------------------

/// PDF ke font me sirf Angreezi akshar, ankde aur rupaye ka nishan hain.
/// Group ka naam Hindi me ho to wahan '?' dikhega - girne se behtar hai.
String asciiSafe(String text) {
  if (text.codeUnits.every((unit) => unit < 128 || unit == 0x20B9)) {
    return text;
  }
  final out = StringBuffer();
  for (final rune in text.runes) {
    out.write(rune < 128 || rune == 0x20B9 ? String.fromCharCode(rune) : '?');
  }
  return out.toString();
}

/// Test helper: PDF ke andar ka text nikaal kar padhne layak banaata hai
/// (pdf package ke compressed streams ke liye nahi, poori tarah safe nahi —
/// sirf smoke test ke liye).
String pdfDebugText(Uint8List bytes) => latin1.decode(bytes, allowInvalid: true);
