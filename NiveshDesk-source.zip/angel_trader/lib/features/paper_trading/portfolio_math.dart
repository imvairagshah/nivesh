// ---------------------------------------------------------------------------
// portfolio_math.dart — every P&L number the paper-trading UI shows, computed
// in one place from (positions, trades, live prices).
//
// THE CASH IDENTITY (why the dashboard always reconciles)
//   Every filled leg moves cash: a buy debits `turnover + charges`, a sell
//   credits `turnover − charges`. So:
//
//     availableCash  = startingCapital + Σ cashFlow(every filled trade)
//     marketValue    = Σ (ltp × quantity)              over open positions
//     portfolioValue = availableCash + marketValue     ← the "account value"
//
//   A **short** (a written option) is a liability, not an asset: its premium was
//   already credited to cash when it was sold, so its market value enters the
//   sum *negative* (−ltp × quantity). Forgetting the sign would double-count the
//   premium and make a written option look like free money.
//     totalPnl       = portfolioValue − startingCapital
//
//   and that total splits exactly into
//     realised (booked on closing legs, net of both legs' charges)
//   + unrealised (gross, i.e. before the exit charges you have not paid yet)
//   − charges already paid on the opening legs of positions that are still open
//
//   `netTotalPnl` is the version that keeps the identity true; the tiles show
//   both so nothing is hidden. test/features/paper_trading/portfolio_math_test.dart
//   asserts the identity on a synthetic book.
//
// Month bucketing is done in Dart against IST (`MarketCalendar.istFromUtc`), the
// same rule TradeGroupDao uses, so a trade at 02:00 IST on 1 Oct is reported in
// October rather than September.
//
// Pure Dart — no Flutter, no database — so it can be unit-tested directly.
// ---------------------------------------------------------------------------

import '../../core/utils/markets.dart';
import '../../data/local/models/paper_trade.dart';
import '../../data/local/models/trade_group.dart';
import 'charges.dart';

/// One open position enriched with its live price and its group label.
class HoldingView {
  final Position position;

  /// Latest traded price, or `null` when nothing is known yet (offline start).
  final double? ltp;

  /// Day change % from the feed (quote mode only) — informational.
  final double? changePct;

  /// Group label for the chip; [kUngroupedLabel] when the position has none.
  final String groupName;
  final int groupColorIndex;

  /// `true` when [ltp] came off the live WebSocket rather than a REST snapshot.
  final bool isLive;

  /// When the price was observed.
  final DateTime? pricedAt;

  const HoldingView({
    required this.position,
    this.ltp,
    this.changePct,
    this.groupName = kUngroupedLabel,
    this.groupColorIndex = 0,
    this.isLive = false,
    this.pricedAt,
  });

  /// Book value (`avgPrice × quantity`).
  double get invested => position.investedValue;

  /// Market value at [ltp] (`null` while no price is known).
  double? get marketValue =>
      ltp == null ? null : position.marketValueAt(ltp!);

  /// Gross unrealised P&L — the headline number on the Holdings card.
  double? get unrealizedPnl =>
      ltp == null ? null : position.unrealizedAt(ltp!);

  /// Gross unrealised P&L in %.
  double? get unrealizedPct =>
      ltp == null ? null : position.unrealizedPctAt(ltp!);

  /// What the exit would cost in charges (STT + exchange + GST + DP …) if the
  /// position were sold right now. Shown in the exit confirmation, not in the
  /// headline P&L.
  ///
  /// Closing a **short** is a *buy* (a cover), not a sell, and an option pays
  /// the F&O stack — getting either wrong would understate the exit cost.
  double exitCharges(ChargesMode mode, {bool includeDpCharge = true}) =>
      EquityCharges.compute(
        side: position.isShort ? OrderSide.buy : OrderSide.sell,
        price: ltp ?? position.avgPrice,
        quantity: position.quantity,
        exchange: position.exchange,
        mode: mode,
        includeDpCharge: includeDpCharge,
        kind: position.exchange == Exchange.nfo
            ? InstrumentKind.option
            : InstrumentKind.equity,
      ).total;

  /// Unrealised P&L after the expected exit charges — "what you would keep".
  double? netUnrealized(ChargesMode mode, {bool includeDpCharge = true}) {
    final gross = unrealizedPnl;
    if (gross == null) return null;
    return gross - exitCharges(mode, includeDpCharge: includeDpCharge);
  }

  /// `true` when the stop is currently breached (the auto-exit watcher's test).
  bool get stopBreached => ltp != null && position.stopHit(ltp!);

  /// `true` when the target is currently reached.
  bool get targetReached => ltp != null && position.targetHit(ltp!);

  bool get isPriced => ltp != null && ltp! > 0;

  @override
  String toString() =>
      'HoldingView(${position.displaySymbol}, qty=${position.quantity}, ltp=$ltp)';
}

/// One pending LIMIT order enriched with the live price, for the Orders tab.
class PendingOrderView {
  final PaperOrder order;
  final double? ltp;

  const PendingOrderView({required this.order, this.ltp});

  /// How far the market still has to move before this order fills, in %.
  /// Negative = the level was already crossed (it will fill on the next tick).
  double? get distancePct {
    final target = order.limitPrice;
    if (target == null || ltp == null || ltp == 0) return null;
    return (target - ltp!) / ltp! * 100;
  }

  bool get isMarketable {
    final target = order.limitPrice;
    if (target == null || ltp == null) return false;
    return order.side == OrderSide.buy ? ltp! <= target : ltp! >= target;
  }

  @override
  String toString() => 'PendingOrderView(${order.symbol}, ltp=$ltp)';
}

// ---------------------------------------------------------------------------
// Aggregate statistics
// ---------------------------------------------------------------------------

/// Realised-P&L statistics over a set of closing legs (one round trip each).
class PnlStats {
  final double realizedPnl;
  final int closedTrades;
  final int wins;
  final int losses;
  final double grossProfit;
  final double grossLoss; // negative number

  /// Total charges paid across *all* legs in the sampled set.
  final double charges;

  /// Best and worst single round trip of the set.
  final Trade? bestTrade;
  final Trade? worstTrade;

  const PnlStats({
    this.realizedPnl = 0,
    this.closedTrades = 0,
    this.wins = 0,
    this.losses = 0,
    this.grossProfit = 0,
    this.grossLoss = 0,
    this.charges = 0,
    this.bestTrade,
    this.worstTrade,
  });

  static const PnlStats empty = PnlStats();

  bool get isEmpty => closedTrades == 0;
  bool get isNotEmpty => closedTrades > 0;

  /// Win rate in percent.
  double get winRate => closedTrades == 0 ? 0 : wins / closedTrades * 100;

  /// Average size of a winning round trip (0 when there were none).
  double get averageWin => wins == 0 ? 0 : grossProfit / wins;

  /// Average size of a losing round trip, as a positive number.
  double get averageLoss => losses == 0 ? 0 : grossLoss.abs() / losses;

  double get biggestWin => bestTrade?.realizedPnl ?? 0;
  double get biggestLoss => worstTrade?.realizedPnl ?? 0;

  /// Gross profit ÷ gross loss; `null` when there were no losses.
  double? get profitFactor =>
      grossLoss == 0 ? null : grossProfit / grossLoss.abs();

  /// Average P&L per closed trade.
  double get averageTrade => closedTrades == 0 ? 0 : realizedPnl / closedTrades;

  /// `1.35x` style label for the analytics row.
  String get winRateLabel => '${winRate.toStringAsFixed(winRate % 1 == 0 ? 0 : 1)}%';

  @override
  String toString() =>
      'PnlStats(realized=${realizedPnl.toStringAsFixed(2)}, closed=$closedTrades, '
      'winRate=${winRate.toStringAsFixed(1)}%)';
}

/// Realised P&L for one IST calendar month.
class MonthlyPnlRow {
  /// First day of the month (IST), `DateTime(y, m)`.
  final DateTime month;
  final double realizedPnl;
  final int trades;
  final int wins;
  final int losses;
  final double biggestWin;
  final double biggestLoss;
  final double charges;

  const MonthlyPnlRow({
    required this.month,
    this.realizedPnl = 0,
    this.trades = 0,
    this.wins = 0,
    this.losses = 0,
    this.biggestWin = 0,
    this.biggestLoss = 0,
    this.charges = 0,
  });

  /// `Sep 2025` — label under the bar.
  String get label => '${_months[month.month - 1]} ${month.year}';

  /// `Sep` — the compact axis label when several months are shown at once.
  String get shortLabel => _months[month.month - 1];

  /// `2025-09` — stable key for grouping/CSV.
  String get key =>
      '${month.year}-${month.month.toString().padLeft(2, '0')}';

  double get winRate => trades == 0 ? 0 : wins / trades * 100;

  static const List<String> _months = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
  ];

  @override
  String toString() =>
      'MonthlyPnlRow($label, ${realizedPnl.toStringAsFixed(2)}, $trades trades)';
}

/// The dashboard's headline numbers — everything the top tiles need.
class PortfolioSnapshot {
  /// Virtual capital the user configured.
  final double startingCapital;

  /// Uninvested cash: `startingCapital + Σ cashFlow(filled trades)`.
  final double availableCash;

  /// Book value of everything currently held.
  final double investedValue;

  /// Market value of everything currently held (at the latest known prices).
  final double marketValue;

  /// Realised P&L booked so far (net of both legs' charges).
  final double realizedPnl;

  /// Gross unrealised P&L on open positions.
  final double unrealizedPnl;

  /// Charges already paid on the opening legs of *open* positions.
  final double openLegCharges;

  /// Number of open positions / closed round trips.
  final int openPositions;
  final int closedTrades;

  /// Number of pending LIMIT orders.
  final int pendingOrders;

  /// `true` when at least one open position could not be priced (offline).
  final bool hasUnpricedPositions;

  const PortfolioSnapshot({
    this.startingCapital = 0,
    this.availableCash = 0,
    this.investedValue = 0,
    this.marketValue = 0,
    this.realizedPnl = 0,
    this.unrealizedPnl = 0,
    this.openLegCharges = 0,
    this.openPositions = 0,
    this.closedTrades = 0,
    this.pendingOrders = 0,
    this.hasUnpricedPositions = false,
  });

  static const PortfolioSnapshot empty = PortfolioSnapshot();

  /// Cash + holdings: what the virtual account is worth right now.
  double get portfolioValue => availableCash + marketValue;

  /// Total return on the virtual capital.
  double get totalPnl => portfolioValue - startingCapital;

  /// Total return in % of the starting capital.
  double get totalPnlPct =>
      startingCapital == 0 ? 0 : totalPnl / startingCapital * 100;

  /// Realised + unrealised, minus the opening charges already paid on positions
  /// that are still open. This is the number that reconciles exactly with
  /// [portfolioValue] (see the identity at the top of the file).
  double get netTotalPnl => realizedPnl + unrealizedPnl - openLegCharges;

  /// Share of the account that is deployed, in %.
  double get deployedPct =>
      portfolioValue == 0 ? 0 : marketValue / portfolioValue * 100;

  /// Free cash as a percentage of the account.
  double get cashPct =>
      portfolioValue == 0 ? 0 : availableCash / portfolioValue * 100;

  @override
  String toString() =>
      'PortfolioSnapshot(value=${portfolioValue.toStringAsFixed(2)}, '
      'realized=${realizedPnl.toStringAsFixed(2)}, '
      'unrealized=${unrealizedPnl.toStringAsFixed(2)})';
}

// ---------------------------------------------------------------------------
// The maths
// ---------------------------------------------------------------------------

class PortfolioMath {
  PortfolioMath._();

  /// Aggregates closing legs into [PnlStats].
  ///
  /// [allLegs] (when given) is used only for the charges total, so the caller can
  /// pass both the whole trade book and the closing subset.
  static PnlStats stats(List<Trade> closingLegs, {List<Trade>? allLegs}) {
    if (closingLegs.isEmpty && (allLegs == null || allLegs.isEmpty)) {
      return PnlStats.empty;
    }

    var realized = 0.0;
    var grossProfit = 0.0;
    var grossLoss = 0.0;
    var wins = 0;
    var losses = 0;
    Trade? best;
    Trade? worst;

    for (final leg in closingLegs) {
      final pnl = leg.realizedPnl ?? 0;
      realized += pnl;
      if (pnl > 0) {
        wins++;
        grossProfit += pnl;
      } else if (pnl < 0) {
        losses++;
        grossLoss += pnl;
      }
      // A flat round trip counts as a closed trade but neither a win nor a loss.
      if (best == null || pnl > (best.realizedPnl ?? 0)) best = leg;
      if (worst == null || pnl < (worst.realizedPnl ?? 0)) worst = leg;
    }

    final chargeRows = allLegs ?? closingLegs;
    return PnlStats(
      realizedPnl: realized,
      closedTrades: closingLegs.length,
      wins: wins,
      losses: losses,
      grossProfit: grossProfit,
      grossLoss: grossLoss,
      charges: chargeRows.fold<double>(0, (sum, t) => sum + t.charges),
      bestTrade: best,
      worstTrade: worst,
    );
  }

  /// Buckets closing legs into IST calendar months, oldest first.
  static List<MonthlyPnlRow> monthly(List<Trade> closingLegs) {
    final buckets = <String, MonthlyPnlRow>{};

    for (final leg in closingLegs) {
      final ist = MarketCalendar.istFromUtc(leg.executedAt.toUtc());
      final month = DateTime(ist.year, ist.month);
      final key = '${month.year}-${month.month}';
      final pnl = leg.realizedPnl ?? 0;
      final existing = buckets[key];

      buckets[key] = MonthlyPnlRow(
        month: month,
        realizedPnl: (existing?.realizedPnl ?? 0) + pnl,
        trades: (existing?.trades ?? 0) + 1,
        wins: (existing?.wins ?? 0) + (pnl > 0 ? 1 : 0),
        losses: (existing?.losses ?? 0) + (pnl < 0 ? 1 : 0),
        biggestWin: pnl > (existing?.biggestWin ?? 0) ? pnl : (existing?.biggestWin ?? 0),
        biggestLoss: pnl < (existing?.biggestLoss ?? 0) ? pnl : (existing?.biggestLoss ?? 0),
        charges: existing?.charges ?? 0,
      );
    }

    final rows = buckets.values.toList()
      ..sort((a, b) => a.month.compareTo(b.month));
    return rows;
  }

  /// Builds the dashboard snapshot.
  ///
  /// [trades] must be every filled leg (opening *and* closing) — the cash
  /// identity depends on it. [holdings] is the priced open positions.
  static PortfolioSnapshot snapshot({
    required double startingCapital,
    required List<Trade> trades,
    required List<HoldingView> holdings,
    int pendingOrders = 0,
  }) {
    var cash = startingCapital;
    var realized = 0.0;
    var closedTrades = 0;

    for (final leg in trades) {
      cash += leg.cashFlow;
      if (leg.isClosingLeg) {
        realized += leg.realizedPnl ?? 0;
        closedTrades++;
      }
    }

    var invested = 0.0;
    var market = 0.0;
    var unrealized = 0.0;
    var openCharges = 0.0;
    var unpriced = false;

    for (final holding in holdings) {
      // A short contributes negatively on both sides (see the identity above):
      // its premium is already in `cash`, the position itself is a liability.
      final sign = holding.position.isShort ? -1.0 : 1.0;
      invested += sign * holding.invested;
      openCharges += holding.position.chargesPaid;
      final value = holding.marketValue;
      final pnl = holding.unrealizedPnl;
      if (value == null || pnl == null) {
        // No price yet: count the position at book value so the account value
        // never drops to zero just because the feed is offline.
        market += sign * holding.invested;
        unpriced = true;
      } else {
        market += sign * value;
        unrealized += pnl;
      }
    }

    return PortfolioSnapshot(
      startingCapital: startingCapital,
      availableCash: cash,
      investedValue: invested,
      marketValue: market,
      realizedPnl: realized,
      unrealizedPnl: unrealized,
      openLegCharges: openCharges,
      openPositions: holdings.length,
      closedTrades: closedTrades,
      pendingOrders: pendingOrders,
      hasUnpricedPositions: unpriced,
    );
  }

  /// Groups open holdings by their group id (`null` = Ungrouped), preserving the
  /// order of [groups] and appending unknown ids at the end.
  static Map<int?, List<HoldingView>> byGroup(List<HoldingView> holdings) {
    final map = <int?, List<HoldingView>>{};
    for (final holding in holdings) {
      map.putIfAbsent(holding.position.groupId, () => []).add(holding);
    }
    return map;
  }
}
