// ---------------------------------------------------------------------------
// paper_trading_screen.dart — Feature 3's Paper Trading tab.
//
//   ┌ dashboard tiles (portfolio value, cash, realised, unrealised, feed state)
//   ├ group filter + symbol search
//   ├ Holdings | Orders | Trade Book
//   └ FAB → the Buy/Sell sheet
//
// The tab owns no trading logic: it renders PaperTradingProvider's state and
// calls its actions. Stop-loss / target / group edits and the partial-exit flow
// are small dialogs defined here because they only exist for this screen.
//
// Everything is simulated: no order ever reaches Angel One.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../core/utils/formatters.dart';
import '../../core/widgets/brand.dart';
import '../../core/widgets/motion.dart';
import '../../core/widgets/page_scroll.dart';
import '../../core/theme/app_theme.dart';
import '../../data/local/models/paper_trade.dart';
import 'paper_export_sheet.dart' show TradeBookTools;
import 'paper_trading_provider.dart';
import 'portfolio_math.dart';
import 'widgets/group_chips.dart';
import 'widgets/holding_card.dart';
import 'widgets/order_sheet.dart';
import 'widgets/order_tile.dart';
import 'widgets/portfolio_header.dart';
import 'widgets/trade_tile.dart';

class PaperTradingScreen extends StatefulWidget {
  const PaperTradingScreen({super.key});

  @override
  State<PaperTradingScreen> createState() => _PaperTradingScreenState();
}

enum _PaperTab { holdings, orders, book }

class _PaperTradingScreenState extends State<PaperTradingScreen> {
  _PaperTab _tab = _PaperTab.holdings;
  bool _bootstrapped = false;
  String? _shownNotice;

  @override
  void initState() {
    super.initState();
    // Load once the first frame is up (the provider needs the DB, which the
    // shell has already opened).
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || _bootstrapped) return;
      _bootstrapped = true;
      context.read<PaperTradingProvider>().bootstrap();
    });
  }

  @override
  Widget build(BuildContext context) {
    // Surface the provider's last message (fill, auto-exit, group change) as a
    // snackbar exactly once.
    final paper = context.watch<PaperTradingProvider>();
    if (paper.notice.isNotEmpty && paper.notice != _shownNotice) {
      _shownNotice = paper.notice;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(paper.notice)));
        context.read<PaperTradingProvider>().clearNotice();
      });
    }

    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showOrderSheet(context),
        icon: const Icon(Icons.add_chart_rounded),
        label: const Text('Trade'),
      ),
      // 1.5.92 — PC fix: poora page ek hi scroll me (header + tab content
      // saath chalte hain, koi fixed header + inner list nahi).
      body: PageScroll.children(
        padding: EdgeInsets.zero,
        onRefresh: () async {
          await paper.refreshPricesViaRest(force: true);
          await paper.refresh(reloadLists: true);
        },
        [
          const PortfolioHeader(),
          const GroupFilterBar(),
          const _SearchRow(),
          _TabSelector(
            tab: _tab,
            onChanged: (tab) => setState(() => _tab = tab),
            counts: (
              holdings: paper.allHoldings.length,
              orders: paper.pendingOrders.length,
              book: paper.tradeBook.length,
            ),
          ),
          const Divider(height: 1),
          SwapFade(
            child: KeyedSubtree(
              key: ValueKey<_PaperTab>(_tab),
              child: switch (_tab) {
                _PaperTab.holdings => const _HoldingsTab(),
                _PaperTab.orders => const _OrdersTab(),
                _PaperTab.book => const _TradeBookTab(),
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Chrome
// ---------------------------------------------------------------------------

class _SearchRow extends StatefulWidget {
  const _SearchRow();

  @override
  State<_SearchRow> createState() => _SearchRowState();
}

class _SearchRowState extends State<_SearchRow> {
  final TextEditingController _controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    _controller.text = context.read<PaperTradingProvider>().filter.query;
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final query = context.select<PaperTradingProvider, String>(
      (paper) => paper.filter.query,
    );
    if (_controller.text != query && query.isEmpty) _controller.text = '';

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 6, 12, 6),
      child: TextField(
        controller: _controller,
        decoration: InputDecoration(
          isDense: true,
          hintText: 'Filter by symbol',
          prefixIcon: const Icon(Icons.search_rounded, size: 18),
          suffixIcon: query.isEmpty
              ? null
              : IconButton(
                  icon: const Icon(Icons.close_rounded, size: 18),
                  onPressed: () {
                    _controller.clear();
                    context.read<PaperTradingProvider>().setQuery('');
                  },
                ),
        ),
        onChanged: (value) =>
            context.read<PaperTradingProvider>().setQuery(value),
      ),
    );
  }
}

class _TabSelector extends StatelessWidget {
  const _TabSelector({
    required this.tab,
    required this.onChanged,
    required this.counts,
  });

  final _PaperTab tab;
  final ValueChanged<_PaperTab> onChanged;
  final ({int holdings, int orders, int book}) counts;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 2, 12, 8),
      child: SegmentedButton<_PaperTab>(
        showSelectedIcon: false,
        segments: [
          ButtonSegment(
            value: _PaperTab.holdings,
            label: Text('Holdings (${counts.holdings})'),
          ),
          ButtonSegment(
            value: _PaperTab.orders,
            label: Text(
              counts.orders > 0 ? 'Orders (${counts.orders})' : 'Orders',
            ),
          ),
          ButtonSegment(
            value: _PaperTab.book,
            label: Text('Trade book (${counts.book})'),
          ),
        ],
        selected: {tab},
        onSelectionChanged: (set) => onChanged(set.first),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Holdings
// ---------------------------------------------------------------------------

class _HoldingsTab extends StatelessWidget {
  const _HoldingsTab();

  @override
  Widget build(BuildContext context) {
    final paper = context.watch<PaperTradingProvider>();
    final holdings = paper.holdings;

    // First load: three skeleton cards instead of an empty-looking screen.
    if (holdings.isEmpty && paper.isLoading) {
      return const Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(height: 10),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 12),
            child: ShimmerCard(),
          ),
          SizedBox(height: 8),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 12),
            child: ShimmerCard(),
          ),
          SizedBox(height: 8),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 12),
            child: ShimmerCard(),
          ),
        ],
      );
    }

    if (holdings.isEmpty) {
      return _EmptyState(
        icon: Icons.account_balance_wallet_outlined,
        title: paper.filter.isAll
            ? 'No open positions'
            : 'Nothing matches this filter',
        message: paper.filter.isAll
            ? 'Place a paper buy to start building the book. Virtual capital: '
                  '${Fmt.money(paper.startingCapital)}.'
            : 'Try "All groups" or clear the symbol filter.',
        actionLabel: 'Place a paper trade',
        onAction: () => showOrderSheet(context),
      );
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const SizedBox(height: 10),
        for (var index = 0; index < holdings.length; index++) ...[
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Builder(
              builder: (context) {
                final holding = holdings[index];
                final position = holding.position;
                return FadeSlideIn(
                  index: index,
                  child: HoldingCard(
                    holding: holding,
                    onExit: () => _confirmExit(context, position, holding),
                    onPartialExit: () => _askPartialExit(context, position),
                    onSetStopLoss: () => _askStopLoss(context, position),
                    onSetTarget: () => _askTarget(context, position),
                    onChangeGroup: () => _askGroup(context, position),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 8),
        ],
        const SizedBox(height: 80),
      ],
    );
  }

  Future<void> _confirmExit(
    BuildContext context,
    Position position,
    HoldingView view,
  ) async {
    final paper = context.read<PaperTradingProvider>();
    final charges = view.exitCharges(
      paper.chargesMode,
      includeDpCharge: paper.includeDpCharges,
    );
    final ltp = view.ltp;
    final net = view.unrealizedPnl == null
        ? null
        : view.unrealizedPnl! - charges;

    // A short is closed by *buying it back*; the words have to say so.
    final short = position.isShort;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(
          short
              ? 'Cover ${position.displaySymbol}?'
              : 'Exit ${position.displaySymbol}?',
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              short
                  ? 'Buy back ${position.quantity} qty at market'
                        '${ltp == null ? '' : ' (≈ ${Fmt.price(ltp)})'}.'
                  : 'Sell all ${position.quantity} shares at market'
                        '${ltp == null ? '' : ' (≈ ${Fmt.price(ltp)})'}.',
            ),
            const SizedBox(height: 8),
            Text(
              'Exit charges ≈ ${Fmt.money(charges)}',
              style: const TextStyle(fontSize: 12),
            ),
            if (net != null)
              Text(
                'Realised P&L ≈ ${Fmt.signedMoney(net)}',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: MarketColors.of(dialogContext).forValue(net),
                ),
              ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Keep position'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: Text(short ? 'Cover at market' : 'Exit at market'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    final result = await paper.exitPosition(position);
    if (context.mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(result.message)));
    }
  }

  Future<void> _askPartialExit(BuildContext context, Position position) async {
    final paper = context.read<PaperTradingProvider>();
    final controller = TextEditingController(
      text: '${(position.quantity / 2).floor().clamp(1, position.quantity)}',
    );

    final short = position.isShort;
    final qty = await showDialog<int>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(
          short
              ? 'Cover part of ${position.displaySymbol}'
              : 'Sell part of ${position.displaySymbol}',
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              short
                  ? 'Short ${position.quantity} qty @ ${Fmt.price(position.avgPrice)}.'
                  : 'Holding ${position.quantity} shares '
                        '@ ${Fmt.price(position.avgPrice)}.',
            ),
            const SizedBox(height: 10),
            TextField(
              controller: controller,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: InputDecoration(
                labelText: short ? 'Quantity to cover' : 'Quantity to sell',
                helperText: 'Up to ${position.quantity}',
              ),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              children: [
                for (final fraction in const [0.25, 0.5, 0.75, 1.0])
                  ActionChip(
                    label: Text('${(fraction * 100).toStringAsFixed(0)}%'),
                    visualDensity: VisualDensity.compact,
                    onPressed: () => controller.text =
                        '${(position.quantity * fraction).floor().clamp(1, position.quantity)}',
                  ),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(
              dialogContext,
            ).pop(int.tryParse(controller.text.trim())),
            child: const Text('Sell'),
          ),
        ],
      ),
    );

    if (qty == null || qty <= 0 || qty > position.quantity) return;
    final result = await paper.exitPartial(position, qty);
    if (context.mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(result.message)));
    }
  }

  Future<void> _askStopLoss(BuildContext context, Position position) async {
    final paper = context.read<PaperTradingProvider>();
    final ltp = paper.priceFor(position.priceKey);
    final entry = position.avgPrice;
    final controller = TextEditingController(
      text: (position.stopLoss ?? (ltp ?? entry) * 0.95).toStringAsFixed(2),
    );
    var inPercent = false;

    final applied = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: Text('Stop loss · ${position.displaySymbol}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Average price ${Fmt.price(entry)}'
                '${ltp == null ? '' : ' · LTP ${Fmt.price(ltp)}'}',
                style: const TextStyle(fontSize: 12),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    flex: 3,
                    child: TextField(
                      controller: controller,
                      keyboardType: const TextInputType.numberWithOptions(
                        decimal: true,
                      ),
                      decoration: InputDecoration(
                        labelText: inPercent
                            ? 'Stop loss %'
                            : 'Stop loss price',
                        prefixText: inPercent ? null : '₹ ',
                        suffixText: inPercent ? '%' : null,
                      ),
                      onChanged: (_) => setDialogState(() {}),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    flex: 2,
                    child: SegmentedButton<bool>(
                      segments: const [
                        ButtonSegment(value: false, label: Text('₹')),
                        ButtonSegment(value: true, label: Text('%')),
                      ],
                      selected: {inPercent},
                      onSelectionChanged: (set) => setDialogState(() {
                        inPercent = set.first;
                        controller.text = (inPercent ? 5 : entry * 0.95)
                            .toStringAsFixed(inPercent ? 1 : 2);
                      }),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 6,
                children: [
                  for (final pct in const [2.0, 5.0, 8.0, 10.0])
                    ActionChip(
                      label: Text('−${pct.toStringAsFixed(0)}%'),
                      visualDensity: VisualDensity.compact,
                      onPressed: () => setDialogState(() {
                        inPercent = false;
                        controller.text = (entry * (1 - pct / 100))
                            .toStringAsFixed(2);
                      }),
                    ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                'Checked against every live tick; a breach sells the whole '
                'position at market.',
                style: TextStyle(
                  fontSize: 11,
                  color: Theme.of(dialogContext).colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
          actions: [
            if (position.stopLoss != null)
              TextButton(
                onPressed: () async {
                  await paper.setStopLoss(position);
                  if (dialogContext.mounted) {
                    Navigator.of(dialogContext).pop(false);
                  }
                },
                child: const Text('Remove'),
              ),
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () async {
                final value = double.tryParse(controller.text.trim());
                if (value == null || value <= 0) return;
                await paper.setStopLoss(
                  position,
                  price: inPercent ? null : value,
                  pct: inPercent ? value : null,
                );
                if (dialogContext.mounted) {
                  Navigator.of(dialogContext).pop(true);
                }
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );

    if (applied == true && context.mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(paper.notice)));
    }
  }

  Future<void> _askTarget(BuildContext context, Position position) async {
    final paper = context.read<PaperTradingProvider>();
    final controller = TextEditingController(
      text: (position.target ?? position.avgPrice * 1.1).toStringAsFixed(2),
    );

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text('Target · ${position.displaySymbol}'),
        content: TextField(
          controller: controller,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(
            labelText: 'Target price',
            prefixText: '₹ ',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () async {
              final value = double.tryParse(controller.text.trim());
              await paper.setTarget(position, value);
              if (dialogContext.mounted) Navigator.of(dialogContext).pop();
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  Future<void> _askGroup(BuildContext context, Position position) async {
    final paper = context.read<PaperTradingProvider>();
    var selected = position.groupId;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: Text('Group · ${position.displaySymbol}'),
          content: SingleChildScrollView(
            child: GroupPicker(
              groups: paper.groups,
              selectedId: selected,
              onChanged: (id) => setDialogState(() => selected = id),
              onCreate: (name) async {
                final group = await paper.createGroup(name);
                setDialogState(() => selected = group.id);
              },
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () async {
                await paper.setPositionGroup(position, selected);
                if (dialogContext.mounted) Navigator.of(dialogContext).pop();
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Orders
// ---------------------------------------------------------------------------

class _OrdersTab extends StatelessWidget {
  const _OrdersTab();

  @override
  Widget build(BuildContext context) {
    final paper = context.watch<PaperTradingProvider>();
    final pending = paper.pendingOrderViews;
    final history = paper.filledOrders;
    final scheme = Theme.of(context).colorScheme;

    if (pending.isEmpty && history.isEmpty) {
      return const _EmptyState(
        icon: Icons.receipt_long_outlined,
        title: 'No orders yet',
        message:
            'Market orders fill instantly; LIMIT orders wait here until the '
            'market reaches their price.',
      );
    }

    String groupName(int? id) {
      if (id == null) return 'Ungrouped';
      for (final group in paper.groups) {
        if (group.id == id) return group.name;
      }
      return 'Ungrouped';
    }

    int groupColor(int? id) {
      for (final group in paper.groups) {
        if (group.id == id) return group.colorIndex;
      }
      return 0;
    }

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 90),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (pending.isNotEmpty) ...[
            Text(
              'RESTING (${pending.length})',
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.6,
                color: scheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 6),
            for (var i = 0; i < pending.length; i++) ...[
              FadeSlideIn(
                index: i,
                child: OrderTile(
                  view: pending[i],
                  groupName: groupName(pending[i].order.groupId),
                  groupColorIndex: groupColor(pending[i].order.groupId),
                  onCancel: () => paper.cancelOrder(pending[i].order),
                  onFillNow: () => paper.forceFill(pending[i].order),
                ),
              ),
              const SizedBox(height: 8),
            ],
            const SizedBox(height: 6),
          ],
          if (history.isNotEmpty) ...[
            Text(
              'HISTORY',
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.6,
                color: scheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 6),
            for (final order in history) ...[
              OrderHistoryTile(
                order: order,
                groupName: groupName(order.groupId),
                groupColorIndex: groupColor(order.groupId),
              ),
              const SizedBox(height: 6),
            ],
          ],
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Trade book
// ---------------------------------------------------------------------------

class _TradeBookTab extends StatelessWidget {
  const _TradeBookTab();

  @override
  Widget build(BuildContext context) {
    final paper = context.watch<PaperTradingProvider>();
    final trades = paper.filteredTrades;
    final scheme = Theme.of(context).colorScheme;
    final market = MarketColors.of(context);

    if (trades.isEmpty) {
      // Export / Import khali book me bhi dikhta hai — import ka rasta yahin
      // se milta hai, aur purana data wapas lane ka yahi ek tareeka hai.
      return const Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TradeBookTools(legs: 0),
          _EmptyState(
            icon: Icons.menu_book_outlined,
            title: 'Trade book is empty',
            message:
                'Every fill lands here — entry and exit legs, with '
                'charges and realised P&L per leg.',
          ),
        ],
      );
    }

    final closing = trades.where((t) => t.isClosingLeg).toList(growable: false);
    final realized = closing.fold<double>(
      0,
      (sum, t) => sum + (t.realizedPnl ?? 0),
    );
    final charges = trades.fold<double>(0, (sum, t) => sum + t.charges);

    String groupName(int? id) {
      if (id == null) return 'Ungrouped';
      for (final group in paper.groups) {
        if (group.id == id) return group.name;
      }
      return 'Ungrouped';
    }

    int groupColor(int? id) {
      for (final group in paper.groups) {
        if (group.id == id) return group.colorIndex;
      }
      return 0;
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        TradeBookTools(legs: trades.length),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 90),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: scheme.surfaceContainerHighest.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  children: [
                    Text(
                      '${trades.length} legs · ${closing.length} closed',
                      style: TextStyle(
                        fontSize: 11,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      'charges ${Fmt.money(charges)}',
                      style: TextStyle(
                        fontSize: 11,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      Fmt.signedMoney(realized),
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w700,
                        color: market.forValue(realized),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              for (var i = 0; i < trades.length; i++) ...[
                FadeSlideIn(
                  index: i,
                  child: TradeTile(
                    trade: trades[i],
                    groupName: groupName(trades[i].groupId),
                    groupColorIndex: groupColor(trades[i].groupId),
                    onTap: () => showModalBottomSheet<void>(
                      context: context,
                      isScrollControlled: true,
                      useSafeArea: true,
                      builder: (_) => TradeDetailSheet(
                        trade: trades[i],
                        groupName: groupName(trades[i].groupId),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 7),
              ],
            ],
          ),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Shared bits
// ---------------------------------------------------------------------------

class _EmptyState extends StatelessWidget {
  const _EmptyState({
    required this.icon,
    required this.title,
    required this.message,
    this.actionLabel,
    this.onAction,
  });

  final IconData icon;
  final String title;
  final String message;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(28, 48, 28, 60),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Center(
            child: Stack(
              alignment: Alignment.center,
              children: [
                const BrandWatermark(size: 132),
                Icon(icon, size: 46, color: scheme.onSurfaceVariant),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 6),
          Text(
            message,
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12.5, color: scheme.onSurfaceVariant),
          ),
          if (actionLabel != null) ...[
            const SizedBox(height: 16),
            Center(
              child: FilledButton.tonal(
                onPressed: onAction,
                child: Text(actionLabel!),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
