// ---------------------------------------------------------------------------
// group_manager_screen.dart — Settings → Paper trading → Trade groups.
//
// Where groups are created and curated. Reachable from Settings and from the
// "+ New group" chip in the Buy/Sell sheet (which creates them inline — this
// screen is where you rename, archive or delete them).
//
// Safety rules baked into the UI (locked spec G5–G7):
//   * Archiving hides a group from the picker but keeps every rupee of its P&L
//     reportable — it is the recommended "retire this strategy" action.
//   * Deleting never destroys history: the dialog forces a destination
//     (another group, or Ungrouped) and the trades are reassigned, not removed.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_theme.dart';
import '../../data/local/dao/trade_group_dao.dart';
import '../../data/local/models/trade_group.dart';
import '../paper_trading/paper_trading_provider.dart';

class GroupManagerScreen extends StatefulWidget {
  const GroupManagerScreen({super.key});

  @override
  State<GroupManagerScreen> createState() => _GroupManagerScreenState();
}

class _GroupManagerScreenState extends State<GroupManagerScreen> {
  List<TradeGroup> _groups = const [];
  final Map<int, ({int trades, int positions})> _usage = {};
  bool _loading = true;
  bool _showArchived = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  TradeGroupDao get _dao => context.read<TradeGroupDao>();

  /// Reloads the list and, afterwards, nudges the paper-trading provider so the
  /// chips/filters everywhere else pick the change up immediately.
  Future<void> _load() async {
    setState(() => _loading = true);
    final groups = await _dao.all(includeArchived: _showArchived);
    final usage = <int, ({int trades, int positions})>{};
    for (final group in groups) {
      final id = group.id;
      if (id != null) usage[id] = await _dao.usageCount(id);
    }
    if (!mounted) return;
    setState(() {
      _groups = groups;
      _usage
        ..clear()
        ..addAll(usage);
      _loading = false;
    });
  }

  Future<void> _refreshProvider() =>
      context.read<PaperTradingProvider>().refresh(reloadLists: true);

  // -------------------------------------------------------------------------
  // Actions
  // -------------------------------------------------------------------------

  Future<void> _create() async {
    final name = await _askName(title: 'New group');
    if (name == null) return;
    final all = await _dao.all(includeArchived: true);
    // Create the plain group; the DAO assigns the next palette colour and
    // rejects (via a unique index) a duplicate name.
    final group = await _dao.createNamed(
      name,
      colorIndex: TradeGroup.suggestColorIndex(all.length),
    );
    if (!mounted) return;
    await _load();
    await _refreshProvider();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Group "${group.name}" added.')),
    );
  }

  Future<void> _rename(TradeGroup group) async {
    final name = await _askName(
      title: 'Rename group',
      initial: group.name,
      excludeId: group.id,
    );
    if (name == null) return;
    await _dao.update(group.copyWith(name: name));
    if (!mounted) return;
    await _load();
    await _refreshProvider();
  }

  Future<void> _toggleArchive(TradeGroup group) async {
    final id = group.id;
    if (id == null) return;
    await _dao.archive(id, archived: !group.archived);
    if (!mounted) return;
    await _load();
    await _refreshProvider();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          group.archived
              ? '"${group.name}" is active again.'
              : '"${group.name}" archived — hidden from the trade sheet, keeps '
                  'its P&L.',
        ),
      ),
    );
  }

  Future<void> _delete(TradeGroup group) async {
    final id = group.id;
    if (id == null) return;

    // Destination picker: another group (archived ones excluded) or Ungrouped.
    final others = (await _dao.all())
        .where((candidate) => candidate.id != id)
        .toList(growable: false);
    if (!mounted) return;

    final destination = await showDialog<int?>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text('Delete "${group.name}"?'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'History is never destroyed — every trade that carried this tag '
              'will be re-tagged to the destination you pick.',
              style: TextStyle(fontSize: 12.5),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<int?>(
              initialValue: null,
              decoration: const InputDecoration(labelText: 'Reassign to'),
              items: [
                const DropdownMenuItem<int?>(
                  value: null,
                  child: Text(kUngroupedLabel),
                ),
                for (final other in others)
                  DropdownMenuItem<int?>(
                    value: other.id,
                    child: Text(other.name),
                  ),
              ],
              onChanged: (value) => Navigator.of(dialogContext).pop(value),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(-999),
            child: const Text('Cancel'),
          ),
        ],
      ),
    );

    if (destination == -999) return; // cancelled
    final moved = await _dao.delete(id, reassignTo: destination);
    if (!mounted) return;
    await _load();
    await _refreshProvider();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Group deleted · ${moved.trades} trade'
          '${moved.trades == 1 ? '' : 's'} and ${moved.positions} position'
          '${moved.positions == 1 ? '' : 's'} re-tagged.',
        ),
      ),
    );
  }

  /// Name dialog shared by create/rename. Returns the validated name, or null.
  Future<String?> _askName({
    required String title,
    String initial = '',
    int? excludeId,
  }) async {
    final controller = TextEditingController(text: initial);
    final formKey = GlobalKey<FormState>();

    return showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(title),
        content: Form(
          key: formKey,
          child: TextFormField(
            controller: controller,
            autofocus: true,
            maxLength: TradeGroup.maxNameLength,
            textCapitalization: TextCapitalization.sentences,
            decoration: const InputDecoration(
              labelText: 'Name',
              hintText: 'Momentum, IPO base, Result play…',
            ),
            validator: (value) {
              final errors = TradeGroup.validateName(value ?? '');
              return errors.isEmpty ? null : errors.first;
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () async {
              if (formKey.currentState?.validate() != true) return;
              final name = controller.text.trim();
              final clash = await _dao.nameExists(name, excludingId: excludeId);
              if (clash) {
                if (dialogContext.mounted) {
                  ScaffoldMessenger.of(dialogContext).showSnackBar(
                    SnackBar(content: Text('"$name" already exists.')),
                  );
                }
                return;
              }
              if (dialogContext.mounted) {
                Navigator.of(dialogContext).pop(name);
              }
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  // -------------------------------------------------------------------------
  // UI
  // -------------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Trade groups'),
        actions: [
          IconButton(
            tooltip: _showArchived ? 'Hide archived' : 'Show archived',
            icon: Icon(
              _showArchived
                  ? Icons.visibility_off_outlined
                  : Icons.inventory_2_outlined,
            ),
            onPressed: () {
              setState(() => _showArchived = !_showArchived);
              _load();
            },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _create,
        icon: const Icon(Icons.add_rounded),
        label: const Text('New group'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
              children: [
                Text(
                  'Groups tag a paper trade with the idea behind it, so the '
                  'Reports tab can show which basket actually made money. A '
                  'trade may have no group — that is the Ungrouped bucket.',
                  style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant),
                ),
                const SizedBox(height: 12),
                if (_groups.isEmpty)
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          Icon(Icons.sell_outlined,
                              size: 34, color: scheme.onSurfaceVariant),
                          const SizedBox(height: 10),
                          const Text(
                            'No groups yet',
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Examples: "Momentum", "IPO base", "Long term".',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 12,
                              color: scheme.onSurfaceVariant,
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
                else
                  for (final group in _groups) _groupCard(group),
                const SizedBox(height: 8),
                Text(
                  'Archiving keeps a group\'s P&L in Reports but removes it from '
                  'the trade sheet. Deleting always asks where to move the '
                  'history — nothing is ever thrown away.',
                  style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
                ),
              ],
            ),
    );
  }

  Widget _groupCard(TradeGroup group) {
    final scheme = Theme.of(context).colorScheme;
    final usage = _usage[group.id] ?? (trades: 0, positions: 0);
    final color = GroupPalette.colorAt(group.colorIndex);

    return Card(
      child: ListTile(
        leading: Container(
          width: 12,
          height: 40,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(3),
          ),
        ),
        title: Row(
          children: [
            Flexible(
              child: Text(
                group.name,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
            if (group.archived) ...[
              const SizedBox(width: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                decoration: BoxDecoration(
                  color: scheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  'archived',
                  style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant),
                ),
              ),
            ],
          ],
        ),
        subtitle: Text(
          usage.trades == 0 && usage.positions == 0
              ? 'Not used yet'
              : '${usage.trades} trade${usage.trades == 1 ? '' : 's'} · '
                  '${usage.positions} position'
                  '${usage.positions == 1 ? '' : 's'} open',
          style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
        ),
        trailing: PopupMenuButton<String>(
          onSelected: (value) => switch (value) {
            'rename' => _rename(group),
            'archive' => _toggleArchive(group),
            'delete' => _delete(group),
            _ => null,
          },
          itemBuilder: (context) => [
            const PopupMenuItem(
              value: 'rename',
              child: ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: Icon(Icons.edit_outlined, size: 18),
                title: Text('Rename'),
              ),
            ),
            PopupMenuItem(
              value: 'archive',
              child: ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: Icon(
                  group.archived
                      ? Icons.unarchive_outlined
                      : Icons.archive_outlined,
                  size: 18,
                ),
                title: Text(group.archived ? 'Restore' : 'Archive'),
              ),
            ),
            const PopupMenuItem(
              value: 'delete',
              child: ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: Icon(Icons.delete_outline, size: 18),
                title: Text('Delete (reassign history)'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
