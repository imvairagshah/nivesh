// ---------------------------------------------------------------------------
// portfolio_header.dart — the paper-trading dashboard.
//
// The hero card answers "how am I doing?" in one glance: portfolio value, the
// total return, and where the prices behind those numbers came from (live
// socket / REST snapshot / stale) — because a P&L number you cannot trust is
// worse than no number at all.
//
// Design notes
//   * the hero sits on the brand gradient; the mark's gold is reused for the
//     live dot, so the identity carries through the product
//   * every figure passes through [NumberTicker], so a fill or a tick *rolls*
//     the number instead of snapping it
//   * the four supporting tiles stay flat and quiet — the hero is the hero
//
// The maths comes from PortfolioSnapshot (see portfolio_math.dart), where the
// cash identity is asserted in tests:
//     portfolioValue = availableCash + marketValue
//     totalPnl       = portfolioValue − startingCapital
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/widgets/brand.dart';
import '../../../core/widgets/motion.dart';
import '../../../services/live_feed_service.dart';
import '../paper_trading_provider.dart';

class PortfolioHeader extends StatelessWidget {
  const PortfolioHeader({super.key});

  @override
  Widget build(BuildContext context) {
    final paper = context.watch<PaperTradingProvider>();
    final snapshot = paper.snapshot;
    final market = MarketColors.of(context);

    // While the very first load is in flight there is nothing truthful to
    // show — a skeleton beats a row of zeroes.
    if (paper.isLoading && paper.allHoldings.isEmpty && paper.tradeBook.isEmpty) {
      return const Padding(
        padding: EdgeInsets.fromLTRB(12, 12, 12, 4),
        child: ShimmerCard(lines: 2),
      );
    }

    final pnlColor = snapshot.totalPnl >= 0
        ? const Color(0xFF8BF3C4)
        : const Color(0xFFFFB4AB);

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // ---------------------------------------------------------------
          // Hero: portfolio value + total return, on the brand gradient
          // ---------------------------------------------------------------
          Container(
            padding: const EdgeInsets.fromLTRB(16, 14, 12, 14),
            decoration: BoxDecoration(
              gradient: Brand.heroGradient(
                dark: Theme.of(context).brightness == Brightness.dark,
              ),
              borderRadius: BorderRadius.circular(AppRadius.xl),
              boxShadow: AppTheme.softShadow(
                Theme.of(context).brightness,
                y: 10,
              ),
            ),
            child: Stack(
              children: [
                // A faint gold sweep + a watermark mark keep the surface from
                // looking like a flat rectangle of green.
                Positioned(
                  right: -28,
                  top: -30,
                  child: Opacity(
                    opacity: 0.16,
                    child: BrandMark(
                      size: 132,
                      showBackground: false,
                      monochrome: true,
                    ),
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'PORTFOLIO VALUE',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 1.2,
                                  color: Color(0xB3FFFFFF),
                                ),
                              ),
                              const SizedBox(height: 4),
                              NumberTicker(
                                value: snapshot.portfolioValue,
                                format: Fmt.money,
                                style: const TextStyle(
                                  fontSize: 28,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: -0.8,
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ),
                        ),
                        _FeedChip(paper: paper, onDark: true),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 3,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.14),
                            borderRadius: BorderRadius.circular(AppRadius.pill),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                snapshot.totalPnl >= 0
                                    ? Icons.arrow_upward_rounded
                                    : Icons.arrow_downward_rounded,
                                size: 13,
                                color: pnlColor,
                              ),
                              const SizedBox(width: 3),
                              NumberTicker(
                                value: snapshot.totalPnl,
                                format: Fmt.signedMoney,
                                style: TextStyle(
                                  fontSize: 12.5,
                                  fontWeight: FontWeight.w700,
                                  color: pnlColor,
                                ),
                              ),
                              const SizedBox(width: 5),
                              NumberTicker(
                                value: snapshot.totalPnlPct,
                                format: (v) => '(${Fmt.signedPct(v)})',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: pnlColor.withOpacity(0.9),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'on ${Fmt.moneyCompact(snapshot.startingCapital)} capital',
                            style: const TextStyle(
                              fontSize: 11,
                              color: Color(0xB3FFFFFF),
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),

          // ---------------------------------------------------------------
          // Supporting numbers
          // ---------------------------------------------------------------
          Row(
            children: [
              Expanded(
                child: _Tile(
                  label: 'Available cash',
                  value: snapshot.availableCash,
                  hint: '${snapshot.cashPct.toStringAsFixed(0)}% of account',
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: _Tile(
                  label: 'Invested',
                  value: snapshot.marketValue,
                  hint: '${snapshot.openPositions} position'
                      '${snapshot.openPositions == 1 ? '' : 's'}'
                      '${snapshot.pendingOrders > 0 ? ' · ${snapshot.pendingOrders} pending' : ''}',
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: _Tile(
                  label: 'Realised',
                  value: snapshot.realizedPnl,
                  hint: '${snapshot.closedTrades} closed',
                  valueColor: market.forValue(snapshot.realizedPnl),
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: _Tile(
                  label: 'Unrealised',
                  value: snapshot.unrealizedPnl,
                  hint: snapshot.hasUnpricedPositions ? 'partly unpriced' : 'live',
                  valueColor: market.forValue(snapshot.unrealizedPnl),
                ),
              ),
            ],
          ),

          if (snapshot.hasUnpricedPositions || paper.error != null) ...[
            const SizedBox(height: 8),
            _Banner(
              message: paper.error ??
                  'Some positions have no price yet — pull down to refresh.',
              isError: paper.error != null,
            ),
          ] else if (paper.notice.isNotEmpty) ...[
            const SizedBox(height: 8),
            _Banner(message: paper.notice, isError: false),
          ],
        ],
      ),
    );
  }
}

/// "LIVE · 15:42:07" style provenance chip, with the manual refresh button.
/// [onDark] switches it to the white-on-green variant used inside the hero.
class _FeedChip extends StatelessWidget {
  const _FeedChip({required this.paper, this.onDark = false});

  final PaperTradingProvider paper;
  final bool onDark;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final market = MarketColors.of(context);
    final feed = paper.feed;

    final (Color color, String label) = switch (feed.status) {
      FeedStatus.connected => (onDark ? Brand.gold : market.gain, 'LIVE'),
      FeedStatus.connecting => (
          onDark ? Brand.gold : market.stale,
          'CONNECTING'
        ),
      FeedStatus.reconnecting => (
          onDark ? Brand.gold : market.stale,
          'RECONNECTING'
        ),
      FeedStatus.error => (onDark ? const Color(0xFFFFB4AB) : market.loss, 'FEED ERR'),
      FeedStatus.idle => (
          onDark
              ? const Color(0xCCFFFFFF)
              : (paper.lastPriceAt == null
                  ? scheme.onSurfaceVariant
                  : market.stale),
          paper.lastPriceAt == null ? 'OFFLINE' : 'SNAPSHOT',
        ),
    };

    final isLive = feed.status == FeedStatus.connected;
    final background = onDark
        ? Colors.white.withOpacity(0.14)
        : color.withOpacity(0.12);
    final border = onDark ? Colors.white.withOpacity(0.22) : color.withOpacity(0.4);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        PressScale(
          child: InkWell(
            borderRadius: BorderRadius.circular(AppRadius.pill),
            onTap: () => paper.refreshPricesViaRest(force: true),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
              decoration: BoxDecoration(
                color: background,
                borderRadius: BorderRadius.circular(AppRadius.pill),
                border: Border.all(color: border),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Live really *is* live: the dot breathes only while the
                  // socket is delivering ticks.
                  if (isLive)
                    PulseDot(color: color, size: 7)
                  else
                    Container(
                      width: 7,
                      height: 7,
                      decoration: BoxDecoration(
                        color: color,
                        shape: BoxShape.circle,
                      ),
                    ),
                  const SizedBox(width: 5),
                  Text(
                    label,
                    style: TextStyle(
                      fontSize: 9.5,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.5,
                      color: onDark ? Colors.white : color,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 3),
        Text(
          feed.lastTickAt != null
              ? 'tick ${Fmt.clock(feed.lastTickAt)}'
              : (paper.lastPriceAt != null
                  ? 'prices ${Fmt.relative(paper.lastPriceAt)}'
                  : 'no prices yet'),
          style: TextStyle(
            fontSize: 9.5,
            color: onDark
                ? const Color(0x99FFFFFF)
                : scheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }
}

/// Compact figure tile. Its number animates whenever the value changes.
class _Tile extends StatelessWidget {
  const _Tile({
    required this.label,
    required this.value,
    required this.hint,
    this.valueColor,
  });

  final String label;
  final double value;
  final String hint;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 9),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest.withOpacity(0.45),
        borderRadius: BorderRadius.circular(AppRadius.md),
        border: Border.all(color: scheme.outlineVariant.withOpacity(0.4)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label.toUpperCase(),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 8.5,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.5,
              color: scheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 3),
          NumberTicker(
            value: value,
            format: Fmt.moneyCompact,
            countUpOnFirstBuild: false,
            style: TextStyle(
              fontSize: 13.5,
              fontWeight: FontWeight.w700,
              color: valueColor,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 1),
          Text(
            hint,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: 9, color: scheme.onSurfaceVariant),
          ),
        ],
      ),
    );
  }
}

class _Banner extends StatelessWidget {
  const _Banner({required this.message, required this.isError});

  final String message;
  final bool isError;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final market = MarketColors.of(context);
    final color = isError ? market.loss : market.stale;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: color.withOpacity(0.10),
        borderRadius: BorderRadius.circular(AppRadius.sm),
        border: Border.all(color: color.withOpacity(0.30)),
      ),
      child: Row(
        children: [
          Icon(
            isError ? Icons.error_outline_rounded : Icons.info_outline_rounded,
            size: 14,
            color: color,
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              message,
              style: TextStyle(
                fontSize: 11,
                color: isError ? color : scheme.onSurfaceVariant,
              ),
            ),
          ),
          if (isError)
            InkWell(
              onTap: () => context.read<PaperTradingProvider>().clearError(),
              child: Icon(Icons.close_rounded, size: 14, color: color),
            ),
        ],
      ),
    );
  }
}
