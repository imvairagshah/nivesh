// ---------------------------------------------------------------------------
// trade_tile.dart — one leg of the trade book (plus its detail sheet).
//
// The trade book is the audit trail: every fill, with the price it happened at,
// the charges the broker would have taken, and — on closing legs — the realised
// P&L that also feeds the Reports tab. Tapping a row opens the full record.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/utils/link_opener.dart';
import '../../../data/local/models/paper_trade.dart';
import 'group_chips.dart';

class TradeTile extends StatelessWidget {
  const TradeTile({
    super.key,
    required this.trade,
    required this.groupName,
    required this.groupColorIndex,
    this.onTap,
  });

  final Trade trade;
  final String groupName;
  final int groupColorIndex;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final market = MarketColors.of(context);
    final isBuy = trade.side == OrderSide.buy;
    final sideColor = isBuy ? market.gain : market.loss;
    final pnl = trade.realizedPnl;

    return Card(
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 9, 10, 9),
          child: Row(
            children: [
              Container(
                width: 4,
                height: 40,
                decoration: BoxDecoration(
                  color: sideColor,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          '${trade.side.label} ${Fmt.qty(trade.quantity)} '
                          '${trade.displaySymbol}',
                          style: const TextStyle(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          '@ ${Fmt.price(trade.price)}',
                          style: TextStyle(
                            fontSize: 12,
                            color: scheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        GroupBadge(
                          name: groupName,
                          colorIndex: groupColorIndex,
                          isUngrouped: trade.groupId == null,
                          dense: true,
                        ),
                        const SizedBox(width: 6),
                        Flexible(
                          child: Text(
                            '${Fmt.dateTime(trade.executedAt)} · '
                            'charges ${Fmt.price(trade.charges)}',
                            style: TextStyle(
                              fontSize: 10,
                              color: scheme.onSurfaceVariant,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    pnl == null ? '${Fmt.money(trade.value)}' : Fmt.signedMoney(pnl),
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: pnl == null ? null : market.forValue(pnl),
                    ),
                  ),
                  Text(
                    pnl == null
                        ? 'value'
                        : 'realised${pnl >= 0 ? '' : ' · loss'}',
                    style: TextStyle(
                      fontSize: 9.5,
                      color: pnl == null
                          ? scheme.onSurfaceVariant
                          : market.forValue(pnl),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Full detail for one leg — opened by tapping a [TradeTile].
class TradeDetailSheet extends StatelessWidget {
  const TradeDetailSheet({
    super.key,
    required this.trade,
    required this.groupName,
  });

  final Trade trade;
  final String groupName;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final market = MarketColors.of(context);
    final pnl = trade.realizedPnl;

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                '${trade.side.label} ${trade.displaySymbol}',
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
              ),
              const SizedBox(width: 8),
              GroupBadge(
                name: groupName,
                colorIndex: 0,
                isUngrouped: trade.groupId == null,
                dense: true,
              ),
            ],
          ),
          const SizedBox(height: 12),
          _Row(label: 'Exchange', value: trade.exchange.code),
          _Row(label: 'Token', value: trade.token.isEmpty ? '—' : trade.token),
          _Row(label: 'Quantity', value: Fmt.qty(trade.quantity)),
          _Row(label: 'Fill price', value: Fmt.price(trade.price)),
          _Row(label: 'Order type', value: trade.orderType.label),
          _Row(label: 'Value', value: Fmt.money(trade.value)),
          _Row(label: 'Charges', value: Fmt.money(trade.charges)),
          _Row(
            label: trade.isClosingLeg ? 'Realised P&L' : 'Position',
            value: trade.isClosingLeg
                ? Fmt.signedMoney(pnl)
                : '#${trade.positionId ?? '—'}',
            valueColor: trade.isClosingLeg ? market.forValue(pnl) : null,
          ),
          _Row(label: 'Executed', value: Fmt.dateTime(trade.executedAt)),
          if (trade.note.isNotEmpty) _Row(label: 'Note', value: trade.note),
          const SizedBox(height: 8),
          Text(
            trade.isClosingLeg
                ? 'Realised P&L is net of this leg\'s charges and of the opening '
                    'leg\'s share of charges.'
                : 'Opening leg: charges are carried on the position and deducted '
                    'when it is finally sold.',
            style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              OutlinedButton.icon(
                onPressed: () => LinkOpener.open(
                  LinkOpener.tradingViewUrl(
                    trade.exchange.code,
                    trade.displaySymbol,
                  ),
                  context: context,
                ),
                icon: const Icon(Icons.open_in_new_rounded, size: 16),
                label: const Text('Chart'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Row extends StatelessWidget {
  const _Row({required this.label, required this.value, this.valueColor});

  final String label;
  final String value;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 110,
            child: Text(
              label,
              style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w600,
                color: valueColor,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
