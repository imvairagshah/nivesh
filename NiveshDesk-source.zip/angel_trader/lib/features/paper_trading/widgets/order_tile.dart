// ---------------------------------------------------------------------------
// order_tile.dart — one row of the Orders tab.
//
// A pending LIMIT order shows how far the market still has to travel to fill it
// (and a "Fill now" shortcut when it is already marketable, i.e. the level has
// been crossed since the last refresh). Filled/cancelled/rejected orders show
// what happened and why — a rejected order keeps its reason so the user is never
// left guessing why nothing appeared in the trade book.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../data/local/models/paper_trade.dart';
import '../portfolio_math.dart';
import 'group_chips.dart';

class OrderTile extends StatelessWidget {
  const OrderTile({
    super.key,
    required this.view,
    required this.groupName,
    required this.groupColorIndex,
    this.onCancel,
    this.onFillNow,
  });

  /// Pending order + its live price.
  final PendingOrderView view;

  final String groupName;
  final int groupColorIndex;

  final VoidCallback? onCancel;

  /// Manual fill trigger (shown when the level has already been crossed).
  final VoidCallback? onFillNow;

  PaperOrder get order => view.order;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final market = MarketColors.of(context);
    final isBuy = order.side == OrderSide.buy;
    final sideColor = isBuy ? market.gain : market.loss;

    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 10, 10, 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: sideColor.withOpacity(0.14),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    order.side.label.toUpperCase(),
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      color: sideColor,
                    ),
                  ),
                ),
                const SizedBox(width: 7),
                Text(
                  order.displaySymbol,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  order.orderType.label.toUpperCase(),
                  style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant),
                ),
                const Spacer(),
                GroupBadge(
                  name: groupName,
                  colorIndex: groupColorIndex,
                  isUngrouped: order.groupId == null,
                  dense: true,
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: _Meta(
                    label: 'Qty @ limit',
                    value:
                        '${Fmt.qty(order.quantity)} @ ${order.limitPrice == null ? 'market' : Fmt.price(order.limitPrice!)}',
                  ),
                ),
                Expanded(
                  child: _Meta(
                    label: 'LTP',
                    value: view.ltp == null ? '—' : Fmt.price(view.ltp!),
                  ),
                ),
                Expanded(
                  child: _Meta(
                    label: 'Distance',
                    value: view.distancePct == null
                        ? '—'
                        : '${view.distancePct! >= 0 ? '+' : ''}'
                            '${view.distancePct!.toStringAsFixed(2)}%',
                    valueColor: view.isMarketable ? market.gain : null,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(
                  order.status == OrderStatus.pending
                      ? Icons.hourglass_bottom_rounded
                      : Icons.check_circle_outline_rounded,
                  size: 13,
                  color: scheme.onSurfaceVariant,
                ),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    order.status == OrderStatus.pending
                        ? 'Placed ${Fmt.relative(order.createdAt)}'
                          '${view.isMarketable ? ' · level already crossed' : ''}'
                        : 'Placed ${Fmt.dateTime(order.createdAt)}',
                    style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
                  ),
                ),
                if (order.status == OrderStatus.pending && view.isMarketable)
                  TextButton.icon(
                    onPressed: onFillNow,
                    icon: const Icon(Icons.bolt_rounded, size: 16),
                    label: const Text('Fill now'),
                  ),
                if (order.status == OrderStatus.pending)
                  TextButton(
                    onPressed: onCancel,
                    child: const Text('Cancel'),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Compact row for a finished order (filled / cancelled / rejected).
class OrderHistoryTile extends StatelessWidget {
  const OrderHistoryTile({
    super.key,
    required this.order,
    required this.groupName,
    required this.groupColorIndex,
  });

  final PaperOrder order;
  final String groupName;
  final int groupColorIndex;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final market = MarketColors.of(context);
    final isBuy = order.side == OrderSide.buy;
    final sideColor = isBuy ? market.gain : market.loss;

    final (Color statusColor, IconData statusIcon) = switch (order.status) {
      OrderStatus.filled => (market.gain, Icons.check_circle_rounded),
      OrderStatus.cancelled => (scheme.onSurfaceVariant, Icons.cancel_outlined),
      OrderStatus.rejected => (market.loss, Icons.error_outline_rounded),
      OrderStatus.pending => (market.stale, Icons.hourglass_bottom_rounded),
    };

    return Card(
      child: ListTile(
        dense: true,
        leading: Container(
          width: 4,
          height: 34,
          decoration: BoxDecoration(
            color: sideColor,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        title: Row(
          children: [
            Text(
              '${order.side.label} ${Fmt.qty(order.quantity)} '
              '${order.displaySymbol}',
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
            ),
            const SizedBox(width: 6),
            Icon(statusIcon, size: 13, color: statusColor),
            const Spacer(),
            GroupBadge(
              name: groupName,
              colorIndex: groupColorIndex,
              isUngrouped: order.groupId == null,
              dense: true,
            ),
          ],
        ),
        subtitle: Text(
          [
            order.orderType.label,
            if (order.limitPrice != null) '@ ${Fmt.price(order.limitPrice!)}',
            if (order.filledPrice != null) 'filled ${Fmt.price(order.filledPrice!)}',
            Fmt.dateTime(order.filledAt ?? order.createdAt),
            if (order.note.isNotEmpty) order.note,
          ].join(' · '),
          style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
        ),
      ),
    );
  }
}

class _Meta extends StatelessWidget {
  const _Meta({required this.label, required this.value, this.valueColor});

  final String label;
  final String value;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant)),
        Text(
          value,
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: valueColor,
          ),
        ),
      ],
    );
  }
}
