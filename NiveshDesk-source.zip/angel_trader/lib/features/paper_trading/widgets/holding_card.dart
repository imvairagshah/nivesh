// ---------------------------------------------------------------------------
// holding_card.dart — one open position.
//
// Shows what a trader needs to decide, in this order:
//   symbol + strategy group            → what is this trade?
//   qty × average price, invested      → what did I put in?
//   LTP (live dot) + % change          → where is it now?
//   unrealised P&L (₹ and %)           → am I up or down?
//   a stop↔target range bar            → how far from either exit?
//
// and offers the actions: exit at market, partial exit, set/clear stop loss,
// set target, re-tag the group, open the TradingView chart.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/utils/markets.dart' show Exchange;
import '../../../core/utils/link_opener.dart';
import '../../../data/local/models/paper_trade.dart';
import '../portfolio_math.dart';
import 'group_chips.dart';

class HoldingCard extends StatelessWidget {
  const HoldingCard({
    super.key,
    required this.holding,
    required this.onExit,
    required this.onPartialExit,
    required this.onSetStopLoss,
    required this.onSetTarget,
    required this.onChangeGroup,
  });

  final HoldingView holding;
  final VoidCallback onExit;
  final VoidCallback onPartialExit;
  final VoidCallback onSetStopLoss;
  final VoidCallback onSetTarget;
  final VoidCallback onChangeGroup;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final market = MarketColors.of(context);
    final position = holding.position;
    final pnl = holding.unrealizedPnl;

    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 10, 8, 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ---- header: symbol, group, actions
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            position.displaySymbol,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(width: 6),
                          Text(
                            position.exchange.code,
                            style: TextStyle(
                              fontSize: 10,
                              color: scheme.onSurfaceVariant,
                            ),
                          ),
                          // Long/short tag: for options a "bought" and a
                          // "written" position look identical otherwise.
                          if (position.exchange == Exchange.nfo ||
                              position.isShort) ...[
                            const SizedBox(width: 6),
                            _SideBadge(position: position),
                          ],
                          if (holding.isLive) ...[
                            const SizedBox(width: 6),
                            Tooltip(
                              message: 'Live price from the WebSocket feed',
                              child: Container(
                                width: 6,
                                height: 6,
                                decoration: BoxDecoration(
                                  color: market.gain,
                                  shape: BoxShape.circle,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                      const SizedBox(height: 3),
                      GroupBadge(
                        name: holding.groupName,
                        colorIndex: holding.groupColorIndex,
                        isUngrouped: position.groupId == null,
                        dense: true,
                      ),
                    ],
                  ),
                ),
                _ActionsMenu(
                  position: position,
                  onExit: onExit,
                  onPartialExit: onPartialExit,
                  onSetStopLoss: onSetStopLoss,
                  onSetTarget: onSetTarget,
                  onChangeGroup: onChangeGroup,
                ),
              ],
            ),
            const SizedBox(height: 10),

            // ---- the numbers
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: _KeyValue(
                    label: 'Qty × avg',
                    value: '${Fmt.qty(position.quantity)} × '
                        '${Fmt.price(position.avgPrice)}',
                    // A short didn't spend money — it *received* the premium.
                    sub: position.isShort
                        ? 'premium ${Fmt.moneyCompact(holding.invested)}'
                        : 'invested ${Fmt.moneyCompact(holding.invested)}',
                  ),
                ),
                Expanded(
                  child: _KeyValue(
                    label: 'LTP',
                    value: holding.ltp == null
                        ? '—'
                        : Fmt.price(holding.ltp!),
                    sub: holding.isLive
                        ? 'live'
                        : Fmt.relative(holding.pricedAt),
                    valueColor: holding.isLive ? null : scheme.onSurfaceVariant,
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        pnl == null ? '—' : Fmt.signedMoney(pnl),
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: market.forValue(pnl),
                        ),
                      ),
                      Text(
                        holding.unrealizedPct == null
                            ? 'no price yet'
                            : '${Fmt.signedPct(holding.unrealizedPct)} '
                                'on ${Fmt.moneyCompact(holding.invested)}',
                        style: TextStyle(
                          fontSize: 11,
                          color: market.forValue(pnl),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 10),
            _StopTargetBar(holding: holding),

            // ---- a breached stop is loud, because it is about to be executed
            if (holding.stopBreached) ...[
              const SizedBox(height: 6),
              _Alert(
                color: market.loss,
                icon: Icons.warning_amber_rounded,
                text: 'Stop loss hit — auto-exiting at market',
              ),
            ] else if (holding.targetReached) ...[
              const SizedBox(height: 6),
              _Alert(
                color: market.gain,
                icon: Icons.flag_rounded,
                text: 'Target reached',
              ),
            ],
          ],
        ),
      ),
    );
  }
}

/// Visualises where the LTP sits between the stop (left) and the target (right).
class _StopTargetBar extends StatelessWidget {
  const _StopTargetBar({required this.holding});

  final HoldingView holding;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final market = MarketColors.of(context);
    final position = holding.position;
    final ltp = holding.ltp;
    final sl = position.stopLoss;
    final target = position.target;

    if (sl == null && target == null) {
      return Row(
        children: [
          Icon(Icons.shield_outlined, size: 13, color: scheme.onSurfaceVariant),
          const SizedBox(width: 5),
          Text(
            'No stop loss — auto-exit is off for this position',
            style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
          ),
        ],
      );
    }

    // Anchor the bar on the range the position can move through: from the stop
    // to the target (or ±10% around entry when one is missing). A **short** has
    // them the other way round — the stop sits above the entry price, the
    // target below — so the band is mirrored, otherwise the marker would sit
    // outside the bar.
    final anchor = position.avgPrice;
    final low = position.isShort
        ? (target ?? anchor * 0.9).abs()
        : (sl ?? anchor * 0.9);
    final high = position.isShort
        ? (sl ?? anchor * 1.1)
        : (target ?? anchor * 1.1);
    final span = (high - low).abs() < 0.01 ? 1.0 : high - low;
    final fraction = ltp == null
        ? null
        : ((ltp - low) / span).clamp(0.0, 1.0);
    final entryFraction = ((position.avgPrice - low) / span).clamp(0.0, 1.0);

    return Column(
      children: [
        LayoutBuilder(
          builder: (context, constraints) {
            return SizedBox(
              height: 8,
              child: Stack(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      color: scheme.surfaceContainerHighest,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                  // entry marker
                  Positioned(
                    left: constraints.maxWidth * entryFraction - 1,
                    top: -2,
                    bottom: -2,
                    child: Container(width: 2, color: scheme.outline),
                  ),
                  if (fraction != null)
                    Positioned(
                      left: constraints.maxWidth * fraction - 3,
                      child: Container(
                        width: 6,
                        height: 8,
                        decoration: BoxDecoration(
                          color: market.forValue(holding.unrealizedPnl),
                          borderRadius: BorderRadius.circular(3),
                        ),
                      ),
                    ),
                ],
              ),
            );
          },
        ),
        const SizedBox(height: 3),
        Row(
          children: [
            if (sl != null)
              Text(
                'SL ${Fmt.price(sl)}'
                '${position.stopLossPct == null ? '' : ' (−${position.stopLossPct!.toStringAsFixed(1)}%)'}',
                style: TextStyle(fontSize: 10, color: market.loss),
              ),
            const Spacer(),
            if (target != null)
              Text(
                'T ${Fmt.price(target)}'
                '${position.targetPct == null ? '' : ' (+${position.targetPct!.toStringAsFixed(1)}%)'}',
                style: TextStyle(fontSize: 10, color: market.gain),
              ),
          ],
        ),
      ],
    );
  }
}

class _ActionsMenu extends StatelessWidget {
  const _ActionsMenu({
    required this.position,
    required this.onExit,
    required this.onPartialExit,
    required this.onSetStopLoss,
    required this.onSetTarget,
    required this.onChangeGroup,
  });

  final Position position;
  final VoidCallback onExit;
  final VoidCallback onPartialExit;
  final VoidCallback onSetStopLoss;
  final VoidCallback onSetTarget;
  final VoidCallback onChangeGroup;

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<String>(
      tooltip: 'Position actions',
      icon: const Icon(Icons.more_vert_rounded, size: 20),
      onSelected: (value) {
        switch (value) {
          case 'exit':
            onExit();
          case 'partial':
            onPartialExit();
          case 'sl':
            onSetStopLoss();
          case 'target':
            onSetTarget();
          case 'group':
            onChangeGroup();
          case 'chart':
            // Same URL scheme as the IPO / Golden Cross cards.
            LinkOpener.open(
              LinkOpener.tradingViewUrl(
                position.exchange.code,
                position.displaySymbol,
              ),
              context: context,
            );
        }
      },
      itemBuilder: (context) => [
        PopupMenuItem(
          value: 'exit',
          child: ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.exit_to_app_rounded, size: 18),
            // A short is closed by buying it back, not by selling.
            title: Text(position.isShort ? 'Cover at market' : 'Exit at market'),
          ),
        ),
        if (position.quantity > 1)
          PopupMenuItem(
            value: 'partial',
            child: ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.call_split_rounded, size: 18),
              title: Text(position.isShort
                  ? 'Cover part of it'
                  : 'Sell part of it'),
            ),
          ),
        PopupMenuItem(
          value: 'sl',
          child: ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.shield_outlined, size: 18),
            title: Text(position.stopLoss == null
                ? 'Set stop loss'
                : 'Change stop loss'),
          ),
        ),
        PopupMenuItem(
          value: 'target',
          child: ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.flag_outlined, size: 18),
            title: Text(position.target == null ? 'Set target' : 'Change target'),
          ),
        ),
        const PopupMenuItem(
          value: 'group',
          child: ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            leading: Icon(Icons.sell_outlined, size: 18),
            title: Text('Change group'),
          ),
        ),
        const PopupMenuItem(
          value: 'chart',
          child: ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            leading: Icon(Icons.open_in_new_rounded, size: 18),
            title: Text('TradingView chart'),
          ),
        ),
      ],
    );
  }
}

class _KeyValue extends StatelessWidget {
  const _KeyValue({
    required this.label,
    required this.value,
    this.sub,
    this.valueColor,
  });

  final String label;
  final String value;
  final String? sub;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant)),
        const SizedBox(height: 1),
        Text(
          value,
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: valueColor,
          ),
        ),
        if (sub != null)
          Text(sub!, style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant)),
      ],
    );
  }
}

class _Alert extends StatelessWidget {
  const _Alert({required this.color, required this.icon, required this.text});

  final Color color;
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Icon(icon, size: 13, color: color),
          const SizedBox(width: 5),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: color,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Tiny L / S tag shown next to an option (or any short) position.
class _SideBadge extends StatelessWidget {
  const _SideBadge({required this.position});

  final Position position;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final market = MarketColors.of(context);
    final short = position.isShort;
    final color = short ? market.loss : market.gain;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: color.withValues(alpha: 0.45)),
      ),
      child: Text(
        short ? 'SHORT' : 'LONG',
        style: TextStyle(
          fontSize: 8.5,
          fontWeight: FontWeight.w800,
          letterSpacing: 0.4,
          color: short ? color : scheme.onSurfaceVariant,
        ),
      ),
    );
  }
}
