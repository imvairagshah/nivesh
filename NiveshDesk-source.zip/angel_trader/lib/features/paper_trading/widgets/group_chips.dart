// ---------------------------------------------------------------------------
// group_chips.dart — the strategy-tag UI shared by the trade sheet and the lists.
//
//   [GroupPicker]      chips to choose the group for a trade (with "+ New group")
//   [GroupFilterBar]   a horizontally scrolling filter: All · Ungrouped · groups
//   [GroupBadge]       the little coloured label shown on a holding/trade row
//
// Groups are the Feature-3 addition the user asked for ("group pehle se add karke
// rakh saku…"), so the picker is ordered by *usage*: the baskets a trader actually
// uses float to the front instead of appearing in creation order.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/local/models/trade_group.dart';
import '../paper_trading_provider.dart';

/// Coloured pill showing one group (or Ungrouped).
class GroupBadge extends StatelessWidget {
  const GroupBadge({
    super.key,
    required this.name,
    this.colorIndex = 0,
    this.isUngrouped = false,
    this.dense = false,
  });

  final String name;
  final int colorIndex;
  final bool isUngrouped;
  final bool dense;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final color = isUngrouped
        ? scheme.onSurfaceVariant
        : GroupPalette.colorAt(colorIndex);

    return Container(
      padding: EdgeInsets.symmetric(horizontal: dense ? 6 : 8, vertical: dense ? 1 : 3),
      decoration: BoxDecoration(
        color: isUngrouped
            ? scheme.surfaceContainerHighest
            : GroupPalette.tintAt(colorIndex, Theme.of(context).brightness),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.45)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: dense ? 6 : 7,
            height: dense ? 6 : 7,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 5),
          Text(
            name,
            style: TextStyle(
              fontSize: dense ? 10 : 11,
              fontWeight: FontWeight.w600,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

/// Chip row for picking the group of an order.
class GroupPicker extends StatelessWidget {
  const GroupPicker({
    super.key,
    required this.groups,
    required this.selectedId,
    required this.onChanged,
    required this.onCreate,
  });

  /// Groups ordered by usage (the provider already returns them that way).
  final List<TradeGroup> groups;

  /// `null` == Ungrouped.
  final int? selectedId;

  final ValueChanged<int?> onChanged;

  /// Called with a brand-new name; the caller creates it and selects it.
  final Future<void> Function(String name) onCreate;

  Future<void> _promptNewGroup(BuildContext context) async {
    final controller = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('New group'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: controller,
              autofocus: true,
              textCapitalization: TextCapitalization.words,
              maxLength: TradeGroup.maxNameLength,
              decoration: const InputDecoration(
                hintText: 'e.g. Momentum, IPO base, Result play',
                labelText: 'Group name',
              ),
              onSubmitted: (value) => Navigator.of(dialogContext).pop(value),
            ),
            const Text(
              'Groups are reusable: they show up on every trade sheet and get '
              'their own P&L in Reports.',
              style: TextStyle(fontSize: 11),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(controller.text),
            child: const Text('Create'),
          ),
        ],
      ),
    );

    final trimmed = (name ?? '').trim();
    if (trimmed.isEmpty) return;

    final errors = TradeGroup.validateName(trimmed);
    if (errors.isNotEmpty) {
      if (context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(errors.first)));
      }
      return;
    }
    await onCreate(trimmed);
  }

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 6,
      runSpacing: 6,
      children: [
        ChoiceChip(
          label: const Text(kUngroupedLabel),
          selected: selectedId == null,
          onSelected: (_) => onChanged(null),
        ),
        for (final group in groups)
          ChoiceChip(
            avatar: CircleAvatar(
              radius: 6,
              backgroundColor: GroupPalette.colorAt(group.colorIndex),
            ),
            label: Text(group.name),
            selected: selectedId == group.id,
            onSelected: (_) => onChanged(group.id),
          ),
        ActionChip(
          avatar: const Icon(Icons.add, size: 16),
          label: const Text('New group'),
          onPressed: () => _promptNewGroup(context),
        ),
      ],
    );
  }
}

/// Horizontal filter bar used above the Holdings / Orders / Trade Book lists.
class GroupFilterBar extends StatelessWidget {
  const GroupFilterBar({super.key, this.showUngrouped = true});

  final bool showUngrouped;

  @override
  Widget build(BuildContext context) {
    final paper = context.watch<PaperTradingProvider>();
    final filter = paper.filter;
    final scheme = Theme.of(context).colorScheme;

    return SizedBox(
      height: 40,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        children: [
          FilterChip(
            label: const Text('All groups'),
            selected: filter.groupId == null && !filter.ungroupedOnly,
            onSelected: (_) => paper.setGroupFilter(null),
          ),
          if (showUngrouped) ...[
            const SizedBox(width: 6),
            FilterChip(
              label: const Text(kUngroupedLabel),
              selected: filter.ungroupedOnly,
              onSelected: (selected) => paper.setGroupFilter(
                null,
                ungroupedOnly: selected,
              ),
            ),
          ],
          for (final group in paper.groups) ...[
            const SizedBox(width: 6),
            FilterChip(
              avatar: CircleAvatar(
                radius: 6,
                backgroundColor: GroupPalette.colorAt(group.colorIndex),
              ),
              label: Text(group.name),
              selected: filter.groupId == group.id,
              onSelected: (_) => paper.setGroupFilter(group.id),
            ),
          ],
          if (paper.groups.isEmpty) ...[
            const SizedBox(width: 10),
            Center(
              child: Text(
                'No groups yet — create one while placing a trade',
                style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
