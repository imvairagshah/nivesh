// ---------------------------------------------------------------------------
// order_sheet.dart — the Buy / Sell sheet.
//
// One modal that collects everything the product brief asks for:
//   symbol (with search over the cached scrip master)
//   Buy / Sell, quantity (with quick amounts and a Max that leaves room for
//   charges), MARKET or LIMIT price (tick-rounded)
//   stop loss as a price *or* a percentage, optional target
//   strategy group (chips, ordered by usage, with an inline "+ New group")
//
// and shows, live, what the order costs: turnover, the itemised charges, the
// cash it needs/returns, the break-even exit price and the risk:reward ratio.
// Nothing is sent anywhere — this is paper trading, the sheet only writes rows
// into SQLite through PaperTradingProvider.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/utils/markets.dart' show Exchange;
import '../../../data/local/models/paper_trade.dart';
import '../../../data/remote/dto/scrip.dart';
import '../../../features/settings/settings_provider.dart';
import '../charges.dart';
import '../order_engine.dart';
import '../paper_trading_provider.dart';
import 'group_chips.dart';

/// Opens the trade sheet. [preset] pre-fills the instrument (Holdings → "add to
/// position", search results, F&O chain …); [forcedSide] locks the direction.
///
/// [lotSize] is the contract size when [preset] is an F&O option (`0` for
/// equity / unknown). The sheet then asks for **lots**, shows the resulting qty
/// and refuses a quantity that is not a whole lot.
Future<void> showOrderSheet(
  BuildContext context, {
  Scrip? preset,
  OrderSide? forcedSide,
  int lotSize = 0,
}) =>
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) =>
          OrderSheet(preset: preset, forcedSide: forcedSide, lotSize: lotSize),
    );

class OrderSheet extends StatefulWidget {
  const OrderSheet({
    super.key,
    this.preset,
    this.forcedSide,
    this.lotSize = 0,
  });

  final Scrip? preset;
  final OrderSide? forcedSide;

  /// Contract size for an option (`0` when not an option / unknown).
  final int lotSize;

  @override
  State<OrderSheet> createState() => _OrderSheetState();
}

class _OrderSheetState extends State<OrderSheet> {
  final TextEditingController _symbolController = TextEditingController();
  final TextEditingController _qtyController = TextEditingController(text: '1');
  final TextEditingController _limitController = TextEditingController();
  final TextEditingController _slController = TextEditingController();
  final TextEditingController _slPctController = TextEditingController();
  final TextEditingController _targetController = TextEditingController();
  final TextEditingController _searchController = TextEditingController();

  Scrip? _scrip;
  OrderSide _side = OrderSide.buy;

  /// Lots the user picked. Only used when the scrip is an F&O option — the
  /// quantity is then `lots × lotSize` so a half lot can never be sent.
  int _lots = 1;
  PaperOrderType _orderType = PaperOrderType.market;
  int? _groupId;
  bool _withStopLoss = true;
  bool _stopLossInPercent = true;
  bool _withTarget = false;
  bool _submitting = false;

  List<Scrip> _results = const [];
  bool _searching = false;

  @override
  void initState() {
    super.initState();
    _side = widget.forcedSide ?? OrderSide.buy;
    final preset = widget.preset;
    if (preset != null) {
      _scrip = preset;
      _symbolController.text = preset.symbol;
    }
  }

  @override
  void dispose() {
    _symbolController.dispose();
    _qtyController.dispose();
    _limitController.dispose();
    _slController.dispose();
    _slPctController.dispose();
    _targetController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  PaperTradingProvider get _paper => context.read<PaperTradingProvider>();

  double? get _ltp => _scrip == null ? null : _paper.livePriceFor(_scrip!);

  /// `true` when this sheet is trading an F&O contract (NFO).
  bool get _isOption => _scrip?.exchange == Exchange.nfo;

  int get _lotSize => _isOption ? widget.lotSize : 0;

  /// `true` when the sheet can honestly talk in lots.
  bool get _lotMode => _isOption && _lotSize > 0;

  /// Lots affordable right now (0 when there is no price / no cash).
  int get _maxLots {
    if (!_lotMode) return 0;
    final price = _tickPrice;
    if (price == null || price <= 0) return 0;
    return _paper.maxAffordable(price, _scrip!.exchange) ~/ _lotSize;
  }

  /// The price the order would fill at (limit price while typing one).
  double? get _tickPrice {
    final ltp = _ltp;
    if (_orderType != PaperOrderType.limit) return ltp;
    return double.tryParse(_limitController.text.trim()) ?? ltp;
  }

  /// Quantity in units: lots × lotSize for an option, the typed number else.
  int get _quantity =>
      _lotMode ? _lots * _lotSize : int.tryParse(_qtyController.text.trim()) ?? 0;

  OrderDraft? get _draft {
    final scrip = _scrip;
    if (scrip == null) return null;
    return OrderDraft(
      scrip: scrip,
      side: _side,
      quantity: _quantity,
      orderType: _orderType,
      limitPrice:
          _orderType == PaperOrderType.limit ? double.tryParse(_limitController.text) : null,
      stopLossPrice: _withStopLoss && !_stopLossInPercent
          ? double.tryParse(_slController.text)
          : null,
      stopLossPct: _withStopLoss && _stopLossInPercent
          ? double.tryParse(_slPctController.text)
          : null,
      targetPrice: _withTarget ? double.tryParse(_targetController.text) : null,
      groupId: _groupId,
      lotSize: _lotMode ? _lotSize : 0,
      note: _isOption ? 'Paper option order' : 'Paper order',
    );
  }

  // -------------------------------------------------------------------------
  // Search
  // -------------------------------------------------------------------------

  Future<void> _search(String query) async {
    if (query.trim().length < 2) {
      setState(() => _results = const []);
      return;
    }
    setState(() => _searching = true);
    final results = await _paper.searchInstruments(query);
    if (!mounted) return;
    setState(() {
      _results = results;
      _searching = false;
    });
  }

  void _select(Scrip scrip) {
    setState(() {
      _scrip = scrip;
      _symbolController.text = scrip.symbol;
      _results = const [];
      _searchController.clear();
      final ltp = _paper.livePriceFor(scrip);
      if (ltp != null) _limitController.text = ltp.toStringAsFixed(2);
    });
    // The feed only streams what the open book holds, so ask for a REST quote
    // for a symbol the user is merely considering.
    _paper.fetchQuote(scrip).then((_) {
      if (!mounted || _scrip?.token != scrip.token) return;
      setState(() {
        if (_limitController.text.isEmpty &&
            _orderType == PaperOrderType.limit) {
          final ltp = _paper.livePriceFor(scrip);
          if (ltp != null) _limitController.text = ltp.toStringAsFixed(2);
        }
      });
    });
  }

  // -------------------------------------------------------------------------
  // Submit
  // -------------------------------------------------------------------------

  Future<void> _submit(OrderDraft draft) async {
    setState(() => _submitting = true);
    final result = await _paper.placeOrder(draft);
    if (!mounted) return;
    setState(() => _submitting = false);

    final messenger = ScaffoldMessenger.of(context);
    messenger.showSnackBar(
      SnackBar(
        content: Text(result.message),
        backgroundColor: result.isFailure
            ? Theme.of(context).colorScheme.error
            : null,
        duration: Duration(seconds: result.isFailure ? 5 : 3),
      ),
    );
    if (result.isFilled || result.isResting) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final paper = context.watch<PaperTradingProvider>();
    final settings = context.watch<SettingsProvider>();
    final scheme = Theme.of(context).colorScheme;
    final draft = _draft;

    final ltp = _ltp;
    final check = draft == null ? null : paper.check(draft);
    final preview = draft == null ? null : paper.preview(draft);
    final available = paper.snapshot.availableCash;
    final maxQty = ltp == null
        ? 0
        : paper.maxAffordable(
            _orderType == PaperOrderType.limit
                ? (double.tryParse(_limitController.text) ?? ltp)
                : ltp,
            _scrip!.exchange,
          );

    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(14, 4, 14, 18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Text(
                  'Paper order',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                  decoration: BoxDecoration(
                    color: scheme.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    'SIMULATED · no real order',
                    style: TextStyle(
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.3,
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // ---- instrument
            _InstrumentField(
              controller: _symbolController,
              searchController: _searchController,
              scrip: _scrip,
              ltp: ltp,
              isLive: _scrip != null &&
                  paper.isLivePrice(
                    '${_scrip!.exchange.code}:${Scrip.plainSymbol(_scrip!.symbol)}',
                  ),
              results: _results,
              searching: _searching,
              onSearch: _search,
              onSelect: _select,
            ),
            const SizedBox(height: 12),

            // ---- side
            SegmentedButton<OrderSide>(
              segments: const [
                ButtonSegment(
                  value: OrderSide.buy,
                  label: Text('BUY'),
                  icon: Icon(Icons.trending_up_rounded, size: 16),
                ),
                ButtonSegment(
                  value: OrderSide.sell,
                  label: Text('SELL'),
                  icon: Icon(Icons.trending_down_rounded, size: 16),
                ),
              ],
              selected: {_side},
              onSelectionChanged: widget.forcedSide != null
                  ? null
                  : (set) => setState(() => _side = set.first),
            ),
            const SizedBox(height: 12),

            // ---- what BUY / SELL mean on an option (short writes are real)
            if (_isOption) ...[
              _SideHint(side: _side, isOption: true),
              const SizedBox(height: 12),
            ],

            // ---- lots (options) / quantity (everything else)
            if (_lotMode) ...[
              Row(
                children: [
                  IconButton(
                    tooltip: 'Ek lot kam',
                    onPressed: _lots <= 1
                        ? null
                        : () => setState(() => _lots -= 1),
                    icon: const Icon(Icons.remove_circle_outline_rounded),
                  ),
                  Expanded(
                    child: Column(
                      children: [
                        Text(
                          '$_lots lot${_lots == 1 ? '' : 's'} × $_lotSize',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        Text(
                          '= $_quantity qty · 1 lot = $_lotSize',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 11,
                            color: scheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    tooltip: 'Ek lot zyada',
                    onPressed: () => setState(() => _lots += 1),
                    icon: const Icon(Icons.add_circle_outline_rounded),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Wrap(
                spacing: 5,
                children: [
                  for (final l in const [1, 2, 3, 5, 10])
                    ActionChip(
                      label: Text('$l lot${l == 1 ? '' : 's'}'),
                      visualDensity: VisualDensity.compact,
                      onPressed: () => setState(() => _lots = l),
                    ),
                  // Only a BUY is limited by cash — a written option receives
                  // the premium instead, so there is no "max affordable" there.
                  if (_side == OrderSide.buy && _maxLots > 0)
                    ActionChip(
                      label: const Text('MAX'),
                      visualDensity: VisualDensity.compact,
                      onPressed: () => setState(() => _lots = _maxLots),
                    ),
                ],
              ),
              const SizedBox(height: 12),
            ],
            if (!_lotMode)
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  flex: 2,
                  child: TextField(
                    controller: _qtyController,
                    keyboardType: TextInputType.number,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    decoration: InputDecoration(
                      labelText: 'Quantity',
                      helperText: 'Max affordable: $maxQty',
                      suffixIcon: _qtyController.text == '$maxQty' && maxQty > 0
                          ? null
                          : TextButton(
                              onPressed: maxQty == 0
                                  ? null
                                  : () => setState(
                                        () => _qtyController.text = '$maxQty',
                                      ),
                              child: const Text('MAX'),
                            ),
                    ),
                    onChanged: (_) => setState(() {}),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  flex: 3,
                  child: Wrap(
                    spacing: 5,
                    children: [
                      for (final q in const [1, 5, 10, 25, 50, 100])
                        ActionChip(
                          label: Text('$q'),
                          visualDensity: VisualDensity.compact,
                          onPressed: () =>
                              setState(() => _qtyController.text = '$q'),
                        ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // ---- order type + price
            SegmentedButton<PaperOrderType>(
              segments: const [
                ButtonSegment(
                  value: PaperOrderType.market,
                  label: Text('Market'),
                ),
                ButtonSegment(value: PaperOrderType.limit, label: Text('Limit')),
              ],
              selected: {_orderType},
              onSelectionChanged: (set) => setState(() {
                _orderType = set.first;
                if (_orderType == PaperOrderType.limit &&
                    _limitController.text.isEmpty &&
                    ltp != null) {
                  _limitController.text = ltp.toStringAsFixed(2);
                }
              }),
            ),
            if (_orderType == PaperOrderType.limit) ...[
              const SizedBox(height: 10),
              TextField(
                controller: _limitController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                  labelText: 'Limit price',
                  prefixText: '₹ ',
                  helperText: 'Fills when the market trades through this price',
                ),
                onChanged: (_) => setState(() {}),
              ),
              if (_scrip != null)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Wrap(
                    spacing: 6,
                    children: [
                      for (final offset in const [-1.0, -0.5, 0.5, 1.0])
                        if (ltp != null)
                          ActionChip(
                            label: Text(
                              '${offset > 0 ? '+' : ''}${offset.toStringAsFixed(1)}%',
                            ),
                            visualDensity: VisualDensity.compact,
                            onPressed: () => setState(() {
                              _limitController.text = OrderEngine.tickRound(
                                ltp * (1 + offset / 100),
                                _scrip!.tickSize,
                              ).toStringAsFixed(2);
                            }),
                          ),
                    ],
                  ),
                ),
            ],
            const SizedBox(height: 14),

            // ---- stop loss
            Row(
              children: [
                Expanded(
                  child: SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    value: _withStopLoss,
                    onChanged: (value) => setState(() => _withStopLoss = value),
                    title: const Text(
                      'Stop loss (auto-exit)',
                      style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                    ),
                    subtitle: Text(
                      _side == OrderSide.sell && _isOption
                          ? 'Short ke liye stop entry se oopar hota hai — '
                              'hit hone par market se cover ho jayega'
                          : 'Monitored on every tick and squared off at market',
                      style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant),
                    ),
                  ),
                ),
              ],
            ),
            if (_withStopLoss)
              Row(
                children: [
                  Expanded(
                    flex: 3,
                    child: TextField(
                      controller: _stopLossInPercent
                          ? _slPctController
                          : _slController,
                      keyboardType:
                          const TextInputType.numberWithOptions(decimal: true),
                      decoration: InputDecoration(
                        labelText: _stopLossInPercent ? 'Stop loss %' : 'Stop loss price',
                        prefixText: _stopLossInPercent ? null : '₹ ',
                        suffixText: _stopLossInPercent ? '%' : null,
                      ),
                      onChanged: (_) => setState(() {}),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    flex: 2,
                    child: SegmentedButton<bool>(
                      segments: const [
                        ButtonSegment(value: true, label: Text('%')),
                        ButtonSegment(value: false, label: Text('₹')),
                      ],
                      selected: {_stopLossInPercent},
                      onSelectionChanged: (set) => setState(
                        () => _stopLossInPercent = set.first,
                      ),
                    ),
                  ),
                ],
              ),
            const SizedBox(height: 8),

            // ---- target
            Row(
              children: [
                Expanded(
                  child: SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    value: _withTarget,
                    onChanged: (value) => setState(() => _withTarget = value),
                    title: const Text(
                      'Target',
                      style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                    ),
                    subtitle: Text(
                      settings.settings.autoExitOnTarget
                          ? 'Auto-exits when reached (enabled in Settings)'
                          : 'Informational — enable auto-exit in Settings',
                      style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant),
                    ),
                  ),
                ),
              ],
            ),
            if (_withTarget)
              TextField(
                controller: _targetController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                  labelText: 'Target price',
                  prefixText: '₹ ',
                ),
                onChanged: (_) => setState(() {}),
              ),
            const SizedBox(height: 10),

            // ---- group
            Text(
              'Group (optional)',
              style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant),
            ),
            const SizedBox(height: 6),
            GroupPicker(
              groups: paper.groups,
              selectedId: _groupId,
              onChanged: (id) => setState(() => _groupId = id),
              onCreate: (name) async {
                final group = await _paper.createGroup(name);
                if (mounted) setState(() => _groupId = group.id);
              },
            ),
            const SizedBox(height: 14),

            // ---- preview
            if (preview != null && _scrip != null) ...[
              _PreviewCard(
                preview: preview,
                side: _side,
                available: available,
                chargesMode: paper.chargesMode,
                ltp: ltp,
              ),
              const SizedBox(height: 10),
            ],

            // ---- validation
            if (check != null && check.errors.isNotEmpty)
              _MessageBox(
                color: Theme.of(context).colorScheme.error,
                icon: Icons.error_outline_rounded,
                lines: check.errors,
              ),
            if (check != null && check.warnings.isNotEmpty) ...[
              const SizedBox(height: 6),
              _MessageBox(
                color: MarketColors.of(context).stale,
                icon: Icons.info_outline_rounded,
                lines: check.warnings,
              ),
            ],
            const SizedBox(height: 14),

            // ---- place
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: (_submitting ||
                        draft == null ||
                        check == null ||
                        !check.isValid)
                    ? null
                    : () => _submit(draft),
                icon: _submitting
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : Icon(
                        _side == OrderSide.buy
                            ? Icons.shopping_cart_checkout_rounded
                            : Icons.sell_rounded,
                      ),
                label: Text(
                  _side == OrderSide.buy
                      ? 'Place paper BUY'
                      : _isOption
                          ? 'Place paper SELL (short open)'
                          : 'Place paper SELL',
                ),
                style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(46),
                ),
              ),
            ),
            const SizedBox(height: 6),
            Center(
              child: Text(
                'Virtual money only — nothing is sent to Angel One.',
                style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Pieces
// ---------------------------------------------------------------------------

class _InstrumentField extends StatelessWidget {
  const _InstrumentField({
    required this.controller,
    required this.searchController,
    required this.scrip,
    required this.ltp,
    required this.isLive,
    required this.results,
    required this.searching,
    required this.onSearch,
    required this.onSelect,
  });

  final TextEditingController controller;
  final TextEditingController searchController;
  final Scrip? scrip;
  final double? ltp;
  final bool isLive;
  final List<Scrip> results;
  final bool searching;
  final Future<void> Function(String) onSearch;
  final void Function(Scrip) onSelect;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final market = MarketColors.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextField(
          controller: searchController,
          textCapitalization: TextCapitalization.characters,
          decoration: InputDecoration(
            labelText: 'Symbol or company',
            hintText: 'e.g. SBIN, Tata Motors, INFY-EQ',
            prefixIcon: const Icon(Icons.search_rounded, size: 20),
            suffixIcon: searching
                ? const Padding(
                    padding: EdgeInsets.all(12),
                    child: SizedBox(
                      width: 14,
                      height: 14,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    ),
                  )
                : null,
          ),
          onChanged: onSearch,
        ),
        if (results.isNotEmpty)
          Container(
            margin: const EdgeInsets.only(top: 4),
            constraints: const BoxConstraints(maxHeight: 190),
            decoration: BoxDecoration(
              color: scheme.surface,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: scheme.outlineVariant),
            ),
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: results.length,
              itemBuilder: (context, index) {
                final item = results[index];
                return ListTile(
                  dense: true,
                  title: Text(
                    Scrip.plainSymbol(item.symbol),
                    style: const TextStyle(fontSize: 13),
                  ),
                  subtitle: Text(
                    '${item.exchange.code} · ${item.name}',
                    style: const TextStyle(fontSize: 10.5),
                  ),
                  onTap: () => onSelect(item),
                );
              },
            ),
          ),
        if (scrip != null) ...[
          const SizedBox(height: 8),
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: scheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '${scrip!.exchange.code}:${Scrip.plainSymbol(scrip!.symbol)}',
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      scrip!.name,
                      style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant),
                    ),
                  ],
                ),
              ),
              const Spacer(),
              if (ltp != null)
                Row(
                  children: [
                    if (isLive)
                      Container(
                        width: 6,
                        height: 6,
                        margin: const EdgeInsets.only(right: 5),
                        decoration: BoxDecoration(
                          color: market.gain,
                          shape: BoxShape.circle,
                        ),
                      ),
                    Text(
                      Fmt.price(ltp!),
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                )
              else
                Text(
                  'no live price',
                  style: TextStyle(fontSize: 11, color: market.stale),
                ),
            ],
          ),
        ],
      ],
    );
  }
}

class _PreviewCard extends StatelessWidget {
  const _PreviewCard({
    required this.preview,
    required this.side,
    required this.available,
    required this.chargesMode,
    required this.ltp,
  });

  final OrderPreview preview;
  final OrderSide side;
  final double available;
  final ChargesMode chargesMode;
  final double? ltp;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final market = MarketColors.of(context);

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest.withOpacity(0.5),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'Turnover ${Fmt.money(preview.turnover)}',
                style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700),
              ),
              const Spacer(),
              Text(
                '${chargesMode.label} charges',
                style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant),
              ),
            ],
          ),
          const SizedBox(height: 6),
          _Line(
            'Charges',
            Fmt.money(preview.charges.total),
            sub: preview.charges.totalPct == 0
                ? null
                : '${preview.charges.totalPct.toStringAsFixed(3)}% of turnover',
          ),
          _Line(
            side == OrderSide.buy ? 'Cash required' : 'Cash released',
            Fmt.money(
              side == OrderSide.buy ? preview.cashRequired : preview.cashReleased,
            ),
            sub: side == OrderSide.buy
                ? 'available ${Fmt.moneyCompact(available)}'
                : null,
          ),
          _Line(
            'Break-even exit',
            Fmt.price(preview.breakEvenPrice),
            sub: 'after both legs\' charges',
          ),
          if (preview.stopLoss != null)
            _Line(
              'Stop loss',
              '${Fmt.price(preview.stopLoss!)} '
              '(${preview.stopPct?.toStringAsFixed(1) ?? '—'}%)',
              sub: preview.riskAmount == null
                  ? null
                  : 'risk ${Fmt.money(preview.riskAmount!)}',
              valueColor: market.loss,
            ),
          if (preview.target != null)
            _Line(
              'Target',
              Fmt.price(preview.target!),
              sub: preview.rewardAmount == null
                  ? null
                  : 'reward ${Fmt.money(preview.rewardAmount!)}',
              valueColor: market.gain,
            ),
          if (preview.riskReward != null)
            _Line(
              'Risk : reward',
              '1 : ${preview.riskReward!.toStringAsFixed(2)}',
              sub: preview.riskReward! >= 2
                  ? 'healthy'
                  : 'thin — consider a tighter stop',
            ),
        ],
      ),
    );
  }
}

class _Line extends StatelessWidget {
  const _Line(this.label, this.value, {this.sub, this.valueColor});

  final String label;
  final String value;
  final String? sub;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 108,
            child: Text(
              label,
              style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant),
            ),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w600,
                    color: valueColor,
                  ),
                ),
                if (sub != null)
                  Text(
                    sub!,
                    style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _MessageBox extends StatelessWidget {
  const _MessageBox({
    required this.color,
    required this.icon,
    required this.lines,
  });

  final Color color;
  final IconData icon;
  final List<String> lines;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.10),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.35)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 15, color: color),
          const SizedBox(width: 7),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (final line in lines)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 1),
                    child: Text(
                      line,
                      style: TextStyle(fontSize: 11.5, color: color),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// One-line explanation of what BUY / SELL do on an option, so a short (option
/// writing) is never mistaken for "selling something I own".
class _SideHint extends StatelessWidget {
  const _SideHint({required this.side, this.isOption = true});

  final OrderSide side;
  final bool isOption;

  @override
  Widget build(BuildContext context) {
    if (!isOption) return const SizedBox.shrink();
    final scheme = Theme.of(context).colorScheme;
    final market = MarketColors.of(context);
    final buy = side == OrderSide.buy;
    final color = buy ? market.gain : market.loss;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            buy ? Icons.south_west_rounded : Icons.north_east_rounded,
            size: 15,
            color: color,
          ),
          const SizedBox(width: 7),
          Expanded(
            child: Text(
              buy
                  ? 'BUY — long position (premium do). Kisi short ko band karna ho '
                      'to bhi BUY hi karna hai (cover).'
                  : 'SELL — short position (option likhna). Premium milta hai; '
                      'band karne ke liye baad me BUY (cover) karo.',
              style: TextStyle(fontSize: 11, height: 1.35, color: scheme.onSurface),
            ),
          ),
        ],
      ),
    );
  }
}
