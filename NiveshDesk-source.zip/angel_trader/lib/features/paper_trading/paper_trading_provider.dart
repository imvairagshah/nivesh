// ---------------------------------------------------------------------------
// paper_trading_provider.dart — the paper-trading desk: state + orchestration.
//
// This is where the pieces meet:
//
//   TradeDao            persistence (orders, trades, positions)
//   OrderEngine         the rules (fills, validation, book-keeping maths)
//   EquityCharges       what the broker would have taken
//   LiveFeedService     live LTPs off the SmartAPI WebSocket
//   MarketDataService   REST fallback when the feed is down/unavailable
//   SettingsProvider    virtual capital, charge model, feed switches
//
// Three loops run while the tab is alive:
//
//   1. PRICES   the feed streams LTPs (throttled UI notify). If the feed is off
//               or offline, a periodic REST snapshot every
//               `autoRefreshSeconds` keeps holdings valued instead of frozen.
//   2. EXITS    every tick is tested against each open position's stop (and,
//               if enabled, its target). A breach books a MARKET exit at that
//               price — this is the "auto-exit at SL" requirement, and it runs
//               wherever the user is in the app, because the shell keeps this
//               provider alive.
//   3. ORDERS   resting LIMIT orders are matched on every tick and fill at the
//               moment the market trades through their level.
//
// Writes are serialised through a single-flight guard so a tick storm cannot
// interleave two exits of the same position.
// ---------------------------------------------------------------------------

import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import '../../core/utils/markets.dart';
import '../../data/local/dao/scrip_dao.dart';
import '../../data/local/dao/trade_dao.dart';
import '../../data/local/dao/trade_group_dao.dart';
import '../../data/local/models/paper_trade.dart';
import '../../data/local/models/trade_group.dart';
import '../../data/remote/dto/quote.dart';
import '../../data/remote/dto/scrip.dart';
import '../../services/auth_service.dart';
import '../../services/live_feed_service.dart';
import '../../services/market_data_service.dart';
import '../settings/settings_provider.dart';
import 'charges.dart';
import 'order_engine.dart';
import 'portfolio_math.dart';
import 'trade_range.dart';

/// What a placement attempt did — the sheet shows this and closes (or not).
enum OrderOutcome { filled, resting, rejected }

/// Result of [PaperTradingProvider.placeOrder] / [exitPosition].
@immutable
class OrderResult {
  final OrderOutcome outcome;

  /// Human-readable summary ("Bought 100 SBIN-EQ @ 812.35"), or the reason a
  /// rejection happened.
  final String message;

  /// Warnings the user should still see (missing stop, instant trigger …).
  final List<String> warnings;

  /// The row that was written, when one was.
  final PaperOrder? order;

  const OrderResult({
    required this.outcome,
    required this.message,
    this.warnings = const [],
    this.order,
  });

  bool get isFailure => outcome == OrderOutcome.rejected;
  bool get isFilled => outcome == OrderOutcome.filled;
  bool get isResting => outcome == OrderOutcome.resting;
}

/// Group filter shared by Holdings / Orders / Trade Book.
@immutable
class PaperFilter {
  /// `null` + [ungroupedOnly] false = all groups.
  final int? groupId;
  final bool ungroupedOnly;
  final String query;

  const PaperFilter({this.groupId, this.ungroupedOnly = false, this.query = ''});

  /// `true` when nothing is filtered out.
  bool get isAll => groupId == null && !ungroupedOnly && query.trim().isEmpty;

  PaperFilter copyWith({
    int? groupId,
    bool? ungroupedOnly,
    String? query,
    bool clearGroup = false,
  }) =>
      PaperFilter(
        groupId: clearGroup ? null : (groupId ?? this.groupId),
        ungroupedOnly: clearGroup ? false : (ungroupedOnly ?? this.ungroupedOnly),
        query: query ?? this.query,
      );

  @override
  bool operator ==(Object other) =>
      other is PaperFilter &&
      other.groupId == groupId &&
      other.ungroupedOnly == ungroupedOnly &&
      other.query == query;

  @override
  int get hashCode => Object.hash(groupId, ungroupedOnly, query);
}

class PaperTradingProvider extends ChangeNotifier {
  PaperTradingProvider({
    required TradeDao trades,
    required TradeGroupDao groups,
    required SettingsProvider settings,
    required AuthService auth,
    required MarketDataService marketData,
    required LiveFeedService feed,
    required ScripDao scripDao,
    DateTime Function()? clock,
    bool manageWakelock = true,
  })  : _trades = trades,
        _groups = groups,
        _settings = settings,
        _auth = auth,
        _marketData = marketData,
        _feed = feed,
        _scripDao = scripDao,
        _clock = clock ?? DateTime.now,
        _manageWakelock = manageWakelock {
    _feedSub = _feed.ticks.listen(_onTick);
  }

  final TradeDao _trades;
  final TradeGroupDao _groups;
  final SettingsProvider _settings;
  final AuthService _auth;
  final MarketDataService _marketData;
  final LiveFeedService _feed;
  final ScripDao _scripDao;
  final DateTime Function() _clock;
  final bool _manageWakelock;

  StreamSubscription<LiveTick>? _feedSub;
  Timer? _restRefreshTimer;
  bool _disposed = false;
  bool _refreshing = false;
  bool _refreshDirty = false;

  // ---- state ------------------------------------------------------------
  bool _loading = true;
  bool _busy = false;
  String? _error;
  String _notice = '';
  DateTime? _lastPriceAt;

  List<Position> _openPositions = const [];
  List<PaperOrder> _pendingOrders = const [];
  List<PaperOrder> _orders = const [];
  List<Trade> _tradesCache = const [];
  List<Trade> _allLegs = const [];
  List<TradeGroup> _groupsCache = const [];
  PaperFilter _filter = const PaperFilter();
  final Set<int> _exitsInFlight = {};

  // -------------------------------------------------------------------------
  // Read-only surface
  // -------------------------------------------------------------------------

  bool get isLoading => _loading;
  bool get isBusy => _busy;
  String? get error => _error;
  String get notice => _notice;
  PaperFilter get filter => _filter;
  List<TradeGroup> get groups => _groupsCache;
  List<PaperOrder> get orders => _orders;
  List<PaperOrder> get pendingOrders => _pendingOrders;
  List<Trade> get tradeBook => _tradesCache;
  List<Position> get openPositionsRaw => _openPositions;
  LiveFeedService get feed => _feed;

  double get startingCapital => _settings.settings.startingCapital;
  ChargesMode get chargesMode =>
      ChargesMode.fromName(_settings.settings.chargesMode);
  bool get includeDpCharges => _settings.settings.includeDpCharges;

  /// `true` when the app has any reason to keep the feed subscribed.
  bool get hasLiveBook => _openPositions.isNotEmpty || _pendingOrders.isNotEmpty;

  /// Latest price for a position/order, preferring the live feed and falling
  /// back to the last REST snapshot. `null` when nothing is known.
  double? priceFor(String priceKey) {
    final live = _feed.tickFor(priceKey);
    if (live != null) return live.ltp;
    final cached = _restPrices[priceKey];
    return cached?.value;
  }

  DateTime? priceStampFor(String priceKey) {
    final live = _feed.tickFor(priceKey);
    if (live != null) return live.receivedAt;
    return _restPrices[priceKey]?.asOf;
  }

  /// `true` when the price came off the socket (not the REST snapshot).
  bool isLivePrice(String priceKey) => _feed.tickFor(priceKey) != null;

  final Map<String, PricedValue> _restPrices = {};
  DateTime? get lastPriceAt => _lastPriceAt;

  // ---- derived views ----------------------------------------------------

  /// Open positions with their live price and group label, filtered.
  List<HoldingView> get holdings {
    final views = _openPositions.map(_viewFor).toList(growable: false);
    return views.where(_matchesFilter).toList(growable: false)
      ..sort((a, b) => b.invested.compareTo(a.invested));
  }

  /// Every open holding, ignoring the filter (dashboard maths).
  List<HoldingView> get allHoldings =>
      _openPositions.map(_viewFor).toList(growable: false);

  /// Resting limit orders with their live price, filtered.
  List<PendingOrderView> get pendingOrderViews {
    final views = _pendingOrders
        .map((o) => PendingOrderView(
              order: o,
              ltp: priceFor(_keyFor(o.symbol, o.exchange)),
            ))
        .toList(growable: false);
    return views
        .where((v) =>
            _filter.ungroupedOnly
                ? v.order.groupId == null
                : (_filter.groupId == null || v.order.groupId == _filter.groupId))
        .where((v) => _matchesQuery(v.order.displaySymbol))
        .toList(growable: false);
  }

  /// Filled orders (history), newest first, filtered.
  List<PaperOrder> get filledOrders => _orders
      .where((o) => !o.isPending)
      .where((o) =>
          _filter.ungroupedOnly
              ? o.groupId == null
              : (_filter.groupId == null || o.groupId == _filter.groupId))
      .where((o) => _matchesQuery(o.displaySymbol))
      .toList(growable: false);

  /// The dashboard tiles.
  PortfolioSnapshot get snapshot => PortfolioMath.snapshot(
        startingCapital: startingCapital,
        trades: _allLegs,
        holdings: allHoldings,
        pendingOrders: _pendingOrders.length,
      );

  /// Trade-book rows that survive the current filter.
  List<Trade> get filteredTrades => _tradesCache;

  /// Abhi chune hue group filter ka naam (export ki report me chhapta hai).
  String get filterLabel {
    if (_filter.ungroupedOnly) return 'Bina group (Ungrouped)';
    final id = _filter.groupId;
    if (id == null) return 'Sab group';
    for (final group in _groupsCache) {
      if (group.id == id) return group.name;
    }
    return 'Sab group';
  }

  /// Export ke liye: chune hue daayre ki **poori** kitaab.
  ///
  /// Screen wali list 500 leg par ruk jati hai — export adhoora nikalna galat
  /// hoga, isliye yahan seedhe DAO se poora daayra padha jata hai (DAO me
  /// `from`/`to` pehle se hai).
  Future<List<Trade>> tradeBookForRange(TradeRange range, DateTime now) =>
      _trades.tradeBook(
        groupId: _filter.ungroupedOnly ? null : _filter.groupId,
        ungroupedOnly: _filter.ungroupedOnly,
        symbolQuery: _filter.query,
        from: range.resolveFrom(now),
        to: range.resolveTo(now),
        limit: 20000,
      );

  HoldingView _viewFor(Position position) {
    final key = position.priceKey;
    final live = _feed.tickFor(key);
    final fallback = _restPrices[key];
    return HoldingView(
      position: position,
      ltp: live?.ltp ?? fallback?.value,
      changePct: live?.changePct ?? fallback?.changePct,
      groupName: _groupNameFor(position.groupId),
      groupColorIndex: _groupColorFor(position.groupId),
      isLive: live != null,
      pricedAt: live?.receivedAt ?? fallback?.asOf,
    );
  }

  bool _matchesFilter(HoldingView view) {
    if (_filter.ungroupedOnly && view.position.groupId != null) return false;
    if (!_filter.ungroupedOnly &&
        _filter.groupId != null &&
        view.position.groupId != _filter.groupId) {
      return false;
    }
    return _matchesQuery(view.position.displaySymbol);
  }

  bool _matchesQuery(String symbol) {
    final q = _filter.query.trim().toUpperCase();
    if (q.isEmpty) return true;
    return symbol.toUpperCase().contains(q);
  }

  String _groupNameFor(int? groupId) {
    if (groupId == null) return kUngroupedLabel;
    for (final group in _groupsCache) {
      if (group.id == groupId) return group.name;
    }
    return kUngroupedLabel;
  }

  int _groupColorFor(int? groupId) {
    if (groupId == null) return 0;
    for (final group in _groupsCache) {
      if (group.id == groupId) return group.colorIndex;
    }
    return 0;
  }

  static String _keyFor(String symbol, Exchange exchange) =>
      '${exchange.code}:${Scrip.plainSymbol(symbol)}';

  // -------------------------------------------------------------------------
  // Lifecycle
  // -------------------------------------------------------------------------

  /// Loads everything from SQLite and starts the price loop. Safe to call more
  /// than once (the shell calls it every time the tab becomes visible).
  Future<void> bootstrap() async {
    await refresh(reloadLists: true);
  }

  /// Reloads lists from SQLite (and optionally prices), then re-syncs the feed.
  ///
  /// Single-flight: a refresh triggered *by* a refresh (a fill discovered while
  /// pricing the book, for instance) does not recurse — it just marks the current
  /// pass dirty, and one more pass runs afterwards with the new data.
  Future<void> refresh({bool reloadLists = true}) async {
    if (_disposed) return;
    if (_refreshing) {
      _refreshDirty = true;
      return;
    }
    _refreshing = true;
    try {
      var passes = 0;
      do {
        _refreshDirty = false;
        await _refreshOnce(reloadLists: reloadLists);
        passes++;
      } while (_refreshDirty && passes < 2 && !_disposed);
    } finally {
      _refreshing = false;
    }
  }

  Future<void> _refreshOnce({required bool reloadLists}) async {
    if (_disposed) return;
    if (reloadLists) {
      try {
        _openPositions = await _trades.allOpenPositions();
        _pendingOrders = await _trades.pendingOrders();
        _orders = await _trades.orders(limit: 200);
        _groupsCache = await _groups.byUsage();
        _allLegs = await _trades.allTrades();
        _tradesCache = await _trades.tradeBook(
          groupId: _filter.ungroupedOnly ? null : _filter.groupId,
          ungroupedOnly: _filter.ungroupedOnly,
          symbolQuery: _filter.query,
        );
        _error = null;
      } catch (e) {
        _error = 'Could not load the paper account: $e';
      }
    }

    await syncFeedSubscription();
    await refreshPricesViaRest(force: false);
    _loading = false;
    _notify();
  }

  /// Tells the feed exactly which instruments the open book needs, and starts /
  /// stops the REST timer accordingly.
  Future<void> syncFeedSubscription() async {
    if (_settings.settings.liveFeedEnabled && _auth.isLoggedIn) {
      final wanted = <FeedSubscription>[
        for (final position in _openPositions)
          FeedSubscription(
            token: position.token,
            exchange: position.exchange,
            priceKey: position.priceKey,
          ),
        for (final order in _pendingOrders)
          FeedSubscription(
            token: order.token,
            exchange: order.exchange,
            priceKey: order.priceKey,
          ),
      ];
      await _feed.sync(wanted);
      _applyWakelock(wanted.isNotEmpty);
    } else {
      await _feed.stop();
      _applyWakelock(false);
    }
    _restartRestTimer();
  }

  /// Keeps the screen awake while a live book is streaming (only when the user
  /// asked for it in Settings).
  void _applyWakelock(bool wanted) {
    if (!_manageWakelock) return;
    final enabled = wanted && _settings.settings.keepScreenAwake;
    try {
      if (enabled) {
        WakelockPlus.enable();
      } else {
        WakelockPlus.disable();
      }
    } catch (_) {
      // No plugin (tests / unsupported platform) — never fatal.
    }
  }

  void _restartRestTimer() {
    _restRefreshTimer?.cancel();
    // With a healthy socket there is no need to poll at all; without one, the
    // REST snapshot is the only thing keeping holdings valued.
    if (_feed.isStreaming || !hasLiveBook || !_auth.isLoggedIn) return;
    final seconds = _settings.settings.autoRefreshSeconds;
    _restRefreshTimer = Timer.periodic(
      Duration(seconds: seconds),
      (_) => refreshPricesViaRest(force: true),
    );
  }

  /// One REST LTP snapshot for the whole open book (max 50 tokens per call).
  ///
  /// [force] skips the freshness check; the manual pull-to-refresh uses it.
  Future<void> refreshPricesViaRest({bool force = false}) async {
    if (!_auth.isLoggedIn) return;
    final scrips = <Scrip>[
      for (final position in _openPositions)
        Scrip(
          token: position.token,
          symbol: position.symbol,
          name: position.symbol,
          exchange: position.exchange,
        ),
      for (final order in _pendingOrders)
        Scrip(
          token: order.token,
          symbol: order.symbol,
          name: order.symbol,
          exchange: order.exchange,
        ),
    ];
    if (scrips.isEmpty) return;
    if (!force && !_needsRestPrices) return;

    try {
      final prices = await _marketData.fetchLtp(scrips);
      if (prices.isEmpty) return;
      _restPrices
        ..clear()
        ..addAll(prices);
      _lastPriceAt = _clock();
      _error = null;
      // The fresh snapshot may have crossed a limit order or a stop.
      await _processRestPrices();
      _notify();
    } catch (e) {
      // Never clobber a working value with an error: only report if we have
      // nothing at all to show.
      if (_restPrices.isEmpty) {
        _error = 'Prices unavailable — showing book values. ($e)';
      }
      _notify();
    }
  }

  /// `true` when the feed is not delivering and we have something to price.
  bool get _needsRestPrices {
    if (_feed.isStreaming) return false;
    return hasLiveBook;
  }

  Future<void> _processRestPrices() async {
    for (final order in List<PaperOrder>.from(_pendingOrders)) {
      final ltp = priceFor(order.priceKey);
      if (ltp != null && OrderEngine.isMarketable(order, ltp)) {
        await _executeOrder(order, ltp, trigger: 'LIMIT reached');
      }
    }
    for (final position in List<Position>.from(_openPositions)) {
      final ltp = priceFor(position.priceKey);
      if (ltp == null) continue;
      if (position.stopHit(ltp)) {
        await _autoExit(position, ltp, reason: 'stop loss');
      } else if (_settings.settings.autoExitOnTarget && position.targetHit(ltp)) {
        await _autoExit(position, ltp, reason: 'target');
      }
    }
  }

  // -------------------------------------------------------------------------
  // Tick handling — exits + resting orders
  // -------------------------------------------------------------------------

  void _onTick(LiveTick tick) {
    if (_disposed) return;
    // Ticks arrive on the socket's own schedule; run the matching off the
    // current event loop turn so a burst cannot re-enter the DAO.
    unawaited(_matchTick(tick));
  }

  Future<void> _matchTick(LiveTick tick) async {
    if (_disposed || _busy) return;
    final id = '${tick.exchange.wsType}:${tick.token}';

    // --- resting LIMIT orders
    for (final order in List<PaperOrder>.from(_pendingOrders)) {
      if ('${order.exchange.wsType}:${order.token}' != id) continue;
      if (OrderEngine.isMarketable(order, tick.ltp)) {
        await _executeOrder(order, tick.ltp, trigger: 'LIMIT reached');
      }
    }

    // --- stop-loss / target exits
    for (final position in List<Position>.from(_openPositions)) {
      if ('${position.exchange.wsType}:${position.token}' != id) continue;
      if (_exitsInFlight.contains(position.id)) continue;
      if (position.stopHit(tick.ltp)) {
        await _autoExit(position, tick.ltp, reason: 'stop loss');
      } else if (_settings.settings.autoExitOnTarget &&
          position.targetHit(tick.ltp)) {
        await _autoExit(position, tick.ltp, reason: 'target');
      }
    }
  }

  /// Books a market exit for [position] at [price] and tells the user why.
  Future<void> _autoExit(
    Position position,
    double price, {
    required String reason,
  }) async {
    final id = position.id;
    if (id == null || !_exitsInFlight.add(id)) return;
    try {
      // A short is closed by *buying* (a cover); a long by selling.
      final closingSide =
          position.isShort ? OrderSide.buy : OrderSide.sell;
      final charges = EquityCharges.compute(
        side: closingSide,
        price: price,
        quantity: position.quantity,
        exchange: position.exchange,
        mode: chargesMode,
        includeDpCharge: includeDpCharges,
        kind: position.exchange == Exchange.nfo
            ? InstrumentKind.option
            : InstrumentKind.equity,
      );
      final update = position.isShort
          ? OrderEngine.applyBuy(
              current: position,
              scrip: Scrip(
                token: position.token,
                symbol: position.symbol,
                name: position.symbol,
                exchange: position.exchange,
              ),
              quantity: position.quantity,
              price: price,
              charges: charges.total,
              at: _clock(),
            )
          : OrderEngine.applySell(
              current: position,
              quantity: position.quantity,
              price: price,
              charges: charges.total,
              at: _clock(),
            );
      await _trades.updatePosition(update.position);
      await _trades.insertTrade(
        Trade(
          symbol: position.symbol,
          exchange: position.exchange,
          token: position.token,
          side: closingSide,
          quantity: position.quantity,
          price: price,
          orderType: PaperOrderType.market,
          positionId: position.id,
          groupId: position.groupId,
          realizedPnl: update.realizedPnl,
          charges: charges.total,
          executedAt: _clock(),
          note: 'Auto-exit: $reason',
        ),
      );

      final pnl = update.realizedPnl ?? 0;
      _notice = 'Auto-exit ($reason): '
          '${position.isShort ? 'covered' : 'sold'} ${position.quantity} '
          '${position.displaySymbol} @ ${price.toStringAsFixed(2)} · '
          'P&L ${pnl >= 0 ? '+' : ''}${pnl.toStringAsFixed(2)}';
      await refresh(reloadLists: true);
    } catch (e) {
      _error = 'Auto-exit failed for ${position.displaySymbol}: $e';
      _notify();
    } finally {
      _exitsInFlight.remove(id);
    }
  }

  // -------------------------------------------------------------------------
  // Order placement
  // -------------------------------------------------------------------------

  /// Validates, stores and (when marketable) fills a draft.
  Future<OrderResult> placeOrder(OrderDraft draft) async {
    if (_busy) {
      return const OrderResult(
        outcome: OrderOutcome.rejected,
        message: 'Another order is still being processed — try again.',
      );
    }
    _busy = true;
    _notify();
    try {
      final position =
          await _trades.openPositionFor(draft.scrip.symbol, draft.scrip.exchange.code);
      final ltp = priceFor(_keyFor(draft.scrip.symbol, draft.scrip.exchange));
      final account = snapshot;

      final check = OrderEngine.check(
        draft: draft,
        ltp: ltp,
        position: position,
        availableCash: account.availableCash,
        pendingOrderCount: _pendingOrders.length,
      );
      if (!check.isValid) {
        return OrderResult(
          outcome: OrderOutcome.rejected,
          message: check.firstError ?? 'Order rejected.',
          warnings: check.warnings,
        );
      }

      // Resolve the exits against the price the order will actually trade at.
      final reference = draft.orderType == PaperOrderType.limit
          ? (draft.limitPrice ?? ltp)
          : ltp;
      // A sell that opens an option short mirrors the exits: stop above the
      // entry, target below it.
      final opensShort =
          draft.side == OrderSide.sell && draft.canOpenShort;
      final stopLoss = reference == null
          ? null
          : OrderEngine.resolveStopLoss(
              entry: reference,
              stopLossPrice: draft.stopLossPrice,
              stopLossPct: draft.stopLossPct,
              tickSize: draft.scrip.tickSize,
              short: opensShort,
            );
      final target = reference == null
          ? null
          : OrderEngine.resolveTarget(
              entry: reference,
              targetPrice: draft.targetPrice,
              tickSize: draft.scrip.tickSize,
              short: opensShort,
            );

      var order = OrderEngine.orderFor(
        draft: draft,
        stopLoss: stopLoss,
        target: target,
        at: _clock(),
      );
      final orderId = await _trades.insertOrder(order);
      order = order.copyWith(id: orderId);

      // Can it fill right now?
      final fillPrice = switch (draft.orderType) {
        PaperOrderType.market => OrderEngine.marketFillPrice(ltp),
        PaperOrderType.limit => (ltp == null || draft.limitPrice == null)
            ? null
            : OrderEngine.limitFillPrice(
                side: draft.side,
                limitPrice: draft.limitPrice!,
                ltp: ltp,
              ),
      };

      if (fillPrice == null) {
        _notice = 'Limit order placed: ${draft.side.label} '
            '${draft.quantity} ${Scrip.plainSymbol(draft.scrip.symbol)} @ '
            '${draft.limitPrice?.toStringAsFixed(2) ?? '—'} — waiting for the '
            'market to reach it.';
        await refresh(reloadLists: true);
        return OrderResult(
          outcome: OrderOutcome.resting,
          message: _notice,
          warnings: check.warnings,
          order: order,
        );
      }

      final result = await _executeOrder(
        order,
        fillPrice,
        trigger: draft.orderType == PaperOrderType.market
            ? 'MARKET'
            : 'LIMIT reached',
        existingPosition: position,
      );
      return OrderResult(
        outcome: result ? OrderOutcome.filled : OrderOutcome.rejected,
        message: _notice,
        warnings: check.warnings,
        order: order,
      );
    } catch (e) {
      return OrderResult(
        outcome: OrderOutcome.rejected,
        message: 'Could not place the order: $e',
      );
    } finally {
      _busy = false;
      _notify();
    }
  }

  /// Fills [order] at [price]: writes the trade leg, moves the position, marks
  /// the order filled. Returns `false` if the fill could not be applied.
  Future<bool> _executeOrder(
    PaperOrder order,
    double price, {
    required String trigger,
    Position? existingPosition,
  }) async {
    final charges = EquityCharges.compute(
      side: order.side,
      price: price,
      quantity: order.quantity,
      exchange: order.exchange,
      mode: chargesMode,
      includeDpCharge: includeDpCharges,
      // Options pay the F&O stack (flat brokerage, STT sell-side only, no DP).
      kind: order.exchange == Exchange.nfo
          ? InstrumentKind.option
          : InstrumentKind.equity,
    );

    final scrip = Scrip(
      token: order.token,
      symbol: order.symbol,
      name: order.symbol,
      exchange: order.exchange,
    );

    int? positionId;
    double? realized;
    var openedShort = false;

    if (order.side == OrderSide.buy) {
      final current = existingPosition ??
          await _trades.openPositionFor(order.symbol, order.exchange.code);
      final update = OrderEngine.applyBuy(
        current: current,
        scrip: scrip,
        quantity: order.quantity,
        price: price,
        charges: charges.total,
        at: _clock(),
        stopLoss: order.stopLoss,
        target: order.target,
        groupId: order.groupId,
      );
      // A BUY against a short is a **cover** and books P&L, so this is not
      // always null: dropping it here would silently lose the P&L of every
      // covered option.
      realized = update.realizedPnl;
      if (current?.id == null) {
        positionId = await _trades.insertPosition(update.position);
      } else {
        positionId = current!.id;
        await _trades.updatePosition(update.position.copyWith(id: positionId));
      }
    } else {
      final existing = existingPosition ??
          await _trades.openPositionFor(order.symbol, order.exchange.code);
      final open = (existing != null && existing.isOpen) ? existing : null;

      // Nothing held + an option → this sell **opens a short** (writing the
      // contract). Equity never reaches here: OrderEngine.check refuses it.
      if (open == null && order.exchange != Exchange.nfo) {
        _notice = 'Could not sell ${order.displaySymbol}: no open position.';
        return false;
      }

      final update = OrderEngine.applySell(
        current: open,
        scrip: scrip,
        quantity: order.quantity,
        price: price,
        charges: charges.total,
        at: _clock(),
        stopLoss: order.stopLoss,
        target: order.target,
        groupId: order.groupId,
      );
      realized = update.realizedPnl;
      if (open?.id != null) {
        positionId = open!.id;
        await _trades.updatePosition(update.position.copyWith(id: positionId));
      } else {
        positionId = await _trades.insertPosition(update.position);
      }
      openedShort = update.openedShort;
    }

    await _trades.insertTrade(OrderEngine.tradeFor(
      order: order,
      price: price,
      charges: charges.total,
      at: _clock(),
      positionId: positionId,
      realizedPnl: realized,
    ));

    await _trades.updateOrder(order.copyWith(
      status: OrderStatus.filled,
      filledAt: _clock(),
      filledPrice: price,
      positionId: positionId,
      note: order.note.isEmpty ? trigger : '${order.note} · $trigger',
    ));

    final plain = order.displaySymbol;
    if (realized != null) {
      // A cover is a *buy* that closes a short; say so instead of "Bought".
      final verb = order.side == OrderSide.sell ? 'Sold' : 'Covered (bought)';
      _notice = '$verb ${order.quantity} $plain @ ${price.toStringAsFixed(2)} · '
          'P&L ${realized >= 0 ? '+' : ''}${realized.toStringAsFixed(2)} '
          '(after ${charges.total.toStringAsFixed(2)} charges)';
    } else if (openedShort) {
      _notice = 'Short khula (option written): sold ${order.quantity} $plain '
          '@ ${price.toStringAsFixed(2)} · charges '
          '${charges.total.toStringAsFixed(2)} · cover karne ke liye BUY karo';
    } else {
      _notice = 'Bought ${order.quantity} $plain @ ${price.toStringAsFixed(2)} · '
          'charges ${charges.total.toStringAsFixed(2)}';
    }

    _refreshDirty = true; // the caller's refresh pass must re-read the book
    await refresh(reloadLists: true);
    // A new position (e.g. a just-written option) must start ticking even if it
    // is not in the book the feed was subscribed to a second ago.
    await syncFeedSubscription();
    return true;
  }

  /// Market-exits a whole position from the Holdings tab (user-initiated).
  ///
  /// A long is sold, a short is **covered** (bought back) — same button, correct
  /// side underneath.
  Future<OrderResult> exitPosition(Position position, {String note = ''}) async {
    final ltp = priceFor(position.priceKey);
    if (ltp == null) {
      return const OrderResult(
        outcome: OrderOutcome.rejected,
        message: 'No live price for this position — connect the feed or refresh '
            'prices first.',
      );
    }
    final draft = OrderDraft(
      scrip: Scrip(
        token: position.token,
        symbol: position.symbol,
        name: position.symbol,
        exchange: position.exchange,
      ),
      side: position.isShort ? OrderSide.buy : OrderSide.sell,
      quantity: position.quantity,
      note: note.isEmpty ? 'Manual exit' : note,
      chargesMode: chargesMode,
      includeDpCharge: includeDpCharges,
    );
    return placeOrder(draft);
  }

  /// Exits *some* of a position (partial profit-taking / partial cover).
  Future<OrderResult> exitPartial(Position position, int quantity) async {
    final ltp = priceFor(position.priceKey);
    if (ltp == null) {
      return const OrderResult(
        outcome: OrderOutcome.rejected,
        message: 'No live price for this position yet.',
      );
    }
    return placeOrder(OrderDraft(
      scrip: Scrip(
        token: position.token,
        symbol: position.symbol,
        name: position.symbol,
        exchange: position.exchange,
      ),
      side: position.isShort ? OrderSide.buy : OrderSide.sell,
      quantity: quantity,
      note: position.isShort ? 'Partial cover' : 'Partial exit',
      chargesMode: chargesMode,
      includeDpCharge: includeDpCharges,
    ));
  }

  /// Fills a resting order immediately at the current market price.
  ///
  /// The Orders tab offers this when the level has already been crossed (the
  /// price moved between the last poll and now, or the user simply does not want
  /// to wait for the next tick).
  Future<OrderResult> forceFill(PaperOrder order) async {
    final ltp = priceFor(order.priceKey) ?? order.limitPrice;
    if (ltp == null) {
      return const OrderResult(
        outcome: OrderOutcome.rejected,
        message: 'No price available to fill this order right now.',
      );
    }
    final filled = await _executeOrder(order, ltp, trigger: 'Manual fill');
    return OrderResult(
      outcome: filled ? OrderOutcome.filled : OrderOutcome.rejected,
      message: _notice,
      order: order,
    );
  }

  /// Cancels a resting limit order.
  Future<void> cancelOrder(PaperOrder order) async {
    await _trades.updateOrder(order.copyWith(
      status: OrderStatus.cancelled,
      note: 'Cancelled by user',
    ));
    _notice = 'Cancelled ${order.side.label} ${order.quantity} '
        '${order.displaySymbol} @ ${order.limitPrice?.toStringAsFixed(2)}.';
    await refresh(reloadLists: true);
  }

  // -------------------------------------------------------------------------
  // Position edits
  // -------------------------------------------------------------------------

  /// Sets / clears a position's stop loss (price or %). Passing both `null`
  /// removes the stop.
  Future<void> setStopLoss(
    Position position, {
    double? price,
    double? pct,
  }) async {
    final resolved = OrderEngine.resolveStopLoss(
      entry: position.avgPrice,
      stopLossPrice: price,
      stopLossPct: pct,
      short: position.isShort,
    );
    final updated = position.copyWith(
      stopLoss: resolved,
      clearStopLoss: resolved == null,
    );
    await _trades.updatePosition(updated);
    _notice = resolved == null
        ? 'Stop loss removed for ${position.displaySymbol}.'
        : 'Stop loss set to ${resolved.toStringAsFixed(2)} '
            '(${(resolved / position.avgPrice * 100).toStringAsFixed(1)}% of '
            'the average price).';
    await refresh(reloadLists: true);
  }

  Future<void> setTarget(Position position, double? target) async {
    final resolved = target == null
        ? null
        : OrderEngine.resolveTarget(
            entry: position.avgPrice,
            targetPrice: target,
            short: position.isShort,
          );
    await _trades.updatePosition(position.copyWith(
      target: resolved,
      clearTarget: resolved == null,
    ));
    await refresh(reloadLists: true);
  }

  /// Re-tags a position; its trades inherit the group so the Reports tab stays
  /// consistent.
  Future<void> setPositionGroup(Position position, int? groupId) async {
    final id = position.id;
    if (id == null) return;
    await _trades.setPositionGroup(id, groupId);
    for (final leg in await _trades.tradesForPosition(id)) {
      await _trades.updateTradeGroup(leg.id, groupId);
    }
    _notice = groupId == null
        ? '${position.displaySymbol} moved to $kUngroupedLabel.'
        : '${position.displaySymbol} tagged "${_groupNameFor(groupId)}".';
    await refresh(reloadLists: true);
  }

  /// Wipes the paper account (orders, trades, positions). The virtual capital
  /// goes back to the configured amount.
  Future<void> resetAccount() async {
    await _trades.clearPaperAccount();
    _restPrices.clear();
    _notice = 'Paper account reset. Virtual capital: '
        '₹${startingCapital.toStringAsFixed(0)}.';
    await refresh(reloadLists: true);
  }

  // -------------------------------------------------------------------------
  // Groups
  // -------------------------------------------------------------------------

  Future<TradeGroup> createGroup(String name, {String notes = ''}) async {
    final group = await _groups.createNamed(
      name,
      notes: notes,
      colorIndex: TradeGroup.suggestColorIndex(_groupsCache.length),
    );
    await refresh(reloadLists: true);
    return group;
  }

  // -------------------------------------------------------------------------
  // Order sheet helpers (used by the UI)
  // -------------------------------------------------------------------------

  /// Instruments the order sheet can offer: searches the cached scrip master by
  /// symbol or company name.
  Future<List<Scrip>> searchInstruments(String query) async {
    final q = query.trim();
    if (q.length < 2) return const [];
    return _scripDao.search(q, limit: 25);
  }

  /// Resolves a typed symbol to one instrument (`SBIN`, `SBIN-EQ`, `NSE:SBIN`).
  /// `NSE:SBIN` / `sbin-eq` / `SBIN` all resolve to the same instrument.
  Future<Scrip?> resolveInstrument(String input) async {
    final cleaned = input.trim().toUpperCase();
    if (cleaned.isEmpty) return null;
    final bare = cleaned.contains(':') ? cleaned.split(':').last : cleaned;
    // Each lookup must be awaited individually: `??` on Futures never falls
    // through (a Future is never null), so chaining them would silently return
    // the first Future — and the `-EQ`/search fallbacks would never run.
    final direct = await _scripDao.findBySymbol(bare);
    if (direct != null) return direct;
    final suffixed = await _scripDao.findBySymbol('$bare-EQ');
    if (suffixed != null) return suffixed;
    final matches = await _scripDao.search(bare, limit: 1);
    return matches.isEmpty ? null : matches.first;
  }

  /// Current position for a symbol (drives the sheet's "you hold N" line).
  Future<Position?> positionFor(String symbol, Exchange exchange) =>
      _trades.openPositionFor(symbol, exchange.code);

  /// Validation for the live order sheet.
  OrderCheck check(OrderDraft draft) {
    final ltp = priceFor(_keyFor(draft.scrip.symbol, draft.scrip.exchange));
    return OrderEngine.check(
      draft: draft,
      ltp: ltp,
      position: _openPositions.firstWhereOrNull(
        (p) => p.symbol == draft.scrip.symbol && p.exchange == draft.scrip.exchange,
      ),
      availableCash: snapshot.availableCash,
      pendingOrderCount: _pendingOrders.length,
    );
  }

  OrderPreview preview(OrderDraft draft) => OrderEngine.preview(
        draft: draft,
        ltp: priceFor(_keyFor(draft.scrip.symbol, draft.scrip.exchange)),
      );

  int maxAffordable(double price, Exchange exchange) =>
      OrderEngine.maxAffordableQuantity(
        availableCash: snapshot.availableCash,
        price: price,
        exchange: exchange,
        mode: chargesMode,
        includeDpCharge: includeDpCharges,
      );

  /// Live price for a scrip about to be traded (drives the sheet header).
  double? livePriceFor(Scrip scrip) =>
      priceFor(_keyFor(scrip.symbol, scrip.exchange));

  /// One-off REST quote for an instrument the user is *looking at* rather than
  /// holding yet (the order sheet's symbol picker).
  ///
  /// The WebSocket only streams what the open book needs, so a brand-new symbol
  /// has no tick — without this, a market order for it could never be validated
  /// or priced. The value is cached in `_restPrices` (with a short freshness
  /// window so flipping between instruments does not burn the rate limit) and
  /// `priceFor`/`livePriceFor` pick it up immediately.
  Future<double?> fetchQuote(Scrip scrip) async {
    if (!_auth.isLoggedIn) return null;
    final key = _keyFor(scrip.symbol, scrip.exchange);
    final cached = _restPrices[key];
    if (cached != null && _clock().difference(cached.asOf).inSeconds < 15) {
      return cached.value;
    }
    try {
      final quote = await _marketData.fetchSingleLtp(scrip);
      if (quote == null) return cached?.value;
      _restPrices[key] = PricedValue(value: quote.ltp, asOf: _clock());
      _lastPriceAt = _clock();
      _error = null;
      _notify();
      return quote.ltp;
    } catch (e) {
      _error = 'Could not fetch a quote for ${scrip.symbol}: $e';
      _notify();
      return cached?.value;
    }
  }

  // -------------------------------------------------------------------------
  // Filters / notices
  // -------------------------------------------------------------------------

  Future<void> setFilter(PaperFilter filter) async {
    if (_filter == filter) return;
    _filter = filter;
    await refresh(reloadLists: true);
  }

  Future<void> setGroupFilter(int? groupId, {bool ungroupedOnly = false}) =>
      setFilter(PaperFilter(
        groupId: groupId,
        ungroupedOnly: ungroupedOnly,
        query: _filter.query,
      ));

  Future<void> setQuery(String query) =>
      setFilter(_filter.copyWith(query: query));

  void clearNotice() {
    if (_notice.isEmpty) return;
    _notice = '';
    _notify();
  }

  void clearError() {
    if (_error == null) return;
    _error = null;
    _notify();
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _feedSub?.cancel();
    _restRefreshTimer?.cancel();
    _applyWakelock(false);
    super.dispose();
  }
}

/// Small local helpers so the file does not pull in `package:collection`.
extension _FirstWhereOrNull<E> on Iterable<E> {
  E? firstWhereOrNull(bool Function(E) test) {
    for (final element in this) {
      if (test(element)) return element;
    }
    return null;
  }
}
