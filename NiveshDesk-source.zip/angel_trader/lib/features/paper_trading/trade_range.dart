// ---------------------------------------------------------------------------
// trade_range.dart — "kaunse din se kaunse din tak" (export / import ke liye).
//
// Default **ALL** hai: jab tak aap date na chunein, sab kuch niklega. Custom
// me do date (se … tak) chuni jati hain.
//
// Din ki hadbandi (midnight) IST wall-clock pe hoti hai — app ka baqi hisaab
// bhi yahi manta hai, isliye "aaj" ka matlab phone ki timezone se badalta nahi.
//
// Pure: no Flutter, no database, no network.
// ---------------------------------------------------------------------------

/// Taiyar chunav — aksar yahi kaafi hota hai, date khud nahi bharni padti.
enum TradeRangePreset {
  all('Sab (ALL)'),
  today('Aaj'),
  week1('7 din'),
  month1('1 mahina'),
  months3('3 mahine'),
  year1('1 saal'),
  custom('Custom date');

  const TradeRangePreset(this.label);

  final String label;
}

/// Chuna hua daayra.
class TradeRange {
  const TradeRange({
    this.preset = TradeRangePreset.all,
    this.from,
    this.to,
  });

  /// Hamesha ALL se shuru — jab tak aap kuch na chunein, kuch chhuta nahi.
  static const TradeRange all = TradeRange();

  final TradeRangePreset preset;

  /// Sirf [TradeRangePreset.custom] me (din ki shuruaat).
  final DateTime? from;

  /// Sirf [TradeRangePreset.custom] me (din ka aakhir).
  final DateTime? to;

  bool get isAll => preset == TradeRangePreset.all;
  bool get isCustom => preset == TradeRangePreset.custom;

  int get days => switch (preset) {
        TradeRangePreset.all => 0,
        TradeRangePreset.today => 1,
        TradeRangePreset.week1 => 7,
        TradeRangePreset.month1 => 30,
        TradeRangePreset.months3 => 90,
        TradeRangePreset.year1 => 365,
        TradeRangePreset.custom => 0,
      };

  TradeRange copyWith({
    TradeRangePreset? preset,
    DateTime? from,
    DateTime? to,
  }) =>
      TradeRange(
        preset: preset ?? this.preset,
        from: from ?? this.from,
        to: to ?? this.to,
      );

  /// Shuruat ki had (`null` = koi had nahi).
  DateTime? resolveFrom(DateTime now) {
    final start = DateTime(now.year, now.month, now.day);
    if (isCustom) {
      final day = from;
      return day == null ? null : DateTime(day.year, day.month, day.day);
    }
    return days == 0 ? null : start.subtract(Duration(days: days - 1));
  }

  /// Aakhir ki had (`null` = koi had nahi). Din ka aakhir tak, taaki aaj ke
  /// trade bhi shamil ho.
  DateTime? resolveTo(DateTime now) {
    if (isCustom) {
      final day = to ?? from;
      return day == null
          ? null
          : DateTime(day.year, day.month, day.day, 23, 59, 59, 999);
    }
    return days == 0
        ? null
        : DateTime(now.year, now.month, now.day, 23, 59, 59, 999);
  }

  /// `true` jab [when] is daayre me aata hai.
  bool contains(DateTime when, DateTime now) {
    final start = resolveFrom(now);
    final end = resolveTo(now);
    if (start != null && when.isBefore(start)) return false;
    if (end != null && when.isAfter(end)) return false;
    return true;
  }

  /// File ke naam aur report ke liye — 'Sab (ALL)' ya '1 Jan 25 – 31 Mar 25'.
  String describe(DateTime now) {
    if (isAll) return 'Sab (ALL)';
    final start = resolveFrom(now);
    final end = resolveTo(now);
    if (start == null && end == null) return 'Sab (ALL)';
    String side(DateTime? day) =>
        day == null ? '…' : '${day.day} ${_month(day.month)} ${day.year}';
    return '${side(start)} – ${side(end)}';
  }

  /// File ke naam me lagne wala hissa: `all`, `1m`, `20250101-20250331`.
  String fileTag(DateTime now) {
    if (isAll) return 'all';
    final start = resolveFrom(now);
    final end = resolveTo(now);
    String stamp(DateTime? day) => day == null
        ? ''
        : '${day.year}${_two(day.month)}${_two(day.day)}';
    if (isCustom) return '${stamp(start)}-${stamp(end)}';
    return '${days}d';
  }
}

String _two(int value) => value.toString().padLeft(2, '0');

String _month(int month) => const [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
    ][(month - 1).clamp(0, 11)];
