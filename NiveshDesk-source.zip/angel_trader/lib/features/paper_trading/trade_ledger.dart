// ---------------------------------------------------------------------------
// trade_ledger.dart — export ke liye saaf-suthri kitaab (ledger).
//
// PDF ho, Excel ho ya DB — sabko ek hi tarah ki kitaab chahiye: ek line har
// leg ke liye, aur upar hisaab. Ye file wahi banati hai, taaki teeno format
// aapas me kabhi na jhooth bolen.
//
// Pure: no Flutter, no database, no network.
// ---------------------------------------------------------------------------

import '../../data/local/models/paper_trade.dart';
import '../../data/local/models/trade_group.dart';
import 'trade_range.dart';

/// Ek leg ki ek line.
class LedgerRow {
  const LedgerRow({
    required this.executedAt,
    required this.symbol,
    required this.side,
    required this.quantity,
    required this.price,
    required this.charges,
    required this.value,
    this.realizedPnl,
    required this.group,
    required this.isClosing,
  });

  final DateTime executedAt;
  final String symbol;

  /// 'BUY' ya 'SELL'.
  final String side;

  final int quantity;
  final double price;
  final double charges;

  /// `qty × price` — gross, charges se pahle.
  final double value;

  /// Sirf band karne wali leg par (null = kholne wali).
  final double? realizedPnl;

  final String group;
  final bool isClosing;

  /// `LONG`/`SHORT` wala group hone par bhi seedha samajh aaye.
  String get sideLabel => side.toUpperCase() == 'BUY' ? 'BUY' : 'SELL';
}

/// Upar wala hisaab.
class LedgerSummary {
  const LedgerSummary({
    required this.legs,
    required this.closingLegs,
    required this.wins,
    required this.realized,
    required this.charges,
    required this.rangeLabel,
    required this.groupLabel,
    required this.generatedAt,
  });

  final int legs;
  final int closingLegs;
  final int wins;
  final double realized;
  final double charges;
  final String rangeLabel;
  final String groupLabel;
  final DateTime generatedAt;

  double get winRate => closingLegs == 0 ? 0 : wins / closingLegs;

  /// Realised minus charges — jo haath me aaya.
  double get net => realized - charges;

  bool get isEmpty => legs == 0;

  /// `64%` ya `—` jab kuch band hua hi nahi.
  String get winRateText =>
      closingLegs == 0 ? '—' : '${(winRate * 100).toStringAsFixed(0)}%';
}

/// Poori kitaab: upar hisaab, niche har leg ki line.
class TradeLedger {
  const TradeLedger({required this.summary, required this.rows});

  final LedgerSummary summary;
  final List<LedgerRow> rows;

  bool get isEmpty => rows.isEmpty;
}

/// Kitaab banata hai — range aur (agar chuna ho to) group ke hisaab se.
///
/// [trades] me sabhi leg aa sakti hain; yahin chhanti hoti hai. Naye se purane
/// (nazdeek wale upar), jaise trade book me dikhte hain.
TradeLedger buildTradeLedger({
  required List<Trade> trades,
  required List<TradeGroup> groups,
  required TradeRange range,
  required DateTime now,
  String groupLabel = 'Sab group',
  int? groupId,
  bool ungroupedOnly = false,
}) {
  final names = <int, String>{
    for (final group in groups) if (group.id != null) group.id!: group.name,
  };

  final rows = <LedgerRow>[];
  double realized = 0;
  double charges = 0;
  var closingLegs = 0;
  var wins = 0;

  for (final trade in trades) {
    if (trade.groupId != null && ungroupedOnly) continue;
    if (groupId != null && trade.groupId != groupId) continue;
    if (!range.contains(trade.executedAt, now)) continue;

    final pnl = trade.realizedPnl;
    if (pnl != null) {
      closingLegs++;
      if (pnl > 0) wins++;
      realized += pnl;
    }
    charges += trade.charges;

    rows.add(LedgerRow(
      executedAt: trade.executedAt,
      symbol: trade.displaySymbol,
      side: trade.side.name.toUpperCase(),
      quantity: trade.quantity,
      price: trade.price,
      charges: trade.charges,
      value: trade.value,
      realizedPnl: pnl,
      group: trade.groupId == null
          ? 'Ungrouped'
          : (names[trade.groupId] ?? 'Ungrouped'),
      isClosing: pnl != null,
    ));
  }

  rows.sort((a, b) => b.executedAt.compareTo(a.executedAt));

  return TradeLedger(
    summary: LedgerSummary(
      legs: rows.length,
      closingLegs: closingLegs,
      wins: wins,
      realized: realized,
      charges: charges,
      rangeLabel: range.describe(now),
      groupLabel: groupLabel,
      generatedAt: now,
    ),
    rows: rows,
  );
}
