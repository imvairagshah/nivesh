// ---------------------------------------------------------------------------
// report_math.dart — pure aggregation for the Reports tab.
//
// Everything here is a plain function over lists the provider already holds
// (trade book + open holdings + groups), so the Reports tab never hits the
// database and can never disagree with the Trade Book tab.
//
// Conventions:
//   * Only CLOSING legs (`Trade.realizedPnl != null`) count as "closed trades":
//     an opening leg has no result yet. Realised P&L is already net of both
//     legs' charges (the order engine stored it that way).
//   * A "win" is a closing leg with realised P&L > 0; break-even counts as a
//     loss for the win-rate denominator only (`wins / closed`).
//   * Months are bucketed by the trade's own timestamp in IST wall-clock.
// ---------------------------------------------------------------------------

import '../../data/local/models/paper_trade.dart';
import '../../data/local/models/trade_group.dart';
import 'portfolio_math.dart';

/// One month of realised results.
class MonthPnl {
  const MonthPnl({
    required this.monthKey,
    required this.monthStart,
    required this.label,
    required this.realized,
    required this.charges,
    required this.closedTrades,
    required this.wins,
    required this.losses,
    required this.biggestWin,
    required this.biggestLoss,
  });

  /// `2026-10` — stable sort key, also used as a Map key.
  final String monthKey;

  /// First day of the month (IST wall clock).
  final DateTime monthStart;

  /// Short human label, e.g. `Oct 26`.
  final String label;

  /// Sum of realised P&L across the month's closing legs (net of charges).
  final double realized;

  /// Charges actually paid on every leg executed in the month (both legs).
  final double charges;

  final int closedTrades;
  final int wins;
  final int losses;

  /// Best single closing leg of the month (0.0 when there were none).
  final double biggestWin;

  /// Worst single closing leg of the month (0.0 when there were none).
  final double biggestLoss;

  bool get isEmpty => closedTrades == 0;

  /// Fraction of closed trades that made money (`0` when nothing closed).
  double get winRate => closedTrades == 0 ? 0 : wins / closedTrades;
}

/// Per-group roll-up: realised history plus the live state of what is still open.
class GroupReport {
  const GroupReport({
    required this.groupId,
    required this.name,
    required this.colorIndex,
    required this.archived,
    required this.realized,
    required this.closedTrades,
    required this.wins,
    required this.losses,
    required this.openCount,
    required this.openInvested,
    required this.openUnrealized,
    required this.openPriced,
  });

  /// `null` ⇒ the implicit "Ungrouped" bucket.
  final int? groupId;

  final String name;
  final int colorIndex;
  final bool archived;

  final double realized;
  final int closedTrades;
  final int wins;
  final int losses;

  final int openCount;
  final double openInvested;

  /// Live unrealised P&L of the group's open positions; `null` when none of them
  /// has a price yet.
  final double? openUnrealized;

  /// How many open positions actually contributed to [openUnrealized].
  final int openPriced;

  bool get isUngrouped => groupId == null;

  double get winRate => closedTrades == 0 ? 0 : wins / closedTrades;

  /// Realised + unrealised, i.e. what this basket has earned so far.
  double get total => realized + (openUnrealized ?? 0);

  bool get hasHistory => closedTrades > 0;

  bool get hasOpen => openCount > 0;
}

/// Headline numbers across the whole book.
class OverallStats {
  const OverallStats({
    required this.realized,
    required this.charges,
    required this.closedTrades,
    required this.wins,
    required this.losses,
    required this.biggestWin,
    required this.biggestLoss,
    required this.profitFactor,
    required this.bestMonth,
    required this.worstMonth,
  });

  final double realized;
  final double charges;
  final int closedTrades;
  final int wins;
  final int losses;
  final double biggestWin;
  final double biggestLoss;

  /// Gross wins ÷ gross losses (`null` until there is at least one loss).
  final double? profitFactor;

  final MonthPnl? bestMonth;
  final MonthPnl? worstMonth;

  double get winRate => closedTrades == 0 ? 0 : wins / closedTrades;
  double get expectancy =>
      closedTrades == 0 ? 0 : realized / closedTrades;
}

class ReportMath {
  ReportMath._();

  static const List<String> _monthNames = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
  ];

  /// `yyyy-MM` key for a timestamp, using its own wall-clock fields (the app
  /// stamps trades with IST values, see MarketCalendar).
  static String monthKeyOf(DateTime when) =>
      '${when.year.toString().padLeft(4, '0')}-'
      '${when.month.toString().padLeft(2, '0')}';

  static String _labelOf(DateTime when) =>
      '${_monthNames[when.month - 1]} ${when.year % 100}';

  /// Realised P&L of a single closing leg (0 for opening legs).
  static double realizedOf(Trade trade) => trade.realizedPnl ?? 0;

  // -------------------------------------------------------------------------
  // Monthly series
  // -------------------------------------------------------------------------

  /// The last [months] calendar months ending with the month of [now],
  /// oldest → newest, **including months with no trades** so the bar chart keeps
  /// an even axis. [now] is injected by the caller (the provider clock).
  static List<MonthPnl> monthly(
    List<Trade> trades, {
    required DateTime now,
    int months = 12,
  }) {
    // Bucket by month key first…
    final buckets = <String, List<Trade>>{};
    final charges = <String, double>{};
    for (final trade in trades) {
      final key = monthKeyOf(trade.executedAt);
      buckets.putIfAbsent(key, () => <Trade>[]).add(trade);
      charges[key] = (charges[key] ?? 0) + trade.charges;
    }

    // …then walk the axis so empty months come out as zeroes.
    final out = <MonthPnl>[];
    final anchor = DateTime(now.year, now.month, 1);
    for (var i = months - 1; i >= 0; i--) {
      final start = DateTime(anchor.year, anchor.month - i, 1);
      final key = monthKeyOf(start);
      out.add(_monthFrom(key, start, buckets[key] ?? const [], charges[key] ?? 0));
    }
    return out;
  }

  static MonthPnl _monthFrom(
    String key,
    DateTime start,
    List<Trade> legs,
    double charges,
  ) {
    var realized = 0.0;
    var wins = 0;
    var losses = 0;
    var closed = 0;
    var biggestWin = 0.0;
    var biggestLoss = 0.0;

    for (final leg in legs) {
      final pnl = leg.realizedPnl;
      if (pnl == null) continue; // opening leg — not a result yet
      closed++;
      realized += pnl;
      if (pnl > 0) {
        wins++;
        if (pnl > biggestWin) biggestWin = pnl;
      } else {
        losses++;
        if (pnl < biggestLoss) biggestLoss = pnl;
      }
    }

    return MonthPnl(
      monthKey: key,
      monthStart: start,
      label: _labelOf(start),
      realized: realized,
      charges: charges,
      closedTrades: closed,
      wins: wins,
      losses: losses,
      biggestWin: biggestWin,
      biggestLoss: biggestLoss,
    );
  }

  // -------------------------------------------------------------------------
  // Group roll-up
  // -------------------------------------------------------------------------

  /// One [GroupReport] per group that has any history or any open position,
  /// plus the implicit "Ungrouped" row when it has something to show.
  ///
  /// Sorted by realised P&L (best first); groups that have only open exposure
  /// come after the ones with results.
  static List<GroupReport> byGroup({
    required List<Trade> trades,
    required List<TradeGroup> groups,
    required List<HoldingView> holdings,
  }) {
    final realized = <int?, double>{};
    final closed = <int?, int>{};
    final wins = <int?, int>{};
    final losses = <int?, int>{};
    final openCount = <int?, int>{};
    final openInvested = <int?, double>{};
    final openUnrealized = <int?, double>{};
    final openPriced = <int?, int>{};

    for (final trade in trades) {
      final pnl = trade.realizedPnl;
      if (pnl == null) continue;
      final id = trade.groupId;
      realized[id] = (realized[id] ?? 0) + pnl;
      closed[id] = (closed[id] ?? 0) + 1;
      if (pnl > 0) {
        wins[id] = (wins[id] ?? 0) + 1;
      } else {
        losses[id] = (losses[id] ?? 0) + 1;
      }
    }

    for (final view in holdings) {
      final id = view.position.groupId;
      openCount[id] = (openCount[id] ?? 0) + 1;
      openInvested[id] = (openInvested[id] ?? 0) + view.invested;
      final pnl = view.unrealizedPnl;
      if (pnl != null) {
        openUnrealized[id] = (openUnrealized[id] ?? 0) + pnl;
        openPriced[id] = (openPriced[id] ?? 0) + 1;
      }
    }

    final reports = <GroupReport>[];
    for (final group in groups) {
      final id = group.id;
      if (!realized.containsKey(id) && !openCount.containsKey(id)) continue;
      reports.add(GroupReport(
        groupId: id,
        name: group.name,
        colorIndex: group.colorIndex,
        archived: group.archived,
        realized: realized[id] ?? 0,
        closedTrades: closed[id] ?? 0,
        wins: wins[id] ?? 0,
        losses: losses[id] ?? 0,
        openCount: openCount[id] ?? 0,
        openInvested: openInvested[id] ?? 0,
        openUnrealized: openUnrealized[id],
        openPriced: openPriced[id] ?? 0,
      ));
    }

    // The implicit Ungrouped bucket (no row in `trade_groups` by design).
    if (realized.containsKey(null) || openCount.containsKey(null)) {
      reports.add(GroupReport(
        groupId: null,
        name: kUngroupedLabel,
        colorIndex: 0,
        archived: false,
        realized: realized[null] ?? 0,
        closedTrades: closed[null] ?? 0,
        wins: wins[null] ?? 0,
        losses: losses[null] ?? 0,
        openCount: openCount[null] ?? 0,
        openInvested: openInvested[null] ?? 0,
        openUnrealized: openUnrealized[null],
        openPriced: openPriced[null] ?? 0,
      ));
    }

    reports.sort((a, b) {
      if (a.hasHistory != b.hasHistory) return a.hasHistory ? -1 : 1;
      return b.realized.compareTo(a.realized);
    });
    return reports;
  }

  // -------------------------------------------------------------------------
  // Overall
  // -------------------------------------------------------------------------

  static OverallStats overall(List<Trade> trades, {required DateTime now}) {
    var realized = 0.0;
    var charges = 0.0;
    var closed = 0;
    var wins = 0;
    var losses = 0;
    var grossWin = 0.0;
    var grossLoss = 0.0;
    var biggestWin = 0.0;
    var biggestLoss = 0.0;

    for (final trade in trades) {
      charges += trade.charges;
      final pnl = trade.realizedPnl;
      if (pnl == null) continue;
      closed++;
      realized += pnl;
      if (pnl > 0) {
        wins++;
        grossWin += pnl;
        if (pnl > biggestWin) biggestWin = pnl;
      } else {
        losses++;
        grossLoss += -pnl;
        if (pnl < biggestLoss) biggestLoss = pnl;
      }
    }

    // Best/worst month are computed off the 12-month window; a trade older than
    // that still counts in the totals above but cannot own the title.
    final window = monthly(trades, now: now);
    MonthPnl? best;
    MonthPnl? worst;
    for (final month in window) {
      if (month.isEmpty) continue;
      if (best == null || month.realized > best.realized) best = month;
      if (worst == null || month.realized < worst.realized) worst = month;
    }

    return OverallStats(
      realized: realized,
      charges: charges,
      closedTrades: closed,
      wins: wins,
      losses: losses,
      biggestWin: biggestWin,
      biggestLoss: biggestLoss,
      profitFactor: grossLoss <= 0 ? null : grossWin / grossLoss,
      bestMonth: best,
      worstMonth: worst,
    );
  }

  /// Groups ordered for the legend/chart, capped to the palette size so colours
  /// stay unique in the month×group chart.
  static List<GroupReport> chartGroups(List<GroupReport> reports,
      {int max = kTradeGroupPaletteSize}) {
    final withHistory = reports.where((r) => r.hasHistory).toList();
    final limited = withHistory.length > max
        ? withHistory.sublist(0, max)
        : withHistory;
    return limited;
  }
}
