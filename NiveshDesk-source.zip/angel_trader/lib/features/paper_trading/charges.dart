// ---------------------------------------------------------------------------
// charges.dart — Indian equity transaction-cost model for the paper-trading
// simulation.
//
// WHY: a paper trade that ignores costs lies to you. Buying ₹1,00,000 of stock
// and selling it flat is *not* break-even in reality — STT, exchange fees, GST
// and stamp duty shave a few hundred rupees off every round trip. Modelling them
// is what makes the monthly P&L in the Reports tab trustworthy.
//
// Rates below are the statutory/typical brokerage stack for **NSE/BSE cash
// equity** (post-1-Oct-2024 regime, in force through 2025-26). They are
// constants with a comment each, so when the government changes one, you edit
// one line:
//
//   Delivery (CNC — shares actually held in your demat)
//     Brokerage   ₹0            Angel One charges nothing for delivery
//     STT         0.1%          on BOTH the buy and the sell leg
//     Stamp duty  0.015%        buy side only
//     DP charge   ₹13.5 + GST   per sell scrip per day (depository charge)
//
//   Intraday (MIS — squared off the same day)
//     Brokerage   min(₹20, 0.25% of turnover) per executed order
//     STT         0.025%        sell side only
//     Stamp duty  0.003%        buy side only
//
//   Always (both modes)
//     Exchange txn fee  NSE 0.00297% / BSE 0.00375% of turnover
//     SEBI turnover fee 0.0001% (₹10 per crore)
//     GST               18% on (brokerage + exchange fee + SEBI fee)
//
// Everything is computed per *leg* (one order fill), because that is how the
// broker charges it — which is also why a round trip is modelled as two
// breakdowns rather than one.
//
// This file is pure Dart (no Flutter, no database) so it is cheap to unit-test:
// see test/features/paper_trading/charges_test.dart.
// ---------------------------------------------------------------------------

import '../../core/utils/markets.dart';
import '../../data/local/models/paper_trade.dart';

/// Which cost stack applies. Options are **not** equity with a different name:
/// the broker charges a flat per-order fee, STT only on the sell premium, a much
/// higher exchange fee, and no DP charge — modelling them as equity would make
/// every option round trip look ~3× cheaper than it is.
enum InstrumentKind {
  equity('Equity'),
  option('Option');

  const InstrumentKind(this.label);
  final String label;
}

/// Delivery (positional) vs intraday (squared off the same day).
///
/// The difference is not cosmetic: it changes brokerage (₹0 vs max ₹20), STT
/// (both legs vs sell only) and stamp duty (0.015% vs 0.003%).
enum ChargesMode {
  delivery('Delivery', 'D'),
  intraday('Intraday', 'I');

  const ChargesMode(this.label, this.short);

  final String label;
  final String short;

  static ChargesMode fromName(String? name) => ChargesMode.values.firstWhere(
        (m) => m.name == name,
        orElse: () => ChargesMode.delivery,
      );
}

/// Rounds to paise — brokers bill in paise, and rounding the *sum* (not just the
/// components) is what keeps `₹100.00 + ₹2.97 + ₹0.10 + ₹0.55 + ₹15.00` from
/// coming out as `118.61999999999999`.
double _paise(double value) => (value * 100).roundToDouble() / 100;

/// Itemised cost of a single executed order leg.
class ChargeBreakdown {
  /// Brokerage charged by Angel One for this leg.
  final double brokerage;

  /// Securities Transaction Tax (statutory).
  final double stt;

  /// Exchange transaction charge (NSE/BSE turnover fee).
  final double exchangeTxn;

  /// SEBI turnover fee.
  final double sebi;

  /// 18% GST on brokerage + exchange txn + SEBI fee.
  final double gst;

  /// Stamp duty (buy side only).
  final double stampDuty;

  /// Depository-participant charge on a delivery sell (₹0 otherwise).
  final double dpCharge;

  /// Turnover this breakdown was computed from — `price × quantity`.
  final double turnover;

  /// Which side / mode produced it (kept for UI labels and CSV export).
  final OrderSide side;
  final ChargesMode mode;

  /// Equity or option cost stack.
  final InstrumentKind kind;

  const ChargeBreakdown({
    required this.turnover,
    required this.side,
    required this.mode,
    this.kind = InstrumentKind.equity,
    this.brokerage = 0,
    this.stt = 0,
    this.exchangeTxn = 0,
    this.sebi = 0,
    this.gst = 0,
    this.stampDuty = 0,
    this.dpCharge = 0,
  });

  /// Every rupee the broker/government takes on this leg (rounded to paise).
  double get total => _paise(
        brokerage + stt + exchangeTxn + sebi + gst + stampDuty + dpCharge,
      );

  /// Cost as a percentage of turnover — lets the UI print "≈ 0.12% in costs".
  double get totalPct => turnover == 0 ? 0 : total / turnover * 100;

  /// Cash that actually leaves the account when this leg executes.
  ///
  /// A buy debits `turnover + charges`; a sell credits `turnover − charges`.
  /// Modelling it this way keeps the cash ledger exact (no rounding drift).
  double get cashFlow => side == OrderSide.buy
      ? -_paise(turnover + total)
      : _paise(turnover - total);

  /// `true` when nothing was charged (e.g. a zero-quantity preview row).
  bool get isZero => total == 0;

  /// Compact one-line description for the order sheet, e.g.
  /// `Delivery · brokerage ₹0 · STT ₹100.00 · GST ₹5.37`.
  String get summary {
    final parts = <String>[kind == InstrumentKind.option ? 'F&O ${kind.label}' : mode.label];
    if (brokerage > 0) parts.add('brokerage ₹${brokerage.toStringAsFixed(2)}');
    if (stt > 0) parts.add('STT ₹${stt.toStringAsFixed(2)}');
    if (exchangeTxn > 0) {
      parts.add('exch ₹${exchangeTxn.toStringAsFixed(2)}');
    }
    if (gst > 0) parts.add('GST ₹${gst.toStringAsFixed(2)}');
    if (stampDuty > 0) parts.add('stamp ₹${stampDuty.toStringAsFixed(2)}');
    if (dpCharge > 0) parts.add('DP ₹${dpCharge.toStringAsFixed(2)}');
    parts.add('total ₹${total.toStringAsFixed(2)}');
    return parts.join(' · ');
  }

  /// Row for the CSV export of the trade book.
  List<String> toCsvCells() => [
        brokerage.toStringAsFixed(2),
        stt.toStringAsFixed(2),
        exchangeTxn.toStringAsFixed(2),
        sebi.toStringAsFixed(2),
        gst.toStringAsFixed(2),
        stampDuty.toStringAsFixed(2),
        dpCharge.toStringAsFixed(2),
        total.toStringAsFixed(2),
      ];

  @override
  String toString() =>
      'ChargeBreakdown(${side.name} ${mode.name}, total=${total.toStringAsFixed(2)})';
}

/// The charge rules, as a callable engine.
class EquityCharges {
  EquityCharges._();

  // ---- Brokerage ----------------------------------------------------------
  /// Delivery brokerage at Angel One is ₹0 (₹20 on intraday only).
  static const double brokerageDelivery = 0.0;

  /// Intraday brokerage is the lower of a flat ₹20 or 0.25% of turnover.
  static const double brokerageIntradayFlat = 20.0;
  static const double brokerageIntradayRate = 0.0025;

  // ---- Securities Transaction Tax ----------------------------------------
  static const double sttDeliveryRate = 0.001; // 0.1% on buy AND sell
  static const double sttIntradaySellRate = 0.00025; // 0.025%, sell only

  // ---- Exchange transaction charges --------------------------------------
  static const double exchangeTxnNseRate = 0.0000297; // 0.00297%
  static const double exchangeTxnBseRate = 0.0000375; // 0.00375%

  // ---- SEBI turnover fee --------------------------------------------------
  static const double sebiRate = 0.000001; // 0.0001% (₹10 per crore)

  // ---- GST ---------------------------------------------------------------
  static const double gstRate = 0.18; // on brokerage + exchange + SEBI

  // ---- Stamp duty (buy side only) ----------------------------------------
  static const double stampDutyDeliveryRate = 0.00015; // 0.015%
  static const double stampDutyIntradayRate = 0.00003; // 0.003%

  // ---- Depository participant charge (delivery sell) ---------------------
  /// Angel One DP charge per scrip per day, charged when delivery shares leave
  /// the demat account (i.e. on a delivery SELL).
  static const double dpChargeBase = 13.5;

  /// Itemises the cost of one executed leg.
  ///
  /// [price] is the **fill** price, not the requested price, and [quantity] the
  /// filled quantity — a partially filled order is charged on what executed.
  ///
  /// [includeDpCharge] exists because the DP charge is a broker-specific fee
  /// (₹13.5) that users who square off through a different broker may not want
  /// to see; it only ever applies to a delivery sell.
  static ChargeBreakdown compute({
    required OrderSide side,
    required double price,
    required int quantity,
    required Exchange exchange,
    ChargesMode mode = ChargesMode.delivery,
    bool includeDpCharge = true,
    InstrumentKind kind = InstrumentKind.equity,
  }) {
    final turnover = price * quantity;
    if (turnover <= 0 || quantity <= 0) {
      return ChargeBreakdown(
        turnover: 0,
        side: side,
        mode: mode,
        kind: kind,
      );
    }

    if (kind == InstrumentKind.option) {
      return _optionLeg(side: side, turnover: turnover, kind: kind);
    }

    // --- brokerage
    final brokerage = mode == ChargesMode.delivery
        ? brokerageDelivery
        : _paise(
            (turnover * brokerageIntradayRate)
                .clamp(0, brokerageIntradayFlat),
          );

    // --- STT: delivery taxes both legs, intraday only the sell
    final stt = switch (mode) {
      ChargesMode.delivery => turnover * sttDeliveryRate,
      ChargesMode.intraday =>
        side == OrderSide.sell ? turnover * sttIntradaySellRate : 0.0,
    };

    // --- exchange + SEBI
    final exchangeTxn = turnover *
        (exchange == Exchange.bse
            ? exchangeTxnBseRate
            : exchangeTxnNseRate);
    final sebi = turnover * sebiRate;

    // --- GST on the broker/exchange/regulator stack
    final gst = (brokerage + exchangeTxn + sebi) * gstRate;

    // --- stamp duty: buy side only
    final stampDuty = side == OrderSide.buy
        ? turnover *
            (mode == ChargesMode.delivery
                ? stampDutyDeliveryRate
                : stampDutyIntradayRate)
        : 0.0;

    // --- DP charge: delivery sell only (13.5 + 18% GST)
    final dpCharge = (includeDpCharge &&
            mode == ChargesMode.delivery &&
            side == OrderSide.sell)
        ? dpChargeBase * (1 + gstRate)
        : 0.0;

    return ChargeBreakdown(
      turnover: turnover,
      side: side,
      mode: mode,
      brokerage: _paise(brokerage),
      stt: _paise(stt),
      exchangeTxn: _paise(exchangeTxn),
      sebi: _paise(sebi),
      gst: _paise(gst),
      stampDuty: _paise(stampDuty),
      dpCharge: _paise(dpCharge),
    );
  }

  // -------------------------------------------------------------------------
  // Options stack (NSE F&O, post-1-Oct-2024 regime)
  //
  //   Brokerage   ₹20 per executed order (flat — Angel One's F&O rate)
  //   STT         0.1% of the premium, **sell side only**
  //   Exch txn    0.0495% of the premium
  //   SEBI        0.0001% of the premium
  //   GST         18% on (brokerage + exch + SEBI)
  //   Stamp duty  0.003% of the premium, buy side only
  //   DP charge   none (nothing is delivered)
  //
  // `mode` (delivery/intraday) deliberately does not apply: an option has no
  // delivery leg, so both directions cost the same.
  // -------------------------------------------------------------------------

  /// Flat brokerage per executed F&O order (options and futures alike).
  static const double optionBrokerageFlat = 20;

  /// STT on the **sell** premium.
  static const double optionSttSellRate = 0.001;

  /// NSE F&O options exchange transaction charge (on premium).
  static const double optionExchangeRate = 0.000495;

  /// Stamp duty on the **buy** premium.
  static const double optionStampBuyRate = 0.00003;

  static ChargeBreakdown _optionLeg({
    required OrderSide side,
    required double turnover,
    required InstrumentKind kind,
  }) {
    final brokerage = optionBrokerageFlat;
    final stt = side == OrderSide.sell ? turnover * optionSttSellRate : 0.0;
    final exchangeTxn = turnover * optionExchangeRate;
    final sebi = turnover * sebiRate;
    final gst = (brokerage + exchangeTxn + sebi) * gstRate;
    final stampDuty =
        side == OrderSide.buy ? turnover * optionStampBuyRate : 0.0;

    return ChargeBreakdown(
      turnover: turnover,
      side: side,
      mode: ChargesMode.intraday, // options have no delivery leg
      kind: kind,
      brokerage: _paise(brokerage),
      stt: _paise(stt),
      exchangeTxn: _paise(exchangeTxn),
      sebi: _paise(sebi),
      gst: _paise(gst),
      stampDuty: _paise(stampDuty),
      dpCharge: 0,
    );
  }

  /// Cost of a complete round trip (`buyQty` in, `sellQty` out) — used by the
  /// order sheet's preview line ("≈ ₹212 in charges if you exit at cost").
  ///
  /// [kind] selects the cost stack — pass [InstrumentKind.option] for an F&O
  /// leg, otherwise the preview would quote equity rates for an option.
  static double roundTripCost({
    required double buyPrice,
    required double sellPrice,
    required int quantity,
    required Exchange exchange,
    ChargesMode mode = ChargesMode.delivery,
    InstrumentKind kind = InstrumentKind.equity,
  }) =>
      compute(
        side: OrderSide.buy,
        price: buyPrice,
        quantity: quantity,
        exchange: exchange,
        mode: mode,
        kind: kind,
      ).total +
      compute(
        side: OrderSide.sell,
        price: sellPrice,
        quantity: quantity,
        exchange: exchange,
        mode: mode,
        kind: kind,
      ).total;
}
