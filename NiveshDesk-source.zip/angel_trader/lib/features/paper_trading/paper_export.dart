// ---------------------------------------------------------------------------
// paper_export.dart — Trade Book ke upar wala "Export / Import".
//
// Teen format, ek hi jagah se:
//   PDF    — chhapne / bhejne layak report (upar hisaab, niche har leg)
//   Excel  — kaam wali file, jisme aap chhant sakte ho aur formula laga sakte ho
//   DB     — poora app DB (backup) ya chune hue dinon ka data (doosre phone par)
//
// DATE: default **ALL** hai — kuch chhune tak sab kuch niklega.
// IMPORT: sirf jodta hai (merge). Duplicate (same symbol+qty+price+time)
//         chhod diya jata hai; purana data kabhi nahi mitta.
//
// Ye class file banane aur share karne ka kaam karti hai; UI alag hai.
// ---------------------------------------------------------------------------

import 'dart:io';

import '../../core/utils/share_helper.dart';

import '../../data/local/models/paper_trade.dart';
import '../../data/local/models/trade_group.dart';
import 'paper_database_file.dart';
import 'trade_excel_export.dart';
import 'trade_ledger.dart';
import 'trade_pdf_export.dart';
import 'trade_range.dart';

/// Kaun sa format.
enum PaperExportKind {
  pdf('PDF', 'Chhapne layak report (print / bhejne ke liye)'),
  excel('Excel', 'Kaam wali file — chhanto, formula lagao (.xlsx)'),
  db('DB file', 'App ka data — backup ya doosre phone par le jao');

  const PaperExportKind(this.label, this.help);

  final String label;
  final String help;
}

/// UI ko milne wala natija.
class PaperExportOutcome {
  const PaperExportOutcome({
    required this.ok,
    required this.message,
    this.file,
    this.report,
  });

  final bool ok;
  final String message;

  /// Banayi gayi file (share karne ke liye).
  final File? file;

  /// Import ke baad ka hisaab.
  final DbMergeReport? report;

  static PaperExportOutcome fail(String message) =>
      PaperExportOutcome(ok: false, message: message);
}

class PaperExportService {
  PaperExportService({
    TradePdfExport? pdf,
    TradeExcelExport? excel,
    PaperDatabaseFile? databaseFile,
    Directory? directory,
    this.shareFile,
  })  : _pdf = pdf ?? TradePdfExport(),
        _excel = excel ?? TradeExcelExport(directory: directory),
        _dbFile = databaseFile ?? PaperDatabaseFile(directory: directory);

  final TradePdfExport _pdf;
  final TradeExcelExport _excel;
  final PaperDatabaseFile _dbFile;

  /// Test seam: asli share sheet ke bajaye ye chalaya jata hai.
  final Future<void> Function(File file, String subject)? shareFile;

  // -------------------------------------------------------------------------
  // Names
  // -------------------------------------------------------------------------

  static String fileName(PaperExportKind kind, TradeRange range, DateTime now) {
    final tag = range.fileTag(now);
    final stamp = dbFileStamp(now);
    final ext = switch (kind) {
      PaperExportKind.pdf => 'pdf',
      PaperExportKind.excel => 'xlsx',
      PaperExportKind.db => 'db',
    };
    return 'niveshdesk-$tag-$stamp.$ext';
  }

  // -------------------------------------------------------------------------
  // PDF / Excel
  // -------------------------------------------------------------------------

  Future<PaperExportOutcome> exportLedger({
    required PaperExportKind kind,
    required List<Trade> trades,
    required List<TradeGroup> groups,
    required TradeRange range,
    required DateTime now,
    String groupLabel = 'Sab group',
    int? groupId,
    bool ungroupedOnly = false,
  }) async {
    try {
      final ledger = buildTradeLedger(
        trades: trades,
        groups: groups,
        range: range,
        now: now,
        groupLabel: groupLabel,
        groupId: groupId,
        ungroupedOnly: ungroupedOnly,
      );

      if (ledger.isEmpty) {
        return PaperExportOutcome.fail(
          'Is daayre me koi leg nahi mili — Export ke liye range badlo '
          '(abhi: ${range.describe(now)}).',
        );
      }

      final name = fileName(kind, range, now);
      final File file;
      switch (kind) {
        case PaperExportKind.pdf:
          final bytes = await _pdf.build(ledger);
          file = await _excelWrite(
            name: name,
            bytes: bytes,
          );
          break;
        case PaperExportKind.excel:
          file = await _excel.write(ledger: ledger, fileName: name);
          break;
        case PaperExportKind.db:
          return PaperExportOutcome.fail('DB ke liye exportDatabase() use karo.');
      }

      await _share(file, 'NiveshDesk Paper Trading');

      return PaperExportOutcome(
        ok: true,
        file: file,
        message: '${kind.label} taiyar: ${_count(ledger)} — '
            '${range.describe(now)}. Share sheet khul gaya.',
      );
    } catch (error) {
      return PaperExportOutcome.fail('${kind.label} banane me dikkat: $error');
    }
  }

  /// PDF/Excel dono ko ek jagah likhne ke liye — directory Excel wale se milti
  /// hai, isliye pdf bytes bhi wahin jate hain.
  Future<File> _excelWrite({
    required String name,
    required List<int> bytes,
  }) async {
    final file = await _excel.writeBytes(name: name, bytes: bytes);
    return file;
  }

  // -------------------------------------------------------------------------
  // DB
  // -------------------------------------------------------------------------

  /// ALL → poora DB; Custom → sirf chune hue dinon ka trading data.
  Future<PaperExportOutcome> exportDatabase({
    required TradeRange range,
    required DateTime now,
  }) async {
    try {
      final file = range.isAll
          ? await _dbFile.exportAll()
          : await _dbFile.exportRange(range: range, now: now);
      final size = await file.length();
      await _share(file, 'NiveshDesk app database');
      return PaperExportOutcome(
        ok: true,
        file: file,
        message: range.isAll
            ? 'Poora DB save ho gaya (${_size(size)}) — '
                '${file.uri.pathSegments.last}. Badi file hai, isliye WhatsApp '
                'ke bajaye backup ki jagah rakho.'
            : 'Chune hue dinon ka DB ban gaya (${_size(size)}) — '
                '${file.uri.pathSegments.last}. Import karte waqt ye sirf '
                'joda jayega, kuch nahi mitayega.',
      );
    } catch (error) {
      return PaperExportOutcome.fail('DB banane me dikkat: $error');
    }
  }

  /// File chuno aur **jodo** — kuch nahi mitta.
  Future<PaperExportOutcome> importDatabase({
    required File file,
    TradeRange range = TradeRange.all,
    DateTime? now,
  }) async {
    try {
      if (!await PaperDatabaseFile.looksLikeSqlite(file)) {
        return PaperExportOutcome.fail(
          'Ye DB file nahi lagti. NiveshDesk se export ki hui .db file chuno.',
        );
      }
      final report = await _dbFile.import(file: file, range: range, now: now);
      return PaperExportOutcome(
        ok: true,
        report: report,
        message: report.message,
      );
    } on PaperDatabaseFileException catch (error) {
      return PaperExportOutcome.fail(error.message);
    } catch (error) {
      return PaperExportOutcome.fail('Import me dikkat: $error');
    }
  }

  // -------------------------------------------------------------------------
  // Internals
  // -------------------------------------------------------------------------

  Future<void> _share(File file, String subject) async {
    final hook = shareFile;
    if (hook != null) {
      await hook(file, subject);
      return;
    }
    // 1.5.72 — desktop par file Downloads me save hoti hai (share sheet nahi).
    await ShareHelper.shareFile(file, subject);
  }

  static String _count(TradeLedger ledger) =>
      '${ledger.summary.legs} leg, ${ledger.summary.closingLegs} band';

  static String _size(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(0)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }
}
