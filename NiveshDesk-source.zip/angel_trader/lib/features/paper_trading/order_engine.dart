// ---------------------------------------------------------------------------
// order_engine.dart — the rules of the paper-trading desk, as pure functions.
//
// Three responsibilities, deliberately kept out of the UI and out of the
// database so they can be unit-tested exhaustively:
//
//   1. FILL RULES      when does an order execute, and at what price?
//        MARKET  → at the live LTP, immediately (there is no book to walk;
//                  the LTP is the honest "best available" price in a sim).
//        LIMIT   → only when the market trades through the level, and then at
//                  the *better* of the two prices (a limit buy whose level is
//                  above the market fills at the market — that is what a real
//                  exchange does).
//
//   2. BOOK-KEEPING    how does a fill change the position?
//        BUY   → weighted-average cost grows, opening charges accumulate.
//        SELL  → realised P&L is booked net of the exit charges *and* of the
//                pro-rated opening charges the retired shares carried, which is
//                what makes the ledger balance (see portfolio_math.dart).
//
//   3. VALIDATION      what should the user be told before they tap Place?
//        hard errors (blocked) vs. warnings (allowed but risky).
//
// Long-only: BUY opens/adds, SELL reduces/closes. There is no short selling.
// ---------------------------------------------------------------------------

import '../../core/utils/markets.dart';
import '../../data/local/models/paper_trade.dart';
import '../../data/remote/dto/scrip.dart';
import 'charges.dart';

/// Everything the order sheet collects, in one immutable object.
class OrderDraft {
  /// Instrument being traded (carries the tick size used for price rounding).
  final Scrip scrip;

  final OrderSide side;
  final int quantity;
  final PaperOrderType orderType;

  /// Requested price — only meaningful for a LIMIT order.
  final double? limitPrice;

  /// Stop loss expressed as an absolute price …
  final double? stopLossPrice;

  /// … or as a percentage below the entry. If both are given, the price wins.
  final double? stopLossPct;

  /// Optional target price.
  final double? targetPrice;

  /// Strategy tag (`null` = Ungrouped).
  final int? groupId;

  final String note;

  /// Delivery vs intraday charge model (see charges.dart).
  final ChargesMode chargesMode;

  /// Contract size when the instrument is an F&O option (`0` = equity).
  ///
  /// Options are quoted and traded in **lots**; the sheet asks for lots and the
  /// draft carries the size so validation can insist on a whole multiple.
  final int lotSize;

  /// Whether the ₹13.5 + GST DP charge applies to a delivery sell.
  final bool includeDpCharge;

  const OrderDraft({
    required this.scrip,
    required this.side,
    required this.quantity,
    this.orderType = PaperOrderType.market,
    this.limitPrice,
    this.stopLossPrice,
    this.stopLossPct,
    this.targetPrice,
    this.groupId,
    this.note = '',
    this.chargesMode = ChargesMode.delivery,
    this.includeDpCharge = true,
    this.lotSize = 0,
  });

  /// `true` when this order is for an F&O contract (options live on NFO).
  bool get isOption => scrip.exchange == Exchange.nfo;

  /// The cost stack this order pays.
  InstrumentKind get chargesKind =>
      isOption ? InstrumentKind.option : InstrumentKind.equity;

  /// `true` when a SELL may **open** a position (option writing). Equity stays
  /// long-only: for cash instruments a naked short is not a thing the paper book
  /// pretends to support.
  bool get canOpenShort => isOption;

  OrderDraft copyWith({
    Scrip? scrip,
    OrderSide? side,
    int? quantity,
    int? lotSize,
    PaperOrderType? orderType,
    double? limitPrice,
    double? stopLossPrice,
    double? stopLossPct,
    double? targetPrice,
    int? groupId,
    String? note,
    ChargesMode? chargesMode,
    bool? includeDpCharge,
  }) =>
      OrderDraft(
        scrip: scrip ?? this.scrip,
        side: side ?? this.side,
        quantity: quantity ?? this.quantity,
        lotSize: lotSize ?? this.lotSize,
        orderType: orderType ?? this.orderType,
        limitPrice: limitPrice ?? this.limitPrice,
        stopLossPrice: stopLossPrice ?? this.stopLossPrice,
        stopLossPct: stopLossPct ?? this.stopLossPct,
        targetPrice: targetPrice ?? this.targetPrice,
        groupId: groupId ?? this.groupId,
        note: note ?? this.note,
        chargesMode: chargesMode ?? this.chargesMode,
        includeDpCharge: includeDpCharge ?? this.includeDpCharge,
      );
}

/// Result of validating a draft: blocking errors and advisory warnings.
class OrderCheck {
  final List<String> errors;
  final List<String> warnings;

  const OrderCheck({this.errors = const [], this.warnings = const []});

  bool get isValid => errors.isEmpty;
  bool get hasWarnings => warnings.isNotEmpty;

  /// First blocking message, for a snackbar/inline banner.
  String? get firstError => errors.isEmpty ? null : errors.first;

  @override
  String toString() => 'OrderCheck(errors=$errors, warnings=$warnings)';
}

/// Everything the order sheet shows *before* the user commits: what it will
/// cost, what is at risk, and where break-even sits.
class OrderPreview {
  /// Price the estimate is based on — the LTP for a marketable order, else the
  /// limit price.
  final double referencePrice;

  final double turnover;
  final ChargeBreakdown charges;

  /// Cash that must be free for a BUY (turnover + charges); 0 for a SELL.
  final double cashRequired;

  /// Cash credited by a SELL (turnover − charges); 0 for a BUY.
  final double cashReleased;

  /// Price at which the round trip breaks even after both legs' charges —
  /// the single most useful number to show a new trader.
  final double breakEvenPrice;

  /// Stop-loss actually applied (resolved from price-or-percent), `null` if none.
  final double? stopLoss;

  /// Target actually applied, `null` if none.
  final double? target;

  /// Rupees at risk between [referencePrice] and [stopLoss] (positive).
  final double? riskAmount;

  /// Rupees to gain between [referencePrice] and [target] (positive).
  final double? rewardAmount;

  /// Charges for a hypothetical immediate round trip at [referencePrice].
  final double roundTripCharges;

  const OrderPreview({
    required this.referencePrice,
    required this.turnover,
    required this.charges,
    required this.cashRequired,
    required this.cashReleased,
    required this.breakEvenPrice,
    required this.roundTripCharges,
    this.stopLoss,
    this.target,
    this.riskAmount,
    this.rewardAmount,
  });

  /// Reward ÷ risk; `null` when either side is missing.
  double? get riskReward {
    final r = riskAmount;
    final w = rewardAmount;
    if (r == null || w == null || r <= 0) return null;
    return w / r;
  }

  /// Stop distance as a % of the reference price (positive below it).
  double? get stopPct {
    final sl = stopLoss;
    if (sl == null || referencePrice == 0) return null;
    return (referencePrice - sl) / referencePrice * 100;
  }

  @override
  String toString() =>
      'OrderPreview(ref=${referencePrice.toStringAsFixed(2)}, '
      'charges=${charges.total.toStringAsFixed(2)})';
}

/// The outcome of applying a fill to a position.
class PositionUpdate {
  /// The position as it should be stored after the fill (never `null`: a buy
  /// with no prior position creates one).
  final Position position;

  /// Realised P&L booked by this fill — `null` for opening/adding legs.
  final double? realizedPnl;

  /// `true` when this fill opened a **new short** (option writing) rather than
  /// reducing a long. The provider uses it only for the wording of the notice —
  /// the arithmetic lives in [position].
  final bool openedShort;

  const PositionUpdate({
    required this.position,
    this.realizedPnl,
    this.openedShort = false,
  });

  bool get isClosing => realizedPnl != null;
}

class OrderEngine {
  OrderEngine._();

  /// Sanity ceiling on a single paper order. Not a broker rule — just a guard
  /// against a fat-fingered quantity zeroing the account.
  static const int maxQuantity = 100000;

  /// Maximum number of pending LIMIT orders allowed at once (keeps the feed
  /// subscription list small and the Orders tab readable).
  static const int maxPendingOrders = 25;

  // -------------------------------------------------------------------------
  // Price helpers
  // -------------------------------------------------------------------------

  /// Rounds [price] to a valid multiple of [tickSize] (NSE equity = ₹0.05).
  ///
  /// [up] selects the direction (a stop loss rounds down, a target rounds up, so
  /// rounding never silently tightens the trade by a tick).
  static double tickRound(double price, double tickSize, {bool up = true}) {
    final tick = tickSize <= 0 ? 0.05 : tickSize;
    // Snap the step count to 6 decimals before rounding. In binary floating
    // point 94.05 / 0.05 is 1880.9999999999998, which would floor a "5 % below
    // entry" stop one extra tick lower — and ceil a target one tick higher.
    final steps = double.parse((price / tick).toStringAsFixed(6));
    final rounded = up ? steps.ceil() : steps.floor();
    final value = rounded * tick;
    // Kill floating-point dust like 1234.0500000000002.
    return (value * 100).roundToDouble() / 100;
  }

  /// The price a LIMIT order fills at, or `null` when it cannot fill yet.
  ///
  /// A limit order is *marketable* when the market is already at least as good
  /// as the requested price; it then fills at the market price (price
  /// improvement), otherwise it rests.
  static double? limitFillPrice({
    required OrderSide side,
    required double limitPrice,
    required double ltp,
  }) {
    if (ltp <= 0 || limitPrice <= 0) return null;
    if (side == OrderSide.buy) return ltp <= limitPrice ? ltp : null;
    return ltp >= limitPrice ? ltp : null;
  }

  /// The price a MARKET order fills at — the live LTP, or `null` when no price
  /// is available (offline). Callers must reject rather than invent a price.
  static double? marketFillPrice(double? ltp) =>
      (ltp == null || ltp <= 0) ? null : ltp;

  /// `true` when a resting order should now execute against [ltp].
  static bool isMarketable(PaperOrder order, double ltp) {
    final limit = order.limitPrice;
    if (limit == null) return false;
    return limitFillPrice(side: order.side, limitPrice: limit, ltp: ltp) != null;
  }

  /// Break-even exit price for a long position: the sell price at which
  /// `(exit − entry) × qty` exactly covers the opening charges and the exit
  /// charges.
  ///
  /// Exit charges themselves depend on the exit price (STT and exchange fees are
  /// ad-valorem), so this is solved with two fixed-point iterations — exact to
  /// well under a paisa, and deterministic for tests.
  /// [side] is the *opening* side: a long buys first (exit = sell), a short
  /// sells first (exit = buy), which mirrors the whole equation.
  static double breakEvenPrice({
    required double entryPrice,
    required int quantity,
    required Exchange exchange,
    ChargesMode mode = ChargesMode.delivery,
    bool includeDpCharge = true,
    InstrumentKind kind = InstrumentKind.equity,
    OrderSide side = OrderSide.buy,
  }) {
    if (quantity <= 0 || entryPrice <= 0) return entryPrice;
    final opens = side == OrderSide.buy ? OrderSide.buy : OrderSide.sell;
    final exits = side == OrderSide.buy ? OrderSide.sell : OrderSide.buy;

    final openCharges = EquityCharges.compute(
      side: opens,
      price: entryPrice,
      quantity: quantity,
      exchange: exchange,
      mode: mode,
      includeDpCharge: includeDpCharge,
      kind: kind,
    ).total;

    var price = entryPrice;
    for (var i = 0; i < 2; i++) {
      final exitCharges = EquityCharges.compute(
        side: exits,
        price: price,
        quantity: quantity,
        exchange: exchange,
        mode: mode,
        includeDpCharge: includeDpCharge,
        kind: kind,
      ).total;
      if (side == OrderSide.buy) {
        // (exit − entry) × qty = open + exit charges
        price = (entryPrice * quantity + openCharges + exitCharges) / quantity;
      } else {
        // (entry − exit) × qty = open + exit charges
        price = (entryPrice * quantity - openCharges - exitCharges) / quantity;
      }
    }
    return price;
  }

  // -------------------------------------------------------------------------
  // Stop-loss / target resolution
  // -------------------------------------------------------------------------

  /// Turns "SL price or SL %" into an absolute price for a long entry at
  /// [entry]. Returns `null` when neither was supplied.
  ///
  /// A percentage stop is always *below* the entry; the price, if given, is
  /// clamped to at least one tick below the entry so an instant trigger cannot
  /// be created by accident (the UI warns about it too).
  ///
  /// [short] mirrors the whole thing for a position that starts by *selling*:
  /// its stop has to sit **above** the entry, otherwise the very first tick
  /// would trip it.
  static double? resolveStopLoss({
    required double entry,
    double? stopLossPrice,
    double? stopLossPct,
    double tickSize = 0.05,
    bool short = false,
  }) {
    if (short) {
      if (stopLossPrice != null && stopLossPrice > 0) {
        return stopLossPrice <= entry
            ? tickRound(entry + tickSize, tickSize, up: true)
            : stopLossPrice;
      }
      if (stopLossPct != null && stopLossPct > 0) {
        return tickRound(entry * (1 + stopLossPct / 100), tickSize, up: true);
      }
      return null;
    }
    if (stopLossPrice != null && stopLossPrice > 0) {
      return stopLossPrice >= entry
          ? tickRound(entry - tickSize, tickSize, up: false)
          : stopLossPrice;
    }
    if (stopLossPct != null && stopLossPct > 0) {
      final price = entry * (1 - stopLossPct / 100);
      return price <= 0 ? null : tickRound(price, tickSize, up: false);
    }
    return null;
  }

  /// Target price for a long entry (`null` when not supplied).
  ///
  /// For a [short] the target is the *lower* price (a written option profits as
  /// the premium decays), so the comparison flips.
  static double? resolveTarget({
    required double entry,
    double? targetPrice,
    double tickSize = 0.05,
    bool short = false,
  }) {
    if (targetPrice == null) return null;
    if (short) {
      final price = targetPrice;
      if (price >= entry || price <= 0) return null;
      return tickRound(price, tickSize, up: false);
    }
    if (targetPrice <= entry) return null;
    return tickRound(targetPrice, tickSize, up: true);
  }

  /// Inverse of [resolveStopLoss]: the % a stop price sits below [entry].
  static double? stopPctFor({required double entry, double? stopLoss}) {
    if (stopLoss == null || entry <= 0) return null;
    return (entry - stopLoss) / entry * 100;
  }

  // -------------------------------------------------------------------------
  // Validation
  // -------------------------------------------------------------------------

  /// Checks a draft against the account and (for sells) the open position.
  ///
  /// [availableCash] is ignored for sells. [ltp] may be `null` when the app has
  /// no price yet — that blocks MARKET orders but still allows a LIMIT order to
  /// be placed (it is going to rest anyway).
  static OrderCheck check({
    required OrderDraft draft,
    required double? ltp,
    required Position? position,
    required double availableCash,
    int pendingOrderCount = 0,
    double bufferPct = 0.0,
  }) {
    final errors = <String>[];
    final warnings = <String>[];
    final qty = draft.quantity;
    final scrip = draft.scrip;

    // ---- quantity
    if (qty <= 0) {
      errors.add('Enter a quantity of at least 1 share.');
    } else if (qty > maxQuantity) {
      errors.add('Quantity is capped at ${maxQuantity.toString()} shares.');
    }

    // ---- price / order type
    final limit = draft.limitPrice;
    switch (draft.orderType) {
      case PaperOrderType.market:
        if (ltp == null || ltp <= 0) {
          errors.add(
            'No live price for ${scrip.symbol} yet — connect the live feed or '
            'place a LIMIT order instead.',
          );
        }
      case PaperOrderType.limit:
        if (limit == null || limit <= 0) {
          errors.add('Enter a limit price.');
        } else if (ltp != null &&
            ltp > 0 &&
            draft.side == OrderSide.buy &&
            limit > ltp * 1.2) {
          warnings.add(
            'Limit is more than 20% above the market — it will fill '
            'immediately at ${ltp.toStringAsFixed(2)}.',
          );
        } else if (ltp != null &&
            ltp > 0 &&
            draft.side == OrderSide.sell &&
            limit < ltp * 0.8) {
          warnings.add(
            'Limit is more than 20% below the market — it will fill '
            'immediately at ${ltp.toStringAsFixed(2)}.',
          );
        }
    }

    // ---- lot size (options trade in whole lots)
    if (draft.lotSize > 0 && qty > 0 && qty % draft.lotSize != 0) {
      errors.add(
        '1 lot = ${draft.lotSize} qty — quantity usi ka multiple honi chahiye '
        '(jaise ${draft.lotSize}, ${draft.lotSize * 2}, ${draft.lotSize * 3}…).',
      );
    }

    // ---- side-specific
    final open = position?.isOpen == true ? position : null;
    final held = open?.quantity ?? 0;
    final shortOpen = open?.isShort ?? false;
    if (draft.side == OrderSide.sell) {
      if (shortOpen) {
        // Adding to a short — allowed, same as adding to a long.
      } else if (held == 0) {
        // Nothing held. On an option this is the normal way to *write* the
        // contract (open a short); equity paper trading stays long-only.
        if (!draft.canOpenShort) {
          errors.add(
            'No open position in ${scrip.symbol} to sell. Equity paper trading '
            'here is long-only: buy first.',
          );
        }
      } else if (qty > held) {
        errors.add(
          'You hold $held ${draft.isOption ? 'qty' : 'share'}'
          '${held == 1 ? '' : 's'} — sell at most that many, or use the '
          'Holdings tab to exit the full position.',
        );
      }
    } else if (shortOpen) {
      // Buying against a short = covering. Never more than the short, and it
      // needs no cash check (it releases the blocked margin instead).
      if (qty > held) {
        errors.add('Short position $held qty ka hai — utna hi cover ho sakta hai.');
      }
    } else {
      // Estimate the cash need using the best price knowledge available.
      final ref = draft.orderType == PaperOrderType.limit ? (limit ?? ltp) : ltp;
      if (ref != null && ref > 0 && qty > 0) {
        final need = EquityCharges.compute(
          side: OrderSide.buy,
          price: ref,
          quantity: qty,
          exchange: scrip.exchange,
          mode: draft.chargesMode,
          includeDpCharge: draft.includeDpCharge,
          kind: draft.chargesKind,
        ).total +
            (ref * qty);
        final budget = availableCash * (1 - bufferPct / 100);
        if (need > budget + 0.01) {
          errors.add(
            'Not enough virtual cash: needs ${need.toStringAsFixed(0)} '
            '(including charges), available ${availableCash.toStringAsFixed(0)}.',
          );
        }
      }
    }

    // ---- stop loss / target sanity
    final entryRef = draft.orderType == PaperOrderType.limit
        ? (limit ?? ltp)
        : ltp;
    if (draft.stopLossPrice != null && draft.stopLossPrice! <= 0) {
      errors.add('Stop-loss price must be greater than zero.');
    }
    if (draft.stopLossPct != null) {
      if (draft.stopLossPct! <= 0) {
        errors.add('Stop-loss % must be greater than zero.');
      } else if (draft.stopLossPct! > 50) {
        warnings.add('A ${draft.stopLossPct!.toStringAsFixed(0)}% stop would '
            'risk half the position value on one trade.');
      } else if (draft.stopLossPct! < 0.5) {
        warnings.add('A stop that tight will be triggered by normal noise.');
      }
    }
    if (entryRef != null && entryRef > 0) {
      // A sell that opens an option short is a short entry: its stop is above
      // and its target below, so the warnings have to read the same way.
      final opensShort = draft.side == OrderSide.sell && draft.canOpenShort;
      final sl = resolveStopLoss(
        entry: entryRef,
        stopLossPrice: draft.stopLossPrice,
        stopLossPct: draft.stopLossPct,
        short: opensShort,
      );
      if (sl != null && !opensShort && sl >= entryRef) {
        warnings.add('Stop-loss is at or above the entry price.');
      }
      if (sl != null && opensShort && sl <= entryRef) {
        warnings.add('Short ka stop-loss entry se neeche hai.');
      }
      if (opensShort) {
        if (draft.targetPrice != null && draft.targetPrice! >= entryRef) {
          warnings.add('Short ka target entry se oopar hai.');
        }
      } else if (draft.targetPrice != null && draft.targetPrice! <= entryRef) {
        warnings.add('Target is below the entry price.');
      }
      if (sl == null && draft.targetPrice == null) {
        warnings.add(
          'No stop-loss: the position will not be auto-exited. You can still '
          'exit it from Holdings.',
        );
      }
    }

    // ---- pending-order cap
    if (draft.orderType == PaperOrderType.limit &&
        pendingOrderCount >= maxPendingOrders) {
      errors.add(
        'You already have $pendingOrderCount pending orders (limit '
        '$maxPendingOrders). Cancel one before adding another.',
      );
    }

    return OrderCheck(errors: errors, warnings: warnings);
  }

  /// Builds the sheet's cost/risk preview. Never throws: with no price it falls
  /// back to the limit price, then to zero-turnover placeholders.
  static OrderPreview preview({
    required OrderDraft draft,
    required double? ltp,
  }) {
    final limit = draft.limitPrice;
    final ref = switch (draft.orderType) {
      PaperOrderType.market => ltp ?? limit ?? 0,
      PaperOrderType.limit => limit ?? ltp ?? 0,
    };

    final charges = EquityCharges.compute(
      side: draft.side,
      price: ref,
      quantity: draft.quantity,
      exchange: draft.scrip.exchange,
      mode: draft.chargesMode,
      includeDpCharge: draft.includeDpCharge,
    );
    final turnover = ref * draft.quantity;

    final opensShort = draft.side == OrderSide.sell && draft.canOpenShort;
    final sl = resolveStopLoss(
      entry: ref,
      stopLossPrice: draft.stopLossPrice,
      stopLossPct: draft.stopLossPct,
      tickSize: draft.scrip.tickSize,
      short: opensShort,
    );
    final target = resolveTarget(
      entry: ref,
      targetPrice: draft.targetPrice,
      tickSize: draft.scrip.tickSize,
      short: opensShort,
    );

    return OrderPreview(
      referencePrice: ref,
      turnover: turnover,
      charges: charges,
      cashRequired: draft.side == OrderSide.buy ? turnover + charges.total : 0,
      cashReleased: draft.side == OrderSide.sell ? turnover - charges.total : 0,
      breakEvenPrice: breakEvenPrice(
        entryPrice: ref,
        quantity: draft.quantity,
        exchange: draft.scrip.exchange,
        mode: draft.chargesMode,
        includeDpCharge: draft.includeDpCharge,
        kind: draft.chargesKind,
        side: draft.side,
      ),
      roundTripCharges: EquityCharges.roundTripCost(
        buyPrice: ref,
        sellPrice: ref,
        quantity: draft.quantity,
        exchange: draft.scrip.exchange,
        mode: draft.chargesMode,
        kind: draft.chargesKind,
      ),
      stopLoss: sl,
      target: target,
      riskAmount: sl == null ? null : (ref - sl) * draft.quantity,
      rewardAmount: target == null ? null : (target - ref) * draft.quantity,
    );
  }

  // -------------------------------------------------------------------------
  // Book-keeping
  // -------------------------------------------------------------------------

  /// Applies a BUY fill to a position, returning the position to store.
  ///
  /// Weighted-average cost, opening charges accumulated (so a later exit can
  /// book a P&L net of them), and the entry's group/stop/target adopted.
  /// A missing stop on the *add* leg leaves the existing stop untouched; a new
  /// stop replaces it.
  static PositionUpdate applyBuy({
    required Position? current,
    required Scrip scrip,
    required int quantity,
    required double price,
    required double charges,
    required DateTime at,
    double? stopLoss,
    double? target,
    int? groupId,
    bool adoptStopLoss = true,
  }) {
    // Buying against a short **covers** it: realised P&L is (sold − bought),
    // the mirror of a long exit. Handled here so no caller has to know.
    if (current != null && current.isOpen && current.isShort) {
      return _coverShort(
        current: current,
        quantity: quantity,
        price: price,
        charges: charges,
        at: at,
      );
    }

    final prevQty = current?.isOpen == true ? current!.quantity : 0;
    final prevAvg = current?.isOpen == true ? current!.avgPrice : 0.0;
    final newQty = prevQty + quantity;
    final newAvg = newQty == 0 ? price : (prevAvg * prevQty + price * quantity) / newQty;

    final base = current ??
        Position(
          symbol: scrip.symbol,
          exchange: scrip.exchange,
          token: scrip.token,
          quantity: 0,
          avgPrice: price,
          openedAt: at,
        );

    return PositionUpdate(
      position: base.copyWith(
        symbol: scrip.symbol,
        exchange: scrip.exchange,
        token: scrip.token,
        quantity: newQty,
        avgPrice: newAvg,
        chargesPaid: (current?.chargesPaid ?? 0) + charges,
        stopLoss: adoptStopLoss ? (stopLoss ?? current?.stopLoss) : current?.stopLoss,
        target: adoptStopLoss ? (target ?? current?.target) : current?.target,
        groupId: current?.isOpen == true ? (current!.groupId ?? groupId) : groupId,
        status: PositionStatus.open,
        openedAt: prevQty == 0 ? at : (current?.openedAt ?? at),
      ),
      realizedPnl: null,
    );
  }

  /// Applies a SELL fill, booking realised P&L **net** of the exit charges and
  /// of the pro-rated opening charges the sold shares carried.
  ///
  /// `quantity` must be ≤ the position's quantity (validated by [check]).
  /// [at] is the fill time used to stamp `closedAt` (injectable for tests).
  static PositionUpdate applySell({
    required Position? current,
    required int quantity,
    required double price,
    required double charges,
    DateTime? at,
    // Only used when this sell *opens* a short (i.e. there was nothing held).
    Scrip? scrip,
    double? stopLoss,
    double? target,
    int? groupId,
  }) {
    // Nothing open → this sell writes the contract (a short). The caller has
    // already checked that the instrument may be shorted (OrderDraft.canOpenShort).
    if (current == null || !current.isOpen) {
      final base = current ??
          Position(
            symbol: scrip?.symbol ?? '',
            exchange: scrip?.exchange ?? Exchange.nse,
            token: scrip?.token ?? '',
            quantity: 0,
            avgPrice: price,
            openedAt: at ?? DateTime.now(),
          );
      return PositionUpdate(
        position: base.copyWith(
          symbol: scrip?.symbol ?? base.symbol,
          exchange: scrip?.exchange ?? base.exchange,
          token: scrip?.token ?? base.token,
          side: PositionSide.short,
          quantity: quantity,
          avgPrice: price,
          status: PositionStatus.open,
          openedAt: at ?? DateTime.now(),
          closedAt: null,
          groupId: groupId,
          stopLoss: stopLoss,
          target: target,
          clearStopLoss: stopLoss == null,
          clearTarget: target == null,
          // Premium received is cash *in*, so the leg's charges are the only
          // cost recorded now; they are pro-rated back when it is covered.
          chargesPaid: base.chargesPaid + charges,
        ),
        realizedPnl: null,
        openedShort: true,
      );
    }

    // Adding to an existing short: weighted average, no realised P&L yet.
    if (current.isShort) {
      final prevQty = current.quantity;
      final prevAvg = current.avgPrice;
      final newQty = prevQty + quantity;
      final newAvg = newQty == 0 ? price : (prevAvg * prevQty + price * quantity) / newQty;
      return PositionUpdate(
        position: current.copyWith(
          quantity: newQty,
          avgPrice: newAvg,
          chargesPaid: current.chargesPaid + charges,
          status: PositionStatus.open,
        ),
        realizedPnl: null,
      );
    }

    final held = current.quantity;
    final sold = quantity.clamp(0, held);
    if (sold == 0) {
      return PositionUpdate(position: current, realizedPnl: null);
    }

    // Opening charges retire in proportion to the shares being sold.
    final sharedCharges = held == 0 ? 0.0 : current.chargesPaid * (sold / held);
    final gross = (price - current.avgPrice) * sold;
    final realized = gross - sharedCharges - charges;

    final remaining = held - sold;
    final closing = remaining == 0;

    return PositionUpdate(
      position: current.copyWith(
        quantity: remaining,
        chargesPaid: closing ? 0 : current.chargesPaid - sharedCharges,
        status: closing ? PositionStatus.closed : PositionStatus.open,
        closedAt: closing ? (at ?? DateTime.now()) : null,
      ),
      realizedPnl: realized,
    );
  }

  /// Covers (buys back) part or all of a short: realised P&L is
  /// `(avgPrice − price) × qty`, net of the pro-rated opening charges and the
  /// cover leg's own charges — the exact mirror of [applySell]'s long exit.
  static PositionUpdate _coverShort({
    required Position current,
    required int quantity,
    required double price,
    required double charges,
    DateTime? at,
  }) {
    final held = current.quantity;
    final covered = quantity.clamp(0, held);
    if (covered == 0) {
      return PositionUpdate(position: current, realizedPnl: null);
    }

    final sharedCharges = held == 0 ? 0.0 : current.chargesPaid * (covered / held);
    final gross = (current.avgPrice - price) * covered;
    final realized = gross - sharedCharges - charges;

    final remaining = held - covered;
    final closing = remaining == 0;

    return PositionUpdate(
      position: current.copyWith(
        quantity: remaining,
        chargesPaid: closing ? 0 : current.chargesPaid - sharedCharges,
        status: closing ? PositionStatus.closed : PositionStatus.open,
        closedAt: closing ? (at ?? DateTime.now()) : null,
      ),
      realizedPnl: realized,
    );
  }

  /// How many shares of [availableCash] can be bought at [price] including
  /// charges — powers the "Max" button in the order sheet.
  ///
  /// Uses the *net* price per share (fill + estimated charges per share) and then
  /// walks down until the full cost fits, because charges are a step function
  /// (the ₹20 intraday cap).
  static int maxAffordableQuantity({
    required double availableCash,
    required double price,
    required Exchange exchange,
    ChargesMode mode = ChargesMode.delivery,
    bool includeDpCharge = true,
  }) {
    if (price <= 0 || availableCash <= 0) return 0;

    // First guess: charges are usually ≤ 0.3%, so 99.7% of the cash is a safe
    // upper bound; then verify and shave.
    var qty = (availableCash / price).floor();
    if (qty > maxQuantity) qty = maxQuantity;
    while (qty > 0) {
      final cost = price * qty +
          EquityCharges.compute(
            side: OrderSide.buy,
            price: price,
            quantity: qty,
            exchange: exchange,
            mode: mode,
            includeDpCharge: includeDpCharge,
          ).total;
      if (cost <= availableCash) return qty;
      qty--;
    }
    return 0;
  }

  /// Builds the [PaperOrder] row for a submission, before any fill is known.
  static PaperOrder orderFor({
    required OrderDraft draft,
    required double? stopLoss,
    required double? target,
    required DateTime at,
    double? limitPrice,
  }) =>
      PaperOrder(
        symbol: draft.scrip.symbol,
        exchange: draft.scrip.exchange,
        token: draft.scrip.token,
        side: draft.side,
        quantity: draft.quantity,
        orderType: draft.orderType,
        limitPrice: draft.orderType == PaperOrderType.limit
            ? (limitPrice ?? draft.limitPrice)
            : null,
        stopLoss: stopLoss,
        target: target,
        groupId: draft.groupId,
        status: OrderStatus.pending,
        createdAt: at,
        note: draft.note,
      );

  /// Builds the [Trade] row for a fill.
  static Trade tradeFor({
    required PaperOrder order,
    required double price,
    required double charges,
    required DateTime at,
    int? positionId,
    double? realizedPnl,
  }) =>
      Trade(
        symbol: order.symbol,
        exchange: order.exchange,
        token: order.token,
        side: order.side,
        quantity: order.quantity,
        price: price,
        orderType: order.orderType,
        positionId: positionId,
        groupId: order.groupId,
        realizedPnl: realizedPnl,
        charges: charges,
        executedAt: at,
        note: order.note,
      );
}
