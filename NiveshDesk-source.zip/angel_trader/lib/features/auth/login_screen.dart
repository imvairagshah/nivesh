// ---------------------------------------------------------------------------
// login_screen.dart — SmartAPI 2FA login.
//
//   API key      → from smartapi.angelbroking.com → My Apps → Create App
//   Client code  → your Angel One client id (e.g. A123456)
//   Password     → the 4-digit MPIN (or your login password)
//   TOTP secret  → base32 secret shown when you enable TOTP in SmartAPI
//
// The TOTP is generated on the phone (RFC 6238); a live countdown shows how long
// the visible code stays valid. Credentials go straight into the platform
// keystore — they are never written to SQLite and never sent anywhere except
// Angel One's login endpoint.
// ---------------------------------------------------------------------------

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/link_opener.dart';
import '../../core/widgets/brand.dart';
import '../../core/widgets/motion.dart';
import '../../core/utils/totp.dart';
import '../../data/remote/dto/session.dart';
import '../../services/auth_service.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, required this.onBrowseOffline});

  /// Lets the user explore cached screener data without a broker session.
  final VoidCallback onBrowseOffline;

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _apiKey = TextEditingController();
  final _clientCode = TextEditingController();
  final _password = TextEditingController();
  final _totpSecret = TextEditingController();
  final _manualTotp = TextEditingController();

  bool _obscurePassword = true;
  bool _manualTotpMode = false;
  bool _busy = false;

  /// Drives the "code refreshes in Ns" countdown.
  Timer? _ticker;
  int _secondsLeft = Totp.periodSeconds;
  String _liveTotp = '';

  @override
  void initState() {
    super.initState();
    final auth = context.read<AuthService>();
    _apiKey.text = auth.savedApiKey;
    _clientCode.text = auth.savedClientCode;
    _startTicker();
  }

  void _startTicker() {
    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() {
        _secondsLeft = Totp.secondsRemaining();
        if (!_manualTotpMode &&
            Totp.isValidSecret(_totpSecret.text) &&
            !Totp.isExpiringSoon(threshold: 0)) {
          _liveTotp = Totp.generate(_totpSecret.text);
        }
      });
    });
  }

  @override
  void dispose() {
    _ticker?.cancel();
    _apiKey.dispose();
    _clientCode.dispose();
    _password.dispose();
    _totpSecret.dispose();
    _manualTotp.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    FocusScope.of(context).unfocus();
    if (!(_formKey.currentState?.validate() ?? false)) return;
    if (_manualTotpMode && _manualTotp.text.trim().length != 6) {
      _snack('Enter the 6-digit code from your authenticator app.');
      return;
    }

    setState(() => _busy = true);
    final auth = context.read<AuthService>();
    final ok = await auth.login(
      AngelCredentials(
        apiKey: _apiKey.text.trim(),
        clientCode: _clientCode.text.trim().toUpperCase(),
        password: _password.text,
        totpSecret: _totpSecret.text.trim(),
      ),
      manualTotp: _manualTotpMode ? _manualTotp.text.trim() : null,
    );
    if (!mounted) return;
    setState(() => _busy = false);
    if (ok) {
      _snack('Connected to Angel One.');
    }
    // On success AppGate swaps this screen for the shell; on failure the error
    // banner below shows the SmartAPI message.
  }

  Future<void> _reLoginWithSaved() async {
    setState(() => _busy = true);
    final auth = context.read<AuthService>();
    final ok = await auth.loginWithSavedCredentials();
    if (!mounted) return;
    setState(() => _busy = false);
    if (ok) _snack('Session renewed.');
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();
    final scheme = Theme.of(context).colorScheme;
    final error = auth.errorMessage;

    return Scaffold(
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 32),
            children: [
              _Header(scheme: scheme),
              const SizedBox(height: 24),
              Text(
                'Sign in with SmartAPI',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 10),

              if (error != null) ...[
                _ErrorBanner(
                  message: error,
                  hint: auth.errorHint ?? '',
                  onDismiss: auth.clearError,
                ),
                const SizedBox(height: 16),
              ],

              if (auth.hasSavedPassword && auth.hasSavedTotpSecret) ...[
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Saved login found',
                          style: Theme.of(context).textTheme.titleSmall,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Client ${auth.savedClientCode} · MPIN and TOTP secret '
                          'are in the secure keystore.',
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                        const SizedBox(height: 12),
                        FilledButton.icon(
                          onPressed: _busy ? null : _reLoginWithSaved,
                          icon: const Icon(Icons.bolt),
                          label: const Text('Re-login with saved details'),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),
              ],

              Text(
                'API credentials',
                style: Theme.of(context).textTheme.titleSmall,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: _apiKey,
                textCapitalization: TextCapitalization.characters,
                decoration: const InputDecoration(
                  labelText: 'API key',
                  hintText: 'e.g. AbCdEfGh',
                  prefixIcon: Icon(Icons.vpn_key_outlined),
                  helperText: 'SmartAPI → My Apps → API key',
                ),
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'API key is required' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _clientCode,
                textCapitalization: TextCapitalization.characters,
                decoration: const InputDecoration(
                  labelText: 'Client code',
                  hintText: 'e.g. A123456',
                  prefixIcon: Icon(Icons.badge_outlined),
                ),
                validator: (v) => (v == null || v.trim().isEmpty)
                    ? 'Client code is required'
                    : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _password,
                obscureText: _obscurePassword,
                decoration: InputDecoration(
                  labelText: 'Password / MPIN',
                  prefixIcon: const Icon(Icons.lock_outline),
                  suffixIcon: IconButton(
                    icon: Icon(
                      _obscurePassword
                          ? Icons.visibility_outlined
                          : Icons.visibility_off_outlined,
                    ),
                    onPressed: () =>
                        setState(() => _obscurePassword = !_obscurePassword),
                  ),
                ),
                validator: (v) => (v == null || v.isEmpty)
                    ? 'Password / MPIN is required'
                    : null,
              ),
              const SizedBox(height: 20),

              Row(
                children: [
                  Expanded(
                    child: Text(
                      'Two-factor authentication',
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                  ),
                  SegmentedButton<bool>(
                    style: const ButtonStyle(
                      visualDensity: VisualDensity.compact,
                    ),
                    segments: const [
                      ButtonSegment(value: false, label: Text('Secret')),
                      ButtonSegment(value: true, label: Text('6-digit')),
                    ],
                    selected: {_manualTotpMode},
                    onSelectionChanged: (value) =>
                        setState(() => _manualTotpMode = value.first),
                  ),
                ],
              ),
              const SizedBox(height: 10),

              if (!_manualTotpMode) ...[
                TextFormField(
                  controller: _totpSecret,
                  autofillHints: const [AutofillHints.oneTimeCode],
                  decoration: const InputDecoration(
                    labelText: 'TOTP secret (base32)',
                    hintText: 'JBSWY3DPEHPK3PXP',
                    prefixIcon: Icon(Icons.shield_outlined),
                    helperText: 'Stored in the device keystore, used to generate '
                        'the code automatically',
                  ),
                  onChanged: (_) => setState(() {
                    _liveTotp = Totp.isValidSecret(_totpSecret.text) &&
                            !Totp.isExpiringSoon(threshold: 0)
                        ? Totp.generate(_totpSecret.text)
                        : '';
                  }),
                  validator: (v) {
                    if (_manualTotpMode) return null;
                    if (v == null || v.trim().isEmpty) {
                      return 'Enter the TOTP secret or switch to a 6-digit code';
                    }
                    if (!Totp.isValidSecret(v)) {
                      return 'That does not look like a base32 TOTP secret';
                    }
                    return null;
                  },
                ),
                if (_liveTotp.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  _TotpPreview(
                    code: _liveTotp,
                    secondsLeft: _secondsLeft,
                    scheme: scheme,
                  ),
                ],
              ] else ...[
                TextFormField(
                  controller: _manualTotp,
                  keyboardType: TextInputType.number,
                  maxLength: 6,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  autofillHints: const [AutofillHints.oneTimeCode],
                  decoration: InputDecoration(
                    labelText: '6-digit TOTP',
                    prefixIcon: const Icon(Icons.pin_outlined),
                    counterText: '',
                    helperText: 'Code from your authenticator app · refreshes in '
                        '${_secondsLeft}s',
                  ),
                  validator: (v) {
                    if (!_manualTotpMode) return null;
                    return (v == null || v.trim().length != 6)
                        ? 'Enter the 6-digit code'
                        : null;
                  },
                ),
              ],

              const SizedBox(height: 24),
              FilledButton.icon(
                onPressed: _busy ? null : _submit,
                icon: _busy
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.login),
                label: Text(_busy ? 'Connecting…' : 'Connect to Angel One'),
                style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(48),
                ),
              ),
              const SizedBox(height: 8),
              TextButton.icon(
                onPressed: () => LinkOpener.open(
                  'https://smartapi.angelbroking.com/docs',
                  context: context,
                ),
                icon: const Icon(Icons.menu_book_outlined, size: 18),
                label: const Text('How do I get an API key and enable TOTP?'),
              ),
              const Divider(height: 32),
              OutlinedButton.icon(
                onPressed: widget.onBrowseOffline,
                icon: const Icon(Icons.offline_bolt_outlined),
                label: const Text('Browse cached data without logging in'),
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size.fromHeight(46),
                ),
              ),
              const SizedBox(height: 18),
              _Disclaimer(scheme: scheme),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Sub-widgets
// ---------------------------------------------------------------------------

class _Header extends StatelessWidget {
  const _Header({required this.scheme});

  final ColorScheme scheme;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // ---- brand block
        const Center(
          child: FadeSlideIn(
            child: BrandLogo(
              markSize: 54,
              axis: Axis.vertical,
              showTagline: true,
            ),
          ),
        ),
        const SizedBox(height: 24),
        Text(
          Brand.blurb,
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.bodySmall,
        ),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(AppSpacing.md),
          decoration: BoxDecoration(
            color: scheme.primaryContainer.withOpacity(0.35),
            borderRadius: BorderRadius.circular(AppRadius.md),
            border: Border.all(color: scheme.primary.withOpacity(0.18)),
          ),
          child: Row(
            children: [
              Icon(Icons.shield_outlined, size: 18, color: scheme.primary),
              const SizedBox(width: AppSpacing.sm),
              Expanded(
                child: Text(
                  'Read-only market data and 100% simulated trades. Credentials '
                  'never leave the phone except to Angel One’s login endpoint.',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: scheme.onSurface,
                      ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _TotpPreview extends StatelessWidget {
  const _TotpPreview({
    required this.code,
    required this.secondsLeft,
    required this.scheme,
  });

  final String code;
  final int secondsLeft;
  final ColorScheme scheme;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest.withOpacity(0.4),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(Icons.verified_user_outlined, size: 18, color: scheme.primary),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Live TOTP', style: Theme.of(context).textTheme.labelSmall),
                Text(
                  code.replaceRange(3, 3, ' '),
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 3,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            width: 42,
            height: 42,
            child: Stack(
              alignment: Alignment.center,
              children: [
                CircularProgressIndicator(
                  value: secondsLeft / Totp.periodSeconds,
                  strokeWidth: 3,
                ),
                Text('$secondsLeft', style: const TextStyle(fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ErrorBanner extends StatelessWidget {
  const _ErrorBanner({
    required this.message,
    required this.hint,
    required this.onDismiss,
  });

  final String message;
  final String hint;
  final VoidCallback onDismiss;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: scheme.errorContainer,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.error_outline, color: scheme.onErrorContainer, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  message,
                  style: TextStyle(
                    color: scheme.onErrorContainer,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                if (hint.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(
                    hint,
                    style: TextStyle(color: scheme.onErrorContainer, fontSize: 12),
                  ),
                ],
              ],
            ),
          ),
          IconButton(
            visualDensity: VisualDensity.compact,
            icon: Icon(Icons.close, size: 18, color: scheme.onErrorContainer),
            onPressed: onDismiss,
          ),
        ],
      ),
    );
  }
}

class _Disclaimer extends StatelessWidget {
  const _Disclaimer({required this.scheme});

  final ColorScheme scheme;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        border: Border.all(color: scheme.outlineVariant),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.gavel_outlined, size: 18, color: scheme.onSurfaceVariant),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              'This app only reads market data. It places no orders, and the '
              'paper-trading module is a simulation for practice and analysis. '
              'Not investment advice.',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ),
        ],
      ),
    );
  }
}
