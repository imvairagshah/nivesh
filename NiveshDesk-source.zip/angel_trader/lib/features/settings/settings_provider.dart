// ---------------------------------------------------------------------------
// settings_provider.dart — user preferences (persisted in SQLite).
//
// Every setter writes through to the database immediately, so a settings change
// survives a force-close even if the user never taps "Save".
// ---------------------------------------------------------------------------

import '../../features/fno/ai/ai_suggestion.dart' show AiFilters;
import 'package:flutter/material.dart';

import '../../data/local/dao/settings_dao.dart';
import '../../data/local/models/app_settings.dart';

class SettingsProvider extends ChangeNotifier {
  SettingsProvider(this._dao);

  final SettingsDao _dao;

  AppSettings _settings = const AppSettings();
  bool _loaded = false;

  AppSettings get settings => _settings;
  bool get isLoaded => _loaded;

  ThemeMode get themeMode => switch (_settings.themeMode) {
        'light' => ThemeMode.light,
        'dark' => ThemeMode.dark,
        _ => ThemeMode.system,
      };

  Future<void> load() async {
    _settings = await _dao.load();
    _loaded = true;
    notifyListeners();
  }

  Future<void> _persist(AppSettings next) async {
    _settings = next;
    notifyListeners();
    await _dao.save(next);
  }

  Future<void> setProximityPct(int value) =>
      _persist(_settings.copyWith(proximityPct: value.clamp(1, 25)));

  Future<void> setThemeMode(String mode) =>
      _persist(_settings.copyWith(themeMode: mode));

  Future<void> setStartingCapital(double value) =>
      _persist(_settings.copyWith(startingCapital: value < 1000 ? 1000 : value));

  /// The AI Suggestion screen reads its thresholds from here, so a change in
  /// Settings is honoured by the very next run.
  AiFilters get aiFilters => AiFilters(
        rsiOversold: _settings.aiRsiOversold,
        rsiOverbought: _settings.aiRsiOverbought,
        volumeSpike: _settings.aiVolumeSpike,
        nearHighPct: _settings.aiNearHighPct,
        minStudyScore: _settings.aiMinStudyScore,
        minScore: _settings.aiMinScore,
        minTurnoverCrore: _settings.aiMinTurnoverCrore,
        eventBlockDays: _settings.aiEventBlockDays,
        riskPct: _settings.aiRiskPct,
        buyMinDte: _settings.aiBuyMinDte,
        sellMaxDte: _settings.aiSellMaxDte,
        topN: _settings.aiTopN,
      );

  /// Applies the whole AI filter block in **one** write — the filter sheet calls
  /// this on every slider move, and seven separate writes per frame would be
  /// seven SQLite round-trips for one gesture.
  Future<void> setAiFilters(AiFilters value) => _persist(_settings.copyWith(
        aiRsiOversold: value.rsiOversold,
        aiRsiOverbought: value.rsiOverbought,
        aiVolumeSpike: value.volumeSpike,
        aiNearHighPct: value.nearHighPct,
        aiMinStudyScore: value.minStudyScore,
        aiMinScore: value.minScore,
        aiMinTurnoverCrore: value.minTurnoverCrore,
        aiEventBlockDays: value.eventBlockDays,
        aiRiskPct: value.riskPct,
        aiBuyMinDte: value.buyMinDte,
        aiSellMaxDte: value.sellMaxDte,
        aiTopN: value.topN,
      ));

  Future<void> setAiRsiOversold(double value) =>
      _persist(_settings.copyWith(aiRsiOversold: value.clamp(1, 99)));

  Future<void> setAiRsiOverbought(double value) =>
      _persist(_settings.copyWith(aiRsiOverbought: value.clamp(1, 99)));

  Future<void> setAiVolumeSpike(double value) =>
      _persist(_settings.copyWith(aiVolumeSpike: value.clamp(0.1, 20)));

  Future<void> setAiNearHighPct(double value) =>
      _persist(_settings.copyWith(aiNearHighPct: value.clamp(1, 50)));

  Future<void> setAiMinStudyScore(double value) =>
      _persist(_settings.copyWith(aiMinStudyScore: value.clamp(0, 12)));

  Future<void> setAiMinScore(double value) =>
      _persist(_settings.copyWith(aiMinScore: value.clamp(0, 100)));

  Future<void> setAiMinTurnoverCrore(double value) => _persist(
      _settings.copyWith(aiMinTurnoverCrore: value.clamp(0, 500)));

  Future<void> setAiEventBlockDays(int value) =>
      _persist(_settings.copyWith(aiEventBlockDays: value.clamp(0, 30)));

  Future<void> setAiRiskPct(double value) =>
      _persist(_settings.copyWith(aiRiskPct: value.clamp(0.1, 10)));

  Future<void> setAiBuyMinDte(int value) =>
      _persist(_settings.copyWith(aiBuyMinDte: value.clamp(0, 60)));

  Future<void> setAiSellMaxDte(int value) =>
      _persist(_settings.copyWith(aiSellMaxDte: value.clamp(3, 90)));

  Future<void> setAiTopN(int value) =>
      _persist(_settings.copyWith(aiTopN: value.clamp(5, 50)));

  Future<void> resetAiFilters() => setAiFilters(AiFilters.defaults);

  Future<void> setDeathCrossEnabled(bool value) =>
      _persist(_settings.copyWith(deathCrossEnabled: value));

  Future<void> setAutoRefreshSeconds(int value) =>
      _persist(_settings.copyWith(autoRefreshSeconds: value.clamp(15, 900)));

  Future<void> setGoldenCrossUniverse(String universe) =>
      _persist(_settings.copyWith(goldenCrossUniverse: universe));

  // ---- RSI scanner (Feature 4) -------------------------------------------

  Future<void> setRsiUniverse(String universe) =>
      _persist(_settings.copyWith(rsiUniverse: universe));

  /// Persists all three threshold values at once (the sheet edits them
  /// together, so a half-applied period/threshold pair is never stored).
  Future<void> setRsiThresholds({
    int? period,
    double? upper,
    double? lower,
  }) =>
      _persist(_settings.copyWith(
        rsiPeriod: period?.clamp(2, 200),
        rsiUpper: upper?.clamp(1, 99),
        rsiLower: lower?.clamp(1, 99),
      ));

  // ---- F&O module (3-Month Study) ---------------------------------------

  /// Telegram credentials for "Send to Telegram" (document upload).
  Future<void> setTelegramCredentials({
    required String botToken,
    required String chatId,
  }) =>
      _persist(_settings.copyWith(
        telegramBotToken: botToken.trim(),
        telegramChatId: chatId.trim(),
      ));

  Future<void> setKeepScreenAwake(bool value) =>
      _persist(_settings.copyWith(keepScreenAwake: value));

  Future<void> setNotifyWebhookUrl(String url) =>
      _persist(_settings.copyWith(notifyWebhookUrl: url.trim()));

  // ---- Paper trading (Feature 3) -----------------------------------------

  /// `delivery` | `intraday` — the simulated cost model.
  Future<void> setChargesMode(String mode) => _persist(
        _settings.copyWith(
          chargesMode: mode == 'intraday' ? 'intraday' : 'delivery',
        ),
      );

  Future<void> setIncludeDpCharges(bool value) =>
      _persist(_settings.copyWith(includeDpCharges: value));

  Future<void> setLiveFeedEnabled(bool value) =>
      _persist(_settings.copyWith(liveFeedEnabled: value));

  Future<void> setAutoExitOnTarget(bool value) =>
      _persist(_settings.copyWith(autoExitOnTarget: value));

  /// `auto` | `broker` | `blackScholes` — see [StudyIvSource].
  Future<void> setStudyIvSource(String value) =>
      _persist(_settings.copyWith(studyIvSource: value));
}
