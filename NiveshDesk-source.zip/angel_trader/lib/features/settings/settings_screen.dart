// ---------------------------------------------------------------------------
// settings_screen.dart — session, instrument master, screener defaults, theme
// and local-data diagnostics.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../core/utils/formatters.dart';
import '../../core/widgets/app_version.dart';
import '../../core/widgets/brand.dart';
import '../../core/utils/link_opener.dart';
import '../../data/local/app_database.dart';
import '../../data/local/dao/candle_dao.dart';
import '../../data/local/dao/fno_contract_dao.dart';
import '../../data/local/dao/scan_cache_dao.dart';
import '../../data/local/dao/settings_dao.dart';
import '../../features/fno/study/study_engine.dart' show StudyIvSource;
import '../fno/study/iv_sheet.dart';
import '../fno/study/iv_sheet_link.dart';
import '../../data/local/dao/scrip_dao.dart';
import '../fno/ai/ai_suggestion_screen.dart' show showAiFilterSheet;
import '../../services/auth_service.dart';
import '../../services/scrip_master_service.dart';
import '../auth/login_screen.dart';
import '../paper_trading/charges.dart';
import '../paper_trading/group_manager_screen.dart';
import '../paper_trading/paper_trading_provider.dart';
import 'settings_provider.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 32),
        children: const [
          _SessionCard(),
          SizedBox(height: 12),
          _ScripMasterCard(),
          SizedBox(height: 12),
          _ScreenerCard(),
          SizedBox(height: 12),
          _AppearanceCard(),
          SizedBox(height: 12),
          _FnoStudyCard(),
          _IvSheetCard(),
          SizedBox(height: 12),
          _AiSuggestionCard(),
          SizedBox(height: 12),
          _PaperTradingCard(),
          SizedBox(height: 12),
          _DataCard(),
          SizedBox(height: 12),
          _StorageCard(),
          SizedBox(height: 12),
          _AboutCard(),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Angel One session
// ---------------------------------------------------------------------------

class _SessionCard extends StatelessWidget {
  const _SessionCard();

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();
    final scheme = Theme.of(context).colorScheme;

    return _Section(
      title: 'Angel One session',
      icon: Icons.vpn_key_outlined,
      children: [
        if (auth.isLoggedIn) ...[
          _Row('Client', auth.session?.clientCode ?? '—'),
          _Row(
            'Name',
            auth.profile?.name.isNotEmpty == true ? auth.profile!.name : '—',
          ),
          _Row('Token valid for', '${auth.minutesToExpiry ?? 0} min'),
          _Row('Token expires', Fmt.dateTime(auth.session?.expiresAt)),
          const SizedBox(height: 10),
          Wrap(
            spacing: 10,
            children: [
              OutlinedButton.icon(
                onPressed: () async {
                  final ok = await auth.refreshSession();
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        ok
                            ? 'Session refreshed.'
                            : 'Could not refresh — try logging in again.',
                      ),
                    ),
                  );
                },
                icon: const Icon(Icons.autorenew, size: 18),
                label: const Text('Refresh token'),
              ),
              TextButton.icon(
                onPressed: () => auth.logout(),
                icon: const Icon(Icons.logout, size: 18),
                label: const Text('Log out'),
              ),
            ],
          ),
        ] else ...[
          Text(
            'Not connected. Prices come from the local cache until you log in.',
            style: TextStyle(fontSize: 13, color: scheme.onSurfaceVariant),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => LoginScreen(
                  onBrowseOffline: () => Navigator.of(context).pop(),
                ),
              ),
            ),
            icon: const Icon(Icons.login, size: 18),
            label: const Text('Sign in to Angel One'),
          ),
        ],
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Scrip master
// ---------------------------------------------------------------------------

class _ScripMasterCard extends StatelessWidget {
  const _ScripMasterCard();

  @override
  Widget build(BuildContext context) {
    final master = context.watch<ScripMasterService>();
    final scheme = Theme.of(context).colorScheme;
    final busy = master.isRefreshing;

    return _Section(
      title: 'Instrument master (symbol ➜ token)',
      icon: Icons.storage_outlined,
      children: [
        _Row('Instruments cached', '${master.rowCount}'),
        _Row('Source', master.source.isEmpty ? 'not loaded' : master.source),
        _Row(
          'Updated',
          master.lastUpdated == null
              ? 'never'
              : Fmt.relative(master.lastUpdated),
        ),
        _Row(
          'Broker file',
          master.fileDate == null ? 'unknown' : Fmt.dateTime(master.fileDate),
        ),
        if (busy) ...[
          const SizedBox(height: 12),
          LinearProgressIndicator(
            value: master.progress == 0 ? null : master.progress,
          ),
          const SizedBox(height: 6),
          Text(master.stage, style: const TextStyle(fontSize: 11)),
        ] else if (master.stage.isNotEmpty) ...[
          const SizedBox(height: 6),
          Text(
            master.stage,
            style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
          ),
        ],
        const SizedBox(height: 10),
        Wrap(
          spacing: 10,
          children: [
            FilledButton.tonalIcon(
              onPressed: busy
                  ? null
                  : () async {
                      try {
                        await master.refresh(force: true);
                        if (!context.mounted) return;
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              'Master updated — ${master.rowCount} instruments.',
                            ),
                          ),
                        );
                      } catch (e) {
                        if (!context.mounted) return;
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Update failed: $e')),
                        );
                      }
                    },
              icon: const Icon(Icons.cloud_download_outlined, size: 18),
              label: const Text('Download latest'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          'Angel One publishes the full instrument list daily — 34 MB, ~1.45 lakh '
          'rows (every exchange: cash, F&O, currency, commodity). It is streamed, '
          'filtered to what the app needs and stored in SQLite. Before downloading, '
          'the app asks the host for the file\'s Last-Modified with a 1 KB request: '
          'if the broker has not published anything new (weekend, holiday, or a '
          'second launch on the same day) the 34 MB is skipped. The bundled starter '
          'list is used until the first download completes.',
          style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Screener defaults
// ---------------------------------------------------------------------------

class _ScreenerCard extends StatelessWidget {
  const _ScreenerCard();

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();
    final value = settings.settings;

    return _Section(
      title: 'Screener defaults',
      icon: Icons.tune,
      children: [
        Row(
          children: [
            const Expanded(child: Text('Proximity band')),
            Text('±${value.proximityPct}%'),
          ],
        ),
        Slider(
          value: value.proximityPct.toDouble().clamp(0.5, 10),
          min: 0.5,
          max: 10,
          divisions: 19,
          label: '±${value.proximityPct}%',
          onChanged: (v) => settings.setProximityPct(v.round()),
        ),
        Text(
          'A stock is listed when the live price is within this band of its '
          'listing-day high or low (spec default ±3%).',
          style: TextStyle(
            fontSize: 11,
            color: Theme.of(context).colorScheme.onSurfaceVariant,
          ),
        ),
        const Divider(height: 24),
        Row(
          children: [
            const Expanded(child: Text('Auto-refresh interval')),
            DropdownButton<int>(
              value:
                  const [
                    15,
                    30,
                    60,
                    120,
                    300,
                    600,
                  ].contains(value.autoRefreshSeconds)
                  ? value.autoRefreshSeconds
                  : 60,
              items: const [15, 30, 60, 120, 300, 600]
                  .map((s) => DropdownMenuItem(value: s, child: Text('${s}s')))
                  .toList(),
              onChanged: (v) {
                if (v != null) settings.setAutoRefreshSeconds(v);
              },
            ),
          ],
        ),
        Text(
          'Prices are only polled while the market is open (09:15–15:30 IST) and '
          'while you are signed in.',
          style: TextStyle(
            fontSize: 11,
            color: Theme.of(context).colorScheme.onSurfaceVariant,
          ),
        ),
        const Divider(height: 24),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          value: value.deathCrossEnabled,
          onChanged: settings.setDeathCrossEnabled,
          title: const Text('Include Death Cross'),
          subtitle: const Text(
            'Golden Cross tab: also list 50-SMA crossing below 200-SMA '
            '(Feature 2)',
            style: TextStyle(fontSize: 11),
          ),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Appearance
// ---------------------------------------------------------------------------

class _AppearanceCard extends StatelessWidget {
  const _AppearanceCard();

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();

    return _Section(
      title: 'Appearance',
      icon: Icons.palette_outlined,
      children: [
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(
              value: 'system',
              label: Text('System'),
              icon: Icon(Icons.brightness_auto, size: 16),
            ),
            ButtonSegment(
              value: 'light',
              label: Text('Light'),
              icon: Icon(Icons.light_mode, size: 16),
            ),
            ButtonSegment(
              value: 'dark',
              label: Text('Dark'),
              icon: Icon(Icons.dark_mode, size: 16),
            ),
          ],
          selected: {settings.settings.themeMode},
          onSelectionChanged: (value) => settings.setThemeMode(value.first),
        ),
        const SizedBox(height: 12),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          value: settings.settings.keepScreenAwake,
          onChanged: settings.setKeepScreenAwake,
          title: const Text('Keep the screen awake'),
          subtitle: const Text(
            'Only while the live price feed is running (paper trading)',
            style: TextStyle(fontSize: 11),
          ),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Local data
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// F&O module — 3-Month Study
// ---------------------------------------------------------------------------

/// The universal Opstra IVP/IVR Google Sheet link (1.5.57) — yehi ek jagah
/// link save hota hai, aur AI Jodi Study, 3-Month Study aur Study Advance
/// sab isko use karte hain (shared IvSheetStore cache).
class _IvSheetCard extends StatefulWidget {
  const _IvSheetCard();

  @override
  State<_IvSheetCard> createState() => _IvSheetCardState();
}

class _IvSheetCardState extends State<_IvSheetCard> {
  late final TextEditingController _controller = TextEditingController(
    text: IvSheetStore.instance.sourceUrl ?? '',
  );

  @override
  void initState() {
    super.initState();
    // Link load karke shared cache bhar do — sab screens ko faayda.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      refreshIvSheetIfPossible(context);
      if (_controller.text.trim().isEmpty) {
        _controller.text = IvSheetStore.instance.sourceUrl ?? '';
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _saveAndFetch() async {
    final url = _controller.text.trim();
    if (url.isEmpty) return;
    final settings = context.read<SettingsDao>();
    await settings.put(IvSheetStore.urlKey, url);
    await IvSheetStore.instance.refresh(url);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return _Section(
      title: 'IVP/IVR sheet (Opstra)',
      icon: Icons.table_chart_rounded,
      children: [
        TextField(
          controller: _controller,
          style: const TextStyle(fontSize: 13),
          decoration: const InputDecoration(
            labelText: 'Google Sheet link',
            hintText: 'https://docs.google.com/spreadsheets/d/…',
            isDense: true,
            border: OutlineInputBorder(),
          ),
          onSubmitted: (_) => _saveAndFetch(),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            FilledButton.tonal(
              onPressed: _saveAndFetch,
              child: const Text('Save + Fetch'),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: ListenableBuilder(
                listenable: IvSheetStore.instance,
                builder: (context, _) => Text(
                  IvSheetStore.instance.bySymbol.isEmpty
                      ? (IvSheetStore.instance.error ??
                          'Abhi koi data load nahi hua.')
                      : '${IvSheetStore.instance.bySymbol.length} stocks · '
                          'as of ${IvSheetStore.instance.asOf ?? IvSheetStore.instance.fetchedAt ?? DateTime.now()}'
                          '${IvSheetStore.instance.error == null ? '' : ' · ${IvSheetStore.instance.error}'}',
                  style: TextStyle(
                    fontSize: 11,
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          'Sheet "Publish to web" (CSV) honi chahiye — columns symbol | ivp | '
          'ivr. Ek baar yahan link save kar do: AI Jodi Study, 3-Month Study '
          'aur Study Advance — sab jagah IVP/IVR dikhne lagenge. Data '
          'Google sheet me jo Opstra se daala hai wahi hai — missing values '
          'missing hi rehte hain.',
          style: TextStyle(
            fontSize: 11,
            color: Theme.of(context).colorScheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }
}

class _FnoStudyCard extends StatelessWidget {
  const _FnoStudyCard();

  @override
  Widget build(BuildContext context) {
    return _Section(
      title: 'F&O — 3-Month Study',
      icon: Icons.query_stats,
      children: [
        const _IvSourcePicker(),
        const Divider(height: 24),
        Text(
          'Study poore F&O universe ka hota hai — jo bhi stock resolve hota hai, '
          'sab scan hote hain (213-name list me se har ek). Kitne stocks scan '
          'karne hain — aisi koi setting nahi hai, kyunki adhoora scan adhoori '
          'list se bura hai. Pehla scan candles download karta hai (~1.5 min), '
          'uske baad sab cache se aata hai.',
          style: TextStyle(
            fontSize: 11,
            color: Theme.of(context).colorScheme.onSurfaceVariant,
          ),
        ),
        const Divider(height: 24),
        const _FieldLabel(
          'Telegram bot token (optional)',
          hint: '123456:ABC-DEF…',
          settingKey: 'telegram_bot_token',
        ),
        const SizedBox(height: 10),
        const _FieldLabel(
          'Telegram chat id (optional)',
          hint: '123456789',
          settingKey: 'telegram_chat_id',
        ),
        const SizedBox(height: 8),
        Text(
          'Bhar diya to study screen ke export menu me "Telegram pe bhejo" '
          'XLSX file seedha is chat me bhej dega. Bot @BotFather se banao, '
          'phir us bot ko ek baar /start bhejo.',
          style: TextStyle(
            fontSize: 11,
            color: Theme.of(context).colorScheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }
}

/// Where the study may take implied volatility from (B1).
///
/// A full F&O scan asks the broker for greeks once per stock — about 213
/// requests, and the slowest part of the scan. This is the switch that turns
/// that off without losing IV: the premium is already on the phone, so the
/// same Black-Scholes solver the app already uses as a fallback can do the
/// whole job.
class _IvSourcePicker extends StatelessWidget {
  const _IvSourcePicker();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final settings = context.watch<SettingsProvider>();
    final current = StudyIvSource.fromName(settings.settings.studyIvSource);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'IV kahan se mile',
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 4),
        Text(
          'Broker ka greek endpoint har stock ke liye ek alag request hai '
          '(~213 ek scan me). Apne hisaab se solve karne me wahi kaam zero '
          'request me ho jata hai.',
          style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
        ),
        const SizedBox(height: 10),
        for (final source in StudyIvSource.values)
          RadioListTile<String>(
            contentPadding: EdgeInsets.zero,
            dense: true,
            value: source.name,
            groupValue: current.name,
            onChanged: (value) => settings.setStudyIvSource(value ?? 'auto'),
            title: Text(source.label, style: const TextStyle(fontSize: 12.5)),
            subtitle: Text(
              source.hint,
              style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
            ),
          ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// F&O — AI Suggestion filters
// ---------------------------------------------------------------------------

/// The thresholds the AI Suggestion list obeys. Editing them here or on the
/// screen writes the same Settings row, so the very next scan follows.
class _AiSuggestionCard extends StatelessWidget {
  const _AiSuggestionCard();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final settings = context.watch<SettingsProvider>();
    final f = settings.aiFilters;

    return _Section(
      title: 'F&O — AI Suggestion',
      icon: Icons.auto_awesome,
      children: [
        Text(
          'Ye koi online AI nahi hai — phone me maujood candles par fixed niyam '
          'chalte hain. Same data + same filter = hamesha same list. Niche ke '
          'sabhi filter aapke hain: badlo to agli list badlegi.',
          style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
        ),
        const Divider(height: 20),
        _AiFilterLine(
          label: 'Min 3-month study score',
          value: f.minStudyScore.toStringAsFixed(1),
        ),
        _AiFilterLine(
          label: 'Min momentum score',
          value: f.minScore.toStringAsFixed(0),
        ),
        _AiFilterLine(
          label: 'RSI oversold / overbought',
          value:
              '${f.rsiOversold.toStringAsFixed(0)} / ${f.rsiOverbought.toStringAsFixed(0)}',
        ),
        _AiFilterLine(
          label: 'Volume spike',
          value: '${f.volumeSpike.toStringAsFixed(1)}x',
        ),
        _AiFilterLine(
          label: '52w high se doori',
          value: '${f.nearHighPct.toStringAsFixed(0)}%',
        ),
        _AiFilterLine(
          label: 'Min turnover (₹ crore/day)',
          value: f.minTurnoverCrore.toStringAsFixed(0),
        ),
        _AiFilterLine(
          label: 'Result ki chhutti (din)',
          value: '${f.eventBlockDays}',
        ),
        _AiFilterLine(
          label: 'Ek trade me capital ka jokhim',
          value: '${f.riskPct.toStringAsFixed(1)}%',
        ),
        _AiFilterLine(
          label: 'Kharidne ke liye kam se kam DTE',
          value: '${f.buyMinDte} din',
        ),
        _AiFilterLine(
          label: 'Bechne ke liye zyada se zyada DTE',
          value: '${f.sellMaxDte} din',
        ),
        _AiFilterLine(label: 'List me kitne stocks', value: '${f.topN}'),
        const SizedBox(height: 12),
        Row(
          children: [
            OutlinedButton.icon(
              onPressed: () => showAiFilterSheet(context),
              icon: const Icon(Icons.tune, size: 17),
              label: const Text('Filter badlo'),
            ),
            const SizedBox(width: 8),
            TextButton(
              onPressed: () =>
                  context.read<SettingsProvider>().resetAiFilters(),
              child: const Text('Default karo'),
            ),
          ],
        ),
      ],
    );
  }
}

class _AiFilterLine extends StatelessWidget {
  const _AiFilterLine({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant),
            ),
          ),
          Text(
            value,
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
          ),
        ],
      ),
    );
  }
}

/// A one-line text setting edited in place (used for the Telegram credentials).
class _FieldLabel extends StatefulWidget {
  const _FieldLabel(this.label, {required this.hint, required this.settingKey});

  final String label;
  final String hint;
  final String settingKey;

  @override
  State<_FieldLabel> createState() => _FieldLabelState();
}

class _FieldLabelState extends State<_FieldLabel> {
  late final TextEditingController _controller = TextEditingController(
    text: _current(context),
  );

  String _current(BuildContext context) {
    final settings = context.read<SettingsProvider>().settings;
    return widget.settingKey == 'telegram_bot_token'
        ? settings.telegramBotToken
        : settings.telegramChatId;
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: _controller,
      style: const TextStyle(fontSize: 13),
      decoration: InputDecoration(
        labelText: widget.label,
        hintText: widget.hint,
        isDense: true,
        border: const OutlineInputBorder(),
      ),
      onSubmitted: (raw) {
        final settings = context.read<SettingsProvider>();
        final value = settings.settings;
        settings.setTelegramCredentials(
          botToken: widget.settingKey == 'telegram_bot_token'
              ? raw
              : value.telegramBotToken,
          chatId: widget.settingKey == 'telegram_chat_id'
              ? raw
              : value.telegramChatId,
        );
      },
    );
  }
}

class _DataCard extends StatelessWidget {
  const _DataCard();

  @override
  Widget build(BuildContext context) {
    final cache = context.read<ScanCacheDao>();
    final database = context.read<AppDatabase>();
    final scheme = Theme.of(context).colorScheme;

    return _Section(
      title: 'Local data',
      icon: Icons.folder_outlined,
      children: [
        SelectableText(
          database.path ?? '—',
          style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: 10,
          runSpacing: 8,
          children: [
            OutlinedButton.icon(
              onPressed: () async {
                await cache.clearPrices();
                if (!context.mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Cached prices cleared.')),
                );
              },
              icon: const Icon(Icons.cleaning_services_outlined, size: 18),
              label: const Text('Clear price cache'),
            ),
            OutlinedButton.icon(
              onPressed: () async {
                await Clipboard.setData(
                  ClipboardData(text: database.path ?? ''),
                );
                if (!context.mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Database path copied.')),
                );
              },
              icon: const Icon(Icons.copy_all_outlined, size: 18),
              label: const Text('Copy DB path'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          'Everything is stored on this device only: the IPO database, the '
          'instrument cache, last known prices, scanner output and (from '
          'Phase 3) the paper trade book.',
          style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Storage — what the app actually costs on the phone
// ---------------------------------------------------------------------------

/// Rows + bytes, as measured from the live database.
class _StorageStats {
  final int bytes;
  final int scrips;
  final int contracts;
  final int candles;

  const _StorageStats({
    required this.bytes,
    required this.scrips,
    required this.contracts,
    required this.candles,
  });
}

/// The honest answer to "ye app kitni jagah leti hai?".
///
/// The broker's 34 MB master is **never** written to disk: it is streamed,
/// filtered and only ~40k useful rows reach SQLite (equities + the near
/// expiries of every F&O underlying). This card shows that real number and
/// offers one button that reclaims whatever a rewrite left behind.
class _StorageCard extends StatefulWidget {
  const _StorageCard();

  @override
  State<_StorageCard> createState() => _StorageCardState();
}

class _StorageCardState extends State<_StorageCard> {
  late Future<_StorageStats> _stats;
  bool _busy = false;
  String? _result;

  @override
  void initState() {
    super.initState();
    _stats = _load();
  }

  Future<_StorageStats> _load() async {
    final db = context.read<AppDatabase>();
    final scrips = context.read<ScripDao>();
    final contracts = context.read<FnoContractDao>();
    final candles = context.read<CandleDao>();
    return _StorageStats(
      bytes: await db.sizeBytes(),
      scrips: await scrips.count(),
      contracts: await contracts.count(),
      candles: await candles.count(),
    );
  }

  Future<void> _compact() async {
    final contracts = context.read<FnoContractDao>();
    final db = context.read<AppDatabase>();
    setState(() {
      _busy = true;
      _result = null;
    });
    try {
      final expired = await contracts.pruneExpired();
      final freed = await db.vacuum();
      if (!mounted) return;
      setState(() {
        _result =
            '${_size(freed)} free kar diya'
            '${expired > 0 ? ' · $expired expired contracts hata diye' : ''}';
        _stats = _load();
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _result = 'Compact fail hua: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  static String _size(int bytes) {
    if (bytes >= 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    if (bytes >= 1024) return '${(bytes / 1024).round()} KB';
    return '$bytes B';
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return _Section(
      title: 'Storage',
      icon: Icons.storage_outlined,
      children: [
        FutureBuilder<_StorageStats>(
          future: _stats,
          builder: (context, snapshot) {
            final stats = snapshot.data;
            if (stats == null) {
              return Text(
                'Measuring…',
                style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant),
              );
            }
            final rows = <(String, String)>[
              ('App data (database)', _size(stats.bytes)),
              ('Scrips (NSE + BSE equities)', '${stats.scrips}'),
              ('Option contracts (near expiries)', '${stats.contracts}'),
              ('Daily candles (cache)', '${stats.candles}'),
            ];
            return Column(
              children: [
                for (final (label, value) in rows)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 3),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            label,
                            style: const TextStyle(fontSize: 12),
                          ),
                        ),
                        Text(
                          value,
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            fontFeatures: const [FontFeature.tabularFigures()],
                            color: scheme.onSurface,
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            );
          },
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            OutlinedButton.icon(
              onPressed: _busy ? null : _compact,
              icon: _busy
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.compress_outlined, size: 18),
              label: const Text('Compact karo'),
            ),
            if (_result != null) ...[
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  _result!,
                  style: TextStyle(fontSize: 11, color: scheme.primary),
                ),
              ),
            ],
          ],
        ),
        const SizedBox(height: 8),
        Text(
          'Broker ka master file (34 MB) device par save nahi hota — app usse '
          'seedha stream karke sirf kaam ki rows rakhti hai. Compact purane '
          'expiry aur khaali pages hata deta hai.',
          style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// About / disclaimer
// ---------------------------------------------------------------------------

class _AboutCard extends StatelessWidget {
  const _AboutCard();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return _Section(
      title: 'About',
      icon: Icons.info_outline,
      children: [
        const Center(
          child: BrandLogo(
            markSize: 46,
            axis: Axis.vertical,
            showTagline: true,
          ),
        ),
        const SizedBox(height: 16),
        const _Row('Version', '', valueWidget: AppVersionLabel()),
        const _Row('Package', 'com.angeltrader.angel_trader'),
        const _Row('Market data', 'Angel One SmartAPI (read-only)'),
        const SizedBox(height: 6),
        Text(
          'Market data by Angel One SmartAPI (read-only). Trades are simulated: '
          'this app never places a real order. Analysis here is not investment '
          'advice — verify every level before acting.',
          style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant),
        ),
        const SizedBox(height: 12),
        TextButton.icon(
          onPressed: () => LinkOpener.open(
            'https://smartapi.angelbroking.com/docs',
            context: context,
          ),
          icon: const Icon(Icons.open_in_new, size: 16),
          label: const Text('SmartAPI documentation'),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Paper trading (Feature 3)
// ---------------------------------------------------------------------------

class _PaperTradingCard extends StatelessWidget {
  const _PaperTradingCard();

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();
    final paper = context.watch<PaperTradingProvider>();
    final scheme = Theme.of(context).colorScheme;
    final value = settings.settings;

    return _Section(
      title: 'Paper trading',
      icon: Icons.account_balance_wallet_outlined,
      children: [
        _Row('Virtual capital', Fmt.money(paper.startingCapital)),
        _Row('Cash available', Fmt.money(paper.snapshot.availableCash)),
        _Row('Open positions', '${paper.allHoldings.length}'),
        const SizedBox(height: 6),
        Wrap(
          spacing: 8,
          children: [
            for (final amount in const [100000.0, 500000.0, 1000000.0])
              ChoiceChip(
                label: Text(Fmt.moneyCompact(amount)),
                selected: (paper.startingCapital - amount).abs() < 1,
                onSelected: (_) => settings.setStartingCapital(amount),
              ),
          ],
        ),
        Text(
          'Used for sizing checks and the portfolio-value tile. Changing it '
          're-bases the maths; it never alters trades that already exist.',
          style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
        ),
        const Divider(height: 24),

        // ---- costs
        Row(
          children: [
            const Expanded(child: Text('Charge mode')),
            SegmentedButton<ChargesMode>(
              showSelectedIcon: false,
              segments: const [
                ButtonSegment(
                  value: ChargesMode.delivery,
                  label: Text('Delivery'),
                ),
                ButtonSegment(
                  value: ChargesMode.intraday,
                  label: Text('Intraday'),
                ),
              ],
              selected: {paper.chargesMode},
              onSelectionChanged: (set) =>
                  settings.setChargesMode(set.first.name),
            ),
          ],
        ),
        Text(
          'Determines brokerage, STT and stamp duty on every simulated fill.',
          style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          value: value.includeDpCharges,
          onChanged: settings.setIncludeDpCharges,
          title: const Text('Include DP charges'),
          subtitle: const Text(
            'Depository fee (about ₹13.50 + GST) on delivery sells',
            style: TextStyle(fontSize: 11),
          ),
        ),
        const Divider(height: 24),

        // ---- live monitoring
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          value: value.liveFeedEnabled,
          onChanged: settings.setLiveFeedEnabled,
          title: const Text('Live WebSocket LTP feed'),
          subtitle: const Text(
            'Tick-by-tick prices and stop-loss auto-exit; REST polling is used '
            'when this is off',
            style: TextStyle(fontSize: 11),
          ),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          value: value.autoExitOnTarget,
          onChanged: settings.setAutoExitOnTarget,
          title: const Text('Auto-exit on target'),
          subtitle: const Text(
            'Off by default: a target is shown, you decide when to book it',
            style: TextStyle(fontSize: 11),
          ),
        ),
        const Divider(height: 24),

        // ---- groups
        Row(
          children: [
            const Expanded(child: Text('Trade groups')),
            Text(
              '${paper.groups.length} active',
              style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            OutlinedButton.icon(
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => const GroupManagerScreen(),
                ),
              ),
              icon: const Icon(Icons.sell_outlined, size: 18),
              label: const Text('Manage groups'),
            ),
            OutlinedButton.icon(
              onPressed: () => _confirmReset(context, paper),
              icon: const Icon(Icons.restart_alt_rounded, size: 18),
              label: const Text('Reset account'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          'Paper trading is a simulation: orders are matched inside this app '
          'against the live LTP (or your limit price) and never reach Angel One.',
          style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
        ),
      ],
    );
  }

  Future<void> _confirmReset(
    BuildContext context,
    PaperTradingProvider paper,
  ) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Reset the paper account?'),
        content: const Text(
          'Every simulated trade, position and order is deleted and the virtual '
          'capital is restored. Groups are kept.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Reset'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    await paper.resetAccount();
    if (!context.mounted) return;
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('Paper account reset.')));
  }
}

// ---------------------------------------------------------------------------
// Shared chrome
// ---------------------------------------------------------------------------

class _Section extends StatelessWidget {
  const _Section({
    required this.title,
    required this.icon,
    required this.children,
  });

  final String title;
  final IconData icon;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, size: 18),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 14,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ...children,
          ],
        ),
      ),
    );
  }
}

class _Row extends StatelessWidget {
  const _Row(this.label, this.value, {this.valueWidget});

  final String label;
  final String value;
  final Widget? valueWidget;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Text(
              label,
              style: TextStyle(fontSize: 12.5, color: scheme.onSurfaceVariant),
            ),
          ),
          Flexible(
            child:
                valueWidget ??
                Text(
                  value,
                  textAlign: TextAlign.end,
                  style: const TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
          ),
        ],
      ),
    );
  }
}
