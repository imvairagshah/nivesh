import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';

import '../../data/local/dao/magic_formula_dao.dart';
import '../../data/local/dao/settings_dao.dart';
import '../../services/magic_formula_data_source.dart';
import 'magic_formula_engine.dart';
import 'magic_formula_models.dart';

enum MagicFormulaPhase { idle, loadingCache, scanning, ready, error }

enum MagicFormulaSortKey {
  rank,
  symbol,
  roce,
  earningsYield,
  roceRank,
  earningsYieldRank,
  score,
  marketCap,
  enterpriseValue,
}

/// Coordinates a user-started NSE scan and the local one-hour fundamentals
/// cache. Opening the page is deliberately offline-only; network work begins
/// only when the user taps Scan.
class MagicFormulaProvider extends ChangeNotifier {
  MagicFormulaProvider({
    required MagicFormulaDao dao,
    required MagicFormulaDataSource dataSource,
    required SettingsDao settings,
    DateTime Function()? clock,
  }) : _dao = dao,
       _dataSource = dataSource,
       _settings = settings,
       _clock = clock ?? DateTime.now;

  static const String _lastScanMetaKey = 'magic_formula_last_scan_v1';
  static const String fundamentalsCacheVersionMetaKey =
      'magic_formula_fundamentals_cache_version';
  static const String fundamentalsCacheVersion =
      'nse-udiff-xbrl-context-v9';
  static const int _pageSize = 10;

  final MagicFormulaDao _dao;
  final MagicFormulaDataSource _dataSource;
  final SettingsDao _settings;
  final DateTime Function() _clock;

  MagicFormulaPhase _phase = MagicFormulaPhase.idle;
  MagicFormulaUniverse _universe = MagicFormulaUniverse.all;
  Set<String> _selectedSectors = Set<String>.from(MagicFormulaSectors.all);
  int _topN = 20;
  int _page = 0;
  MagicFormulaSortKey _sortKey = MagicFormulaSortKey.rank;
  bool _ascending = true;
  String? _expandedKey;
  String? _error;
  String _stage = '';
  String _currentStock = '';
  int _completed = 0;
  int _total = 0;
  bool _cancelRequested = false;
  bool _scanWasCancelled = false;
  bool _initialized = false;
  bool _disposed = false;
  DateTime? _lastScanAt;
  String? _lastScanUniverseKey;
  List<MagicFormulaFundamental> _scanRows = const [];
  MagicFormulaRanking _ranking = const MagicFormulaRanking(
    ranked: [],
    skipped: [],
  );

  MagicFormulaPhase get phase => _phase;
  MagicFormulaUniverse get universe => _universe;
  Set<String> get selectedSectors => Set.unmodifiable(_selectedSectors);
  int get topN => _topN;
  int get currentPage => _page;
  int get pageSize => _pageSize;
  MagicFormulaSortKey get sortKey => _sortKey;
  bool get ascending => _ascending;
  String? get expandedKey => _expandedKey;
  String? get error => _error;
  bool get isScanning => _phase == MagicFormulaPhase.scanning;
  bool get isLoadingCache => _phase == MagicFormulaPhase.loadingCache;
  bool get hasCache => _scanRows.isNotEmpty;
  bool get isPartialScan => _scanWasCancelled;
  DateTime? get lastScanAt => _lastScanAt;
  String? get lastScanUniverseKey => _lastScanUniverseKey;
  bool get cacheScopeDiffers =>
      _lastScanUniverseKey != null && _lastScanUniverseKey != _universe.key;
  bool get hasError => _error != null && _error!.isNotEmpty;

  MagicFormulaProgress get progress => MagicFormulaProgress(
    completed: _completed,
    total: _total,
    stockLabel: _currentStock,
    stage: _stage,
  );

  MagicFormulaRanking get ranking => _ranking;
  List<MagicFormulaRankedStock> get allRankedRows => _ranking.ranked;
  List<MagicFormulaSkippedStock> get skippedRows => _ranking.skipped;
  int get scannedCount => _ranking.scannedCount;
  int get eligibleCount => _ranking.ranked.length;
  int get skippedCount => _ranking.skipped.length;
  double? get medianRocePct => _ranking.medianRocePct;
  double? get medianEarningsYieldPct => _ranking.medianEarningsYieldPct;
  String? get topSector => _ranking.topSector(topN: _topN);

  List<MagicFormulaRankedStock> get displayedRows {
    final rows = [..._ranking.ranked]..sort(_compareRanked);
    final topRows = rows.take(_topN).toList(growable: false);
    final start = _page * _pageSize;
    if (start >= topRows.length) return const [];
    return topRows.skip(start).take(_pageSize).toList(growable: false);
  }

  int get pageCount {
    final count = _ranking.ranked.length < _topN
        ? _ranking.ranked.length
        : _topN;
    return count == 0 ? 1 : (count / _pageSize).ceil();
  }

  int get displayRankedCount =>
      _ranking.ranked.length < _topN ? _ranking.ranked.length : _topN;

  /// Reads the prior scan from SQLite and its local metadata only. No request
  /// is made while this page is opened, including when the device is offline.
  Future<void> bootstrap() async {
    if (_initialized || _phase == MagicFormulaPhase.loadingCache) return;
    _phase = MagicFormulaPhase.loadingCache;
    _error = null;
    _notify();
    try {
      final storedCacheVersion = await _settings.meta(
        fundamentalsCacheVersionMetaKey,
      );
      if (storedCacheVersion != fundamentalsCacheVersion) {
        // Older app builds either depended on fixed `OneI`/`OneD` IDs, read
        // balance-sheet facts from only one same-date context, or skipped
        // Q1/Q3 rows because the quarter filing carries no balance sheet.
        // Drop this module's incompatible cache so the next explicit scan
        // reparses NSE filings and applies the half-yearly balance-sheet
        // fallback.
        await _dao.clear();
        await _settings.putMeta(
          fundamentalsCacheVersionMetaKey,
          fundamentalsCacheVersion,
        );
        await _settings.putMeta(_lastScanMetaKey, '');
      }
      final cache = await _dao.all();
      final rawMeta = await _settings.meta(_lastScanMetaKey);
      final metadata = _decodeMeta(rawMeta);
      if (metadata != null) {
        _lastScanUniverseKey = '${metadata['universe'] ?? ''}'.trim();
        if (_lastScanUniverseKey!.isEmpty) _lastScanUniverseKey = null;
        _universe = MagicFormulaUniverse.fromKey(_lastScanUniverseKey);
        _lastScanAt = DateTime.tryParse('${metadata['scannedAt'] ?? ''}');
        _scanWasCancelled = metadata['cancelled'] == true;
        final savedSectors = metadata['sectors'];
        if (savedSectors is List) {
          final known = savedSectors.map((value) => '$value').toSet();
          _selectedSectors = known.intersection(
            MagicFormulaSectors.all.toSet(),
          );
        }
        final keys = metadata['keys'];
        if (keys is List) {
          _scanRows = keys
              .map((key) => cache['$key'])
              .whereType<MagicFormulaFundamental>()
              .where((row) => !row.isTransientHttpFailure)
              .toList(growable: false);
        } else {
          _scanRows = cache.values
              .where((row) => !row.isTransientHttpFailure)
              .toList(growable: false);
        }
      } else {
        _scanRows = cache.values
            .where((row) => !row.isTransientHttpFailure)
            .toList(growable: false);
      }
      _rebuildRanking();
      _initialized = true;
      _phase = _scanRows.isEmpty
          ? MagicFormulaPhase.idle
          : MagicFormulaPhase.ready;
    } catch (error) {
      _error = 'Local Magic Formula cache nahi khul saka: $error';
      _phase = MagicFormulaPhase.error;
    }
    _notify();
  }

  void setUniverse(MagicFormulaUniverse value) {
    if (isScanning || _universe == value) return;
    _universe = value;
    _page = 0;
    _expandedKey = null;
    _rebuildRanking();
    _notify();
  }

  void setTopN(int value) {
    final next = value.clamp(5, 100).toInt();
    if (_topN == next) return;
    _topN = next;
    _page = 0;
    _expandedKey = null;
    _notify();
  }

  void toggleSector(String sector) {
    if (!MagicFormulaSectors.all.contains(sector)) return;
    if (_selectedSectors.contains(sector)) {
      _selectedSectors.remove(sector);
    } else {
      _selectedSectors.add(sector);
    }
    _page = 0;
    _expandedKey = null;
    _rebuildRanking();
    _notify();
  }

  void selectAllSectors() {
    _selectedSectors = Set<String>.from(MagicFormulaSectors.all);
    _page = 0;
    _rebuildRanking();
    _notify();
  }

  void clearSectors() {
    _selectedSectors.clear();
    _page = 0;
    _rebuildRanking();
    _notify();
  }

  void sortBy(MagicFormulaSortKey key) {
    if (_sortKey == key) {
      _ascending = !_ascending;
    } else {
      _sortKey = key;
      _ascending = switch (key) {
        MagicFormulaSortKey.rank ||
        MagicFormulaSortKey.roceRank ||
        MagicFormulaSortKey.earningsYieldRank ||
        MagicFormulaSortKey.score ||
        MagicFormulaSortKey.symbol => true,
        _ => false,
      };
    }
    _page = 0;
    _notify();
  }

  void goToPage(int page) {
    final next = page.clamp(0, pageCount - 1).toInt();
    if (_page == next) return;
    _page = next;
    _expandedKey = null;
    _notify();
  }

  void toggleExpanded(String securityKey) {
    _expandedKey = _expandedKey == securityKey ? null : securityKey;
    _notify();
  }

  /// Performs a complete scan of the selected universe. Rows younger than one
  /// hour come from SQLite unless [force] is true. A stop request is honored
  /// after the in-flight stock completes; partial results are labeled as such.
  Future<void> scan({bool force = false}) async {
    if (isScanning || _disposed) return;
    if (_universe == MagicFormulaUniverse.sectorWise &&
        _selectedSectors.isEmpty) {
      _error = 'Sector-wise scan ke liye kam se kam ek sector select karein.';
      _notify();
      return;
    }

    _phase = MagicFormulaPhase.scanning;
    _error = null;
    _cancelRequested = false;
    _scanWasCancelled = false;
    _completed = 0;
    _total = 0;
    _stage = 'Official constituent list load ho rahi hai';
    _currentStock = '';
    _notify();

    try {
      final candidates = await _dataSource.loadCandidates(_universe);
      if (_disposed) return;
      await _scanAll(candidates, force: force, universeKey: _universe.key);
    } catch (error) {
      _error = '$error';
      _phase = _scanRows.isEmpty
          ? MagicFormulaPhase.error
          : MagicFormulaPhase.ready;
    }
    _notify();
  }

  /// Basket mode: scans an explicit member list through the exact same
  /// official-data pipeline, cache, and ranking as [scan].
  Future<void> scanMembers(
    List<MagicFormulaCandidate> members, {
    required String label,
    bool force = false,
  }) async {
    if (isScanning || _disposed) return;
    if (members.isEmpty) {
      _error = 'Is basket me koi stock nahi hai — pehle stocks add karein.';
      _notify();
      return;
    }

    _phase = MagicFormulaPhase.scanning;
    _error = null;
    _cancelRequested = false;
    _scanWasCancelled = false;
    _completed = 0;
    _total = 0;
    _stage = 'Official EOD close aur filings load ho rahi hain';
    _currentStock = '';
    _notify();

    try {
      await _scanAll(members, force: force, universeKey: 'basket:$label');
    } catch (error) {
      _error = '$error';
      _phase = _scanRows.isEmpty
          ? MagicFormulaPhase.error
          : MagicFormulaPhase.ready;
    }
    _notify();
  }

  Future<void> _scanAll(
    List<MagicFormulaCandidate> candidates, {
    required bool force,
    required String universeKey,
  }) async {
    _total = candidates.length;
    if (candidates.isEmpty) {
      _scanRows = const [];
      _lastScanUniverseKey = universeKey;
      _lastScanAt = _clock();
      _error = 'Is list me koi listed cash equity nahi mili.';
      _phase = MagicFormulaPhase.ready;
      _rebuildRanking();
      await _saveLastScanMetadata(const [], cancelled: false);
      _notify();
      return;
    }

      final cached = await _dao.all();
      final scannedByKey = <String, MagicFormulaFundamental>{};
      final pendingWrites = <MagicFormulaFundamental>[];
      for (var index = 0; index < candidates.length; index++) {
        if (_cancelRequested || _disposed) break;
        final candidate = candidates[index];
        _currentStock = candidate.displayTicker;
        _stage = 'Financials aur official EOD close check ho rahe hain';
        final previous = _findCached(candidate, cached);
        MagicFormulaFundamental row;
        if (!force && previous != null && previous.isFresh(now: _clock())) {
          final merged = _mergeCandidate(candidate, previous.candidate);
          row = previous.withCandidate(merged);
          _stage = '1-hour local cache';
        } else {
          try {
            row = await _dataSource.fetchFundamentals(
              candidate,
              onStage: (stage) => _stage = stage,
            );
          } on MagicFormulaScanAbortException catch (error) {
            _stopScanForSource(error.message);
            break;
          } on NseMagicFormulaHttpException catch (error) {
            if (error.shouldStopScan) {
              _stopScanForSource(error.userMessage);
              break;
            }
            row = MagicFormulaFundamental(
              candidate: candidate,
              fetchedAt: _clock(),
              source: 'NSE public feed',
              missingReason: 'Data fetch fail: $error',
            );
          } catch (error) {
            row = MagicFormulaFundamental(
              candidate: candidate,
              fetchedAt: _clock(),
              source: 'NSE public feed',
              missingReason: 'Data fetch fail: $error',
            );
          }
        }
        final key = row.candidate.cacheKey;
        scannedByKey[key] = row;
        cached[key] = row;
        pendingWrites.add(row);
        if (pendingWrites.length >= 100) {
          await _dao.saveAll(pendingWrites);
          pendingWrites.clear();
        }
        _completed = index + 1;
        _progressNotify(index, candidates.length);
      }
      if (pendingWrites.isNotEmpty) await _dao.saveAll(pendingWrites);
      if (_disposed) return;

      _scanRows = scannedByKey.values.toList(growable: false);
      _lastScanUniverseKey = universeKey;
      _lastScanAt = _clock();
      _scanWasCancelled = _cancelRequested;
      _phase = MagicFormulaPhase.ready;
      _page = 0;
      _expandedKey = null;
      _rebuildRanking();
      await _saveLastScanMetadata(
        _scanRows.map((row) => row.candidate.cacheKey).toList(growable: false),
        cancelled: _scanWasCancelled,
      );
  }

  void cancelScan() {
    if (!isScanning) return;
    _cancelRequested = true;
    _stage = 'Current stock poora hote hi scan ruk jayega';
    _notify();
  }

  void clearError() {
    if (_error == null) return;
    _error = null;
    _notify();
  }

  MagicFormulaFundamental? cachedFor(MagicFormulaCandidate candidate) =>
      _findCached(candidate, {
        for (final row in _scanRows) row.candidate.cacheKey: row,
      });

  void _progressNotify(int index, int total) {
    if (index % 5 == 0 || index + 1 == total || _cancelRequested) _notify();
  }

  void _stopScanForSource(String message) {
    _cancelRequested = true;
    _error =
        '$message Scan $_completed/$_total par rok diya; failed rows cache nahi ki. Baar-baar turant retry na karein.';
    _stage = 'NSE public feed unavailable; scan stopped';
  }

  Map<String, dynamic>? _decodeMeta(String? raw) {
    if (raw == null || raw.isEmpty) return null;
    try {
      final value = jsonDecode(raw);
      return value is Map<String, dynamic> ? value : null;
    } catch (_) {
      return null;
    }
  }

  Future<void> _saveLastScanMetadata(
    List<String> keys, {
    required bool cancelled,
  }) async {
    final metadata = <String, Object?>{
      'universe': _universe.key,
      'scannedAt': _lastScanAt?.toIso8601String(),
      'cancelled': cancelled,
      'sectors': _selectedSectors.toList()..sort(),
      'keys': keys,
    };
    await _settings.putMeta(_lastScanMetaKey, jsonEncode(metadata));
  }

  void _rebuildRanking() {
    Iterable<MagicFormulaFundamental> rows = _scanRows;
    if (_universe == MagicFormulaUniverse.sectorWise) {
      rows = rows.where((row) => _selectedSectors.contains(_sectorLabel(row)));
    }
    _ranking = MagicFormulaEngine.rank(rows);
    if (_page >= pageCount) _page = pageCount - 1;
  }

  String _sectorLabel(MagicFormulaFundamental row) =>
      row.candidate.sector.trim().isEmpty
      ? 'Other / Unclassified'
      : row.candidate.sector.trim();

  MagicFormulaFundamental? _findCached(
    MagicFormulaCandidate candidate,
    Map<String, MagicFormulaFundamental> cached,
  ) {
    final exact = cached[candidate.cacheKey];
    if (exact != null) return exact;
    final matches = cached.values
        .where((row) {
          final prior = row.candidate;
          return prior.symbol.toUpperCase() == candidate.symbol.toUpperCase() &&
              prior.dataSymbol.toUpperCase() ==
                  candidate.dataSymbol.toUpperCase() &&
              (prior.exchange == candidate.exchange ||
                  prior.exchange == 'NSE/BSE' ||
                  candidate.exchange == 'NSE/BSE');
        })
        .toList(growable: false);
    return matches.length == 1 ? matches.single : null;
  }

  MagicFormulaCandidate _mergeCandidate(
    MagicFormulaCandidate current,
    MagicFormulaCandidate cached,
  ) => MagicFormulaCandidate(
    symbol: current.symbol,
    companyName: current.companyName.isNotEmpty
        ? current.companyName
        : cached.companyName,
    exchange: current.exchange,
    sector: current.sector.isNotEmpty ? current.sector : cached.sector,
    industry: current.industry.isNotEmpty ? current.industry : cached.industry,
    isin: current.isin.isNotEmpty ? current.isin : cached.isin,
    dataSymbol: current.dataSymbol.isNotEmpty
        ? current.dataSymbol
        : cached.dataSymbol,
    dataCompanyName: current.dataCompanyName.isNotEmpty
        ? current.dataCompanyName
        : cached.dataCompanyName,
  );

  int _compareRanked(MagicFormulaRankedStock a, MagicFormulaRankedStock b) {
    int compared = switch (_sortKey) {
      MagicFormulaSortKey.rank => a.rank.compareTo(b.rank),
      MagicFormulaSortKey.symbol => a.candidate.symbol.toUpperCase().compareTo(
        b.candidate.symbol.toUpperCase(),
      ),
      MagicFormulaSortKey.roce => a.rocePct.compareTo(b.rocePct),
      MagicFormulaSortKey.earningsYield => a.earningsYieldPct.compareTo(
        b.earningsYieldPct,
      ),
      MagicFormulaSortKey.roceRank => a.roceRank.compareTo(b.roceRank),
      MagicFormulaSortKey.earningsYieldRank => a.earningsYieldRank.compareTo(
        b.earningsYieldRank,
      ),
      MagicFormulaSortKey.score => a.score.compareTo(b.score),
      MagicFormulaSortKey.marketCap => a.marketCapCr.compareTo(b.marketCapCr),
      MagicFormulaSortKey.enterpriseValue => a.enterpriseValueCr.compareTo(
        b.enterpriseValueCr,
      ),
    };
    if (!_ascending) compared = -compared;
    if (compared != 0) return compared;
    return a.rank.compareTo(b.rank);
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }
}
