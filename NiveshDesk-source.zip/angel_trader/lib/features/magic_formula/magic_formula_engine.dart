import 'magic_formula_models.dart';

/// Pure Magic Formula calculations. No network, storage, or Flutter widgets.
class MagicFormulaEngine {
  const MagicFormulaEngine._();

  /// Calculates the requested ratios from ₹ crore values.
  ///
  /// ROCE = EBIT TTM / (Total Assets − Current Liabilities)
  /// EY   = EBIT TTM / (Market Cap + Total Debt − Cash)
  ///
  /// Percent values are returned as percentages (multiply by 100). A zero
  /// denominator is invalid; negative denominators are retained because the
  /// selected specification asks for the raw formula, including financials.
  static ({double rocePct, double earningsYieldPct})? metrics(
    MagicFormulaFundamental row,
  ) {
    final ebit = row.ebitTtmCr;
    final assets = row.totalAssetsCr;
    final currentLiabilities = row.currentLiabilitiesCr;
    final marketCap = row.marketCapCr;
    final debt = row.totalDebtCr;
    final cash = row.cashCr;

    if (ebit == null ||
        assets == null ||
        currentLiabilities == null ||
        marketCap == null ||
        debt == null ||
        cash == null ||
        ![
          ebit,
          assets,
          currentLiabilities,
          marketCap,
          debt,
          cash,
        ].every((value) => value.isFinite)) {
      return null;
    }

    final capital = assets - currentLiabilities;
    final enterpriseValue = marketCap + debt - cash;
    if (capital == 0 || enterpriseValue == 0) return null;

    final roce = ebit / capital * 100;
    final earningsYield = ebit / enterpriseValue * 100;
    if (!roce.isFinite || !earningsYield.isFinite) return null;
    return (rocePct: roce, earningsYieldPct: earningsYield);
  }

  /// Independently ranks eligible stocks on ROCE and Earnings Yield, then adds
  /// the ranks. Equal values share a competition rank (1, 2, 2, 4); final ties
  /// are stable by ticker and exchange.
  static MagicFormulaRanking rank(Iterable<MagicFormulaFundamental> input) {
    final eligible =
        <({MagicFormulaFundamental row, double roce, double ey})>[];
    final skipped = <MagicFormulaSkippedStock>[];

    for (final row in input) {
      final reason = _missingOrInvalidReason(row);
      if (reason != null) {
        skipped.add(MagicFormulaSkippedStock(fundamental: row, reason: reason));
        continue;
      }
      final values = metrics(row)!;
      eligible.add((
        row: row,
        roce: values.rocePct,
        ey: values.earningsYieldPct,
      ));
    }

    final roceOrder = [...eligible]
      ..sort((a, b) {
        final byValue = b.roce.compareTo(a.roce);
        if (byValue != 0) return byValue;
        return _stableKey(a.row).compareTo(_stableKey(b.row));
      });
    final eyOrder = [...eligible]
      ..sort((a, b) {
        final byValue = b.ey.compareTo(a.ey);
        if (byValue != 0) return byValue;
        return _stableKey(a.row).compareTo(_stableKey(b.row));
      });

    final roceRanks = _competitionRanks(roceOrder, (item) => item.roce);
    final eyRanks = _competitionRanks(eyOrder, (item) => item.ey);
    final rankByKey = <String, ({int roce, int ey})>{};
    for (var index = 0; index < roceOrder.length; index++) {
      final key = _stableKey(roceOrder[index].row);
      rankByKey[key] = (roce: roceRanks[index], ey: 0);
    }
    for (var index = 0; index < eyOrder.length; index++) {
      final key = _stableKey(eyOrder[index].row);
      final prior = rankByKey[key]!;
      rankByKey[key] = (roce: prior.roce, ey: eyRanks[index]);
    }

    final ranked =
        <MagicFormulaRankedStock>[
          for (final item in eligible)
            MagicFormulaRankedStock(
              fundamental: item.row,
              rocePct: item.roce,
              earningsYieldPct: item.ey,
              roceRank: rankByKey[_stableKey(item.row)]!.roce,
              earningsYieldRank: rankByKey[_stableKey(item.row)]!.ey,
              score:
                  rankByKey[_stableKey(item.row)]!.roce +
                  rankByKey[_stableKey(item.row)]!.ey,
              rank: 0,
            ),
        ]..sort((a, b) {
          final byScore = a.score.compareTo(b.score);
          if (byScore != 0) return byScore;
          final bySymbol = a.candidate.symbol.compareTo(b.candidate.symbol);
          if (bySymbol != 0) return bySymbol;
          return a.candidate.exchange.compareTo(b.candidate.exchange);
        });

    final withFinalRank = <MagicFormulaRankedStock>[
      for (var index = 0; index < ranked.length; index++)
        MagicFormulaRankedStock(
          fundamental: ranked[index].fundamental,
          rocePct: ranked[index].rocePct,
          earningsYieldPct: ranked[index].earningsYieldPct,
          roceRank: ranked[index].roceRank,
          earningsYieldRank: ranked[index].earningsYieldRank,
          score: ranked[index].score,
          rank: index + 1,
        ),
    ];

    skipped.sort(
      (a, b) => _stableKey(a.fundamental).compareTo(_stableKey(b.fundamental)),
    );
    return MagicFormulaRanking(ranked: withFinalRank, skipped: skipped);
  }

  static String? _missingOrInvalidReason(MagicFormulaFundamental row) {
    if (row.missingReason.trim().isNotEmpty) return row.missingReason.trim();
    final names = <String>[];
    if (row.marketCapCr == null) names.add('Market Cap');
    if (row.ebitTtmCr == null) names.add('TTM EBIT');
    if (row.totalDebtCr == null) names.add('Total Debt');
    if (row.cashCr == null) names.add('Cash & Equivalents');
    if (row.totalAssetsCr == null) names.add('Total Assets');
    if (row.currentLiabilitiesCr == null) names.add('Current Liabilities');
    if (names.isNotEmpty) return 'Missing: ${names.join(', ')}';

    if (row.marketCapCr! <= 0) return 'Market Cap is not positive';
    final capital = row.totalAssetsCr! - row.currentLiabilitiesCr!;
    if (capital == 0) return 'Total Assets − Current Liabilities is zero';
    final ev = row.marketCapCr! + row.totalDebtCr! - row.cashCr!;
    if (ev == 0) return 'Enterprise Value is zero';

    final values = metrics(row);
    if (values == null) return 'ROCE or Earnings Yield is not finite';
    return null;
  }

  static List<int> _competitionRanks<T>(
    List<T> sorted,
    double Function(T) valueOf,
  ) {
    final ranks = <int>[];
    double? previous;
    for (var index = 0; index < sorted.length; index++) {
      final value = valueOf(sorted[index]);
      if (previous == null || value != previous) {
        ranks.add(index + 1);
        previous = value;
      } else {
        ranks.add(ranks.last);
      }
    }
    return ranks;
  }

  static String _stableKey(MagicFormulaFundamental row) =>
      '${row.candidate.symbol.toUpperCase()}|${row.candidate.exchange.toUpperCase()}';
}
