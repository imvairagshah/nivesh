import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

import 'magic_formula_models.dart';

class MagicFormulaExportService {
  Future<File> writeCsv({
    required List<MagicFormulaRankedStock> ranked,
    required List<MagicFormulaSkippedStock> skipped,
    required MagicFormulaUniverse universe,
    required DateTime scannedAt,
  }) async {
    final directory = await getApplicationDocumentsDirectory();
    final stamp = _dateStamp(scannedAt);
    final file = File('${directory.path}/NiveshDesk_Magic_Formula_$stamp.csv');
    await file.writeAsString(
      buildCsv(
        ranked: ranked,
        skipped: skipped,
        universe: universe,
        scannedAt: scannedAt,
      ),
      encoding: utf8,
      flush: true,
    );
    return file;
  }

  static String buildCsv({
    required List<MagicFormulaRankedStock> ranked,
    required List<MagicFormulaSkippedStock> skipped,
    required MagicFormulaUniverse universe,
    required DateTime scannedAt,
  }) {
    const headers = [
      'Status',
      'Universe',
      'Scanned At',
      'Rank',
      'Symbol',
      'Company',
      'Exchange',
      'Sector',
      'Industry',
      'ROCE %',
      'ROCE Rank',
      'Earnings Yield %',
      'EY Rank',
      'Combined Score',
      'Market Cap (₹ Cr)',
      'Market Price As Of',
      'Enterprise Value (₹ Cr)',
      'TTM EBIT (₹ Cr)',
      'Total Debt (₹ Cr)',
      'Cash (₹ Cr)',
      'Total Assets (₹ Cr)',
      'Current Liabilities (₹ Cr)',
      'Statement Basis',
      'Period End',
      'Balance Sheet Date',
      'Source',
      'Missing Reason',
    ];
    final lines = <String>[headers.map(_csv).join(',')];

    for (final row in ranked) {
      final fundamental = row.fundamental;
      lines.add(
        [
          'Ranked',
          universe.label,
          scannedAt.toIso8601String(),
          '${row.rank}',
          row.candidate.symbol,
          row.candidate.companyName,
          row.candidate.exchange,
          row.candidate.sector,
          row.candidate.industry,
          _decimal(row.rocePct),
          '${row.roceRank}',
          _decimal(row.earningsYieldPct),
          '${row.earningsYieldRank}',
          '${row.score}',
          _decimal(fundamental.marketCapCr),
          _date(fundamental.marketPriceAsOf),
          _decimal(fundamental.enterpriseValueCr),
          _decimal(fundamental.ebitTtmCr),
          _decimal(fundamental.totalDebtCr),
          _decimal(fundamental.cashCr),
          _decimal(fundamental.totalAssetsCr),
          _decimal(fundamental.currentLiabilitiesCr),
          fundamental.statementBasis,
          _date(fundamental.periodEnd),
          _date(fundamental.balanceSheetDate),
          fundamental.source,
          fundamental.missingReason,
        ].map(_csv).join(','),
      );
    }

    for (final row in skipped) {
      final fundamental = row.fundamental;
      lines.add(
        [
          'Skipped',
          universe.label,
          scannedAt.toIso8601String(),
          '',
          fundamental.candidate.symbol,
          fundamental.candidate.companyName,
          fundamental.candidate.exchange,
          fundamental.candidate.sector,
          fundamental.candidate.industry,
          '',
          '',
          '',
          '',
          '',
          _decimal(fundamental.marketCapCr),
          _date(fundamental.marketPriceAsOf),
          _decimal(fundamental.enterpriseValueCr),
          _decimal(fundamental.ebitTtmCr),
          _decimal(fundamental.totalDebtCr),
          _decimal(fundamental.cashCr),
          _decimal(fundamental.totalAssetsCr),
          _decimal(fundamental.currentLiabilitiesCr),
          fundamental.statementBasis,
          _date(fundamental.periodEnd),
          _date(fundamental.balanceSheetDate),
          fundamental.source,
          row.reason,
        ].map(_csv).join(','),
      );
    }

    return '\uFEFF${lines.join('\r\n')}\r\n';
  }

  static String _csv(String value) {
    if (!value.contains(',') &&
        !value.contains('"') &&
        !value.contains('\r') &&
        !value.contains('\n')) {
      return value;
    }
    return '"${value.replaceAll('"', '""')}"';
  }

  static String _decimal(double? value) => value?.toStringAsFixed(2) ?? '';

  static String _date(DateTime? value) {
    if (value == null) return '';
    return '${value.year.toString().padLeft(4, '0')}-'
        '${value.month.toString().padLeft(2, '0')}-'
        '${value.day.toString().padLeft(2, '0')}';
  }

  static String _dateStamp(DateTime date) =>
      '${date.year.toString().padLeft(4, '0')}'
      '${date.month.toString().padLeft(2, '0')}'
      '${date.day.toString().padLeft(2, '0')}';
}
