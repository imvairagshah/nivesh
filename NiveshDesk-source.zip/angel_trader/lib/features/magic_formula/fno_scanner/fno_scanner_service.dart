// ---------------------------------------------------------------------------
// fno_scanner_service.dart — official-data plumbing for the F&O Scanner.
//
//   • CM bhavcopy ZIPs  → per-symbol daily OHLCV history (≥21 sessions) for
//     % change, ATR(14), 20-din average volume and yesterday's CPR.
//   • FO bhavcopy ZIP   → near-month FUTSTK OpnIntrst + ChngInOpnIntrst (OI
//     change), plus lot size from NewBrdLotQty.
//
// Sourcing is exchange-official archives only (`nsearchives.nseindia.com`),
// the same files the news-module level plans use. No guessed values: a file
// that 404s (holiday/weekend) just moves the walk-back one day further. The
// scan result is cached per trade date in [ScanCacheDao] so the app shows the
// lists instantly and refetches only on Rescan.
//
// Everything parse-related is a pure function on CSV text → unit-testable.
// ---------------------------------------------------------------------------

import 'dart:convert';

import '../../../data/local/dao/scan_cache_dao.dart';
import 'fno_scanner_engine.dart';
import 'package:archive/archive.dart';

typedef ScannerGetBytes = Future<List<int>> Function(
  Uri uri, {
  String? refererPath,
});

/// One parsed CM day.
typedef CmDay = ({DateTime date, Map<String, ScanBar> bars});

/// One parsed FO day (OI snapshot).
typedef FoOi = Map<String, OiRow>;

class ScannerFetchException implements Exception {
  ScannerFetchException(this.message);
  final String message;
  @override
  String toString() => message;
}

abstract final class ScannerParsers {
  static String _norm(String h) =>
      h.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

  static int _col(List<String> header, List<String> names) {
    for (final name in names) {
      final idx = header.indexOf(_norm(name));
      if (idx >= 0) return idx;
    }
    return -1;
  }

  static List<String> _splitCsvLine(String line) {
    // Bhavcopy cells never contain quoted commas today, but keep one pass of
    // quote-stripping so a renamed column with a comma cannot break rows.
    final out = <String>[];
    final buf = StringBuffer();
    var inQuotes = false;
    for (var i = 0; i < line.length; i++) {
      final c = line[i];
      if (c == '"') {
        inQuotes = !inQuotes;
      } else if (c == ',' && !inQuotes) {
        out.add(buf.toString());
        buf.clear();
      } else {
        buf.write(c);
      }
    }
    out.add(buf.toString());
    return out;
  }

  /// `2024-11-28`, `28-Nov-2024`, `28NOV2024`, `28-11-2024` — all appear in
  /// NSE files across formats/years. Null when none match (row skipped).
  static DateTime? parseNseDate(String raw) {
    final s = raw.trim();
    if (s.isEmpty) return null;
    final iso = DateTime.tryParse(s);
    if (iso != null) return DateTime(iso.year, iso.month, iso.day);
    final m = RegExp(r'^(\d{1,2})[-/ ]?([A-Za-z]{3})[-/ ]?(\d{2,4})$')
        .firstMatch(s);
    if (m != null) {
      const months = {
        'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4, 'may': 5, 'jun': 6,
        'jul': 7, 'aug': 8, 'sep': 9, 'oct': 10, 'nov': 11, 'dec': 12,
      };
      final month = months[m.group(2)!.toLowerCase()];
      if (month != null) {
        var year = int.parse(m.group(3)!);
        if (year < 100) year += 2000;
        return DateTime(year, month, int.parse(m.group(1)!));
      }
    }
    return null;
  }

  /// Official NSE CM bhavcopy CSV → per-symbol daily OHLCV (EQ/BE/BZ only).
  /// Header styles: UDiFF (`TckrSymb, SctySrs, …`) and classic
  /// (`SYMBOL, SERIES, …`). Volume is optional — 0 when the column is absent.
  static Map<String, ScanBar> parseCmBhavcopy(String csv, DateTime tradeDate) {
    final lines = csv.split(RegExp(r'[\r\n]+'));
    if (lines.isEmpty) return {};
    final header = _splitCsvLine(lines.first).map(_norm).toList();
    final iSymbol = _col(header, ['TckrSymb', 'Symbol']);
    final iSeries = _col(header, ['SctySrs', 'Series']);
    final iOpen = _col(header, ['OpnPric', 'OpenPrice', 'Open']);
    final iHigh = _col(header, ['HghPric', 'HighPrice', 'High']);
    final iLow = _col(header, ['LwPric', 'LowPrice', 'Low']);
    final iClose = _col(header, ['ClsPric', 'ClosePrice', 'Close']);
    final iVol = _col(header, [
      'TtlTradgVol',
      'TotTrdQty',
      'TotalTradedQuantity',
      'No.ofShares',
      'Volume',
    ]);
    if (iSymbol < 0 || iHigh < 0 || iLow < 0 || iClose < 0) return {};

    const allowedSeries = {'EQ', 'BE', 'BZ'};
    final out = <String, ScanBar>{};
    for (var i = 1; i < lines.length; i++) {
      final line = lines[i].trim();
      if (line.isEmpty) continue;
      final parts = _splitCsvLine(line);
      if (parts.length <= iClose) continue;
      final series = iSeries >= 0 && iSeries < parts.length
          ? parts[iSeries].trim().toUpperCase()
          : 'EQ';
      if (!allowedSeries.contains(series)) continue;
      final symbol = parts[iSymbol].trim().toUpperCase();
      if (symbol.isEmpty) continue;
      double? numAt(int idx) =>
          idx >= 0 && idx < parts.length
              ? double.tryParse(parts[idx].trim())
              : null;
      final high = numAt(iHigh);
      final low = numAt(iLow);
      final close = numAt(iClose);
      if (high == null || low == null || close == null) continue;
      if (high <= 0 || low <= 0 || close <= 0) continue;
      out[symbol] = ScanBar(
        date: tradeDate,
        open: numAt(iOpen) ?? 0,
        high: high,
        low: low,
        close: close,
        volume: numAt(iVol) ?? 0,
      );
    }
    return out;
  }

  /// Official NSE FO bhavcopy CSV → near-month stock-futures OI per symbol.
  /// UDiFF (`FinInstrmTp=FUTSTK`) and classic (`OPTION_TYP=XX`) both accepted;
  /// index futures are excluded in classic mode via a deny-list.
  static FoOi parseFoBhavcopy(String csv, DateTime tradeDate) {
    final lines = csv.split(RegExp(r'[\r\n]+'));
    if (lines.isEmpty) return {};
    final header = _splitCsvLine(lines.first).map(_norm).toList();
    final iSymbol = _col(header, ['TckrSymb', 'Symbol']);
    final iExpiry = _col(header, ['XpryDt', 'ExpiryDt', 'ExpiryDate']);
    final iType = _col(header, ['FinInstrmTp']);
    final iOpt = _col(header, ['OptnTp', 'OptionTyp']);
    final iOi = _col(header, ['OpnIntrst', 'OpenInt', 'OpenInterest']);
    final iChg =
        _col(header, ['ChngInOpnIntrst', 'ChgInOI', 'ChangeInOpenInterest']);
    final iClose = _col(header, ['ClsPric', 'ClosePrice', 'Close']);
    final iPrev = _col(header, ['PrvsClsgPric', 'PrevClose', 'PrevClsgPric']);
    final iLot = _col(header, ['NewBrdLotQty', 'MarketLot', 'LotSize']);
    if (iSymbol < 0 || iExpiry < 0 || iOi < 0 || iChg < 0) return {};

    const indexDeny = {
      'NIFTY', 'BANKNIFTY', 'FINNIFTY', 'MIDCPNIFTY', 'NIFTYNXT50',
      'SENSEX', 'BANKEX', 'SENSEX50', 'NIFTY50',
    };

    final rows = <String, List<(DateTime, OiRow)>>{};
    for (var i = 1; i < lines.length; i++) {
      final line = lines[i].trim();
      if (line.isEmpty) continue;
      final parts = _splitCsvLine(line);
      if (parts.length <= iChg) continue;
      String at(int idx) =>
          idx >= 0 && idx < parts.length ? parts[idx].trim() : '';
      double? numAt(int idx) => double.tryParse(at(idx));
      final symbol = at(iSymbol).toUpperCase();
      if (symbol.isEmpty || indexDeny.contains(symbol)) continue;

      // UDiFF FO bhavcopy ke FinInstrmTp: STF (stock futures), STO (stock
      // options), IDF/IDO (index). Sirf **stock futures** chahiye. (1.5.65
      // fix: 'FUT' contains-check 'STF' ko miss karta tha — universe khaali.)
      final type = at(iType).toUpperCase();
      final bool isFuture;
      if (iType >= 0 && type.isNotEmpty) {
        isFuture = type == 'STF' || type == 'FUTSTK';
      } else {
        // Classic FO bhavcopy (no FinInstrmTp): futures = OPTION_TYP XX.
        isFuture =
            iOpt < 0 || at(iOpt).toUpperCase() == 'XX' || at(iOpt).isEmpty;
      }
      if (!isFuture) continue;

      final expiry = parseNseDate(at(iExpiry));
      if (expiry == null) continue;
      final oi = numAt(iOi);
      final chg = numAt(iChg);
      if (oi == null || chg == null || oi <= 0) continue;

      (rows[symbol] ??= []).add((
        expiry,
        OiRow(
          symbol: symbol,
          oi: oi,
          oiChange: chg,
          futuresClose: numAt(iClose) ?? 0,
          previousClose: numAt(iPrev) ?? 0,
          lotSize: numAt(iLot)?.round() ?? 0,
          expiryLabel: at(iExpiry),
        ),
      ));
    }

    final out = <String, OiRow>{};
    for (final entry in rows.entries) {
      // Nearest expiry that is not long expired (roll pe naya contract chuno).
      final sorted = entry.value..sort((a, b) => a.$1.compareTo(b.$1));
      OiRow? pick;
      for (final (expiry, row) in sorted) {
        if (!expiry.isBefore(tradeDate.subtract(const Duration(days: 3)))) {
          pick = row;
          break;
        }
      }
      out[entry.key] = pick ?? sorted.last.$2;
    }
    return out;
  }

  // -- result ↔ cache rows ---------------------------------------------------

  static Map<String, dynamic> resultToRow(ScannerResult r) => {
        'asOf':
            '${r.asOf.year}-${r.asOf.month.toString().padLeft(2, '0')}-${r.asOf.day.toString().padLeft(2, '0')}',
        'universeSize': r.universeSize,
        'lists': [
          for (final l in r.lists)
            {
              'key': l.key,
              'title': l.title,
              'emoji': l.emoji,
              'tooltip': l.tooltip,
              'entries': [
                for (final e in l.entries)
                  {
                    'symbol': e.symbol,
                    'rank': e.rank,
                    'value': e.valueText,
                    if (e.subText != null) 'sub': e.subText,
                  },
              ],
            },
        ],
        'shortlist': [
          for (final p in r.shortlist)
            {
              'symbol': p.symbol,
              'points': p.points,
              'score': p.score,
              'lists': p.listNames,
              'changePct': p.changePct,
              'ltp': p.ltp,
              if (p.oi != null)
                'oi': {
                  'oi': p.oi!.oi,
                  'oiChange': p.oi!.oiChange,
                  'lotSize': p.oi!.lotSize,
                  'expiryLabel': p.oi!.expiryLabel,
                },
              'plan': {
                'direction': p.plan.direction.name,
                'entry': p.plan.entry,
                'atr': p.plan.atr,
                'sl': p.plan.sl,
                'target': p.plan.target,
              },
            },
        ],
      };

  // -- scanner input ↔ cache row (1.5.70 live recompute base) ---------------
  //
  // The live overlay recomputes from the SAME parsed bars/OI, so the base
  // input is cached next to the result. Compact: 21 sessions × [d,o,h,l,c,v].

  static const String inputCacheKind = 'fno_scanner_input';

  static Map<String, dynamic> inputToRow(ScannerInput input) => {
        'bars': {
          for (final e in input.bars.entries)
            e.key: [
              for (final b in e.value)
                [
                  b.date.millisecondsSinceEpoch,
                  b.open,
                  b.high,
                  b.low,
                  b.close,
                  b.volume,
                ],
            ],
        },
        'oi': {
          for (final e in input.oi.entries)
            e.key: {
              'symbol': e.value.symbol,
              'oi': e.value.oi,
              'oiChange': e.value.oiChange,
              'futuresClose': e.value.futuresClose,
              'previousClose': e.value.previousClose,
              'lotSize': e.value.lotSize,
              'expiryLabel': e.value.expiryLabel,
            },
        },
        if (input.universe != null) 'universe': input.universe!.toList(),
      };

  static ScannerInput? inputFromRow(Map<String, dynamic> row) {
    final barsRaw = row['bars'];
    if (barsRaw is! Map || barsRaw.isEmpty) return null;
    final bars = <String, List<ScanBar>>{};
    for (final e in barsRaw.entries) {
      final days = e.value;
      if (days is! List) continue;
      final list = <ScanBar>[];
      for (final d in days) {
        if (d is! List || d.length < 6) continue;
        final n = [for (final v in d) (v as num).toDouble()];
        list.add(ScanBar(
          date: DateTime.fromMillisecondsSinceEpoch(n[0].toInt()),
          open: n[1],
          high: n[2],
          low: n[3],
          close: n[4],
          volume: n[5],
        ));
      }
      if (list.isNotEmpty) bars['${e.key}'] = list;
    }
    final oi = <String, OiRow>{};
    final oiRaw = row['oi'];
    if (oiRaw is Map) {
      for (final e in oiRaw.entries) {
        final m = e.value;
        if (m is! Map) continue;
        double numOf(String k) =>
            (m[k] as num? ?? 0).toDouble();
        oi['${e.key}'] = OiRow(
          symbol: '${m['symbol'] ?? e.key}',
          oi: numOf('oi'),
          oiChange: numOf('oiChange'),
          futuresClose: numOf('futuresClose'),
          previousClose: numOf('previousClose'),
          lotSize: (m['lotSize'] as num? ?? 0).toInt(),
          expiryLabel: '${m['expiryLabel'] ?? ''}',
        );
      }
    }
    if (bars.isEmpty) return null;
    final universeRaw = row['universe'];
    return ScannerInput(
      bars: bars,
      oi: oi,
      universe: universeRaw is List
          ? {for (final s in universeRaw) '$s'}
          : oi.keys.toSet(),
    );
  }

  static ScannerResult resultFromRow(Map<String, dynamic> row) {
    DateTime parseDay(String s) =>
        DateTime.tryParse(s) ?? DateTime.fromMillisecondsSinceEpoch(0);
    return ScannerResult(
      asOf: parseDay('${row['asOf']}'),
      universeSize: (row['universeSize'] as num? ?? 0).toInt(),
      lists: [
        for (final l in (row['lists'] as List? ?? const []))
          if (l is Map)
            ScannerList(
              key: '${l['key']}',
              title: '${l['title']}',
              emoji: '${l['emoji']}',
              tooltip: '${l['tooltip']}',
              entries: [
                for (final e in (l['entries'] as List? ?? const []))
                  if (e is Map)
                    ScannerEntry(
                      symbol: '${e['symbol']}',
                      rank: (e['rank'] as num? ?? 0).toInt(),
                      valueText: '${e['value']}',
                      subText: e['sub'] == null ? null : '${e['sub']}',
                    ),
              ],
            ),
      ],
      shortlist: [
        for (final p in (row['shortlist'] as List? ?? const []))
          if (p is Map)
            ScannerPick(
              symbol: '${p['symbol']}',
              points: (p['points'] as num? ?? 0).toInt(),
              score: (p['score'] as num? ?? 0).toInt(),
              listNames: [
                for (final n in (p['lists'] as List? ?? const [])) '$n',
              ],
              changePct: (p['changePct'] as num? ?? 0).toDouble(),
              ltp: (p['ltp'] as num? ?? 0).toDouble(),
              oi: p['oi'] is Map
                  ? OiRow(
                      symbol: '${p['symbol']}',
                      oi: ((p['oi'] as Map)['oi'] as num? ?? 0).toDouble(),
                      oiChange:
                          ((p['oi'] as Map)['oiChange'] as num? ?? 0).toDouble(),
                      lotSize:
                          ((p['oi'] as Map)['lotSize'] as num? ?? 0).toInt(),
                      expiryLabel: '${(p['oi'] as Map)['expiryLabel'] ?? ''}',
                    )
                  : null,
              plan: () {
                final plan = (p['plan'] as Map?) ?? const {};
                double? d(Object? v) => (v as num?)?.toDouble();
                return StockPlan(
                  symbol: '${p['symbol']}',
                  direction: plan['direction'] == TradeDirection.sell.name
                      ? TradeDirection.sell
                      : TradeDirection.buy,
                  entry: d(plan['entry']) ?? 0,
                  atr: d(plan['atr']) ?? 0,
                  sl: d(plan['sl']),
                  target: d(plan['target']),
                );
              }(),
            ),
      ],
    );
  }
}

class FnoScannerService {
  FnoScannerService({
    required this.getBytes,
    required this.cache,
    DateTime Function()? clock,
  }) : _clock = clock ?? DateTime.now;

  static const String cacheKind = 'fno_scanner';
  static const String _nseHost = 'nsearchives.nseindia.com';
  static const int historySessions = 22; // 20-avg + today + buffer

  final ScannerGetBytes getBytes;
  final ScanCacheDao cache;
  final DateTime Function() _clock;

  /// The cached scan (any trade date) — screens show this instantly, then the
  /// user decides whether to Rescan. Null = nothing cached yet.
  Future<ScannerResult?> loadCached() async {
    final run = await cache.latestRun(cacheKind);
    if (run == null || run.rows.isEmpty) return null;
    try {
      return ScannerParsers.resultFromRow(run.rows.first);
    } catch (_) {
      return null;
    }
  }

  Future<void> clearCache() async {
    await cache.clearRuns(cacheKind);
    await cache.clearRuns(ScannerParsers.inputCacheKind);
  }

  /// Parsed base of the newest scan (bars + OI) — the live overlay (1.5.70)
  /// recomputes from this. Memory first, then the cached mirror.
  ScannerInput? _input;

  ScannerInput? get lastInput => _input;

  Future<ScannerInput?> loadInput() async {
    if (_input != null) return _input;
    try {
      final run = await cache.latestRun(ScannerParsers.inputCacheKind);
      if (run != null && run.rows.isNotEmpty) {
        final input = ScannerParsers.inputFromRow(
          (run.rows.first as Map).cast<String, dynamic>(),
        );
        if (input != null) return _input = input;
      }
    } catch (_) {
      // Corrupt input row = no base; a full scan will rebuild it.
    }
    return null;
  }

  /// Full scan: CM history walk-back → FO OI of the same trade date → engine.
  /// Throws [ScannerFetchException] when no bhavcopy is reachable at all.
  Future<ScannerResult> scan({void Function(String progress)? onProgress}) async {
    onProgress?.call('Official CM bhavcopy download ho raha hai…');
    final days = <CmDay>[];
    Object? lastError;
    final today = DateTime(_clock().year, _clock().month, _clock().day);
    for (var offset = 0; offset < 70 && days.length < historySessions; offset++) {
      final date = today.subtract(Duration(days: offset));
      try {
        final csv = await _bhavcopyCsv(_cmUrl(date));
        final bars = ScannerParsers.parseCmBhavcopy(csv, date);
        if (bars.isNotEmpty) days.add((date: date, bars: bars));
      } catch (e) {
        lastError = e;
      }
    }
    if (days.length < kScannerMinBars) {
      throw ScannerFetchException(
        'Bhavcopy history nahi mili (${days.length} sessions) — '
        '${lastError ?? 'network check karo'}.',
      );
    }
    // Newest first from the walk; engine wants oldest first per symbol.
    days.sort((a, b) => a.date.compareTo(b.date));
    final tradeDate = days.last.date;

    onProgress?.call('FO bhavcopy (OI + F&O universe) load ho raha hai…');
    FoOi oi;
    try {
      final foCsv = await _bhavcopyCsv(_foUrl(tradeDate));
      oi = ScannerParsers.parseFoBhavcopy(foCsv, tradeDate);
    } catch (e) {
      throw ScannerFetchException(
        'FO bhavcopy nahi mili — bina F&O stocks ke list ke scan jhootha '
        'hota (poori cash market aa jati). Network check karo. ($e)',
      );
    }
    if (oi.isEmpty) {
      throw ScannerFetchException(
        'FO bhavcopy me koi stock-futures row nahi mili — F&O universe '
        'khaali hai.',
      );
    }

    onProgress?.call('Lists + score bana raha hai…');
    final perSymbol = <String, List<ScanBar>>{};
    for (final day in days) {
      for (final entry in day.bars.entries) {
        (perSymbol[entry.key] ??= []).add(entry.value);
      }
    }
    // Only symbols with a full window count (engine filters too, but the cache
    // stays small if the map is already clean).
    perSymbol.removeWhere((_, v) => v.length < kScannerMinBars);

    final input = ScannerInput(
      bars: perSymbol,
      oi: oi,
      // Sirf F&O stocks (FO bhavcopy ke FUTSTK underlyings) — non-F&O cash
      // stocks kisi bhi list me nahi aate.
      universe: oi.keys.toSet(),
    );
    final result = computeScanner(input);
    await cache.saveRun(
      kind: cacheKind,
      asOf: _dayKey(result.asOf),
      rows: [ScannerParsers.resultToRow(result)],
    );
    // 1.5.70 — base input bhi cache karo (live recompute ke liye).
    try {
      await cache.saveRun(
        kind: ScannerParsers.inputCacheKind,
        asOf: _dayKey(result.asOf),
        rows: [ScannerParsers.inputToRow(input)],
      );
    } catch (_) {
      // Input mirror fail = live overlay nahi chalega, scan bilkul chalega.
    }
    _input = input;
    return result;
  }

  Future<String> _bhavcopyCsv(Uri zipUrl) async {
    final bytes = await getBytes(zipUrl, refererPath: '/all-reports');
    final archive = ZipDecoder().decodeBytes(bytes);
    for (final file in archive) {
      if (file.isFile && file.name.toLowerCase().endsWith('.csv')) {
        return utf8.decode(file.content as List<int>);
      }
    }
    throw ScannerFetchException('ZIP me CSV nahi: $zipUrl');
  }

  Uri _cmUrl(DateTime date) => Uri.https(
        _nseHost,
        '/content/cm/BhavCopy_NSE_CM_0_0_0_${_dayCompact(date)}_F_0000.csv.zip',
      );

  Uri _foUrl(DateTime date) => Uri.https(
        _nseHost,
        '/content/fo/BhavCopy_NSE_FO_0_0_0_${_dayCompact(date)}_F_0000.csv.zip',
      );

  String _dayCompact(DateTime d) =>
      '${d.year}${d.month.toString().padLeft(2, '0')}${d.day.toString().padLeft(2, '0')}';

  String _dayKey(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
}
