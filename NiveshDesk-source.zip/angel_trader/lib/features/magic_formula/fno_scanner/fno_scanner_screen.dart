// ---------------------------------------------------------------------------
// fno_scanner_screen.dart — the F&O Scanner (2nd function behind the Magic
// Formula icon).
//
// Sections, top to bottom:
//   1. Header — trade date, universe size, Rescan, honest status line.
//   2. Shortlist — stocks common to ≥2 top-10 lists, score 0–100, har pick ka
//      trade plan: stock plan (Entry/SL/Target ₹, ATR rule) + options plan
//      (ATM CE/PE, strike, lot, real premium, rule-based SL/Target).
//   3. The five lists — Top Gainers · Top Losers · OI Change · Narrow CPR ·
//      Volume ×2 — each top-10 with value + sub-label + list tags on rows.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/layout/desktop_layout.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/widgets/motion.dart';
import '../../../core/widgets/ui.dart';
import 'fno_scanner_engine.dart';
import 'fno_scanner_provider.dart';

class FnoScannerScreen extends StatefulWidget {
  const FnoScannerScreen({super.key});

  @override
  State<FnoScannerScreen> createState() => _FnoScannerScreenState();
}

class _FnoScannerScreenState extends State<FnoScannerScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final p = context.read<FnoScannerProvider>();
      // 1.5.70 — market hours me har 5 min live overlay auto-refresh.
      p.startAutoLive();
      if (p.result == null && !p.loading) {
        p.load().then((_) {
          // Koi cache nahi = pehli baar — seedha official scan chalao.
          if (mounted && p.result == null && p.error == null) p.scan();
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final p = context.watch<FnoScannerProvider>();
    final result = p.result;

    return Scaffold(
      appBar: AppBar(
        title: const Text('F&O Scanner'),
        actions: [
          IconButton(
            tooltip: 'Live refresh — Angel quotes se abhi ke rates (market '
                'hours me har 5 min khud)',
            icon: p.liveLoading
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.bolt_rounded),
            onPressed: p.liveLoading || p.loading
                ? null
                : () => context.read<FnoScannerProvider>().refreshLive(),
          ),
          IconButton(
            tooltip: 'Rescan — official bhavcopy se fresh data',
            icon: p.loading
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.refresh_rounded),
            onPressed: p.loading ? null : () => context.read<FnoScannerProvider>().scan(),
          ),
        ],
      ),
      body: result == null
          ? _EmptyState(p: p)
          : FadeSlideIn(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 28),
                children: [
                  _Header(p: p),
                  const SizedBox(height: 6),
                  _Shortlist(p: p),
                  if (!DesktopLayout.isWide(context))
                    for (final list in result.lists) ...[
                      const SizedBox(height: 4),
                      _ListSection(list: list, shortlist: result.shortlist),
                    ]
                  else
                    // Desktop 1.5.73: paanch lists side-by-side (2-col grid).
                    Builder(
                      builder: (context) {
                        final cols = DesktopLayout.columns(
                          context,
                          minTile: 480,
                          max: 2,
                        );
                        final tileW =
                            (MediaQuery.sizeOf(context).width / cols - 22)
                                .clamp(380.0, 640.0);
                        return Wrap(
                          spacing: 10,
                          runSpacing: 6,
                          children: [
                            for (final list in result.lists)
                              SizedBox(
                                width: tileW,
                                child: _ListSection(
                                  list: list,
                                  shortlist: result.shortlist,
                                ),
                              ),
                          ],
                        );
                      },
                    ),
                  const SizedBox(height: 10),
                  const Text(
                    'Official NSE EOD bhavcopy (CM + FO) se bana — as-of trade '
                    'date upar likha hai. Plan ke numbers MECHANICAL RULES hain '
                    '(1×ATR SL · 2×ATR target · premium ×0.5/×1.5), guarantee '
                    'nahi. Ye suggestion nahi hai — trading se pehle khud verify karo.',
                    style: TextStyle(fontSize: 10.5, height: 1.5),
                  ),
                ],
              ),
            ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.p});
  final FnoScannerProvider p;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (p.loading) ...[
              const CircularProgressIndicator(),
              const SizedBox(height: 16),
              Text(p.progress ?? 'Load ho raha hai…'),
            ] else if (p.error != null) ...[
              const Text('⚠️', style: TextStyle(fontSize: 34)),
              const SizedBox(height: 10),
              Text(p.error!, textAlign: TextAlign.center),
              const SizedBox(height: 14),
              FilledButton.icon(
                onPressed: () => context.read<FnoScannerProvider>().scan(),
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Fir se try karo'),
              ),
            ] else ...[
              const Text('📡', style: TextStyle(fontSize: 34)),
              const SizedBox(height: 10),
              const Text('Official bhavcopy se scan hoga.'),
              const SizedBox(height: 14),
              FilledButton.icon(
                onPressed: () => context.read<FnoScannerProvider>().scan(),
                icon: const Icon(Icons.play_arrow_rounded),
                label: const Text('Scan start karo'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

/// `13:05` — live badge ka IST time.
String _hm(DateTime d) =>
    '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

String _dateLabel(DateTime d) {
  const months = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
  ];
  return '${d.day} ${months[d.month - 1]} ${d.year}';
}

String _money(double? v) => v == null ? '—' : Fmt.price(v);

class _Header extends StatelessWidget {
  const _Header({required this.p});
  final FnoScannerProvider p;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final result = p.result!;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            scheme.primaryContainer.withOpacity(0.7),
            scheme.surfaceContainerLow,
          ],
        ),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text('📡', style: TextStyle(fontSize: 15)),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Trade date: ${_dateLabel(result.asOf)}',
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5),
                ),
              ),
              TapChip(
                label: '${result.universeSize} F&O stocks',
                color: scheme.primary,
                filled: true,
                fontSize: 10,
                tooltip: 'Jitne stocks ki bhavcopy history poori thi (≥21 sessions)',
              ),
              if (p.liveAsOf != null) ...[
                const SizedBox(width: 6),
                TapChip(
                  label: '⚡ LIVE ${_hm(p.liveAsOf!)}',
                  color: MarketColors.of(context).gain,
                  filled: true,
                  fontSize: 10,
                  tooltip: 'Angel ke live quotes — gainers/losers, Volume, plan '
                      'Entry=LTP abhi ke rates pe. OI + CPR EOD (bhavcopy). '
                      'Market hours me har 5 min auto-refresh.',
                ),
              ],
            ],
          ),
          const SizedBox(height: 6),
          Text(
            p.loading
                ? (p.progress ?? 'Load ho raha hai…')
                : p.liveAsOf != null
                    ? '⚡ LIVE ${_hm(p.liveAsOf!)} IST — lists + plan prices Angel '
                        'quotes se. OI + CPR EOD (bhavcopy).'
                    : p.fromCache
                        ? 'Cached scan dikh raha hai — fresh ke liye ↻ dabao.'
                        : '5 lists · Top-10 each · score + trade plan',
            style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
          ),
          if (p.liveNote != null) ...[
            const SizedBox(height: 4),
            Text('ℹ️ ${p.liveNote}',
                style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant)),
          ],
          if (p.error != null) ...[
            const SizedBox(height: 6),
            Text('⚠️ ${p.error}',
                style: TextStyle(fontSize: 11, color: scheme.error)),
          ],
        ],
      ),
    );
  }
}

class _Shortlist extends StatelessWidget {
  const _Shortlist({required this.p});
  final FnoScannerProvider p;

  @override
  Widget build(BuildContext context) {
    final picks = p.result!.shortlist;
    return InfoSection(
      emoji: '🎯',
      title: 'Shortlist — common stocks (score)',
      tooltip: 'Jo stocks 2 ya zyada lists ke top-10 me hain — score = points '
          '(rank 1 pe 10 … rank 10 pe 1) × 2, 0–100',
      children: picks.isEmpty
          ? [
              const Text(
                'Is baar koi stock 2 lists me common nahi hai — lists neeche dekho.',
                style: TextStyle(fontSize: 12),
              ),
            ]
          : [
              // Desktop 1.5.73: shortlist cards wide par 2-col grid.
              if (!DesktopLayout.isWide(context))
                for (var i = 0; i < picks.length; i++) ...[
                  if (i > 0) const SizedBox(height: 10),
                  _PickCard(
                      pick: picks[i], options: p.optionsPlans[picks[i].symbol]),
                ]
              else
                Builder(
                  builder: (context) {
                    final cols =
                        DesktopLayout.columns(context, minTile: 520, max: 2);
                    final tileW =
                        (MediaQuery.sizeOf(context).width / cols - 22)
                            .clamp(420.0, 680.0);
                    return Wrap(
                      spacing: 10,
                      runSpacing: 10,
                      children: [
                        for (final pick in picks)
                          SizedBox(
                            width: tileW,
                            child: _PickCard(
                                pick: pick, options: p.optionsPlans[pick.symbol]),
                          ),
                      ],
                    );
                  },
                ),
            ],
    );
  }
}

class _PickCard extends StatelessWidget {
  const _PickCard({required this.pick, required this.options});
  final ScannerPick pick;
  final OptionsPlan? options;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final colors = MarketColors.of(context);
    final buy = pick.plan.direction == TradeDirection.buy;
    final dirColor = buy ? colors.gain : colors.loss;
    final dirLabel = buy ? 'BUY' : 'SELL';

    return Container(
      padding: const EdgeInsets.all(11),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest.withOpacity(0.5),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: dirColor.withOpacity(0.45)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  pick.symbol,
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
                ),
              ),
              TapChip(
                label: dirLabel,
                color: dirColor,
                filled: true,
                fontSize: 11,
                tooltip: 'Votes se direction — gainers/losers, volume, CPR aur '
                    'OI build-up label mila kar',
              ),
              const SizedBox(width: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: scheme.primary.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  'Score ${pick.score}',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    color: scheme.primary,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            'LTP ${Fmt.price(pick.ltp)} · ${pick.changePct >= 0 ? '+' : ''}'
            '${pick.changePct.toStringAsFixed(2)}% · ${pick.points} points',
            style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
          ),
          const SizedBox(height: 6),
          Wrap(
            spacing: 5,
            runSpacing: 5,
            children: [
              for (final name in pick.listNames)
                TapChip(label: name, color: scheme.primary, fontSize: 9.5),
            ],
          ),
          const SizedBox(height: 9),
          Row(
            children: [
              Expanded(
                child: MetricBox(
                  emoji: '🚪',
                  label: 'Entry',
                  value: Fmt.price(pick.plan.entry),
                  sub: 'LTP (rule)',
                  tooltip: 'Entry = current price — mechanical, koi limit guess nahi',
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: MetricBox(
                  emoji: '🛑',
                  label: 'SL',
                  value: _money(pick.plan.sl),
                  sub: '1×ATR(14)',
                  tooltip: StockPlan.ruleText,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: MetricBox(
                  emoji: '🎯',
                  label: 'Target',
                  value: _money(pick.plan.target),
                  sub: '2×ATR(14)',
                  tooltip: StockPlan.ruleText,
                ),
              ),
            ],
          ),
          const SizedBox(height: 9),
          _OptionsLine(options: options),
        ],
      ),
    );
  }
}

class _OptionsLine extends StatelessWidget {
  const _OptionsLine({required this.options});
  final OptionsPlan? options;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    if (options == null) {
      return Text(
        'Options plan: contract book me data nahi mila.',
        style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
      );
    }
    final o = options!;
    final cePe = o.direction == TradeDirection.buy ? 'CE' : 'PE';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text('⚡', style: TextStyle(fontSize: 11)),
            const SizedBox(width: 5),
            Expanded(
              child: Text(
                'Options plan — ATM $cePe ${o.strike == null ? '' : Fmt.price(o.strike, decimals: 0)}'
                '${o.expiryLabel.isEmpty ? '' : ' · ${o.expiryLabel}'}'
                '${o.lotSize > 0 ? ' · lot ${o.lotSize}' : ''}',
                style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Row(
          children: [
            Expanded(
              child: MetricBox(
                emoji: '💰',
                label: 'Premium',
                value: _money(o.premium),
                sub: 'live quote',
                tooltip: 'ATM option ka real premium (broker quote) — nahi mila to —',
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: MetricBox(
                emoji: '🛑',
                label: 'SL',
                value: _money(o.slRule),
                sub: 'entry × 0.5',
                tooltip: OptionsPlan.ruleText,
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: MetricBox(
                emoji: '🎯',
                label: 'Target',
                value: _money(o.targetRule),
                sub: 'entry × 1.5',
                tooltip: OptionsPlan.ruleText,
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          OptionsPlan.ruleText,
          style: TextStyle(fontSize: 9.5, height: 1.4, color: scheme.onSurfaceVariant),
        ),
      ],
    );
  }
}

class _ListSection extends StatelessWidget {
  const _ListSection({required this.list, required this.shortlist});
  final ScannerList list;
  final List<ScannerPick> shortlist;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final shortlistSymbols = {for (final p in shortlist) p.symbol};
    return InfoSection(
      emoji: list.emoji,
      title: list.title,
      tooltip: list.tooltip,
      children: list.entries.isEmpty
          ? [
              Text(
                'Is list me koi stock qualify nahi hua.',
                style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant),
              ),
            ]
          : [
              for (final e in list.entries)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 3.5),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 22,
                        child: Text(
                          '${e.rank}',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            color: scheme.onSurfaceVariant,
                          ),
                        ),
                      ),
                      Expanded(
                        child: Row(
                          children: [
                            Flexible(
                              child: Text(
                                e.symbol,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontWeight: shortlistSymbols.contains(e.symbol)
                                      ? FontWeight.w800
                                      : FontWeight.w600,
                                  fontSize: 12.5,
                                ),
                              ),
                            ),
                            if (shortlistSymbols.contains(e.symbol)) ...[
                              const SizedBox(width: 5),
                              Tooltip(
                                message: 'Shortlist me hai (≥2 lists)',
                                child: Text('⭐',
                                    style: TextStyle(
                                        fontSize: 10,
                                        color: scheme.primary)),
                              ),
                            ],
                          ],
                        ),
                      ),
                      if (e.subText != null) ...[
                        Flexible(
                          child: Text(
                            e.subText!,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                fontSize: 10, color: scheme.onSurfaceVariant),
                          ),
                        ),
                        const SizedBox(width: 8),
                      ],
                      Text(
                        e.valueText,
                        style: const TextStyle(
                            fontSize: 12, fontWeight: FontWeight.w700),
                      ),
                    ],
                  ),
                ),
            ],
    );
  }
}
