// ---------------------------------------------------------------------------
// fno_scanner_provider.dart — state for the F&O Scanner screen.
//
// Owns: the cached scan (shown instantly), the official-bhavcopy rescan, the
// LIVE overlay (1.5.70 — Angel batched quotes, 5-min auto refresh inside
// market hours), and the options half of every shortlisted stock's plan (local
// contract book for strike/expiry/lot + one batched quote call for the real
// ATM premium).
//
// Degrade policy, same as the rest of the app: a failed quote leaves the
// premium '—' (never a guessed number); a missing contract book leaves the
// options row honest-empty. The stock plan never depends on options data.
// Live quotes fail → the EOD scan stays, with an honest note. OI + CPR stay
// EOD always (bhavcopy OI, daily pivot levels).
// ---------------------------------------------------------------------------

import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../../data/local/dao/fno_contract_dao.dart';
import '../../../data/remote/api_client.dart';
import '../../../data/remote/dto/scrip.dart';
import '../../../services/scrip_master_service.dart';
import '../../../services/study_market_data.dart';
import 'fno_scanner_engine.dart';
import '../../alerts/alerts_center.dart';
import 'fno_scanner_service.dart';

class FnoScannerProvider extends ChangeNotifier {
  FnoScannerProvider({
    required FnoScannerService service,
    required FnoContractDao contracts,
    required StudyMarketData marketData,
    ScripMasterService? scripMaster,
    DateTime Function()? clock,
  })  : _service = service,
        _contracts = contracts,
        _marketData = marketData,
        _scripMaster = scripMaster,
        _clock = clock ?? DateTime.now;

  final FnoScannerService _service;
  final FnoContractDao _contracts;
  final StudyMarketData _marketData;
  final ScripMasterService? _scripMaster;
  final DateTime Function() _clock;

  ScannerResult? result;
  bool loading = false;
  bool fromCache = false;
  String? progress;
  String? error;

  // -- live overlay (1.5.70) ------------------------------------------------
  bool liveLoading = false;

  /// Jab live quotes se result bana ho — tab ki IST timestamp.
  DateTime? liveAsOf;

  /// Honest status: 'Live quotes fail — EOD data', partial coverage, etc.
  String? liveNote;
  Timer? _liveTimer;

  /// symbol → options half of the trade plan (live premium included).
  final Map<String, OptionsPlan> optionsPlans = {};

  /// Loads the cached scan instantly (if any), then keeps it. Use [scan] to
  /// actually fetch fresh official data.
  Future<void> load() async {
    try {
      final cached = await _service.loadCached();
      if (cached != null) {
        result = cached;
        fromCache = true;
        error = null;
        notifyListeners();
        await _loadOptionsPlans();
        // 1.5.70 — cached EOD ke upar live overlay (market hours me).
        unawaited(refreshLive());
      }
    } catch (_) {
      // A corrupt cache row is simply not a cache hit.
    }
  }

  /// Full rescan from the official bhavcopy archives. [force] clears the cache
  /// first so the next open of the screen refetches too.
  Future<void> scan({bool force = true}) async {
    if (loading) return;
    loading = true;
    error = null;
    progress = 'Official bhavcopy download ho raha hai…';
    notifyListeners();
    try {
      if (force) await _service.clearCache();
      final fresh = await _service.scan(
        onProgress: (p) {
          progress = p;
          notifyListeners();
        },
      );
      result = fresh;
      // 1.5.74 — shortlist ready signal (jo naye symbols aaye wahi alert).
      AlertsCenter.instance
          .checkShortlist(fresh.shortlist.map((p) => p.symbol).toList());
      fromCache = false;
      optionsPlans.clear();
      await _loadOptionsPlans();
      // 1.5.70 — market hours me fresh EOD base ke upar live overlay.
      unawaited(refreshLive());
    } catch (e) {
      error = '$e';
    } finally {
      loading = false;
      progress = null;
      notifyListeners();
    }
  }

  // -- live overlay (1.5.70) ------------------------------------------------

  /// IST "now" — device timezone se independent (UTC + 5:30).
  DateTime _istNow() =>
      _clock().toUtc().add(const Duration(hours: 5, minutes: 30));

  /// NSE cash market hours: Mon–Fri 9:15–15:30 IST. Holidays calendar nahi —
  /// tab live quotes last close hi lautate hain (harmless).
  static bool marketOpenAt(DateTime ist) {
    if (ist.weekday == DateTime.saturday || ist.weekday == DateTime.sunday) {
      return false;
    }
    final minutes = ist.hour * 60 + ist.minute;
    return minutes >= 9 * 60 + 15 && minutes <= 15 * 60 + 30;
  }

  bool get marketOpen => marketOpenAt(_istNow());

  /// 5-minute auto live refresh — sirf market hours me. Screen se start hota hai.
  void startAutoLive() {
    _liveTimer?.cancel();
    _liveTimer = Timer.periodic(const Duration(minutes: 5), (_) {
      if (marketOpen && !loading && !liveLoading) {
        unawaited(refreshLive());
      }
    });
    if (marketOpen) unawaited(refreshLive());
  }

  @override
  void dispose() {
    _liveTimer?.cancel();
    super.dispose();
  }

  /// EOD base (bars + OI) ke upar Angel ke batched live quotes se lists aur
  /// plans refresh. Fail = [liveNote] me honest wajah, purana result chalta
  /// rehta hai. OI list + CPR hamesha EOD (bhavcopy OI, daily pivot levels).
  Future<void> refreshLive() async {
    if (loading || liveLoading) return;
    liveLoading = true;
    liveNote = null;
    notifyListeners();
    try {
      final input = await _service.loadInput();
      if (input == null) {
        liveNote = 'Base scan nahi mila — Rescan karke base banao, phir live.';
        return;
      }
      final master = _scripMaster;
      if (master == null) {
        liveNote = 'Scrip master ke bina live quotes nahi — EOD data.';
        return;
      }
      final resolver = await master.resolver();
      final symbols = [...(input.universe ?? input.bars.keys.toSet())]..sort();
      final scripBySymbol = <String, Scrip>{};
      for (final s in symbols) {
        final scrip = resolver.resolve(s).scrip;
        if (scrip != null && scrip.token.isNotEmpty) {
          scripBySymbol[s] = scrip;
        }
      }
      if (scripBySymbol.isEmpty) {
        liveNote = 'Live quotes ke tokens nahi mile — EOD data.';
        return;
      }
      final quotes = await _marketData.fetchQuotesFull(
        [for (final s in scripBySymbol.values) s],
      );
      final live = <String, LiveQuote>{};
      for (final e in scripBySymbol.entries) {
        final q = quotes[e.value.token];
        if (q == null || q.ltp <= 0) continue;
        live[e.key] = LiveQuote(
          ltp: q.ltp,
          prevClose: q.previousClose ?? 0,
          volume: (q.volume ?? 0).toDouble(),
        );
      }
      if (live.isEmpty) {
        liveNote = 'Live quotes nahi mile — EOD data dikha rahe hain.';
        return;
      }
      result = computeScanner(ScannerInput(
        bars: input.bars,
        oi: input.oi,
        universe: input.universe,
        live: live,
      ));
      liveAsOf = _istNow();
      fromCache = false;
      optionsPlans.clear();
      await _loadOptionsPlans();
      if (live.length < scripBySymbol.length * 0.6) {
        liveNote = 'Live ${live.length}/${scripBySymbol.length} stocks ka hi '
            'quote mila — baaki EOD.';
      }
    } on ApiException catch (e) {
      liveNote = e.isAuthError
          ? 'Angel login ke bina live quotes nahi — EOD data.'
          : 'Live quotes fail — EOD data.';
    } catch (_) {
      liveNote = 'Live quotes fail — EOD data dikha rahe hain.';
    } finally {
      liveLoading = false;
      notifyListeners();
    }
  }

  /// ATM CE/PE for every shortlisted stock: strike/expiry/lot from the local
  /// contract book, premium from one batched live quote call.
  Future<void> _loadOptionsPlans() async {
    final r = result;
    if (r == null || r.shortlist.isEmpty) return;
    final legs = <FnoContract>[];
    final pairBySymbol = <String, AtmPair>{};
    for (final pick in r.shortlist) {
      try {
        final pair = await _contracts.atmPair(
          underlying: pick.symbol,
          spot: pick.ltp,
          asOf: _clock(),
        );
        if (pair == null) continue;
        pairBySymbol[pick.symbol] = pair;
        final leg = pick.plan.direction == TradeDirection.buy ? pair.ce : pair.pe;
        if (leg != null) legs.add(leg);
      } catch (_) {
        // Book me symbol nahi = options plan honestly missing.
      }
    }

    Map<String, double> premiumByToken = {};
    if (legs.isNotEmpty) {
      try {
        final quotes =
            await _marketData.fetchQuotesFull([for (final l in legs) l.asScrip()]);
        premiumByToken = {
          for (final e in quotes.entries) e.key: e.value.ltp,
        };
      } catch (_) {
        // Quote fail = premium '—', plan ka baaki hisaab intact.
      }
    }

    for (final pick in r.shortlist) {
      final pair = pairBySymbol[pick.symbol];
      if (pair == null) continue;
      final leg =
          pick.plan.direction == TradeDirection.buy ? pair.ce : pair.pe;
      optionsPlans[pick.symbol] = OptionsPlan(
        direction: pick.plan.direction,
        strike: pair.strike,
        expiryLabel: pair.expiryLabel,
        lotSize: leg?.lotSize ?? pair.ce?.lotSize ?? pair.pe?.lotSize ?? 0,
        premium: leg == null ? null : premiumByToken[leg.token],
      );
    }
    notifyListeners();
  }
}
