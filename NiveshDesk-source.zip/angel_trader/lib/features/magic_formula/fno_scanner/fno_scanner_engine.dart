// ---------------------------------------------------------------------------
// fno_scanner_engine.dart — the F&O Scanner rules, start to finish (pure Dart).
//
// One scan answers: "F&O ke stocks me aaj kya chal raha hai, konsa stock kis
// list me top-10 me hai, aur common stocks ke liye trade plan kya hai?"
//
// Five official-data lists (top-10 each):
//   1. Top Gainers       — cash close vs previous close, % change desc
//   2. Top Losers        — same, asc
//   3. OI Change         — |near-month futures OI change %| desc, with the
//                          classic build-up label (long/short build-up etc.)
//   4. Narrow CPR (daily)— yesterday's (H,L,C) se banne wala Central Pivot
//                          Range: BC=(H+L)/2, TC=2P−BC, P=(H+L+C)/3. Width
//                          ATR(14) se normalise karke rank — sabse narrow pehle.
//   5. Volume ×2         — aaj ka volume ≥ 2 × 20-din ka average, rank by
//                          multiple desc.
//
// Scoring (user-approved): har list ke top-10 me aane par points 10..1
// (rank ke hisaab se). score = points × 2 → 0–100. Shortlist = stock jo ≥ 2
// lists me hai (sabse zyada points pehle).
//
// Trade plan (user-approved: stock + options dono):
//   Stock plan  — direction votes se; Entry = LTP; SL = 1×ATR(14); Target =
//                 2×ATR(14) (1:2 risk:reward). Ye MECHANICAL rule hai, label
//                 me disclosed. ATR missing = SL/Target honestly '—'.
//   Options plan— yahan sirf *direction + rule* banta hai (CE ya PE, kitne
//                 premium par SL/target = entry×0.5 / entry×1.5). Real strike,
//                 expiry, lot aur premium provider bharta hai (local contract
//                 book + live quote); missing = '—', guess kabhi nahi.
//
// Nothing here touches Flutter or the network — inputs in, [ScannerResult] out.
// ---------------------------------------------------------------------------

import '../../../data/remote/dto/candle.dart';
import '../../fno/study/study_engine.dart' show wilderAtr;

/// One symbol's one cash-market session (official CM bhavcopy row).
class ScanBar {
  const ScanBar({
    required this.date,
    required this.open,
    required this.high,
    required this.low,
    required this.close,
    this.volume = 0,
  });

  final DateTime date;
  final double open;
  final double high;
  final double low;
  final double close;
  final double volume;
}

/// One symbol's live quote (Angel SmartAPI market-quote, 1.5.70 live scanner).
/// Jab market band ho, yahi overlay gainers/losers, Volume ×2 aur plan ka
/// Entry=LTP live karta hai. OI aur CPR EOD rehte hain (bhavcopy/levels).
class LiveQuote {
  const LiveQuote({
    required this.ltp,
    required this.prevClose,
    required this.volume,
  });

  final double ltp;
  final double prevClose;

  /// Aaj ka ab-tak ka traded volume (shares).
  final double volume;
}

/// One symbol's near-month FUTSTK row (official FO bhavcopy).
class OiRow {
  const OiRow({
    required this.symbol,
    required this.oi,
    required this.oiChange,
    this.futuresClose = 0,
    this.previousClose = 0,
    this.lotSize = 0,
    this.expiryLabel = '',
  });

  final String symbol;

  /// `OpnIntrst` of the nearest-expiry FUTSTK contract.
  final double oi;

  /// `ChngInOpnIntrst` — official change-in-OI, same contract.
  final double oiChange;

  final double futuresClose;
  final double previousClose;
  final int lotSize;
  final String expiryLabel;

  /// Change as % of the *previous* OI (base = oi − oiChange). 0 when unknown.
  double get oiChangePct {
    final base = oi - oiChange;
    return base > 0 ? oiChange / base * 100 : 0;
  }

  /// The classic four labels — price side + OI side, koi interpretation nahi.
  String buildupLabel(double changePct) {
    final priceUp = changePct > 0;
    final oiUp = oiChange > 0;
    if (priceUp && oiUp) return 'Long build-up';
    if (!priceUp && oiUp) return 'Short build-up';
    if (!priceUp && !oiUp) return 'Short covering';
    return 'Long unwinding';
  }
}

/// One line of a top-10 list.
class ScannerEntry {
  const ScannerEntry({
    required this.symbol,
    required this.rank,
    required this.valueText,
    this.subText,
  });

  final String symbol;

  /// 1-based rank inside its list.
  final int rank;
  final String valueText;
  final String? subText;
}

/// One of the five lists.
class ScannerList {
  const ScannerList({
    required this.key,
    required this.title,
    required this.emoji,
    required this.tooltip,
    required this.entries,
  });

  final String key;
  final String title;
  final String emoji;
  final String tooltip;
  final List<ScannerEntry> entries;
}

enum TradeDirection { buy, sell }

/// The mechanical stock plan — every number is a disclosed rule, not a guess.
class StockPlan {
  const StockPlan({
    required this.symbol,
    required this.direction,
    required this.entry,
    required this.atr,
    this.sl,
    this.target,
  });

  final String symbol;
  final TradeDirection direction;
  final double entry;
  final double atr;
  final double? sl;
  final double? target;

  static const String ruleText =
      'Rule: SL = 1×ATR(14), Target = 2×ATR(14) — risk:reward 1:2. '
      'Ye mechanical rule hai, guarantee nahi.';
}

/// Options half of the plan. Strike/expiry/lot/premium provider bharta hai —
/// yahan rule-based SL/target hain (premium × 0.5 / × 1.5, disclosed).
class OptionsPlan {
  const OptionsPlan({
    required this.direction,
    this.strike,
    this.expiryLabel = '',
    this.lotSize = 0,
    this.premium,
  });

  final TradeDirection direction;
  final double? strike;
  final String expiryLabel;
  final int lotSize;

  /// Real ATM premium (live quote). Null = quote nahi mila — '—' dikhao.
  final double? premium;

  double? get slRule => premium == null ? null : premium! * 0.5;
  double? get targetRule => premium == null ? null : premium! * 1.5;

  static const String ruleText =
      'Rule: premium SL = entry × 0.5, Target = entry × 1.5 (mechanical). '
      'Stock SL hit = turant exit.';
}

/// A shortlisted stock — score, lists, plan.
class ScannerPick {
  const ScannerPick({
    required this.symbol,
    required this.points,
    required this.score,
    required this.listNames,
    required this.changePct,
    required this.ltp,
    required this.plan,
    this.oi,
  });

  final String symbol;

  /// Raw points (0–50): har top-10 presence par 10..1.
  final int points;

  /// points × 2 → 0–100.
  final int score;

  /// List names jahan ye top-10 me hai.
  final List<String> listNames;
  final double changePct;
  final double ltp;
  final StockPlan plan;
  final OiRow? oi;
}

class ScannerResult {
  const ScannerResult({
    required this.asOf,
    required this.lists,
    required this.shortlist,
    required this.universeSize,
  });

  /// Trade date of the newest CM bhavcopy that built this scan.
  final DateTime asOf;
  final List<ScannerList> lists;

  /// ≥2 lists me common, points desc.
  final List<ScannerPick> shortlist;
  final int universeSize;
}

/// Everything one scan needs — already parsed, per symbol.
class ScannerInput {
  const ScannerInput({
    required this.bars,
    required this.oi,
    this.universe,
    this.live,
  });

  /// symbol → sessions, oldest first. Latest session = "aaj".
  final Map<String, List<ScanBar>> bars;

  /// symbol → near-month FUTSTK OI row (same trade date as [bars]).
  final Map<String, OiRow> oi;

  /// F&O symbols (FO bhavcopy ke FUTSTK underlyings). Jab diya ho, tab lists
  /// me **sirf ye** aate hain — cash market ka koi bhi non-F&O stock nahi.
  /// Null = sab bars wale symbols (standalone/tests ke liye).
  final Set<String>? universe;

  /// symbol → live quote (1.5.70). In symbols ke change/LTP/volume live
  /// hote hain; jo symbol yahan na ho wo EOD. Null = pure EOD scan.
  final Map<String, LiveQuote>? live;
}

// ---------------------------------------------------------------------------
// The rules.
// ---------------------------------------------------------------------------

const int kScannerVolumeAvg = 20;
const int kScannerMinBars = 21; // 20 avg + today
const double kScannerVolumeMultiple = 2;

ScannerResult computeScanner(ScannerInput input, {int topN = 10}) {
  final universe = input.universe;
  final symbols = input.bars.keys
      .where((s) =>
          (universe == null || universe.contains(s)) &&
          (input.bars[s]?.length ?? 0) >= kScannerMinBars)
      .toList()
    ..sort();

  // -- per-symbol stats ----------------------------------------------------
  final changePct = <String, double>{};
  final ltp = <String, double>{};
  final atr = <String, double>{};
  final cprWidthOverAtr = <String, double>{};
  final cprWidthPct = <String, double>{};
  final volMult = <String, double>{};

  for (final symbol in symbols) {
    final bars = input.bars[symbol]!;
    final last = bars[bars.length - 1];
    final prev = bars[bars.length - 2];
    // Live overlay (1.5.70): quote mila to LTP/change/volume usi se, warna EOD.
    final live = input.live?[symbol];
    final liveLtp = live == null || live.ltp <= 0 ? 0.0 : live.ltp;
    final livePrev = live?.prevClose ?? 0.0;
    final liveVol = live?.volume ?? 0.0;
    if (liveLtp > 0) {
      ltp[symbol] = liveLtp;
      changePct[symbol] = livePrev > 0
          ? (liveLtp - livePrev) / livePrev * 100
          : (prev.close > 0 ? (liveLtp - prev.close) / prev.close * 100 : 0);
    } else {
      ltp[symbol] = last.close;
      changePct[symbol] =
          prev.close > 0 ? (last.close - prev.close) / prev.close * 100 : 0;
    }

    final a = wilderAtr([for (final b in bars) _toCandle(b)]);
    atr[symbol] = a;

    // CPR from the PREVIOUS session — "kal ka CPR, aaj ke intraday ke liye".
    final p = (prev.high + prev.low + prev.close) / 3;
    final bc = (prev.high + prev.low) / 2;
    final tc = 2 * p - bc;
    final width = (tc - bc).abs();
    cprWidthPct[symbol] = last.close > 0 ? width / last.close * 100 : 0;
    cprWidthOverAtr[symbol] = a > 0 ? width / a : double.infinity;

    final volWindow = bars.sublist(bars.length - 1 - kScannerVolumeAvg, bars.length - 1);
    var volSum = 0.0;
    for (final b in volWindow) {
      volSum += b.volume;
    }
    final avgVol = volWindow.isEmpty ? 0.0 : volSum / volWindow.length;
    final dayVol = liveLtp > 0 && liveVol > 0 ? liveVol : last.volume;
    volMult[symbol] = avgVol > 0 ? dayVol / avgVol : 0;
  }

  // -- the five lists ------------------------------------------------------
  final gainers = symbols.where((s) => changePct[s]! > 0).toList()
    ..sort((a, b) => changePct[b]!.compareTo(changePct[a]!));
  final losers = symbols.where((s) => changePct[s]! < 0).toList()
    ..sort((a, b) => changePct[a]!.compareTo(changePct[b]!));

  final oiSymbols = [
    for (final s in symbols)
      if (input.oi.containsKey(s)) s,
  ]..sort((a, b) {
      final da = input.oi[a]!.oiChangePct.abs();
      final db = input.oi[b]!.oiChangePct.abs();
      return db.compareTo(da);
    });

  final cpr = symbols.where((s) => cprWidthOverAtr[s]! < double.infinity).toList()
    ..sort((a, b) => cprWidthOverAtr[a]!.compareTo(cprWidthOverAtr[b]!));

  final volume = symbols.where((s) => volMult[s]! >= kScannerVolumeMultiple).toList()
    ..sort((a, b) => volMult[b]!.compareTo(volMult[a]!));

  String pct(double v) => '${v >= 0 ? '+' : ''}${v.toStringAsFixed(2)}%';

  ScannerList list(
    String key,
    String title,
    String emoji,
    String tooltip,
    List<String> ranked,
    String Function(String symbol) valueOf, [
    String? Function(String symbol)? subOf,
  ]) =>
      ScannerList(
        key: key,
        title: title,
        emoji: emoji,
        tooltip: tooltip,
        entries: [
          for (var i = 0; i < ranked.length && i < topN; i++)
            ScannerEntry(
              symbol: ranked[i],
              rank: i + 1,
              valueText: valueOf(ranked[i]),
              subText: subOf?.call(ranked[i]),
            ),
        ],
      );

  final lists = <ScannerList>[
    list(
      'gainers',
      'Top Gainers',
      '🚀',
      'Cash close vs kal ka close — sabse zyada % upar. Official CM bhavcopy.',
      gainers,
      (s) => pct(changePct[s]!),
    ),
    list(
      'losers',
      'Top Losers',
      '📉',
      'Cash close vs kal ka close — sabse zyada % neeche.',
      losers,
      (s) => pct(changePct[s]!),
    ),
    list(
      'oi',
      'OI Change',
      '🔄',
      'Near-month futures ka change-in-OI (official FO bhavcopy) — sabse '
          'zyada % badlav. Label batata hai build-up ka type.',
      oiSymbols,
      (s) => pct(input.oi[s]!.oiChangePct),
      (s) => input.oi[s]!.buildupLabel(changePct[s]!),
    ),
    list(
      'cpr',
      'Narrow CPR (daily)',
      '🎯',
      'Kal ke (H,L,C) se bana Central Pivot Range: BC=(H+L)/2, TC=2P−BC, '
          'P=(H+L+C)/3. Width ko ATR(14) se divide karke narrowness — chhoti '
          'width = aaj trend move ki sambhavna. Sabse narrow pehle.',
      cpr,
      (s) => '${cprWidthPct[s]!.toStringAsFixed(2)}% wide',
      (s) => 'width ${cprWidthOverAtr[s]!.toStringAsFixed(2)}× ATR',
    ),
    list(
      'volume',
      'Volume ×2',
      '📊',
      'Aaj ka volume 20-din average ka 2× ya usse zyada — classic volume spike.',
      volume,
      (s) => '${volMult[s]!.toStringAsFixed(1)}× avg',
    ),
  ];

  // -- scoring: har top-10 entry par points 10..1 --------------------------
  final points = <String, int>{};
  final listNames = <String, List<String>>{};
  final namesByKey = {for (final l in lists) l.key: l.title};
  for (final l in lists) {
    for (final e in l.entries) {
      final p = topN + 1 - e.rank;
      points[e.symbol] = (points[e.symbol] ?? 0) + p;
      (listNames[e.symbol] ??= []).add(namesByKey[l.key]!);
    }
  }

  // -- shortlist: ≥2 lists me common, points desc --------------------------
  final shortlistSymbols = [
    for (final s in points.keys)
      if ((listNames[s]?.length ?? 0) >= 2) s,
  ]..sort((a, b) {
      final byPoints = points[b]!.compareTo(points[a]!);
      if (byPoints != 0) return byPoints;
      return changePct[b]!.compareTo(changePct[a]!);
    });

  final shortlist = <ScannerPick>[
    for (final s in shortlistSymbols)
      ScannerPick(
        symbol: s,
        points: points[s]!,
        score: points[s]! * 2,
        listNames: listNames[s]!,
        changePct: changePct[s]!,
        ltp: ltp[s]!,
        oi: input.oi[s],
        plan: _planFor(
          symbol: s,
          ltp: ltp[s]!,
          changePct: changePct[s]!,
          atr: atr[s]!,
          lists: listNames[s]!,
          oi: input.oi[s],
          volMult: volMult[s] ?? 0,
        ),
      ),
  ];

  return ScannerResult(
    asOf: _latestDate(input),
    lists: lists,
    shortlist: shortlist,
    universeSize: symbols.length,
  );
}

/// Direction = disclosed votes; Entry/SL/Target = mechanical ATR rule.
StockPlan _planFor({
  required String symbol,
  required double ltp,
  required double changePct,
  required double atr,
  required List<String> lists,
  required OiRow? oi,
  required double volMult,
}) {
  var votes = 0;
  if (lists.contains('Top Gainers')) votes += 2;
  if (lists.contains('Top Losers')) votes -= 2;
  if (lists.contains('Volume ×2')) votes += changePct > 0 ? 1 : -1;
  if (lists.contains('Narrow CPR (daily)')) votes += changePct > 0 ? 1 : -1;
  if (lists.contains('OI Change') && oi != null) {
    final label = oi.buildupLabel(changePct);
    if (label == 'Long build-up') votes += 1;
    if (label == 'Short build-up') votes -= 1;
  }
  final direction =
      votes > 0 ? TradeDirection.buy : (votes < 0 ? TradeDirection.sell : (changePct >= 0 ? TradeDirection.buy : TradeDirection.sell));

  double? sl;
  double? target;
  if (atr > 0) {
    sl = direction == TradeDirection.buy ? ltp - atr : ltp + atr;
    target = direction == TradeDirection.buy ? ltp + 2 * atr : ltp - 2 * atr;
  }
  return StockPlan(
    symbol: symbol,
    direction: direction,
    entry: ltp,
    atr: atr,
    sl: sl,
    target: target,
  );
}

Candle _toCandle(ScanBar b) => Candle(
      time: b.date,
      open: b.open,
      high: b.high,
      low: b.low,
      close: b.close,
      volume: b.volume.round(),
    );

DateTime _latestDate(ScannerInput input) {
  var latest = DateTime(0);
  for (final bars in input.bars.values) {
    if (bars.isNotEmpty && bars.last.date.isAfter(latest)) {
      latest = bars.last.date;
    }
  }
  return latest;
}
