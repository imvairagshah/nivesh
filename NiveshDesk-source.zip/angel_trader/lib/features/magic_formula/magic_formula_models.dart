import 'package:flutter/foundation.dart';

/// Universe offered by the standalone Equity Magic Formula tool.
enum MagicFormulaUniverse {
  all('all', 'ALL Stocks'),
  nifty50('nifty50', 'NIFTY 50'),
  nifty100('nifty100', 'NIFTY 100'),
  nifty500('nifty500', 'NIFTY 500'),
  sectorWise('sector', 'Sector-wise');

  const MagicFormulaUniverse(this.key, this.label);

  final String key;
  final String label;

  static MagicFormulaUniverse fromKey(String? key) => values.firstWhere(
    (value) => value.key == key,
    orElse: () => MagicFormulaUniverse.all,
  );
}

/// User-selectable broad sectors. The exchange's more specific industry label
/// is retained separately on each row; this category is for the chip filter.
abstract final class MagicFormulaSectors {
  static const List<String> all = [
    'Banking',
    'IT',
    'Pharma',
    'Auto',
    'FMCG',
    'Metals',
    'Energy',
    'Realty',
    'PSU Banks',
    'Financial Services',
    'Infrastructure',
    'Capital Goods',
    'Construction Materials',
    'Healthcare',
    'Consumer Services',
    'Services',
    'Chemicals',
    'Consumer Durables',
    'Media',
    'Telecom',
    'Power',
    'Other / Unclassified',
  ];
}

/// One tradable/listed company in a selected universe.
@immutable
class MagicFormulaCandidate {
  const MagicFormulaCandidate({
    required this.symbol,
    required this.companyName,
    required this.exchange,
    this.sector = '',
    this.industry = '',
    this.isin = '',
    this.dataSymbol = '',
    this.dataCompanyName = '',
  });

  /// The ticker the user sees.
  final String symbol;
  final String companyName;
  final String exchange;
  final String sector;
  final String industry;
  final String isin;

  /// NSE symbol/company used for the official NSE filing fallback when a
  /// dual-listed BSE row can be matched to its NSE listing. Empty for rows with
  /// no verified NSE match.
  final String dataSymbol;
  final String dataCompanyName;

  String get sourceSymbol => dataSymbol.isEmpty ? symbol : dataSymbol;
  String get sourceCompanyName =>
      dataCompanyName.isEmpty ? companyName : dataCompanyName;

  /// ISIN is the canonical identity when the official listing source provides
  /// it. Otherwise keep exchange + ticker separate; never guess an ISIN.
  String get cacheKey {
    final securityId = isin.trim().toUpperCase();
    return securityId.isNotEmpty
        ? 'ISIN:$securityId'
        : '${exchange.trim().toUpperCase()}:${symbol.trim().toUpperCase()}';
  }

  String get displayTicker => symbol.trim().toUpperCase();
}

/// Financial data needed by the Magic Formula, stored in ₹ crore.
///
/// Null means "not verified/available" — it is never silently replaced with 0.
@immutable
class MagicFormulaFundamental {
  const MagicFormulaFundamental({
    required this.candidate,
    this.marketCapCr,
    this.ebitTtmCr,
    this.totalDebtCr,
    this.cashCr,
    this.totalAssetsCr,
    this.currentLiabilitiesCr,
    this.marketPriceAsOf,
    this.statementBasis = '',
    this.earningsBasis = '',
    this.periodStart,
    this.periodEnd,
    this.balanceSheetDate,
    this.fetchedAt,
    this.source = 'NSE filings',
    this.missingReason = '',
  });

  final MagicFormulaCandidate candidate;
  final double? marketCapCr;
  final double? ebitTtmCr;
  final double? totalDebtCr;
  final double? cashCr;
  final double? totalAssetsCr;
  final double? currentLiabilitiesCr;
  final DateTime? marketPriceAsOf;
  final String statementBasis;

  /// '' means TTM EBIT from the filing's own EBIT tag. Non-empty is a
  /// disclosed substitute such as 'PBT proxy (EBIT not tagged)' used for
  /// banking/insurance/NBFC filing formats without an EBIT element.
  final String earningsBasis;
  final DateTime? periodStart;
  final DateTime? periodEnd;
  final DateTime? balanceSheetDate;
  final DateTime? fetchedAt;
  final String source;
  final String missingReason;

  double? get enterpriseValueCr {
    final marketCap = marketCapCr;
    final debt = totalDebtCr;
    final cash = cashCr;
    if (marketCap == null || debt == null || cash == null) return null;
    return marketCap + debt - cash;
  }

  bool get hasRequiredFields =>
      marketCapCr != null &&
      ebitTtmCr != null &&
      totalDebtCr != null &&
      cashCr != null &&
      totalAssetsCr != null &&
      currentLiabilitiesCr != null;

  /// Service-wide HTTP failures must never pin a broken scan for one hour.
  /// This also recognizes old cached 403 rows created by earlier app builds.
  bool get isTransientHttpFailure => RegExp(
    r'\bhttp\s+(401|403|408|429|5\d\d)\b',
    caseSensitive: false,
  ).hasMatch(missingReason);

  bool isFresh({
    required DateTime now,
    Duration validity = const Duration(hours: 1),
  }) {
    if (isTransientHttpFailure) return false;
    // A row that could not be built is never served stale: its error is an
    // invitation to retry, and pinning it (even for an hour) makes a fixed
    // pipeline look broken. Absence stays absence — refetched every scan.
    if (missingReason.isNotEmpty) return false;
    final at = fetchedAt;
    if (at == null) return false;
    final age = now.difference(at);
    return !age.isNegative && age < validity;
  }

  MagicFormulaFundamental withCandidate(MagicFormulaCandidate next) =>
      MagicFormulaFundamental(
        candidate: next,
        marketCapCr: marketCapCr,
        ebitTtmCr: ebitTtmCr,
        totalDebtCr: totalDebtCr,
        cashCr: cashCr,
        totalAssetsCr: totalAssetsCr,
        currentLiabilitiesCr: currentLiabilitiesCr,
        marketPriceAsOf: marketPriceAsOf,
        statementBasis: statementBasis,
        earningsBasis: earningsBasis,
        periodStart: periodStart,
        periodEnd: periodEnd,
        balanceSheetDate: balanceSheetDate,
        fetchedAt: fetchedAt,
        source: source,
        missingReason: missingReason,
      );

  Map<String, Object?> toDb() => {
    'security_key': candidate.cacheKey,
    'symbol': candidate.symbol,
    'company_name': candidate.companyName,
    'exchange': candidate.exchange,
    'sector': candidate.sector,
    'industry': candidate.industry,
    'isin': candidate.isin,
    'data_symbol': candidate.dataSymbol,
    'data_company_name': candidate.dataCompanyName,
    'market_cap_cr': marketCapCr,
    'ebit_ttm_cr': ebitTtmCr,
    'total_debt_cr': totalDebtCr,
    'cash_cr': cashCr,
    'total_assets_cr': totalAssetsCr,
    'current_liabilities_cr': currentLiabilitiesCr,
    'market_price_as_of': marketPriceAsOf?.toIso8601String(),
    'statement_basis': statementBasis,
    'earnings_basis': earningsBasis,
    'period_start': periodStart?.toIso8601String(),
    'period_end': periodEnd?.toIso8601String(),
    'balance_sheet_date': balanceSheetDate?.toIso8601String(),
    'fetched_at': fetchedAt?.millisecondsSinceEpoch,
    'source': source,
    'missing_reason': missingReason,
  };

  factory MagicFormulaFundamental.fromDb(Map<String, Object?> row) {
    double? number(String key) => (row[key] as num?)?.toDouble();
    DateTime? date(String key) => DateTime.tryParse('${row[key] ?? ''}');
    final candidate = MagicFormulaCandidate(
      symbol: '${row['symbol'] ?? ''}',
      companyName: '${row['company_name'] ?? ''}',
      exchange: '${row['exchange'] ?? 'NSE'}',
      sector: '${row['sector'] ?? ''}',
      industry: '${row['industry'] ?? ''}',
      isin: '${row['isin'] ?? ''}',
      dataSymbol: '${row['data_symbol'] ?? ''}',
      dataCompanyName: '${row['data_company_name'] ?? ''}',
    );
    return MagicFormulaFundamental(
      candidate: candidate,
      marketCapCr: number('market_cap_cr'),
      ebitTtmCr: number('ebit_ttm_cr'),
      totalDebtCr: number('total_debt_cr'),
      cashCr: number('cash_cr'),
      totalAssetsCr: number('total_assets_cr'),
      currentLiabilitiesCr: number('current_liabilities_cr'),
      marketPriceAsOf: date('market_price_as_of'),
      statementBasis: '${row['statement_basis'] ?? ''}',
      earningsBasis: '${row['earnings_basis'] ?? ''}',
      periodStart: date('period_start'),
      periodEnd: date('period_end'),
      balanceSheetDate: date('balance_sheet_date'),
      fetchedAt: row['fetched_at'] == null
          ? null
          : DateTime.fromMillisecondsSinceEpoch(
              (row['fetched_at'] as num).toInt(),
            ),
      source: '${row['source'] ?? 'NSE filings'}',
      missingReason: '${row['missing_reason'] ?? ''}',
    );
  }
}

/// A ranked row. [score] is the sum of the independent ROCE and EY ranks;
/// [rank] is the final position after ascending sort by that score.
@immutable
class MagicFormulaRankedStock {
  const MagicFormulaRankedStock({
    required this.fundamental,
    required this.rocePct,
    required this.earningsYieldPct,
    required this.roceRank,
    required this.earningsYieldRank,
    required this.score,
    required this.rank,
  });

  final MagicFormulaFundamental fundamental;
  final double rocePct;
  final double earningsYieldPct;
  final int roceRank;
  final int earningsYieldRank;
  final int score;
  final int rank;

  MagicFormulaCandidate get candidate => fundamental.candidate;
  double get marketCapCr => fundamental.marketCapCr!;
  double get enterpriseValueCr => fundamental.enterpriseValueCr!;
}

/// Stocks that could not be included in ranks, with the specific reason.
@immutable
class MagicFormulaSkippedStock {
  const MagicFormulaSkippedStock({
    required this.fundamental,
    required this.reason,
  });

  final MagicFormulaFundamental fundamental;
  final String reason;
}

/// One completed ranking pass before Top-N display/pagination.
@immutable
class MagicFormulaRanking {
  const MagicFormulaRanking({required this.ranked, required this.skipped});

  final List<MagicFormulaRankedStock> ranked;
  final List<MagicFormulaSkippedStock> skipped;

  int get scannedCount => ranked.length + skipped.length;

  double? get medianRocePct =>
      _median(ranked.map((row) => row.rocePct).toList());
  double? get medianEarningsYieldPct =>
      _median(ranked.map((row) => row.earningsYieldPct).toList());

  String? topSector({int topN = 20}) {
    final counts = <String, int>{};
    for (final row in ranked.take(topN)) {
      final sector = row.candidate.sector.trim();
      if (sector.isNotEmpty) counts[sector] = (counts[sector] ?? 0) + 1;
    }
    if (counts.isEmpty) return null;
    final entries = counts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return entries.first.key;
  }

  static double? _median(List<double> values) {
    if (values.isEmpty) return null;
    values.sort();
    final mid = values.length ~/ 2;
    if (values.length.isOdd) return values[mid];
    return (values[mid - 1] + values[mid]) / 2;
  }
}

/// Scan progress sent to the loading indicator.
@immutable
class MagicFormulaProgress {
  const MagicFormulaProgress({
    required this.completed,
    required this.total,
    required this.stockLabel,
    required this.stage,
  });

  final int completed;
  final int total;
  final String stockLabel;
  final String stage;

  double get fraction =>
      total == 0 ? 0 : (completed / total).clamp(0.0, 1.0).toDouble();
}
