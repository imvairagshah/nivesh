import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../core/utils/share_helper.dart';

import '../../core/widgets/brand.dart';
import '../../data/local/dao/magic_basket_dao.dart';
import '../../services/stock_suggestion_service.dart';
import 'magic_basket_provider.dart';
import 'magic_formula_export.dart';
import 'magic_formula_models.dart';
import 'magic_formula_provider.dart';

class MagicFormulaScreen extends StatefulWidget {
  const MagicFormulaScreen({super.key});

  @override
  State<MagicFormulaScreen> createState() => _MagicFormulaScreenState();
}

class _MagicFormulaScreenState extends State<MagicFormulaScreen> {
  final MagicFormulaExportService _export = MagicFormulaExportService();
  bool _exporting = false;
  bool _showBaskets = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      context.read<MagicFormulaProvider>().bootstrap();
      context.read<MagicBasketProvider>().load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<MagicFormulaProvider>();
    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            BrandMark(size: 25),
            SizedBox(width: 10),
            Expanded(
              child: Text('Magic Formula', overflow: TextOverflow.ellipsis),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Export full ranked + skipped list as CSV',
            onPressed: !provider.hasCache || _exporting
                ? null
                : () => _exportCsv(provider),
            icon: _exporting
                ? const SizedBox.square(
                    dimension: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.download_rounded),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: provider.isLoadingCache && !provider.hasCache
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
              children: [
                _introCard(context),
                const SizedBox(height: 12),
                _modeToggle(context),
                const SizedBox(height: 12),
                if (!_showBaskets) ...[
                  _universeControls(context, provider),
                  const SizedBox(height: 12),
                  if (provider.universe == MagicFormulaUniverse.sectorWise) ...[
                    _sectorControls(context, provider),
                    const SizedBox(height: 12),
                  ],
                  _scanControls(context, provider),
                ] else ...[
                  _basketsSection(context),
                ],
                if (provider.isScanning) ...[
                  const SizedBox(height: 12),
                  _progressCard(context, provider),
                ],
                if (provider.cacheScopeDiffers && !_showBaskets) ...[
                  const SizedBox(height: 12),
                  _noticeCard(
                    context,
                    icon: Icons.cached_rounded,
                    text:
                        'Offline cache pichhle ${_universeLabel(provider.lastScanUniverseKey)} scan ka hai. Is universe ke sahi results ke liye Scan dabayein.',
                    warning: true,
                  ),
                ],
                if (provider.isPartialScan) ...[
                  const SizedBox(height: 12),
                  _noticeCard(
                    context,
                    icon: Icons.pause_circle_outline_rounded,
                    text: provider.hasError
                        ? 'Official NSE feed unavailable raha; ${provider.progress.completed}/${provider.progress.total} stocks par scan ruk gaya. Dikh rahi ranking sirf in completed rows ki hai.'
                        : 'Scan beech me roka gaya tha: ${provider.progress.completed}/${provider.progress.total} stocks. Ye partial universe ranking hai.',
                    warning: true,
                  ),
                ],
                if (provider.hasError) ...[
                  const SizedBox(height: 12),
                  _errorCard(context, provider),
                ],
                if (provider.hasCache) ...[
                  const SizedBox(height: 12),
                  _summaryCards(context, provider),
                  const SizedBox(height: 12),
                  if (provider.eligibleCount > 0) ...[
                    _rankedTable(context, provider),
                    const SizedBox(height: 12),
                  ] else if (!provider.isScanning) ...[
                    _emptyRankings(context, provider),
                    const SizedBox(height: 12),
                  ],
                  if (provider.skippedCount > 0)
                    _skippedSection(context, provider),
                  const SizedBox(height: 12),
                ] else if (!_showBaskets &&
                    !provider.isScanning &&
                    !provider.hasError) ...[
                  const SizedBox(height: 18),
                  _firstRunEmpty(context),
                  const SizedBox(height: 12),
                ],
                _disclaimer(context),
              ],
            ),
    );
  }

  Widget _modeToggle(BuildContext context) {
    return Row(
      children: [
        ChoiceChip(
          label: const Text('Universe scan'),
          selected: !_showBaskets,
          onSelected: (selected) => setState(() => _showBaskets = false),
        ),
        const SizedBox(width: 10),
        ChoiceChip(
          label: const Text('Baskets'),
          selected: _showBaskets,
          onSelected: (selected) => setState(() => _showBaskets = true),
        ),
      ],
    );
  }

  // ---------------------------------------------------------------- baskets

  Widget _basketsSection(BuildContext context) {
    final baskets = context.watch<MagicBasketProvider>();
    final open = baskets.openBasket;
    if (open == null) return _basketList(context, baskets);
    return _basketDetail(context, baskets, open);
  }

  Widget _basketList(BuildContext context, MagicBasketProvider baskets) {
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'My baskets',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                  ),
                ),
                FilledButton.tonalIcon(
                  onPressed: () async {
                    final name = await _askName(context, 'Naya basket');
                    if (name != null && mounted) {
                      await baskets.create(name);
                    }
                  },
                  icon: const Icon(Icons.add_rounded),
                  label: const Text('Naya basket'),
                ),
              ],
            ),
            const SizedBox(height: 6),
            if (baskets.baskets.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 18),
                child: Text(
                  'Abhi koi basket nahi hai. "Naya basket" se apni pasandida '
                  'scripts (NSE ya BSE) ki list banayein, phir usay scan karein.',
                  style: TextStyle(color: Colors.grey.shade600, height: 1.4),
                ),
              )
            else
              ...baskets.baskets.map(
                (basket) => ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.shopping_basket_outlined),
                  title: Text(
                    basket.name,
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                  subtitle: Text(
                    '${basket.itemCount} stock${basket.itemCount == 1 ? '' : 's'}',
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        tooltip: 'Rename',
                        icon: const Icon(Icons.edit_rounded, size: 20),
                        onPressed: () async {
                          final name = await _askName(
                            context,
                            'Basket ka naam',
                            initial: basket.name,
                          );
                          if (name != null && mounted) {
                            await baskets.rename(basket.id, name);
                          }
                        },
                      ),
                      IconButton(
                        tooltip: 'Delete',
                        icon: const Icon(
                          Icons.delete_outline_rounded,
                          size: 20,
                        ),
                        onPressed: () async {
                          final ok = await _confirmDelete(context, basket.name);
                          if (ok && mounted) await baskets.delete(basket.id);
                        },
                      ),
                    ],
                  ),
                  onTap: () => baskets.open(basket.id),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _basketDetail(
    BuildContext context,
    MagicBasketProvider baskets,
    MagicBasket basket,
  ) {
    final scan = context.watch<MagicFormulaProvider>();
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                IconButton(
                  tooltip: 'Back to baskets',
                  visualDensity: VisualDensity.compact,
                  onPressed: baskets.close,
                  icon: const Icon(Icons.arrow_back_rounded),
                ),
                Expanded(
                  child: Text(
                    basket.name,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                Text(
                  '${baskets.items.length} stock'
                  '${baskets.items.length == 1 ? '' : 's'}',
                  style: TextStyle(color: Colors.grey.shade600),
                ),
              ],
            ),
            const SizedBox(height: 10),
            _AddStockField(
              onPick: (suggestion) async {
                final messenger = ScaffoldMessenger.of(context);
                final added = await baskets.addSuggestion(suggestion);
                if (added) {
                  messenger.showSnackBar(
                    SnackBar(
                      content: Text(
                        '${suggestion.symbol} ${basket.name} me add ho gaya.',
                      ),
                      duration: const Duration(seconds: 2),
                    ),
                  );
                }
              },
            ),
            const SizedBox(height: 8),
            if (baskets.items.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 14),
                child: Text(
                  'Basket khaali hai. Upar stock name ya symbol type karein — '
                  'suggestions se select karke add karein.',
                  style: TextStyle(color: Colors.grey.shade600, height: 1.4),
                ),
              )
            else
              ...baskets.items.map(
                (item) => ListTile(
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  title: Text(
                    item.companyName.isEmpty ? item.symbol : item.companyName,
                    style: const TextStyle(fontWeight: FontWeight.w500),
                  ),
                  subtitle: Text('${item.symbol} · ${item.exchange}'),
                  trailing: IconButton(
                    tooltip: 'Remove',
                    icon: const Icon(Icons.remove_circle_outline_rounded),
                    onPressed: () => baskets.removeItem(item.id),
                  ),
                ),
              ),
            const SizedBox(height: 10),
            FilledButton.icon(
              onPressed: baskets.items.isEmpty || scan.isScanning
                  ? null
                  : () => _scanBasket(baskets),
              icon: const Icon(Icons.query_stats_rounded),
              label: Text(
                scan.isScanning ? 'Scan chal raha hai…' : 'Scan basket',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _scanBasket(MagicBasketProvider baskets) async {
    final members = [
      for (final item in baskets.items) item.toCandidate(),
    ];
    await context.read<MagicFormulaProvider>().scanMembers(
      members,
      label: baskets.openBasket?.name ?? 'Basket',
      force: true,
    );
    if (mounted) {
      // Results render in the shared tables below the basket pane.
      setState(() {});
    }
  }

  Future<String?> _askName(
    BuildContext context,
    String title, {
    String? initial,
  }) {
    final controller = TextEditingController(text: initial);
    return showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLength: 40,
          decoration: const InputDecoration(hintText: 'e.g. Long term, Banks'),
          onSubmitted: (value) => Navigator.of(dialogContext).pop(value),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(controller.text),
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  Future<bool> _confirmDelete(BuildContext context, String name) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Basket delete karein?'),
        content: Text('"$name" aur uske stocks hat jayenge.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    return result ?? false;
  }

  Widget _introCard(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: colors.primaryContainer,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(Icons.auto_graph_rounded, color: colors.primary),
                ),
                const SizedBox(width: 12),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Quality + value, ek hi ranking me',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Har metric ko alag rank; dono ranks ka chhota sum behtar.',
                        style: TextStyle(fontSize: 12.5, height: 1.35),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            const Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _FormulaPill(
                  label: 'ROCE',
                  formula: 'TTM EBIT ÷ (Total Assets − Current Liabilities)',
                ),
                _FormulaPill(
                  label: 'Earnings Yield',
                  formula: 'TTM EBIT ÷ Enterprise Value',
                ),
                _FormulaPill(
                  label: 'Enterprise Value',
                  formula: 'Market Cap + Total Debt − Cash',
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              'Official NSE public sources · consolidated preferred, standalone fallback · no broker login required',
              style: TextStyle(
                color: colors.onSurfaceVariant,
                fontSize: 11.5,
                height: 1.35,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _universeControls(
    BuildContext context,
    MagicFormulaProvider provider,
  ) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'UNIVERSE',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 9),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final universe in MagicFormulaUniverse.values)
                  ChoiceChip(
                    label: Text(universe.label),
                    selected: provider.universe == universe,
                    onSelected: provider.isScanning
                        ? null
                        : (_) => provider.setUniverse(universe),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: Text(
                    'Display Top ${provider.topN}',
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
                Text(
                  '5–100',
                  style: TextStyle(
                    color: colors.onSurfaceVariant,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
            Slider(
              min: 5,
              max: 100,
              divisions: 95,
              value: provider.topN.toDouble(),
              label: '${provider.topN}',
              onChanged: (value) => provider.setTopN(value.round()),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectorControls(BuildContext context, MagicFormulaProvider provider) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'SECTORS',
                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800),
                  ),
                ),
                TextButton(
                  onPressed: provider.selectAllSectors,
                  child: const Text('All'),
                ),
                TextButton(
                  onPressed: provider.clearSectors,
                  child: const Text('Clear'),
                ),
              ],
            ),
            Wrap(
              spacing: 7,
              runSpacing: 2,
              children: [
                for (final sector in MagicFormulaSectors.all)
                  FilterChip(
                    label: Text(sector),
                    selected: provider.selectedSectors.contains(sector),
                    onSelected: (_) => provider.toggleSector(sector),
                    visualDensity: VisualDensity.compact,
                  ),
              ],
            ),
            const SizedBox(height: 5),
            Text(
              'Sector-wise ranking ke liye pehle selected universe ka data scan hota hai; pehla scan lamba ho sakta hai.',
              style: TextStyle(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
                fontSize: 11.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _scanControls(BuildContext context, MagicFormulaProvider provider) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Wrap(
          alignment: WrapAlignment.spaceBetween,
          crossAxisAlignment: WrapCrossAlignment.center,
          runSpacing: 10,
          spacing: 12,
          children: [
            Wrap(
              spacing: 9,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                FilledButton.icon(
                  onPressed: provider.isScanning ? null : () => provider.scan(),
                  icon: const Icon(Icons.play_arrow_rounded),
                  label: const Text('Scan'),
                ),
                OutlinedButton.icon(
                  onPressed: provider.isScanning
                      ? provider.cancelScan
                      : provider.hasCache
                      ? () => provider.scan(force: true)
                      : null,
                  icon: Icon(
                    provider.isScanning
                        ? Icons.stop_circle_outlined
                        : Icons.refresh_rounded,
                  ),
                  label: Text(provider.isScanning ? 'Stop' : 'Refresh data'),
                ),
              ],
            ),
            Text(
              provider.lastScanAt == null
                  ? 'First scan network se fundamentals load karega.'
                  : 'Last scan: ${_dateTime(provider.lastScanAt!)}',
              style: TextStyle(color: colors.onSurfaceVariant, fontSize: 11.5),
            ),
          ],
        ),
      ),
    );
  }

  Widget _progressCard(BuildContext context, MagicFormulaProvider provider) {
    final progress = provider.progress;
    final colors = Theme.of(context).colorScheme;
    return Card(
      color: colors.primaryContainer.withValues(alpha: 0.45),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const SizedBox.square(
                  dimension: 16,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
                const SizedBox(width: 9),
                Expanded(
                  child: Text(
                    progress.total == 0
                        ? progress.stage
                        : 'Stocks ${progress.completed}/${progress.total} · ${progress.stockLabel}',
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
              ],
            ),
            if (progress.total > 0) ...[
              const SizedBox(height: 10),
              LinearProgressIndicator(value: progress.fraction),
              const SizedBox(height: 7),
              Text(
                progress.stage,
                style: TextStyle(
                  color: colors.onSurfaceVariant,
                  fontSize: 11.5,
                ),
              ),
            ],
            if (provider.hasCache) ...[
              const SizedBox(height: 5),
              Text(
                'Pehle se saved rows table me available hain; stop karne par partial ranking label hogi.',
                style: TextStyle(color: colors.onSurfaceVariant, fontSize: 11),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _summaryCards(BuildContext context, MagicFormulaProvider provider) {
    final width = MediaQuery.sizeOf(context).width;
    final columns = width >= 850 ? 4 : 2;
    final available = width - 32;
    final cardWidth = (available - (columns - 1) * 9) / columns;
    return Wrap(
      spacing: 9,
      runSpacing: 9,
      children: [
        SizedBox(
          width: cardWidth,
          child: _MetricCard(
            label: 'Ranked / scanned',
            value: '${provider.eligibleCount} / ${provider.scannedCount}',
            icon: Icons.format_list_numbered_rounded,
          ),
        ),
        SizedBox(
          width: cardWidth,
          child: _MetricCard(
            label: 'Median ROCE',
            value: _percent(provider.medianRocePct),
            icon: Icons.trending_up_rounded,
          ),
        ),
        SizedBox(
          width: cardWidth,
          child: _MetricCard(
            label: 'Median Earnings Yield',
            value: _percent(provider.medianEarningsYieldPct),
            icon: Icons.savings_outlined,
          ),
        ),
        SizedBox(
          width: cardWidth,
          child: _MetricCard(
            label: 'Skipped / top sector',
            value: '${provider.skippedCount} / ${provider.topSector ?? '—'}',
            icon: Icons.info_outline_rounded,
          ),
        ),
      ],
    );
  }

  Widget _rankedTable(BuildContext context, MagicFormulaProvider provider) {
    final colors = Theme.of(context).colorScheme;
    const widths = <double>[54, 116, 84, 86, 96, 76, 76, 76, 112, 112, 48];
    const tableWidth = 936.0;
    final rows = provider.displayedRows;

    return Card(
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.only(top: 14, bottom: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Magic Formula ranking',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                  Text(
                    'Top ${provider.topN}',
                    style: TextStyle(
                      color: colors.onSurfaceVariant,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: SizedBox(
                width: tableWidth,
                child: Column(
                  children: [
                    Container(
                      color: colors.surfaceContainerHighest.withValues(
                        alpha: 0.55,
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 5),
                      child: Row(
                        children: [
                          _SortHeader(
                            label: '#',
                            width: widths[0],
                            sortKey: MagicFormulaSortKey.rank,
                            provider: provider,
                          ),
                          _SortHeader(
                            label: 'Ticker',
                            width: widths[1],
                            sortKey: MagicFormulaSortKey.symbol,
                            provider: provider,
                          ),
                          _SortHeader(label: 'Exchange', width: widths[2]),
                          _SortHeader(
                            label: 'ROCE %',
                            tooltip:
                                'TTM EBIT ÷ (Total Assets − Current Liabilities)',
                            width: widths[3],
                            sortKey: MagicFormulaSortKey.roce,
                            provider: provider,
                          ),
                          _SortHeader(
                            label: 'EY %',
                            tooltip: 'TTM EBIT ÷ Enterprise Value',
                            width: widths[4],
                            sortKey: MagicFormulaSortKey.earningsYield,
                            provider: provider,
                          ),
                          _SortHeader(
                            label: 'ROCE r.',
                            tooltip: 'Independent descending ROCE rank',
                            width: widths[5],
                            sortKey: MagicFormulaSortKey.roceRank,
                            provider: provider,
                          ),
                          _SortHeader(
                            label: 'EY r.',
                            tooltip: 'Independent descending EY rank',
                            width: widths[6],
                            sortKey: MagicFormulaSortKey.earningsYieldRank,
                            provider: provider,
                          ),
                          _SortHeader(
                            label: 'Score',
                            tooltip:
                                'ROCE rank + Earnings Yield rank; lower is better',
                            width: widths[7],
                            sortKey: MagicFormulaSortKey.score,
                            provider: provider,
                          ),
                          _SortHeader(
                            label: 'Mkt Cap ₹Cr',
                            width: widths[8],
                            sortKey: MagicFormulaSortKey.marketCap,
                            provider: provider,
                          ),
                          _SortHeader(
                            label: 'EV ₹Cr',
                            tooltip: 'Market Cap + Debt − Cash',
                            width: widths[9],
                            sortKey: MagicFormulaSortKey.enterpriseValue,
                            provider: provider,
                          ),
                          SizedBox(width: widths[10]),
                        ],
                      ),
                    ),
                    for (var index = 0; index < rows.length; index++) ...[
                      _rankedRow(
                        context,
                        provider,
                        rows[index],
                        widths,
                        index.isEven,
                      ),
                      Divider(
                        height: 1,
                        color: colors.outlineVariant.withValues(alpha: 0.55),
                      ),
                    ],
                  ],
                ),
              ),
            ),
            _pagination(context, provider),
          ],
        ),
      ),
    );
  }

  Widget _rankedRow(
    BuildContext context,
    MagicFormulaProvider provider,
    MagicFormulaRankedStock row,
    List<double> widths,
    bool striped,
  ) {
    final colors = Theme.of(context).colorScheme;
    final key = row.candidate.cacheKey;
    final expanded = provider.expandedKey == key;
    return Column(
      children: [
        Material(
          color: striped
              ? colors.surfaceContainerLow.withValues(alpha: 0.45)
              : Colors.transparent,
          child: InkWell(
            onTap: () => provider.toggleExpanded(key),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 9),
              child: Row(
                children: [
                  _bodyCell('${row.rank}', widths[0], strong: true),
                  _tickerCell(context, row, widths[1]),
                  _bodyCell(row.candidate.exchange, widths[2]),
                  _bodyCell(_percent(row.rocePct), widths[3], numeric: true),
                  _bodyCell(
                    _percent(row.earningsYieldPct),
                    widths[4],
                    numeric: true,
                  ),
                  _bodyCell('${row.roceRank}', widths[5], numeric: true),
                  _bodyCell(
                    '${row.earningsYieldRank}',
                    widths[6],
                    numeric: true,
                  ),
                  _bodyCell(
                    '${row.score}',
                    widths[7],
                    numeric: true,
                    strong: true,
                  ),
                  _bodyCell(_crores(row.marketCapCr), widths[8], numeric: true),
                  _bodyCell(
                    _crores(row.enterpriseValueCr),
                    widths[9],
                    numeric: true,
                  ),
                  SizedBox(
                    width: widths[10],
                    child: Icon(
                      expanded
                          ? Icons.keyboard_arrow_up_rounded
                          : Icons.keyboard_arrow_down_rounded,
                      size: 20,
                      color: colors.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        if (expanded)
          _financialDetails(context, row.fundamental, showMissingReason: true),
      ],
    );
  }

  Widget _tickerCell(
    BuildContext context,
    MagicFormulaRankedStock row,
    double width,
  ) {
    final colors = Theme.of(context).colorScheme;
    final priceDate = row.fundamental.marketPriceAsOf;
    return SizedBox(
      width: width,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 7),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              row.candidate.symbol,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 11.5,
                fontWeight: FontWeight.w800,
              ),
            ),
            if (priceDate != null)
              Text(
                'EOD ${_dateOnly(priceDate)}',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: colors.onSurfaceVariant, fontSize: 9),
              ),
          ],
        ),
      ),
    );
  }

  Widget _bodyCell(
    String value,
    double width, {
    bool numeric = false,
    bool strong = false,
  }) => SizedBox(
    width: width,
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 7),
      child: Text(
        value,
        textAlign: numeric ? TextAlign.right : TextAlign.left,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          fontSize: 11.5,
          fontWeight: strong ? FontWeight.w800 : FontWeight.w500,
        ),
      ),
    ),
  );

  Widget _pagination(BuildContext context, MagicFormulaProvider provider) {
    final colors = Theme.of(context).colorScheme;
    final page = provider.currentPage + 1;
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 9, 12, 0),
      child: Row(
        children: [
          Text(
            'Showing ${provider.displayedRows.length} of ${provider.displayRankedCount}',
            style: TextStyle(color: colors.onSurfaceVariant, fontSize: 11.5),
          ),
          const Spacer(),
          IconButton(
            tooltip: 'Previous page',
            onPressed: provider.currentPage <= 0
                ? null
                : () => provider.goToPage(provider.currentPage - 1),
            icon: const Icon(Icons.chevron_left_rounded),
            visualDensity: VisualDensity.compact,
          ),
          Text(
            '$page / ${provider.pageCount}',
            style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700),
          ),
          IconButton(
            tooltip: 'Next page',
            onPressed: page >= provider.pageCount
                ? null
                : () => provider.goToPage(provider.currentPage + 1),
            icon: const Icon(Icons.chevron_right_rounded),
            visualDensity: VisualDensity.compact,
          ),
        ],
      ),
    );
  }

  Widget _skippedSection(BuildContext context, MagicFormulaProvider provider) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: ExpansionTile(
        leading: Icon(Icons.rule_folder_outlined, color: colors.error),
        title: Text('Skipped / incomplete · ${provider.skippedCount}'),
        subtitle: const Text(
          'Kaun chhoota aur kyun — tap karke detail dekhein.',
        ),
        children: [
          SizedBox(
            height: 320,
            child: ListView.builder(
              itemCount: provider.skippedRows.length,
              itemBuilder: (context, index) {
                final row = provider.skippedRows[index];
                return ExpansionTile(
                  tilePadding: const EdgeInsets.symmetric(horizontal: 16),
                  title: Text(
                    '${row.fundamental.candidate.symbol} · ${row.fundamental.candidate.companyName}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  subtitle: Text(
                    row.reason,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: colors.error, fontSize: 11.5),
                  ),
                  children: [
                    _financialDetails(
                      context,
                      row.fundamental,
                      showMissingReason: true,
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _financialDetails(
    BuildContext context,
    MagicFormulaFundamental row, {
    required bool showMissingReason,
  }) {
    final colors = Theme.of(context).colorScheme;
    final details = <(String, String)>[
      ('Company', row.candidate.companyName),
      (
        'Sector / industry',
        [
          row.candidate.sector,
          row.candidate.industry,
        ].where((value) => value.trim().isNotEmpty).join(' · '),
      ),
      ('TTM EBIT', _croresOrDash(row.ebitTtmCr)),
      if (row.earningsBasis.isNotEmpty) ('Earnings input', row.earningsBasis),
      ('Market Cap', _croresOrDash(row.marketCapCr)),
      ('Market price as of', _dateOnly(row.marketPriceAsOf)),
      ('Enterprise Value', _croresOrDash(row.enterpriseValueCr)),
      ('Total Debt', _croresOrDash(row.totalDebtCr)),
      ('Cash & Equivalents', _croresOrDash(row.cashCr)),
      ('Total Assets', _croresOrDash(row.totalAssetsCr)),
      ('Current Liabilities', _croresOrDash(row.currentLiabilitiesCr)),
      (
        'Statement basis',
        row.statementBasis.isEmpty ? 'Not available' : row.statementBasis,
      ),
      ('Period end', _dateOnly(row.periodEnd)),
      ('Balance-sheet date', _dateOnly(row.balanceSheetDate)),
      ('Data source', row.source),
    ];
    return Container(
      width: double.infinity,
      color: colors.surfaceContainerLow,
      padding: const EdgeInsets.fromLTRB(16, 13, 16, 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 20,
            runSpacing: 12,
            children: [
              for (final (label, value) in details)
                SizedBox(
                  width: 190,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        label.toUpperCase(),
                        style: TextStyle(
                          color: colors.onSurfaceVariant,
                          fontSize: 9.5,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        value.isEmpty ? '—' : value,
                        style: const TextStyle(fontSize: 12, height: 1.25),
                      ),
                    ],
                  ),
                ),
            ],
          ),
          if (showMissingReason && row.missingReason.isNotEmpty) ...[
            const SizedBox(height: 12),
            Text(
              row.missingReason,
              style: TextStyle(
                color: colors.error,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
          if (row.fetchedAt != null) ...[
            const SizedBox(height: 8),
            Text(
              'Fetched ${_dateTime(row.fetchedAt!)} · cache valid for 1 hour',
              style: TextStyle(color: colors.onSurfaceVariant, fontSize: 10.5),
            ),
          ],
        ],
      ),
    );
  }

  Widget _emptyRankings(BuildContext context, MagicFormulaProvider provider) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Icon(Icons.fact_check_outlined, size: 30, color: colors.secondary),
            const SizedBox(height: 8),
            const Text(
              'Abhi koi stock rank nahi hua',
              style: TextStyle(fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 5),
            Text(
              provider.universe == MagicFormulaUniverse.sectorWise &&
                      provider.selectedSectors.isEmpty
                  ? 'Pehle kam se kam ek sector chip select karein.'
                  : 'Required financial fields missing hain. Neeche har skipped row ka reason diya hai.',
              textAlign: TextAlign.center,
              style: TextStyle(color: colors.onSurfaceVariant, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  Widget _firstRunEmpty(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 25),
        child: Column(
          children: [
            Icon(Icons.search_rounded, size: 34, color: colors.primary),
            const SizedBox(height: 9),
            const Text(
              'Pehla scan taiyaar hai',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 6),
            Text(
              'Universe select karke Scan dabayein. Pehli baar NSE ka latest available EOD close (last trading date) aur filing data load hoga; har stock ki price date details me dikhegi. Poora scan 10 second se kam me ho, iski guarantee nahi hai.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: colors.onSurfaceVariant,
                fontSize: 12.5,
                height: 1.45,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _disclaimer(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      color: colors.surfaceContainerLow,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'FORMULA & DATA NOTE',
              style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 6),
            Text(
              'ROCE = EBIT ÷ (Total Assets − Current Liabilities). Earnings Yield = EBIT ÷ EV; EV = Market Cap + Total Debt − Cash. ROCE aur EY dono ko alag-alag descending rank kiya jaata hai; rank-sum kam ho to rank behtar. Banks/financial services bhi isi raw formula se include hain. Banking/insurance/NBFC ke alag SEBI filing formats me EBIT tag nahi hota — wahan approved PBT (Profit Before Tax) proxy earnings input hoti hai aur row/skip note me uska basis dikhta hai; Total Debt un formats ke borrowings lines (NBFC: debt securities + borrowings + subordinated) se banta hai. Consolidated filing pehle, warna standalone (basis row me dikhega).',
              style: TextStyle(
                color: colors.onSurfaceVariant,
                fontSize: 11.5,
                height: 1.42,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'NSE official constituents, CM-UDiFF EOD Bhavcopy close aur Integrated Filing XBRL par aadharit. EOD close live/intraday quote nahi; trade date har ticker ke neeche aur details me dikhegi. Balance sheet SEBI rule se half-yearly (Q2/Q4) filings me file hoti hai; jis quarter ki filing me na ho (Q1/Q3) wahan pichhli official half-year balance sheet use hoti hai aur Balance-sheet date row me uska asli date dikhta hai — kabhi guess nahi hoti. Integrated Filing endpoint/fields ka stable developer contract documented nahi hai; feed missing/badla/blocked ho to value guess nahi hoti aur row skipped me dikhti hai. BSE-only fundamentals filhaal supported nahi. Yeh research tool hai, investment advice nahi; Magic Formula future returns ya safety guarantee nahi karta.',
              style: TextStyle(
                color: colors.onSurfaceVariant,
                fontSize: 11.5,
                height: 1.42,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _noticeCard(
    BuildContext context, {
    required IconData icon,
    required String text,
    required bool warning,
  }) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      color: warning ? colors.tertiaryContainer.withValues(alpha: 0.55) : null,
      child: Padding(
        padding: const EdgeInsets.all(13),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: colors.tertiary, size: 19),
            const SizedBox(width: 9),
            Expanded(
              child: Text(
                text,
                style: const TextStyle(fontSize: 12, height: 1.35),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _errorCard(BuildContext context, MagicFormulaProvider provider) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      color: colors.errorContainer.withValues(alpha: 0.55),
      child: Padding(
        padding: const EdgeInsets.all(13),
        child: Row(
          children: [
            Icon(Icons.error_outline_rounded, color: colors.error),
            const SizedBox(width: 9),
            Expanded(
              child: Text(
                provider.error!,
                style: TextStyle(color: colors.onErrorContainer, fontSize: 12),
              ),
            ),
            IconButton(
              tooltip: 'Close message',
              onPressed: provider.clearError,
              icon: const Icon(Icons.close_rounded),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _exportCsv(MagicFormulaProvider provider) async {
    setState(() => _exporting = true);
    try {
      final file = await _export.writeCsv(
        ranked: provider.ranking.ranked,
        skipped: provider.ranking.skipped,
        universe: provider.universe,
        scannedAt: provider.lastScanAt ?? DateTime.now(),
      );
      if (!mounted) return;
      // 1.5.72 — desktop par file Downloads me save hoti hai (share sheet nahi).
      final result = await ShareHelper.shareFile(
        file,
        'NiveshDesk Magic Formula results',
      );
      if (!mounted) return;
      final message = result.message;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(message)));
    } on FileSystemException catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('CSV file save nahi hui: ${error.message}')),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('CSV export fail: $error')));
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({
    required this.label,
    required this.value,
    required this.icon,
  });

  final String label;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(13),
        child: Row(
          children: [
            Icon(icon, color: colors.primary, size: 19),
            const SizedBox(width: 9),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: colors.onSurfaceVariant,
                      fontSize: 10.5,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    value,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FormulaPill extends StatelessWidget {
  const _FormulaPill({required this.label, required this.formula});

  final String label;
  final String formula;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: formula,
      child: Chip(
        avatar: const Icon(Icons.functions_rounded, size: 15),
        label: Text(label),
        visualDensity: VisualDensity.compact,
      ),
    );
  }
}

class _SortHeader extends StatelessWidget {
  const _SortHeader({
    required this.label,
    required this.width,
    this.sortKey,
    this.provider,
    this.tooltip,
  });

  final String label;
  final double width;
  final MagicFormulaSortKey? sortKey;
  final MagicFormulaProvider? provider;
  final String? tooltip;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final selected = provider != null && provider!.sortKey == sortKey;
    final child = Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Flexible(
          child: Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w800,
              color: selected ? colors.primary : colors.onSurfaceVariant,
            ),
          ),
        ),
        if (selected)
          Icon(
            provider!.ascending
                ? Icons.arrow_upward_rounded
                : Icons.arrow_downward_rounded,
            size: 11,
            color: colors.primary,
          ),
      ],
    );
    final header = SizedBox(
      width: width,
      height: 32,
      child: provider == null
          ? Center(child: child)
          : InkWell(
              onTap: () => provider!.sortBy(sortKey!),
              child: Center(child: child),
            ),
    );
    return tooltip == null ? header : Tooltip(message: tooltip!, child: header);
  }
}

String _percent(double? value) =>
    value == null ? '—' : '${value.toStringAsFixed(2)}%';

String _crores(double value) =>
    '₹${NumberFormat('#,##0.00;(#,##0.00)').format(value)}';

String _croresOrDash(double? value) =>
    value == null ? '—' : '${_crores(value)} Cr';

String _dateOnly(DateTime? value) {
  if (value == null) return '—';
  return '${value.day.toString().padLeft(2, '0')} '
      '${DateFormat('MMM').format(value)} ${value.year}';
}

String _dateTime(DateTime value) =>
    DateFormat('dd MMM yyyy · HH:mm').format(value);

String _universeLabel(String? key) {
  if (key == null) return 'unknown';
  if (key.startsWith('basket:')) {
    final name = key.substring('basket:'.length);
    return name.isEmpty ? 'basket' : '"$name" basket';
  }
  return MagicFormulaUniverse.fromKey(key).label;
}

/// Typing box with live stock suggestions (symbol + company name, NSE and
/// BSE). Debounced lookup over the merged local master; tapping a row hands
/// the suggestion back to the basket.
class _AddStockField extends StatefulWidget {
  const _AddStockField({required this.onPick});

  final void Function(StockSuggestion suggestion) onPick;

  @override
  State<_AddStockField> createState() => _AddStockFieldState();
}

class _AddStockFieldState extends State<_AddStockField> {
  final TextEditingController _controller = TextEditingController();
  Timer? _debounce;
  List<StockSuggestion> _matches = const [];
  bool _searching = false;

  @override
  void dispose() {
    _debounce?.cancel();
    _controller.dispose();
    super.dispose();
  }

  void _onChanged(String value) {
    _debounce?.cancel();
    if (value.trim().isEmpty) {
      setState(() {
        _matches = const [];
        _searching = false;
      });
      return;
    }
    setState(() => _searching = true);
    _debounce = Timer(const Duration(milliseconds: 250), () async {
      try {
        final service = context.read<StockSuggestionService>();
        final matches = await service.search(value);
        if (!mounted) return;
        setState(() {
          _matches = matches;
          _searching = false;
        });
      } catch (_) {
        if (!mounted) return;
        setState(() {
          _matches = const [];
          _searching = false;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        TextField(
          controller: _controller,
          onChanged: _onChanged,
          decoration: InputDecoration(
            prefixIcon: const Icon(Icons.search_rounded),
            hintText: 'Stock name ya symbol (NSE/BSE)…',
            suffixIcon: _searching
                ? const Padding(
                    padding: EdgeInsets.all(12),
                    child: SizedBox.square(
                      dimension: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    ),
                  )
                : null,
            border: const OutlineInputBorder(),
            isDense: true,
          ),
        ),
        if (_matches.isNotEmpty)
          Container(
            margin: const EdgeInsets.only(top: 4),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey.shade300),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Column(
              children: [
                for (final match in _matches)
                  ListTile(
                    dense: true,
                    title: Text(
                      match.companyName.isEmpty ? match.symbol : match.companyName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    subtitle: Text(
                      '${match.symbol} · ${match.exchange}',
                      style: const TextStyle(fontSize: 12),
                    ),
                    trailing: const Icon(Icons.add_circle_outline_rounded),
                    onTap: () {
                      widget.onPick(match);
                      _controller.clear();
                      setState(() => _matches = const []);
                    },
                  ),
              ],
            ),
          ),
      ],
    );
  }
}
