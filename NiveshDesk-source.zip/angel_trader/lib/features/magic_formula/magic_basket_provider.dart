import 'package:flutter/foundation.dart';

import '../../data/local/dao/magic_basket_dao.dart';
import '../../services/stock_suggestion_service.dart';

/// Basket state for the Magic Formula screen: the user's named lists, the
/// open basket, and its items. All of it local (SQLite) — the scan itself
/// runs through the normal official-data pipeline in [MagicFormulaProvider].
class MagicBasketProvider extends ChangeNotifier {
  MagicBasketProvider(this._dao);

  final MagicBasketDao _dao;

  List<MagicBasket> _baskets = const [];
  int? _openBasketId;
  List<MagicBasketItem> _items = const [];
  bool _loaded = false;
  bool _busy = false;
  String? _error;

  List<MagicBasket> get baskets => _baskets;
  int? get openBasketId => _openBasketId;
  List<MagicBasketItem> get items => _items;
  bool get loaded => _loaded;
  bool get busy => _busy;
  String? get error => _error;

  MagicBasket? get openBasket {
    final id = _openBasketId;
    if (id == null) return null;
    for (final basket in _baskets) {
      if (basket.id == id) return basket;
    }
    return null;
  }

  Future<void> load() async {
    _busy = true;
    try {
      _baskets = await _dao.allBaskets();
      _loaded = true;
      _error = null;
      final openId = _openBasketId;
      if (openId != null) {
        _items = await _dao.items(openId);
        if (!_baskets.any((basket) => basket.id == openId)) {
          _openBasketId = null;
          _items = const [];
        }
      }
    } catch (error) {
      _error = '$error';
    }
    _busy = false;
    notifyListeners();
  }

  /// Union of every basket's member symbols — the News "Mere stocks" filter
  /// (1.5.55). An empty set means the user has no baskets yet (honest).
  Future<Set<String>> allMemberSymbols() async {
    final out = <String>{};
    try {
      final baskets = _baskets.isEmpty ? await _dao.allBaskets() : _baskets;
      for (final basket in baskets) {
        final items = await _dao.items(basket.id);
        for (final item in items) {
          final symbol = item.symbol.trim().toUpperCase();
          if (symbol.isNotEmpty) out.add(symbol);
        }
      }
    } catch (_) {
      // Khaali set hi rehne do — filter honestly dega "koi basket nahi".
    }
    return out;
  }

  Future<MagicBasket?> create(String name) async {
    final trimmed = name.trim();
    if (trimmed.isEmpty) {
      _error = 'Basket ka naam khaali nahi ho sakta.';
      notifyListeners();
      return null;
    }
    final basket = await _dao.createBasket(trimmed);
    await load();
    return basket;
  }

  Future<void> rename(int id, String name) async {
    if (name.trim().isEmpty) return;
    await _dao.renameBasket(id, name);
    await load();
  }

  Future<void> delete(int id) async {
    await _dao.deleteBasket(id);
    if (_openBasketId == id) _openBasketId = null;
    await load();
  }

  Future<void> open(int id) async {
    _openBasketId = id;
    _items = await _dao.items(id);
    _error = null;
    notifyListeners();
  }

  void close() {
    _openBasketId = null;
    _items = const [];
    notifyListeners();
  }

  /// Adds a suggested stock to the open basket. Returns false when the row is
  /// already in it (the DAO enforces one row per basket+exchange+symbol).
  Future<bool> addSuggestion(StockSuggestion suggestion) async {
    final basketId = _openBasketId;
    if (basketId == null) return false;
    final added = await _dao.addItem(
      MagicBasketItem(
        id: 0,
        basketId: basketId,
        symbol: suggestion.symbol,
        exchange: suggestion.exchange,
        companyName: suggestion.companyName,
        isin: suggestion.isin,
        scripCode: suggestion.scripCode,
        addedAt: DateTime.now().millisecondsSinceEpoch,
      ),
    );
    if (added) {
      _items = await _dao.items(basketId);
      _baskets = await _dao.allBaskets();
      _error = null;
      notifyListeners();
    } else {
      _error = 'Ye stock is basket me pehle se hai.';
      notifyListeners();
    }
    return added;
  }

  Future<void> removeItem(int itemId) async {
    final basketId = _openBasketId;
    if (basketId == null) return;
    await _dao.removeItem(itemId);
    _items = await _dao.items(basketId);
    _baskets = await _dao.allBaskets();
    notifyListeners();
  }

  void clearError() {
    if (_error == null) return;
    _error = null;
    notifyListeners();
  }
}
