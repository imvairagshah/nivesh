// ---------------------------------------------------------------------------
// sample_data.dart — 1.5.78 DEMO snapshot (clearly labelled — live data NAHI).
//
// Live Angel chain wiring next cycle; tab tak strategies ka machinery dekhne
// ke liye ye sample numbers (deterministic, koi random nahi). Reports par
// "DEMO DATA" banner dikhta hai — in numbers pe trade KABHI mat karo.
// ---------------------------------------------------------------------------

import 'bankex_models.dart';

class SampleData {
  SampleData._();

  static MarketSnapshot snapshot() => MarketSnapshot(
        isDemo: true,
        bankNifty: _index(
          name: 'BANKNIFTY',
          spot: 60120,
          prev: 59780,
          high: 60240,
          low: 59720,
          atmIv: 14.2,
          ivRank: 38,
          pcr: 1.12,
          maxPain: 60000,
          dte: 14,
          step: 100,
        ),
        bankex: _index(
          name: 'BANKEX',
          spot: 62350,
          prev: 62180,
          high: 62480,
          low: 62020,
          atmIv: 16.1,
          ivRank: 46,
          pcr: 0.95,
          maxPain: 62000,
          dte: 16,
          step: 100,
        ),
        indiaVix: 13.4,
        vixRank30d: 28,
        advances: 8,
        declines: 4,
        capitalAvailable: 500000,
      );

  /// Simple deterministic chain: intrinsic + time-value decay curve.
  /// YE SAMPLE HAI — real premiums nahi.
  static IndexSnapshot _index({
    required String name,
    required double spot,
    required double prev,
    required double high,
    required double low,
    required double atmIv,
    required double ivRank,
    required double pcr,
    required double maxPain,
    required int dte,
    required int step,
  }) {
    final chain = <ChainRow>[];
    final center = (spot / step).round() * step;
    for (var k = -30; k <= 30; k++) {
      final strike = (center + k * step).toDouble();
      final dist = (strike - spot).abs();
      final tv = spot * atmIv / 100 * (dte / 365).clamp(0.01, 1) *
          1.2 *
          (1 - (dist / (spot * 0.06)).clamp(0, 1));
      final callIntrinsic = (spot - strike).clamp(0, double.infinity);
      final putIntrinsic = (strike - spot).clamp(0, double.infinity);
      final callLtp = (callIntrinsic + tv).clamp(1, double.infinity);
      final putLtp = (putIntrinsic + tv).clamp(1, double.infinity);
      chain.add(ChainRow(
        strike: strike,
        callLtp: double.parse(callLtp.toStringAsFixed(2)),
        callIv: atmIv + (k * 0.06).abs(),
        callOi: 20000 + (40 - k.abs()).clamp(0, 40) * 3500.0,
        callDelta: (callIntrinsic > 0 ? 0.55 : 0.35) + k * 0.008,
        callTheta: -tv / dte.clamp(1, 30),
        callVega: tv * 0.2,
        putLtp: double.parse(putLtp.toStringAsFixed(2)),
        putIv: atmIv + (k * 0.05).abs() + 0.3,
        putOi: 22000 + (40 - k.abs()).clamp(0, 40) * 3800.0,
        putDelta: -((putIntrinsic > 0 ? 0.55 : 0.35) - k * 0.008),
        putTheta: -tv / dte.clamp(1, 30),
        putVega: tv * 0.2,
      ));
    }
    return IndexSnapshot(
      name: name,
      spot: spot,
      previousClose: prev,
      intradayHigh: high,
      intradayLow: low,
      atmIv: atmIv,
      ivRank30d: ivRank,
      pcr: pcr,
      maxPain: maxPain,
      expiryDate: DateTime.now().add(Duration(days: dte)),
      dte: dte,
      chain: chain,
      totalCallOi: 1800000,
      totalPutOi: 2100000,
    );
  }
}
