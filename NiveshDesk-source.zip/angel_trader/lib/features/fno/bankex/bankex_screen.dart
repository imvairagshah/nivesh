// ---------------------------------------------------------------------------
// bankex_screen.dart — 1.5.78 "Bankex–Bank Nifty Strategies" (PDF-based).
// Regime card + 10 PDF strategies → tap → full report (legs, economics,
// entry/exit/adjustments) + share. Design = 1.5.58 rules.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import 'package:provider/provider.dart';

import '../../../core/layout/desktop_layout.dart';
import '../../../core/utils/share_helper.dart';
import '../../../core/widgets/motion.dart';
import '../../../core/widgets/ui.dart';
import '../../../data/local/app_database.dart';
import '../../../data/local/dao/fno_contract_dao.dart';
import '../../../services/auth_service.dart';
import '../../../services/market_data_service.dart';
import '../../../services/scrip_master_service.dart';
import 'bankex_models.dart';
import 'bankex_data_service.dart';
import 'regime_engine.dart';
import 'sample_data.dart';
import 'strategy_backtest.dart';
import 'strategy_engine.dart';

class BankexStrategiesScreen extends StatefulWidget {
  const BankexStrategiesScreen({super.key});

  @override
  State<BankexStrategiesScreen> createState() => _BankexStrategiesScreenState();
}

class _BankexStrategiesScreenState extends State<BankexStrategiesScreen> {
  late MarketSnapshot _snapshot;
  late RegimeReport _regime;
  int _lots = 3;

  // 1.5.80 — P2.1/2.2/2.4/2.5 user-request par remove (sirf 6 strategies).
  static const _titles = {
    'P2.3': 'Cross-Expiry Calendar (BN + Bankex)',
    'P2.6': 'Long Straddle / Strangle (Vol Long)',
    'P2.7': 'Short Strangle + Cross-Index Hedge',
    'P2.8': 'Diagonal Ratio Backspread',
    'P2.9': 'Iron Butterfly (Max Theta)',
    'P2.10': 'Delta-Neutral Pair (Bankex vs BN)',
  };
  static const _emoji = {
    'P2.3': '📅', 'P2.6': '🌋', 'P2.7': '🛡️', 'P2.8': '⚖️', 'P2.9': '🦋',
    'P2.10': '🔀',
  };

  String? _liveError;
  bool _liveLoading = true;
  List<DiagStep> _diag = const [];

  // 1.5.84 — in-feature Data Sync (bhavcopy/scrip master) card.
  int _bnContracts = 0;
  int _bnExpiries = 0;
  int _bexContracts = 0;
  int _bexExpiries = 0;
  bool _syncing = false;
  String? _syncMessage;
  bool _syncFailed = false;

  @override
  void initState() {
    super.initState();
    _snapshot = SampleData.snapshot(); // fallback — live aane tak demo
    _regime = RegimeEngine.classify(_snapshot);
    _loadBookStats();
    _loadLive();
  }

  /// Option book me BANKNIFTY / BANKEX contracts kitne hain — live load ka
  /// pehla gate yahi hai.
  Future<void> _loadBookStats() async {
    try {
      final dao = FnoContractDao(AppDatabase.instance);
      final bnContracts = await dao.countFor('BANKNIFTY');
      final bexContracts = await dao.countFor('BANKEX');
      final bnExpiries = (await dao.expiries('BANKNIFTY')).length;
      final bexExpiries = (await dao.expiries('BANKEX')).length;
      if (!mounted) return;
      setState(() {
        _bnContracts = bnContracts;
        _bnExpiries = bnExpiries;
        _bexContracts = bexContracts;
        _bexExpiries = bexExpiries;
      });
    } catch (_) {
      // Book read fail — card counts 0 dikhayega, koi crash nahi.
    }
  }

  /// Diagnose ka plain text (clipboard ke liye) — support ke liye.
  String _diagText() {
    final b = StringBuffer()
      ..writeln('NiveshDesk Bankex diagnose')
      ..writeln('time: ${DateTime.now()}')
      ..writeln('book: BN $_bnContracts (exp $_bnExpiries) · '
          'BEX $_bexContracts (exp $_bexExpiries)')
      ..writeln('live error: ${_liveError ?? '-'}');
    for (final step in _diag) {
      b.writeln('${step.ok ? 'OK' : (step.fatal ? 'FAIL' : 'WARN')} · '
          '${step.label}: ${step.detail}');
    }
    return b.toString();
  }

  /// 1.5.84 — scrip master (= bhavcopy) sync, seedha isi screen se.
  /// Login ki zaroorat nahi (file public hai); download ke baad book rebuild
  /// hota hai aur snapshot dobara load hota hai.
  Future<void> _syncNow() async {
    setState(() {
      _syncing = true;
      _syncMessage = null;
      _syncFailed = false;
    });
    try {
      final master = context.read<ScripMasterService?>();
      if (master == null) {
        setState(() {
          _syncing = false;
          _syncFailed = true;
          _syncMessage = 'Master service available nahi — app dobara kholo.';
        });
        return;
      }
      final rows = await master.refresh(force: true);
      if (!mounted) return;
      await _loadBookStats();
      if (!mounted) return;
      setState(() {
        _syncing = false;
        _syncFailed = false;
        _syncMessage = 'Master sync ho gaya ($rows instruments). '
            'Index contracts: BN $_bnContracts · Bankex $_bexContracts.';
      });
      // Book badla → live snapshot dobara.
      setState(() {
        _liveLoading = true;
        _liveError = null;
      });
      await _loadLive();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _syncing = false;
        _syncFailed = true;
        _syncMessage = 'Sync fail: $e';
      });
    }
  }

  Future<void> _loadLive() async {
    setState(() => _liveLoading = true);
    // 1.5.88 — app ke SAME logged-in services (naya AuthService banane se
    // session khaali hota tha → "Not logged in").
    final d = await LiveSnapshotLoader.diagnose(
      auth: context.read<AuthService?>(),
      marketData: context.read<MarketDataService?>(),
      scripMaster: context.read<ScripMasterService?>(),
    );
    if (!mounted) return;
    setState(() {
      _diag = d.steps;
      _liveLoading = false;
      if (d.snapshot != null) {
        _snapshot = d.snapshot!;
        _regime = RegimeEngine.classify(d.snapshot!);
        _liveError = null;
      } else {
        final f = d.failure;
        _liveError = f == null ? 'unknown' : '${f.label} — ${f.detail}';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final wide = DesktopLayout.isWide(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('🏦 Bankex–Bank Nifty Strategies'),
        actions: [
          IconButton(
            tooltip: 'Lots badlo (default 3)',
            icon: const Icon(Icons.tune_rounded),
            onPressed: _pickLots,
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: CenteredWidth(
        max: wide ? 980 : double.infinity,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 24),
          children: [
            if (_liveLoading)
              Container(
                padding: const EdgeInsets.all(10),
                margin: const EdgeInsets.only(bottom: 10),
                child: const Text('⏳ Live market data load ho raha hai '
                    '(Angel chain + greeks)...',
                    style: TextStyle(fontSize: 11.5)),
              )
            else if (_snapshot.isDemo)
              Container(
                padding: const EdgeInsets.all(10),
                margin: const EdgeInsets.only(bottom: 10),
                decoration: BoxDecoration(
                  color: scheme.errorContainer,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  '⚠️ DEMO DATA — sample numbers (live market nahi). '
                  'Trade in numbers pe KABHI mat karo.'
                  '${_liveError == null ? '' : '\n❌ Fail step: $_liveError'}'
                  '\nNeeche Data Sync card me step-by-step diagnose hai — '
                  'wahi bata raha hai kahan atka.',
                  style: const TextStyle(fontSize: 11.5, height: 1.5),
                ),
              )
            else
              Container(
                padding: const EdgeInsets.all(10),
                margin: const EdgeInsets.only(bottom: 10),
                decoration: BoxDecoration(
                  color: scheme.primaryContainer,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  '🟢 LIVE data — ${DateTime.now().hour.toString().padLeft(2, '0')}:'
                  '${DateTime.now().minute.toString().padLeft(2, '0')} IST · '
                  'Angel SmartAPI chain + broker greeks. PCR/max-pain = OI '
                  'source pending (manual verify).',
                  style: const TextStyle(fontSize: 11.5, height: 1.5),
                ),
              ),
            // 1.5.83 — live load ke partial gaps (IV nahi mili etc.), honest.
            if (!_snapshot.isDemo && _snapshot.warnings.isNotEmpty)
              Container(
                padding: const EdgeInsets.all(9),
                margin: const EdgeInsets.only(bottom: 10),
                decoration: BoxDecoration(
                  color: scheme.tertiaryContainer,
                  borderRadius: BorderRadius.circular(9),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    for (final w in _snapshot.warnings)
                      Text('⚠️ $w',
                          style: const TextStyle(fontSize: 10.5, height: 1.45)),
                  ],
                ),
              ),
            _dataSyncCard(scheme),
            const SizedBox(height: 10),
            _regimeCard(scheme),
            const SizedBox(height: 12),
            Row(
              children: [
                Text('PDF Strategies (Phase 2)',
                    style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        color: scheme.onSurface)),
                const SizedBox(width: 8),
                Tooltip(
                  message: 'Har strategy PDF ke exact construction rules se '
                      'banti hai — strike %OTM, lots, credit gates, DTE checks',
                  child: Icon(Icons.info_outline,
                      size: 14, color: scheme.onSurfaceVariant),
                ),
              ],
            ),
            const SizedBox(height: 8),
            for (final id in _titles.keys) ...[
              FadeSlideIn(
                child: _strategyCard(id, scheme),
              ),
              const SizedBox(height: 8),
            ],
          ],
        ),
      ),
    );
  }

  /// 1.5.84 — "Data Sync" card: bhavcopy/scrip master seedha isi feature se.
  ///
  /// Live data ka pehla gate: local option book me BANKNIFTY + BANKEX contracts
  /// hona chahiye. Card wahi counts dikhata hai, isliye pata chalta hai ki
  /// problem sync ki hai ya login/quotes ki.
  Widget _dataSyncCard(ColorScheme scheme) {
    // Nullable lookup — agar provider tree me na mile to card disabled rahe,
    // screen crash na kare.
    final master = context.watch<ScripMasterService?>();
    final busy = _syncing || (master?.isRefreshing ?? false);
    final bookEmpty = _bnContracts == 0 || _bexContracts == 0;
    final profitRed = scheme.error;

    Widget row(String label, String value) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 2),
          child: Row(
            children: [
              Expanded(
                child: Text(label,
                    style: TextStyle(
                        fontSize: 11, color: scheme.onSurfaceVariant)),
              ),
              Text(value,
                  style: const TextStyle(
                      fontSize: 11, fontWeight: FontWeight.w700)),
            ],
          ),
        );

    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 11, 12, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Text('🔧 Data Sync — Bankex + Bank Nifty',
                    style:
                        TextStyle(fontSize: 12, fontWeight: FontWeight.w800)),
                const SizedBox(width: 6),
                Tooltip(
                  message: 'Live data ke liye local option book me BANKNIFTY '
                      'aur BANKEX contracts chahiye. Ye button Angel ka scrip '
                      'master (jisme F&O/bhavcopy contracts hote hain) sync '
                      'karta hai, phir live snapshot dobara load hota hai.',
                  child: Icon(Icons.info_outline,
                      size: 14, color: scheme.onSurfaceVariant),
                ),
                const Spacer(),
                if (bookEmpty)
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 7, vertical: 2),
                    decoration: BoxDecoration(
                      color: profitRed.withValues(alpha: 0.14),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text('BOOK KHAALI',
                        style: TextStyle(
                            fontSize: 9.5,
                            fontWeight: FontWeight.w800,
                            color: profitRed)),
                  ),
              ],
            ),
            const SizedBox(height: 6),
            row('Bank Nifty contracts',
                _bnContracts == 0 ? '❌ 0' : '$_bnContracts ($_bnExpiries expiry)'),
            row('Bankex contracts',
                _bexContracts == 0 ? '❌ 0' : '$_bexContracts ($_bexExpiries expiry)'),
            row('Master source',
                (master?.source ?? '').isEmpty
                    ? 'not loaded'
                    : master!.source),
            row(
              'Last sync',
              master?.lastUpdated == null
                  ? 'never'
                  : DateFormat('dd MMM HH:mm').format(master!.lastUpdated!),
            ),
            if (bookEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(
                  '⚠️ Index contracts book me nahi hain — isi wajah se live '
                  'data nahi aata. Neeche sync dabao (login ki zaroorat nahi, '
                  'file public hai). Sync ke baad app khud live reload karega.',
                  style: TextStyle(
                      fontSize: 10.5, height: 1.45, color: profitRed),
                ),
              ),
            if (busy) ...[
              const SizedBox(height: 8),
              LinearProgressIndicator(
                value: (master?.progress ?? 0) <= 0 ||
                        (master?.progress ?? 0) >= 1
                    ? null
                    : master!.progress,
              ),
              const SizedBox(height: 5),
              Text(
                  (master?.stage ?? '').isEmpty
                      ? 'Sync chal raha hai…'
                      : master!.stage,
                  style: const TextStyle(fontSize: 10.5)),
            ],
            if (!busy && _syncMessage != null)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(
                  _syncMessage!,
                  style: TextStyle(
                      fontSize: 10.5,
                      height: 1.45,
                      color: _syncFailed ? profitRed : scheme.onSurfaceVariant),
                ),
              ),
            const SizedBox(height: 9),
            SizedBox(
              width: double.infinity,
              child: FilledButton.tonalIcon(
                onPressed: busy ? null : _syncNow,
                icon: const Icon(Icons.sync_rounded, size: 18),
                label: Text(
                  busy
                      ? 'Sync ho raha hai…'
                      : (bookEmpty
                          ? '🔄 Scrip master / bhavcopy sync karo'
                          : '🔄 Scrip master refresh'),
                  style: const TextStyle(fontSize: 12),
                ),
              ),
            ),
            const SizedBox(height: 8),
            // ---- 1.5.85 live diagnose (step-by-step) ----
            Row(
              children: [
                const Text('🔍 Live data — step by step',
                    style: TextStyle(
                        fontSize: 11.5, fontWeight: FontWeight.w800)),
                const Spacer(),
                TextButton.icon(
                  onPressed: _diag.isEmpty
                      ? null
                      : () async {
                          final text = _diagText();
                          await Clipboard.setData(ClipboardData(text: text));
                          if (!context.mounted) return;
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                                content: Text(
                                    'Diagnose copy ho gaya — paste karke bhej do.')),
                          );
                        },
                  icon: const Icon(Icons.copy_rounded, size: 14),
                  label: const Text('Copy', style: TextStyle(fontSize: 11)),
                  style: TextButton.styleFrom(
                      visualDensity: VisualDensity.compact,
                      padding: const EdgeInsets.symmetric(horizontal: 6)),
                ),
                TextButton.icon(
                  onPressed: _liveLoading ? null : _loadLive,
                  icon: const Icon(Icons.refresh_rounded, size: 15),
                  label: const Text('Retry', style: TextStyle(fontSize: 11)),
                  style: TextButton.styleFrom(
                      visualDensity: VisualDensity.compact,
                      padding: const EdgeInsets.symmetric(horizontal: 8)),
                ),
              ],
            ),
            if (_liveLoading)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 4),
                child: LinearProgressIndicator(),
              )
            else
              for (final step in _diag)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 1.5),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(step.ok ? '✅' : (step.fatal ? '❌' : '⚠️'),
                          style: const TextStyle(fontSize: 10.5)),
                      const SizedBox(width: 5),
                      Expanded(
                        child: Text(
                          '${step.label}: ${step.detail}',
                          style: TextStyle(
                            fontSize: 10,
                            height: 1.4,
                            color: step.ok
                                ? scheme.onSurfaceVariant
                                : (step.fatal
                                    ? scheme.error
                                    : scheme.onSurfaceVariant),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
            const SizedBox(height: 6),
            Text(
              'Angel ka daily instrument file (~34 MB) — F&O contracts isi me '
              'aate hain. File ka Last-Modified wahi ho to download skip hota '
              'hai. Live quotes ke liye Angel One login + market-data '
              'subscription chahiye.',
              style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant),
            ),
          ],
        ),
      ),
    );
  }

  Widget _regimeCard(ColorScheme scheme) => InfoSection(
        emoji: '🧭',
        title: 'Market Regime — ${_regime.primary}',
        tooltip: 'PDF Phase 1 (P1.1) rules: trend, VIX, PCR, breadth',
        children: [
          Text('Confidence: ${_regime.confidence}',
              style: const TextStyle(
                  fontSize: 12, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text('📈 ${_regime.trendLine}', style: const TextStyle(fontSize: 11.5)),
          Text('🌊 ${_regime.volatilityLine}', style: const TextStyle(fontSize: 11.5)),
          Text('🎯 ${_regime.sentimentLine}', style: const TextStyle(fontSize: 11.5)),
          Text('📊 ${_regime.breadthLine}', style: const TextStyle(fontSize: 11.5)),
          const SizedBox(height: 6),
          Text('Recommended: ${_regime.recommended.take(3).join(' · ')}',
              style: TextStyle(fontSize: 11, color: scheme.primary)),
          if (_regime.avoid.isNotEmpty)
            Text('Avoid: ${_regime.avoid.join(' · ')}',
                style: TextStyle(fontSize: 11, color: scheme.error)),
        ],
      );

  Widget _strategyCard(String id, ColorScheme scheme) {
    final fit = _regime.recommended.any((r) => r.startsWith(id));
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => _openReport(id),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Row(
            children: [
              Text(_emoji[id] ?? '📋', style: const TextStyle(fontSize: 18)),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('$id · ${_titles[id]}',
                        style: const TextStyle(
                            fontSize: 12.5, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 2),
                    Text(
                      fit ? '✅ Regime fit — abhi recommended' : 'Tap = report banao',
                      style: TextStyle(
                          fontSize: 10.5,
                          color: fit ? scheme.primary : scheme.onSurfaceVariant),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded, size: 18),
            ],
          ),
        ),
      ),
    );
  }

  void _pickLots() {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            for (final lots in const [1, 2, 3])
              ListTile(
                title: Text('$lots lot${lots > 1 ? 's' : ''} '
                    '(${lots * StrategyEngine.lotSize} units)'),
                trailing: _lots == lots
                    ? const Icon(Icons.check_rounded)
                    : null,
                onTap: () {
                  Navigator.pop(ctx);
                  setState(() => _lots = lots);
                },
              ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  void _openReport(String id) {
    final report = _build(id);
    Navigator.of(context).push(
      MaterialPageRoute<void>(
          builder: (_) => _ReportScreen(
              report: report,
              snapshot: _snapshot,
              marketData: context.read<MarketDataService?>())),
    );
  }

  StrategyReport _build(String id) {
    final m = _snapshot;
    final lots = _lots;
    switch (id) {
      case 'P2.3':
        return StrategyEngine.crossExpiryCalendar(m, lots);
      case 'P2.6':
        return StrategyEngine.longStraddle(m, lots, true);
      case 'P2.7':
        return StrategyEngine.shortStrangleHedged(m, lots);
      case 'P2.8':
        return StrategyEngine.diagonalRatioBackspread(m, lots, true);
      case 'P2.9':
        return StrategyEngine.ironButterfly(m, lots);
      default:
        return StrategyEngine.deltaNeutralPair(m, lots);
    }
  }
}

class _ReportScreen extends StatefulWidget {
  const _ReportScreen({
    required this.report,
    required this.snapshot,
    this.marketData,
  });
  final StrategyReport report;
  final MarketSnapshot snapshot;
  final MarketDataService? marketData;

  @override
  State<_ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends State<_ReportScreen> {
  StrategyReport get report => widget.report;
  MarketSnapshot get snapshot => widget.snapshot;

  // 1.5.82 — "kal lagayi hoti to aaj?" card (async, report block nahi karta).
  StrategyBacktest? _backtest;
  bool _btLoading = true;

  @override
  void initState() {
    super.initState();
    _loadBacktest();
  }

  Future<void> _retryBacktest() async {
    setState(() => _btLoading = true);
    await _loadBacktest();
  }

  Future<void> _loadBacktest() async {
    try {
      final bt = await StrategyBacktestService.load(
          m: widget.snapshot,
          report: widget.report,
          marketDataIn: widget.marketData);
      if (!mounted) return;
      setState(() {
        _backtest = bt;
        _btLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _backtest = StrategyBacktest(
            id: widget.report.id,
            note: 'Kal→aaj calculation fail: $e');
        _btLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final wide = DesktopLayout.isWide(context);
    return Scaffold(
      appBar: AppBar(
        title: Text('${report.id} · ${report.title}',
            style: const TextStyle(fontSize: 14)),
        actions: [
          IconButton(
            tooltip: 'Report share/export',
            icon: const Icon(Icons.share_rounded),
            onPressed: () => ShareHelper.shareText(_asText()),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: CenteredWidth(
        max: wide ? 980 : double.infinity,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 24),
          children: [
            if (snapshot.isDemo)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Text('⚠️ DEMO DATA — sample numbers, live market nahi.',
                    style: TextStyle(fontSize: 11, color: scheme.error)),
              ),
            if (!report.valid)
              Container(
                padding: const EdgeInsets.all(10),
                margin: const EdgeInsets.only(bottom: 10),
                decoration: BoxDecoration(
                  color: scheme.errorContainer,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text('❌ PDF constraints pass nahi hue:\n'
                    '${report.validationNote}',
                    style: const TextStyle(fontSize: 11.5, height: 1.5)),
              ),
            _backtestCard(scheme),
            const SizedBox(height: 10),
            InfoSection(
              emoji: '📋',
              title: 'Position Construction',
              tooltip: 'PDF rules: lot size 30, defined risk',
              children: [
                Text(report.underlying,
                    style: const TextStyle(
                        fontSize: 12, fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                for (final leg in report.legs)
                  Container(
                    margin: const EdgeInsets.symmetric(vertical: 2.5),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                    decoration: BoxDecoration(
                      color: scheme.surfaceContainerLow,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      children: [
                        SizedBox(
                          width: 52,
                          child: Text(leg.action,
                              style: TextStyle(
                                  fontSize: 11.5,
                                  fontWeight: FontWeight.w800,
                                  color: leg.isBuy
                                      ? scheme.primary
                                      : scheme.error)),
                        ),
                        Expanded(
                          child: Text(
                            '${leg.instrument} @ ${leg.strike.toStringAsFixed(0)} '
                            '(${leg.distancePct >= 0 ? '+' : ''}${leg.distancePct.toStringAsFixed(1)}%)',
                            style: const TextStyle(
                                fontSize: 11.5, fontWeight: FontWeight.w700),
                          ),
                        ),
                        Text('${leg.lots}L · ₹${leg.premium.toStringAsFixed(1)}',
                            style: TextStyle(
                                fontSize: 11,
                                color: scheme.onSurfaceVariant)),
                      ],
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 10),
            InfoSection(
              emoji: '💰',
              title: 'Economics',
              children: [
                for (final line in report.economics)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 2),
                    child: Text(line,
                        style: const TextStyle(fontSize: 11.5, height: 1.45)),
                  ),
              ],
            ),
            const SizedBox(height: 10),
            InfoSection(emoji: '📐', title: 'Greeks', children: [
              for (final line in report.greeks)
                Text(line, style: const TextStyle(fontSize: 11.5, height: 1.45)),
            ]),
            const SizedBox(height: 10),
            InfoSection(emoji: '🚀', title: 'Entry Rules', children: [
              for (final line in report.entryRules)
                Text('• $line',
                    style: const TextStyle(fontSize: 11.5, height: 1.45)),
            ]),
            const SizedBox(height: 10),
            InfoSection(emoji: '🏁', title: 'Exit Rules', children: [
              for (final line in report.exitRules)
                Text('• $line',
                    style: const TextStyle(fontSize: 11.5, height: 1.45)),
            ]),
            const SizedBox(height: 10),
            InfoSection(emoji: '🔧', title: 'Adjustment Triggers', children: [
              for (final line in report.adjustments)
                Text('• $line',
                    style: const TextStyle(fontSize: 11.5, height: 1.45)),
            ]),
            const SizedBox(height: 10),
            InfoSection(emoji: '⚠️', title: 'Warnings', children: [
              for (final line in report.warnings)
                Text(line,
                    style: TextStyle(
                        fontSize: 11, height: 1.5, color: scheme.onSurfaceVariant)),
            ]),
          ],
        ),
      ),
    );
  }

  /// 1.5.82 — "Kal lagayi hoti to aaj?" card.
  ///
  /// Entry = pichhle trading din ka close, aaj = aaj ka close ya live LTP.
  /// Data na mile to honest note — koi anumaanit number nahi.
  Widget _backtestCard(ColorScheme scheme) {
    if (_btLoading) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: const [
              SizedBox(
                  width: 14,
                  height: 14,
                  child: CircularProgressIndicator(strokeWidth: 2)),
              SizedBox(width: 10),
              Expanded(
                child: Text('⏮️ Kal → Aaj P&L calculate ho raha hai…',
                    style: TextStyle(fontSize: 11.5)),
              ),
            ],
          ),
        ),
      );
    }
    final bt = _backtest;
    if (bt == null) return const SizedBox.shrink();

    final profitColor = scheme.brightness == Brightness.dark
        ? const Color(0xFF7BD88F)
        : const Color(0xFF1B7F3B);
    final total = bt.totalPnl;
    final invested = bt.legs.fold<double>(
        0, (sum, leg) => sum + leg.entryPremium * leg.units);
    final totalPct = invested == 0 ? 0.0 : total / invested * 100;
    final positive = total >= 0;

    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 11, 12, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Text('⏮️ Kal lagayi hoti to aaj?',
                    style:
                        TextStyle(fontSize: 12, fontWeight: FontWeight.w800)),
                const Spacer(),
                if (bt.complete)
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 7, vertical: 2),
                    decoration: BoxDecoration(
                      color: (positive ? profitColor : scheme.error)
                          .withValues(alpha: 0.14),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(positive ? 'PROFIT' : 'LOSS',
                        style: TextStyle(
                            fontSize: 9.5,
                            fontWeight: FontWeight.w800,
                            color: positive ? profitColor : scheme.error)),
                  ),
              ],
            ),
            if (bt.entryDate != null)
              Padding(
                padding: const EdgeInsets.only(top: 3),
                child: Text(
                  'Entry: ${DateFormat('dd MMM').format(bt.entryDate!)} close · '
                  'Aaj: ${DateFormat('dd MMM').format(bt.asOfDate ?? DateTime.now())}',
                  style:
                      TextStyle(fontSize: 10, color: scheme.onSurfaceVariant),
                ),
              ),
            if (bt.note != null) ...[
              const SizedBox(height: 8),
              Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
                decoration: BoxDecoration(
                  color: scheme.errorContainer.withValues(alpha: 0.55),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('❌ Kal → Aaj P&L — data nahi mila',
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w900,
                            color: scheme.error)),
                    const SizedBox(height: 3),
                    Text(bt.note!,
                        style:
                            const TextStyle(fontSize: 11, height: 1.45)),
                    const SizedBox(height: 3),
                    Text(
                      'Live data ke liye Bankex screen ke 🔧 Data Sync card me '
                      'step-by-step diagnose dekho (Login → Book → Spot → '
                      'Quotes → IV). Wahan fail step ka exact reason milega.',
                      style: TextStyle(
                          fontSize: 10,
                          height: 1.4,
                          color: scheme.onSurfaceVariant),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: _retryBacktest,
                  icon: const Icon(Icons.refresh_rounded, size: 16),
                  label: const Text('🔁 Dobara try karo',
                      style: TextStyle(fontSize: 11.5)),
                ),
              ),
            ],
            if (bt.complete) ...[
              const SizedBox(height: 8),
              Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                decoration: BoxDecoration(
                  color: (positive ? profitColor : scheme.error)
                      .withValues(alpha: 0.10),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Text(
                      '${positive ? '+' : '−'}₹${total.abs().toStringAsFixed(0)}',
                      style: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.w900,
                          color: positive ? profitColor : scheme.error),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      '(${totalPct >= 0 ? '+' : '−'}${totalPct.abs().toStringAsFixed(1)}% premium par)',
                      style: TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w700,
                          color: positive ? profitColor : scheme.error),
                    ),
                    const Spacer(),
                    Text('${bt.winners}W / ${bt.losers}L',
                        style: TextStyle(
                            fontSize: 10, color: scheme.onSurfaceVariant)),
                  ],
                ),
              ),
            ],
            if (bt.legs.isNotEmpty) const SizedBox(height: 6),
            for (final leg in bt.legs)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 2.5),
                child: Row(
                  children: [
                    Icon(
                      leg.pnl >= 0
                          ? Icons.arrow_drop_up_rounded
                          : Icons.arrow_drop_down_rounded,
                      size: 18,
                      color: leg.pnl >= 0 ? profitColor : scheme.error,
                    ),
                    Expanded(
                      child: Text(
                        '${leg.isBuy ? 'Buy' : 'Sell'} ${leg.instrument} · '
                        '₹${leg.entryPremium.toStringAsFixed(1)} → '
                        '₹${leg.currentPremium.toStringAsFixed(1)} '
                        '(${leg.priceBasis})',
                        style: const TextStyle(fontSize: 10.5, height: 1.35),
                      ),
                    ),
                    Text(
                      '${leg.pnl >= 0 ? '+' : '−'}₹${leg.pnl.abs().toStringAsFixed(0)}',
                      style: TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w800,
                          color: leg.pnl >= 0 ? profitColor : scheme.error),
                    ),
                  ],
                ),
              ),
            if (bt.missing.isNotEmpty) ...[
              const SizedBox(height: 6),
              Text('⚠️ Data nahi mila (total me shaamil nahi):',
                  style: TextStyle(
                      fontSize: 10.5,
                      fontWeight: FontWeight.w800,
                      color: scheme.error)),
              for (final miss in bt.missing)
                Text('• $miss',
                    style: TextStyle(
                        fontSize: 10,
                        height: 1.4,
                        color: scheme.onSurfaceVariant)),
            ],
            if (bt.legs.isNotEmpty) ...[
              const SizedBox(height: 7),
              Text(
                'Sirf premium change calculate hua (kal close → aaj). '
                'Brokerage, STT, slippage aur margin shaamil nahi.',
                style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant),
              ),
            ],
          ],
        ),
      ),
    );
  }

  String _asText() {
    final b = StringBuffer()
      ..writeln('=== ${report.id}: ${report.title} ===')
      ..writeln(report.underlying)
      ..writeln('\nPOSITION:');
    for (final l in report.legs) {
      b.writeln('${l.action} ${l.instrument} @ ${l.strike} '
          '(${l.distancePct.toStringAsFixed(1)}%) × ${l.lots}L — '
          '₹${l.premium.toStringAsFixed(1)}/unit');
    }
    b.writeln('\nECONOMICS:');
    for (final l in report.economics) {
      b.writeln(l);
    }
    b.writeln('\nENTRY:');
    for (final l in report.entryRules) {
      b.writeln('• $l');
    }
    b.writeln('\nEXIT:');
    for (final l in report.exitRules) {
      b.writeln('• $l');
    }
    final bt = _backtest;
    if (bt != null && bt.hasData) {
      b.writeln('\nKAL → AAJ (agar kal lagayi hoti):');
      for (final leg in bt.legs) {
        b.writeln('${leg.instrument}: ₹${leg.entryPremium.toStringAsFixed(1)} → '
            '₹${leg.currentPremium.toStringAsFixed(1)} = '
            '${leg.pnl >= 0 ? '+' : '−'}₹${leg.pnl.abs().toStringAsFixed(0)}');
      }
      if (bt.complete) {
        b.writeln('TOTAL: ${bt.totalPnl >= 0 ? '+' : '−'}'
            '₹${bt.totalPnl.abs().toStringAsFixed(0)}');
      }
      if (bt.missing.isNotEmpty) {
        b.writeln('Data nahi mila: ${bt.missing.join('; ')}');
      }
    }
    b.writeln('\n${report.warnings.join('\n')}');
    return b.toString();
  }
}
