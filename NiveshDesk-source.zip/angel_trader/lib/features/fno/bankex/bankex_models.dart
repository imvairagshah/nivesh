// ---------------------------------------------------------------------------
// bankex_models.dart — 1.5.78 Bankex–Bank Nifty Strategy module (PDF-based).
//
// Source: uploads/Bankex-BankNifty-Strategy-Prompt-Library.pdf (v1.0 Nov 2026)
// — Phase 0 schema (market_data.json) + Phase 2 strategy specs. Sab kuch
// rule-based (koi external AI nahi). Lot size 30 dono indexes ke liye.
// ---------------------------------------------------------------------------

/// PDF P0.2 — ek index ka snapshot + monthly option chain.
class IndexSnapshot {
  const IndexSnapshot({
    required this.name,
    required this.spot,
    required this.previousClose,
    required this.intradayHigh,
    required this.intradayLow,
    required this.atmIv,
    required this.ivRank30d,
    required this.pcr,
    required this.maxPain,
    required this.expiryDate,
    required this.dte,
    required this.chain,
    this.totalCallOi = 0,
    this.totalPutOi = 0,
  });

  final String name; // 'BANKNIFTY' | 'BANKEX'
  final double spot;
  final double previousClose;
  final double intradayHigh;
  final double intradayLow;
  final double atmIv;
  final double ivRank30d;
  final double pcr;
  final double maxPain;
  final DateTime expiryDate;
  final int dte;
  final double totalCallOi;
  final double totalPutOi;
  final List<ChainRow> chain;

  double get changePct =>
      previousClose == 0 ? 0 : (spot - previousClose) / previousClose * 100;
}

/// PDF P0.2 option_chain[] row — strike + dono side ltp/iv/oi/greeks.
class ChainRow {
  const ChainRow({
    required this.strike,
    required this.callLtp,
    required this.callIv,
    required this.callOi,
    required this.callDelta,
    required this.callTheta,
    required this.callVega,
    required this.putLtp,
    required this.putIv,
    required this.putOi,
    required this.putDelta,
    required this.putTheta,
    required this.putVega,
  });

  final double strike;
  final double callLtp;
  final double callIv;
  final double callOi;
  final double callDelta;
  final double callTheta;
  final double callVega;
  final double putLtp;
  final double putIv;
  final double putOi;
  final double putDelta;
  final double putTheta;
  final double putVega;
}

/// PDF P0.2 ka poora market_data.json.
class MarketSnapshot {
  const MarketSnapshot({
    required this.bankNifty,
    required this.bankex,
    required this.indiaVix,
    required this.vixRank30d,
    required this.advances,
    required this.declines,
    required this.capitalAvailable,
    this.isDemo = false,
    this.warnings = const [],
  });

  final IndexSnapshot bankNifty;
  final IndexSnapshot bankex;
  final double indiaVix;
  final double vixRank30d;
  final int advances;
  final int declines;
  final double capitalAvailable;

  /// True = sample numbers (clearly labelled) — live data nahi.
  final bool isDemo;

  /// Live load ke partial gaps (1.5.83) — e.g. "BANKEX: greeks nahi mili".
  /// Screen inhe LIVE banner ke neeche amber note ki tarah dikhata hai.
  final List<String> warnings;
}

/// Ek strategy leg — PDF "POSITION CONSTRUCTION" table row.
class StrategyLeg {
  const StrategyLeg({
    required this.instrument,
    required this.action, // 'Buy' | 'Sell'
    required this.strike,
    required this.distancePct,
    required this.lots,
    required this.premium,
  });

  final String instrument; // 'BN PE' | 'BANKEX CE' ...
  final String action;
  final double strike;
  final double distancePct;
  final int lots;
  final double premium; // per unit

  double get total => premium * 30 * lots; // lot size 30 (PDF rule)
  bool get isBuy => action == 'Buy';
}

/// PDF OUTPUT FORMAT — poora strategy report.
class StrategyReport {
  StrategyReport({
    required this.id,
    required this.title,
    required this.underlying,
    required this.regimeFit,
    required this.legs,
    required this.economics,
    required this.greeks,
    required this.entryRules,
    required this.exitRules,
    required this.adjustments,
    required this.warnings,
    this.valid = true,
    this.validationNote,
  });

  final String id; // 'P2.1' ... 'P2.10'
  final String title;
  final String underlying;
  final String regimeFit;
  final List<StrategyLeg> legs;
  final List<String> economics; // Net credit, Max P/L, BEs ...
  final List<String> greeks;
  final List<String> entryRules;
  final List<String> exitRules;
  final List<String> adjustments;
  final List<String> warnings;

  /// False = PDF constraints fail ho gaye (DTE/credit/OI) — build mat karo.
  final bool valid;
  final String? validationNote;
}

/// PDF P1.1 — regime classification report.
class RegimeReport {
  const RegimeReport({
    required this.primary,
    required this.confidence,
    required this.trendLine,
    required this.volatilityLine,
    required this.sentimentLine,
    required this.breadthLine,
    required this.recommended,
    required this.avoid,
    required this.eventRisk,
  });

  final String primary; // BULLISH ... VOLATILE-CRUSH
  final String confidence; // HIGH | MEDIUM | LOW
  final String trendLine;
  final String volatilityLine;
  final String sentimentLine;
  final String breadthLine;
  final List<String> recommended; // ranked strategy ids/titles
  final List<String> avoid;
  final String eventRisk;
}
