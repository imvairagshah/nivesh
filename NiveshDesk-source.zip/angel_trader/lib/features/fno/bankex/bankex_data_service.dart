// ---------------------------------------------------------------------------
// bankex_data_service.dart — LIVE market_data.json builder (PDF P0.2).
//
// 1.5.85: har step ka **diagnostic** — "live data nahi aa raha" ka jawab ab
// guess nahi, screen par step-by-step ✅/❌ (Book → Spot → Quotes → Chain →
// Greeks). Fatal step fail = demo fallback + wahi step ka message.
//
// Sources (sab existing app layers):
//   • chain/expiry — FnoContractDao (local option book) + asScrip()
//   • LTP/spot/VIX — MarketDataService.fetchQuotesFull / fetchLtp
//   • IV/strike    — MarketDataService.fetchOptionGreeks (broker greeks)
//
// Honest gaps (nahi milta = guess NAHI, sentinel -1 + UI note):
//   • OI book me nahi → PCR/max-pain = -1 (unknown). Liquidity gate manual.
//   • IV rank 30d history nahi → -1 (P2.9 gate unknown par skip+note).
//   • Breadth (advances/declines) source nahi → 0/0 (regime me noted).
//   • IV greeks fail = NON-fatal (atmIv -1 + amber note), snapshot live rehta.
// ---------------------------------------------------------------------------

import '../../../core/utils/markets.dart';
import '../../../data/local/app_database.dart';
import '../../../data/local/dao/fno_contract_dao.dart';
import '../../../data/local/dao/scrip_dao.dart';
import '../../../data/local/dao/settings_dao.dart';
import '../../../data/remote/dto/quote.dart';
import '../../../data/remote/dto/scrip.dart';
import '../../../services/auth_service.dart';
import '../../../services/market_data_service.dart';
import '../../../services/scrip_master_service.dart';
import '../../../services/secure_store.dart';
import '../../../services/study_market_data.dart';
import '../study/black_scholes.dart';
import 'bankex_models.dart';

/// Ek diagnostic step — screen isi list ko ✅/❌ me dikhata hai.
class DiagStep {
  const DiagStep({
    required this.label,
    required this.ok,
    required this.detail,
    this.fatal = true,
  });

  final String label;
  final bool ok;
  final String detail;

  /// `false` = gap hai par snapshot still live (e.g. IV unknown).
  final bool fatal;
}

/// Fatal step fail — kaunsa step, kya message.
class LiveLoadFailure implements Exception {
  const LiveLoadFailure(this.step, this.detail);
  final String step;
  final String detail;

  @override
  String toString() => '$step — $detail';
}

/// `load()` ka result: ya live snapshot, ya step-wise wajah.
class LiveDiagnosis {
  const LiveDiagnosis({required this.steps, this.snapshot});
  final List<DiagStep> steps;
  final MarketSnapshot? snapshot;

  bool get ok => snapshot != null;

  /// Pehla fatal fail (agar hua).
  DiagStep? get failure {
    for (final s in steps) {
      if (!s.ok && s.fatal) return s;
    }
    return null;
  }
}

class LiveSnapshotLoader {
  LiveSnapshotLoader._();

  /// Poora load + step-wise diagnosis (screen yahi call karta hai).
  ///
  /// 1.5.88: `auth`/`marketData`/`scripMaster` app ke providers se pass karo —
  /// tab wahi logged-in session use hota hai (naya instance banane par
  /// SecureStore se restore hota hai, par shared instance better hai).
  static Future<LiveDiagnosis> diagnose({
    AuthService? auth,
    MarketDataService? marketData,
    ScripMasterService? scripMaster,
  }) async {
    final steps = <DiagStep>[];
    try {
      final snapshot =
          await _build(steps, auth, marketData, scripMaster);
      steps.add(const DiagStep(
        label: 'Snapshot',
        ok: true,
        detail: 'LIVE — dono index ka chain + spot mil gaya',
      ));
      return LiveDiagnosis(steps: steps, snapshot: snapshot);
    } on LiveLoadFailure catch (e) {
      steps.add(DiagStep(label: e.step, ok: false, detail: e.detail));
      return LiveDiagnosis(steps: steps);
    } catch (e) {
      steps.add(DiagStep(
        label: 'Unexpected',
        ok: false,
        detail: '$e',
      ));
      return LiveDiagnosis(steps: steps);
    }
  }

  /// Purana API — sirf snapshot ya exception (callers ke liye).
  static Future<MarketSnapshot> load() async {
    final d = await diagnose();
    if (d.snapshot != null) return d.snapshot!;
    final f = d.failure;
    throw LiveLoadFailure(f?.label ?? 'Live load', f?.detail ?? 'unknown');
  }

  static Future<MarketSnapshot> _build(
    List<DiagStep> steps,
    AuthService? authIn,
    MarketDataService? marketDataIn,
    ScripMasterService? scripMasterIn,
  ) async {
    final database = AppDatabase.instance;
    final auth = authIn ?? AuthService(store: SecureStore());
    if (authIn == null) await auth.restore(); // naya instance — session load
    final marketData = marketDataIn ?? MarketDataService(auth: auth);
    final contractsDao = FnoContractDao(database);
    final scripMaster = scripMasterIn ??
        ScripMasterService(
          scripDao: ScripDao(database),
          settingsDao: SettingsDao(database),
        );

    // 0. Login — har quote/greek call isse guzarta hai; pehle hi saaf bata do.
    bool sessionOk = false;
    String sessionDetail = 'session check fail';
    try {
      sessionOk = await auth.ensureValidSession();
      sessionDetail = sessionOk
          ? 'Angel session active'
          : 'login nahi / session expired — Settings → Angel One login karo';
    } catch (e) {
      sessionDetail = 'login check error: $e';
    }
    steps.add(DiagStep(
      label: 'Angel login',
      ok: sessionOk,
      detail: sessionDetail,
    ));
    if (!sessionOk) {
      throw LiveLoadFailure('Angel login', sessionDetail);
    }

    final warnings = <String>[];
    final bn = await _loadIndex(
      steps: steps,
      warnings: warnings,
      name: 'BANKNIFTY',
      underlying: 'BANKNIFTY',
      spotNames: const ['NIFTY BANK', 'BANKNIFTY'],
      contractsDao: contractsDao,
      marketData: marketData,
      scripMaster: scripMaster,
    );
    final bex = await _loadIndex(
      steps: steps,
      warnings: warnings,
      name: 'BANKEX',
      underlying: 'BANKEX',
      spotNames: const ['BANKEX', 'BSE BANKEX'],
      contractsDao: contractsDao,
      marketData: marketData,
      scripMaster: scripMaster,
    );

    double vix = -1;
    try {
      final resolver = await scripMaster.resolver();
      final vixScrip = resolver.resolve('INDIA VIX').scrip;
      if (vixScrip != null) {
        final q = await marketData.fetchLtp([vixScrip]);
        if (q.isNotEmpty) vix = q.values.first.value;
      }
    } catch (_) {}

    return MarketSnapshot(
      bankNifty: bn,
      bankex: bex,
      indiaVix: vix,
      vixRank30d: -1,
      advances: 0,
      declines: 0,
      capitalAvailable: 250000,
      isDemo: false,
      warnings: warnings,
    );
  }

  static Future<IndexSnapshot> _loadIndex({
    required List<DiagStep> steps,
    required List<String> warnings,
    required String name,
    required String underlying,
    required List<String> spotNames,
    required FnoContractDao contractsDao,
    required MarketDataService marketData,
    required ScripMasterService scripMaster,
  }) async {
    // 1. Book: future expiries.
    List<DateTime> expiries;
    try {
      expiries = await contractsDao.expiries(
          underlying, from: DateTime.now().subtract(const Duration(days: 1)));
    } catch (e) {
      throw LiveLoadFailure('$name · book', 'option book read fail: $e');
    }
    if (expiries.isEmpty) {
      throw LiveLoadFailure(
        '$name · book',
        'local option book me koi future expiry nahi — is screen ke '
            '"Data Sync" card se bhavcopy sync chalao',
      );
    }
    final expiry = expiries.first;

    // 2. Chain rows.
    List<FnoContract> rows;
    try {
      rows = await contractsDao.chainOn(underlying, expiry);
    } catch (e) {
      throw LiveLoadFailure('$name · chain', 'chain read fail: $e');
    }
    if (rows.length < 6) {
      throw LiveLoadFailure('$name · chain',
          '${rows.length} rows mile (6+ chahiye) — bhavcopy sync dobara chalao');
    }
    steps.add(DiagStep(
      label: '$name · book',
      ok: true,
      detail: '${rows.length} contracts · ${expiries.length} expiries · '
          'nearest ${_d(expiry)}',
    ));

    // 3. Spot.
    double spot = -1;
    double prev = -1;
    double high = -1;
    double low = -1;
    String spotSource = '';
    // 1.5.89 — index rows scrip table me nahi hote, isliye master sync ke waqt
    // cache kiye tokens se spot lo (NIFTY BANK / BANKEX).
    final indexTokens = await scripMaster.cachedIndexTokens();
    for (final nm in spotNames) {
      final token = indexTokens[ScripMasterService.normIndex(nm)];
      if (token == null || token.isEmpty) continue;
      try {
        final scrip = Scrip(
          token: token,
          symbol: nm.toUpperCase(),
          name: nm,
          exchange: Exchange.nse,
        );
        final qs = await marketData.fetchQuotesFull([scrip]);
        if (qs.isEmpty) continue;
        final MarketQuote q = qs.values.first;
        if (q.ltp <= 0) continue;
        spot = q.ltp;
        prev = q.previousClose ?? -1;
        high = q.high ?? -1;
        low = q.low ?? -1;
        spotSource = '$nm (index token)';
        break;
      } catch (_) {}
    }
    final resolver = await scripMaster.resolver();
    if (spot <= 0) {
      for (final nm in spotNames) {
        try {
          final s = resolver.resolve(nm).scrip;
          if (s == null) continue;
          final qs = await marketData.fetchQuotesFull([s]);
          if (qs.isEmpty) continue;
          final MarketQuote q = qs.values.first;
          if (q.ltp <= 0) continue;
          spot = q.ltp;
          prev = q.previousClose ?? -1;
          high = q.high ?? -1;
          low = q.low ?? -1;
          spotSource = nm;
          break;
        } catch (_) {}
      }
    }
    // 1.5.87 — spot na mile to chain se ATM estimate (CE≈PE wala strike).
    // Index scrip master me na ho (BSE index kabhi kabhi missing) tab bhi
    // module chalta rahe — par UI par saaf warning ke saath (guess nahi,
    // chain se derived).
    var spotEstimated = false;
    if (spot <= 0) {
      final sample = atmAroundMedian(rows, take: 40);
      if (sample.isNotEmpty) {
        try {
          final qs = await marketData
              .fetchQuotesFull([for (final r in sample) r.asScrip()]);
          final byStrike = <double, List<double>>{}; // strike → [ce, pe]
          for (final r in sample) {
            final q = qs[r.token] ?? qs[r.symbol];
            final ltp = q?.ltp ?? -1;
            if (ltp <= 0) continue;
            final slot = byStrike.putIfAbsent(r.strike, () => [-1, -1]);
            if (r.optionType == 'CE') {
              slot[0] = ltp;
            } else {
              slot[1] = ltp;
            }
          }
          var bestDiff = double.infinity;
          var bestStrike = -1.0;
          for (final e in byStrike.entries) {
            final ce = e.value[0], pe = e.value[1];
            if (ce <= 0 || pe <= 0) continue;
            final diff = (ce - pe).abs();
            if (diff < bestDiff) {
              bestDiff = diff;
              bestStrike = e.key;
            }
          }
          if (bestStrike > 0) {
            spot = bestStrike;
            prev = bestStrike;
            high = bestStrike;
            low = bestStrike;
            spotEstimated = true;
            spotSource = 'chain ATM estimate';
            warnings.add('$name: index spot quote nahi mili — spot '
                '\u20b9${bestStrike.toStringAsFixed(0)} chain ke ATM strike '
                'se estimate kiya (CE\u2248PE). %OTM strikes isliye ~1 strike '
                'shift ho sakte hain.'
                '${indexTokens.isEmpty ? ' (Index token cache khaali — ek baar '
                    '"Data Sync" chalao, phir real spot aayega.)' : ''}');
          }
        } catch (_) {}
      }
    }
    if (spot <= 0) {
      throw LiveLoadFailure(
        '$name · spot',
        'spot quote nahi mili (${spotNames.join(" / ")}) aur chain se bhi '
            'estimate nahi hua — login/session ya market-data subscription '
            'check karo',
      );
    }
    steps.add(DiagStep(
      label: '$name · spot',
      ok: !spotEstimated,
      fatal: false,
      detail: spotEstimated
          ? '\u20b9${spot.toStringAsFixed(1)} (estimate — index quote nahi mila)'
          : '\u20b9${spot.toStringAsFixed(1)} ($spotSource)',
    ));

    // 1.5.87 — sirf ATM ke aas-paas ke strikes ke quotes.
    //
    // Kyun: chain me 1000+ contracts hote hain; poore chain ke quotes maangna
    // = ~25 batched call per index, sequential — Angel ki rate limit se chunks
    // fail hone lagte hain aur live load mar jaata hai ("quotes mile" error).
    // Strategies ko max ~4.5% OTM chahiye, isliye ATM ±6% window kaafi hai
    // (1-2 call). Window ke bahar ke strikes chain me nahi aate.
    final windowRows = windowAround(rows, spot, pct: 6.0);
    if (windowRows.length < rows.length) {
      steps.add(DiagStep(
        label: '$name · window',
        ok: true,
        detail: '${windowRows.length}/${rows.length} contracts (ATM ±6%) — '
            'quote calls kam, rate-limit safe',
      ));
    }

    // 4. Option quotes (sirf window).
    final scrips = <String, Scrip>{};
    for (final r in windowRows) {
      final s = r.asScrip();
      if (s.token.isNotEmpty) scrips[s.token] = s;
    }
    Map<String, MarketQuote> quotes;
    try {
      quotes = await marketData.fetchQuotesFull(scrips.values.toList());
    } catch (e) {
      throw LiveLoadFailure('$name · quotes',
          'option quotes fail (${scrips.length} tokens): $e');
    }
    var quoted = 0;
    for (final r in windowRows) {
      final q = quotes[r.token] ?? quotes[r.symbol];
      if (q != null && q.ltp > 0) quoted++;
    }
    // 1.5.85 — segment guess galat ho sakta hai (BFO vs NFO). Khaali quotes
    // par doosra segment ek hi baar try karo, phir hi fail karo.
    var segmentTried = 'primary';
    if (quoted < 5) {
      final alt = <String, Scrip>{};
      for (final r in windowRows) {
        final s = r.asScrip();
        if (s.token.isEmpty) continue;
        alt[s.token] = Scrip(
          token: s.token,
          symbol: s.symbol,
          name: s.name,
          exchange:
              s.exchange == Exchange.bfo ? Exchange.nfo : Exchange.bfo,
        );
      }
      try {
        final altQuotes =
            await marketData.fetchQuotesFull(alt.values.toList());
        var altCount = 0;
        for (final r in windowRows) {
          final q = altQuotes[r.token] ?? altQuotes[r.symbol];
          if (q != null && q.ltp > 0) altCount++;
        }
        if (altCount > quoted) {
          quotes = altQuotes;
          quoted = altCount;
          segmentTried = 'alternate segment';
        }
      } catch (_) {}
    }
    if (quoted < 5) {
      throw LiveLoadFailure(
        '$name · quotes',
        '${windowRows.length} window contracts me se sirf $quoted ke quotes '
            'mile (dono segment try kiye) — market-data subscription ya '
            'symbol token mapping check karo',
      );
    }
    steps.add(DiagStep(
      label: '$name · quotes',
      ok: true,
      detail: '$quoted/${windowRows.length} window contracts ke LTP mile '
          '($segmentTried)',
    ));

    // 5. Greeks (non-fatal).
    OptionGreekBatch greeks;
    try {
      greeks = await marketData.fetchOptionGreeks(
        underlying: underlying,
        expiryLabel: rows.first.expiryLabel,
      );
    } catch (e) {
      greeks = OptionGreekBatch(byStrike: const {}, error: '$e');
    }

    // 1.5.89 — IV per strike: broker greeks pehle; na mile to premium se
    // Black-Scholes (BSE/BANKEX ke liye broker greeks "No Data Available"
    // deta hai, isliye ye fallback zaroori hai).
    final dte = expiry.difference(DateTime.now()).inDays;
    final ivByKey = <String, double>{};
    var brokerIvCount = 0;
    var bsIvCount = 0;
    double currentLtpOf(FnoContract r) {
      final q = quotes[r.token] ?? quotes[r.symbol];
      return q?.ltp ?? -1;
    }

    for (final r in windowRows) {
      final key = MarketDataService.greeksKey(r.strike, r.optionType);
      final brokerIv = greeks.byStrike[key] ?? -1;
      if (brokerIv > 0) {
        ivByKey[key] = brokerIv;
        brokerIvCount++;
        continue;
      }
      final ltp = currentLtpOf(r);
      if (ltp <= 0 || dte <= 0) continue;
      final solved = impliedVolatility(
        type: r.optionType == 'CE' ? OptionType.call : OptionType.put,
        premium: ltp,
        spot: spot,
        strike: r.strike,
        daysToExpiry: dte,
      );
      if (solved.isSolved && solved.iv! > 0) {
        ivByKey[key] = solved.iv! * 100; // percent
        bsIvCount++;
      }
    }

    final chain = <ChainRow>[];
    var atmIvSum = 0.0;
    var atmIvCount = 0;
    for (final r in windowRows) {
      final key = MarketDataService.greeksKey(r.strike, r.optionType);
      final iv = ivByKey[key] ?? -1;
      if ((r.strike - spot).abs() < spot * 0.015 && iv > 0) {
        atmIvSum += iv;
        atmIvCount++;
      }
    }
    for (final r in windowRows) {
      final q = quotes[r.token] ?? quotes[r.symbol];
      final ltp = q?.ltp ?? -1;
      if (ltp <= 0) continue;
      final key = MarketDataService.greeksKey(r.strike, r.optionType);
      final iv = ivByKey[key] ?? -1;
      final existing = chain.where((c) => c.strike == r.strike);
      if (r.optionType == 'CE') {
        final put = existing.isEmpty ? null : existing.first;
        chain.removeWhere((c) => c.strike == r.strike);
        chain.add(ChainRow(
          strike: r.strike,
          callLtp: ltp,
          callIv: iv,
          callOi: -1,
          callDelta: -1,
          callTheta: -1,
          callVega: -1,
          putLtp: put?.putLtp ?? -1,
          putIv: put?.putIv ?? -1,
          putOi: -1,
          putDelta: -1,
          putTheta: -1,
          putVega: -1,
        ));
      } else {
        final call = existing.isEmpty ? null : existing.first;
        chain.removeWhere((c) => c.strike == r.strike);
        chain.add(ChainRow(
          strike: r.strike,
          callLtp: call?.callLtp ?? -1,
          callIv: call?.callIv ?? -1,
          callOi: -1,
          callDelta: -1,
          callTheta: -1,
          callVega: -1,
          putLtp: ltp,
          putIv: iv,
          putOi: -1,
          putDelta: -1,
          putTheta: -1,
          putVega: -1,
        ));
      }
    }
    if (chain.length < 5) {
      throw LiveLoadFailure('$name · chain',
          'quotes mil gaye par chain ${chain.length} strikes ki bani (5+ chahiye)');
    }

    var atmIv = atmIvCount > 0
        ? atmIvSum / atmIvCount
        : (ivByKey.isNotEmpty ? ivByKey.values.first : -1.0);
    final ivSourceLabel = bsIvCount > 0 && brokerIvCount == 0
        ? 'Black-Scholes (premium se)'
        : (bsIvCount > 0 ? 'broker + Black-Scholes' : 'broker greeks');
    if (atmIv <= 0) {
      atmIv = -1;
      warnings.add('$name: IV kisi bhi source se nahi bani — '
          '${greeks.error ?? "greek endpoint empty"}; IV-based gates '
          '(P2.9 IVRank / P2.10 differential) unknown rahenge.');
      steps.add(DiagStep(
        label: '$name · IV',
        ok: false,
        fatal: false,
        detail: 'IV unknown (premiums real hain) — ${greeks.error ?? "empty"}',
      ));
    } else {
      steps.add(DiagStep(
        label: '$name · IV',
        ok: true,
        detail: 'ATM IV ${atmIv.toStringAsFixed(1)} · '
            '$ivSourceLabel ($brokerIvCount broker / $bsIvCount BS strikes)',
      ));
      if (bsIvCount > 0 && brokerIvCount == 0) {
        warnings.add('$name: broker greeks nahi mile — IV premium se '
            'Black-Scholes se nikali gayi (approx, ±1 vol pt).');
      }
    }

    return IndexSnapshot(
      name: name,
      spot: spot,
      previousClose: prev > 0 ? prev : spot,
      intradayHigh: high > 0 ? high : spot,
      intradayLow: low > 0 ? low : spot,
      atmIv: atmIv,
      ivRank30d: -1, // honest unknown
      pcr: -1, // OI source pending
      maxPain: -1,
      expiryDate: expiry,
      dte: expiry.difference(DateTime.now()).inDays,
      chain: chain..sort((a, b) => a.strike.compareTo(b.strike)),
    );
  }

  /// ATM ke aas-paas ke strikes (pct % band) — agar band bahut chhota nikle
  /// to nearest 30 strikes (kam se kam 5 chahiye).
  static List<FnoContract> windowAround(List<FnoContract> rows, double spot,
      {double pct = 6.0}) {
    final band = <FnoContract>[
      for (final r in rows)
        if ((r.strike - spot).abs() <= spot * pct / 100) r,
    ];
    if (band.length >= 10) return band;
    final sorted = [...rows]
      ..sort((a, b) =>
          (a.strike - spot).abs().compareTo((b.strike - spot).abs()));
    return sorted.take(30).toList();
  }

  /// Chain ke median strike ke aas-paas ka chhota sample (spot estimate ke liye).
  static List<FnoContract> atmAroundMedian(List<FnoContract> rows,
      {int take = 40}) {
    if (rows.isEmpty) return const [];
    final strikes = rows.map((r) => r.strike).toList()..sort();
    final median = strikes[strikes.length ~/ 2];
    final sorted = [...rows]
      ..sort((a, b) =>
          (a.strike - median).abs().compareTo((b.strike - median).abs()));
    return sorted.take(take).toList();
  }

  static String _d(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
}
