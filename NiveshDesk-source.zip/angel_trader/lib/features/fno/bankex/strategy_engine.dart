// ---------------------------------------------------------------------------
// strategy_engine.dart — PDF Phase 2: 6 strategy builders (rule-based).
// Har builder PDF ke CONSTRUCTION RULES follow karta hai (strike %OTM, lots,
// credit targets, DTE gates, OI>5000, slippage) + OUTPUT FORMAT sections.
// Lot size 30 (PDF: post Dec 2025 revision, dono indexes). Numbers rounded
// to rupee — live broker chain se validate karna zaroori (disclaimer).
// ---------------------------------------------------------------------------


import 'bankex_models.dart';

class StrategyEngine {
  StrategyEngine._();

  static const int lotSize = 30; // PDF rule — BN + Bankex both
  static const double slippageBn = 0.50; // rupee per leg (PDF)
  static const double slippageBex = 3.00; // rupee per leg (PDF)
  static const double minOi = 5000; // PDF liquidity gate

  /// Chain me %OTM ke sabse paas ka strike row (CE ke liye spot upar, PE neeche).
  static ChainRow? pickStrike(
      IndexSnapshot index, String side, double pctOtm) {
    final target = side == 'CE'
        ? index.spot * (1 + pctOtm / 100)
        : index.spot * (1 - pctOtm / 100);
    ChainRow? best;
    double bestDist = double.infinity;
    for (final r in index.chain) {
      if (side == 'CE' ? r.callLtp <= 0 : r.putLtp <= 0) continue;
      final d = (r.strike - target).abs();
      if (d < bestDist) {
        bestDist = d;
        best = r;
      }
    }
    return best;
  }

  static double _distPct(IndexSnapshot i, double strike) =>
      i.spot == 0 ? 0 : (strike - i.spot) / i.spot * 100;

  static String _r(double v) => v.round().toString();

  // ==== 1.5.82 SHARED SIDE RULE (user) ===================================
  // Jiski expiry PEHLE us index pe SHORT (near-expiry premium sabse tez decay),
  // jiski expiry BAAD ME us pe LONG. P2.3 / P2.7 / P2.8 / P2.10 — sab yahi
  // rule use karte hain, taaki chaaron strategies consistent rahein.
  // Tie (dono expiry same moment) → higher-IV index short (fallback) — phir
  // bhi data-driven, koi index hardcoded nahi.
  static bool expiryTie(MarketSnapshot m) =>
      m.bankex.expiryDate.isAtSameMomentAs(m.bankNifty.expiryDate);

  static bool shortBankex(MarketSnapshot m) => expiryTie(m)
      ? m.bankex.atmIv > m.bankNifty.atmIv
      : m.bankex.expiryDate.isBefore(m.bankNifty.expiryDate);

  /// Report me dikhne wali transparent side-rule line.
  static String sideRuleLine(MarketSnapshot m, IndexSnapshot s, IndexSnapshot h,
          String sTag, String hTag) =>
      expiryTie(m)
          ? 'Side rule (tie — same expiry): $sTag short (IV '
              '${s.atmIv.toStringAsFixed(1)} higher), $hTag long'
          : 'Side rule: $sTag short (expiry pehle — DTE ${s.dte}), '
              '$hTag long (DTE ${h.dte})';

  /// Shared PDF boilerplate — har report ke end me.
  static const disclaimer =
      'DISCLAIMER: Ye output market data + PDF rules se bana hai — educational '
      'hai. Sab strikes/premiums/margins live broker option chain se validate '
      'karo. F&O trading me substantial risk of loss hai.';

  // ==== P2.3 Cross-Expiry Calendar (short earlier-expiry, long later) =====
  static StrategyReport crossExpiryCalendar(MarketSnapshot m, int lots) {
    // 1.5.82: sides expiry se (pehle wala short, baad wala long) — pehle BN
    // hardcoded tha.
    final sellBex = shortBankex(m);
    final s = sellBex ? m.bankex : m.bankNifty;
    final h = sellBex ? m.bankNifty : m.bankex;
    final sTag = sellBex ? 'BANKEX' : 'BN';
    final hTag = sellBex ? 'BN' : 'BANKEX';
    final gap = h.expiryDate.difference(s.expiryDate).inDays;
    final sellCe = pickStrike(s, 'CE', 1.5);
    final sellPe = pickStrike(s, 'PE', 1.5);
    final buyCe = pickStrike(h, 'CE', 1.5);
    final buyPe = pickStrike(h, 'PE', 1.5);
    if (sellCe == null || sellPe == null || buyCe == null || buyPe == null) {
      return _invalid('P2.3', 'Cross-Expiry Calendar', 'Chain incomplete');
    }
    final legs = [
      StrategyLeg(
          instrument: '$sTag CE (near expiry)',
          action: 'Sell',
          strike: sellCe.strike,
          distancePct: _distPct(s, sellCe.strike),
          lots: lots,
          premium: sellCe.callLtp),
      StrategyLeg(
          instrument: '$sTag PE (near expiry)',
          action: 'Sell',
          strike: sellPe.strike,
          distancePct: _distPct(s, sellPe.strike),
          lots: lots,
          premium: sellPe.putLtp),
      StrategyLeg(
          instrument: '$hTag CE (far expiry)',
          action: 'Buy',
          strike: buyCe.strike,
          distancePct: _distPct(h, buyCe.strike),
          lots: lots,
          premium: buyCe.callLtp),
      StrategyLeg(
          instrument: '$hTag PE (far expiry)',
          action: 'Buy',
          strike: buyPe.strike,
          distancePct: _distPct(h, buyPe.strike),
          lots: lots,
          premium: buyPe.putLtp),
    ];
    final net = _netCredit(legs); // -ve = debit (PDF expects debit 15–40k/2 lots)
    final problems = <String>[
      if (s.dte < 8 || s.dte > 20)
        '$sTag DTE ${s.dte} — PDF window 8–20 din ke bahar',
      if (gap < 3 || gap > 7)
        'Expiry gap $gap din — PDF: later-expiry index 3–7 din baad hona chahiye',
    ];
    return StrategyReport(
      id: 'P2.3',
      title: 'Cross-Expiry Calendar Spread (BN + Bankex)',
      underlying: '$sTag short strangle (DTE ${s.dte}) + $hTag long strangle '
          '(DTE ${h.dte})',
      regimeFit: '2–5 din ka expiry gap — theta differential + cross-expiry '
          'window (near expiry ke baad sirf far legs decay).',
      legs: legs,
      economics: [
        'Net ${net >= 0 ? 'Credit' : 'Debit'}: ₹${_r(net.abs())} '
            '(PDF expect: debit ₹15k–40k per 2 lots)',
        'Edge: $sTag shorts faster theta; near expiry ke baad $hTag legs akela decay',
        'Max Loss: correlation breakdown ya IV expansion — defined nahi bina wings',
      ],
      greeks: _greekSum(legs, 'Net +theta (short side faster), +vega on long expiry'),
      entryRules: [
        sideRuleLine(m, s, h, sTag, hTag),
        '$sTag DTE 8–20 (abhi ${s.dte}); gap $gap din; far-side ATM bid-ask < 5₹ verify',
        'Leg sequencing: pehle $hTag buy (bharne me slow), phir $sTag sell',
      ],
      exitRules: [
        '$sTag expiry day = decision point: $hTag legs roll ya book',
        'Time stop: near expiry se pehle mandatory review',
      ],
      adjustments: [
        '$sTag sharp move 3 din pehle → correlation risk, hedge reduce',
        'IV expansion → dono side loss; structure reduce by 50%',
      ],
      warnings: [
        'Correlation breakdown risk; Bankex hedge legs ki liquidity low',
        disclaimer,
      ],
      valid: problems.isEmpty,
      validationNote: problems.isEmpty ? null : problems.join('\n'),
    );
  }

  // ==== P2.6 Long Straddle / Strangle (Volatility Long) ===================
  static StrategyReport longStraddle(MarketSnapshot m, int lots, bool straddle) {
    // PDF: lower-IV index choose karo (cheap buying); <0.5 diff = BN default.
    final useBex = m.bankex.atmIv < m.bankNifty.atmIv - 0.5;
    final i = useBex ? m.bankex : m.bankNifty;
    final tag = useBex ? 'BANKEX' : 'BN';
    final otm = straddle ? 0.0 : 1.5;
    final ce = pickStrike(i, 'CE', otm);
    final pe = pickStrike(i, 'PE', otm);
    if (ce == null || pe == null) {
      return _invalid('P2.6', 'Long Straddle/Strangle', 'Chain incomplete');
    }
    final legs = [
      StrategyLeg(
          instrument: '$tag CE',
          action: 'Buy',
          strike: ce.strike,
          distancePct: _distPct(i, ce.strike),
          lots: lots,
          premium: ce.callLtp),
      StrategyLeg(
          instrument: '$tag PE',
          action: 'Buy',
          strike: pe.strike,
          distancePct: _distPct(i, pe.strike),
          lots: lots,
          premium: pe.putLtp),
    ];
    final net = -_netCredit(legs);
    final units = lotSize * lots;
    final problems = <String>[
      if (i.dte < 10) 'DTE ${i.dte} < 10 — move develop hone ke liye time chahiye',
    ];
    return StrategyReport(
      id: 'P2.6',
      title: straddle ? 'Long Straddle (Vol Long)' : 'Long Strangle (Vol Long)',
      underlying: '${i.name} (monthly) — lower IV index (BN ${m.bankNifty.atmIv
          .toStringAsFixed(1)} vs Bankex ${m.bankex.atmIv.toStringAsFixed(1)})',
      regimeFit: 'Volatility expansion — straddle: 2–3% move, strangle: 3–5% '
          'move expectation.',
      legs: legs,
      economics: [
        'Net Debit: ₹${_r(net)} = MAX LOSS (defined)',
        'Upside BE: ${_r(ce.strike + net / units)} · Downside BE: ${_r(pe.strike - net / units)}',
        'Profit: spot BE ke bahar jaaye jitna zyada',
      ],
      greeks: _greekSum(legs, 'Net +vega (IV up = profit), −theta (roz decay)'),
      entryRules: [
        'DTE ≥ 10 (abhi ${i.dte}); OI > 5000; max 2 lots (risk zyada)',
        'Slippage: BN 0.5₹/leg, Bankex 3–5₹/leg',
      ],
      exitRules: [
        'Profit: move ke baad IV spike pe book (50–100% premium)',
        'SL: 50% debit; Time stop: DTE-5 pe close',
      ],
      adjustments: ['Bina move flat rahe → theta roz khaata hai; DTE-5 pe exit'],
      warnings: [
        'Time decay enemy hai — move na aaya to debit doobta hai',
        disclaimer,
      ],
      valid: problems.isEmpty,
      validationNote: problems.isEmpty ? null : problems.join('\n'),
    );
  }

  // ==== P2.7 Short Strangle + Cross-Index Hedge ===========================
  static StrategyReport shortStrangleHedged(MarketSnapshot m, int lots) {
    // 1.5.82 user rule: sell = EARLIER expiry index, wings = LATER expiry.
    // (Pehle higher-IV se chalta tha.)
    final sellBex = shortBankex(m);
    final s = sellBex ? m.bankex : m.bankNifty;
    final h = sellBex ? m.bankNifty : m.bankex;
    final sTag = sellBex ? 'BANKEX' : 'BN';
    final hTag = sellBex ? 'BN' : 'BANKEX';
    final sellCe = pickStrike(s, 'CE', 1.75);
    final sellPe = pickStrike(s, 'PE', 1.75);
    final hedgeCe = pickStrike(h, 'CE', 4.5);
    final hedgePe = pickStrike(h, 'PE', 4.5);
    if (sellCe == null || sellPe == null || hedgeCe == null || hedgePe == null) {
      return _invalid('P2.7', 'Short Strangle + Hedge', 'Chain incomplete');
    }
    final legs = [
      StrategyLeg(
          instrument: '$sTag CE',
          action: 'Sell',
          strike: sellCe.strike,
          distancePct: _distPct(s, sellCe.strike),
          lots: lots,
          premium: sellCe.callLtp),
      StrategyLeg(
          instrument: '$sTag PE',
          action: 'Sell',
          strike: sellPe.strike,
          distancePct: _distPct(s, sellPe.strike),
          lots: lots,
          premium: sellPe.putLtp),
      StrategyLeg(
          instrument: '$hTag CE (wing)',
          action: 'Buy',
          strike: hedgeCe.strike,
          distancePct: _distPct(h, hedgeCe.strike),
          lots: lots,
          premium: hedgeCe.callLtp),
      StrategyLeg(
          instrument: '$hTag PE (wing)',
          action: 'Buy',
          strike: hedgePe.strike,
          distancePct: _distPct(h, hedgePe.strike),
          lots: lots,
          premium: hedgePe.putLtp),
    ];
    final net = _netCredit(legs);
    final problems = <String>[
      if (s.dte < 12) 'DTE ${s.dte} < 12 — PDF gate fail',
      if (net < 15000 / 2 * lots || net > 30000 / 2 * lots * 1.5)
        'Credit ₹${_r(net)} — PDF expect ₹${_r(15000 / 2 * lots)}–${_r(30000 / 2 * lots)}',
    ];
    return StrategyReport(
      id: 'P2.7',
      title: 'Short Strangle + Cross-Index Hedge',
      underlying: 'Sell $sTag (near expiry, DTE ${s.dte}) + '
          'wings $hTag (far expiry, DTE ${h.dte})',
      regimeFit: 'Rangebound + theta capture — near-expiry short, far-expiry wings.',
      legs: legs,
      economics: [
        'Net Credit: ₹${_r(net)}',
        'Max Loss: wing width difference × ${lotSize * lots} (cross-index hedge)',
        'Edge: theta on shorts + IV differential compression',
      ],
      greeks: _greekSum(legs, 'Net +theta, −vega; delta near zero'),
      entryRules: [
        sideRuleLine(m, s, h, sTag, hTag),
        'DTE ≥ 12 (abhi ${s.dte}); OI > 5000 sab strikes; max 2 lots/side',
        'Bankex side pe limit orders hi (liquidity low)',
      ],
      exitRules: [
        'Profit: 50% credit; SL: 1.5× credit ya correlation break',
        'Time stop: DTE-3 mandatory',
      ],
      adjustments: [
        'Correlation drift → hedge strengthen; Divergence sharp → position half',
      ],
      warnings: [
        'Correlation breakdown = hedge protect nahi karega',
        'Bankex legs ki liquidity risk',
        disclaimer,
      ],
      valid: problems.isEmpty,
      validationNote: problems.isEmpty ? null : problems.join('\n'),
    );
  }

  // ==== P2.8 Diagonal Ratio Backspread ===================================
  static StrategyReport diagonalRatioBackspread(
      MarketSnapshot m, int lots, bool bullish) {
    // 1.5.81+ user rule (shared): jiski expiry pehle us pe SHORT, baad wale pe
    // LONG — dynamic, live expiry dates se (tie → higher-IV fallback).
    final sellBankex = shortBankex(m);
    final s = sellBankex ? m.bankex : m.bankNifty;
    final h = sellBankex ? m.bankNifty : m.bankex;
    final sTag = sellBankex ? 'BANKEX' : 'BN';
    final hTag = sellBankex ? 'BN' : 'BANKEX';
    final side = bullish ? 'CE' : 'PE';
    final sellAtm = pickStrike(s, side, 0);
    final buyOtm = pickStrike(h, side, bullish ? 2.5 : -2.5);
    if (sellAtm == null || buyOtm == null) {
      return _invalid('P2.8', 'Diagonal Ratio Backspread', 'Chain incomplete');
    }
    final sellLots = lots; // ratio 2:3 — sell 2, buy 3 (per unit)
    final buyLots = (lots * 1.5).round();
    final legs = [
      StrategyLeg(
          instrument: '$sTag $side (ATM)',
          action: 'Sell',
          strike: sellAtm.strike,
          distancePct: _distPct(s, sellAtm.strike),
          lots: sellLots,
          premium: side == 'CE' ? sellAtm.callLtp : sellAtm.putLtp),
      StrategyLeg(
          instrument: '$hTag $side (OTM)',
          action: 'Buy',
          strike: buyOtm.strike,
          distancePct: _distPct(h, buyOtm.strike),
          lots: buyLots,
          premium: side == 'CE' ? buyOtm.callLtp : buyOtm.putLtp),
    ];
    final problems = <String>[
      if (s.dte < 10) 'DTE ${s.dte} < 10 — PDF gate fail',
    ];
    return StrategyReport(
      id: 'P2.8',
      title: 'Diagonal Ratio Backspread (${bullish ? 'Bull' : 'Bear'})',
      underlying: 'Sell $sTag ATM $side ×$sellLots lots + Buy $hTag OTM $side '
          '×$buyLots lots (2:3 ratio)',
      regimeFit: 'Strong directional view — short earlier-expiry index, long '
          'later-expiry index; 2:3 net long gamma (near leg pe theta fast).',
      legs: legs,
      economics: [
        'Net: ${_netCredit(legs) >= 0 ? 'Credit' : 'Debit'} ₹${_r(_netCredit(legs).abs())}',
        'Flat market: theta on short side profit',
        'Directional (favored): large profit (long gamma side gains)',
        'Against ya correlated big move: loss (protective wing se defined)',
      ],
      greeks: _greekSum(legs, 'Net +gamma (ratio), +/−delta by direction'),
      entryRules: [
        sideRuleLine(m, s, h, sTag, hTag),
        'DTE ≥ 10 (abhi ${s.dte}); OI > 5000; sell 2 lots max, buy 3 lots max',
        'Optional protective wing: sell-side index ka 6–8% OTM (defined risk)',
      ],
      exitRules: [
        'Profit: directional move ke baad premium book',
        'Time stop: DTE-3; without wing = undefined risk — wing strongly advised',
      ],
      adjustments: ['Delta drift → opposite delta leg add (BN futures se)'],
      warnings: [
        'Bina protective wing = undefined risk (PDF: defined-risk preference)',
        disclaimer,
      ],
      valid: problems.isEmpty,
      validationNote: problems.isEmpty ? null : problems.join('\n'),
    );
  }

  // ==== P2.9 Iron Butterfly ==============================================
  static StrategyReport ironButterfly(MarketSnapshot m, int lots) {
    final i = m.bankNifty; // PDF: BN default (ATM liquidity)
    final atm = pickStrike(i, 'CE', 0);
    final wingCe = pickStrike(i, 'CE', 3.5);
    final wingPe = pickStrike(i, 'PE', -3.5);
    if (atm == null || wingCe == null || wingPe == null) {
      return _invalid('P2.9', 'Iron Butterfly', 'Chain incomplete');
    }
    final legs = [
      StrategyLeg(
          instrument: 'BN CE (ATM body)',
          action: 'Sell',
          strike: atm.strike,
          distancePct: _distPct(i, atm.strike),
          lots: lots,
          premium: atm.callLtp),
      StrategyLeg(
          instrument: 'BN PE (ATM body)',
          action: 'Sell',
          strike: atm.strike,
          distancePct: _distPct(i, atm.strike),
          lots: lots,
          premium: atm.putLtp),
      StrategyLeg(
          instrument: 'BN CE (wing)',
          action: 'Buy',
          strike: wingCe.strike,
          distancePct: _distPct(i, wingCe.strike),
          lots: lots,
          premium: wingCe.callLtp),
      StrategyLeg(
          instrument: 'BN PE (wing)',
          action: 'Buy',
          strike: wingPe.strike,
          distancePct: _distPct(i, wingPe.strike),
          lots: lots,
          premium: wingPe.putLtp),
    ];
    final net = _netCredit(legs);
    final units = lotSize * lots;
    final wing = (wingCe.strike - atm.strike).abs();
    final problems = <String>[
      if (i.dte < 12) 'DTE ${i.dte} < 12 — PDF gate fail',
      if (i.ivRank30d >= 0 && i.ivRank30d <= 40)
        'IV rank ${i.ivRank30d.toStringAsFixed(0)} ≤ 40 — PDF: butterfly high IV rank me',
      if (net < 25000 / 2 * lots || net > 40000 / 2 * lots * 1.5)
        'Credit ₹${_r(net)} — PDF target ₹${_r(25000 / 2 * lots)}–${_r(40000 / 2 * lots)}',
    ];
    return StrategyReport(
      id: 'P2.9',
      title: 'Iron Butterfly (Max Theta)',
      underlying: 'Bank Nifty (monthly) — ATM body + 3.5% wings',
      regimeFit: 'Tight rangebound + high IV rank (>40) — ATM body highest theta.',
      legs: legs,
      economics: [
        'Net Credit: ₹${_r(net)}',
        'Max Profit: ₹${_r(net)} — spot ATM strike pe expiry',
        'Max Loss (per side): ₹${_r(wing * units - net / 2)} ≈ wing $wing × $units − side credit',
        'BEs: ${_r(atm.strike - net / units)} · ${_r(atm.strike + net / units)}',
      ],
      greeks: _greekSum(legs, 'Delta zero (ATM body), max +theta, −vega'),
      entryRules: [
        'DTE ≥ 12 (abhi ${i.dte}); IV rank > 40 (abhi ${i.ivRank30d.toStringAsFixed(0)})',
        'OI > 5000; timing 10:30–2:00; limit orders',
      ],
      exitRules: [
        'Profit: 50% credit; SL: 1.5× credit; Time stop: DTE-3',
      ],
      adjustments: ['Wing breach → us side roll out (max 1/side); second → close'],
      warnings: [
        'Profit zone narrow (ATM body) — tight range chahiye',
        if (i.ivRank30d < 0)
          'IV rank unknown (history source pending) — P2.9 ka >40 gate '
              'manually verify karo',
        disclaimer,
      ],
      valid: problems.isEmpty,
      validationNote: problems.isEmpty ? null : problems.join('\n'),
    );
  }

  // ==== P2.10 Delta-Neutral Pair Trade (Bankex vs BN) ====================
  static StrategyReport deltaNeutralPair(MarketSnapshot m, int lots) {
    final ivDiff = (m.bankNifty.atmIv - m.bankex.atmIv).abs();
    // 1.5.82 user rule: sell = EARLIER expiry, buy = LATER expiry.
    final sellBex = shortBankex(m);
    final s = sellBex ? m.bankex : m.bankNifty;
    final h = sellBex ? m.bankNifty : m.bankex;
    final sTag = sellBex ? 'BANKEX' : 'BN';
    final hTag = sellBex ? 'BN' : 'BANKEX';
    final sCe = pickStrike(s, 'CE', 0);
    final sPe = pickStrike(s, 'PE', 0);
    final hCe = pickStrike(h, 'CE', 0);
    final hPe = pickStrike(h, 'PE', 0);
    if (sCe == null || sPe == null || hCe == null || hPe == null) {
      return _invalid('P2.10', 'Delta-Neutral Pair', 'Chain incomplete');
    }
    final legs = [
      StrategyLeg(
          instrument: '$sTag CE (ATM)',
          action: 'Sell',
          strike: sCe.strike,
          distancePct: _distPct(s, sCe.strike),
          lots: lots,
          premium: sCe.callLtp),
      StrategyLeg(
          instrument: '$sTag PE (ATM)',
          action: 'Sell',
          strike: sPe.strike,
          distancePct: _distPct(s, sPe.strike),
          lots: lots,
          premium: sPe.putLtp),
      StrategyLeg(
          instrument: '$hTag CE (ATM)',
          action: 'Buy',
          strike: hCe.strike,
          distancePct: _distPct(h, hCe.strike),
          lots: lots,
          premium: hCe.callLtp),
      StrategyLeg(
          instrument: '$hTag PE (ATM)',
          action: 'Buy',
          strike: hPe.strike,
          distancePct: _distPct(h, hPe.strike),
          lots: lots,
          premium: hPe.putLtp),
    ];
    final problems = <String>[
      if (s.atmIv <= 0 || h.atmIv <= 0)
        'IV unknown (greeks source nahi mila) — IV differential gate verify '
            'nahi ho sakta; broker terminal se IV check karo'
      else if (ivDiff <= 2.5)
        'IV differential ${ivDiff.toStringAsFixed(1)} ≤ 2.5 — PDF entry gate '
            'fail (abnormal level chahiye)',
    ];
    return StrategyReport(
      id: 'P2.10',
      title: 'Delta-Neutral Pair Trade (IV Differential)',
      underlying: 'Sell $sTag ATM straddle (near expiry, IV '
          '${s.atmIv.toStringAsFixed(1)}) + Buy $hTag ATM straddle (far '
          'expiry, IV ${h.atmIv.toStringAsFixed(1)})',
      regimeFit: 'IV differential > 2.5 vol pts (abnormal) — mean reversion '
          'expectation, delta near zero.',
      legs: legs,
      economics: [
        'Net: ${_netCredit(legs) >= 0 ? 'Credit' : 'Debit'} ₹${_r(_netCredit(legs).abs())}',
        'Max Profit: IV differential compress ho jaaye',
        'Expected edge: theta differential + vega decay per day',
      ],
      greeks: _greekSum(legs, 'Delta ±2000 ke andar (near zero), net −vega'),
      entryRules: [
        sideRuleLine(m, s, h, sTag, hTag),
        'Entry condition: IV diff > 2.5 vol pts (abhi ${ivDiff.toStringAsFixed(1)})',
        'Leg sequencing: pehle $hTag buy (slow), phir $sTag sell',
        'Dono ATM strikes 0.3% of spot ke andar verify karo',
      ],
      exitRules: [
        'Profit: IV diff < 1.0 pe exit',
        'SL: 5-day correlation < 0.88 ya defined loss level',
        'Time stop: shorter-DTE side pe 7 DTE mandatory close',
      ],
      adjustments: [
        'Delta drift ±5000 → opposite delta leg (BN futures se)',
        'Correlation < 0.92 → position 50% reduce',
      ],
      warnings: [
        'Correlation breakdown risk — pair hai, guarantee nahi',
        disclaimer,
      ],
      valid: problems.isEmpty,
      validationNote: problems.isEmpty ? null : problems.join('\n'),
    );
  }

  // ==== shared ===========================================================

  static double _netCredit(List<StrategyLeg> legs) {
    var net = 0.0;
    for (final l in legs) {
      net += l.isBuy ? -l.total : l.total;
    }
    return net;
  }

  static List<String> _greekSum(List<StrategyLeg> legs, String profile) => [
        'Profile: $profile',
        'Leg-level greeks chain se report ke legs table me aate hain — '
            'broker terminal ke greeks se validate karo',
      ];

  static StrategyReport _invalid(String id, String title, String why) =>
      StrategyReport(
        id: id,
        title: title,
        underlying: '—',
        regimeFit: '—',
        legs: const [],
        economics: const [],
        greeks: const [],
        entryRules: const [],
        exitRules: const [],
        adjustments: const [],
        warnings: [disclaimer],
        valid: false,
        validationNote: why,
      );

  /// Saare builders — PDF order me (1.5.80: P2.1/2.2/2.4/2.5 user-request
  /// par remove kiye gaye).
  static List<StrategyReport> buildAll(MarketSnapshot m, int lots) => [
        crossExpiryCalendar(m, lots),
        longStraddle(m, lots, true),
        longStraddle(m, lots, false),
        shortStrangleHedged(m, lots),
        diagonalRatioBackspread(m, lots, true),
        ironButterfly(m, lots),
        deltaNeutralPair(m, lots),
      ];
}
