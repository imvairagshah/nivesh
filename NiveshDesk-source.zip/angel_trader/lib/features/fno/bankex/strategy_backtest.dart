// ---------------------------------------------------------------------------
// strategy_backtest.dart — 1.5.82 "Kal lagayi hoti to aaj?" card.
//
// Sawal: agar ye strategy KAL (pichhle trading din ke close par) lagayi hoti,
// to AAJ usme profit hua hota ya loss — aur kitna?
//
// Data (sab REAL, koi estimate nahi):
//   • Entry premium — pichhle trading din ka daily candle CLOSE (broker
//     `getCandleData`, per option token).
//   • Aaj ka premium — agar aaj ka candle ban gaya hai to uska close, warna
//     live chain ka LTP (jis snapshot se report bani).
//   • Token — local option book (FnoContractDao) se, strike + CE/PE + expiry
//     match karke.
//
// Honest rule: kisi leg ka candle nahi mila → us leg ko `missing` me daal ke
// card par "data nahi mila" likha jaata hai. Total P&L sirf tab dikhta hai jab
// SAB legs ka data ho (adhoore total se galat picture na bane).
//
// Note: BSE F&O (Bankex) tokens BFO segment me quote hote hain — isliye candle
// call me exchange code override pass hota hai.
// ---------------------------------------------------------------------------

import '../../../core/utils/markets.dart';
import '../../../data/local/app_database.dart';
import '../../../data/local/dao/fno_contract_dao.dart';
import '../../../data/remote/dto/candle.dart';
import '../../../services/auth_service.dart';
import '../../../services/market_data_service.dart';
import '../../../services/secure_store.dart';
import 'bankex_models.dart';
import 'strategy_engine.dart';

/// Ek leg ka kal→aaj P&L.
class LegPnl {
  const LegPnl({
    required this.instrument,
    required this.isBuy,
    required this.lots,
    required this.entryPremium,
    required this.currentPremium,
    required this.priceBasis,
  });

  final String instrument;
  final bool isBuy;
  final int lots;

  /// Pichhle trading din ka close (entry).
  final double entryPremium;

  /// Aaj ka close (candle) ya live LTP.
  final double currentPremium;

  /// 'aaj ka close' | 'live LTP' — UI me transparency ke liye.
  final String priceBasis;

  int get units => lots * StrategyEngine.lotSize;

  /// Buy → (aaj − kal) × units. Sell → (kal − aaj) × units.
  double get pnl =>
      (isBuy ? currentPremium - entryPremium : entryPremium - currentPremium) *
      units;

  double get changePct => entryPremium <= 0
      ? 0
      : (currentPremium - entryPremium) / entryPremium * 100;
}

/// Ek strategy ka poora kal→aaj result.
class StrategyBacktest {
  const StrategyBacktest({
    required this.id,
    this.entryDate,
    this.asOfDate,
    this.legs = const [],
    this.missing = const [],
    this.note,
  });

  final String id;

  /// Pichhla trading din (entry) — null = data nahi.
  final DateTime? entryDate;

  /// Aaj ki date (as-of).
  final DateTime? asOfDate;

  /// Jinke premiums mil gaye.
  final List<LegPnl> legs;

  /// Jinke premiums nahi mile (honest gap).
  final List<String> missing;

  /// Data hi nahi mila / demo mode — reason.
  final String? note;

  bool get hasData => legs.isNotEmpty;

  /// Total sirf tab jab sab legs ka data ho.
  bool get complete => missing.isEmpty && legs.isNotEmpty && note == null;

  double get totalPnl =>
      legs.fold<double>(0, (sum, leg) => sum + leg.pnl);

  int get winners => legs.where((l) => l.pnl > 0).length;
  int get losers => legs.where((l) => l.pnl < 0).length;
}

class StrategyBacktestService {
  StrategyBacktestService._();

  /// Session cache — report dobara kholne par network dobara na ho.
  static final Map<String, List<Candle>> _candleCache = <String, List<Candle>>{};
  static final Map<String, List<FnoContract>> _chainCache =
      <String, List<FnoContract>>{};

  /// Pure maths — tests isko network ke bina chalate hain.
  static LegPnl computeLeg({
    required String instrument,
    required String action,
    required int lots,
    required double entryPremium,
    required double currentPremium,
    String priceBasis = 'live LTP',
  }) =>
      LegPnl(
        instrument: instrument,
        isBuy: action.toLowerCase() == 'buy',
        lots: lots,
        entryPremium: entryPremium,
        currentPremium: currentPremium,
        priceBasis: priceBasis,
      );

  /// Leg label se underlying + option type nikalna
  /// ('BN CE (ATM)' → BN/CE, 'BANKEX PE (far expiry)' → BANKEX/PE).
  static ({bool bankex, String side})? parseInstrument(String label) {
    final text = label.toUpperCase();
    final bankex = text.startsWith('BANKEX');
    final isCall = text.contains('CE');
    final isPut = text.contains('PE');
    if (isCall == isPut) return null; // dono ya koi nahi — parse fail
    return (bankex: bankex, side: isCall ? 'CE' : 'PE');
  }

  static Future<StrategyBacktest> load({
    required MarketSnapshot m,
    required StrategyReport report,
    MarketDataService? marketDataIn,
  }) async {
    if (report.legs.isEmpty) {
      return StrategyBacktest(
        id: report.id,
        note: 'Is strategy ke legs nahi bane (chain incomplete) — '
            'kal→aaj calculate nahi ho sakta.',
      );
    }
    if (m.isDemo) {
      return StrategyBacktest(
        id: report.id,
        note: 'DEMO mode — real kal ka premium nahi. Live login + bhavcopy '
            'sync ke baad ye card actual P&L dikhayega.',
      );
    }

    final database = AppDatabase.instance;
    final contractsDao = FnoContractDao(database);
    // 1.5.88 — provider ka shared instance (wahi logged-in session); warna
    // naya banao par pehle stored session restore karo.
    var marketData = marketDataIn;
    if (marketData == null) {
      final auth = AuthService(store: SecureStore());
      await auth.restore();
      marketData = MarketDataService(auth: auth);
    }

    final nowIst = MarketCalendar.nowIst();
    final today = DateTime(nowIst.year, nowIst.month, nowIst.day);
    final from = today.subtract(const Duration(days: 12));

    final legs = <LegPnl>[];
    final missing = <String>[];
    DateTime? entryDate;

    for (final leg in report.legs) {
      final parsed = parseInstrument(leg.instrument);
      if (parsed == null) {
        missing.add('${leg.instrument} — label parse nahi hua');
        continue;
      }
      final underlying = parsed.bankex ? 'BANKEX' : 'BANKNIFTY';
      final index = parsed.bankex ? m.bankex : m.bankNifty;
      final chainKey = '$underlying|${index.expiryDate.toIso8601String()}';

      List<FnoContract> chain;
      try {
        chain = _chainCache[chainKey] ??=
            await contractsDao.chainOn(underlying, index.expiryDate);
      } catch (e) {
        missing.add('${leg.instrument} — option book read fail');
        continue;
      }

      FnoContract? contract;
      for (final c in chain) {
        if (c.strike == leg.strike && c.optionType == parsed.side) {
          contract = c;
          break;
        }
      }
      if (contract == null || contract.token.isEmpty) {
        missing.add('${leg.instrument} — option book me token nahi '
            '(bhavcopy sync chalao)');
        continue;
      }

      // 1.5.83 — asScrip() khud BANKEX → BFO aur baaki → NFO deta hai.
      final scrip = contract.asScrip();

      final candleKey = '${contract.token}|${today.toIso8601String()}';
      List<Candle> bars;
      try {
        bars = _candleCache[candleKey] ??= await marketData.fetchDailyCandles(
          scrip: scrip,
          from: DateTime(from.year, from.month, from.day, 9, 15),
          to: DateTime(today.year, today.month, today.day, 15, 30),
          exchangeCode: scrip.exchange.code,
        );
      } catch (e) {
        missing.add('${leg.instrument} — candle request fail');
        continue;
      }

      double? prevClose;
      double? todayClose;
      for (final bar in bars) {
        final day = bar.istDate;
        if (day.isBefore(today)) {
          prevClose = bar.close; // ascending order → last one wins
          entryDate ??= day;
        } else if (day == today) {
          todayClose = bar.close;
        }
      }
      if (prevClose == null || prevClose <= 0) {
        missing.add('${leg.instrument} — kal ka candle nahi mila '
            '(naya strike/contract ho sakta hai)');
        continue;
      }

      final useClose = todayClose != null && todayClose > 0;
      final current = useClose ? todayClose : leg.premium;
      if (current <= 0) {
        missing.add('${leg.instrument} — aaj ka premium nahi mila');
        continue;
      }

      legs.add(computeLeg(
        instrument: leg.instrument,
        action: leg.action,
        lots: leg.lots,
        entryPremium: prevClose,
        currentPremium: current,
        priceBasis: useClose ? 'aaj ka close' : 'live LTP',
      ));
    }

    return StrategyBacktest(
      id: report.id,
      entryDate: entryDate,
      asOfDate: today,
      legs: legs,
      missing: missing,
      note: legs.isEmpty
          ? 'Kal ka premium data nahi mila — koi number guess nahi kiya.'
          : null,
    );
  }
}
