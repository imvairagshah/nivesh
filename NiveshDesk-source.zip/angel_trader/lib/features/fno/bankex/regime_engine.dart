// ---------------------------------------------------------------------------
// regime_engine.dart — PDF Phase 1 (P1.1) market regime classification.
// Rules PDF ke exact: VIX >18 & rank >60 = elevated; VIX <14 & rank <30 =
// depressed; PCR >1.3 bullish, 0.8–1.3 neutral, <0.8 bearish. Trend =
// spot vs previous close/high-low (PDF ka 20-MA ka honest fallback).
// ---------------------------------------------------------------------------

import 'bankex_models.dart';

class RegimeEngine {
  RegimeEngine._();

  static RegimeReport classify(MarketSnapshot m) {
    final bn = m.bankNifty;

    // 1. Trend (PDF fallback: spot vs prev close + day range position).
    final chg = bn.changePct;
    final rangePos = bn.intradayHigh == bn.intradayLow
        ? 0.5
        : (bn.spot - bn.intradayLow) / (bn.intradayHigh - bn.intradayLow);
    final trend = switch ((chg, rangePos)) {
      (>= 1.0, _) => 'Strong Up',
      (>= 0.25, _) => 'Mild Up',
      (<= -1.0, _) => 'Strong Down',
      (<= -0.25, _) => 'Mild Down',
      _ when rangePos > 0.7 => 'Mild Up',
      _ when rangePos < 0.3 => 'Mild Down',
      _ => 'Sideways',
    };

    // 2. Volatility (PDF thresholds).
    final vixStatus = (m.indiaVix > 18 && m.vixRank30d > 60)
        ? 'elevated'
        : (m.indiaVix < 14 && m.vixRank30d < 30)
            ? 'depressed'
            : 'normal';
    final ivDiff = bn.atmIv - m.bankex.atmIv; // +ve = inverted (PDF)
    final ivStatus = ivDiff > 0 ? 'inverted' : 'normal';

    // 3. Sentiment (PDF PCR bands).
    String pcrRead(double pcr) => pcr < 0
        ? 'unknown (OI source pending)'
        : (pcr > 1.3 ? 'bullish' : (pcr < 0.8 ? 'bearish' : 'neutral'));

    // 4. Breadth.
    final ad = m.declines == 0 ? 99.0 : m.advances / m.declines;
    final breadthRead =
        ad > 1.2 ? 'strong' : (ad < 0.8 ? 'weak' : 'mixed');

    // Primary regime (PDF ke 7 classes).
    final String primary;
    final String confidence;
    if (vixStatus == 'elevated' && (chg <= -0.25 || chg >= 0.25)) {
      primary = 'VOLATILE-ELEVATED';
      confidence = 'HIGH';
    } else if (vixStatus == 'depressed' && chg.abs() < 0.25) {
      primary = 'VOLATILE-CRUSH';
      confidence = 'MEDIUM';
    } else if (chg >= 1.0 && ad >= 1.2) {
      primary = 'BULLISH';
      confidence = 'HIGH';
    } else if (chg >= 0.25) {
      primary = 'MILDLY BULLISH';
      confidence = 'MEDIUM';
    } else if (chg <= -1.0 && ad <= 0.8) {
      primary = 'BEARISH';
      confidence = 'HIGH';
    } else if (chg <= -0.25) {
      primary = 'MILDLY BEARISH';
      confidence = 'MEDIUM';
    } else {
      primary = 'RANGEBOUND';
      confidence = 'MEDIUM';
    }

    // PDF "NEXT STEP" mapping — regime → strategies (1.5.80: sirf 6 live).
    final recommended = <String>[
      if (primary == 'BULLISH' || primary == 'MILDLY BULLISH') ...[
        'P2.8 Diagonal Ratio (Bull) — near-expiry short + long gamma',
      ],
      if (primary == 'BEARISH' || primary == 'MILDLY BEARISH') ...[
        'P2.8 Diagonal Ratio (Bear) — near-expiry short + long gamma',
      ],
      if (primary == 'RANGEBOUND' || primary == 'VOLATILE-CRUSH') ...[
        'P2.9 Iron Butterfly — max theta',
        'P2.7 Short Strangle + Hedge — premium collection',
      ],
      if (primary == 'VOLATILE-ELEVATED') ...[
        'P2.6 Long Straddle/Strangle — volatility long',
        'P2.8 Diagonal Ratio Backspread — expiry-gap theta + gamma',
      ],
      'P2.3 Cross-Expiry Calendar — expiry-gap decay',
      'P2.10 Delta-Neutral Pair — IV differential',
    ];
    final avoid = <String>[
      if (primary == 'RANGEBOUND' || primary == 'VOLATILE-CRUSH')
        'P2.6 Long Straddle — IV crush me premium loss',
      if (primary == 'VOLATILE-ELEVATED')
        'P2.9 Iron Butterfly — breakout se wings breach',
    ];

    return RegimeReport(
      primary: primary,
      confidence: confidence,
      trendLine: 'BN spot=${bn.spot.toStringAsFixed(0)}, '
          'change=${chg.toStringAsFixed(2)}%, trend=$trend '
          '(Bankex: ${m.bankex.changePct.toStringAsFixed(2)}%)',
      volatilityLine: 'India VIX=${m.indiaVix.toStringAsFixed(1)} '
          '(rank ${m.vixRank30d.toStringAsFixed(0)}) = $vixStatus · '
          'BN IV ${bn.atmIv.toStringAsFixed(1)} vs Bankex '
          '${m.bankex.atmIv.toStringAsFixed(1)} = $ivStatus',
      sentimentLine: 'BN PCR=${bn.pcr < 0 ? 'n/a' : bn.pcr.toStringAsFixed(2)} '
          '(${pcrRead(bn.pcr)}) · Bankex PCR='
          '${m.bankex.pcr < 0 ? 'n/a' : m.bankex.pcr.toStringAsFixed(2)} '
          '(${pcrRead(m.bankex.pcr)}) · Max pain '
          '${bn.maxPain < 0 ? 'n/a (OI pending)' : bn.maxPain.toStringAsFixed(0)}',
      breadthLine: 'A/D=${m.advances}/${m.declines} (ratio '
          '${ad.toStringAsFixed(2)}) = $breadthRead',
      recommended: recommended,
      avoid: avoid,
      eventRisk: 'Events calendar app me nahi — high-impact news ke bina '
          'entry mat lo.',
    );
  }
}
