// ---------------------------------------------------------------------------
// black_scholes.dart — European option pricing + implied-volatility solve.
//
// The 3-Month Study needs an IV for the ATM CE/PE pair. The broker's option
// greek endpoint normally supplies it; when that fails (or returns nothing for
// the strike) the spec says: reverse-solve it from the traded premium with
// Black-Scholes. That is what this file does — and nothing else, so it can be
// unit-tested to death.
//
//   d1 = (ln(S/K) + (r + σ²/2)T) / (σ√T)
//   d2 = d1 − σ√T
//   call = S·N(d1) − K·e^(−rT)·N(d2)
//   put  = K·e^(−rT)·N(−d2) − S·N(−d1)
//
// There is no closed form for σ, so the solver bisects between 0.5 % and 500 %
// (80 iterations ≈ 1e-24 resolution — far beyond the 0.01 % the UI shows), with
// the guard rails the spec lists: junk premiums, prices below the discounted
// intrinsic value, and prices that even 500 % volatility cannot explain all
// return `null` rather than a made-up number.
// ---------------------------------------------------------------------------

import 'dart:math' as math;

enum OptionType {
  call('CE'),
  put('PE');

  const OptionType(this.code);

  /// Broker code: `CE` / `PE`.
  final String code;

  static OptionType? fromCode(String code) {
    switch (code.trim().toUpperCase()) {
      case 'CE':
      case 'CALL':
        return OptionType.call;
      case 'PE':
      case 'PUT':
        return OptionType.put;
      default:
        return null;
    }
  }
}

/// Risk-free rate assumed by the spec (Indian 10-year G-sec ballpark).
const double kRiskFreeRate = 0.065;

/// Solver bounds: the spec's 0.5 % … 500 % search window.
const double kIvLowerBound = 0.005;
const double kIvUpperBound = 5.0;

/// Accepted output range: anything outside 1 % … 400 % is treated as noise.
const double kIvAcceptMin = 0.01;
const double kIvAcceptMax = 4.0;

/// Standard normal CDF (Abramowitz & Stegun 7.1.26 — accurate to ~1e-7, which is
/// far finer than option premiums are quoted).
double normalCdf(double x) {
  final t = 1 / (1 + 0.2316419 * x.abs());
  final poly = t *
      (0.319381530 +
          t *
              (-0.356563782 +
                  t * (1.781477937 + t * (-1.821255978 + t * 1.330274429))));
  final density = 0.3989422804014327 * math.exp(-x * x / 2);
  final cdf = 1 - density * poly;
  return x >= 0 ? cdf : 1 - cdf;
}

double normalPdf(double x) => 0.3989422804014327 * math.exp(-x * x / 2);

/// One option's inputs. [timeToExpiryYears] is `daysToExpiry / 365` per spec.
class BsInput {
  final double spot;
  final double strike;
  final double timeToExpiryYears;
  final double volatility;
  final double rate;

  const BsInput({
    required this.spot,
    required this.strike,
    required this.timeToExpiryYears,
    required this.volatility,
    this.rate = kRiskFreeRate,
  });
}

/// Black-Scholes price of a European option.
///
/// Returns `0`-ish intrinsic for a degenerate input (expiry today, zero vol) —
/// the caller guards those cases before solving, so a nonsense input here means
/// a bug, not a market condition.
double blackScholesPrice(OptionType type, BsInput input) {
  final s = input.spot;
  final k = input.strike;
  final t = input.timeToExpiryYears;
  final v = input.volatility;
  final r = input.rate;

  if (s <= 0 || k <= 0) return 0;
  if (t <= 0 || v <= 0) {
    // At/after expiry an option is worth its intrinsic value.
    final intrinsic =
        type == OptionType.call ? math.max(s - k, 0.0) : math.max(k - s, 0.0);
    return intrinsic;
  }

  final sqrtT = math.sqrt(t);
  final d1 = (math.log(s / k) + (r + v * v / 2) * t) / (v * sqrtT);
  final d2 = d1 - v * sqrtT;
  final discount = math.exp(-r * t);

  if (type == OptionType.call) {
    return s * normalCdf(d1) - k * discount * normalCdf(d2);
  }
  return k * discount * normalCdf(-d2) - s * normalCdf(-d1);
}

/// Discounted intrinsic value — a premium below this is an impossible price
/// (arbitrage), so the solver must refuse rather than invent a volatility.
double discountedIntrinsic(OptionType type, BsInput input) {
  final discount = math.exp(-input.rate * math.max(input.timeToExpiryYears, 0));
  if (type == OptionType.call) {
    return math.max(input.spot - input.strike * discount, 0.0);
  }
  return math.max(input.strike * discount - input.spot, 0.0);
}

/// Why an implied volatility could not be solved — surfaced in the UI so an
/// empty IV is always explainable instead of looking like a bug.
enum IvFailure {
  badInput('Premium/spot missing or expiry already passed.'),
  tinyPremium('Premium is under 0.2 % of spot — junk quote.'),
  belowIntrinsic('Premium is below the option\'s discounted intrinsic value.'),
  aboveRange('Premium is higher than a 500 % volatility would price.'),
  outOfAcceptedRange('Solved volatility fell outside the accepted 1–400 % band.');

  const IvFailure(this.message);
  final String message;
}

/// Result of the reverse solve: either a volatility or a reason it does not
/// exist. (`null` IV with a reason beats a misleading number.)
class IvSolveResult {
  final double? iv;
  final IvFailure? failure;
  final int iterations;

  const IvSolveResult.solved(this.iv, this.iterations) : failure = null;
  const IvSolveResult.failed(this.failure, this.iterations) : iv = null;

  bool get isSolved => iv != null;
}

/// Reverse-solves implied volatility from a market premium (bisection).
///
/// [premium] is the option's traded price, [spot] the underlying's last price
/// and [daysToExpiry] calendar days to expiry (0 → skip, per spec).
IvSolveResult impliedVolatility({
  required OptionType type,
  required double premium,
  required double spot,
  required double strike,
  required int daysToExpiry,
  double rate = kRiskFreeRate,
  int maxIterations = 80,
}) {
  // -- guard rails (spec §2.6.1 step 3) ------------------------------------
  if (premium <= 0 || spot <= 0 || strike <= 0 || daysToExpiry <= 0) {
    return const IvSolveResult.failed(IvFailure.badInput, 0);
  }
  if (premium < spot * 0.002) {
    return const IvSolveResult.failed(IvFailure.tinyPremium, 0);
  }

  final t = daysToExpiry / 365;
  final probe = BsInput(spot: spot, strike: strike, timeToExpiryYears: t, volatility: 0);
  if (premium < discountedIntrinsic(type, probe)) {
    return const IvSolveResult.failed(IvFailure.belowIntrinsic, 0);
  }

  double priceAt(double vol) => blackScholesPrice(
        type,
        BsInput(
          spot: spot,
          strike: strike,
          timeToExpiryYears: t,
          volatility: vol,
          rate: rate,
        ),
      );

  // Even 500 % vol cannot explain the premium → it is not a volatility problem.
  if (priceAt(kIvUpperBound) < premium) {
    return const IvSolveResult.failed(IvFailure.aboveRange, 0);
  }

  var low = kIvLowerBound;
  var high = kIvUpperBound;
  var mid = low;
  var iterations = 0;

  for (var i = 0; i < maxIterations; i++) {
    iterations = i + 1;
    mid = (low + high) / 2;
    final price = priceAt(mid);
    if ((price - premium).abs() <= 1e-6 * math.max(premium, 1)) break;
    if (price > premium) {
      high = mid;
    } else {
      low = mid;
    }
  }

  if (mid < kIvAcceptMin || mid > kIvAcceptMax) {
    return IvSolveResult.failed(IvFailure.outOfAcceptedRange, iterations);
  }
  return IvSolveResult.solved(mid, iterations);
}

/// Greeks of a solved option (kept because the detail panel shows delta-free
/// summaries today but a future tool will want them).
class BsGreeks {
  final double delta;
  final double gamma;
  final double thetaPerDay;
  final double vegaPerPct;

  const BsGreeks({
    required this.delta,
    required this.gamma,
    required this.thetaPerDay,
    required this.vegaPerPct,
  });
}

BsGreeks blackScholesGreeks(OptionType type, BsInput input) {
  final s = input.spot;
  final k = input.strike;
  final t = input.timeToExpiryYears;
  final v = input.volatility;
  final r = input.rate;
  if (t <= 0 || v <= 0 || s <= 0 || k <= 0) {
    return const BsGreeks(delta: 0, gamma: 0, thetaPerDay: 0, vegaPerPct: 0);
  }

  final sqrtT = math.sqrt(t);
  final d1 = (math.log(s / k) + (r + v * v / 2) * t) / (v * sqrtT);
  final d2 = d1 - v * sqrtT;
  final discount = math.exp(-r * t);
  final density = normalPdf(d1);

  final delta = type == OptionType.call
      ? normalCdf(d1)
      : normalCdf(d1) - 1;
  final gamma = density / (s * v * sqrtT);
  final vega = s * density * sqrtT / 100; // per 1 % vol
  final theta = type == OptionType.call
      ? (-(s * density * v) / (2 * sqrtT) - r * k * discount * normalCdf(d2)) / 365
      : (-(s * density * v) / (2 * sqrtT) + r * k * discount * normalCdf(-d2)) / 365;

  return BsGreeks(delta: delta, gamma: gamma, thetaPerDay: theta, vegaPerPct: vega);
}
