// ---------------------------------------------------------------------------
// ai_jodi_engine.dart — the "AI Calculation & Chart Study" rules (AI Jodi
// Study), pure and offline.
//
// The user's spec, decided with them on 25 Oct 2026:
//   • Gate 1 (15 din): "roz ka average daily move ATR(14) se zyada ho" —
//     [AiJodiInput.avgDailyMove15] > [AiJodiInput.atr].
//   • Gate 2 (mahina): "mostly month me 20-30% ki movement" — the high−low
//     range of a month ≥ 20% of its price in MOST of the last three months
//     (≥ 2 of 3). [MonthMove.rangePct] is that measure.
//   • Gate 3 (jodi sasti): "movement jodi ki price se zyada dete he" — the
//     typical monthly ₹ range must exceed what the pair costs.
//   • Verdict (ATM ya OTM?): both legs are BOUGHT (long straddle / long
//     strangle — direction-neutral, risk = premium only, monthly expiry).
//     The pair must be covered **twice** by the typical monthly move — the
//     buyer pays both premiums, so a move equal to the premium only breaks
//     even. ATM is preferred while movement is ample (needs less precision);
//     the cheaper OTM jodi is recommended when only it clears 2×.
//
// Everything here is pure (no network, no broker): the rules are pinned by
// tests. The screen shows a simple table — name, price, ATR, ATM jodi, OTM
// jodi, verdict — nothing more.
// ---------------------------------------------------------------------------

import 'study_engine.dart' show IvRank;

/// One stock's numbers, assembled from the 3-Month Study's [StudyRow].
class AiJodiInput {
  const AiJodiInput({
    required this.symbol,
    required this.companyName,
    required this.ltp,
    required this.atr,
    this.avgRange = 0,
    required this.avgDailyMove15,
    required this.monthlyRangePcts,
    this.atmJodiPrice,
    this.otmJodiPrice,
    this.isManual = false,
    this.ivp,
    this.ivr,
  });

  final String symbol;
  final String companyName;

  /// Current price (cash-market close).
  final double ltp;

  /// Wilder ATR(14), rupees.
  final double atr;

  /// Simple (High − Low) average of the last 14 sessions, rupees — display
  /// only. Gates/score ATR se hi chalte hain; ye "din ka average range" hai
  /// bina gap ke.
  final double avgRange;

  /// Average |close-to-close| move of the last 15 sessions, rupees.
  final double avgDailyMove15;

  /// High−low range % of each of the last three months (`MonthMove.rangePct`).
  final List<double> monthlyRangePcts;

  /// ATM jodi (straddle) ka aaj ka kul premium — CE + PE.
  final double? atmJodiPrice;

  /// OTM jodi (strangle) ka aaj ka kul premium — CE + PE.
  final double? otmJodiPrice;

  /// User ne khud add kiya — gates skip karte hain, numbers + verdict sabit.
  final bool isManual;

  /// IV Percentile (0–100) — Opstra sheet se (1.5.56). Null = data nahi.
  final double? ivp;

  /// IV Rank (0–100) — Opstra sheet se (1.5.56). Null = data nahi.
  final double? ivr;

  /// Dono me se jo zyada "rich" (mehnga) hai — conservative signal. Jab
  /// dono missing hon tab null (absence stays absence).
  double? get effectiveIv {
    final values = [
      if (ivp != null) ivp!,
      if (ivr != null) ivr!,
    ];
    if (values.isEmpty) return null;
    return values.reduce((a, b) => a > b ? a : b);
  }

  /// Premium apne itihaas me sasta hai (dono me se koi bhi ≤ cheap floor).
  bool get ivCheap {
    final values = [
      if (ivp != null) ivp!,
      if (ivr != null) ivr!,
    ];
    return values.isNotEmpty &&
        values.every((v) => v <= AiJodiRules.ivCheapCeilPct);
  }

  /// Months (of the last three) whose range was ≥ 20% of price.
  int get monthsMeeting20 =>
      monthlyRangePcts.where((pct) => pct >= AiJodiRules.monthlyRangeFloorPct).length;

  /// Median monthly range in ₹ — the "typically kitna hilta hai" number.
  double get typicalMoveRupee {
    if (monthlyRangePcts.isEmpty || ltp <= 0) return 0;
    final sorted = [...monthlyRangePcts]..sort();
    final mid = sorted.length ~/ 2;
    final medianPct = sorted.length.isOdd
        ? sorted[mid]
        : (sorted[mid - 1] + sorted[mid]) / 2;
    return medianPct * ltp / 100;
  }
}

/// The thresholds — kept named so the tests and the screen agree.
abstract final class AiJodiRules {
  /// "20-30% (ya usse zyada)" — the monthly high−low floor.
  static const double monthlyRangeFloorPct = 20;

  /// "Mostly" — kitne months me range floor chahiye (3 me se).
  static const int monthsRequired = 2;

  /// Movement must cover the pair **twice** (both premiums are at risk).
  static const double coverRequired = 2;

  /// IVP/IVR ≥ ye → premium apne itihaas me mehnga (1.5.56). Jodi-buy ke
  /// liye ye gate band — IV crush even sahi move me kha jaata hai.
  static const double ivRichFloorPct = 70;

  /// IVP/IVR ≤ ye → premium sasta — scoring me bonus (1.5.56).
  static const double ivCheapCeilPct = 40;

  /// Saste-vol wale ko ranking me utna extra score (cover points).
  static const double ivCheapScoreBonus = 0.5;

  /// One shared disclaimer — sheet, export and recap all print it.
  static const String disclaimer =
      'Long pair (CE+PE dono BUY) — direction-neutral, risk sirf premium tak. '
      'Ye analytics hai, investment advice nahi.';
}

/// The verdict the table shows in its last column.
enum AiJodiVerdict {
  /// Movement bharpoor — ATM straddle buy karein.
  atmBuy('ATM jodi buy karein'),

  /// Movement madhyam — sasti OTM strangle buy karein.
  otmBuy('OTM jodi buy karein'),

  /// Movement jodi ke daam ko 2× cover nahi karti.
  skip('Abhi mat le — movement jodi ke daam ko 2× cover nahi karti'),

  /// Jodi ka daam hi nahi mila (chain/IV incomplete).
  noPrice('Jodi ka daam nahi mila — chain/IV incomplete'),

  /// IVP/IVR ≥ 70 — premium apne itihaas me mehnga, IV crush ka risk
  /// (1.5.56). "Premium sasta lagta ho to bhi soch lo."
  ivRich('IV mehnga — jodi mehngi padegi, IV crush ka risk, soch lo');

  const AiJodiVerdict(this.label);

  /// Hinglish line the table shows.
  final String label;
}

/// Gate-by-gate result for one stock.
class AiJodiResult {
  const AiJodiResult({
    required this.gate15,
    required this.gateMonth,
    required this.gateJodi,
    required this.monthsMeeting20,
    required this.typicalMoveRupee,
    required this.coverAtm,
    required this.coverOtm,
    required this.verdict,
    this.gateIv = true,
    this.ivNote = '',
  });

  /// Gate 1: 15-din ka average daily move > ATR.
  final bool gate15;

  /// Gate 2: mostly months (≥2/3) me 20%+ range.
  final bool gateMonth;

  /// Gate 3: typical ₹ move > jodi ka daam (at least one pair priced).
  final bool gateJodi;

  /// Gate 4 (1.5.56): IV sasta hona chahiye — IVP/IVR < 70. Missing data
  /// passes honestly (absence is not a failure).
  final bool gateIv;

  /// Short IV line for the detail text — '' when nothing to say.
  final String ivNote;

  final int monthsMeeting20;
  final double typicalMoveRupee;
  final double? coverAtm;
  final double? coverOtm;
  final AiJodiVerdict verdict;

  /// All three gates — the stock earns its place in the auto list.
  bool get passes => gate15 && gateMonth && gateJodi && gateIv;

  /// Why the stock is (or is not) in the list — one short line.
  String get detail {
    final missed = <String>[
      if (!gate15) '15-din move ≤ ATR',
      if (!gateMonth) '$monthsMeeting20/3 months me 20%+ range',
      if (!gateJodi) 'movement jodi ke daam se kam',
      if (ivNote.isNotEmpty) ivNote,
    ];
    return missed.isEmpty ? verdict.label : missed.join(' · ');
  }
}

/// The pure rules. One entry point, no side effects.
abstract final class AiJodiEngine {
  /// Break-evens of a bought pair: the stock must leave [lowerStrike] −
  /// premium below or [upperStrike] + premium above. The ATM straddle passes
  /// the same strike twice; the strangle passes the PE strike and the CE
  /// strike. Pure maths — the chart draws these as two lines.
  static ({double lower, double upper}) jodiBreakEvens({
    required double lowerStrike,
    required double upperStrike,
    required double totalPremium,
  }) => (
        lower: lowerStrike - totalPremium,
        upper: upperStrike + totalPremium,
      );

  /// "Kal ye jodi buy ki hoti" — P&L of the bought pair from the previous
  /// close to now. `null` when either number is missing (never a guess).
  static ({double rupees, double pct})? kalJodiPnl({
    required double? buyCost,
    required double? nowValue,
  }) {
    if (buyCost == null ||
        nowValue == null ||
        buyCost <= 0 ||
        nowValue < 0) {
      return null;
    }
    return (
      rupees: nowValue - buyCost,
      pct: (nowValue - buyCost) / buyCost * 100,
    );
  }

  /// The IV-rank star the verdict column carries: a cheap pair is only a
  /// deal when its IV is cheap too ("premium sasta, IV mehnga → asli deal
  /// nahi" — the user's rule).
  static String ivStarLabel(IvRank rank) => switch (rank) {
        IvRank.low => '⭐ IV sasta — jodi lene ke liye achha',
        IvRank.medium => 'IV medium',
        IvRank.high => '⚠️ IV mehnga — premium sasta lagta ho to bhi soch lo',
        IvRank.unknown => 'IV data nahi',
      };

  /// The numeric star (1.5.56) — Opstra sheet ke IVP/IVR values se. Jab
  /// values hon tab yehi dikhega; warna [ivStarLabel] wala coarse star.
  static String ivStarFromValues({double? ivp, double? ivr}) {
    final values = [
      if (ivp != null) ivp,
      if (ivr != null) ivr,
    ];
    if (values.isEmpty) return 'IV data nahi';
    final eff = values.reduce((a, b) => a > b ? a : b);
    final shown = 'IVP ${ivp?.toStringAsFixed(0) ?? '—'} · IVR ${ivr?.toStringAsFixed(0) ?? '—'}';
    if (eff >= AiJodiRules.ivRichFloorPct) {
      return '⚠️ IV mehnga ($shown) — premium sasta lagta ho to bhi soch lo';
    }
    if (eff <= AiJodiRules.ivCheapCeilPct) {
      return '⭐ IV sasta ($shown) — jodi lene ke liye achha';
    }
    return 'IV medium ($shown)';
  }

  static AiJodiResult analyze(AiJodiInput input) {
    final move = input.typicalMoveRupee;
    final atm = input.atmJodiPrice;
    final otm = input.otmJodiPrice;

    final gate15 = input.avgDailyMove15 > input.atr;
    final gateMonth = input.monthsMeeting20 >= AiJodiRules.monthsRequired;
    final anyPriced = (atm != null && atm > 0) || (otm != null && otm > 0);
    final gateJodi = anyPriced &&
        ((atm != null && atm > 0 && move > atm) ||
            (otm != null && otm > 0 && move > otm));

    double? cover(double? price) =>
        (price == null || price <= 0 || move <= 0) ? null : move / price;
    final coverAtm = cover(atm);
    final coverOtm = cover(otm);

    // Gate 4 (1.5.56): IV richness. Missing IVP/IVR passes honestly; a
    // rich premium blocks the buy (manual rows are never gated, only warned).
    final ivEff = input.effectiveIv;
    final ivRich = ivEff != null && ivEff >= AiJodiRules.ivRichFloorPct;
    final gateIv = input.isManual || !ivRich;
    final ivNote = !ivRich
        ? ''
        : 'IV ${ivEff.toStringAsFixed(0)} (IVP ${input.ivp?.toStringAsFixed(0) ?? '—'}'
            ' · IVR ${input.ivr?.toStringAsFixed(0) ?? '—'})'
            '${input.isManual ? ' — khud add kiya, isliye gate nahi, soch lo' : ' — mehnga, IV crush ka risk'}';

    final AiJodiVerdict verdict;
    if (!anyPriced) {
      verdict = AiJodiVerdict.noPrice;
    } else {
      final atmClears = coverAtm != null && coverAtm >= AiJodiRules.coverRequired;
      final otmClears = coverOtm != null && coverOtm >= AiJodiRules.coverRequired;
      // Movement is ample: the ATM straddle needs less strike precision and
      // answers to any big move — prefer it while it clears 2×.
      if (atmClears) {
        verdict = (ivRich && !input.isManual)
            ? AiJodiVerdict.ivRich
            : AiJodiVerdict.atmBuy;
      } else if (otmClears) {
        verdict = (ivRich && !input.isManual)
            ? AiJodiVerdict.ivRich
            : AiJodiVerdict.otmBuy;
      } else {
        verdict = AiJodiVerdict.skip;
      }
    }

    return AiJodiResult(
      gate15: gate15,
      gateMonth: gateMonth,
      gateJodi: gateJodi,
      monthsMeeting20: input.monthsMeeting20,
      typicalMoveRupee: move,
      coverAtm: coverAtm,
      coverOtm: coverOtm,
      verdict: verdict,
      gateIv: gateIv,
      ivNote: ivNote,
    );
  }

  /// The output list — "kaunse 20 best stocks hain": every all-gate passer
  /// first (best movement-per-rupee of jodi first), then, if the gates left
  /// the list short, the next-best priced stocks fill it out — each with its
  /// honest verdict. Manual rows are never dropped. Auto rows are capped at
  /// [limit] (the user's "20 best").
  static List<({AiJodiInput input, AiJodiResult result})> topList(
    List<AiJodiInput> inputs, {
    int limit = 20,
  }) {
    double score(({AiJodiInput input, AiJodiResult result}) row) {
      final covers = [
        if (row.result.coverAtm != null) row.result.coverAtm!,
        if (row.result.coverOtm != null) row.result.coverOtm!,
      ];
      final base = covers.isEmpty ? 0.0 : covers.reduce((x, y) => x > y ? x : y);
      // 1.5.56: sasta vol (IVP/IVR ≤ 40) ko ranking me bonus — same cover
      // me premium jo apne itihaas me sasta hai, behtar entry hai.
      return row.input.ivCheap ? base + AiJodiRules.ivCheapScoreBonus : base;
    }

    int byScoreDesc(
      ({AiJodiInput input, AiJodiResult result}) a,
      ({AiJodiInput input, AiJodiResult result}) b,
    ) =>
        score(b).compareTo(score(a));

    final scored = [
      for (final input in inputs) (input: input, result: analyze(input)),
    ];
    final passers = [
      for (final row in scored)
        if (row.input.isManual || row.result.passes) row,
    ]..sort(byScoreDesc);
    final fill = [
      for (final row in scored)
        if (!(row.input.isManual || row.result.passes) && score(row) > 0) row,
    ]..sort(byScoreDesc);

    final out = <({AiJodiInput input, AiJodiResult result})>[];
    var autoCount = 0;
    for (final row in passers) {
      if (row.input.isManual) {
        out.add(row);
      } else if (autoCount < limit) {
        out.add(row);
        autoCount++;
      }
    }
    for (final row in fill) {
      if (autoCount >= limit) break;
      out.add(row);
      autoCount++;
    }
    return out;
  }

  /// Kept for the tests and older callers: passers only, no fill, no cap.
  static List<({AiJodiInput input, AiJodiResult result})> rank(
    List<AiJodiInput> inputs,
  ) {
    final scored = [
      for (final input in inputs) (input: input, result: analyze(input)),
    ];
    final listed = [
      for (final row in scored)
        if (row.input.isManual || row.result.passes) row,
    ];
    listed.sort((a, b) {
      double coverOf(({AiJodiInput input, AiJodiResult result}) row) {
        final covers = [
          if (row.result.coverAtm != null) row.result.coverAtm!,
          if (row.result.coverOtm != null) row.result.coverOtm!,
        ];
        return covers.isEmpty ? 0 : covers.reduce((x, y) => x > y ? x : y);
      }

      return coverOf(b).compareTo(coverOf(a));
    });
    return listed;
  }
}

/// One row of the AI Jodi table — the pair the engine produced for a stock.
typedef JodiRow = ({AiJodiInput input, AiJodiResult result});

/// Table controls added in 1.5.55: verdict filter + sort keys. Pure
/// functions — the screen only owns the state, never the logic.
enum JodiSortKey {
  rank('Rank (best first)'),
  coverPct('Cover % (zyada pehle)'),
  price('Price (sasta pehle)'),
  kalChange('Kal→aaj change (zyada pehle)');

  const JodiSortKey(this.label);
  final String label;
}

enum JodiVerdictFilter {
  all('Sabhi'),
  atmBuy('ATM buy'),
  otmBuy('OTM buy'),
  skip('Abhi mat le');

  const JodiVerdictFilter(this.label);
  final String label;
}

abstract final class JodiTableOps {
  /// Keeps only the rows the filter asks for.
  static List<JodiRow> filter(List<JodiRow> rows, JodiVerdictFilter filter) {
    switch (filter) {
      case JodiVerdictFilter.all:
        return rows;
      case JodiVerdictFilter.atmBuy:
        return [
          for (final row in rows)
            if (row.result.verdict == AiJodiVerdict.atmBuy) row,
        ];
      case JodiVerdictFilter.otmBuy:
        return [
          for (final row in rows)
            if (row.result.verdict == AiJodiVerdict.otmBuy) row,
        ];
      case JodiVerdictFilter.skip:
        return [
          for (final row in rows)
            if (row.result.verdict == AiJodiVerdict.skip ||
                row.result.verdict == AiJodiVerdict.ivRich) row,
        ];
    }
  }

  /// Sorts without losing rows. `kalChangeOf` supplies the kal→aaj premium
  /// change in rupees (null = not available → those rows sink to the end).
  static List<JodiRow> sort(
    List<JodiRow> rows,
    JodiSortKey key, {
    double? Function(String symbol)? kalChangeOf,
  }) {
    final out = [...rows];
    int byKalDesc(JodiRow a, JodiRow b) {
      final ka = kalChangeOf?.call(a.input.symbol);
      final kb = kalChangeOf?.call(b.input.symbol);
      if (ka == null && kb == null) return 0;
      if (ka == null) return 1; // missing last
      if (kb == null) return -1;
      return kb.compareTo(ka);
    }

    switch (key) {
      case JodiSortKey.rank:
        break; // already ranked by the engine
      case JodiSortKey.coverPct:
        double cover(JodiRow row) {
          final a = row.result.coverAtm;
          final b = row.result.coverOtm;
          if (a == null && b == null) return -1;
          return [if (a != null) a, if (b != null) b].reduce((x, y) => x > y ? x : y);
        }

        out.sort((a, b) => cover(b).compareTo(cover(a)));
      case JodiSortKey.price:
        out.sort((a, b) => a.input.ltp.compareTo(b.input.ltp));
      case JodiSortKey.kalChange:
        out.sort(byKalDesc);
    }
    return out;
  }
}
