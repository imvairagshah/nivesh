// ---------------------------------------------------------------------------
// iv_sheet.dart — Google-Sheet IVP/IVR feed for the jodi engine (1.5.56).
//
// The user keeps an Opstra export in a Google Sheet ("Publish to web" CSV)
// with columns like `symbol, ivp, ivr`. The app fetches that public CSV —
// no login, no API key, no tokens (private sheets stay honestly unsupported).
// Missing rows/values stay missing: absence is absence.
// ---------------------------------------------------------------------------

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../../../data/local/dao/settings_dao.dart';
import '../../alerts/alerts_center.dart';

/// One parsed row of the sheet.
///
/// **Sirf IVP + IVR** sheet se aate hain (user rule, 1.5.67) — baaki sab
/// cheezein (IV, price, premium…) app ki normal API/calculation sources se
/// aati hain, is sheet se kabhi nahi. Sheet me extra columns ho sakti hain —
/// wo parse me ignore hoti hain (header-based mapping).
@immutable
class IvSheetRow {
  const IvSheetRow({this.ivp, this.ivr});

  /// 0–100 hi valid (bahar wale dropped, kabhi clamp nahi).
  final double? ivp;
  final double? ivr;

  bool get isEmpty => ivp == null && ivr == null;
}

class IvSheetException implements Exception {
  IvSheetException(this.message);
  final String message;
  @override
  String toString() => message;
}

abstract final class IvSheetParsers {
  /// Quote-aware CSV line split — Google Sheets quoted cells (commas/parens
  /// inside) must not shift the columns after them.
  static List<String> _splitCsvLine(String line) {
    final out = <String>[];
    final buf = StringBuffer();
    var inQuotes = false;
    for (var i = 0; i < line.length; i++) {
      final c = line[i];
      if (c == '"') {
        inQuotes = !inQuotes;
      } else if (c == ',' && !inQuotes) {
        out.add(buf.toString());
        buf.clear();
      } else {
        buf.write(c);
      }
    }
    out.add(buf.toString());
    return out;
  }

  /// Header-based column mapping — the sheet may carry ANY number of columns
  /// in ANY order: `ticker/symbol`, `ivp/iv percentile`, `ivr/iv rank`,
  /// optional `date`. **Baki ke saare columns ignore** (1.5.67 rule: sheet se
  /// sirf IVP/IVR; IV/price/premium app ki apni API/calculation se aate hain).
  /// IVP/IVR values outside 0–100 are dropped honestly (never clamped).
  static ({Map<String, IvSheetRow> bySymbol, DateTime? asOf}) parseCsv(String csv) {
    final lines = csv
        .split(RegExp(r'[\r\n]+'))
        .where((line) => line.trim().isNotEmpty)
        .toList();
    if (lines.length < 2) return (bySymbol: const {}, asOf: null);

    String norm(String raw) =>
        raw.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
    final header = _splitCsvLine(lines.first).map(norm).toList();
    int col(List<String> names) {
      for (final name in names) {
        final idx = header.indexOf(norm(name));
        if (idx >= 0) return idx;
      }
      return -1;
    }

    final iSymbol = col(['symbol', 'ticker', 'stock', 'scrip', 'name']);
    final iIvp = col(['ivp', 'ivpercentile', 'ivpercentil', 'percentile']);
    final iIvr = col(['ivr', 'ivrank', 'rank']);
    final iDate = col(['date', 'asof', 'asofdate', 'updated']);
    if (iSymbol < 0) return (bySymbol: const {}, asOf: null);

    double? valueAt(List<String> parts, int idx) {
      if (idx < 0 || idx >= parts.length) return null;
      final raw = parts[idx].trim().replaceAll('%', '');
      if (raw.isEmpty || raw == '-' || raw.toUpperCase() == 'NA') return null;
      final value = double.tryParse(raw);
      if (value == null || value < 0 || value > 100) return null;
      return value;
    }

    DateTime? asOf;
    final bySymbol = <String, IvSheetRow>{};
    for (var i = 1; i < lines.length; i++) {
      final parts = _splitCsvLine(lines[i]);
      if (parts.length <= iSymbol) continue;
      final symbol = parts[iSymbol].trim().toUpperCase();
      if (symbol.isEmpty) continue;
      final row = IvSheetRow(
        ivp: valueAt(parts, iIvp),
        ivr: valueAt(parts, iIvr),
      );
      if (row.isEmpty) continue;
      bySymbol[symbol] = row;
      if (asOf == null && iDate >= 0 && iDate < parts.length) {
        final rawDate = parts[iDate].trim();
        if (rawDate.isNotEmpty) {
          asOf = DateTime.tryParse(rawDate) ??
              _ddMmmYyyy(rawDate) ??
              _ddMmYyyy(rawDate);
        }
      }
    }
    return (bySymbol: bySymbol, asOf: asOf);
  }

  static DateTime? _ddMmmYyyy(String raw) {
    final m = RegExp(r'^(\d{1,2})[-/ ]([A-Za-z]{3})[-/ ](\d{4})').firstMatch(raw);
    if (m == null) return null;
    const months = {
      'JAN': 1, 'FEB': 2, 'MAR': 3, 'APR': 4, 'MAY': 5, 'JUN': 6,
      'JUL': 7, 'AUG': 8, 'SEP': 9, 'OCT': 10, 'NOV': 11, 'DEC': 12,
    };
    final month = months[m.group(2)!.toUpperCase()];
    if (month == null) return null;
    return DateTime(int.parse(m.group(3)!), month, int.parse(m.group(1)!));
  }

  static DateTime? _ddMmYyyy(String raw) {
    final m = RegExp(r'^(\d{1,2})[-/](\d{1,2})[-/](\d{4})').firstMatch(raw);
    if (m == null) return null;
    return DateTime(
      int.parse(m.group(3)!),
      int.parse(m.group(2)!),
      int.parse(m.group(1)!),
    );
  }

  /// Normalises whatever the user pasted into a fetchable public CSV URL.
  /// Returns null when the link is not a Google Sheets URL (honest error).
  static String? normalizeUrl(String raw) {
    final text = raw.trim();
    if (text.isEmpty) return null;
    // Already a published-CSV link.
    if (text.contains('/pub?') && text.contains('output=csv')) return text;
    final idMatch = RegExp(r'/spreadsheets/d/(?:e/)?([a-zA-Z0-9-_]+)')
        .firstMatch(text);
    if (idMatch == null) return null;
    final id = idMatch.group(1)!;
    if (text.contains('/spreadsheets/d/e/')) {
      // Published-to-web id — the pub?output=csv form.
      return 'https://docs.google.com/spreadsheets/d/e/$id/pub?output=csv';
    }
    final gidMatch = RegExp(r'[#&?]gid=(\d+)').firstMatch(text);
    final gid = gidMatch?.group(1) ?? '0';
    return 'https://docs.google.com/spreadsheets/d/$id/export?format=csv&gid=$gid';
  }
}

/// Fetches + caches the sheet. Screens share this one instance.
class IvSheetStore extends ChangeNotifier {
  IvSheetStore({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;

  static final IvSheetStore instance = IvSheetStore();

  static const String urlKey = 'iv_sheet_url';

  Map<String, IvSheetRow> bySymbol = const {};
  DateTime? asOf;
  DateTime? fetchedAt;
  String? error;
  String? sourceUrl;
  bool loadedOnce = false;

  IvSheetRow? forSymbol(String symbol) => bySymbol[symbol.toUpperCase()];

  /// Reads the saved URL from settings and refetches. Returns false when no
  /// URL is configured or the fetch failed — [error] says why.
  Future<bool> refreshFromSettings(SettingsDao settings) async {
    String? url;
    try {
      final map = await settings.raw();
      url = map[urlKey];
    } catch (e) {
      error = '$e';
      notifyAll();
      return false;
    }
    if (url == null || url.trim().isEmpty) {
      error = 'IV sheet set nahi hai — Settings me Google Sheet link daalo.';
      notifyAll();
      return false;
    }
    return refresh(url);
  }

  /// Fetches [rawUrl] (any pasted Google Sheets link) and repopulates the
  /// cache. Values outside 0–100 or unmapped rows are dropped honestly.
  Future<bool> refresh(String rawUrl) async {
    final url = IvSheetParsers.normalizeUrl(rawUrl);
    if (url == null) {
      error = 'Google Sheets link sahi nahi lag raha.';
      notifyAll();
      return false;
    }
    try {
      final response = await _client.get(
        Uri.parse(url),
        headers: const {
          'User-Agent':
              'Mozilla/5.0 (Linux; Android 13; K) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
        },
      );
      if (response.statusCode != 200) {
        throw IvSheetException('Sheet fetch fail — HTTP ${response.statusCode}');
      }
      final parsed = IvSheetParsers.parseCsv(response.body);
      if (parsed.bySymbol.isEmpty) {
        throw IvSheetException(
            'Sheet me koi valid row nahi (symbol/ivp/ivr columns check karo).');
      }
      bySymbol = parsed.bySymbol;
      asOf = parsed.asOf;
      sourceUrl = rawUrl.trim();
      fetchedAt = DateTime.now();
      error = null;
      loadedOnce = true;
      notifyAll();
      // 1.5.74 — IVP/IVR extremes signal (jo abhi extreme me aaye, wahi alert).
      try {
        final rows = <(String, double, double)>[];
        bySymbol.forEach((symbol, row) {
          final ivp = row.ivp;
          final ivr = row.ivr;
          if (ivp != null && ivr != null) rows.add((symbol, ivp, ivr));
        });
        AlertsCenter.instance.checkIvExtremes(rows);
      } catch (_) {}
      return true;
    } catch (e) {
      error = '$e';
      loadedOnce = true;
      notifyAll();
      return false;
    }
  }

  /// Screens listen via [ChangeNotifier] (1.5.57 — ListenableBuilder support).
  /// [notifyAll] keeps the service's original name for its internal call sites.
  void notifyAll() => notifyListeners();
}
