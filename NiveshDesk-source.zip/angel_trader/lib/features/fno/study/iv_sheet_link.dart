// ---------------------------------------------------------------------------
// iv_sheet_link.dart — shared UI for the Opstra IVP/IVR Google Sheet (1.5.57):
// one universal link dialog (used from Settings and the AI Jodi toolbar) and
// the compact per-stock chip both study screens show. All three screens read
// the same IvSheetStore cache, so one link feeds everything.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/widgets/ui.dart';
import '../../../data/local/dao/settings_dao.dart';
import 'ai_jodi_engine.dart';
import 'iv_sheet.dart';

/// What kind of premium the IVP/IVR values describe — drives chip colours.
enum IvChipKind { none, cheap, mid, rich }

/// Pure chip model: the label text + bucket for a pair of IVP/IVR values.
/// Missing values stay missing — the chip hides itself (kind.none).
({String label, IvChipKind kind}) ivChip(double? ivp, double? ivr) {
  final values = [
    if (ivp != null) ivp,
    if (ivr != null) ivr,
  ];
  if (values.isEmpty) return (label: '', kind: IvChipKind.none);
  final eff = values.reduce((a, b) => a > b ? a : b);
  final kind = eff >= AiJodiRules.ivRichFloorPct
      ? IvChipKind.rich
      : eff <= AiJodiRules.ivCheapCeilPct
          ? IvChipKind.cheap
          : IvChipKind.mid;
  final label =
      'IVP ${ivp?.toStringAsFixed(0) ?? '—'} · IVR ${ivr?.toStringAsFixed(0) ?? '—'}';
  return (label: label, kind: kind);
}

/// IVP + IVR metric boxes (1.5.69) — 3-Month Study aur 3-Month Advance Study
/// ke cards ke andar, 1.5.58 style (har value apne box me). Sheet me value na
/// ho to '—' (honest absence — chip ke ulat boxes hide nahi hote, feature
/// dikhta rehta hai). Dono boxes sheet-fetch par khud update hote hain.
List<Widget> ivMetricBoxes(String symbol) => [
      ListenableBuilder(
        listenable: IvSheetStore.instance,
        builder: (context, _) {
          final row = IvSheetStore.instance.forSymbol(symbol);
          return MetricBox(
            emoji: '🧮',
            label: 'IVP',
            value: row?.ivp == null ? '—' : row!.ivp!.toStringAsFixed(0),
            sub: 'Opstra sheet',
            tooltip: 'IV Percentile (0–100) — Google Sheet se. Zyada = '
                'premium apne itihaas me mehnga. Sheet me value na ho to —',
          );
        },
      ),
      ListenableBuilder(
        listenable: IvSheetStore.instance,
        builder: (context, _) {
          final row = IvSheetStore.instance.forSymbol(symbol);
          return MetricBox(
            emoji: '📏',
            label: 'IVR',
            value: row?.ivr == null ? '—' : row!.ivr!.toStringAsFixed(0),
            sub: 'Opstra sheet',
            tooltip: 'IV Rank (0–100) — Google Sheet se. Sheet me value na '
                'ho to —',
          );
        },
      ),
    ];

/// The compact per-stock chip (1.5.57): `⭐ IVP 30 · IVR 20` (cheap, green),
/// `IVP 55 · IVR 60` (mid, neutral), `⚠️ IVP 72 · IVR 80` (rich, orange —
/// warning only, study screens never gate). Hidden when the sheet has no
/// values for the symbol.
class IvSheetChip extends StatelessWidget {
  const IvSheetChip({super.key, required this.symbol, this.fontSize = 10.5});

  final String symbol;
  final double fontSize;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: IvSheetStore.instance,
      builder: (context, _) {
        final row = IvSheetStore.instance.forSymbol(symbol);
        final (:label, :kind) = ivChip(row?.ivp, row?.ivr);
        if (kind == IvChipKind.none) return const SizedBox.shrink();
        final scheme = Theme.of(context).colorScheme;
        final (bg, fg, prefix) = switch (kind) {
          IvChipKind.cheap => (
              Colors.green.shade100,
              Colors.green.shade900,
              '⭐ ',
            ),
          IvChipKind.rich => (
              Colors.orange.shade100,
              Colors.orange.shade900,
              '⚠️ ',
            ),
          IvChipKind.mid || IvChipKind.none => (
              scheme.surfaceContainerHighest,
              scheme.onSurfaceVariant,
              '',
            ),
        };
        return Container(
          margin: const EdgeInsets.only(top: 3, right: 4),
          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1.5),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(6),
          ),
          child: Text(
            '$prefix$label',
            style: TextStyle(
              fontSize: fontSize,
              fontWeight: FontWeight.w700,
              color: fg,
            ),
          ),
        );
      },
    );
  }
}

/// Refreshes the shared IV sheet cache when a [SettingsDao] is available.
/// Widget tests may pump screens without one — absence must stay harmless
/// (same honest rule: nothing to load from, nothing happens).
void refreshIvSheetIfPossible(BuildContext context) {
  try {
    final settings = context.read<SettingsDao>();
    IvSheetStore.instance.refreshFromSettings(settings);
  } catch (_) {
    // No SettingsDao in this widget tree (tests) — skip the refresh.
  }
}

/// The one sheet-link dialog — Settings and the AI Jodi toolbar both open
/// this. Saving persists `iv_sheet_url` and refreshes the shared cache, so
/// every screen picks the numbers up at once.
Future<void> showIvSheetLinkDialog(BuildContext context) async {
  final store = IvSheetStore.instance;
  final controller = TextEditingController(text: store.sourceUrl ?? '');
  final settings = context.read<SettingsDao>();
  await showDialog<void>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      title: const Text('IVP/IVR sheet (Opstra)'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Google Sheet: columns symbol | ivp | ivr. Sheet "Publish to '
            'web" (CSV) honi chahiye — login/token nahi chahiye. Yeh link '
            'AI Jodi, 3-Month Study aur Study Advance — sab jagah use hoti hai.',
            style: TextStyle(fontSize: 12),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: controller,
            decoration: const InputDecoration(
              labelText: 'Google Sheets link',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 8),
          ListenableBuilder(
            listenable: store,
            builder: (context, _) => Text(
              store.bySymbol.isEmpty
                  ? (store.error ?? 'Abhi koi data load nahi hua.')
                  : '${store.bySymbol.length} stocks · '
                      'as of ${store.asOf ?? store.fetchedAt ?? DateTime.now()}'
                      '${store.error == null ? '' : ' · ${store.error}'}',
              style: const TextStyle(fontSize: 12),
            ),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(dialogContext).pop(),
          child: const Text('Band'),
        ),
        FilledButton(
          onPressed: () async {
            final url = controller.text.trim();
            if (url.isEmpty) return;
            final navigator = Navigator.of(dialogContext);
            await settings.put(IvSheetStore.urlKey, url);
            await store.refresh(url);
            navigator.pop();
          },
          child: const Text('Save + Fetch'),
        ),
      ],
    ),
  );
}
