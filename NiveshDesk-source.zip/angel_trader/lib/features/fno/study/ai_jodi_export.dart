// ---------------------------------------------------------------------------
// ai_jodi_export.dart — the AI Jodi Study list out through the same share
// sheet as the rest of the F&O tools: WhatsApp-style recap text, XLSX, CSV.
// ---------------------------------------------------------------------------

import 'dart:io';

import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';

import 'ai_jodi_engine.dart';

/// One exported line — the table's numbers, flattened.
class AiJodiExportRow {
  const AiJodiExportRow({
    required this.symbol,
    required this.companyName,
    required this.ltp,
    required this.atr,
    this.avgRange = 0,
    required this.avgDailyMove15,
    required this.monthsMeeting20,
    required this.monthlyMoveRupee,
    required this.atmJodi,
    required this.otmJodi,
    required this.coverAtm,
    required this.coverOtm,
    required this.verdict,
    required this.kalAtmPnl,
    required this.kalOtmPnl,
    required this.ivRank,
    required this.isManual,
    this.ivp,
    this.ivr,
  });

  final String symbol;
  final String companyName;
  final double ltp;
  final double atr;

  /// 14-session simple (High − Low) average, ₹ — display-only column.
  final double avgRange;
  final double avgDailyMove15;
  final int monthsMeeting20;
  final double monthlyMoveRupee;
  final double? atmJodi;
  final double? otmJodi;
  final double? coverAtm;
  final double? coverOtm;
  final String verdict;
  final double? kalAtmPnl;
  final double? kalOtmPnl;
  final String ivRank;
  final bool isManual;

  /// Opstra sheet values (1.5.56) — null = data nahi.
  final double? ivp;
  final double? ivr;
}

abstract final class AiJodiExport {
  static const String disclaimer = AiJodiRules.disclaimer;

  static final List<String> headers = [
    'Stock',
    'Company',
    'Price',
    'ATR',
    'Avg Range',
    '15-din avg move',
    'Months 20%+ (of 3)',
    'Monthly move ₹',
    'ATM jodi ₹',
    'OTM jodi ₹',
    'ATM cover',
    'OTM cover',
    'Verdict',
    'Kal ATM P&L ₹',
    'Kal OTM P&L ₹',
    'IV rank',
    'IVP',
    'IVR',
    'Manual',
  ];

  static List<String> cells(AiJodiExportRow row) => [
        row.symbol,
        row.companyName,
        _n(row.ltp),
        _n(row.atr),
        row.avgRange > 0 ? _n(row.avgRange) : '',
        _n(row.avgDailyMove15),
        '${row.monthsMeeting20}/3',
        _n(row.monthlyMoveRupee),
        row.atmJodi == null ? '' : _n(row.atmJodi!),
        row.otmJodi == null ? '' : _n(row.otmJodi!),
        row.coverAtm == null ? '' : _n(row.coverAtm!),
        row.coverOtm == null ? '' : _n(row.coverOtm!),
        row.verdict,
        row.kalAtmPnl == null ? '' : _n(row.kalAtmPnl!),
        row.kalOtmPnl == null ? '' : _n(row.kalOtmPnl!),
        row.ivRank,
        row.ivp == null ? '' : _n(row.ivp!),
        row.ivr == null ? '' : _n(row.ivr!),
        row.isManual ? 'haan' : '',
      ];

  static String _n(double value) => value.toStringAsFixed(2);

  static String _csv(String value) =>
      value.contains(',') || value.contains('"')
          ? '"${value.replaceAll('"', '""')}"'
          : value;

  /// WhatsApp/Telegram-style recap — one line per stock.
  static String recap(List<AiJodiExportRow> rows, DateTime asOf) {
    final buffer = StringBuffer()
      ..writeln('NiveshDesk — AI Jodi Study')
      ..writeln('AI Calculation & Chart Study · rules: 15-din avg move > ATR, '
          'month 20%+ (mostly), movement > jodi, buy at 2× cover')
      ..writeln(disclaimer)
      ..writeln('');
    for (final row in rows) {
      buffer.write('${row.symbol} ₹${row.ltp.toStringAsFixed(1)}');
      buffer.write(
        ' · ATR ₹${row.atr.toStringAsFixed(1)}'
        '${row.avgRange > 0 ? ' · Range ₹${row.avgRange.toStringAsFixed(1)}' : ''}'
        ' · ATM jodi ${row.atmJodi == null ? '—' : '₹${row.atmJodi!.toStringAsFixed(1)}'}'
        ' · OTM jodi ${row.otmJodi == null ? '—' : '₹${row.otmJodi!.toStringAsFixed(1)}'}',
      );
      buffer.write(' → ${row.verdict}');
      if (row.kalAtmPnl != null) {
        buffer.write(
          ' (kal: ATM ${row.kalAtmPnl! >= 0 ? '+' : ''}'
          '₹${row.kalAtmPnl!.toStringAsFixed(1)})',
        );
      }
      buffer.write(' · ${row.ivRank}');
      if (row.isManual) buffer.write(' · aapka add kiya');
      buffer.writeln('');
    }
    return buffer.toString().trimRight();
  }

  /// The workbook, in the app's documents folder.
  static Future<File> writeXlsx(
    List<AiJodiExportRow> rows, {
    required DateTime asOf,
    String? fileName,
  }) async {
    final book = Excel.createExcel();
    final sheet = book['AI Jodi Study'];
    sheet.appendRow([for (final header in headers) TextCellValue(header)]);
    for (final row in rows) {
      sheet.appendRow([
        for (final cell in cells(row))
          TextCellValue(cell),
      ]);
    }
    sheet.appendRow([TextCellValue(disclaimer)]);
    if (book.sheets.containsKey('Sheet1')) book.delete('Sheet1');
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/${fileName ?? _name(asOf, 'xlsx')}');
    await file.writeAsBytes(book.encode()!, flush: true);
    return file;
  }

  static Future<File> writeCsv(
    List<AiJodiExportRow> rows, {
    required DateTime asOf,
    String? fileName,
  }) async {
    final buffer = StringBuffer()
      ..writeln('# NiveshDesk — AI Jodi Study')
      ..writeln('# $disclaimer')
      ..writeln(headers.map(_csv).join(','));
    for (final row in rows) {
      buffer.writeln(cells(row).map(_csv).join(','));
    }
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/${fileName ?? _name(asOf, 'csv')}');
    await file.writeAsString(buffer.toString(), flush: true);
    return file;
  }

  static String _name(DateTime asOf, String ext) {
    final y = asOf.year.toString().padLeft(4, '0');
    final m = asOf.month.toString().padLeft(2, '0');
    final d = asOf.day.toString().padLeft(2, '0');
    return 'ai_jodi_study_$y$m$d.$ext';
  }
}
