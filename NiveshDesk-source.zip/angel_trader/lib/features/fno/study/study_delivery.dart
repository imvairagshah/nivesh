// ---------------------------------------------------------------------------
// study_delivery.dart — where a finished study goes.
//
//   • WhatsApp  → recap text through the share sheet (user picks the app)
//   • Excel     → the 3-sheet workbook, shared as a file
//   • CSV       → the flat table, shared as a file
//   • Telegram  → real Bot API upload (needs bot token + chat id in settings)
//
// Telegram is the only one that talks to the network itself. It follows the
// spec: upload the **XLSX as a document**, not a text dump — and when the
// credentials are missing, say so in Hinglish instead of failing silently.
// ---------------------------------------------------------------------------

import 'dart:convert';
import 'dart:io';

import '../../../core/utils/share_helper.dart';

import '../../../data/local/models/app_settings.dart';
import 'study_engine.dart';
import 'study_export.dart';

/// Menu actions offered on the study screen.
enum StudyExportKind {
  whatsapp('WhatsApp pe text'),
  excel('Excel file (.xlsx)'),
  csv('CSV file'),
  telegram('Telegram pe bhejo');

  const StudyExportKind(this.label);
  final String label;
}

/// What happened — the screen shows [message] in a snackbar.
class StudyDeliveryOutcome {
  final bool ok;
  final String message;

  const StudyDeliveryOutcome({required this.ok, required this.message});
}

class StudyDeliveryService {
  StudyDeliveryService({required StudyExportService export, HttpClient? http})
      : _export = export,
        _http = http ?? HttpClient();

  final StudyExportService _export;
  final HttpClient _http;

  /// Sends the study out through [kind]. [rows] is whatever the table currently
  /// shows, so a filtered view exports filtered data — no surprises.
  Future<StudyDeliveryOutcome> deliver({
    required StudyExportKind kind,
    required List<StudyRow> rows,
    required FnoStudyExportMeta meta,
    required AppSettings settings,
  }) async {
    if (rows.isEmpty) {
      return const StudyDeliveryOutcome(
        ok: false,
        message: 'Pehle scan chalao — table khaali hai.',
      );
    }

    try {
      switch (kind) {
        case StudyExportKind.whatsapp:
          return await _shareText(recap(rows, meta));
        case StudyExportKind.excel:
          return await _shareFile(
            await _export.writeXlsx(rows: rows, meta: meta),
            'NiveshDesk 3-Month Study',
          );
        case StudyExportKind.csv:
          return await _shareFile(
            await _export.writeCsv(rows: rows, meta: meta),
            'NiveshDesk 3-Month Study (CSV)',
          );
        case StudyExportKind.telegram:
          return await _sendTelegram(rows: rows, meta: meta, settings: settings);
      }
    } catch (e) {
      return StudyDeliveryOutcome(ok: false, message: 'Export fail: $e');
    }
  }

  // -------------------------------------------------------------------------
  // Generic delivery — used by the other F&O tools (AI Suggestion), so their
  // exports go out through the same share sheet and the same Telegram bot.
  // -------------------------------------------------------------------------

  Future<StudyDeliveryOutcome> shareText(String text) => _shareText(text);

  Future<StudyDeliveryOutcome> shareFile(File file, String subject) =>
      _shareFile(file, subject);

  /// Sends an already-built file to the Telegram chat configured in Settings.
  Future<StudyDeliveryOutcome> sendTelegramFile({
    required File file,
    required String caption,
    required AppSettings settings,
  }) async {
    final token = settings.telegramBotToken.trim();
    final chatId = settings.telegramChatId.trim();
    if (token.isEmpty || chatId.isEmpty) {
      return const StudyDeliveryOutcome(
        ok: false,
        message: 'Telegram ke liye Settings me bot token + chat id daalo '
            '(@BotFather se bot banao, phir bot ko /start bhejo).',
      );
    }
    try {
      await _postDocument(
        token: token,
        chatId: chatId,
        file: file,
        caption: caption,
      );
      return const StudyDeliveryOutcome(
        ok: true,
        message: 'Telegram pe file bhej di.',
      );
    } catch (e) {
      return StudyDeliveryOutcome(ok: false, message: 'Telegram fail: $e');
    }
  }

  // -------------------------------------------------------------------------
  // Share sheet (WhatsApp / Excel / CSV)
  // -------------------------------------------------------------------------

  Future<StudyDeliveryOutcome> _shareText(String text) async {
    // 1.5.72 — desktop par share sheet nahi: file Downloads me save hoti hai.
    final r = await ShareHelper.shareText(text,
        subject: 'NiveshDesk 3-Month Study');
    return StudyDeliveryOutcome(ok: r.ok, message: r.message);
  }

  Future<StudyDeliveryOutcome> _shareFile(File file, String subject) async {
    final r = await ShareHelper.shareFile(file, subject);
    return StudyDeliveryOutcome(ok: r.ok, message: r.message);
  }

  // -------------------------------------------------------------------------
  // Telegram (Bot API)
  // -------------------------------------------------------------------------

  Future<StudyDeliveryOutcome> _sendTelegram({
    required List<StudyRow> rows,
    required FnoStudyExportMeta meta,
    required AppSettings settings,
  }) async {
    final token = settings.telegramBotToken.trim();
    final chatId = settings.telegramChatId.trim();
    if (token.isEmpty || chatId.isEmpty) {
      return const StudyDeliveryOutcome(
        ok: false,
        message: 'Telegram ke liye Settings me bot token + chat id daalo '
            '(@BotFather se bot banao, phir bot ko /start bhejo).',
      );
    }

    try {
      final file = await _export.writeXlsx(rows: rows, meta: meta);
      await _postDocument(
        token: token,
        chatId: chatId,
        file: file,
        caption: recap(rows, meta),
      );
      return const StudyDeliveryOutcome(
        ok: true,
        message: 'Telegram pe XLSX bhej di.',
      );
    } catch (e) {
      return StudyDeliveryOutcome(ok: false, message: 'Telegram fail: $e');
    }
  }

  Future<void> _postDocument({
    required String token,
    required String chatId,
    required File file,
    required String caption,
  }) async {
    final boundary = '----NiveshDesk${DateTime.now().microsecondsSinceEpoch}';
    final request = await _http
        .postUrl(Uri.parse('https://api.telegram.org/bot$token/sendDocument'));
    request.headers.set(
      HttpHeaders.contentTypeHeader,
      'multipart/form-data; boundary=$boundary',
    );

    void field(String name, String value) {
      request.add(utf8.encode('--$boundary\r\n'
          'Content-Disposition: form-data; name="$name"\r\n\r\n'
          '$value\r\n'));
    }

    field('chat_id', chatId);
    field('caption',
        caption.length > 1000 ? caption.substring(0, 1000) : caption);
    request.add(utf8.encode('--$boundary\r\n'
        'Content-Disposition: form-data; name="document"; '
        'filename="${file.uri.pathSegments.last}"\r\n'
        'Content-Type: application/vnd.openxmlformats-officedocument.'
        'spreadsheetml.sheet\r\n\r\n'));
    request.add(await file.readAsBytes());
    request.add(utf8.encode('\r\n--$boundary--\r\n'));

    final response = await request.close();
    final body = await response.transform(utf8.decoder).join();
    final decoded = jsonDecode(body);
    final ok = decoded is Map && decoded['ok'] == true;
    if (response.statusCode != 200 || !ok) {
      throw HttpException('Telegram ne mana kar diya: $body');
    }
  }

  // -------------------------------------------------------------------------
  // Text recap (WhatsApp / Telegram caption)
  // -------------------------------------------------------------------------

  /// Short Hinglish summary that reads fine in a messaging app.
  static String recap(List<StudyRow> rows, FnoStudyExportMeta meta) {
    final best = rows.where((r) => r.isBestBuy).toList();
    final buffer = StringBuffer()
      ..writeln('*NiveshDesk — F&O 3-Month Study*')
      ..writeln('Study date: ${StudyExportService.isoDate(meta.asOf)}')
      ..writeln('Stocks scan: ${rows.length} · Best-buy: ${best.length}')
      ..writeln();

    for (final row in (best.isEmpty ? rows.take(5) : best.take(5))) {
      buffer.writeln('${row.opportunityTag} '
          '${row.symbol} — ${row.trend.label} (score ${row.score.toStringAsFixed(1)})');
      buffer.writeln('   CMP ${StudyExportService.money(row.ltp)} · '
          '3M move ${StudyExportService.perc(row.total3mPct)} · '
          '${row.atmStrike == null ? 'ATM data nahi' : 'ATM ${row.atmStrike!.toStringAsFixed(0)} ${row.trend.suggested}'} '
          '· IV rank ${row.ivRank.short}');
      if (row.straddleYesterday != null) {
        buffer.writeln('   Kal jodi hoti: ${StudyExportService.yesterdayWords(row)}');
      }
    }

    buffer
      ..writeln()
      ..writeln(StudyExportService.disclaimer);
    return buffer.toString();
  }
}
