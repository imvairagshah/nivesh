// ---------------------------------------------------------------------------
// study_engine.dart — the "3-Month Study" maths, straight from the spec.
//
// Pure Dart: no Flutter, no network, no database. One stock in → one [StudyRow]
// out; then [rankStudy] does the universe-wide pass (IV rank, opportunity tag,
// ranks). Everything is deterministic and unit-tested against hand-computed
// numbers, because a scanner whose score cannot be reproduced is a scanner
// nobody can act on.
//
// What it computes, in the spec's order:
//
//   2.1  63-day window → ltp, high3m, low3m, rangePct
//   2.2  Wilder ATR(14) over the *full* series → atrPct
//   2.3  distance from the 3-month high/low, in % and in ATR-days
//   2.4  month-wise movement (last 3 calendar months) + total move + up/down months
//   2.5  trend classification + suggested action (first matching rule wins)
//   2.6  ATM CE/PE enrichment → avgIv (broker IV first, Black-Scholes fallback)
//   2.7  edgePct = atrPct − avgIv/√252   (what the stock does vs what the option
//        market has priced in)
//   2.8  score 0–12 (consistency · magnitude · proximity · IV)
//   2.9  IV rank across the universe (thirds → Low / Medium / High)
//   2.10 opportunity tag (🎯 Best Buy / ⏸ Watch / -)
//   2.11 sort: best buys first, then score descending
//   2.12 the one-line reason string
// ---------------------------------------------------------------------------

import 'dart:math' as math;

import '../../../core/utils/markets.dart';
import '../../../data/remote/dto/candle.dart';
import '../../../data/remote/dto/scrip.dart';
import 'black_scholes.dart';

// ---------------------------------------------------------------------------
// Constants straight from the spec
// ---------------------------------------------------------------------------

/// Trading days in a year — the annualisation factor for the implied 1-day move.
const int kTradingDaysPerYear = 252;

/// The study window: roughly three months of sessions.
const int kStudyWindowBars = 63;

/// Below this many bars a stock is skipped rather than scored (spec §1).
const int kStudyMinimumBars = 60;

/// Wilder ATR period.
const int kAtrPeriod = 14;

/// Trend thresholds (spec §2.5).
const double kStrongTrendPct = 6.0;
const double kTrendPct = 1.5;

/// A 55 %+ IV is "mehenga" and costs a point in the score (spec §2.8).
const double kExpensiveIvPct = 55;

/// Which set of scoring rules to apply.
///
/// The classic 3-Month Study page (and the AI Suggestion gate) must keep the
/// numbers it has always produced, so every rule below defaults to the old
/// behaviour. "3 Month Study with Advance Filter" passes [StudyRules.advanced]
/// and gets the corrected arithmetic — two rule sets, one engine, no fork.
class StudyRules {
  const StudyRules({
    this.name = 'classic',
    this.symmetricDistance = false,
    this.minSessionsPerMonth = 0,
    this.requireFullMonths = false,
    this.bestBuyNeedsEdge = false,
    this.demoteNearExpiry = 0,
  });

  /// `classic` / `advanced` — lets a caller (the study service) tell whether
  /// the run it is holding is the old page's snapshot or the new page's.
  final String name;

  /// F2 fix: measure both distances from CMP instead of dividing one by the
  /// 3-month high and the other by CMP (which made up- and down-trend
  /// proximity points incomparable).
  final bool symmetricDistance;

  /// F3 fix: a month with fewer than this many sessions is not a month — it is
  /// folded into the one before it. `0` = today's behaviour (keep it).
  final int minSessionsPerMonth;

  /// F4 fix: with fewer than three months of history, consistency cannot claim
  /// a full 3.0 (`points` is capped at the number of months actually seen).
  final bool requireFullMonths;

  /// F1 fix: "IV sasta" alone must not earn a 🎯 when the premium is dearer
  /// than the stock's own move (edge < 0). Low IV + negative edge → ⏸ Watch.
  final bool bestBuyNeedsEdge;

  /// A5 fix: with [demoteNearExpiry] days or fewer left, a 🎯 is a trap —
  /// theta eats the premium faster than the stock can move. `0` = never
  /// demote (the classic page's behaviour, untouched).
  final int demoteNearExpiry;

  /// Exactly what the 3-Month Study has always done.
  static const StudyRules classic = StudyRules();

  /// The corrected rules used by the advance-filter page.
  static const StudyRules advanced = StudyRules(
    name: 'advanced',
    symmetricDistance: true,
    minSessionsPerMonth: 5,
    requireFullMonths: true,
    bestBuyNeedsEdge: true,
    demoteNearExpiry: 3,
  );
}

// ---------------------------------------------------------------------------
// Enums + small models
// ---------------------------------------------------------------------------

enum Trend3M {
  strongUp('STRONG UP'),
  up('UP'),
  sideways('SIDEWAYS'),
  down('DOWN'),
  strongDown('STRONG DOWN');

  const Trend3M(this.label);
  final String label;

  bool get isUp => this == strongUp || this == up;
  bool get isDown => this == strongDown || this == down;

  /// `BUY CE` / `BUY PE` / `AVOID`.
  String get suggested => isUp ? 'BUY CE' : (isDown ? 'BUY PE' : 'AVOID');
}

enum IvRank {
  low('Low', 'Low IV'),
  medium('Medium', 'Medium IV'),
  high('High', 'High IV'),
  unknown('—', 'IV data nahi');

  const IvRank(this.short, this.label);
  final String short;
  final String label;
}

/// One calendar month's move inside the study window.
class MonthMove {
  /// `Aug-25` — what the table and the export show.
  final String label;

  /// `2025-08` — the key it was grouped by.
  final String key;

  final double pct;

  /// High−low range of the month as a % of its first close — the AI Jodi
  /// Study's "mahine me 20-30% ki movement" measure. `0` when unknown
  /// (rows saved by older builds).
  final double rangePct;

  const MonthMove({
    required this.label,
    required this.key,
    required this.pct,
    this.rangePct = 0,
  });

  bool get isUp => pct > 0;
  bool get isDown => pct < 0;

  Map<String, dynamic> toJson() => {
        'label': label,
        'key': key,
        'pct': pct,
        'rangePct': rangePct,
      };

  static MonthMove fromJson(Map<String, dynamic> json) => MonthMove(
        label: '${json['label']}',
        key: '${json['key']}',
        pct: (json['pct'] as num? ?? 0).toDouble(),
        rangePct: (json['rangePct'] as num? ?? 0).toDouble(),
      );
}

/// The ATM CE/PE pair that came back from the broker (or the Black-Scholes
/// fallback). Every field is nullable on purpose: a stock whose option data
/// failed is kept in the table in **degraded mode** (spec §6) instead of being
/// dropped.
class StudyOptionLeg {
  /// Strike in rupees (`2650.0`).
  final double strike;
  final OptionType type;
  final String token;

  /// Broker symbol, e.g. `RELIANCE26JAN2650CE`.
  final String symbol;

  /// Traded premium now.
  final double? ltp;

  /// Previous session's close — only the broker's full quote carries it.
  final double? previousClose;

  /// Implied volatility in **percent** units (`28.5`, not `0.285`).
  final double? iv;

  /// Where the IV came from — shown in the detail panel and the export.
  final IvSource ivSource;

  final IvFailure? ivFailure;

  const StudyOptionLeg({
    required this.strike,
    required this.type,
    required this.token,
    required this.symbol,
    this.ltp,
    this.previousClose,
    this.iv,
    this.ivSource = IvSource.none,
    this.ivFailure,
  });

  bool get hasPrice => (ltp ?? 0) > 0;
  bool get hasClose => (previousClose ?? 0) > 0;

  StudyOptionLeg copyWith({
    double? ltp,
    double? previousClose,
    double? iv,
    IvSource? ivSource,
    IvFailure? ivFailure,
  }) =>
      StudyOptionLeg(
        strike: strike,
        type: type,
        token: token,
        symbol: symbol,
        ltp: ltp ?? this.ltp,
        previousClose: previousClose ?? this.previousClose,
        iv: iv ?? this.iv,
        ivSource: ivSource ?? this.ivSource,
        ivFailure: ivFailure ?? this.ivFailure,
      );

  Map<String, dynamic> toJson() => {
        'strike': strike,
        'type': type.code,
        'token': token,
        'symbol': symbol,
        'ltp': ltp,
        'prevClose': previousClose,
        'iv': iv,
        'ivSource': ivSource.name,
        'ivFailure': ivFailure?.name,
      };

  static StudyOptionLeg fromJson(Map<String, dynamic> json) => StudyOptionLeg(
        strike: (json['strike'] as num? ?? 0).toDouble(),
        type: OptionType.fromCode('${json['type']}') ?? OptionType.call,
        token: '${json['token'] ?? ''}',
        symbol: '${json['symbol'] ?? ''}',
        ltp: (json['ltp'] as num?)?.toDouble(),
        previousClose: (json['prevClose'] as num?)?.toDouble(),
        iv: (json['iv'] as num?)?.toDouble(),
        ivSource: IvSource.values.firstWhere(
          (s) => s.name == '${json['ivSource']}',
          orElse: () => IvSource.none,
        ),
        ivFailure: IvFailure.values
            .where((f) => f.name == '${json['ivFailure']}')
            .firstOrNull,
      );
}

/// Where an IV number came from — never hidden from the user.
enum IvSource {
  none('—'),
  broker('Angel option chain'),
  blackScholes('Black-Scholes (premium se)');

  const IvSource(this.label);
  final String label;
}

/// A premium as a share of the stock's own price, in percent — "ye jodi
/// stock ke bhav ka kitna % hai".
///
/// Null when either number is missing or the price is zero: a blank is
/// honest, a 0 is a lie the user would act on. One helper so the card, the
/// panel and the export all divide the same way.
double? premiumPctOfPrice(double? premium, double price) {
  if (premium == null || price <= 0) return null;
  return premium / price * 100;
}

/// Where the study may take implied volatility from (B1).
///
/// The broker's option-greek endpoint costs **one request per stock** (~213 a
/// scan) and answers live contracts only; Black-Scholes costs nothing here —
/// the premium is already in hand, so the IV is solved on the phone. Which of
/// the two a user wants is a preference, not a technicality, so it is a
/// setting rather than a constant.
enum StudyIvSource {
  /// Broker first, our own maths when the broker has nothing. The default,
  /// and what the app has always done — nothing changes for anyone.
  auto('Auto — broker, na mile to apna hisaab'),

  /// Broker only. No broker IV means no IV on that row: nothing is invented.
  broker('Sirf broker'),

  /// Never call the broker — solve every IV from the premium. Zero extra
  /// requests, the fastest scan, and the one that cannot hit a rate limit.
  blackScholes('Sirf apna hisaab (Black-Scholes)');

  const StudyIvSource(this.label);

  final String label;

  /// Stored in settings as a plain string; an unrecognised value must never
  /// break a scan, so anything unexpected falls back to [auto].
  static StudyIvSource fromName(String? name) => switch (name) {
        'broker' => StudyIvSource.broker,
        'blackScholes' => StudyIvSource.blackScholes,
        _ => StudyIvSource.auto,
      };

  /// `auto` | `broker` | `blackScholes` — the key the settings table stores.
  String get name => switch (this) {
        StudyIvSource.auto => 'auto',
        StudyIvSource.broker => 'broker',
        StudyIvSource.blackScholes => 'blackScholes',
      };

  /// One line on why it matters, shown under the setting.
  String get hint => switch (this) {
        StudyIvSource.auto =>
          'Broker se IV maango (~1 request prati stock), na mile to premium se '
              'khud solve kar lo. Sabse poora, sabse dheema.',
        StudyIvSource.broker =>
          'Sirf broker ki IV. Jiske liye broker ne IV nahi di, us row par IV '
              'khali rahega — kuch banaya nahi jayega.',
        StudyIvSource.blackScholes =>
          'Broker ko ek bhi call nahi. Har IV premium se solve hoga — sabse '
              'tez scan, aur rate limit ka koi dar nahi.',
      };
}

/// Everything the study knows about one stock.
class StudyRow {
  // -- identity ------------------------------------------------------------
  final String symbol;
  final String companyName;
  final Exchange exchange;

  /// Underlying's cash-market token (the F&O underlying trades as an equity).
  final String token;

  /// `STOCK` scanning happened; kept so a future F&O paper module can reuse it.
  final String underlying;

  // -- 2.1 window + levels -------------------------------------------------
  final double ltp;
  final double high3m;
  final double low3m;
  final double rangePct;

  // -- 2.2 ATR -------------------------------------------------------------
  final double atr;
  final double atrPct;

  /// Simple (High − Low) average of the last 14 sessions, ₹ and % of price —
  /// "din ka average range" without the gap leg. Optional so older saved rows
  /// still load (0 = the snapshot predates the field).
  final double avgRange;
  final double avgRangePct;

  // -- 2.3 distances -------------------------------------------------------
  final double distHiPct;
  final double distLoPct;
  final double distHiDays;
  final double distLoDays;

  // -- 2.4 months ----------------------------------------------------------
  final List<MonthMove> months;
  final double total3mPct;
  final int upMonths;
  final int downMonths;

  // -- 2.5 trend -----------------------------------------------------------
  final Trend3M trend;

  // -- 2.6 options ---------------------------------------------------------
  final double? atmStrike;
  final String? expiryLabel;
  final DateTime? expiryDate;
  final int? daysToExpiry;
  final int lotSize;
  final StudyOptionLeg? ce;
  final StudyOptionLeg? pe;

  /// The pair that was ATM at the **previous session's close** — the jodi a
  /// trader could actually have bought "kal". Today's pair ([ce]/[pe]) is the
  /// wrong contract for that question: after a move it is a strike that was not
  /// ATM when the trade would have been taken, so its "kal ka close" made the
  /// P&L read as a loss on trending stocks. Both legs carry `ltp` (aaj ka
  /// premium) and `previousClose` (kal ka premium = the buy cost).
  final double? kalStrike;
  final StudyOptionLeg? kalCe;
  final StudyOptionLeg? kalPe;

  /// The OTM jodi (strangle) for today's spot — CE above the money, PE below
  /// it, picked at roughly half the ATM jodi's premium. Null when the chain,
  /// the IV or the quotes do not allow one (degradation, never a blank lie).
  final StudyStrangle? strangle;

  /// The same pair as it stood at the **previous session's close** — the OTM
  /// jodi a trader could actually have bought "kal". Its `previousClose` is the
  /// buy cost; its `ltp` is what those same contracts are worth now.
  final StudyStrangle? kalStrangle;

  final double? avgIv;
  final IvSource ivSource;

  // -- 2.7..2.10 computed --------------------------------------------------
  final double? implied1dPct;
  final double? edgePct;
  final double consistencyPoints;
  final double magnitudePoints;
  final double proximityPoints;
  final double ivPoints;
  final double score;
  final IvRank ivRank;
  final String opportunityTag;

  /// Rank across the universe (1 = best).
  final int rank;

  final String reason;

  /// Bars the study used (≥ [kStudyMinimumBars]).
  final int bars;
  final DateTime asOf;

  /// Average cash-market turnover of the last 20 sessions, in ₹ crore — the
  /// "can I actually fill this?" test. The classic page prints nothing; the
  /// advance-filter page shows it and can filter on it. Added as an optional
  /// field on purpose, so nothing that builds a [StudyRow] had to change.
  final double turnoverCrore;

  /// AI Jodi Study: average |close-to-close| move of the last 15 sessions,
  /// in rupees. The user's gate — "15 din me roz ka average move ATR se
  /// zyada ho". Optional so older saved rows still load.
  final double avgDailyMove15;

  const StudyRow({
    required this.symbol,
    required this.companyName,
    required this.exchange,
    required this.token,
    required this.underlying,
    required this.ltp,
    required this.high3m,
    required this.low3m,
    required this.rangePct,
    required this.atr,
    required this.atrPct,
    required this.distHiPct,
    required this.distLoPct,
    required this.distHiDays,
    required this.distLoDays,
    required this.months,
    required this.total3mPct,
    required this.upMonths,
    required this.downMonths,
    required this.trend,
    required this.lotSize,
    required this.consistencyPoints,
    required this.magnitudePoints,
    required this.proximityPoints,
    required this.ivPoints,
    required this.score,
    required this.ivRank,
    required this.opportunityTag,
    required this.rank,
    required this.reason,
    required this.bars,
    required this.asOf,
    this.atmStrike,
    this.expiryLabel,
    this.expiryDate,
    this.daysToExpiry,
    this.ce,
    this.pe,
    this.kalStrike,
    this.kalCe,
    this.kalPe,
    this.strangle,
    this.kalStrangle,
    this.avgIv,
    this.ivSource = IvSource.none,
    this.implied1dPct,
    this.edgePct,
    this.turnoverCrore = 0,
    this.avgDailyMove15 = 0,
    this.avgRange = 0,
    this.avgRangePct = 0,
  });

  String get suggested => trend.suggested;

  bool get isBestBuy => opportunityTag.startsWith('🎯');

  /// `true` when the ATM pair is present and priced — the quick-trade dialog and
  /// the "agar kal jodi buy ki hoti" row need this.
  bool get hasTradeablePair => atmStrike != null && (ce?.hasPrice ?? false) && (pe?.hasPrice ?? false);

  /// CE + PE premiums (spec §3.4 item 6).
  double? get straddleLtp {
    final c = ce?.ltp;
    final p = pe?.ltp;
    if (c == null || p == null) return null;
    return c + p;
  }

  /// The OTM jodi's price today — null when the pair is missing or only half
  /// of it is priced (one leg alone is not a jodi).
  double? get strangleLtp => strangle?.total;

  /// ATM jodi, stock ke bhav ka kitna percent — "₹16.10 ka jodi, ₹130 ke
  /// stock par" = 12.38%. Live premium ke saath bhi yahi divide lagta hai
  /// (widget live value la kar isi helper se nikalta hai).
  double? get atmJodiPctOfPrice => premiumPctOfPrice(straddleLtp, ltp);

  /// Wahi hisaab OTM jodi (strangle) ke liye.
  double? get otmJodiPctOfPrice => premiumPctOfPrice(strangleLtp, ltp);

  /// `true` when the "kal jodi" can be computed: the pair that was ATM at the
  /// previous session's close, priced both then and now.
  bool get hasKalJodi =>
      (kalCe?.hasClose ?? false) &&
      (kalPe?.hasClose ?? false) &&
      (kalCe?.hasPrice ?? false) &&
      (kalPe?.hasPrice ?? false);

  /// What the **kal wale ATM jodi** cost at that session's close — the buy
  /// price of the "agar kal jodi buy ki hoti" line, and the number the OTM
  /// jodi's own target is set from (aadha = [kalJodiBuyCost] / 2).
  double? get kalJodiBuyCost {
    final c = kalCe?.previousClose;
    final p = kalPe?.previousClose;
    if (c == null || p == null) return null;
    return c + p;
  }

  /// What that jodi cost at the previous session's close (kal ka buy value).
  double? get kalJodiBase =>
      hasKalJodi ? kalCe!.previousClose! + kalPe!.previousClose! : null;

  /// What those *same contracts* are worth right now.
  double? get kalJodiNow => hasKalJodi ? kalCe!.ltp! + kalPe!.ltp! : null;

  /// "Agar kal jodi buy ki hoti" — points and rupees (spec §3.4 item 7).
  ///
  /// Buy value = previous session's close of the **kal wale ATM strike** (see
  /// [kalStrike]); current value = today's premium of those same two contracts.
  /// The sign is *never* rendered raw: the UI always says Profit/Loss.
  ({double points, double rupees, bool complete})? get straddleYesterday {
    final c = kalCe;
    final p = kalPe;
    if (c == null || p == null) return null;
    if (!c.hasPrice || !p.hasPrice || !c.hasClose || !p.hasClose) return null;
    final points = (c.ltp! + p.ltp!) - (c.previousClose! + p.previousClose!);
    return (points: points, rupees: points * lotSize, complete: true);
  }

  /// 3M High / Low line + month line for the export and detail panel.
  String get monthsLine =>
      months.map((m) => '${m.label}: ${m.pct >= 0 ? '+' : ''}${m.pct.toStringAsFixed(1)}%').join(' · ');

  StudyRow copyWith({
    double? ltp,
    StudyStrangle? strangle,
    StudyStrangle? kalStrangle,
    IvRank? ivRank,
    String? opportunityTag,
    int? rank,
    double? score,
    double? ivPoints,
    double? avgIv,
    double? edgePct,
    double? implied1dPct,
    IvSource? ivSource,
    String? reason,
  }) =>
      StudyRow(
        symbol: symbol,
        companyName: companyName,
        exchange: exchange,
        token: token,
        underlying: underlying,
        ltp: ltp ?? this.ltp,
        high3m: high3m,
        low3m: low3m,
        rangePct: rangePct,
        atr: atr,
        atrPct: atrPct,
        distHiPct: distHiPct,
        distLoPct: distLoPct,
        distHiDays: distHiDays,
        distLoDays: distLoDays,
        months: months,
        total3mPct: total3mPct,
        upMonths: upMonths,
        downMonths: downMonths,
        trend: trend,
        atmStrike: atmStrike,
        expiryLabel: expiryLabel,
        expiryDate: expiryDate,
        daysToExpiry: daysToExpiry,
        lotSize: lotSize,
        ce: ce,
        pe: pe,
        // rankStudy rebuilds every row through copyWith (tag + rank) — dropping
        // the kal pair here silently brought the wrong-strike P&L back.
        kalStrike: kalStrike,
        kalCe: kalCe,
        kalPe: kalPe,
        // Same trap as the kal pair above: rankStudy rebuilds every row, so
        // these must be carried across or the OTM jodi vanishes after ranking.
        strangle: strangle ?? this.strangle,
        kalStrangle: kalStrangle ?? this.kalStrangle,
        avgIv: avgIv ?? this.avgIv,
        ivSource: ivSource ?? this.ivSource,
        implied1dPct: implied1dPct ?? this.implied1dPct,
        edgePct: edgePct ?? this.edgePct,
        consistencyPoints: consistencyPoints,
        magnitudePoints: magnitudePoints,
        proximityPoints: proximityPoints,
        ivPoints: ivPoints ?? this.ivPoints,
        score: score ?? this.score,
        ivRank: ivRank ?? this.ivRank,
        opportunityTag: opportunityTag ?? this.opportunityTag,
        rank: rank ?? this.rank,
        reason: reason ?? this.reason,
        turnoverCrore: turnoverCrore,
        avgDailyMove15: avgDailyMove15,
        avgRange: avgRange,
        avgRangePct: avgRangePct,
        bars: bars,
        asOf: asOf,
      );

  // -------------------------------------------------------------------------
  // Persistence (the snapshot is frozen — spec §6)
  // -------------------------------------------------------------------------

  Map<String, dynamic> toJson() => {
        'symbol': symbol,
        'name': companyName,
        'exchange': exchange.code,
        'token': token,
        'underlying': underlying,
        'ltp': ltp,
        'high3m': high3m,
        'low3m': low3m,
        'rangePct': rangePct,
        'atr': atr,
        'atrPct': atrPct,
        'distHiPct': distHiPct,
        'distLoPct': distLoPct,
        'distHiDays': distHiDays,
        'distLoDays': distLoDays,
        'months': [for (final m in months) m.toJson()],
        'total3mPct': total3mPct,
        'upMonths': upMonths,
        'downMonths': downMonths,
        'trend': trend.name,
        'atmStrike': atmStrike,
        'expiryLabel': expiryLabel,
        'expiryDate': expiryDate?.toIso8601String(),
        'daysToExpiry': daysToExpiry,
        'lotSize': lotSize,
        'ce': ce?.toJson(),
        'pe': pe?.toJson(),
        'kalStrike': kalStrike,
        'kalCe': kalCe?.toJson(),
        'kalPe': kalPe?.toJson(),
        'strangle': strangle?.toJson(),
        'kalStrangle': kalStrangle?.toJson(),
        'avgIv': avgIv,
        'ivSource': ivSource.name,
        'implied1dPct': implied1dPct,
        'edgePct': edgePct,
        'consistencyPoints': consistencyPoints,
        'magnitudePoints': magnitudePoints,
        'proximityPoints': proximityPoints,
        'ivPoints': ivPoints,
        'score': score,
        'ivRank': ivRank.name,
        'opportunityTag': opportunityTag,
        'rank': rank,
        'reason': reason,
        'bars': bars,
        'asOf': asOf.toIso8601String(),
        'turnoverCrore': turnoverCrore,
        'avgDailyMove15': avgDailyMove15,
        'avgRange': avgRange,
        'avgRangePct': avgRangePct,
      };

  static StudyRow fromJson(Map<String, dynamic> json) => StudyRow(
        symbol: '${json['symbol']}',
        companyName: '${json['name'] ?? ''}',
        exchange: Exchange.fromCode('${json['exchange'] ?? 'NSE'}'),
        token: '${json['token'] ?? ''}',
        underlying: '${json['underlying'] ?? ''}',
        ltp: (json['ltp'] as num? ?? 0).toDouble(),
        high3m: (json['high3m'] as num? ?? 0).toDouble(),
        low3m: (json['low3m'] as num? ?? 0).toDouble(),
        rangePct: (json['rangePct'] as num? ?? 0).toDouble(),
        atr: (json['atr'] as num? ?? 0).toDouble(),
        atrPct: (json['atrPct'] as num? ?? 0).toDouble(),
        distHiPct: (json['distHiPct'] as num? ?? 0).toDouble(),
        distLoPct: (json['distLoPct'] as num? ?? 0).toDouble(),
        distHiDays: (json['distHiDays'] as num? ?? 0).toDouble(),
        distLoDays: (json['distLoDays'] as num? ?? 0).toDouble(),
        months: [
          for (final m in (json['months'] as List? ?? const []))
            if (m is Map) MonthMove.fromJson(m.cast<String, dynamic>()),
        ],
        total3mPct: (json['total3mPct'] as num? ?? 0).toDouble(),
        upMonths: (json['upMonths'] as num? ?? 0).toInt(),
        downMonths: (json['downMonths'] as num? ?? 0).toInt(),
        trend: Trend3M.values.firstWhere(
          (t) => t.name == '${json['trend']}',
          orElse: () => Trend3M.sideways,
        ),
        atmStrike: (json['atmStrike'] as num?)?.toDouble(),
        expiryLabel: json['expiryLabel'] == null ? null : '${json['expiryLabel']}',
        expiryDate: DateTime.tryParse('${json['expiryDate']}'),
        daysToExpiry: (json['daysToExpiry'] as num?)?.toInt(),
        lotSize: (json['lotSize'] as num? ?? 0).toInt(),
        ce: json['ce'] is Map
            ? StudyOptionLeg.fromJson((json['ce'] as Map).cast<String, dynamic>())
            : null,
        pe: json['pe'] is Map
            ? StudyOptionLeg.fromJson((json['pe'] as Map).cast<String, dynamic>())
            : null,
        kalStrike: (json['kalStrike'] as num?)?.toDouble(),
        kalCe: json['kalCe'] is Map
            ? StudyOptionLeg.fromJson(
                (json['kalCe'] as Map).cast<String, dynamic>())
            : null,
        kalPe: json['kalPe'] is Map
            ? StudyOptionLeg.fromJson(
                (json['kalPe'] as Map).cast<String, dynamic>())
            : null,
        strangle: json['strangle'] is Map
            ? StudyStrangle.fromJson(
                (json['strangle'] as Map).cast<String, dynamic>())
            : null,
        kalStrangle: json['kalStrangle'] is Map
            ? StudyStrangle.fromJson(
                (json['kalStrangle'] as Map).cast<String, dynamic>())
            : null,
        avgIv: (json['avgIv'] as num?)?.toDouble(),
        ivSource: IvSource.values.firstWhere(
          (s) => s.name == '${json['ivSource']}',
          orElse: () => IvSource.none,
        ),
        implied1dPct: (json['implied1dPct'] as num?)?.toDouble(),
        edgePct: (json['edgePct'] as num?)?.toDouble(),
        consistencyPoints: (json['consistencyPoints'] as num? ?? 0).toDouble(),
        magnitudePoints: (json['magnitudePoints'] as num? ?? 0).toDouble(),
        proximityPoints: (json['proximityPoints'] as num? ?? 0).toDouble(),
        ivPoints: (json['ivPoints'] as num? ?? 0).toDouble(),
        score: (json['score'] as num? ?? 0).toDouble(),
        ivRank: IvRank.values.firstWhere(
          (r) => r.name == '${json['ivRank']}',
          orElse: () => IvRank.unknown,
        ),
        opportunityTag: '${json['opportunityTag'] ?? '-'}',
        rank: (json['rank'] as num? ?? 0).toInt(),
        reason: '${json['reason'] ?? ''}',
        bars: (json['bars'] as num? ?? 0).toInt(),
        turnoverCrore: (json['turnoverCrore'] as num? ?? 0).toDouble(),
        avgRange: (json['avgRange'] as num? ?? 0).toDouble(),
        avgRangePct: (json['avgRangePct'] as num? ?? 0).toDouble(),
        avgDailyMove15: (json['avgDailyMove15'] as num? ?? 0).toDouble(),
        asOf: DateTime.tryParse('${json['asOf']}') ?? DateTime(2015),
      );
}

/// ATM pair as it arrived from the broker layer.
class StudyOptionInput {
  final double strike;
  final String? expiryLabel;
  final DateTime? expiryDate;
  final int lotSize;
  final StudyOptionLeg? ce;
  final StudyOptionLeg? pe;

  const StudyOptionInput({
    required this.strike,
    this.expiryLabel,
    this.expiryDate,
    this.lotSize = 0,
    this.ce,
    this.pe,
  });
}

/// The **OTM jodi (strangle)** for one stock: a CE above the money and a PE
/// below it, chosen so their combined premium is closest to half of what the ATM
/// jodi costs (see `strangle.dart` for the rule, and for why the choice itself
/// runs on an estimate while the displayed premium is the broker's).
///
/// `ce`/`pe` carry `ltp` (aaj ka premium) and `previousClose` (kal ka premium) —
/// the same two numbers the ATM legs carry, so "agar kal ye jodi buy ki hoti"
/// works exactly like the ATM line.
class StudyStrangle {
  const StudyStrangle({this.ce, this.pe, required this.targetPremium});

  final StudyOptionLeg? ce;
  final StudyOptionLeg? pe;

  /// What the pair was picked *for* — half the ATM jodi's premium. Printed as
  /// the rule the strikes came from, never as a promise about the price.
  final double targetPremium;

  bool get isComplete => (ce?.hasPrice ?? false) && (pe?.hasPrice ?? false);

  /// Aaj ka premium (CE + PE) — what the pair costs right now.
  double? get total {
    final c = ce?.ltp;
    final p = pe?.ltp;
    if (c == null || p == null) return null;
    return c + p;
  }

  /// Kal ka premium (previous close of both legs) — the buy cost for the
  /// "agar kal ..." line. Null when a leg's yesterday-close is missing.
  double? get buyCost {
    final c = ce?.previousClose;
    final p = pe?.previousClose;
    if (c == null || p == null) return null;
    return c + p;
  }

  /// `true` when the kal line can be computed: both legs priced today *and*
  /// yesterday.
  bool get hasYesterday => isComplete && buyCost != null;

  /// "Agar kal ye OTM jodi buy ki hoti" — points and rupees for one lot.
  /// The sign is never rendered raw: the UI always says Profit/Loss.
  ({double points, double rupees})? yesterday(int lotSize) {
    if (!hasYesterday) return null;
    final points = total! - buyCost!;
    return (points: points, rupees: points * lotSize);
  }

  Map<String, dynamic> toJson() => {
        'ce': ce?.toJson(),
        'pe': pe?.toJson(),
        'target': targetPremium,
      };

  static StudyStrangle fromJson(Map<String, dynamic> json) => StudyStrangle(
        ce: json['ce'] is Map
            ? StudyOptionLeg.fromJson((json['ce'] as Map).cast<String, dynamic>())
            : null,
        pe: json['pe'] is Map
            ? StudyOptionLeg.fromJson((json['pe'] as Map).cast<String, dynamic>())
            : null,
        targetPremium: (json['target'] as num? ?? 0).toDouble(),
      );
}

// ---------------------------------------------------------------------------
// Step 2.1–2.5 + 2.7–2.8: one stock
// ---------------------------------------------------------------------------

/// Computes one stock's study row.
///
/// Returns `null` when the history is shorter than [kStudyMinimumBars] (spec §1:
/// "agar candle data 60 din se kam hai to skip kar do").
StudyRow? computeStudy({
  required Scrip scrip,
  required List<Candle> candles,
  DateTime? asOf,
  StudyOptionInput? options,
  /// Which scoring rules to apply (defaults to the classic study's own).
  StudyRules rules = StudyRules.classic,
  /// The pair that was ATM at the previous session's close — powers the
  /// "agar kal jodi buy ki hoti" line.
  StudyOptionInput? yesterdayOptions,
  String? companyName,
  String? underlying,
}) {
  final bars = _upto(candles, asOf);
  if (bars.length < kStudyMinimumBars) return null;

  final day = bars.last.istDate;
  final window = bars.length > kStudyWindowBars
      ? bars.sublist(bars.length - kStudyWindowBars)
      : bars;

  // ---- 2.1 levels --------------------------------------------------------
  final ltp = window.last.close;
  var high3m = window.first.high;
  var low3m = window.first.low;
  for (final bar in window) {
    if (bar.high > high3m) high3m = bar.high;
    if (bar.low < low3m) low3m = bar.low;
  }
  final rangePct = low3m > 0 ? (high3m - low3m) / low3m * 100 : 0.0;

  // ---- 2.2 Wilder ATR over the FULL series -------------------------------
  final atr = wilderAtr(bars, period: kAtrPeriod);
  final atrPct = ltp > 0 ? atr / ltp * 100 : 0.0;

  // Simple (High − Low) average of the last 14 sessions — "din ka average
  // range", gap ko chhod ke. Display-only; koi gate/score isse nahi badalta.
  final avgRange = avgHighLow(bars, period: kAtrPeriod);
  final avgRangePct = ltp > 0 ? avgRange / ltp * 100 : 0.0;

  // ---- 2.3 distances -----------------------------------------------------
  // F2: the classic rule divides the distance-to-high by the high and the
  // distance-to-low by CMP, so an up-trend 3 % below its high and a down-trend
  // 3 % above its low did NOT score the same. The advanced rules measure both
  // from CMP — one yardstick, comparable in both directions.
  final distHiPct = high3m > 0
      ? (rules.symmetricDistance && ltp > 0
          ? (high3m - ltp) / ltp * 100
          : (high3m - ltp) / high3m * 100)
      : 0.0;
  final distLoPct = ltp > 0 ? (ltp - low3m) / ltp * 100 : 0.0;
  final distHiDays = atr > 0 ? (high3m - ltp) / atr : 0.0;
  final distLoDays = atr > 0 ? (ltp - low3m) / atr : 0.0;

  // ---- 2.4 month-wise movement ------------------------------------------
  final months = monthMoves(window, minSessions: rules.minSessionsPerMonth);
  final total3mPct = window.first.close > 0
      ? (ltp / window.first.close - 1) * 100
      : 0.0;
  final upMonths = months.where((m) => m.pct > 0).length;
  final downMonths = months.where((m) => m.pct < 0).length;

  // ---- liquidity: 20-session average cash turnover, in ₹ crore -----------
  // (close x volume, averaged; the same yardstick the AI Suggestion scan uses
  // for its liquidity gate. A study row without it cannot be filtered on it.)
  var turnover = 0.0;
  if (bars.isNotEmpty) {
    final tail = bars.length > 20 ? bars.sublist(bars.length - 20) : bars;
    var sum = 0.0;
    for (final bar in tail) {
      sum += bar.close * bar.volume;
    }
    turnover = sum / tail.length / 1e7; // ₹ → ₹ crore
  }

  // ---- AI Jodi Study: 15-session average daily |close-to-close| move ------
  // The user's first gate: "15 din me roz ka average move ATR se zyada ho".
  var avgDailyMove15 = 0.0;
  {
    final tail = bars.length > 16 ? bars.sublist(bars.length - 16) : bars;
    if (tail.length >= 2) {
      var sum = 0.0;
      for (var i = 1; i < tail.length; i++) {
        sum += (tail[i].close - tail[i - 1].close).abs();
      }
      avgDailyMove15 = sum / (tail.length - 1);
    }
  }

  // ---- 2.5 trend + suggested action -------------------------------------
  final trend = classifyTrend(
    total3mPct: total3mPct,
    upMonths: upMonths,
    downMonths: downMonths,
  );

  // ---- 2.6 options ------------------------------------------------------
  final ce = options?.ce;
  final pe = options?.pe;
  final ivs = <double>[
    if (ce?.iv != null) ce!.iv!,
    if (pe?.iv != null) pe!.iv!,
  ];
  final avgIv = ivs.isEmpty ? null : ivs.reduce((a, b) => a + b) / ivs.length;
  final ivSource = _mergeIvSource(ce, pe);
  final daysToExpiry = options?.expiryDate == null
      ? null
      : options!.expiryDate!.difference(DateTime(day.year, day.month, day.day)).inDays;

  // ---- 2.7 edge ---------------------------------------------------------
  final implied1dPct =
      avgIv == null ? null : avgIv / math.sqrt(kTradingDaysPerYear);
  final edgePct = implied1dPct == null ? null : atrPct - implied1dPct;

  // ---- 2.8 score --------------------------------------------------------
  final consistency = consistencyPoints(
    trend,
    upMonths,
    downMonths,
    monthCount: months.length,
    requireFullMonths: rules.requireFullMonths,
  );
  final magnitude = magnitudePoints(total3mPct);
  final proximity = proximityPoints(
    trend: trend,
    distHiPct: distHiPct,
    distLoPct: distLoPct,
  );
  final ivp = ivPointsFor(edgePct: edgePct, avgIv: avgIv, hasIv: avgIv != null);
  final score = (consistency + magnitude + proximity + ivp).clamp(0.0, 12.0);

  return StudyRow(
    symbol: Scrip.plainSymbol(scrip.symbol),
    companyName: (companyName ?? scrip.name).trim(),
    exchange: scrip.exchange,
    token: scrip.token,
    underlying: (underlying ?? Scrip.plainSymbol(scrip.symbol)).toUpperCase(),
    ltp: ltp,
    high3m: high3m,
    low3m: low3m,
    rangePct: rangePct,
    atr: atr,
    atrPct: atrPct,
    distHiPct: distHiPct,
    distLoPct: distLoPct,
    distHiDays: distHiDays,
    distLoDays: distLoDays,
    months: months,
    total3mPct: total3mPct,
    upMonths: upMonths,
    downMonths: downMonths,
    trend: trend,
    atmStrike: options?.strike,
    expiryLabel: options?.expiryLabel,
    expiryDate: options?.expiryDate,
    daysToExpiry: daysToExpiry,
    lotSize: options?.lotSize ?? 0,
    ce: ce,
    pe: pe,
    kalStrike: yesterdayOptions?.strike,
    kalCe: yesterdayOptions?.ce,
    kalPe: yesterdayOptions?.pe,
    avgIv: avgIv,
    ivSource: ivSource,
    implied1dPct: implied1dPct,
    edgePct: edgePct,
    turnoverCrore: turnover,
    avgDailyMove15: avgDailyMove15,
    avgRange: avgRange,
    avgRangePct: avgRangePct,
    consistencyPoints: consistency,
    magnitudePoints: magnitude,
    proximityPoints: proximity,
    ivPoints: ivp,
    score: score,
    ivRank: IvRank.unknown,
    opportunityTag: '-',
    rank: 0,
    reason: '', // filled by [rankStudy], which knows the tag
    bars: bars.length,
    asOf: day,
  );
}

// ---------------------------------------------------------------------------
// 2.9 – 2.12: the universe pass
// ---------------------------------------------------------------------------

/// IV rank + opportunity tag + sort + rank + reason.
///
/// Mutates copies (rows are immutable), so the caller gets a fresh list in the
/// final display order with ranks 1..n.
List<StudyRow> rankStudy(
  List<StudyRow> rows, {
  StudyRules rules = StudyRules.classic,
}) {
  if (rows.isEmpty) return const [];

  final ranked = assignIvRank(rows)
      .map((row) => applyOpportunity(row, rules: rules))
      .toList();

  ranked.sort((a, b) {
    final aBest = a.isBestBuy ? 0 : 1;
    final bBest = b.isBestBuy ? 0 : 1;
    if (aBest != bBest) return aBest - bBest;
    final score = b.score.compareTo(a.score);
    if (score != 0) return score;
    return a.symbol.compareTo(b.symbol); // stable, never shuffles
  });

  return [
    for (var i = 0; i < ranked.length; i++) ranked[i].copyWith(rank: i + 1),
  ];
}

/// 2.9 — percentile thirds of avgIv across the scanned universe.
List<StudyRow> assignIvRank(List<StudyRow> rows) {
  final withIv = [
    for (final r in rows)
      if (r.avgIv != null) r,
  ]..sort((a, b) => a.avgIv!.compareTo(b.avgIv!));

  final n = withIv.length;
  if (n == 0) return rows;

  final rankBySymbol = <String, IvRank>{};
  for (var i = 0; i < n; i++) {
    final percentile = n == 1 ? 0.5 : i / (n - 1); // 0 at the cheapest IV
    rankBySymbol[withIv[i].symbol] = percentile <= 0.3333
        ? IvRank.low
        : (percentile <= 0.6666 ? IvRank.medium : IvRank.high);
  }

  return [
    for (final r in rows)
      r.copyWith(ivRank: rankBySymbol[r.symbol] ?? IvRank.unknown),
  ];
}

/// 2.10 — the tag the table sorts on.
StudyRow applyOpportunity(
  StudyRow row, {
  StudyRules rules = StudyRules.classic,
}) {
  if (row.trend == Trend3M.sideways) {
    return row.copyWith(opportunityTag: '-', reason: buildReason(row));
  }

  final edge = row.edgePct;
  final String tag;
  switch (row.ivRank) {
    case IvRank.low when edge == null || edge >= 0:
      tag = '🎯 Best Buy — ${row.suggested} (IV sasta)';
    // F1: cheap IV is not an edge on its own. When the premium has priced in
    // more than the stock actually moves (edge < 0), buying is the wrong
    // suggestion however low the IV rank is.
    case IvRank.low when rules.bestBuyNeedsEdge && edge != null && edge < 0:
      tag = '⏸ Watch — ${row.suggested} (IV sasta, par premium mehenga)';
    case IvRank.low:
      tag = '🎯 Best Buy — ${row.suggested}';
    case IvRank.unknown:
      tag = '⏸ Watch — ${row.suggested} (${IvRank.unknown.label})';
    case IvRank.medium:
    case IvRank.high:
      tag = '⏸ Watch — ${row.suggested} (IV ${row.ivRank.short.toLowerCase()}, '
          'thoda mehenga)';
  }

  // A5: the tag above may be a 🎯, but with the clock almost out the premium
  // decays faster than the stock can travel. Demote it only for the rule set
  // that asks for it, so the classic page's table never moves.
  final dte = row.daysToExpiry;
  final String finalTag;
  if (rules.demoteNearExpiry > 0 &&
      dte != null &&
      dte <= rules.demoteNearExpiry &&
      tag.startsWith('🎯')) {
    finalTag = '⏸ Watch — ${row.suggested} (expiry $dte din baad: '
        '${dte == 0 ? 'aaj' : 'bahut kam waqt'})';
  } else {
    finalTag = tag;
  }

  final withTag = row.copyWith(opportunityTag: finalTag);
  return withTag.copyWith(reason: buildReason(withTag));
}

/// 2.12 — the one-line summary shown at the bottom of the detail panel.
String buildReason(StudyRow row) {
  final buffer = StringBuffer()
    ..write('${row.trend.label} trend, ')
    ..write('${row.total3mPct >= 0 ? '+' : ''}${row.total3mPct.toStringAsFixed(1)}% 3M move ')
    ..write('(range ${row.rangePct.toStringAsFixed(1)}%).');

  if (row.avgIv != null) {
    buffer.write(' ATM IV ${row.avgIv!.toStringAsFixed(1)}%');
    if (row.edgePct != null) {
      buffer.write(', edge ${row.edgePct!.toStringAsFixed(2)}%');
    }
    buffer.write('.');
  } else {
    buffer.write(' ATM IV nahi mili (options data degraded).');
  }

  if (row.trend == Trend3M.sideways) {
    buffer.write(' Suggested: AVOID — sideways, avoid karo.');
  } else {
    buffer.write(' Suggested: ${row.suggested}');
  }
  return buffer.toString();
}

// ---------------------------------------------------------------------------
// Individual maths (exported so the tests can pin each one down)
// ---------------------------------------------------------------------------

/// Wilder's ATR over [candles] (oldest → newest).
///
/// First value = simple mean of the first [period] true ranges, then
/// `atr = (atr × (period−1) + TR) / period`. Returns 0 when there is not enough
/// history.
double wilderAtr(List<Candle> candles, {int period = kAtrPeriod}) {
  if (candles.length < period + 1) return 0;

  final trs = <double>[];
  for (var i = 1; i < candles.length; i++) {
    final bar = candles[i];
    final prevClose = candles[i - 1].close;
    final tr = math.max(
      bar.high - bar.low,
      math.max((bar.high - prevClose).abs(), (bar.low - prevClose).abs()),
    );
    trs.add(tr);
  }

  var atr = 0.0;
  for (var i = 0; i < period; i++) {
    atr += trs[i];
  }
  atr /= period;

  for (var i = period; i < trs.length; i++) {
    atr = (atr * (period - 1) + trs[i]) / period;
  }
  return atr;
}

/// Simple average of (High − Low) over the last [period] sessions — "stock
/// ek din me average kitna range cover karta hai", gap up/down **bina** count
/// kiye. ATR se alag: ATR me kal ke close ke gap bhi TR me aate hain aur
/// Wilder smoothing hoti hai; ye seedha din ke range ka average hai. Returns
/// 0 when there is not enough history (honest missing, never a fake number).
double avgHighLow(List<Candle> candles, {int period = kAtrPeriod}) {
  if (candles.length < period) return 0;
  final tail = candles.sublist(candles.length - period);
  var sum = 0.0;
  for (final bar in tail) {
    sum += bar.high - bar.low;
  }
  return sum / period;
}

/// 2.4 — month-wise movement for the last (up to) three calendar months in the
/// window. `pct = lastCloseOfMonth / firstCloseOfMonth − 1`.
List<MonthMove> monthMoves(
  List<Candle> window, {
  int maxMonths = 3,

  /// F3: a calendar month needs this many sessions to count as a month. A stub
  /// of two or three sessions (the current month, usually) is folded into the
  /// month before it — otherwise a two-day drift swings the consistency points
  /// that decide three whole points of the score.
  int minSessions = 0,
}) {
  if (window.isEmpty) return const [];

  final order = <String>[];
  final first = <String, double>{};
  final last = <String, double>{};
  final sessions = <String, int>{};
  final high = <String, double>{};
  final low = <String, double>{};

  for (final bar in window) {
    final date = bar.istDate;
    final key = '${date.year.toString().padLeft(4, '0')}-'
        '${date.month.toString().padLeft(2, '0')}';
    if (!first.containsKey(key)) {
      first[key] = bar.close;
      order.add(key);
      sessions[key] = 0;
    }
    last[key] = bar.close;
    sessions[key] = (sessions[key] ?? 0) + 1;
    high[key] = (high[key] == null || bar.high > high[key]!) ? bar.high : high[key]!;
    low[key] = (low[key] == null || bar.low < low[key]!) ? bar.low : low[key]!;
  }

  if (minSessions > 0) {
    var i = 0;
    while (i < order.length) {
      final key = order[i];
      if (i == 0 || (sessions[key] ?? 0) >= minSessions) {
        i++;
        continue;
      }
      // Fold this stub into the month before it: the earlier month keeps its
      // opening close and takes over the stub's closing close.
      final previous = order[i - 1];
      last[previous] = last[key] ?? last[previous]!;
      sessions[previous] = (sessions[previous] ?? 0) + (sessions[key] ?? 0);
      // The folded sessions' range belongs to the merged month too.
      if (high[key] != null) {
        high[previous] = math.max(high[previous] ?? high[key]!, high[key]!);
      }
      if (low[key] != null) {
        low[previous] = math.min(low[previous] ?? low[key]!, low[key]!);
      }
      order.removeAt(i); // stay on this index: the next one may be short too
    }
  }

  final selected = order.length > maxMonths
      ? order.sublist(order.length - maxMonths)
      : order;

  return [
    for (final key in selected)
      MonthMove(
        key: key,
        label: _monthLabel(key),
        pct: (first[key] ?? 0) > 0
            ? ((last[key]! / first[key]!) - 1) * 100
            : 0.0,
        rangePct: (first[key] ?? 0) > 0 && high[key] != null && low[key] != null
            ? ((high[key]! - low[key]!) / first[key]!) * 100
            : 0.0,
      ),
  ];
}

/// `2025-08` → `Aug-25` (what the table and the export show).
String _monthLabel(String key) {
  const names = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
  ];
  final parts = key.split('-');
  if (parts.length != 2) return key;
  final year = int.tryParse(parts[0]);
  final month = int.tryParse(parts[1]);
  if (year == null || month == null || month < 1 || month > 12) return key;
  return '${names[month - 1]}-${year.toString().substring(2)}';
}

/// 2.5 — trend classification. Order matters: the first matching rule wins.
Trend3M classifyTrend({
  required double total3mPct,
  required int upMonths,
  required int downMonths,
}) {
  if (total3mPct >= kStrongTrendPct && upMonths >= 2) return Trend3M.strongUp;
  if (total3mPct >= kTrendPct && upMonths >= 2) return Trend3M.up;
  if (total3mPct <= -kStrongTrendPct && downMonths >= 2) return Trend3M.strongDown;
  if (total3mPct <= -kTrendPct && downMonths >= 2) return Trend3M.down;
  return Trend3M.sideways;
}

/// 2.8 factor 1 — how consistently the months agreed with the overall move.
///
/// All three months with the trend → 3.0; one against → 2.0; more → 1.0.
/// A sideways stock cannot be "consistent" in a direction, so it earns 1.0.
double consistencyPoints(
  Trend3M trend,
  int upMonths,
  int downMonths, {
  /// How many months the window actually held (after short-month merging).
  int monthCount = 3,

  /// F4: two agreeing months out of two is not the same claim as three out of
  /// three — with fewer months, the points are capped at the months seen.
  bool requireFullMonths = false,
}) {
  if (trend == Trend3M.sideways) return 1.0;
  final agree = trend.isUp ? upMonths : downMonths;
  final total = upMonths + downMonths;
  final mismatches = (total - agree).clamp(0, 3);
  var points = mismatches == 0 ? 3.0 : (mismatches == 1 ? 2.0 : 1.0);
  if (requireFullMonths && monthCount < 3) {
    points = math.min(points, monthCount.toDouble());
  }
  return points;
}

/// 2.8 factor 2 — magnitude: `min(|total3mPct| / 8, 3)`.
double magnitudePoints(double total3mPct) =>
    (total3mPct.abs() / 8.0).clamp(0.0, 3.0);

/// 2.8 factor 3 — how close LTP sits to the extreme the trend points at.
double proximityPoints({
  required Trend3M trend,
  required double distHiPct,
  required double distLoPct,
}) {
  if (trend == Trend3M.sideways) return 0.5;
  final distance = trend.isUp ? distHiPct : distLoPct;
  if (distance <= 2) return 3.0;
  if (distance <= 5) return 2.0;
  if (distance <= 10) return 1.0;
  return 0.5;
}

/// 2.8 factor 4 — IV points from the edge, with the "expensive IV" penalty.
double ivPointsFor({
  required double? edgePct,
  required double? avgIv,
  required bool hasIv,
}) {
  if (!hasIv) return 1.5; // neutral: no IV data must not look like a signal

  final edge = edgePct ?? 0;
  var points = edge >= 1.0
      ? 3.0
      : edge >= 0.5
          ? 2.5
          : edge >= 0
              ? 2.0
              : edge >= -0.5
                  ? 1.0
                  : 0.5;

  if ((avgIv ?? 0) > kExpensiveIvPct) points -= 1.0;
  return points.clamp(0.0, 3.0);
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

List<Candle> _upto(List<Candle> candles, DateTime? asOf) {
  if (asOf == null) return candles;
  final day = DateTime(asOf.year, asOf.month, asOf.day);
  return [
    for (final c in candles)
      if (!c.istDate.isAfter(day)) c,
  ];
}

/// Picks the best available IV source label for the pair.
IvSource _mergeIvSource(StudyOptionLeg? ce, StudyOptionLeg? pe) {
  final sources = <IvSource>[
    if (ce?.iv != null) ce!.ivSource,
    if (pe?.iv != null) pe!.ivSource,
  ];
  if (sources.isEmpty) return IvSource.none;
  // Black-Scholes outranks nothing: if either leg needed the fallback, say so.
  if (sources.contains(IvSource.blackScholes)) return IvSource.blackScholes;
  return IvSource.broker;
}
