// ---------------------------------------------------------------------------
// ai_jodi_screen.dart — the "AI Calculation & Chart Study" page (AI Jodi
// Study). Opened from the 3-Month Study's kebab menu.
//
// One simple table, exactly the columns the user asked for:
//   Stock | Current price | ATR | ATM jodi | OTM jodi | Konsi buy karni chahiye
//
// The rules live in [AiJodiEngine] (pure, tested). The numbers come from the
// 3-Month Study scan (same ATR, same monthly moves, same jodi premiums — one
// scan, two views). No directional opinion anywhere: both jodis are long
// pairs (CE+PE bought), risk is the premium, monthly expiry.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/utils/formatters.dart';
import 'ai_jodi_chart.dart';
import 'ai_jodi_engine.dart';
import 'ai_jodi_export.dart';
import '../news/news_signals.dart';
import 'fno_study_provider.dart';
import 'iv_sheet.dart';
import 'iv_sheet_link.dart';
import 'study_delivery.dart';
import 'study_engine.dart';
import 'study_export.dart';

/// Fixed table columns — the table is wider than a phone on purpose and
/// scrolls horizontally as one piece, so every column keeps its shape and
/// the numbers stay readable (no squeezed flex fractions).
const double _wStock = 172;
const double _wPrice = 100;
const double _wAtr = 88;
const double _wAvgRange = 88;
const double _wAtm = 104;
const double _wOtm = 104;
const double _wIv = 104;
const double _wKal = 120;
const double _wVerdict = 210;
const double _kTableWidth = _wStock +
    _wPrice +
    _wAtr +
    _wAvgRange +
    _wAtm +
    _wOtm +
    _wIv +
    _wKal +
    _wVerdict;

/// Builds the engine input from a scanned study row. [ivp]/[ivr] come from
/// the Opstra Google Sheet (1.5.56) — null when the sheet has no row.
@visibleForTesting
AiJodiInput inputFromRow(
  StudyRow row, {
  bool isManual = false,
  double? ivp,
  double? ivr,
}) =>
    AiJodiInput(
      symbol: row.symbol,
      companyName: row.companyName,
      ltp: row.ltp,
      atr: row.atr,
      avgRange: row.avgRange,
      avgDailyMove15: row.avgDailyMove15,
      monthlyRangePcts: [for (final m in row.months) m.rangePct],
      atmJodiPrice: (row.ce?.ltp != null && row.pe?.ltp != null)
          ? row.ce!.ltp! + row.pe!.ltp!
          : null,
      otmJodiPrice: row.strangle?.total,
      isManual: isManual,
      ivp: ivp,
      ivr: ivr,
    );

/// Rescan ke saath IVP/IVR sheet bhi refresh (1.5.56/1.5.57). Top-level so
/// every widget (toolbar, empty/error states) can call it.
void _rescanWithSheet(BuildContext context) {
  refreshIvSheetIfPossible(context);
  context.read<FnoStudyProvider>().scan();
}

class AiJodiScreen extends StatefulWidget {
  const AiJodiScreen({super.key});

  @override
  State<AiJodiScreen> createState() => _AiJodiScreenState();
}

class _AiJodiScreenState extends State<AiJodiScreen> {
  /// Symbols the user pinned by hand — never gated out.
  final Set<String> _manual = <String>{};

  /// Auto-study once per page-open when nothing is scanned yet.
  bool _autoScanRequested = false;

  /// Table controls (1.5.55) — sort + verdict filter.
  JodiSortKey _sortKey = JodiSortKey.rank;
  JodiVerdictFilter _filter = JodiVerdictFilter.all;

  @override
  void initState() {
    super.initState();
    // IVP/IVR sheet (1.5.56) — refresh on open and repaint when fetched.
    IvSheetStore.instance.addListener(_onIvSheet);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      refreshIvSheetIfPossible(context);
    });
    // "Link ki click pe F&O ke sabhi stocks ko automatic khud study karke" —
    // the page starts the study itself; the user never has to press a button.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || _autoScanRequested) return;
      final provider = context.read<FnoStudyProvider>();
      if (provider.allRows.isEmpty && !provider.isRunning) {
        _autoScanRequested = true;
        provider.scan();
      }
    });
  }

  void _onIvSheet() {
    if (mounted) setState(() {});
  }

  /// Google Sheet link (Opstra IVP/IVR) set/replace — shared dialog (1.5.57,
  /// same one as Settings; both feed the universal IvSheetStore cache).
  Future<void> _showIvSheetDialog(BuildContext context) =>
      showIvSheetLinkDialog(context);

  @override
  void dispose() {
    IvSheetStore.instance.removeListener(_onIvSheet);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<FnoStudyProvider>();
    // All F&O stocks — never the study page's search-filtered view.
    final rows = provider.allRows;

    final inputs = [
      for (final row in rows)
        () {
          final iv = IvSheetStore.instance.forSymbol(row.symbol);
          return inputFromRow(
            row,
            isManual: _manual.contains(row.symbol),
            ivp: iv?.ivp,
            ivr: iv?.ivr,
          );
        }(),
    ];
    final ranked = AiJodiEngine.topList(inputs);
    final rowBySymbol = {for (final row in rows) row.symbol: row};
    // Engine rank (best first) — kept even when the display order changes.
    final rankOf = <String, int>{
      for (var i = 0; i < ranked.length; i++) ranked[i].input.symbol: i + 1,
    };
    double? kalChangeOf(String symbol) {
      final row = rowBySymbol[symbol];
      if (row == null) return null;
      final kal = kalPnlFor(row);
      final values = [
        if (kal.atm != null) kal.atm!,
        if (kal.otm != null) kal.otm!,
      ];
      return values.isEmpty ? null : values.reduce((a, b) => a > b ? a : b);
    }

    final displayed = JodiTableOps.sort(
      JodiTableOps.filter(ranked, _filter),
      _sortKey,
      kalChangeOf: kalChangeOf,
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Jodi Study'),
        actions: [
          IconButton(
            tooltip: 'IV sheet (Opstra)',
            icon: const Icon(Icons.table_chart_rounded),
            onPressed: () => _showIvSheetDialog(context),
          ),
          PopupMenuButton<String>(
            tooltip: 'Export',
            icon: const Icon(Icons.ios_share_rounded),
            onSelected: (kind) => _export(context, kind, ranked, rowBySymbol),
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'text', child: Text('WhatsApp / text recap')),
              PopupMenuItem(value: 'xlsx', child: Text('Excel (XLSX)')),
              PopupMenuItem(value: 'csv', child: Text('CSV')),
            ],
          ),
          IconButton(
            tooltip: 'Rules',
            icon: const Icon(Icons.help_outline_rounded),
            onPressed: () => _showRules(context),
          ),
        ],
      ),
      body: Column(
        children: [
          _HeaderStrip(),
          if (provider.isRunning) _ScanProgress(provider: provider),
          if (provider.error != null)
            _ErrorStrip(message: provider.error!, provider: provider),
          if (rows.isEmpty)
            Expanded(child: _EmptyState(provider: provider))
          else ...[
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      '${displayed.length}/${ranked.length} dikha rahe hain — sab ${rows.length} F&O stocks me se',
                      style: Theme.of(context).textTheme.labelSmall,
                    ),
                  ),
                  // Re-run the full F&O scan on demand (1.5.51).
                  OutlinedButton.icon(
                    onPressed: provider.isRunning
                        ? null
                        : () => _rescanWithSheet(context),
                    icon: const Icon(Icons.refresh_rounded, size: 18),
                    label: const Text('Rescan'),
                  ),
                ],
              ),
            ),
            // Sort + verdict filter (1.5.55).
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
              child: Row(
                children: [
                  DropdownButton<JodiSortKey>(
                    value: _sortKey,
                    isDense: true,
                    underline: const SizedBox.shrink(),
                    items: [
                      for (final key in JodiSortKey.values)
                        DropdownMenuItem(value: key, child: Text(key.label)),
                    ],
                    onChanged: (value) => setState(
                        () => _sortKey = value ?? JodiSortKey.rank),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          for (final filter in JodiVerdictFilter.values)
                            Padding(
                              padding: const EdgeInsets.only(right: 6),
                              child: FilterChip(
                                label: Text(filter.label),
                                selected: _filter == filter,
                                onSelected: (_) =>
                                    setState(() => _filter = filter),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: displayed.isEmpty
                  ? const _NoMatches()
                  // The whole table — header AND rows — scrolls horizontally
                  // as one piece, so the columns never misalign. Vertical
                  // scroll moves only the rows under the (sticky) header.
                  : LayoutBuilder(
                      builder: (context, constraints) => SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: SizedBox(
                          width: _kTableWidth,
                          height: constraints.maxHeight,
                          child: Column(
                            children: [
                              const _TableHeader(),
                              const Divider(height: 1),
                              Expanded(
                                child: ListView.separated(
                                  itemCount: displayed.length,
                                  separatorBuilder: (_, __) =>
                                      const Divider(height: 1),
                                  itemBuilder: (context, index) {
                                    final row = displayed[index];
                                    final studyRow =
                                        rowBySymbol[row.input.symbol];
                                    return _JodiRow(
                                      input: row.input,
                                      result: row.result,
                                      rank: rankOf[row.input.symbol] ??
                                          index + 1,
                                      studyRow: studyRow,
                                      zebra: index.isOdd,
                                    );
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
            ),
          ],
          const _FooterNote(),
        ],
      ),
      floatingActionButton: rows.isEmpty
          ? null
          : FloatingActionButton.extended(
              onPressed: () => _addStock(context, ranked, rowBySymbol),
              icon: const Icon(Icons.playlist_add_rounded),
              label: const Text('Stock add karein'),
            ),
    );
  }

  Future<void> _addStock(
    BuildContext context,
    List<({AiJodiInput input, AiJodiResult result})> listed,
    Map<String, StudyRow> rowBySymbol,
  ) async {
    // The dialog offers stocks NOT already visible in the table — earlier it
    // excluded every scanned row, so the list (and the textbox search) was
    // always empty.
    final visible = {for (final entry in listed) entry.input.symbol};
    final candidates = [
      for (final entry in rowBySymbol.values)
        if (!visible.contains(entry.symbol)) entry,
    ];
    final picked = await showDialog<String>(
      context: context,
      builder: (context) => _AddStockDialog(candidates: candidates),
    );
    if (picked != null) {
      setState(() => _manual.add(picked));
    }
  }

  Future<void> _export(
    BuildContext context,
    String kind,
    List<({AiJodiInput input, AiJodiResult result})> listed,
    Map<String, StudyRow> rowBySymbol,
  ) async {
    final messenger = ScaffoldMessenger.of(context);
    final asOf = DateTime.now();
    final exportRows = <AiJodiExportRow>[
      for (final entry in listed)
        () {
          final studyRow = rowBySymbol[entry.input.symbol];
          final kal =
              studyRow == null ? (atm: null, otm: null) : kalPnlFor(studyRow);
          return AiJodiExportRow(
            symbol: entry.input.symbol,
            companyName: entry.input.companyName,
            ltp: entry.input.ltp,
            atr: entry.input.atr,
            avgRange: entry.input.avgRange,
            avgDailyMove15: entry.input.avgDailyMove15,
            monthsMeeting20: entry.result.monthsMeeting20,
            monthlyMoveRupee: entry.result.typicalMoveRupee,
            atmJodi: entry.input.atmJodiPrice,
            otmJodi: entry.input.otmJodiPrice,
            coverAtm: entry.result.coverAtm,
            coverOtm: entry.result.coverOtm,
            verdict: entry.result.verdict.label,
            kalAtmPnl: kal.atm,
            kalOtmPnl: kal.otm,
            ivRank: studyRow?.ivRank.label ?? '—',
            isManual: entry.input.isManual,
            ivp: entry.input.ivp,
            ivr: entry.input.ivr,
          );
        }(),
    ];

    final delivery = StudyDeliveryService(export: StudyExportService());
    final StudyDeliveryOutcome outcome = switch (kind) {
      'text' => await delivery.shareText(AiJodiExport.recap(exportRows, asOf)),
      'xlsx' => await delivery.shareFile(
          await AiJodiExport.writeXlsx(exportRows, asOf: asOf),
          'AI Jodi Study',
        ),
      _ => await delivery.shareFile(
          await AiJodiExport.writeCsv(exportRows, asOf: asOf),
          'AI Jodi Study',
        ),
    };
    messenger.showSnackBar(
      SnackBar(
        content: Text(outcome.message),
        backgroundColor: outcome.ok ? null : Theme.of(context).colorScheme.error,
      ),
    );
  }

  void _showRules(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Rules (aapke decide kiye hue)'),
        content: const SingleChildScrollView(
          child: Text(
            '• 15 din: roz ka average daily move ATR(14) se zyada hona '
            'chahiye.\n'
            '• Month: high−low range price ka 20%+ kam se kam 2 me 3 '
            'months me ("mostly").\n'
            '• Jodi: typical monthly ₹ move, jodi ke daam se zyada honi '
            'chahiye.\n'
            '• Verdict: movement agar jodi ko 2× cover karti hai tabhi '
            'buy — bharpoor ho to ATM straddle, warna sasti OTM '
            'strangle. Dono legs BUY (long pair): direction-neutral, '
            'risk sirf premium tak. Monthly expiry.\n'
            '• Ye analytics hai, investment advice nahi.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Theek hai'),
          ),
        ],
      ),
    );
  }
}

class _HeaderStrip extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      color: scheme.surfaceContainerHighest,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: Text(
        'AI Calculation & Chart Study — 15-din ATR gate · month 20-30% · '
        'jodi 2× cover · long straddle/strangle (risk premium tak)',
        style: Theme.of(context).textTheme.bodySmall,
      ),
    );
  }
}

class _ScanProgress extends StatelessWidget {
  const _ScanProgress({required this.provider});

  final FnoStudyProvider provider;

  @override
  Widget build(BuildContext context) {
    final progress = provider.progress;
    final total = progress?.total ?? 0;
    final done = progress?.done ?? 0;
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Study ho rahi hai… '
            '${total > 0 ? '$done/$total stocks' : 'shuruaat'}',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          const SizedBox(height: 6),
          LinearProgressIndicator(value: total > 0 ? done / total : null),
        ],
      ),
    );
  }
}

class _ErrorStrip extends StatelessWidget {
  const _ErrorStrip({required this.message, required this.provider});

  final String message;
  final FnoStudyProvider provider;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      color: scheme.errorContainer,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: Row(
        children: [
          Expanded(
            child: Text(
              message,
              style: Theme.of(context)
                  .textTheme
                  .bodySmall
                  ?.copyWith(color: scheme.onErrorContainer),
            ),
          ),
          TextButton(
            onPressed: () => _rescanWithSheet(context),
            child: const Text('Retry'),
          ),
        ],
      ),
    );
  }
}

class _TableHeader extends StatelessWidget {
  const _TableHeader();

  @override
  Widget build(BuildContext context) {
    final style = Theme.of(context)
        .textTheme
        .labelSmall
        ?.copyWith(fontWeight: FontWeight.w700);
    // No horizontal padding and no inner scroller — the shared horizontal
    // SingleChildScrollView wraps header AND rows together (1.5.54), so the
    // columns stay aligned at every scroll offset.
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: SizedBox(
        width: _kTableWidth,
        child: Row(
          children: [
            _cell(_wStock, Text('Stock', style: style)),
            _cell(_wPrice, Text('Price', style: style, textAlign: TextAlign.right)),
            _cell(_wAtr, Text('ATR', style: style, textAlign: TextAlign.right)),
            _cell(_wAvgRange,
                Text('Avg Range', style: style, textAlign: TextAlign.right)),
            _cell(_wAtm, Text('ATM jodi', style: style, textAlign: TextAlign.right)),
            _cell(_wOtm, Text('OTM jodi', style: style, textAlign: TextAlign.right)),
            _cell(_wIv, Text('IVP/IVR', style: style, textAlign: TextAlign.right)),
            _cell(_wKal, Text('Kal→aaj', style: style, textAlign: TextAlign.right)),
            _cell(_wVerdict, Text('Konsi buy?', style: style)),
          ],
        ),
      ),
    );
  }
}

Widget _cell(double width, Widget child) => SizedBox(
      width: width,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6),
        child: child,
      ),
    );

class _JodiRow extends StatelessWidget {
  const _JodiRow({
    required this.input,
    required this.result,
    required this.rank,
    required this.studyRow,
    required this.zebra,
  });

  final AiJodiInput input;
  final AiJodiResult result;
  final int rank;
  final StudyRow? studyRow;
  final bool zebra;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final verdict = result.verdict;
    final color = switch (verdict) {
      AiJodiVerdict.atmBuy => Colors.green.shade700,
      AiJodiVerdict.otmBuy => Colors.teal.shade700,
      AiJodiVerdict.skip => Colors.orange.shade800,
      AiJodiVerdict.noPrice => theme.colorScheme.outline,
      AiJodiVerdict.ivRich => Colors.deepOrange.shade700,
    };
    final row = studyRow;
    final kal = row == null ? (atm: null, otm: null) : kalPnlFor(row);
    return Material(
      color: zebra
          ? theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.35)
          : Colors.transparent,
      child: InkWell(
        onTap: row == null
            ? null
            : () => showAiJodiDetail(context, row: row, result: result),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _cell(
                _wStock,
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '$rank. ${input.symbol}',
                      style: theme.textTheme.bodyMedium
                          ?.copyWith(fontWeight: FontWeight.w700),
                    ),
                    Text(
                      input.isManual
                          ? '${input.companyName} · aapka add kiya'
                          : input.companyName,
                      style: theme.textTheme.bodySmall,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    if (row != null || input.ivp != null || input.ivr != null)
                      Text(
                        (input.ivp != null || input.ivr != null)
                            ? AiJodiEngine.ivStarFromValues(
                                ivp: input.ivp, ivr: input.ivr)
                            : AiJodiEngine.ivStarLabel(row!.ivRank),
                        style: theme.textTheme.labelSmall,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    // News × Jodi chips (1.5.55) — News khule bina signal
                    // dikhta hai. 🔥 = news + jodi dono bullish signal de rahe.
                    Builder(
                      builder: (context) {
                        final news =
                            NewsSignals.instance.forSymbol(input.symbol);
                        if (news == null) return const SizedBox.shrink();
                        final isBuy = verdict == AiJodiVerdict.atmBuy ||
                            verdict == AiJodiVerdict.otmBuy;
                        return Text(
                          isBuy
                              ? '🔥 News+Jodi (${news.highImpactCount})'
                              : '📰 ${news.highImpactCount} news',
                          style: theme.textTheme.labelSmall?.copyWith(
                            fontWeight: FontWeight.w700,
                            color: isBuy
                                ? Colors.red.shade700
                                : theme.colorScheme.primary,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        );
                      },
                    ),
                  ],
                ),
              ),
              _cell(
                _wPrice,
                Text(
                  Fmt.price(input.ltp),
                  textAlign: TextAlign.right,
                  style: theme.textTheme.bodyMedium,
                ),
              ),
              _cell(
                _wAtr,
                Text(
                  Fmt.price(input.atr),
                  textAlign: TextAlign.right,
                  style: theme.textTheme.bodyMedium,
                ),
              ),
              _cell(
                _wAvgRange,
                Text(
                  input.avgRange > 0 ? Fmt.price(input.avgRange) : '—',
                  textAlign: TextAlign.right,
                  style: theme.textTheme.bodyMedium,
                ),
              ),
              _cell(
                _wAtm,
                Text(
                  input.atmJodiPrice == null
                      ? '—'
                      : Fmt.price(input.atmJodiPrice),
                  textAlign: TextAlign.right,
                  style: theme.textTheme.bodyMedium,
                ),
              ),
              _cell(
                _wOtm,
                Text(
                  input.otmJodiPrice == null
                      ? '—'
                      : Fmt.price(input.otmJodiPrice),
                  textAlign: TextAlign.right,
                  style: theme.textTheme.bodyMedium,
                ),
              ),
              _cell(
                _wIv,
                Text(
                  '${input.ivp?.toStringAsFixed(0) ?? '—'}/${input.ivr?.toStringAsFixed(0) ?? '—'}',
                  textAlign: TextAlign.right,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: input.ivCheap
                        ? Colors.green.shade700
                        : (input.effectiveIv ?? 0) >= AiJodiRules.ivRichFloorPct
                            ? Colors.deepOrange.shade700
                            : null,
                  ),
                ),
              ),
              _cell(
                _wKal,
                Text(
                  'ATM ${kal.atm == null ? '—' : _signed(kal.atm!)}\n'
                  'OTM ${kal.otm == null ? '—' : _signed(kal.otm!)}',
                  textAlign: TextAlign.right,
                  style: theme.textTheme.labelSmall,
                ),
              ),
              _cell(
                _wVerdict,
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      verdict.label,
                      style: theme.textTheme.bodySmall
                          ?.copyWith(color: color, fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Move ₹${result.typicalMoveRupee.toStringAsFixed(0)}'
                      '${result.coverAtm == null ? '' : ' · ATM ${result.coverAtm!.toStringAsFixed(1)}×'}'
                      '${result.coverOtm == null ? '' : ' · OTM ${result.coverOtm!.toStringAsFixed(1)}×'}',
                      style: theme.textTheme.labelSmall,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _signed(double value) =>
      '${value >= 0 ? '+' : ''}₹${value.toStringAsFixed(1)}';
}



class _FooterNote extends StatelessWidget {
  const _FooterNote();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 8, 14, 10),
        child: Text(
          'Long pair (CE+PE dono BUY) — direction-neutral, risk sirf premium '
          'tak. Ye analytics hai, investment advice nahi.',
          style: Theme.of(context).textTheme.labelSmall,
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.provider});

  final FnoStudyProvider provider;

  @override
  Widget build(BuildContext context) {
    final running = provider.isRunning;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.query_stats_rounded, size: 42),
            const SizedBox(height: 12),
            Text(
              running
                  ? 'F&O ke sabhi stocks ki study apne aap ho rahi hai — '
                      'kuch seconds…'
                  : 'Study khud shuru hoti hai. Agar abhi tak nahi hui to '
                      'neeche button dabayein.',
              textAlign: TextAlign.center,
            ),
            if (!running) ...[
              const SizedBox(height: 14),
              FilledButton(
                onPressed: () => _rescanWithSheet(context),
                child: const Text('Abhi scan karo'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _NoMatches extends StatelessWidget {
  const _NoMatches();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Text(
          'Koi stock teeno gates nahi paar kar raha (15-din ATR, month 20%+, '
          'jodi 2× cover). Aap khud "Stock add karein" se apni pasand ke '
          'stocks daal sakte hain.',
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}

class _AddStockDialog extends StatefulWidget {
  const _AddStockDialog({required this.candidates});

  final List<StudyRow> candidates;

  @override
  State<_AddStockDialog> createState() => _AddStockDialogState();
}

class _AddStockDialogState extends State<_AddStockDialog> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final q = _query.trim().toUpperCase();
    final filtered = q.isEmpty
        ? widget.candidates
        : [
            for (final row in widget.candidates)
              if (row.symbol.toUpperCase().contains(q) ||
                  row.companyName.toUpperCase().contains(q))
                row,
          ];
    return AlertDialog(
      title: const Text('Stock add karein'),
      content: SizedBox(
        width: double.maxFinite,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              autofocus: true,
              decoration: const InputDecoration(
                hintText: 'Symbol ya naam…',
                prefixIcon: Icon(Icons.search_rounded),
              ),
              onChanged: (value) => setState(() => _query = value),
            ),
            const SizedBox(height: 8),
            Flexible(
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: filtered.length,
                itemBuilder: (context, index) {
                  final row = filtered[index];
                  return ListTile(
                    dense: true,
                    title: Text(row.symbol),
                    subtitle: Text(
                      row.companyName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    trailing: Text('₹${row.ltp.toStringAsFixed(2)}'),
                    onTap: () => Navigator.of(context).pop(row.symbol),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
      ],
    );
  }
}
