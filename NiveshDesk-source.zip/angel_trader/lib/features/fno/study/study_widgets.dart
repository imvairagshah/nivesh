// ---------------------------------------------------------------------------
// study_widgets.dart — the pieces the 3-Month Study screen is built from.
//
//   • [StudyRowTile]      one line of the table (rank, trend chip, score, tag)
//   • [StudyDetailPanel]  the expanded view — spec §3.4's seven items, the
//                         "agar kal jodi buy ki hoti" P&L, the live premium
//                         line and the two actions
//   • [showStudyReadMe]   the in-app Read Me (same wording as the XLSX sheet)
//   • [showStudySkips]    which stocks were left out, and why
//   • [showOptionTradeSheet] CE/PE picker that hands off to the existing
//                         paper-trading order sheet
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/markets.dart';
import '../../../core/widgets/ui.dart';
import '../../../data/local/models/paper_trade.dart' show OrderSide;
import '../../../data/remote/dto/scrip.dart';
import 'iv_sheet_link.dart';
import '../../../services/fno_study_service.dart' show StudySkip;
import '../../paper_trading/widgets/order_sheet.dart';
import 'study_engine.dart';
import 'study_export.dart';

// The expanded card lives in study_detail_panel.dart (1.5.58 redesign) —
// exported here so the screens and tests keep one import.
export 'study_detail_panel.dart';

/// Text on the trend chip: label + what the study suggests doing about it.
String trendHeadline(StudyRow row) => '${row.trend.label} · ${row.trend.suggested}';

/// An option leg as an instrument the rest of the app understands (quotes,
/// paper trading) — the F&O exchange, the broker's contract symbol as the
/// ticker, and the underlying as the display name.
Scrip scripForLeg(StudyRow row, StudyOptionLeg leg) => Scrip(
      token: leg.token,
      symbol: leg.symbol,
      name: '${row.symbol} ${leg.strike.toStringAsFixed(0)} ${leg.type.code}',
      exchange: Exchange.nfo,
    );

Color _trendColor(MarketColors colors, Trend3M trend) => switch (trend) {
      Trend3M.strongUp => colors.gain,
      Trend3M.up => colors.gain,
      Trend3M.sideways => colors.flat,
      Trend3M.down => colors.loss,
      Trend3M.strongDown => colors.loss,
    };

// ---------------------------------------------------------------------------
// One table row
// ---------------------------------------------------------------------------

class StudyRowTile extends StatelessWidget {
  const StudyRowTile({
    super.key,
    required this.row,
    required this.expanded,
    required this.onTap,
    this.livePremiums,
    this.liveStrangle,
  });

  final StudyRow row;
  final bool expanded;
  final VoidCallback onTap;

  /// The open row's live premiums (`{'CE': 8.4, 'PE': 7.7}`) — the feed only
  /// subscribes to the row that is open, so a closed card shows the frozen
  /// scan values. Live wins when it is there, exactly like the panel.
  final Map<String, double>? livePremiums;
  final Map<String, double>? liveStrangle;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final colors = MarketColors.of(context);
    final trendColor = _trendColor(colors, row.trend);

    // Live premium first (the open row only), frozen scan values otherwise —
    // one helper for both so the card and the panel can never disagree.
    final liveAtm = livePremiums == null
        ? null
        : _pair(livePremiums!['CE'], livePremiums!['PE']);
    final liveOtm = liveStrangle == null
        ? null
        : _pair(liveStrangle!['CE'], liveStrangle!['PE']);
    final atmPct = premiumPctOfPrice(liveAtm ?? row.straddleLtp, row.ltp);
    final otmPct = premiumPctOfPrice(liveOtm ?? row.strangleLtp, row.ltp);

    return Material(
      color: expanded ? scheme.primaryContainer.withOpacity(0.35) : Colors.transparent,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Line 1 — rank · symbol · trend chip … price · 3M move.
              Row(
                children: [
                  SizedBox(
                    width: 26,
                    child: Text(
                      '${row.rank}',
                      style: TextStyle(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w700,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Flexible(
                              child: Text(
                                row.symbol,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 14.5,
                                ),
                              ),
                            ),
                            const SizedBox(width: 6),
                            TapChip(
                              label: row.trend.label,
                              color: trendColor,
                              filled: true,
                              fontSize: 9.5,
                              tooltip: row.trend.suggested,
                            ),
                          ],
                        ),
                        const SizedBox(height: 2),
                        Text(
                          row.companyName.isEmpty ? row.trend.suggested : row.companyName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 11,
                            color: scheme.onSurfaceVariant,
                          ),
                        ),
                        // Opstra IVP/IVR chip (1.5.57) — sheet me values hon
                        // tabhi dikhta hai (hide = absence stays absence).
                        IvSheetChip(symbol: row.symbol),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        StudyExportService.money(row.ltp),
                        style: const TextStyle(
                          fontSize: 13.5,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Text(
                        '${StudyExportService.perc(row.total3mPct)} 3M',
                        style: TextStyle(
                          fontSize: 11,
                          color: colors.forValue(row.total3mPct),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 8),
              // Line 2 — score · opportunity tag · expand.
              Row(
                children: [
                  _ScorePill(score: row.score),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      row.opportunityTag,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w600,
                        color: row.isBestBuy ? colors.gain : scheme.onSurfaceVariant,
                      ),
                    ),
                  ),
                  if (row.avgIv == null)
                    Tooltip(
                      message: 'Option data nahi mila — baaki study theek hai',
                      child: Icon(Icons.cloud_off_rounded,
                          size: 14, color: colors.stale),
                    ),
                  const SizedBox(width: 6),
                  Icon(
                    expanded
                        ? Icons.keyboard_arrow_up_rounded
                        : Icons.keyboard_arrow_down_rounded,
                    size: 18,
                    color: scheme.onSurfaceVariant,
                  ),
                ],
              ),
              // Line 3 — the two jodis as a share of the stock's own price, one
              // chip each so the numbers never run together. Blank when neither
              // jodi is priced, never 0.
              if (atmPct != null || otmPct != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Row(
                    children: [
                      if (atmPct != null) ...[
                        TapChip(
                          emoji: '🤝',
                          label: 'ATM ${atmPct.toStringAsFixed(2)}%',
                          color: scheme.onSurfaceVariant,
                          filled: true,
                          tooltip: 'ATM jodi (CE+PE) stock ke bhav ka % — of price',
                        ),
                        const SizedBox(width: 6),
                      ],
                      if (otmPct != null) ...[
                        TapChip(
                          emoji: '🎯',
                          label: 'OTM ${otmPct.toStringAsFixed(2)}%',
                          color: scheme.onSurfaceVariant,
                          filled: true,
                          tooltip: 'OTM jodi (strangle) stock ke bhav ka % — of price',
                        ),
                        const SizedBox(width: 6),
                      ],
                      Text(
                        'of price',
                        style: TextStyle(
                          fontSize: 9.5,
                          color: scheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Two legs make a jodi — one leg alone is not a price, so the pair is null
/// until both sides are there (a half-priced strangle would print a number
/// the user could not buy).
double? _pair(double? ce, double? pe) => (ce == null || pe == null) ? null : ce + pe;

class _ScorePill extends StatelessWidget {
  const _ScorePill({required this.score});

  final double score;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    // 0–12 → a three-step colour ramp so a 9 pops out of a long list.
    final Color tint = score >= 8
        ? MarketColors.of(context).gain
        : (score >= 5 ? scheme.primary : scheme.onSurfaceVariant);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: tint.withOpacity(0.14),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        '${score.toStringAsFixed(1)} / 12',
        style: TextStyle(
          fontSize: 10.5,
          fontWeight: FontWeight.w800,
          color: tint,
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Sheets
// ---------------------------------------------------------------------------

/// Read Me — the same wording the XLSX "Read Me" sheet carries.
Future<void> showStudyReadMe(BuildContext context) => showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      showDragHandle: true,
      builder: (_) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.85,
        maxChildSize: 0.95,
        builder: (_, controller) => ListView(
          controller: controller,
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          children: [
            const Text(
              '3-Month Study — Read Me',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 4),
            Text(
              'Har row ek F&O stock hai. Neeche har column ka matlab hai.',
              style: TextStyle(
                fontSize: 12,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 14),
            for (final line in StudyExportService.readMeSheet(
              FnoStudyExportMeta(
                asOf: DateTime.now(),
                runAt: DateTime.now(),
                rowCount: 0,
                bestBuyCount: 0,
                withOptions: 0,
              ),
            ))
              if (line.length == 2 &&
                  line[0] != null &&
                  line[1] != null &&
                  line[1].toString().isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: 118,
                        child: Text(
                          line[0].toString(),
                          style: const TextStyle(
                            fontSize: 11.5,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      Expanded(
                        child: Text(
                          line[1].toString(),
                          style: const TextStyle(fontSize: 11.5, height: 1.35),
                        ),
                      ),
                    ],
                  ),
                ),
          ],
        ),
      ),
    );

/// "Ye stocks study me nahi aaye" — every skip with its reason (spec §6).
Future<void> showStudySkips(BuildContext context, List<StudySkip> skips) =>
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      showDragHandle: true,
      builder: (_) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.6,
        maxChildSize: 0.92,
        builder: (_, controller) => ListView(
          controller: controller,
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          children: [
            Text(
              'Study ke notes (${skips.length})',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 4),
            Text(
              'Har entry ke saath reason hai. Zyadatar cases daily candles kam '
              'hone ki wajah se hote hain (naya listing ya suspend). '
              '"- options -" wali entry batati hai ki option data kyun nahi mila '
              '(study phir bhi degraded mode me chalti hai).',
              style: TextStyle(
                fontSize: 11.5,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 12),
            for (final skip in skips)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: 96,
                      child: Text(
                        skip.symbol,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    Expanded(
                      child: Text(
                        skip.reason,
                        style: const TextStyle(fontSize: 11.5, height: 1.3),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );

/// Closes the picker and opens the paper-trading sheet on [leg], pre-locked to
/// [side]. SELL with nothing held opens a short (option writing) — the engine's
/// own validation is the referee, this only carries the intent.
void _openOrder(
  BuildContext sheetContext,
  BuildContext context, {
  required StudyRow row,
  required StudyOptionLeg leg,
  required OrderSide side,
}) {
  Navigator.of(sheetContext).pop();
  showOrderSheet(
    context,
    preset: scripForLeg(row, leg),
    forcedSide: side,
    lotSize: row.lotSize,
  );
}

/// CE / PE picker → hands the leg to the existing paper-trading order sheet.
Future<void> showOptionTradeSheet(BuildContext context, StudyRow row) =>
    showModalBottomSheet<void>(
      context: context,
      useSafeArea: true,
      showDragHandle: true,
      builder: (sheetContext) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
        // Scrollable: the sheet now lists the ATM jodi **and** the OTM jodi, and
        // a fixed column overflowed the bottom of a short phone screen.
        child: SingleChildScrollView(
          child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${row.symbol} — paper trade',
                  style:
                      const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
                ),
              const SizedBox(height: 4),
              Text(
                'ATM ${StudyExportService.money(row.atmStrike, decimals: 0)} · '
                '${row.expiryLabel ?? '—'} · 1 lot = ${row.lotSize} qty',
                style: TextStyle(
                  fontSize: 11.5,
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
              if (row.straddleLtp != null) ...[
                const SizedBox(height: 2),
                Text(
                  'Jodi total (CE+PE): ${StudyExportService.money(row.straddleLtp)}',
                  style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w700,
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
              const SizedBox(height: 6),
              Text(
                'Study ka suggestion: ${row.trend.suggested} '
                '(${row.trend.label} trend, score ${row.score.toStringAsFixed(1)})',
                style: const TextStyle(fontSize: 11.5),
              ),
              const SizedBox(height: 14),
              // ATM jodi pehle, OTM jodi (strangle) uske baad — dono ke BUY/SELL
              // ek hi tap door hain, jaisa ATM jodi ke liye pehle se tha.
              for (final group in <(String, List<StudyOptionLeg?>)>[
                ('ATM jodi', [row.ce, row.pe]),
                if (row.strangle != null)
                  ('OTM jodi (strangle)', [
                    row.strangle!.ce,
                    row.strangle!.pe,
                  ]),
              ]) ...[
                Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Text(
                    group.$1,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                for (final leg in group.$2)
                  if (leg != null)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Text(
                                leg.type.code,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 13,
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  'LTP ${StudyExportService.money(leg.ltp)} · '
                                  'strike '
                                  '${StudyExportService.money(leg.strike, decimals: 0)}',
                                  style: const TextStyle(fontSize: 12),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 5),
                          Row(
                            children: [
                              // BUY (long) and SELL (short / option writing) are
                              // both one tap — the sheet decides the rest. Lot
                              // size is passed so the sheet can talk in lots.
                              Expanded(
                                child: OutlinedButton(
                                  onPressed: () => _openOrder(
                                    sheetContext,
                                    context,
                                    row: row,
                                    leg: leg,
                                    side: OrderSide.buy,
                                  ),
                                  child: const Text('BUY'),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: OutlinedButton(
                                  onPressed: () => _openOrder(
                                    sheetContext,
                                    context,
                                    row: row,
                                    leg: leg,
                                    side: OrderSide.sell,
                                  ),
                                  child: const Text('SELL'),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
              ],
              const SizedBox(height: 4),
              Text(
                'Ye paisa nahi lagta — sirf app ke andar ka paper trade hai.',
                style: TextStyle(
                  fontSize: 10.5,
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
      ),
    );
