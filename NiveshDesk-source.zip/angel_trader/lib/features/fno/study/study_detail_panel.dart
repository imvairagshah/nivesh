// ---------------------------------------------------------------------------
// study_detail_panel.dart — the expanded 3-Month Study view (1.5.58 redesign).
// Every number now sits in its own labelled box (MetricBox/MetricGrid) so
// values can never run together, section titles carry an emoji marker and a
// tooltip with the full meaning, and the reading order is strict: one section,
// one question. All data and explanation wording is unchanged from the spec —
// only the presentation is rebuilt.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/widgets/ui.dart';
import 'iv_sheet_link.dart';
import '../../../services/earnings_calendar_service.dart';
import 'study_engine.dart';
import 'study_export.dart';
import 'study_widgets.dart' show showOptionTradeSheet, trendHeadline;

class StudyDetailPanel extends StatelessWidget {
  const StudyDetailPanel({
    super.key,
    required this.row,
    required this.livePremiums,
    required this.liveFeedActive,
    required this.onClose,
    this.liveKalPremiums = const {},
    this.liveStrangle = const {},
    this.liveKalStrangle = const {},
    this.earnings,
    this.earningsNote,
    this.earningsLoading = false,
  });

  final StudyRow row;

  /// Live premiums for the two ATM legs, `{'CE': 42.5, 'PE': 38.4}`.
  final Map<String, double> livePremiums;

  /// Live premiums for the **kal wale ATM** legs — same keys. Empty when that
  /// pair is the same strike as today's (the line then uses [livePremiums]).
  final Map<String, double> liveKalPremiums;

  /// Live premiums for the **OTM jodi (strangle)** legs — `{'CE': …, 'PE': …}`.
  final Map<String, double> liveStrangle;

  /// Live premiums for the **kal wale OTM jodi** legs.
  final Map<String, double> liveKalStrangle;
  final bool liveFeedActive;
  final VoidCallback onClose;

  /// When the company last reported and when the next result is due (NSE).
  /// Null = the feed has nothing for this symbol (or has not loaded yet).
  final EarningsInfo? earnings;
  final String? earningsNote;
  final bool earningsLoading;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final colors = MarketColors.of(context);

    return Container(
      margin: const EdgeInsets.fromLTRB(12, 2, 12, 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: scheme.outlineVariant.withOpacity(0.6)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  '${row.symbol} · ${row.companyName.isEmpty ? row.underlying : row.companyName}',
                  style: const TextStyle(
                    fontSize: 13.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              IconButton(
                onPressed: onClose,
                icon: const Icon(Icons.close_rounded, size: 18),
                tooltip: 'Band karo',
                visualDensity: VisualDensity.compact,
              ),
            ],
          ),

          // 1 · Price & levels
          _PanelSection(
            emoji: '💰',
            title: '1 · Price aur 3-month levels',
            tooltip: 'Stock ka aaj ka bhav aur 3-mahine ke high/low/range',
            children: [
              MetricGrid(
                children: [
                  MetricBox(
                    emoji: '🏷️',
                    label: 'CMP',
                    value: Fmt.price(row.ltp),
                    tooltip: 'Current market price — aaj ka close',
                    strong: true,
                  ),
                  MetricBox(
                    emoji: '📈',
                    label: '3M High',
                    value: Fmt.price(row.high3m),
                    sub:
                        '${StudyExportService.perc(row.distHiPct)} neeche · ${row.distHiDays.toStringAsFixed(1)} ATR-din',
                    tooltip: '3-mahine ka sabse ooncha bhav',
                  ),
                  MetricBox(
                    emoji: '📉',
                    label: '3M Low',
                    value: Fmt.price(row.low3m),
                    sub:
                        '${StudyExportService.perc(row.distLoPct)} upar · ${row.distLoDays.toStringAsFixed(1)} ATR-din',
                    tooltip: '3-mahine ka sabse neeche bhav',
                  ),
                  MetricBox(
                    emoji: '↔️',
                    label: '3M range',
                    value: StudyExportService.perc(row.rangePct),
                    tooltip: 'High−Low range, low ka % ke roop me',
                  ),
                ],
              ),
            ],
          ),

          // 2 · Volatility (ATR) + jodi costs as a share of price.
          _PanelSection(
            emoji: '📏',
            title: '2 · Volatility (ATR)',
            tooltip: 'Average True Range — stock ka normal daily move',
            children: [
              MetricGrid(
                children: [
                  MetricBox(
                    emoji: '⚡',
                    label: 'ATR(14)',
                    value: Fmt.price(row.atr),
                    sub: '${StudyExportService.perc(row.atrPct)} of price',
                    tooltip: '14-din ka average daily move (rupees me)',
                  ),
                  MetricBox(
                    emoji: '↔️',
                    label: 'Avg Range (14)',
                    value: row.avgRange > 0 ? Fmt.price(row.avgRange) : '—',
                    sub: row.avgRange > 0
                        ? '${StudyExportService.perc(row.avgRangePct)} of price'
                        : '—',
                    tooltip: 'Pichhle 14 sessions ke High − Low ka simple '
                        'average — sirf din ka range, gap up/down chhod ke. '
                        'ATR alag hai: wo kal ke close ke gap ko bhi count '
                        'karta hai',
                  ),
                  // IVP/IVR (1.5.69) — Opstra Google Sheet se, dono boxes
                  // sheet-fetch par khud update.
                  ...ivMetricBoxes(row.symbol),
                  if (_jodiTotal != null)
                    MetricBox(
                      emoji: '🤝',
                      label: 'Jodi total (CE+PE)',
                      value: _jodiTotal!,
                      sub: _pctOfPrice(_jodiValue),
                      tooltip: 'ATM jodi (CE+PE) ka kul premium, aur stock ke '
                          'bhav ka kitna % hai',
                    ),
                  if (_strangle()?.total != null)
                    MetricBox(
                      emoji: '🎯',
                      label: 'OTM jodi total',
                      value: StudyExportService.money(_strangle()!.total),
                      sub: _pctOfPrice(_strangle()!.total),
                      tooltip: 'OTM jodi (strangle) ka kul premium',
                    ),
                ],
              ),
              if (_jodiValue != null || _strangle()?.total != null)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(
                    'Jodi stock ke bhav ka kitna % hai — '
                    '${StudyExportService.money(row.ltp)} ke stock par.',
                    style: TextStyle(
                      fontSize: 10,
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
                ),
            ],
          ),

          // 3 · Month-wise moves
          _PanelSection(
            emoji: '🗓️',
            title: '3 · Mahine ki move',
            tooltip: 'Har mahine stock ne kitna range banaya',
            children: [
              MetricGrid(
                children: [
                  for (final month in row.months.reversed)
                    MetricBox(
                      label: month.label,
                      value: StudyExportService.perc(month.pct),
                      valueColor: colors.forValue(month.pct),
                      tooltip: '${month.label} ki range (high−low)',
                    ),
                  MetricBox(
                    emoji: 'Σ',
                    label: 'Total 3M',
                    value: StudyExportService.perc(row.total3mPct),
                    sub: '${row.upMonths} up / ${row.downMonths} down month',
                    valueColor: colors.forValue(row.total3mPct),
                    tooltip: 'Teeno mahine ka total move',
                  ),
                ],
              ),
            ],
          ),

          // 4 · Trend
          _PanelSection(
            emoji: '📊',
            title: '4 · Trend',
            tooltip: 'Study ka score aur direction',
            children: [
              MetricGrid(
                children: [
                  MetricBox(
                    emoji: '🧭',
                    label: 'Direction',
                    value: trendHeadline(row),
                    valueColor: _trendColorOf(colors, row.trend),
                    tooltip: '3-mahine ka trend direction',
                    expand: true,
                  ),
                  MetricBox(
                    emoji: '⭐',
                    label: 'Score',
                    value: '${row.score.toStringAsFixed(1)} / 12',
                    sub:
                        'consistency ${row.consistencyPoints.toStringAsFixed(0)} + magnitude ${row.magnitudePoints.toStringAsFixed(1)} + proximity ${row.proximityPoints.toStringAsFixed(1)} + IV ${row.ivPoints.toStringAsFixed(1)}',
                    tooltip: 'Study score — consistency + magnitude + '
                        'proximity + IV, total 12',
                  ),
                ],
              ),
            ],
          ),

          // 5 · ATM option
          _PanelSection(
            emoji: '💹',
            title: '5 · ATM option',
            tooltip: 'ATM strike ke CE/PE legs, jodi ka premium aur edge',
            children: row.atmStrike == null
                ? [
                    Text(
                      'Is stock ke options ka data nahi mila (degraded mode). '
                      'Trend, ATR aur levels upar dekh sakte ho.',
                      style: TextStyle(fontSize: 11.5, color: colors.stale),
                    ),
                  ]
                : [
                    MetricGrid(
                      children: [
                        MetricBox(
                          emoji: '🎯',
                          label: 'Strike',
                          value:
                              StudyExportService.money(row.atmStrike, decimals: 0),
                          sub:
                              '${row.expiryLabel ?? '—'}${row.daysToExpiry == null ? '' : ' · ${row.daysToExpiry} din'}',
                          tooltip: 'ATM strike aur expiry',
                        ),
                        MetricBox(
                          emoji: '📦',
                          label: 'Lot size',
                          value: '${row.lotSize}',
                          tooltip: 'Ek lot me kitne share',
                        ),
                        _legBox(context, row.ce, 'CE', livePremiums['CE']),
                        _legBox(context, row.pe, 'PE', livePremiums['PE']),
                        MetricBox(
                          emoji: '🤝',
                          label: 'Jodi total (CE+PE)',
                          value: _jodiTotal ?? '—',
                          tooltip: 'CE + PE ka kul premium',
                        ),
                        MetricBox(
                          emoji: '🌀',
                          label: 'Avg IV',
                          value: StudyExportService.perc(row.avgIv),
                          tooltip: 'CE aur PE ka average implied volatility',
                        ),
                        MetricBox(
                          emoji: '📶',
                          label: 'IV rank',
                          value: row.ivRank.label,
                          tooltip: 'IV apne history me sasta hai ya mehnga',
                        ),
                        MetricBox(
                          emoji: '🎲',
                          label: 'Edge',
                          value: StudyExportService.edgeWords(row),
                          valueColor: colors.forValue(row.edgePct),
                          tooltip: 'Jodi ka daam vs stock ka normal move',
                        ),
                      ],
                    ),
                  ],
          ),

          // 6 · OTM jodi (strangle)
          _PanelSection(
            emoji: '🎯',
            title: '6 · OTM jodi (strangle)',
            tooltip: 'ATM se hata hua CE+PE pair — sasta, par doori zyada',
            children: _strangleBlock(context, scheme, colors),
          ),

          // 7 · Results (NSE)
          _PanelSection(
            emoji: '📅',
            title: '7 · Results (NSE)',
            tooltip: 'Last result kab aaya, next kab aayega',
            children: _resultsBlock(context, scheme),
          ),

          // 8 · Agar kal (ATM) jodi buy ki hoti
          _PanelSection(
            emoji: '🧮',
            title: '8 · Agar kal jodi buy ki hoti',
            tooltip: 'Kal ke close par jodi li hoti to aaj kya hota',
            children: _kalAtmBlock(context, scheme, colors),
          ),

          // 9 · Agar kal OTM jodi buy ki hoti
          _PanelSection(
            emoji: '🧮',
            title: '9 · Agar kal OTM jodi buy ki hoti',
            tooltip: 'Wahi hisaab, OTM jodi ke saath',
            children: _kalStrangleBlock(context, scheme, colors),
          ),

          // Reason + actions
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: scheme.surfaceContainerHighest.withOpacity(0.6),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              row.reason,
              style: const TextStyle(fontSize: 11.5, height: 1.35),
            ),
          ),
          const SizedBox(height: 10),
          Wrap(
            alignment: WrapAlignment.end,
            spacing: 8,
            runSpacing: 8,
            children: [
              FilledButton.tonalIcon(
                onPressed: row.hasTradeablePair
                    ? () => showOptionTradeSheet(context, row)
                    : null,
                icon: const Icon(Icons.playlist_add_rounded, size: 17),
                label: const Text(
                  'Paper trade me add karo',
                  style: TextStyle(fontSize: 12),
                ),
                style: FilledButton.styleFrom(
                  visualDensity: VisualDensity.compact,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                ),
              ),
              OutlinedButton.icon(
                onPressed: onClose,
                icon: const Icon(Icons.expand_less_rounded, size: 17),
                label: const Text('Band karo', style: TextStyle(fontSize: 12)),
                style: OutlinedButton.styleFrom(
                  visualDensity: VisualDensity.compact,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            liveFeedActive
                ? 'Live premium line: chart band karne tak CE/PE ke rate update '
                    'hote rahenge (30 second me ek baar socket se).'
                : 'Live feed settings me band hai — sirf scan wale rate dikhenge.',
            style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant),
          ),
        ],
      ),
    );
  }

  // -------------------------------------------------------------------------
  // Numbers
  // -------------------------------------------------------------------------

  /// What the ATM pair costs as one jodi (CE + PE), or null when a leg has no
  /// price. Live premiums win over the frozen scan values.
  String? get _jodiTotal {
    final value = _jodiValue;
    return value == null ? null : StudyExportService.money(value);
  }

  /// A premium as "X% of price" — the stock's own price is the yardstick, so
  /// a ₹16 jodi on a ₹130 stock reads very differently from one on ₹1,000.
  /// Blank when the price is missing: never a 0 the user would act on.
  String _pctOfPrice(double? premium) {
    final pct = premiumPctOfPrice(premium, row.ltp);
    return pct == null ? '—' : '${pct.toStringAsFixed(2)}% of price';
  }

  /// The same number as a [double] — the strangle block needs the ratio.
  double? get _jodiValue {
    final ce = livePremiums['CE'] ?? row.ce?.ltp;
    final pe = livePremiums['PE'] ?? row.pe?.ltp;
    if (ce == null || pe == null) return null;
    return ce + pe;
  }

  /// The OTM jodi (today's or kal wala) with live premiums folded in — the
  /// frozen scan values are the fallback, exactly like the ATM legs.
  StudyStrangle? _strangle({bool kal = false}) {
    final base = kal ? row.kalStrangle : row.strangle;
    if (base == null) return null;
    final live = kal ? liveKalStrangle : liveStrangle;
    return StudyStrangle(
      ce: _withLive(base.ce, live['CE']),
      pe: _withLive(base.pe, live['PE']),
      targetPremium: base.targetPremium,
    );
  }

  StudyOptionLeg? _withLive(StudyOptionLeg? leg, double? live) {
    if (leg == null) return null;
    return live == null ? leg : leg.copyWith(ltp: live);
  }

  // -------------------------------------------------------------------------
  // Blocks
  // -------------------------------------------------------------------------

  /// One CE/PE leg in its own box: LTP is the value, IV (and the live tick)
  /// is the quiet sub line. The broker symbol (RELIANCE26JAN2650CE) stays out
  /// — the expiry sits on the Strike box, not on every leg.
  Widget _legBox(
      BuildContext context, StudyOptionLeg? leg, String label, double? live) {
    if (leg == null) {
      return MetricBox(label: label, value: '—', tooltip: 'Is leg ka data nahi');
    }
    return MetricBox(
      label: label,
      value: 'LTP ${StudyExportService.money(leg.ltp)}',
      sub: live == null
          ? 'IV ${StudyExportService.perc(leg.iv)}'
          : 'IV ${StudyExportService.perc(leg.iv)} · live ₹${live.toStringAsFixed(2)}',
      tooltip: '$label leg ka LTP aur implied volatility',
    );
  }

  /// "6 · OTM jodi (strangle)" — the legs, the pair price and how it compares
  /// with the ATM jodi. A missing pair is explained, never left blank.
  List<Widget> _strangleBlock(
    BuildContext context,
    ColorScheme scheme,
    MarketColors colors,
  ) {
    final strangle = _strangle();
    if (strangle == null || !strangle.isComplete) {
      return [
        Text(
          row.atmStrike == null
              ? 'Is stock ke options ka data nahi mila (degraded mode).'
              : 'Is stock ki OTM jodi nahi ban payi — chain me upar/niche '
                  'strike nahi mile, ya OTM premium ka quote nahi aaya.',
          style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant),
        ),
      ];
    }

    final ce = strangle.ce!;
    final pe = strangle.pe!;
    final total = strangle.total!;
    final atm = _jodiValue;

    return [
      MetricGrid(
        children: [
          MetricBox(
            emoji: '📈',
            label: 'CE (upar)',
            value: StudyExportService.money(ce.strike, decimals: 0),
            sub: 'strike · LTP ${StudyExportService.money(ce.ltp)}',
            tooltip: 'OTM call leg — strike aur LTP',
          ),
          MetricBox(
            emoji: '📉',
            label: 'PE (niche)',
            value: StudyExportService.money(pe.strike, decimals: 0),
            sub: 'strike · LTP ${StudyExportService.money(pe.ltp)}',
            tooltip: 'OTM put leg — strike aur LTP',
          ),
          MetricBox(
            emoji: '🤝',
            label: 'OTM jodi total',
            value: StudyExportService.money(total),
            tooltip: 'OTM jodi (CE+PE) ka kul premium — % of price upar, '
                'section 2 me',
          ),
          if (atm != null && atm > 0)
            MetricBox(
              emoji: '⚖️',
              label: 'ATM jodi se',
              value:
                  '${StudyExportService.perc((total / atm - 1) * 100)} ${total <= atm ? 'sasta' : 'mehnga'}',
              sub: '(ATM ${StudyExportService.money(atm)})',
              valueColor: colors.forValue(atm - total),
              tooltip: 'OTM jodi, ATM jodi se kitni sasti/mehngi hai',
            ),
        ],
      ),
      Padding(
        padding: const EdgeInsets.only(top: 6),
        child: Text(
          'Rule: ATM jodi ka aadha '
          '(~${StudyExportService.money(strangle.targetPremium)}) — uske sabse '
          'najdik wala OTM pair (upar CE, niche PE).',
          style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
        ),
      ),
    ];
  }

  /// "8 · Agar kal (ATM) jodi buy ki hoti" — the observation block.
  List<Widget> _kalAtmBlock(
    BuildContext context,
    ColorScheme scheme,
    MarketColors colors,
  ) {
    final kal = _kalJodi(context, row);
    if (kal == null) {
      return [
        Text(
          row.kalStrike == null && row.ce != null
              ? 'Is snapshot me kal wale ATM strike ka data nahi hai — '
                  'scan dobara chalao.'
              : 'Kal ka premium close nahi mila, is liye ye hisaab nahi '
                  'ban saka.',
          style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant),
        ),
      ];
    }
    return [
      Row(
        children: [
          Icon(
            kal.points >= 0
                ? Icons.trending_up_rounded
                : Icons.trending_down_rounded,
            size: 18,
            color: colors.forValue(kal.points),
          ),
          const SizedBox(width: 6),
          Text(
            StudyExportService.pnlWords(kal.rupees),
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w800,
              color: colors.forValue(kal.points),
            ),
          ),
        ],
      ),
      const SizedBox(height: 4),
      Text(
        'ATM ${StudyExportService.money(row.kalStrike, decimals: 0)} '
        'jodi kal ${StudyExportService.money(row.kalCe?.previousClose)} + '
        '${StudyExportService.money(row.kalPe?.previousClose)} = '
        '${StudyExportService.money(kal.base)} '
        'thi, aaj ${StudyExportService.money(kal.now)} '
        'hai · ${StudyExportService.pointsWords(kal.points)} '
        '× lot ${row.lotSize}',
        style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
      ),
      const SizedBox(height: 4),
      Text(
        'ye sirf observation hai — study suggestion nahi.',
        style: TextStyle(
          fontSize: 10.5,
          fontStyle: FontStyle.italic,
          color: scheme.onSurfaceVariant,
        ),
      ),
    ];
  }

  /// "9 · Agar kal OTM jodi buy ki hoti" — same question, OTM pair.
  List<Widget> _kalStrangleBlock(
    BuildContext context,
    ColorScheme scheme,
    MarketColors colors,
  ) {
    final strangle = _strangle(kal: true);
    if (strangle == null || !strangle.hasYesterday) {
      return [
        Text(
          row.kalStrangle == null
              ? 'Kal wale OTM pair ka data nahi mila — scan dobara chalao.'
              : 'Kal ka premium close nahi mila, is liye ye hisaab nahi ban '
                  'saka.',
          style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant),
        ),
      ];
    }

    final pnl = strangle.yesterday(row.lotSize)!;
    return [
      Row(
        children: [
          Icon(
            pnl.points >= 0
                ? Icons.trending_up_rounded
                : Icons.trending_down_rounded,
            size: 18,
            color: colors.forValue(pnl.points),
          ),
          const SizedBox(width: 6),
          Text(
            StudyExportService.pnlWords(pnl.rupees),
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w800,
              color: colors.forValue(pnl.points),
            ),
          ),
        ],
      ),
      const SizedBox(height: 4),
      Text(
        'OTM jodi '
        '(${StudyExportService.money(strangle.ce!.strike, decimals: 0)} CE + '
        '${StudyExportService.money(strangle.pe!.strike, decimals: 0)} PE) '
        'kal ${StudyExportService.money(strangle.buyCost)} thi, aaj '
        '${StudyExportService.money(strangle.total)} hai · '
        '${StudyExportService.pointsWords(pnl.points)} × lot ${row.lotSize}',
        style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
      ),
      const SizedBox(height: 4),
      Text(
        'ye sirf observation hai — study suggestion nahi.',
        style: TextStyle(
          fontSize: 10.5,
          fontStyle: FontStyle.italic,
          color: scheme.onSurfaceVariant,
        ),
      ),
    ];
  }

  /// "Last result kab aaya, next kab aayega" — the one line the user asked to
  /// see next to the company's study numbers.
  List<Widget> _resultsBlock(BuildContext context, ColorScheme scheme) {
    final info = earnings;

    if (info == null || info.isEmpty) {
      return [
        Text(
          earningsLoading
              ? 'Results dates aa rahi hain…'
              : (earningsNote ??
                  'Is stock ki results date NSE feed me nahi mili '
                      '(chhote stocks ka data wahan der se aata hai).'),
          style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant),
        ),
      ];
    }

    final last = info.lastDate;
    // Only an announced date. (A row cached by build ≤ 1.5.12 can still carry
    // a guessed "next" — the app does not print guesses any more.)
    final next = info.announcedNext;
    final today = DateTime.now();
    final out = <Widget>[];

    if (last != null) {
      final daysAgo = DateTime(today.year, today.month, today.day)
          .difference(DateTime(last.year, last.month, last.day))
          .inDays;
      out.add(MetricBox(
        emoji: '📆',
        label: 'Last result',
        value: '${Fmt.date(last)}${info.lastLabel.isEmpty ? '' : ' · ${info.lastLabel}'}',
        sub: daysAgo >= 0 ? '($daysAgo din pehle)' : null,
        tooltip: 'Pichhli baar result kab aaya tha',
      ));
    }

    if (next != null) {
      final daysAway = DateTime(next.year, next.month, next.day)
          .difference(DateTime(today.year, today.month, today.day))
          .inDays;
      out.add(MetricBox(
        emoji: '⏳',
        label: 'Next result',
        value: Fmt.date(next),
        sub:
            '${daysAway >= 0 ? '$daysAway din baaki · ' : ''}${info.nextConfirmed ? 'board meeting confirm' : info.nextLabel}',
        tooltip: 'Agli result ki date',
      ));
    }

    if (out.isEmpty) {
      out.add(Text(
        'NSE feed ne is stock ke liye date nahi di.',
        style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant),
      ));
    }
    // Note grid ke bahar — grid me sirf boxes (row-wise equal height).
    final note = (earningsNote == null || earningsNote!.isEmpty)
        ? null
        : Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(
              earningsNote!,
              style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
            ),
          );
    final boxed = [for (final w in out) if (w is MetricBox) w];
    if (boxed.isEmpty) return out;
    return [
      MetricGrid(children: boxed),
      if (note != null) note,
    ];
  }

  /// The "agar kal jodi buy ki hoti" numbers, computed from the **kal wale ATM
  /// strike** — buy value = that pair's previous close, current value = today's
  /// premium of the same two contracts (live tick wins when it is subscribed).
  ({double base, double now, double points, double rupees})? _kalJodi(
    BuildContext context,
    StudyRow row,
  ) {
    final ce = row.kalCe;
    final pe = row.kalPe;
    if (ce == null || pe == null) return null;
    if (!ce.hasClose || !pe.hasClose) return null;

    // Live ticks arrive under 'CE'/'PE' for whichever pair is subscribed; when
    // the pair is the same contract for both (a flat stock) the two maps hold
    // the same numbers. Compare *tokens*, not strike doubles — two `double`s
    // that print the same can still differ in the last bit.
    final sameStrike = row.kalCe?.token == row.ce?.token &&
        row.kalPe?.token == row.pe?.token;
    double? liveOf(String key) => sameStrike
        ? (livePremiums[key] ?? liveKalPremiums[key])
        : liveKalPremiums[key];

    final nowCe = liveOf('CE') ?? ce.ltp;
    final nowPe = liveOf('PE') ?? pe.ltp;
    if (nowCe == null || nowPe == null) return null;

    final base = ce.previousClose! + pe.previousClose!;
    final now = nowCe + nowPe;
    final points = now - base;
    return (base: base, now: now, points: points, rupees: points * row.lotSize);
  }
}

/// A study-panel section: emoji marker + the exact spec title (kept stable so
/// Read Me/export wording keeps matching) + a tooltip with the plain meaning.
class _PanelSection extends StatelessWidget {
  const _PanelSection({
    required this.title,
    required this.children,
    this.emoji = '',
    this.tooltip,
  });

  final String title;
  final String emoji;
  final String? tooltip;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final header = Row(
      children: [
        if (emoji.isNotEmpty) ...[
          Text(emoji, style: const TextStyle(fontSize: 11.5)),
          const SizedBox(width: 5),
        ],
        Expanded(
          child: Text(
            title.toUpperCase(),
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.7,
              color: scheme.primary,
            ),
          ),
        ),
      ],
    );
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (tooltip == null || tooltip!.isEmpty)
            header
          else
            Tooltip(message: tooltip!, child: header),
          const SizedBox(height: 6),
          ...children,
        ],
      ),
    );
  }
}

Color _trendColorOf(MarketColors colors, Trend3M trend) => switch (trend) {
      Trend3M.strongUp => colors.gain,
      Trend3M.up => colors.gain,
      Trend3M.sideways => colors.flat,
      Trend3M.down => colors.loss,
      Trend3M.strongDown => colors.loss,
    };
