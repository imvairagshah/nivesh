// ---------------------------------------------------------------------------
// fno_study_screen.dart — the "3-Month Study" tool (F&O module, tool #1).
//
// Screen order follows how the numbers are actually used:
//
//   1. status banner   — kaunse din ka study hai, kitne stocks, kitne degraded
//   2. scan bar        — Scan / Rok do with a stage-wise progress + ETA
//   3. controls        — search, filter chips, sort
//   4. table           — 🎯 best-buys first, then score; every row expands into
//                        the detail panel with the option maths explained
//
// Everything the study produces is frozen: the table does not move while the
// detail panel is open, and the only live element is the expanded stock's ATM
// premium line (spec §3.1.1 + §3.4).
// ---------------------------------------------------------------------------

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/widgets/motion.dart';
import '../../../data/local/dao/settings_dao.dart';
import '../../../services/scrip_master_service.dart';
import '../../settings/settings_provider.dart';
import '../study/fno_study_provider.dart';
import '../study/iv_sheet_link.dart';
import '../study/study_delivery.dart';
import '../study/study_export.dart';
import '../study/study_widgets.dart';
import 'ai_jodi_screen.dart';
import '../../../services/stock_suggestion_service.dart';
import '../news/news_provider.dart';
import '../news/news_screen.dart';
import '../../magic_formula/magic_basket_provider.dart';
import '../../../data/local/dao/fno_contract_dao.dart';

class FnoStudyScreen extends StatefulWidget {
  const FnoStudyScreen({super.key});

  @override
  State<FnoStudyScreen> createState() => _FnoStudyScreenState();
}

class _FnoStudyScreenState extends State<FnoStudyScreen> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Cached snapshot + universe resolution; never a scan on open.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final provider = context.read<FnoStudyProvider>();
      provider.bootstrap();
      // IVP/IVR sheet (1.5.57) — shared cache, Settings me save ki hui link.
      refreshIvSheetIfPossible(context);
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<FnoStudyProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('3-Month Study'),
        actions: [
          IconButton(
            tooltip: 'Read Me',
            icon: const Icon(Icons.help_outline_rounded),
            onPressed: () => showStudyReadMe(context),
          ),
          PopupMenuButton<StudyExportKind>(
            tooltip: 'Export',
            icon: const Icon(Icons.ios_share_rounded),
            onSelected: (kind) => _export(context, kind),
            itemBuilder: (_) => [
              for (final kind in StudyExportKind.values)
                PopupMenuItem<StudyExportKind>(
                  value: kind,
                  child: Row(
                    children: [
                      Icon(_exportIcon(kind), size: 17),
                      const SizedBox(width: 10),
                      Text(kind.label),
                    ],
                  ),
                ),
            ],
          ),
          PopupMenuButton<String>(
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'rescan', child: Text('Dobara scan karo')),
              PopupMenuItem(value: 'ai_jodi', child: Text('AI Jodi Study (naya)')),
              PopupMenuItem(value: 'news', child: Text('News (naya)')),
              PopupMenuItem(value: 'skips', child: Text('Skip huye stocks')),
              PopupMenuItem(
                value: 'clear',
                child: Text('Snapshot hatao (cache clear)'),
              ),
            ],
            onSelected: (value) async {
              if (value == 'rescan') {
                refreshIvSheetIfPossible(context);
                await context.read<FnoStudyProvider>().scan();
              } else if (value == 'ai_jodi') {
                await Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => const AiJodiScreen(),
                  ),
                );
              } else if (value == 'news') {
                final study = context.read<FnoStudyProvider>();
                final settings = context.read<SettingsDao>();
                final suggestions = context.read<StockSuggestionService>();
                final baskets = context.read<MagicBasketProvider>();
                final contracts = context.read<FnoContractDao>();
                if (!context.mounted) return;
                await Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => ChangeNotifierProvider<NewsProvider>(
                      create: (_) => buildNewsProvider(
                        study: study,
                        settings: settings,
                        suggestions: suggestions,
                        baskets: baskets,
                        contracts: contracts,
                      )..loadChannels(),
                      child: const NewsScreen(),
                    ),
                  ),
                );
              } else if (value == 'skips') {
                if (!context.mounted) return;
                await showStudySkips(
                  context,
                  context.read<FnoStudyProvider>().skips,
                );
              } else if (value == 'clear') {
                await context.read<FnoStudyProvider>().clearSnapshot();
              }
            },
          ),
        ],
      ),
      body: Column(
        children: [
          _StatusBanner(provider: provider),
          _ScanBar(provider: provider),
          if (provider.error != null) _ErrorStrip(message: provider.error!),
          _Controls(
            provider: provider,
            controller: _searchController,
            onSearch: (value) => provider.setQuery(value),
          ),
          const Divider(height: 1),
          Expanded(
            child: provider.rows.isEmpty
                ? _EmptyState(provider: provider)
                : _StudyTable(provider: provider),
          ),
        ],
      ),
    );
  }

  IconData _exportIcon(StudyExportKind kind) => switch (kind) {
    StudyExportKind.whatsapp => Icons.chat_bubble_outline_rounded,
    StudyExportKind.excel => Icons.grid_on_rounded,
    StudyExportKind.csv => Icons.description_outlined,
    StudyExportKind.telegram => Icons.send_rounded,
  };

  Future<void> _export(BuildContext context, StudyExportKind kind) async {
    final provider = context.read<FnoStudyProvider>();
    final messenger = ScaffoldMessenger.of(context);
    final settings = context.read<SettingsProvider>();
    final outcome = await StudyDeliveryService(export: StudyExportService())
        .deliver(
          kind: kind,
          rows: provider.rows,
          meta: provider.exportMeta,
          settings: settings.settings,
        );
    messenger.showSnackBar(
      SnackBar(
        content: Text(outcome.message),
        backgroundColor: outcome.ok
            ? null
            : Theme.of(context).colorScheme.error,
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Status banner
// ---------------------------------------------------------------------------

class _StatusBanner extends StatelessWidget {
  const _StatusBanner({required this.provider});

  final FnoStudyProvider provider;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final colors = MarketColors.of(context);
    final result = provider.result;

    if (result == null) {
      return Container(
        width: double.infinity,
        color: scheme.primaryContainer.withOpacity(0.4),
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        child: const Text(
          'F&O 3-Month Study: har F&O stock ka 3 mahine ka trend, ATR, high/low '
          'se doori aur ATM option ka IV — ek table me. Stock expiry select '
          'karke Scan dabao.',
          style: TextStyle(fontSize: 12, height: 1.35),
        ),
      );
    }

    final stale = result.isStaleFor(DateTime.now());
    final liveNote = provider.liveFeedActive
        ? 'live feed chalu'
        : 'live feed band (Settings)';

    return Container(
      width: double.infinity,
      color: scheme.primaryContainer.withOpacity(0.4),
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.insights_rounded, size: 16, color: scheme.primary),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Study: ${Fmt.date(result.asOf)} · ${result.scanned} stocks · '
                  'expiry ${Fmt.date(provider.resultExpiry)}',
                  style: const TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              if (stale)
                Chip(
                  label: const Text('purani', style: TextStyle(fontSize: 10)),
                  backgroundColor: colors.stale.withOpacity(0.15),
                  side: BorderSide(color: colors.stale.withOpacity(0.4)),
                  visualDensity: VisualDensity.compact,
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            '${provider.statusLine} · ${result.scanned} scan hue · '
            'IV broker se ${result.ivFromBroker}, premium se '
            '${result.ivFromBlackScholes} · $liveNote',
            style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
          ),
          if (provider.unresolvedCount > 0)
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      provider.universeLine,
                      style: TextStyle(fontSize: 10.5, color: colors.stale),
                    ),
                  ),
                  TextButton(
                    onPressed: provider.isSyncingMaster
                        ? null
                        : () => context
                              .read<FnoStudyProvider>()
                              .refreshMasterNow(),
                    style: TextButton.styleFrom(
                      visualDensity: VisualDensity.compact,
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                    ),
                    child: const Text(
                      'Master update karo',
                      style: TextStyle(fontSize: 10.5),
                    ),
                  ),
                ],
              ),
            ),
          if (provider.masterNote != null)
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Text(
                provider.masterNote!,
                style: TextStyle(
                  fontSize: 10.5,
                  color: scheme.onSurfaceVariant,
                  fontStyle: FontStyle.italic,
                ),
              ),
            ),
          if (provider.selectedExpiry != null &&
              provider.resultExpiry != null &&
              !provider.resultMatchesSelectedExpiry)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                'Table ${Fmt.date(provider.resultExpiry)} expiry ka hai; '
                'selected ${Fmt.date(provider.selectedExpiry)} hai. Naye expiry '
                'data ke liye Scan dabao.',
                style: TextStyle(fontSize: 10.5, color: colors.stale),
              ),
            ),
          if (stale)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                'Ye snapshot pichhle din ka hai — aaj ke rate ke liye dobara '
                'scan karo.',
                style: TextStyle(fontSize: 10.5, color: colors.stale),
              ),
            ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Stock-expiry picker
// ---------------------------------------------------------------------------

/// Monthly stock-option expiry selector used by the 3-Month Study scan bar.
class StudyExpiryPicker extends StatefulWidget {
  const StudyExpiryPicker({super.key, required this.provider});

  final FnoStudyProvider provider;

  @override
  State<StudyExpiryPicker> createState() => _StudyExpiryPickerState();
}

class _StudyExpiryPickerState extends State<StudyExpiryPicker> {
  bool _opening = false;

  Future<void> _open() async {
    final provider = widget.provider;
    if (_opening || provider.isRunning || provider.isSyncingMaster) return;

    final field = context.findRenderObject();
    final overlay = Navigator.of(context).overlay?.context.findRenderObject();
    if (field is! RenderBox || overlay is! RenderBox) return;
    final topLeft = field.localToGlobal(Offset.zero, ancestor: overlay);
    final position = RelativeRect.fromRect(
      Rect.fromLTWH(
        topLeft.dx,
        topLeft.dy,
        field.size.width,
        field.size.height,
      ),
      Offset.zero & overlay.size,
    );

    _opening = true;
    try {
      // If the local book has only the current expiry (or none), refresh the
      // scrip master first. This path never starts a study scan.
      await provider.prepareExpiryPicker();
      if (!mounted) return;
      if (provider.isSyncingMaster) {
        _showMessage(
          'Master update chal raha hai; complete hone par dobara tap karo.',
        );
        return;
      }

      final options = provider.expiryOptions;
      if (options.isEmpty) {
        _showMessage(
          provider.masterNote ??
              'Upcoming stock expiry nahi mili. Internet check karke dobara tap karo; Study scan nahi chala.',
        );
        return;
      }

      final selected = await showMenu<DateTime>(
        context: context,
        position: position,
        initialValue: provider.selectedExpiry,
        items: [
          for (final expiry in options)
            CheckedPopupMenuItem<DateTime>(
              value: expiry,
              checked: _sameDate(provider.selectedExpiry, expiry),
              child: Text(Fmt.date(expiry)),
            ),
        ],
      );
      if (!mounted || selected == null) return;
      provider.selectExpiry(selected);
    } catch (error) {
      if (mounted) {
        _showMessage(
          'Expiry list update fail hui ($error). Study scan nahi chala.',
        );
      }
    } finally {
      _opening = false;
    }
  }

  bool _sameDate(DateTime? left, DateTime right) =>
      left != null &&
      left.year == right.year &&
      left.month == right.month &&
      left.day == right.day;

  void _showMessage(String message) {
    ScaffoldMessenger.maybeOf(
      context,
    )?.showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final provider = widget.provider;
    final scheme = Theme.of(context).colorScheme;
    final enabled = !provider.isRunning && !provider.isSyncingMaster;
    final selected = provider.selectedExpiry;
    final label = selected == null
        ? (provider.isLoadingExpiries
              ? 'Expiry dates load ho rahi hain…'
              : 'Tap to load upcoming expiries')
        : Fmt.date(selected);

    return Semantics(
      button: true,
      enabled: enabled,
      label: 'Stock expiry (monthly), $label',
      child: InkWell(
        key: const Key('study-expiry-picker'),
        onTap: enabled ? _open : null,
        borderRadius: BorderRadius.circular(10),
        child: InputDecorator(
          isEmpty: false,
          decoration: InputDecoration(
            enabled: enabled,
            isDense: true,
            labelText: 'Stock expiry (monthly)',
            prefixIcon: const Icon(Icons.event_available_rounded),
            suffixIcon: provider.isSyncingMaster
                ? const Padding(
                    padding: EdgeInsets.all(12),
                    child: SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    ),
                  )
                : Icon(
                    Icons.arrow_drop_down_rounded,
                    color: scheme.onSurfaceVariant,
                  ),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
          ),
          child: Text(
            label,
            style: TextStyle(
              fontSize: 14,
              color: enabled ? scheme.onSurface : scheme.onSurfaceVariant,
            ),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Scan bar
// ---------------------------------------------------------------------------

class _ScanBar extends StatelessWidget {
  const _ScanBar({required this.provider});

  final FnoStudyProvider provider;

  /// Progress text of the running scrip-master download (`Settings → Scrip
  /// master` shows the same string).
  static String masterStage(BuildContext context) {
    final master = context.watch<ScripMasterService>();
    final stage = master.stage.trim();
    final pct = (master.progress * 100).clamp(0, 100).toStringAsFixed(0);
    return stage.isEmpty
        ? 'Scrip master update ho raha hai…'
        : '$stage ($pct%)';
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final progress = provider.progress;

    return Container(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      child: Column(
        children: [
          StudyExpiryPicker(provider: provider),
          if (provider.isSyncingMaster)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Expiry master update ho raha hai — Study scan nahi chalega.',
                  style: TextStyle(
                    fontSize: 10.5,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ),
            )
          else if (provider.expiryOptions.length <
              FnoStudyProvider.monthlyExpiryChoiceCount)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  provider.masterNote ??
                      (provider.expiryOptions.isEmpty
                          ? 'Expiry list ke liye field tap karo; Study scan nahi chalega.'
                          : '${provider.expiryOptions.length}/3 monthly stock expiries available; field tap karke master update karo.'),
                  style: TextStyle(
                    fontSize: 10.5,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ),
            ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: provider.isRunning || provider.isSyncingMaster
                      ? null
                      : () {
                          refreshIvSheetIfPossible(context);
                          context.read<FnoStudyProvider>().scan();
                        },
                  icon: Icon(
                    provider.isRunning || provider.isSyncingMaster
                        ? Icons.sync_rounded
                        : Icons.play_arrow_rounded,
                  ),
                  label: Text(
                    provider.isRunning
                        ? 'Scan chal raha hai…'
                        : (provider.isSyncingMaster
                              ? 'Expiry list update ho rahi hai…'
                              : provider.scanButtonLabel),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              if (provider.isRunning)
                OutlinedButton.icon(
                  onPressed: () => context.read<FnoStudyProvider>().cancel(),
                  icon: const Icon(Icons.stop_rounded, size: 18),
                  label: const Text('Rok do'),
                )
              else
                OutlinedButton.icon(
                  onPressed: provider.skips.isEmpty
                      ? null
                      : () => showStudySkips(context, provider.skips),
                  icon: const Icon(
                    Icons.report_gmailerrorred_rounded,
                    size: 18,
                  ),
                  label: Text('Skip (${provider.skips.length})'),
                ),
            ],
          ),
          if (provider.isSyncingMaster) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                const SizedBox(
                  width: 13,
                  height: 13,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    masterStage(context),
                    style: TextStyle(
                      fontSize: 11,
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
                ),
              ],
            ),
          ],
          if (provider.isRunning) ...[
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(999),
              child: LinearProgressIndicator(
                value: progress?.fraction.clamp(0.0, 1.0),
                minHeight: 6,
                backgroundColor: scheme.surfaceContainerHighest,
              ),
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                Expanded(
                  child: Text(
                    progress?.label ?? 'Shuru ho raha hai…',
                    style: TextStyle(
                      fontSize: 11,
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
                ),
                if ((progress?.eta.inSeconds ?? 0) > 3)
                  Text(
                    '~${_eta(progress!.eta)} baki',
                    style: TextStyle(
                      fontSize: 11,
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
              ],
            ),
          ] else if (provider.hasResult) ...[
            const SizedBox(height: 6),
            Row(
              children: [
                Expanded(
                  child: Text(
                    '${provider.result!.duration.inSeconds}s me poori study · '
                    'universe ${provider.result!.universeSize} me se '
                    '${provider.result!.scanned} scan hue',
                    style: TextStyle(
                      fontSize: 10.5,
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
                ),
                if (provider.skips.isNotEmpty)
                  Text(
                    '${provider.skips.length} skip',
                    style: TextStyle(
                      fontSize: 10.5,
                      color: MarketColors.of(context).stale,
                    ),
                  ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  static String _eta(Duration duration) {
    if (duration.inMinutes >= 1) {
      return '${duration.inMinutes} min';
    }
    return '${duration.inSeconds}s';
  }
}

class _ErrorStrip extends StatelessWidget {
  const _ErrorStrip({required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      color: scheme.errorContainer.withOpacity(0.55),
      padding: const EdgeInsets.fromLTRB(14, 8, 14, 8),
      child: Row(
        children: [
          Icon(Icons.error_outline_rounded, size: 16, color: scheme.error),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              message,
              style: TextStyle(fontSize: 11.5, color: scheme.onErrorContainer),
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Search / filter / sort
// ---------------------------------------------------------------------------

class _Controls extends StatelessWidget {
  const _Controls({
    required this.provider,
    required this.controller,
    required this.onSearch,
  });

  final FnoStudyProvider provider;
  final TextEditingController controller;
  final ValueChanged<String> onSearch;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final hasResult = provider.hasResult;

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
          child: Row(
            children: [
              Expanded(
                child: SizedBox(
                  height: 40,
                  child: TextField(
                    controller: controller,
                    enabled: hasResult,
                    onChanged: onSearch,
                    textInputAction: TextInputAction.search,
                    decoration: InputDecoration(
                      isDense: true,
                      hintText: 'Stock, company ya trend search karo',
                      hintStyle: const TextStyle(fontSize: 12.5),
                      prefixIcon: const Icon(Icons.search_rounded, size: 18),
                      suffixIcon: provider.query.isEmpty
                          ? null
                          : IconButton(
                              icon: const Icon(Icons.close_rounded, size: 16),
                              onPressed: () {
                                controller.clear();
                                onSearch('');
                              },
                            ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 8,
                      ),
                    ),
                    style: const TextStyle(fontSize: 13),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              if (provider.sortIsUserChoice)
                IconButton(
                  tooltip: 'Default: 🎯 pehle, phir score',
                  visualDensity: VisualDensity.compact,
                  onPressed: () => context.read<FnoStudyProvider>().resetSort(),
                  icon: const Icon(Icons.restart_alt_rounded, size: 18),
                ),
              PopupMenuButton<StudySort>(
                tooltip: 'Sort',
                onSelected: (column) =>
                    context.read<FnoStudyProvider>().sortBy(column),
                itemBuilder: (_) => [
                  for (final column in StudySort.values)
                    PopupMenuItem<StudySort>(
                      value: column,
                      child: Row(
                        children: [
                          if (provider.sort == column)
                            Icon(
                              Icons.check_rounded,
                              size: 16,
                              color: scheme.primary,
                            )
                          else
                            const SizedBox(width: 16),
                          const SizedBox(width: 8),
                          Text(column.label),
                        ],
                      ),
                    ),
                ],
                child: Container(
                  height: 40,
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: scheme.outlineVariant),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.sort_rounded,
                        size: 16,
                        color: scheme.onSurfaceVariant,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        provider.sort.label,
                        style: const TextStyle(fontSize: 12),
                      ),
                      Icon(
                        provider.sortDescending
                            ? Icons.arrow_downward_rounded
                            : Icons.arrow_upward_rounded,
                        size: 13,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          height: 34,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            itemCount: StudyFilter.values.length,
            separatorBuilder: (_, __) => const SizedBox(width: 6),
            itemBuilder: (context, index) {
              final filter = StudyFilter.values[index];
              final selected = provider.filter == filter;
              return ChoiceChip(
                label: Text(
                  filter.label,
                  style: const TextStyle(fontSize: 11.5),
                ),
                selected: selected,
                onSelected: (_) =>
                    context.read<FnoStudyProvider>().setFilter(filter),
                visualDensity: VisualDensity.compact,
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                showCheckmark: false,
              );
            },
          ),
        ),
        const SizedBox(height: 6),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Table
// ---------------------------------------------------------------------------

class _StudyTable extends StatelessWidget {
  const _StudyTable({required this.provider});

  final FnoStudyProvider provider;

  @override
  Widget build(BuildContext context) {
    final rows = provider.rows;
    final scheme = Theme.of(context).colorScheme;

    return Column(
      children: [
        _TableHeader(provider: provider),
        Divider(height: 1, color: scheme.outlineVariant.withOpacity(0.5)),
        Expanded(
          child: ListView.separated(
            padding: const EdgeInsets.only(bottom: 24),
            itemCount: rows.length,
            separatorBuilder: (_, __) => Divider(
              height: 1,
              color: scheme.outlineVariant.withOpacity(0.35),
            ),
            itemBuilder: (context, index) {
              final row = rows[index];
              final expanded = provider.expandedSymbol == row.symbol;
              return Column(
                children: [
                  FadeSlideIn(
                    index: index,
                    child: StudyRowTile(
                      row: row,
                      expanded: expanded,
                      // The feed only carries the open row, so the card gets
                      // live numbers exactly when it is the one open.
                      livePremiums: expanded ? provider.livePremiums : null,
                      liveStrangle: expanded ? provider.liveStrangle : null,
                      onTap: () {
                        final provider = context.read<FnoStudyProvider>();
                        // Opening a stock is also the moment to have its
                        // results dates ready — cache first, NSE at most once
                        // a day (fire-and-forget: the panel renders without it).
                        unawaited(provider.ensureEarnings());
                        provider.toggleExpanded(row);
                      },
                    ),
                  ),
                  if (expanded)
                    StudyDetailPanel(
                      row: row,
                      livePremiums: provider.livePremiums,
                      liveKalPremiums: provider.liveKalPremiums,
                      liveStrangle: provider.liveStrangle,
                      liveKalStrangle: provider.liveKalStrangle,
                      liveFeedActive: provider.liveFeedActive,
                      earnings: provider.earningsFor(row.symbol),
                      earningsNote: provider.earningsNote,
                      earningsLoading: provider.isLoadingEarnings,
                      onClose: () =>
                          context.read<FnoStudyProvider>().collapse(),
                    ),
                ],
              );
            },
          ),
        ),
      ],
    );
  }
}

class _TableHeader extends StatelessWidget {
  const _TableHeader({required this.provider});

  final FnoStudyProvider provider;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      color: scheme.surfaceContainerHighest.withOpacity(0.45),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      child: Row(
        children: [
          const SizedBox(width: 26),
          Expanded(
            child: _HeaderButton(
              label: 'Stock',
              active: provider.sort == StudySort.symbol,
              descending: provider.sortDescending,
              onTap: () =>
                  context.read<FnoStudyProvider>().sortBy(StudySort.symbol),
            ),
          ),
          _HeaderButton(
            label: 'Score',
            active: provider.sort == StudySort.score,
            descending: provider.sortDescending,
            onTap: () =>
                context.read<FnoStudyProvider>().sortBy(StudySort.score),
          ),
          const SizedBox(width: 10),
          _HeaderButton(
            label: 'Edge %',
            active: provider.sort == StudySort.edge,
            descending: provider.sortDescending,
            onTap: () =>
                context.read<FnoStudyProvider>().sortBy(StudySort.edge),
          ),
          const SizedBox(width: 12),
          _HeaderButton(
            label: 'Price',
            active: provider.sort == StudySort.ltp,
            descending: provider.sortDescending,
            onTap: () => context.read<FnoStudyProvider>().sortBy(StudySort.ltp),
          ),
        ],
      ),
    );
  }
}

class _HeaderButton extends StatelessWidget {
  const _HeaderButton({
    required this.label,
    required this.active,
    required this.descending,
    required this.onTap,
  });

  final String label;
  final bool active;
  final bool descending;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(6),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              label,
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: active ? scheme.primary : scheme.onSurfaceVariant,
              ),
            ),
            if (active)
              Icon(
                descending
                    ? Icons.arrow_downward_rounded
                    : Icons.arrow_upward_rounded,
                size: 12,
                color: scheme.primary,
              ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Empty state
// ---------------------------------------------------------------------------

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.provider});

  final FnoStudyProvider provider;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final resolved = provider.universe.size;
    final total = provider.scanTargetCount;
    final hasFilter = provider.hasResult && provider.allRows.isNotEmpty;

    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 28),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.query_stats_rounded, size: 42, color: scheme.primary),
            const SizedBox(height: 14),
            Text(
              hasFilter
                  ? 'Is filter/search me koi stock nahi mila'
                  : 'Abhi koi study nahi hai',
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            Text(
              hasFilter
                  ? 'Filter "Sab" karke ya search hata ke dobara dekho.'
                  : 'Scan dabao — poore $total F&O stocks ka 3 mahine ka study '
                        'banega. Candles cache se aate hain; pehli baar ~1.5 min '
                        'lagta hai.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12,
                height: 1.4,
                color: scheme.onSurfaceVariant,
              ),
            ),
            if (!hasFilter) ...[
              const SizedBox(height: 10),
              Text(
                provider.isResolvingUniverse
                    ? 'F&O list resolve ho rahi hai…'
                    : (resolved >= total
                          ? '$total F&O stocks taiyar hain'
                          : (resolved == 0
                                ? 'List ke $total stocks abhi resolve nahi hue — '
                                      'scan dabao, app khud broker se master update '
                                      'kar ke poore $total le aayega.'
                                : '$resolved of $total resolve hue — scan dabao, '
                                      'master update karke poore $total ho jayenge.')),
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 11,
                  color: resolved == 0
                      ? MarketColors.of(context).stale
                      : scheme.onSurfaceVariant,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
