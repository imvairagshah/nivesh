// ---------------------------------------------------------------------------
// strangle.dart — the OTM jodi: ek CE upar, ek PE niche, dono ATM ke bahar.
//
// The user's rule, in their words: "ATM CE+PE/2 ki sabse najdik jo strike hai
// wo wali" — the pair whose **combined premium** is closest to half of what the
// ATM jodi costs. (That is the usual reason to go OTM in the first place: same
// expiry, roughly half the premium, break-evens further out.)
//
// Choosing it needs a premium for every candidate strike, and the broker only
// quotes what we ask it for. So candidates are priced with Black-Scholes at the
// row's own ATM IV — an estimate used **only to rank** the pairs — and just the
// winning pair is quoted for real. The number the user finally sees is the
// broker's, not the model's.
//
// Everything here is pure (no network, no database), so the rule is pinned by
// tests: symmetric pairing, OTM-only, nearest-to-target, and "no answer" when
// the chain or the inputs cannot support one.
// ---------------------------------------------------------------------------

import 'dart:math' as math;

import 'black_scholes.dart' show BsInput, OptionType, blackScholesPrice;
import '../../../data/local/dao/fno_contract_dao.dart' show FnoContract;

/// One candidate pair, kept with the estimate it was picked (or rejected) on.
class StranglePick {
  const StranglePick({
    required this.ce,
    required this.pe,
    required this.estimatedPremium,
    required this.targetPremium,
  });

  final FnoContract ce;
  final FnoContract pe;

  /// What Black-Scholes says the pair costs (ranking aid, never displayed).
  final double estimatedPremium;

  /// What the pair was *aiming* for: half the ATM jodi.
  final double targetPremium;

  double get ceStrike => ce.strike;
  double get peStrike => pe.strike;

  @override
  String toString() => 'StranglePick(CE ${ce.strike} + PE ${pe.strike} ≈ '
      '${estimatedPremium.toStringAsFixed(2)} (target '
      '${targetPremium.toStringAsFixed(2)}))';
}

/// Picks the OTM pair whose combined premium is closest to [targetPremium].
///
/// Pairs are built **symmetrically** — the k-th strike above [spot] with the
/// k-th strike below it — which is how a strangle is actually quoted; mixing a
/// near CE with a far PE would not be the trade anyone means.
///
/// Returns null when there is nothing sensible to pick (no OTM strikes on one
/// side, expiry today, no IV, a zero target). A null is a fact, not a failure:
/// the caller shows the stock without an OTM jodi line.
StranglePick? pickStrangle({
  required List<FnoContract> chain,
  required double spot,
  required double ivPercent,
  required int daysToExpiry,
  required double targetPremium,
  int maxSteps = 12,
}) {
  if (spot <= 0 || ivPercent <= 0 || daysToExpiry <= 0 || targetPremium <= 0) {
    return null;
  }

  final calls = <FnoContract>[];
  final puts = <FnoContract>[];
  for (final contract in chain) {
    if (contract.isCall) {
      if (contract.strike > spot) calls.add(contract);
    } else if (contract.strike < spot) {
      puts.add(contract);
    }
  }
  if (calls.isEmpty || puts.isEmpty) return null;

  // Nearest OTM first on both sides.
  calls.sort((a, b) => a.strike.compareTo(b.strike));
  puts.sort((a, b) => b.strike.compareTo(a.strike));

  final steps = math.min(math.min(calls.length, puts.length), maxSteps);
  final years = daysToExpiry / 365.0;
  final volatility = ivPercent / 100.0;

  StranglePick? best;
  var bestGap = double.infinity;

  for (var i = 0; i < steps; i++) {
    final call = calls[i];
    final put = puts[i];
    final estimate = blackScholesPrice(
          OptionType.call,
          BsInput(
            spot: spot,
            strike: call.strike,
            timeToExpiryYears: years,
            volatility: volatility,
          ),
        ) +
        blackScholesPrice(
          OptionType.put,
          BsInput(
            spot: spot,
            strike: put.strike,
            timeToExpiryYears: years,
            volatility: volatility,
          ),
        );

    final gap = (estimate - targetPremium).abs();
    if (gap < bestGap) {
      bestGap = gap;
      best = StranglePick(
        ce: call,
        pe: put,
        estimatedPremium: estimate,
        targetPremium: targetPremium,
      );
    }
  }

  return best;
}
