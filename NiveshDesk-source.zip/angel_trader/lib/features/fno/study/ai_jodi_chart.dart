// ---------------------------------------------------------------------------
// ai_jodi_chart.dart — the AI Jodi Study's tap-through detail: a mini candle
// chart with the jodi's break-even lines drawn on it, plus the "kal jodi buy
// ki hoti" P&L and the IV-rank star. The candles come from the offline bar
// cache (the scan already downloaded them) — never live.
// ---------------------------------------------------------------------------

import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../data/remote/dto/candle.dart';
import '../../../features/fno/study/ai_jodi_engine.dart';
import '../../../features/fno/study/fno_study_provider.dart';
import '../../../features/fno/study/study_engine.dart';

/// The two numbers the chart draws and the sheet labels.
class JodiChartLines {
  const JodiChartLines({
    required this.currentPrice,
    this.beLower,
    this.beUpper,
    this.pairLabel,
  });

  final double currentPrice;
  final double? beLower;
  final double? beUpper;
  final String? pairLabel;
}

/// Break-even lines for the recommended pair (falling back to the ATM pair,
/// then the OTM pair) — pure choice, no maths here beyond the engine's.
JodiChartLines chartLinesFor(StudyRow row, AiJodiVerdict verdict) {
  final price = row.ltp;
  double? lower;
  double? upper;
  String? label;
  final straddlePremium = (row.ce?.ltp != null && row.pe?.ltp != null)
      ? row.ce!.ltp! + row.pe!.ltp!
      : null;
  final stranglePremium = row.strangle?.total;
  final wantAtm = verdict == AiJodiVerdict.atmBuy || verdict == AiJodiVerdict.skip;
  final wantOtm = verdict == AiJodiVerdict.otmBuy || verdict == AiJodiVerdict.skip;

  if (wantAtm && straddlePremium != null && row.atmStrike != null) {
    final be = AiJodiEngine.jodiBreakEvens(
      lowerStrike: row.atmStrike!,
      upperStrike: row.atmStrike!,
      totalPremium: straddlePremium,
    );
    lower = be.lower;
    upper = be.upper;
    label = 'ATM jodi break-even';
  } else if (wantOtm &&
      stranglePremium != null &&
      row.strangle?.pe?.strike != null &&
      row.strangle?.ce?.strike != null) {
    final be = AiJodiEngine.jodiBreakEvens(
      lowerStrike: row.strangle!.pe!.strike,
      upperStrike: row.strangle!.ce!.strike,
      totalPremium: stranglePremium,
    );
    lower = be.lower;
    upper = be.upper;
    label = 'OTM jodi break-even';
  } else if (straddlePremium != null && row.atmStrike != null) {
    final be = AiJodiEngine.jodiBreakEvens(
      lowerStrike: row.atmStrike!,
      upperStrike: row.atmStrike!,
      totalPremium: straddlePremium,
    );
    lower = be.lower;
    upper = be.upper;
    label = 'ATM jodi break-even';
  }
  return JodiChartLines(
    currentPrice: price,
    beLower: lower,
    beUpper: upper,
    pairLabel: label,
  );
}

/// "Kal ye jodi buy ki hoti" P&L — ATM pair and OTM pair, in ₹.
({double? atm, double? otm}) kalPnlFor(StudyRow row) {
  double? pair(
    StudyOptionLeg? ce,
    StudyOptionLeg? pe,
  ) {
    final buyCost = (ce?.previousClose != null && pe?.previousClose != null)
        ? ce!.previousClose! + pe!.previousClose!
        : null;
    final nowValue =
        (ce?.ltp != null && pe?.ltp != null) ? ce!.ltp! + pe!.ltp! : null;
    return AiJodiEngine.kalJodiPnl(buyCost: buyCost, nowValue: nowValue)?.rupees;
  }

  return (
    atm: pair(row.kalCe, row.kalPe),
    otm: AiJodiEngine.kalJodiPnl(
      buyCost: row.kalStrangle?.buyCost,
      nowValue: row.kalStrangle?.total,
    )?.rupees,
  );
}

/// Opens the tap-through detail for one listed stock.
void showAiJodiDetail(
  BuildContext context, {
  required StudyRow row,
  required AiJodiResult result,
}) {
  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (context) => _DetailSheet(row: row, result: result),
  );
}

class _DetailSheet extends StatelessWidget {
  const _DetailSheet({required this.row, required this.result});

  final StudyRow row;
  final AiJodiResult result;

  @override
  Widget build(BuildContext context) {
    final provider = context.read<FnoStudyProvider>();
    final theme = Theme.of(context);
    final verdict = result.verdict;
    final lines = chartLinesFor(row, verdict);
    final kal = kalPnlFor(row);

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${row.symbol} — ${row.companyName}',
              style: theme.textTheme.titleMedium
                  ?.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 4),
            Text(
              'Price ₹${row.ltp.toStringAsFixed(2)} · ATR ₹${row.atr.toStringAsFixed(2)}'
              ' · 15-din avg move ₹${row.avgDailyMove15.toStringAsFixed(2)}'
              ' · Mahine ka move ≈ ₹${result.typicalMoveRupee.toStringAsFixed(0)}',
              style: theme.textTheme.bodySmall,
            ),
            const SizedBox(height: 12),
            FutureBuilder<List<Candle>>(
              future: provider.chartBarsFor(row),
              builder: (context, snapshot) {
                final bars = snapshot.data ?? const <Candle>[];
                if (bars.length < 5) {
                  return Container(
                    height: 180,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      border: Border.all(color: theme.colorScheme.outlineVariant),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text(
                      'Chart ke bars cache me nahi mile — ek baar 3-Month '
                      'Study dobara scan karein.',
                      textAlign: TextAlign.center,
                    ),
                  );
                }
                return SizedBox(
                  height: 210,
                  child: CustomPaint(
                    size: const Size(double.infinity, 210),
                    painter: MiniCandlePainter(
                      bars: bars.length > 70
                          ? bars.sublist(bars.length - 70)
                          : bars,
                      currentPrice: lines.currentPrice,
                      beLower: lines.beLower,
                      beUpper: lines.beUpper,
                      beLabel: lines.pairLabel,
                      upColor: Colors.green.shade600,
                      downColor: Colors.red.shade600,
                      lineColor: theme.colorScheme.primary,
                      labelStyle: theme.textTheme.labelSmall!,
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 12),
            Text(
              verdict.label,
              style: theme.textTheme.titleSmall
                  ?.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 6),
            Text(
              'Kal jodi buy ki hoti: '
              'ATM ${kal.atm == null ? '—' : _signed(kal.atm!)}'
              ' · OTM ${kal.otm == null ? '—' : _signed(kal.otm!)}',
              style: theme.textTheme.bodyMedium,
            ),
            const SizedBox(height: 4),
            Text(
              AiJodiEngine.ivStarLabel(row.ivRank),
              style: theme.textTheme.bodyMedium,
            ),
            if (result.coverAtm != null || result.coverOtm != null) ...[
              const SizedBox(height: 4),
              Text(
                'Movement cover: '
                '${result.coverAtm == null ? 'ATM —' : 'ATM ${result.coverAtm!.toStringAsFixed(1)}×'}'
                ' · '
                '${result.coverOtm == null ? 'OTM —' : 'OTM ${result.coverOtm!.toStringAsFixed(1)}×'}',
                style: theme.textTheme.bodySmall,
              ),
            ],
            const SizedBox(height: 10),
            Text(
              AiJodiRules.disclaimer,
              style: theme.textTheme.labelSmall,
            ),
          ],
        ),
      ),
    );
  }

  String _signed(double value) =>
      '${value >= 0 ? '+' : ''}₹${value.toStringAsFixed(1)}';
}

/// Compact candle painter: candles + current-price line + break-even lines.
class MiniCandlePainter extends CustomPainter {
  MiniCandlePainter({
    required this.bars,
    required this.currentPrice,
    required this.beLower,
    required this.beUpper,
    required this.beLabel,
    required this.upColor,
    required this.downColor,
    required this.lineColor,
    required this.labelStyle,
  });

  final List<Candle> bars;
  final double currentPrice;
  final double? beLower;
  final double? beUpper;
  final String? beLabel;
  final Color upColor;
  final Color downColor;
  final Color lineColor;
  final TextStyle labelStyle;

  @override
  void paint(Canvas canvas, Size size) {
    if (bars.isEmpty) return;
    var lo = bars.first.low;
    var hi = bars.first.high;
    for (final bar in bars) {
      if (bar.low < lo) lo = bar.low;
      if (bar.high > hi) hi = bar.high;
    }
    for (final line in [currentPrice, beLower, beUpper]) {
      if (line == null) continue;
      if (line < lo) lo = line;
      if (line > hi) hi = line;
    }
    final pad = (hi - lo) * 0.06 + 0.01;
    lo -= pad;
    hi += pad;
    double y(double price) =>
        size.height - (price - lo) / (hi - lo) * size.height;

    final slot = size.width / bars.length;
    final bodyWidth = math.max(1.5, slot * 0.62);
    for (var i = 0; i < bars.length; i++) {
      final bar = bars[i];
      final cx = i * slot + slot / 2;
      final paint = Paint()
        ..color = bar.close >= bar.open ? upColor : downColor
        ..strokeWidth = 1;
      canvas.drawLine(
        Offset(cx, y(bar.high)),
        Offset(cx, y(bar.low)),
        paint,
      );
      final top = y(math.max(bar.open, bar.close));
      final bottom = y(math.min(bar.open, bar.close));
      canvas.drawRect(
        Rect.fromLTRB(cx - bodyWidth / 2, top, cx + bodyWidth / 2,
            math.max(bottom, top + 1)),
        paint,
      );
    }

    void dashedLine(double price, Color color, String label) {
      final paint = Paint()
        ..color = color
        ..strokeWidth = 1.2;
      const dash = 6.0;
      var x = 0.0;
      final yy = y(price);
      while (x < size.width) {
        canvas.drawLine(Offset(x, yy), Offset(math.min(x + dash, size.width), yy), paint);
        x += dash * 2;
      }
      final tp = TextPainter(
        text: TextSpan(text: label, style: labelStyle.copyWith(color: color)),
        textDirection: TextDirection.ltr,
      )..layout(maxWidth: size.width * 0.55);
      tp.paint(canvas, Offset(4, yy - tp.height - 2));
    }

    if (beLower != null) dashedLine(beLower!, downColor, 'BE ₹${beLower!.toStringAsFixed(0)}');
    if (beUpper != null) dashedLine(beUpper!, upColor, 'BE ₹${beUpper!.toStringAsFixed(0)}');
    dashedLine(currentPrice, lineColor, 'CMP ₹${currentPrice.toStringAsFixed(0)}');
  }

  @override
  bool shouldRepaint(MiniCandlePainter oldDelegate) =>
      oldDelegate.bars != bars ||
      oldDelegate.currentPrice != currentPrice ||
      oldDelegate.beLower != beLower ||
      oldDelegate.beUpper != beUpper;
}
