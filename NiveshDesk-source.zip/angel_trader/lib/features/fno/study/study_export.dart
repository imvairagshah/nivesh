// ---------------------------------------------------------------------------
// study_export.dart — XLSX / CSV output for the 3-Month Study.
//
// The workbook mirrors the on-screen table so the file can be forwarded as-is
// (spec §5):
//
//   Sheet 1 "Read Me"     — what every column means + when the run happened
//   Sheet 2 "All Stocks"  — every row of the table, in table order
//   Sheet 3 "Best Buys"   — only the 🎯 rows (top 20 when there are none)
//
// Both writers share one column list, so the XLSX and the CSV can never drift
// apart — and the spec's "never print a raw sign" rule for P&L lives in exactly
// one place ([pnlWords]).
// ---------------------------------------------------------------------------

import 'dart:io';

import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';

import 'black_scholes.dart';
import 'study_engine.dart';

/// One positioned cell — the sheet builder is 2-D because `excel` is.
typedef ExportCell = CellValue?;

class StudyExportService {
  StudyExportService();

  // -------------------------------------------------------------------------
  // Wording shared by screen, XLSX, CSV and the messaging recap
  // -------------------------------------------------------------------------

  static const String disclaimer =
      'Ye study sirf analysis ke liye hai. Ye buy/sell recommendation nahi hai — '
      'trading se pehle khud verify karo. Options me risk zyada hota hai.';

  /// `Profit ₹1,240` / `Loss ₹860` — never a bare minus sign (spec §2.3).
  static String pnlWords(double rupees, {int decimals = 0}) {
    final amount = _grouped(rupees.abs(), decimals);
    if (rupees > 0) return 'Profit ₹$amount';
    if (rupees < 0) return 'Loss ₹$amount';
    return 'Flat ₹$amount';
  }

  static String pointsWords(double points) {
    final amount = points.abs().toStringAsFixed(2);
    if (points > 0) return 'Profit $amount pts';
    if (points < 0) return 'Loss $amount pts';
    return 'Flat $amount pts';
  }

  /// `1,240` — Indian grouping keeps long P&L numbers readable.
  static String _grouped(double value, int decimals) {
    final text = value.toStringAsFixed(decimals);
    final parts = text.split('.');
    var whole = parts[0];
    if (whole.length > 3) {
      final last3 = whole.substring(whole.length - 3);
      var rest = whole.substring(0, whole.length - 3);
      final chunks = <String>[];
      while (rest.length > 2) {
        chunks.insert(0, rest.substring(rest.length - 2));
        rest = rest.substring(0, rest.length - 2);
      }
      if (rest.isNotEmpty) chunks.insert(0, rest);
      whole = '${chunks.join(',')},$last3';
    }
    return parts.length > 1 ? '$whole.${parts[1]}' : whole;
  }

  static String money(num? value, {int decimals = 2}) =>
      value == null ? '—' : value.toStringAsFixed(decimals);

  static String perc(num? value, {int decimals = 2}) =>
      value == null ? '—' : '${value.toStringAsFixed(decimals)}%';

  /// Where the IV came from — the spec wants this visible, not hidden.
  static String ivSourceWords(IvSource source, IvFailure? failure) {
    switch (source) {
      case IvSource.broker:
        return 'Broker (Angel option chain)';
      case IvSource.blackScholes:
        return 'Premium se banayi (Black-Scholes)';
      case IvSource.none:
        return failure != null ? 'Nahi mili (${failure.message})' : 'Nahi mili';
    }
  }

  static String edgeWords(StudyRow row) {
    if (row.edgePct == null) return '—';
    final kind = row.edgePct! >= 0 ? 'fayda' : 'nuksan (IV mehenga)';
    return '${row.edgePct!.toStringAsFixed(2)}% ($kind)';
  }

  /// `Profit ₹1,240 (Profit 31.00 pts)` — spec §3.4 item 7.
  static String yesterdayWords(StudyRow row) {
    final pnl = row.straddleYesterday;
    if (pnl == null) return '—';
    return '${pnlWords(pnl.rupees)} (${pointsWords(pnl.points)})';
  }

  // -------------------------------------------------------------------------
  // Rows
  // -------------------------------------------------------------------------

  /// Column headers — index order is shared by every writer.
  static const List<String> headers = [
    'Rank',
    'Symbol',
    'Company',
    'Trend (3M)',
    'Suggestion',
    'Score',
    'Opportunity',
    'CMP',
    '3M High',
    '3M Low',
    'High se dur %',
    'High se dur (ATR-din)',
    'Low se dur %',
    'Low se dur (ATR-din)',
    'ATR(14)',
    'ATR %',
    '3M Move %',
    'Up months',
    'Down months',
    'M1 %',
    'M2 %',
    'M3 %',
    'ATM Strike',
    'Expiry',
    'Din bache',
    'Lot Size',
    'CE LTP',
    'PE LTP',
    'CE IV %',
    'PE IV %',
    'Avg IV %',
    'IV Rank',
    'IV source',
    'Edge %',
    'Kyu (reason)',
    'Kal ka P&L',
    'OTM CE strike',
    'OTM PE strike',
    'OTM jodi total',
    'Kal ka OTM P&L',
    // The two the user asked for next to ATR: what each jodi costs as a
    // share of the stock's own price, so a ₹16 jodi on ₹130 and on ₹1,000
    // stop looking like the same trade.
    'ATM jodi % of price',
    'OTM jodi % of price',
    // 1.5.62: "High−Low ka average" — din ka simple range, gap chhod ke (ATR
    // ke mukable). End me append: column index order writers ke saath locked.
    'Avg Range (14)',
    'Avg Range %',
  ];

  static List<ExportCell> rowCells(StudyRow row) {
    final ce = row.ce;
    final pe = row.pe;
    return [
      IntCellValue(row.rank),
      TextCellValue(row.symbol),
      TextCellValue(row.companyName.isEmpty ? row.symbol : row.companyName),
      TextCellValue(row.trend.label),
      TextCellValue(row.trend.suggested),
      IntCellValue(row.score.round()),
      TextCellValue(row.opportunityTag),
      TextCellValue(money(row.ltp)),
      TextCellValue(money(row.high3m)),
      TextCellValue(money(row.low3m)),
      TextCellValue(perc(row.distHiPct)),
      TextCellValue(perc(row.distHiDays, decimals: 1)),
      TextCellValue(perc(row.distLoPct)),
      TextCellValue(perc(row.distLoDays, decimals: 1)),
      TextCellValue(money(row.atr)),
      TextCellValue(perc(row.atrPct)),
      TextCellValue(perc(row.total3mPct)),
      IntCellValue(row.upMonths),
      IntCellValue(row.downMonths),
      TextCellValue(perc(_month(row, 0))),
      TextCellValue(perc(_month(row, 1))),
      TextCellValue(perc(_month(row, 2))),
      TextCellValue(row.atmStrike == null ? '—' : money(row.atmStrike)),
      TextCellValue(row.expiryLabel ?? '—'),
      TextCellValue(row.daysToExpiry == null ? '—' : '${row.daysToExpiry}'),
      TextCellValue('${row.lotSize}'),
      TextCellValue(money(ce?.ltp)),
      TextCellValue(money(pe?.ltp)),
      TextCellValue(perc(ce?.iv)),
      TextCellValue(perc(pe?.iv)),
      TextCellValue(perc(row.avgIv)),
      TextCellValue(row.ivRank.label),
      TextCellValue(ivSourceWords(row.ivSource, ce?.ivFailure ?? pe?.ivFailure)),
      TextCellValue(edgeWords(row)),
      TextCellValue(row.reason),
      TextCellValue(yesterdayWords(row)),
      // The OTM jodi (strangle) — the same two numbers, one step out.
      TextCellValue(row.strangle?.ce?.strike == null
          ? '—'
          : money(row.strangle!.ce!.strike, decimals: 0)),
      TextCellValue(row.strangle?.pe?.strike == null
          ? '—'
          : money(row.strangle!.pe!.strike, decimals: 0)),
      TextCellValue(money(row.strangle?.total)),
      TextCellValue(otmYesterdayWords(row)),
      TextCellValue(perc(row.atmJodiPctOfPrice)),
      TextCellValue(perc(row.otmJodiPctOfPrice)),
      TextCellValue(row.avgRange > 0 ? money(row.avgRange) : '—'),
      TextCellValue(row.avgRange > 0 ? perc(row.avgRangePct) : '—'),
    ];
  }

  /// "Agar kal OTM jodi buy ki hoti" for the export — never a raw sign.
  static String otmYesterdayWords(StudyRow row) {
    final pnl = row.kalStrangle?.yesterday(row.lotSize);
    if (pnl == null) return '—';
    return '${pnlWords(pnl.rupees)} (${pointsWords(pnl.points)})';
  }

  /// `M1` is the oldest of the three months, `M3` the newest.
  static double? _month(StudyRow row, int index) {
    if (row.months.length < 3) return null;
    final month = row.months[row.months.length - 3 + index];
    return month.pct;
  }

  // -------------------------------------------------------------------------
  // "Read Me" sheet — the spec's explanation table
  // -------------------------------------------------------------------------

  static List<List<ExportCell>> readMeSheet(FnoStudyExportMeta meta) {
    String stamp(DateTime d) =>
        '${d.day.toString().padLeft(2, '0')}/'
        '${d.month.toString().padLeft(2, '0')}/${d.year} '
        '${d.hour.toString().padLeft(2, '0')}:'
        '${d.minute.toString().padLeft(2, '0')}';

    return [
      [TextCellValue('NiveshDesk — F&O 3-Month Study')],
      [TextCellValue('Read Me: har column ka matlab')],
      [],
      [TextCellValue('Study date'), TextCellValue(stamp(meta.asOf))],
      [TextCellValue('Banaya gaya'), TextCellValue(stamp(meta.runAt))],
      [
        TextCellValue('Stocks'),
        TextCellValue('${meta.rowCount} scan hue · ${meta.bestBuyCount} best-buy'),
      ],
      [
        TextCellValue('IV source'),
        TextCellValue('Broker ${meta.ivFromBroker} · premium se banayi '
            '${meta.ivFromBlackScholes}'),
      ],
      [
        TextCellValue('Option data'),
        TextCellValue(meta.withOptions == meta.rowCount
            ? 'Sabhi stocks ka ATM option data mila'
            : '${meta.withOptions} stocks ka ATM data mila — baaki degraded '
                'mode me hain (options ke bina)'),
      ],
      [],
      [TextCellValue('Column'), TextCellValue('Matlab')],
      [TextCellValue('Trend (3M)'), TextCellValue('Pichhle 3 mahine ki chalu move — STRONG UP / UP / SIDEWAYS / DOWN / STRONG DOWN. Suggestion: UP = BUY CE, DOWN = BUY PE, SIDEWAYS = AVOID.')],
      [TextCellValue('Score'), TextCellValue('0–12 ka score = direction consistency + move ki size + high/low se doori + IV ka fayda. Zyada = better setup.')],
      [TextCellValue('Opportunity'), TextCellValue('🎯 Best Buy = IV sasta + trend saaf. ⏸ Watch = setup theek hai par IV mehenga ya trend adhoora. "-" = AVOID (sideways).')],
      [TextCellValue('CMP'), TextCellValue('Study wale din ka closing price (frozen snapshot).')],
      [TextCellValue('3M High / Low'), TextCellValue('Pichhle 63 trading din ka sabse ooncha / sabse neecha price.')],
      [TextCellValue('High/Low se dur'), TextCellValue('Percent me doori aur ATR-din (kitne average-daily-range door hai). 0 = level ke bilkul paas.')],
      [TextCellValue('ATR(14)'), TextCellValue('14 din ka average true range — stock ek din me average kitna hilta hai (Wilder method).')],
      [TextCellValue('ATR %'), TextCellValue('ATR, abhi ke price ka kitna percent hai. Zyada = zyada movement.')],
      [TextCellValue('Avg Range (14)'), TextCellValue('Pichhle 14 sessions ke High − Low ka simple average — sirf din ka range (gap up/down chhod ke). ATR ke mukable seedha: gap count nahi hota.')],
      [TextCellValue('3M Move %'), TextCellValue('Poora move over the 3-month window.')],
      [TextCellValue('Up/Down months'), TextCellValue('Teen mahino me kitne mahine up the, kitne down.')],
      [TextCellValue('M1/M2/M3 %'), TextCellValue('Har mahine ka move — M1 sabse purana, M3 latest.')],
      [TextCellValue('ATM Strike'), TextCellValue('Abhi ke price ke sabse kareeb wala option strike (us stock ke expiry ka).')],
      [TextCellValue('Din bache'), TextCellValue('Expiry tak kitne calendar din. 0 ya kam = IV solve nahi hoti (expiry day pe IV ka matlab nahi).')],
      [TextCellValue('CE / PE LTP'), TextCellValue('Us strike ke call/put ka aaj ka premium.')],
      [TextCellValue('CE / PE IV %'), TextCellValue('Implied volatility — option kitna mehenga hai. Kam IV = sasta option.')],
      [TextCellValue('Avg IV %'), TextCellValue('CE + PE IV ka average.')],
      [TextCellValue('IV Rank'), TextCellValue('Aaj ki IV, poore F&O universe ki IV ke muqable kahan hai — Low / Medium / High.')],
      [TextCellValue('Edge %'), TextCellValue('ATR % minus IV ka daily part. Positive (fayda) = stock ki daily movement option ki daily cost se zyada.')],
      [TextCellValue('Kyu (reason)'), TextCellValue('Ek line me poori kahani — trend, level ki doori aur IV ka faisla.')],
      [TextCellValue('Kal ka P&L'), TextCellValue('Agar kal ATM CE+PE (straddle) jodi buy ki hoti to aaj kitna Profit/Loss hota. Buy value = *kal wale* ATM strike ke CE+PE ka kal ka close (aaj ka strike nahi — stock move hone par woh galat number deta hai), current value = usi pair ka aaj ka premium. Ye sirf observation hai, suggestion nahi.')],
      [TextCellValue('ATM jodi % of price'), TextCellValue('ATM jodi (CE+PE ka aaj ka premium) stock ke bhav ka kitna percent hai. ₹16 ka jodi ₹130 ke stock par = 12.38%. Kam = sasta, zyada = mehenga — rupee me comparison alag-alag stock par chaltaa nahi.')],
      [TextCellValue('OTM jodi % of price'), TextCellValue('Wahi hisaab OTM jodi (strangle) ke liye — dono strike ka premium mila kar, stock ke bhav ka kitna percent. ATM se chhota hona hi chahiye (door ke strike saste hote hain).')],
      [],
      [TextCellValue('Note'), TextCellValue(disclaimer)],
    ];
  }

  // -------------------------------------------------------------------------
  // Files
  // -------------------------------------------------------------------------

  /// Writes the 3-sheet workbook into the app's documents folder.
  Future<File> writeXlsx({
    required List<StudyRow> rows,
    required FnoStudyExportMeta meta,
    String? fileName,
  }) async {
    final book = Excel.createExcel();

    final readMe = book['Read Me'];
    for (final line in readMeSheet(meta)) {
      readMe.appendRow([for (final cell in line) cell ?? TextCellValue('')]);
    }

    final all = book['All Stocks'];
    _appendHeader(all);
    for (final row in rows) {
      all.appendRow([for (final cell in rowCells(row)) cell ?? TextCellValue('')]);
    }

    final best = book['Best Buys'];
    _appendHeader(best);
    final bestBuyRows = rows.where((r) => r.isBestBuy).toList();
    if (bestBuyRows.isEmpty) {
      best.appendRow([
        TextCellValue('Aaj koi stock 🎯 Best Buy criteria pe nahi utra. '
            'Neeche top 20 stocks (score ke hisaab se) dekh lo.'),
      ]);
    }
    for (final row in (bestBuyRows.isEmpty ? rows.take(20) : bestBuyRows)) {
      best.appendRow([for (final cell in rowCells(row)) cell ?? TextCellValue('')]);
    }

    // `createExcel()` ships a default sheet; the Read Me replaces it.
    if (book.sheets.containsKey('Sheet1')) book.delete('Sheet1');

    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/${fileName ?? defaultFileName(meta.asOf)}');
    await file.writeAsBytes(book.encode()!, flush: true);
    return file;
  }

  static void _appendHeader(Sheet sheet) {
    sheet.appendRow([for (final header in headers) TextCellValue(header)]);
  }

  /// Flat CSV (comment header + one header row + one row per stock).
  Future<File> writeCsv({
    required List<StudyRow> rows,
    required FnoStudyExportMeta meta,
    String? fileName,
  }) async {
    final buffer = StringBuffer()
      ..writeln('# NiveshDesk F&O — 3-Month Study (${isoDate(meta.asOf)})')
      ..writeln('# $disclaimer')
      ..writeln(headers.map(_csv).join(','));

    for (final row in rows) {
      final cells = rowCells(row).map((cell) => cell?.toString() ?? '').map(_csv);
      buffer.writeln(cells.join(','));
    }

    final dir = await getApplicationDocumentsDirectory();
    final file =
        File('${dir.path}/${fileName ?? defaultFileName(meta.asOf, csv: true)}');
    await file.writeAsString(buffer.toString(), flush: true);
    return file;
  }

  static String _csv(String value) {
    if (value.contains(',') || value.contains('"') || value.contains('\n')) {
      return '"${value.replaceAll('"', '""')}"';
    }
    return value;
  }

  static String defaultFileName(DateTime asOf, {bool csv = false}) =>
      'NiveshDesk-3Month-Study-${isoDate(asOf)}.${csv ? 'csv' : 'xlsx'}';

  static String isoDate(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-'
      '${d.month.toString().padLeft(2, '0')}-'
      '${d.day.toString().padLeft(2, '0')}';
}

/// Header block the export needs — separate from [FnoStudyResult] so a filtered
/// table can be exported with honest counts.
class FnoStudyExportMeta {
  final DateTime asOf;
  final DateTime runAt;
  final int rowCount;
  final int bestBuyCount;
  final int withOptions;
  final int ivFromBroker;
  final int ivFromBlackScholes;

  const FnoStudyExportMeta({
    required this.asOf,
    required this.runAt,
    required this.rowCount,
    required this.bestBuyCount,
    required this.withOptions,
    this.ivFromBroker = 0,
    this.ivFromBlackScholes = 0,
  });
}
