// ---------------------------------------------------------------------------
// fno_study_provider.dart — screen state for the F&O 3-Month Study.
//
// Owns:
//   • the F&O universe it scans (shipped 213-name list → tokens via the same
//     [UniverseCatalog] resolver the other screeners use),
//   • the last result: cached snapshot first, fresh scan on demand,
//   • search / filter / sort / expanded-row UI state,
//   • the live premium line — subscribing the expanded stock's two ATM legs to
//     the existing WebSocket feed so the detail panel can show a moving price
//     while the scanned table itself stays frozen (spec §3.1.1).
//
// The scan itself is [FnoStudyService]'s job. This class never touches the
// network except through that service and the feed.
// ---------------------------------------------------------------------------

import 'package:flutter/foundation.dart';

import '../../../core/utils/markets.dart';
import '../../../data/local/dao/ipo_dao.dart';
import '../../../data/local/dao/scrip_dao.dart';
import '../../../data/remote/dto/candle.dart';
import '../../../data/remote/dto/scrip.dart';
import '../../../services/fno_study_service.dart';
import '../../../services/fno_universe.dart';
import '../../../services/live_feed_service.dart';
import '../../../services/earnings_calendar_service.dart';
import '../../../services/scrip_master_service.dart';
import '../../../services/universe_catalog.dart';
import '../../settings/settings_provider.dart';
import 'study_engine.dart';
import 'study_export.dart';

/// Column the table can be sorted by (spec §4: every header is tappable).
enum StudySort {
  edge('Edge %'),
  score('Score'),
  trend('Trend'),
  ltp('Price'),
  atrPct('ATR %'),
  move('3M Move %'),
  iv('Avg IV %'),
  ivRank('IV Rank'),
  highDist('High se dur'),
  lowDist('Low se dur'),
  pnl('Kal ka P&L'),
  symbol('Naam');

  const StudySort(this.label);
  final String label;
}

/// Filter chips above the table.
enum StudyFilter {
  all('Sab'),
  bestBuy('🎯 Best Buy'),
  watch('⏸ Watch'),
  avoid('AVOID'),
  nearHigh('High ke paas'),
  nearLow('Low ke paas'),
  degraded('Option data nahi');

  const StudyFilter(this.label);
  final String label;

  bool matches(StudyRow row) => switch (this) {
    StudyFilter.all => true,
    StudyFilter.bestBuy => row.isBestBuy,
    StudyFilter.watch => row.opportunityTag.startsWith('⏸'),
    StudyFilter.avoid => row.trend == Trend3M.sideways,
    StudyFilter.nearHigh => row.distHiDays <= 2,
    StudyFilter.nearLow => row.distLoDays <= 2,
    StudyFilter.degraded => row.avgIv == null,
  };
}

class FnoStudyProvider extends ChangeNotifier {
  FnoStudyProvider({
    required FnoStudyService study,
    required SettingsProvider settings,
    required ScripDao scripDao,
    required IpoDao ipoDao,
    required ScripMasterService scripMaster,
    required LiveFeedService feed,
    required EarningsCalendarService earnings,
    FnoUniverse? fnoUniverse,
  }) : _study = study,
       _settings = settings,
       _scripDao = scripDao,
       _ipoDao = ipoDao,
       _scripMaster = scripMaster,
       _feed = feed,
       _earnings = earnings,
       _fno = fnoUniverse {
    _settings.addListener(onSettingsChanged);
  }

  final FnoStudyService _study;
  final SettingsProvider _settings;
  final ScripDao _scripDao;
  final IpoDao _ipoDao;
  final ScripMasterService _scripMaster;
  final LiveFeedService _feed;
  final EarningsCalendarService _earnings;

  FnoUniverse? _fno;

  // ---- status ------------------------------------------------------------
  FnoStudyResult? _result;
  FnoStudyProgress? _progress;
  bool _running = false;
  bool _cancelled = false;
  bool _resolvingUniverse = false;
  bool _syncingMaster = false;
  bool _masterChecked = false;
  String? _masterNote;
  String? _error;
  UniverseResolution _universe = UniverseResolution.empty;

  // ---- view state --------------------------------------------------------
  String _query = '';
  StudySort _sort = StudySort.edge;
  bool _sortDescending = true;
  StudyFilter _filter = StudyFilter.all;
  bool _sortIsUserChoice = false;
  String? _expandedSymbol;
  final List<String> _liveSubscribed = [];

  // The picker is sourced from the stock-only NFO contract book and shows the
  // three nearest monthly expiries. It never pre-scans; the current selection
  // is passed to the existing Scan button.
  List<DateTime> _expiryOptions = const [];
  DateTime? _selectedExpiry;
  bool _expiryLoading = false;
  Future<void>? _expiryRefreshFuture;

  // ---- getters -----------------------------------------------------------
  FnoStudyResult? get result => _result;
  bool get isRunning => _running;
  bool get isCancelled => _cancelled;
  bool get isResolvingUniverse => _resolvingUniverse;

  /// `true` while the scrip master is being downloaded as part of a scan.
  bool get isSyncingMaster => _syncingMaster;

  /// What the last master check did / found — shown under the scan bar.
  String? get masterNote => _masterNote;
  FnoStudyProgress? get progress => _progress;
  String? get error => _error;
  String get query => _query;
  StudySort get sort => _sort;
  bool get sortDescending => _sortDescending;
  StudyFilter get filter => _filter;
  bool get sortIsUserChoice => _sortIsUserChoice;
  String? get expandedSymbol => _expandedSymbol;

  static const int monthlyExpiryChoiceCount = 3;
  List<DateTime> get expiryOptions => List.unmodifiable(_expiryOptions);
  DateTime? get selectedExpiry => _selectedExpiry;
  bool get isLoadingExpiries => _expiryLoading;

  /// Expiry represented by the visible result (metadata first, then a row for
  /// legacy snapshots written before selected-expiry metadata existed).
  DateTime? get resultExpiry {
    final source = _result;
    if (source == null) return null;
    if (source.selectedExpiry != null) return source.selectedExpiry;
    for (final row in source.rows) {
      if (row.expiryDate != null) return row.expiryDate;
    }
    return null;
  }

  bool get resultMatchesSelectedExpiry {
    final shown = resultExpiry;
    final selected = _selectedExpiry;
    if (shown == null || selected == null) return false;
    return _sameDate(shown, selected);
  }

  static bool _sameDate(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  /// Changing the selector only changes the next Scan request; it does not
  /// trigger network work by itself.
  void selectExpiry(DateTime? value) {
    if (value == null || _running) return;
    if (!_expiryOptions.any((date) => _sameDate(date, value))) return;
    if (_selectedExpiry != null && _sameDate(_selectedExpiry!, value)) return;
    _selectedExpiry = DateTime(value.year, value.month, value.day);
    notifyListeners();
  }

  /// How many stocks the next scan will cover: the **whole** resolved F&O
  /// universe. There is no cap setting — see [FnoStudyService.noLimit].
  ///
  /// Before the resolution finishes this reports the shipped list length, so the
  /// button can say "poore 213 stocks" instead of "0".
  int get universeSize =>
      _universe.size > 0 ? _universe.size : (_fno?.length ?? 0);

  /// Total length of the shipped F&O list (`assets/data/fno_symbols.csv`, 213).
  ///
  /// This is the *whole market* the study is meant to cover — and therefore the
  /// number the headings show. It must not be confused with [universeSize],
  /// which is only how many of those names the **local** book currently
  /// resolves: on a device that has not synced the broker master yet, a
  /// 213-name list can resolve to 45, and showing that 45 in the heading read as
  /// "sirf 45 stocks scan honge" even though the scan repairs the master and
  /// covers all 213.
  int get universeTotal => _fno?.length ?? 0;

  /// The count the headings print: the full F&O list when it is loaded, else
  /// whatever the local book resolved.
  int get scanTargetCount {
    final total = universeTotal;
    return total > 0 ? total : _universe.size;
  }

  /// The scan button's label.
  ///
  /// Says the **F&O list total**, never the currently-resolved subset — a thin
  /// local master is repaired by the scan itself (see [ensureUniverse]), so the
  /// promise "poore 213 F&O stocks" is one the scan keeps.
  String get scanButtonLabel => hasResult
      ? 'Dobara scan (poore $scanTargetCount F&O stocks)'
      : 'Scan chalao (poore $scanTargetCount F&O stocks)';

  /// Tickers in the shipped F&O list that no local instrument matched (renamed
  /// or delisted since the list was cut). Shown in the status banner so a
  /// universe of "210 of 213" is never a silent surprise.
  int get unresolvedCount => _universe.missing.length;

  /// `NSE F&O · 210 instruments · 3 resolve nahi hue`
  String get universeLine {
    final size = universeSize;
    final base = '$size F&O stocks';
    return unresolvedCount == 0
        ? base
        : '$base · $unresolvedCount resolve nahi hue '
              '(${_universe.missing.take(3).join(', ')}'
              '${unresolvedCount > 3 ? '…' : ''})';
  }

  UniverseResolution get universe => _universe;

  // ---- results calendar (last / next quarterly result) -------------------

  Map<String, EarningsInfo> _earningsMap = const {};
  bool _earningsLoading = false;
  String? _earningsNote;

  /// Company results calendar: `SYMBOL → EarningsInfo`. Empty until the first
  /// [ensureEarnings] — the table renders fine without it.
  Map<String, EarningsInfo> get earnings => _earningsMap;
  bool get isLoadingEarnings => _earningsLoading;

  /// Why results dates are missing / where they came from — printed under the
  /// results line instead of silently showing nothing.
  String? get earningsNote => _earningsNote;

  /// The two dates for one row, or null when the feed has nothing for it.
  EarningsInfo? earningsFor(String symbol) =>
      _earningsMap[symbol.trim().toUpperCase()];

  /// Loads the calendar: SQLite cache first, NSE at most once a day.
  ///
  /// Called when the user opens a stock's detail panel. Failures are recorded
  /// in [earningsNote] — a company's results dates are useful, never critical.
  Future<void> ensureEarnings() async {
    if (_earningsLoading) return;
    _earningsLoading = true;
    notifyListeners();
    try {
      final calendar = await _earnings.load();
      _earningsMap = calendar.bySymbol;
      _earningsNote = calendar.isEmpty
          ? (_earnings.note ?? 'NSE ke results feed me kuch nahi mila.')
          : _earnings.note;
    } catch (e) {
      _earningsNote = 'Results dates nahi mili ($e).';
    } finally {
      _earningsLoading = false;
      notifyListeners();
    }
  }

  bool get canScan => !_running && !_universe.isEmpty;
  bool get hasResult => _result != null;
  List<StudySkip> get skips => _result?.skips ?? const [];
  List<StudyRow> get allRows => _result?.rows ?? const [];

  /// Recent daily bars for the AI Jodi Study chart — offline cache only
  /// (the scan already downloaded them). Empty = "bars cache me nahi".
  Future<List<Candle>> chartBarsFor(StudyRow row) async {
    Scrip? found;
    for (final scrip in _universe.scrips) {
      if (scrip.token == row.token) {
        found = scrip;
        break;
      }
    }
    found ??= switch (_universe.scrips.where(
          (s) =>
              Scrip.plainSymbol(s.symbol).toUpperCase() ==
              row.symbol.toUpperCase(),
        ).toList()) {
      [final first, ...] => first,
      _ => null,
    };
    if (found == null) return const <Candle>[];
    return _study.cachedBars(found);
  }

  /// Rows after filter + search + sort — what the table *and* any export use, so
  /// "WhatsApp pe bhejo" sends exactly what is on screen.
  List<StudyRow> get rows {
    final source = _result;
    if (source == null) return const [];
    var list = source.rows.where(_filter.matches).toList();

    final needle = _query.trim().toUpperCase();
    if (needle.isNotEmpty) {
      list = list.where((row) {
        return row.symbol.toUpperCase().contains(needle) ||
            row.companyName.toUpperCase().contains(needle) ||
            row.trend.label.toUpperCase().contains(needle);
      }).toList();
    }

    list.sort(_compare);
    return list;
  }

  StudyRow? get expandedRow {
    final symbol = _expandedSymbol;
    if (symbol == null) return null;
    for (final row in allRows) {
      if (row.symbol == symbol) return row;
    }
    return null;
  }

  /// Live premiums for the expanded stock — `{'CE': 42.5, 'PE': 38.1}`.
  Map<String, double> get livePremiums {
    final map = <String, double>{};
    final row = expandedRow;
    if (row == null) return map;
    for (final leg in [row.ce, row.pe]) {
      if (leg == null) continue;
      final tick =
          _feed.ticksBySubscription['${Exchange.nfo.wsType}:${leg.token}'];
      if (tick != null && tick.ltp > 0) map[leg.type.code] = tick.ltp;
    }
    return map;
  }

  /// Live premiums for the **kal wale ATM** pair (the "agar kal jodi buy ki
  /// hoti" line). Empty when that pair is the same strike as today's — the
  /// panel then falls back to [livePremiums].
  Map<String, double> get liveKalPremiums {
    final map = <String, double>{};
    final row = expandedRow;
    if (row == null) return map;
    for (final leg in [row.kalCe, row.kalPe]) {
      if (leg == null) continue;
      final tick =
          _feed.ticksBySubscription['${Exchange.nfo.wsType}:${leg.token}'];
      if (tick != null && tick.ltp > 0) map[leg.type.code] = tick.ltp;
    }
    return map;
  }

  /// Live premiums for the **OTM jodi (strangle)** of the expanded stock.
  Map<String, double> get liveStrangle {
    final map = <String, double>{};
    final pair = expandedRow?.strangle;
    if (pair == null) return map;
    for (final leg in [pair.ce, pair.pe]) {
      if (leg == null) continue;
      final tick =
          _feed.ticksBySubscription['${Exchange.nfo.wsType}:${leg.token}'];
      if (tick != null && tick.ltp > 0) map[leg.type.code] = tick.ltp;
    }
    return map;
  }

  /// Live premiums for the **kal wale OTM jodi** (the "agar kal OTM jodi buy ki
  /// hoti" line). Empty until a tick lands — the panel then uses the scan's
  /// frozen premiums.
  Map<String, double> get liveKalStrangle {
    final map = <String, double>{};
    final pair = expandedRow?.kalStrangle;
    if (pair == null) return map;
    for (final leg in [pair.ce, pair.pe]) {
      if (leg == null) continue;
      final tick =
          _feed.ticksBySubscription['${Exchange.nfo.wsType}:${leg.token}'];
      if (tick != null && tick.ltp > 0) map[leg.type.code] = tick.ltp;
    }
    return map;
  }

  bool get liveFeedActive => _settings.settings.liveFeedEnabled;

  /// `60 stocks · 7 best-buy · 4 degraded · 18 Jan`
  String get statusLine {
    final source = _result;
    if (source == null) return 'Abhi tak koi study nahi chali — Scan dabao.';
    final bits = [
      '${source.rows.length} stocks',
      '${source.bestBuyCount} best-buy',
      if (source.degraded > 0) '${source.degraded} degraded',
      if (resultExpiry != null) 'Expiry ${_shortDate(resultExpiry!)}',
      _shortDate(source.asOf),
    ];
    return bits.join(' · ');
  }

  static String _shortDate(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')} ${_months[(d.month - 1).clamp(0, 11)]}';

  static const List<String> _months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];

  // -------------------------------------------------------------------------
  // Settings plumbing
  // -------------------------------------------------------------------------

  void onSettingsChanged() {
    if (!_settingsLoaded) {
      _settingsLoaded = true;
      return;
    }
    notifyListeners();
  }

  bool _settingsLoaded = false;

  @override
  void dispose() {
    _settings.removeListener(onSettingsChanged);
    _clearLiveSubscriptions();
    super.dispose();
  }

  // -------------------------------------------------------------------------
  // Lifecycle
  // -------------------------------------------------------------------------

  /// Opening the tab: show the stored snapshot, then make sure the universe is
  /// resolved. Never fires a scan on its own.
  Future<void> bootstrap() async {
    await loadCached();
    await resolveUniverse();
    await refreshExpiryOptions();
  }

  /// Loads the stored snapshot (spec §3.1.1 — "frozen snapshot").
  Future<void> loadCached() async {
    if (_result != null) return;
    try {
      _result = await _study.loadCached();
      notifyListeners();
    } catch (_) {
      // A damaged cache is not worth an error banner; the empty state invites a
      // fresh scan anyway.
    }
  }

  /// Reads the available stock-option expiries from the local contract book.
  /// The nearest expiry is the default; selecting another one does no work until
  /// the user presses the existing Scan button. Concurrent callers share the
  /// same read so a picker tap during page bootstrap waits for the loaded dates.
  Future<void> refreshExpiryOptions({bool notify = true}) {
    final inFlight = _expiryRefreshFuture;
    if (inFlight != null) return inFlight;

    late final Future<void> refresh;
    refresh = _loadExpiryOptions(notify: notify).whenComplete(() {
      if (identical(_expiryRefreshFuture, refresh)) {
        _expiryRefreshFuture = null;
      }
    });
    _expiryRefreshFuture = refresh;
    return refresh;
  }

  Future<void> _loadExpiryOptions({required bool notify}) async {
    _expiryLoading = true;
    if (notify) notifyListeners();
    final previous = _selectedExpiry;
    try {
      _expiryOptions = await _study.upcomingStockExpiries(
        from: MarketCalendar.nowIst(),
      );
      if (previous == null ||
          !_expiryOptions.any((date) => _sameDate(date, previous))) {
        _selectedExpiry = _expiryOptions.isEmpty ? null : _expiryOptions.first;
      }
    } catch (_) {
      _expiryOptions = const [];
      _selectedExpiry = null;
    } finally {
      _expiryLoading = false;
      if (notify) notifyListeners();
    }
  }

  /// Prepares the expiry picker when the local book has fewer than three dates.
  /// This may refresh the scrip master, but it never runs the 3-Month Study;
  /// Scan remains the only study-scan trigger.
  Future<void> prepareExpiryPicker() async {
    if (_running) return;
    await refreshExpiryOptions();
    if (_expiryOptions.length >= monthlyExpiryChoiceCount ||
        _masterChecked ||
        _syncingMaster) {
      return;
    }
    await ensureUniverse();
  }

  /// Resolves the F&O symbol list against local tokens (no network).
  Future<void> resolveUniverse() async {
    _resolvingUniverse = true;
    notifyListeners();
    try {
      final fno = _fno ??= await FnoUniverse.load();
      _universe = await UniverseCatalog.resolve(
        UniverseCatalog.fno,
        scripDao: _scripDao,
        ipoDao: _ipoDao,
        resolver: await _scripMaster.resolver(),
        fnoSymbols: fno.symbols,
      );
      if (fno.isEmpty) {
        _error = 'F&O list (assets/data/fno_symbols.csv) nahi mili.';
      }
    } catch (e) {
      _error = 'Universe resolve nahi hua: $e';
    } finally {
      _resolvingUniverse = false;
      notifyListeners();
    }
  }

  /// How much of the F&O list must resolve before a scan is considered to have
  /// a usable universe. Below this the study would quietly cover a fraction of
  /// the market, so the master is refreshed first.
  static const double universeCoverageFloor = 0.8;

  /// `true` when the scan should fetch the scrip master before running.
  ///
  /// Reasons:
  ///   * the F&O universe did not resolve properly — the local scrip table is
  ///     stale or still the thin bundled seed (that is what made a 213-name list
  ///     scan only 45 stocks),
  ///   * the option book is empty, or
  ///   * fewer than the three stock-monthly expiries required by the picker are
  ///     stored locally.
  ///
  /// The master is refreshed **from the broker** (the same daily file the rest of
  /// the app uses), never from a third-party site.
  static bool needsMasterSync({
    required int resolved,
    required int expected,
    required int contracts,
    int expiryCount = monthlyExpiryChoiceCount,
  }) {
    if (contracts <= 0 || expiryCount < monthlyExpiryChoiceCount) return true;
    if (expected <= 0) return false;
    return resolved < (expected * universeCoverageFloor).floor();
  }

  /// Makes sure the universe is complete before a scan: resolves, and when the
  /// coverage is thin (or the option book is empty) pulls the scrip master once,
  /// then resolves again.
  Future<void> ensureUniverse({bool forceSync = false}) async {
    await resolveUniverse();
    if (_masterChecked && !forceSync) return;

    final expected = _fno?.length ?? 0;
    final contracts = await _study.contractCount();
    final expiryCount = (await _study.upcomingStockExpiries()).length;
    final due =
        forceSync ||
        needsMasterSync(
          resolved: _universe.size,
          expected: expected,
          contracts: contracts,
          expiryCount: expiryCount,
        );
    if (!due || _scripMaster.isRefreshing) return;

    _syncingMaster = true;
    _masterNote =
        'Scrip master update ho raha hai — F&O list me '
        '${_universe.size}/$expected stocks resolve hue; local stock-option book '
        'me $contracts contracts aur $expiryCount/3 expiries the.';
    notifyListeners();

    var masterRefreshSucceeded = false;
    try {
      await _scripMaster.refresh(force: true);
      masterRefreshSucceeded = true;
      // The cached resolver still holds the old (thin) table — rebuild it before
      // resolving again, or the retry would return the same 45 stocks.
      await _scripMaster.resolver(forceRebuild: true);
      await resolveUniverse();

      final newContracts = await _study.contractCount();
      final universeNote = _universe.size >= expected
          ? 'Scrip master update ho gaya — poore ${_universe.size} F&O stocks '
                'mil gaye, option book me $newContracts contracts hain.'
          : 'Scrip master update ho gaya — ${_universe.size}/$expected stocks '
                'resolve hue'
                '${_universe.missing.isEmpty ? '.' : ' (${_universe.missing.take(4).join(', ')}${_universe.missing.length > 4 ? '…' : ''} abhi bhi nahi mile).'}';
      final newExpiryCount = (await _study.upcomingStockExpiries()).length;
      _masterNote = '$universeNote Stock expiries: $newExpiryCount/3.';
    } catch (e) {
      _masterNote =
          'Scrip master update fail hua ($e). Jo stocks resolve hue '
          'sirf wahi scan honge.';
    } finally {
      await refreshExpiryOptions(notify: false);
      _syncingMaster = false;
      // A failed attempt can be retried by tapping the expiry picker again.
      _masterChecked = masterRefreshSucceeded;
      notifyListeners();
    }
  }

  /// What the user-facing "Master update karo" button calls.
  Future<void> refreshMasterNow() async {
    _masterChecked = false;
    await ensureUniverse(forceSync: true);
  }

  // -------------------------------------------------------------------------
  // Scan
  // -------------------------------------------------------------------------

  Future<void> scan({bool force = false}) async {
    if (_running) return;

    // The running flag goes up *before* the universe check: the master download
    // that may precede the scan is part of the scan, so the button must show
    // that something is happening and refuse a second tap.
    _running = true;
    _cancelled = false;
    _error = null;
    _progress = const FnoStudyProgress(
      stage: StudyStage.candles,
      done: 0,
      total: 0,
      fraction: 0,
    );
    notifyListeners();

    try {
      // Refresh the broker master when the F&O universe is thin, the option
      // book is empty, or it lacks the three monthly expiries in the picker.
      if (_universe.isEmpty || !_masterChecked) await ensureUniverse();
      if (_universe.isEmpty) {
        _error =
            'F&O stocks resolve nahi hue. Home screen se ek baar scrip '
            'master update karo (ya isi screen ke banner me "Master update '
            'karo" dabao), phir dobara scan.';
        return;
      }
      final fno = _fno ??= await FnoUniverse.load();
      // No cap: every resolved F&O stock is scanned.
      final run = await _study.run(
        universe: _universe.scrips,
        companyNames: fno.companyNames,
        selectedExpiry: _selectedExpiry,
        // B1: where IV may come from — the setting, not a constant.
        ivSource: StudyIvSource.fromName(_settings.settings.studyIvSource),
        onProgress: (progress) {
          _progress = progress;
          notifyListeners();
        },
        isCancelled: () => _cancelled,
      );
      _result = run;
      _expandedSymbol = null;
      _clearLiveSubscriptions();
    } catch (e) {
      _error = 'Scan fail: $e';
    } finally {
      _running = false;
      _progress = null;
      notifyListeners();
    }
  }

  void cancel() {
    if (!_running) return;
    _cancelled = true;
    notifyListeners();
  }

  /// Re-scans only when the cached snapshot is from an older day.
  Future<void> scanIfStale() async {
    final source = _result;
    if (source == null) {
      await scan();
      return;
    }
    if (source.isStaleFor(DateTime.now())) await scan();
  }

  Future<void> clearSnapshot() async {
    _result = null;
    _expandedSymbol = null;
    _clearLiveSubscriptions();
    await _study.clearCache();
    notifyListeners();
  }

  // -------------------------------------------------------------------------
  // UI state
  // -------------------------------------------------------------------------

  void setQuery(String value) {
    _query = value;
    notifyListeners();
  }

  void setFilter(StudyFilter value) {
    _filter = value;
    notifyListeners();
  }

  /// Tapping a header sorts by it; tapping the same header flips direction.
  void sortBy(StudySort column) {
    if (_sort == column) {
      _sortDescending = !_sortDescending;
    } else {
      _sort = column;
      _sortDescending = column != StudySort.symbol;
    }
    _sortIsUserChoice = true;
    notifyListeners();
  }

  /// Back to the spec's own ranking: 🎯 Best Buy first, then score.
  void resetSort() {
    _sort = StudySort.edge;
    _sortDescending = true;
    _sortIsUserChoice = false;
    notifyListeners();
  }

  void toggleExpanded(StudyRow row) {
    _expandedSymbol = _expandedSymbol == row.symbol ? null : row.symbol;
    _syncLiveSubscriptions();
    notifyListeners();
  }

  void collapse() {
    _expandedSymbol = null;
    _syncLiveSubscriptions();
    notifyListeners();
  }

  /// Mirrors the expanded row's two legs into the WebSocket feed (and drops the
  /// previous row's legs, so the feed never accumulates stray tokens).
  void _syncLiveSubscriptions() {
    _clearLiveSubscriptions();

    final row = expandedRow;
    final subscriptions = <FeedSubscription>[];
    if (row != null && _settings.settings.liveFeedEnabled) {
      // Today's ATM legs **and**, when the stock moved, the kal wale ATM legs —
      // so both the live jodi total and the "kal jodi" line keep ticking.
      // The OTM jodi (strangle) rides along: it is the same kind of pair, and
      // leaving it out would freeze one half of the panel while the other moves.
      final seen = <String>{};
      final strangle = row.strangle;
      final kalStrangle = row.kalStrangle;
      for (final leg in [
        row.ce,
        row.pe,
        row.kalCe,
        row.kalPe,
        strangle?.ce,
        strangle?.pe,
        kalStrangle?.ce,
        kalStrangle?.pe,
      ]) {
        if (leg == null) continue;
        if (!seen.add(leg.token)) continue;
        subscriptions.add(
          FeedSubscription(
            token: leg.token,
            exchange: Exchange.nfo,
            priceKey: 'NFO:${leg.symbol}',
          ),
        );
      }
    }

    if (subscriptions.isEmpty) {
      _feed.clearExtraSubscriptions(_feedOwner);
      return;
    }

    _liveSubscribed
      ..clear()
      ..addAll(subscriptions.map((s) => s.id));
    _feed.setExtraSubscriptions(_feedOwner, subscriptions);
  }

  void _clearLiveSubscriptions() {
    if (_liveSubscribed.isEmpty) return;
    _liveSubscribed.clear();
    _feed.clearExtraSubscriptions(_feedOwner);
  }

  /// Namespace under which this screen registers its WebSocket extras.
  static const String _feedOwner = 'fno_study';

  FnoStudyExportMeta get exportMeta {
    final source = _result;
    return FnoStudyExportMeta(
      asOf: source?.asOf ?? DateTime.now(),
      runAt: source?.runAt ?? DateTime.now(),
      rowCount: rows.length,
      bestBuyCount: rows.where((r) => r.isBestBuy).length,
      withOptions: rows.where((r) => r.avgIv != null).length,
      ivFromBroker: source?.ivFromBroker ?? 0,
      ivFromBlackScholes: source?.ivFromBlackScholes ?? 0,
    );
  }

  // -------------------------------------------------------------------------
  // Sorting
  // -------------------------------------------------------------------------

  int _compare(StudyRow a, StudyRow b) {
    // Spec ranking first — unless the user picked a column themselves.
    if (!_sortIsUserChoice) {
      final tagCompare = _tagWeight(b).compareTo(_tagWeight(a));
      if (tagCompare != 0) return tagCompare;
      final scoreCompare = b.score.compareTo(a.score);
      if (scoreCompare != 0) return scoreCompare;
    }

    if (_sort == StudySort.symbol) {
      final cmp = a.symbol.compareTo(b.symbol);
      return _sortDescending ? -cmp : cmp;
    }

    // Every other column is a number that may be missing. A missing value is
    // "unknown", not "the smallest" — so it always sorts last, no matter which
    // direction the user picked.
    final aValue = _sortValue(a);
    final bValue = _sortValue(b);
    if (aValue == null || bValue == null) {
      if (aValue == null && bValue == null) return 0;
      return aValue == null ? 1 : -1;
    }

    final result = aValue.compareTo(bValue);
    return _sortDescending ? -result : result;
  }

  /// The current sort column's value for a row (`null` = no data).
  double? _sortValue(StudyRow row) => switch (_sort) {
    StudySort.edge => row.edgePct,
    StudySort.score => row.score,
    StudySort.trend => _trendWeight(row.trend).toDouble(),
    StudySort.ltp => row.ltp,
    StudySort.atrPct => row.atrPct,
    StudySort.move => row.total3mPct,
    StudySort.iv => row.avgIv,
    StudySort.ivRank =>
      row.ivRank == IvRank.unknown ? null : row.ivRank.index.toDouble(),
    StudySort.highDist => row.distHiDays,
    StudySort.lowDist => row.distLoDays,
    StudySort.pnl => row.straddleYesterday?.points,
    StudySort.symbol => null, // handled above
  };

  static int _tagWeight(StudyRow row) {
    if (row.isBestBuy) return 2;
    if (row.opportunityTag.startsWith('⏸')) return 1;
    return 0;
  }

  static int _trendWeight(Trend3M trend) => switch (trend) {
    Trend3M.strongUp => 4,
    Trend3M.up => 3,
    Trend3M.sideways => 2,
    Trend3M.down => 1,
    Trend3M.strongDown => 0,
  };
}
