// ---------------------------------------------------------------------------
// news_parsers.dart — pure parsers for every news source (1.5.52).
//
// All parsing happens on injected text: NSE/Google RSS XML, the official
// F&O ban CSV, a public Telegram `t.me/s/` preview page, and the official
// NSE CM bhavcopy CSV (OHLC). Nothing here touches the network — the phone
// fetches, the tests feed fixtures. No live NSE calls ever happen in tests.
// ---------------------------------------------------------------------------

import 'package:flutter/foundation.dart';

/// One raw feed entry before stock matching.
@immutable
class RssItem {
  const RssItem({
    required this.title,
    required this.description,
    this.link,
    this.published,
    required this.sourceLabel,
  });

  final String title;
  final String description;
  final String? link;
  final DateTime? published;
  final String sourceLabel;

  String get text => description.isEmpty ? title : '$title $description';
}

/// One public Telegram post from the web preview.
@immutable
class TelegramPost {
  const TelegramPost({
    required this.messageId,
    required this.text,
    this.published,
    this.link,
  });

  final String messageId;
  final String text;
  final DateTime? published;
  final String? link;
}

/// Official daily OHLC for one symbol (bhavcopy row).
@immutable
class OhlcBar {
  const OhlcBar({
    required this.symbol,
    required this.open,
    required this.high,
    required this.low,
    required this.close,
  });

  final String symbol;
  final double open;
  final double high;
  final double low;
  final double close;

  double get range => high - low;
}

abstract final class NewsParsers {
  // -- helpers --------------------------------------------------------------

  static String _unescaped(String raw) {
    var text = raw.replaceAllMapped(
      RegExp(r'<!\[CDATA\[(.*?)\]\]>', dotAll: true),
      (m) => m.group(1)!,
    );
    text = text
        .replaceAll('&amp;', '&')
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll('&quot;', '"')
        .replaceAll('&#39;', "'")
        .replaceAll('&apos;', "'");
    return text
        .replaceAll(RegExp(r'<[^>]+>'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  static String? _tag(String block, String tag) {
    final match = RegExp(
      '<$tag[^>]*>(.*?)</$tag>',
      dotAll: true,
      caseSensitive: false,
    ).firstMatch(block);
    return match == null ? null : _unescaped(match.group(1)!);
  }

  /// NSE RSS uses `dd-MMM-yyyy HH:mm:ss`; Google News uses RFC822/pubDate
  /// with an offset. Both are best-effort — null is an honest miss.
  static DateTime? parseFlexibleDate(String? raw) {
    if (raw == null || raw.trim().isEmpty) return null;
    final text = raw.trim();

    // dd-MMM-yyyy HH:mm:ss (NSE RSS)
    final nse = RegExp(
            r'^(\d{1,2})-([A-Za-z]{3})-(\d{4})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?')
        .firstMatch(text);
    if (nse != null) {
      final months = {
        'JAN': 1, 'FEB': 2, 'MAR': 3, 'APR': 4, 'MAY': 5, 'JUN': 6,
        'JUL': 7, 'AUG': 8, 'SEP': 9, 'OCT': 10, 'NOV': 11, 'DEC': 12,
      };
      final month = months[nse.group(2)!.toUpperCase()];
      if (month != null) {
        return DateTime(
          int.parse(nse.group(3)!),
          month,
          int.parse(nse.group(1)!),
          int.parse(nse.group(4) ?? '0'),
          int.parse(nse.group(5) ?? '0'),
          int.parse(nse.group(6) ?? '0'),
        );
      }
    }

    // ISO-8601 (Telegram datetime attributes, dc:date)
    final iso = DateTime.tryParse(text);
    if (iso != null) return iso;

    // RFC822 (Google News pubDate) — "Sat, 25 Oct 2026 07:20:00 +0530".
    // The weekday and the offset are ignored; the wall-clock is kept.
    final months = {
      'JAN': 1, 'FEB': 2, 'MAR': 3, 'APR': 4, 'MAY': 5, 'JUN': 6,
      'JUL': 7, 'AUG': 8, 'SEP': 9, 'OCT': 10, 'NOV': 11, 'DEC': 12,
    };
    final rfc = RegExp(
      r'^(?:[A-Za-z]{3},\s*)?(\d{1,2})\s+([A-Za-z]{3})\s+(\d{4})'
      r'\s+(\d{2}):(\d{2})(?::(\d{2}))?',
    ).firstMatch(text);
    if (rfc != null) {
      final month = months[rfc.group(2)!.toUpperCase()];
      if (month != null) {
        return DateTime(
          int.parse(rfc.group(3)!),
          month,
          int.parse(rfc.group(1)!),
          int.parse(rfc.group(4)!),
          int.parse(rfc.group(5)!),
          int.parse(rfc.group(6) ?? '0'),
        );
      }
    }
    return null;
  }

  // -- RSS (NSE + Google News) ----------------------------------------------

  /// Items from any RSS 2.0 feed. [fallbackSource] labels the entries when
  /// the feed does not name a publisher per item.
  static List<RssItem> parseRssFeed(String xml, {String fallbackSource = ''}) {
    final items = <RssItem>[];
    final blocks = RegExp(r'<item[ >](.*?)</item>', dotAll: true, caseSensitive: false)
        .allMatches(xml);
    for (final block in blocks) {
      final body = block.group(1)!;
      final title = _tag(body, 'title') ?? '';
      final description = _tag(body, 'description') ?? '';
      final link = _tag(body, 'link');
      final published = parseFlexibleDate(
        _tag(body, 'pubDate') ?? _tag(body, 'dc:date') ?? _tag(body, 'date'),
      );
      // Google News puts the publisher in <source url="…">Name</source>.
      final sourceMatch = RegExp(r'<source[^>]*>(.*?)</source>',
              dotAll: true, caseSensitive: false)
          .firstMatch(body);
      final parsedSource =
          sourceMatch == null ? '' : _unescaped(sourceMatch.group(1)!);
      final sourceLabel =
          parsedSource.isEmpty ? fallbackSource : parsedSource;
      if (title.isEmpty && description.isEmpty) continue;
      items.add(RssItem(
        title: title,
        description: description,
        link: link,
        published: published,
        sourceLabel: sourceLabel,
      ));
    }
    return items;
  }

  // -- F&O ban CSV ----------------------------------------------------------

  /// `fo_secban.csv` — lines like `1,LICHSGFIN` under a header carrying
  /// `Securities in Ban For Trade Date 03-SEP-2026`.
  static ({List<String> symbols, DateTime? tradeDate}) parseFoSecBan(String csv) {
    DateTime? tradeDate;
    final dateMatch = RegExp(r'Trade Date\s+(\d{1,2}-[A-Z]{3}-\d{4})',
            caseSensitive: false)
        .firstMatch(csv);
    if (dateMatch != null) {
      tradeDate = parseFlexibleDate(dateMatch.group(1)!);
    }
    final symbols = <String>[];
    for (final line in csv.split(RegExp(r'[\r\n]+'))) {
      final row = RegExp(r'^\s*\d+\s*,\s*([A-Z0-9&\-\.]+)\s*$').firstMatch(line);
      if (row != null) symbols.add(row.group(1)!.trim().toUpperCase());
    }
    return (symbols: symbols, tradeDate: tradeDate);
  }

  // -- Telegram public preview (t.me/s/<handle>) ----------------------------

  /// Extracts posts from the public web preview HTML. Structure Telegram
  /// serves: `data-post="handle/123"`, `<time … datetime="…">`, and a
  /// `tgme_widget_message_text` body. Regex-based on purpose — no html dep.
  static List<TelegramPost> parseTelegramPreview(String html) {
    final posts = <TelegramPost>[];
    final wraps = RegExp(
      r'data-post="([^"]+)"',
    ).allMatches(html);
    // Slice the page per message using data-post as the anchor.
    final anchors = wraps.toList();
    for (var i = 0; i < anchors.length; i++) {
      final start = anchors[i].start;
      final end = i + 1 < anchors.length ? anchors[i + 1].start : html.length;
      final block = html.substring(start, end);
      final postId = anchors[i].group(1)!; // handle/123
      final messageId = postId.split('/').last;

      final dateMatch =
          RegExp(r'datetime="([^"]+)"').firstMatch(block);
      final published = parseFlexibleDate(dateMatch?.group(1));

      var text = '';
      final textMatch = RegExp(
        r'tgme_widget_message_text[^>]*>(.*?)</div>',
        dotAll: true,
      ).firstMatch(block);
      if (textMatch != null) {
        text = _unescaped(textMatch.group(1)!);
      } else {
        // Service messages (polls, forwards) — take the brave-title if any.
        final titleMatch = RegExp(
          r'tgme_widget_message_text[^>]*>(.*)',
          dotAll: true,
        ).firstMatch(block);
        if (titleMatch != null) text = _unescaped(titleMatch.group(1)!);
      }
      if (text.isEmpty) continue;
      posts.add(TelegramPost(
        messageId: messageId,
        text: text,
        published: published,
        link: 'https://t.me/$postId',
      ));
    }
    return posts;
  }

  // -- NSE CM bhavcopy OHLC -------------------------------------------------

  /// Parses the official NSE CM bhavcopy CSV for open/high/low/close. Two
  /// header styles are accepted: the UDiFF CM names the app already parses
  /// (`TckrSymb, SctySrs, OpnPric, HghPric, LwPric, ClsPric`) and the older
  /// classic names (`SYMBOL, SERIES, OPEN, HIGH, LOW, CLOSE`). Only mainboard
  /// cash series rows are kept.
  static Map<String, OhlcBar> parseBhavcopyOhlc(String csv) {
    final lines = csv.split(RegExp(r'[\r\n]+'));
    if (lines.isEmpty) return {};
    String norm(String h) =>
        h.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
    final header = lines.first.split(',').map(norm).toList();
    int col(List<String> names) {
      for (final name in names) {
        final idx = header.indexOf(norm(name));
        if (idx >= 0) return idx;
      }
      return -1;
    }

    final iSymbol = col(['TckrSymb', 'Symbol']);
    final iSeries = col(['SctySrs', 'Series']);
    final iOpen = col(['OpnPric', 'OpenPrice', 'Open']);
    final iHigh = col(['HghPric', 'HighPrice', 'High']);
    final iLow = col(['LwPric', 'LowPrice', 'Low']);
    final iClose = col(['ClsPric', 'ClosePrice', 'Close']);
    if (iSymbol < 0 || iHigh < 0 || iLow < 0 || iClose < 0) return {};

    const allowedSeries = {'EQ', 'BE', 'BZ'};
    final out = <String, OhlcBar>{};
    for (var i = 1; i < lines.length; i++) {
      final line = lines[i].trim();
      if (line.isEmpty) continue;
      final parts = line.split(',');
      if (parts.length <= iClose) continue;
      final series = iSeries >= 0 && iSeries < parts.length
          ? parts[iSeries].trim().toUpperCase()
          : 'EQ';
      if (!allowedSeries.contains(series)) continue;
      final symbol = parts[iSymbol].trim().toUpperCase();
      if (symbol.isEmpty) continue;
      double? numAt(int idx) =>
          idx >= 0 && idx < parts.length ? double.tryParse(parts[idx].trim()) : null;
      final high = numAt(iHigh);
      final low = numAt(iLow);
      final close = numAt(iClose);
      if (high == null || low == null || close == null) continue;
      if (high <= 0 || low <= 0 || close <= 0) continue;
      out[symbol] = OhlcBar(
        symbol: symbol,
        open: numAt(iOpen) ?? close,
        high: high,
        low: low,
        close: close,
      );
    }
    return out;
  }
}
