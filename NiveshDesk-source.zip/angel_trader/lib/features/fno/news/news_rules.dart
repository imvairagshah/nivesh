// ---------------------------------------------------------------------------
// news_rules.dart — the pure rule engine behind the News module (1.5.52).
//
// "AI" here means exactly what it means in AI Jodi Study: transparent,
// offline, testable rules — keyword direction, name matching, level plans
// from official high/low + ATR. No predictions, no promises: every suggestion
// carries the disclaimer, every missing number stays missing.
// ---------------------------------------------------------------------------

import 'package:flutter/foundation.dart';

import '../study/ai_jodi_engine.dart';
import '../study/study_engine.dart' show IvRank;
import 'news_models.dart';

/// A stock the matcher knows about.
@immutable
class StockRef {
  const StockRef({
    required this.symbol,
    required this.companyName,
    this.sector = '',
    this.isFno = false,
  });

  final String symbol;
  final String companyName;
  final String sector;
  final bool isFno;
}

abstract final class NewsRules {
  static const String disclaimer =
      'Ye suggestion rule-based AI (offline) hai — koi guaranteed move ya '
      'return nahi. News-day high/low aur ATR ek scenario plan hain, bhavishya '
      'ka dava nahi. Apne risk aur stop-loss ke hisab se hi trade karein.';

  // -- company-name normalisation ------------------------------------------

  static const Set<String> _nameSuffixes = {
    'LTD',
    'LIMITED',
    'PVT',
    'PRIVATE',
    'CO',
    'CORP',
    'CORPN',
    'CORPORATION',
    'THE',
    'AND',
    '&',
  };

  /// Upper-case, drop punctuation, drop trailing corporate suffixes so
  /// "Senco Gold Ltd." matches "SENCO GOLD".
  static String normalizeName(String raw) {
    var text = raw.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9 ]'), ' ');
    text = text.replaceAll(RegExp(r'\s+'), ' ').trim();
    final parts = text.split(' ');
    while (parts.length > 1 && _nameSuffixes.contains(parts.last)) {
      parts.removeLast();
    }
    return parts.join(' ');
  }

  // -- direction keywords ---------------------------------------------------

  /// Strong positives score 2, ordinary ones 1.
  static const Map<String, int> positiveKeywords = {
    'ORDER WIN': 2,
    'BAGS ORDER': 2,
    'RECEIVES ORDER': 1,
    'WORK ORDER': 1,
    'CONTRACT AWARDED': 2,
    'RECORD PROFIT': 2,
    'RECORD REVENUE': 2,
    'PROFIT SURGES': 2,
    'PROFIT JUMPS': 2,
    'PROFIT RISES': 1,
    'PROFIT UP': 1,
    'REVENUE UP': 1,
    'EBITDA UP': 1,
    'BEATS ESTIMATES': 2,
    'RESULTS BEAT': 2,
    'POSTS PROFIT': 1,
    'DIVIDEND': 1,
    'BONUS': 1,
    'BUYBACK': 2,
    'SPLIT': 1,
    'EXPANSION': 1,
    'EXPANDS': 1,
    'COMMISSIONS': 1,
    'COMMISSIONED': 1,
    'INAUGURAT': 1,
    'GREENFIELD': 1,
    'CAPACITY': 1,
    'GUIDANCE RAISED': 2,
    'RAISES GUIDANCE': 2,
    'UPGRADE': 1,
    'APPROVAL GRANTED': 2,
    'APPROVED BY': 1,
    'SEBI APPROVAL': 2,
    'PROMOTER BUYS': 2,
    'INSIDER BUYS': 2,
    '52-WEEK HIGH': 1,
    'ALL-TIME HIGH': 1,
  };

  static const Map<String, int> negativeKeywords = {
    'SEBI PROBE': 2,
    'SEBI ORDERS': 2,
    'RAID': 2,
    'PENALTY': 2,
    'SHOW CAUSE': 2,
    'SUMMONS': 2,
    'FIR REGISTERED': 2,
    'ARREST': 2,
    'INVESTIGATION': 1,
    'NCLT': 2,
    'INSOLVENCY': 2,
    'BANKRUPT': 2,
    'WILFUL DEFAULT': 2,
    'PROFIT FALLS': 2,
    'PROFIT DECLINES': 2,
    'PROFIT DROPS': 2,
    'NET LOSS': 2,
    'POSTS LOSS': 2,
    'REVENUE DOWN': 1,
    'EBITDA DOWN': 1,
    'MISSES ESTIMATES': 2,
    'NPA RISES': 2,
    'NPA UP': 1,
    'CUTS GUIDANCE': 2,
    'GUIDANCE CUT': 2,
    'DOWNGRADE': 2,
    'SUSPEND': 2,
    'TERMINAT': 2,
    'CANCELLED': 2,
    'CANCELED': 2,
    'REVOKE': 2,
    'DEBAR': 2,
    'DELAYED': 1,
    'POSTPONE': 1,
    'MARGIN PRESSURE': 1,
    'COST INCREASE': 1,
    'WARN': 1,
    'LAYOFF': 1,
    'SHUTDOWN': 1,
    'STRIKE': 1,
    '52-WEEK LOW': 1,
    'ALL-TIME LOW': 1,
  };

  /// Words that are inherently two-sided — force Mixed when they dominate.
  static const Set<String> mixedKeywords = {
    'ACQUISITION',
    'MERGER',
    'AMALGAMAT',
    'RIGHTS ISSUE',
    'FUND RAISE',
    'FUND-RAISE',
    'FUND RAISING',
    'QIP',
    'STAKE SALE',
    'PROMOTER PLEDGE',
    'ENCUMBER',
    'DISINVEST',
    'JOINT VENTURE',
    'OPEN OFFER',
    'RESTRUCTUR',
    'REPRICING',
  };

  /// Keyword-only direction classification. `text` is upper-cased here.
  static EffectDirection classifyDirection(String text) {
    final upper = text.toUpperCase();
    var pos = 0;
    var neg = 0;
    for (final entry in positiveKeywords.entries) {
      if (upper.contains(entry.key)) pos += entry.value;
    }
    for (final entry in negativeKeywords.entries) {
      if (upper.contains(entry.key)) neg += entry.value;
    }
    final mixedHit = mixedKeywords.any(upper.contains);
    if (mixedHit && pos == 0 && neg == 0) return EffectDirection.mixed;
    if (pos > 0 && neg > 0) return EffectDirection.mixed;
    if (pos > 0) return EffectDirection.positive;
    if (neg > 0) return EffectDirection.negative;
    return mixedHit ? EffectDirection.mixed : EffectDirection.unknown;
  }

  // -- stock matching -------------------------------------------------------

  static bool _symbolMentioned(String upperText, String symbol) {
    final s = symbol.toUpperCase();
    if (s.length < 2) return false;
    return RegExp('(^|[^A-Z0-9])${RegExp.escape(s)}([^A-Z0-9]|\$)')
        .hasMatch(upperText);
  }

  /// Finds the stocks a news text touches. Prefer [NewsMatcher] when matching
  /// many items against the same universe — this wrapper rebuilds the index
  /// every call and is meant for one-off use (tests, tooling).
  static List<AffectedStock> matchAffected({
    required String text,
    required List<StockRef> universe,
  }) =>
      NewsMatcher(universe).match(text);

  /// Impact ranking: symbol-in-title and F&O membership push a name up.
  static List<AffectedStock> rankAffected({
    required String title,
    required List<AffectedStock> matched,
  }) {
    final upperTitle = title.toUpperCase();
    final scored = <AffectedStock>[];
    for (final stock in matched) {
      var score = 0;
      if (_symbolMentioned(upperTitle, stock.symbol)) score += 3;
      if (normalizeName(stock.companyName).length >= 5 &&
          upperTitle.contains(normalizeName(stock.companyName))) {
        score += 2;
      }
      if (stock.isFno) score += 2;
      if (stock.direction != EffectDirection.unknown) score += 1;
      score += stock.impactScore;
      scored.add(stock.copyWith(impactScore: score));
    }
    scored.sort((a, b) {
      final byScore = b.impactScore.compareTo(a.impactScore);
      if (byScore != 0) return byScore;
      if (a.isFno != b.isFno) return a.isFno ? -1 : 1;
      return a.symbol.compareTo(b.symbol);
    });
    return scored;
  }

  // -- level plans ----------------------------------------------------------

  /// Scenario plan from the last session's official high/low + ATR.
  /// Positive news → breakout long above the high; negative → short below the
  /// low (or exit longs). Mixed/unknown news gets no level plan at all.
  static TradePlanLevels? buildLevelsPlan({
    required EffectDirection direction,
    required double? lastHigh,
    required double? lastLow,
    required double? atr,
  }) {
    if (direction != EffectDirection.positive &&
        direction != EffectDirection.negative) {
      return null;
    }
    final vol = (atr != null && atr > 0) ? atr : null;
    final rangeProxy = (lastHigh != null &&
            lastLow != null &&
            lastHigh > lastLow)
        ? lastHigh - lastLow
        : null;
    final effectiveVol = vol ?? rangeProxy;
    final basis = vol != null
        ? 'Last session high/low + ATR(14)'
        : rangeProxy != null
            ? 'Last session high/low + session range (ATR nahi)'
            : 'Data nahi';

    if (direction == EffectDirection.positive) {
      final entry = lastHigh;
      final stop = lastLow;
      final target = (entry != null && effectiveVol != null)
          ? entry + 1.5 * effectiveVol
          : null;
      return TradePlanLevels(
        direction: direction,
        entry: entry,
        stop: stop,
        target: target,
        basis: basis,
      );
    }
    final entry = lastLow;
    final stop = lastHigh;
    final target = (entry != null && effectiveVol != null)
        ? entry - 1.5 * effectiveVol
        : null;
    return TradePlanLevels(
      direction: direction,
      entry: entry,
      stop: stop,
      target: target,
      basis: basis,
    );
  }

  // -- jodi idea ------------------------------------------------------------

  /// "Agar jodi long karni ho" — ATM straddle / OTM strangle for high-impact
  /// news on an F&O stock. Break-evens reuse [AiJodiEngine.jodiBreakEvens].
  static JodiIdea? buildJodiIdea({
    required bool isFno,
    required bool highImpact,
    required double? atmStrike,
    required double? ceLtp,
    required double? peLtp,
    required double? stranglePeStrike,
    required double? strangleCeStrike,
    required double? strangleTotal,
    required IvRank ivRank,
  }) {
    if (!isFno || !highImpact) return null;
    final ivStar = AiJodiEngine.ivStarLabel(ivRank);
    final straddlePremium = (ceLtp != null && peLtp != null)
        ? ceLtp + peLtp
        : null;
    if (atmStrike != null && straddlePremium != null && straddlePremium > 0) {
      final be = AiJodiEngine.jodiBreakEvens(
        lowerStrike: atmStrike,
        upperStrike: atmStrike,
        totalPremium: straddlePremium,
      );
      return JodiIdea(
        label: 'ATM straddle long (jodi)',
        premium: straddlePremium,
        breakEvenLower: be.lower,
        breakEvenUpper: be.upper,
        ivStar: ivStar,
        note: 'Strike ${atmStrike.toStringAsFixed(0)} · premium CE+PE',
      );
    }
    if (stranglePeStrike != null &&
        strangleCeStrike != null &&
        strangleTotal != null &&
        strangleTotal > 0) {
      final be = AiJodiEngine.jodiBreakEvens(
        lowerStrike: stranglePeStrike,
        upperStrike: strangleCeStrike,
        totalPremium: strangleTotal,
      );
      return JodiIdea(
        label: 'OTM strangle long (jodi)',
        premium: strangleTotal,
        breakEvenLower: be.lower,
        breakEvenUpper: be.upper,
        ivStar: ivStar,
        note:
            'PE ${stranglePeStrike.toStringAsFixed(0)} / CE ${strangleCeStrike.toStringAsFixed(0)}',
      );
    }
    return null;
  }

  // -- the AI-suggestion field ---------------------------------------------

  /// Rule-based plan text for one stock. Always honest about what is missing.
  static String suggestionFor({
    required AffectedStock stock,
    required TradePlanLevels? levels,
    required JodiIdea? jodi,
    required String dataNote,
  }) {
    final buffer = StringBuffer();
    switch (stock.direction) {
      case EffectDirection.positive:
        buffer.write(
            'News positive lagta hai. Agar trade lena ho to trend ke sath long: ');
      case EffectDirection.negative:
        buffer.write(
            'News negative lagta hai. Longs me caution — F&O ho to short/put ka plan: ');
      case EffectDirection.mixed:
        buffer.write('News do-tarah ka hai — pehle price action confirm hone do. ');
      case EffectDirection.unknown:
        buffer.write('Direction rule-based taur par saaf nahi — trade se pehle khud check karein. ');
    }
    if (levels != null && levels.hasLevels) {
      String fmt(double? v) => v == null ? '—' : v.toStringAsFixed(1);
      if (stock.direction == EffectDirection.positive) {
        buffer.write(
            'Entry ₹${fmt(levels.entry)} ke upar sustain hone par, SL ₹${fmt(levels.stop)} ke neeche, '
            'target ~₹${fmt(levels.target)} (1.5× volatility).');
      } else {
        buffer.write(
            'Entry ₹${fmt(levels.entry)} ke neeche breakdown par (short/exit), SL ₹${fmt(levels.stop)} ke upar, '
            'target ~₹${fmt(levels.target)} (1.5× volatility).');
      }
    } else if (stock.direction == EffectDirection.positive ||
        stock.direction == EffectDirection.negative) {
      buffer.write('Levels ke liye price data nahi — sirf direction dekh ke trade karein.');
    } else {
      buffer.write('Is news ke liye level plan apply nahi hota.');
    }
    if (jodi != null) {
      buffer.write(
          ' Bada move expect ho to ${jodi.label}: ₹${jodi.premium.toStringAsFixed(1)}, '
          'break-even ${jodi.breakEvenLower.toStringAsFixed(0)}–${jodi.breakEvenUpper.toStringAsFixed(0)}.');
    }
    buffer.write(' ($dataNote)');
    return buffer.toString();
  }

  /// Puts the whole deep-research payload together for one item.
  static DeepResearch buildResearch({
    required String title,
    required List<AffectedStock> ranked,
    required Map<String, ({double? high, double? low, double? atr})> levelsBySymbol,
    required Map<String, JodiIdea?> jodiBySymbol,
    required Map<String, String> dataNotes,
    Map<String, ({bool agrees, String label})> jodiSignals = const {},
  }) {
    final stocks = <StockResearch>[];
    for (final stock in ranked) {
      final data = levelsBySymbol[stock.symbol] ?? (high: null, low: null, atr: null);
      final levels = buildLevelsPlan(
        direction: stock.direction,
        lastHigh: data.high,
        lastLow: data.low,
        atr: data.atr,
      );
      final jodi = jodiBySymbol[stock.symbol];
      final note = dataNotes[stock.symbol] ?? 'Data nahi';
      final signal = jodiSignals[stock.symbol];
      stocks.add(StockResearch(
        symbol: stock.symbol,
        suggestion: suggestionFor(
          stock: stock,
          levels: levels,
          jodi: jodi,
          dataNote: note,
        ),
        levels: levels,
        jodi: jodi,
        dataNote: note,
        jodiAgrees: signal?.agrees ?? false,
        jodiSignalLabel: signal?.label ?? '',
      ));
    }
    final top = ranked.isEmpty ? null : ranked.first;
    return DeepResearch(
      mostAffectedSymbol: top?.symbol,
      mostAffectedReason: top == null
          ? 'Koi stock match nahi hua'
          : '${top.symbol} — impact score ${top.impactScore}'
              '${top.isFno ? ' · F&O stock' : ''}'
              '${top.sector.isEmpty ? '' : ' · ${top.sector}'}',
      stocks: stocks,
      disclaimer: disclaimer,
    );
  }
}

/// One-time matching index over the stock universe.
///
/// Building a RegExp per (news × stock) pair froze the phone on load — the
/// matcher precomputes normalised names, a token→symbol map and (only for
/// odd symbols like `M&M`) cached regexes **once**, so each news item costs
/// a token split and a few map lookups instead of thousands of compiles.
class NewsMatcher {
  NewsMatcher(List<StockRef> universe) {
    for (final ref in universe) {
      final symbol = ref.symbol.toUpperCase();
      if (symbol.isEmpty) continue;
      _refs.putIfAbsent(symbol, () => ref);
      if (_nonWord.hasMatch(symbol)) {
        _symbolRegexes.putIfAbsent(
          symbol,
          () => RegExp('(^|[^A-Z0-9])${RegExp.escape(symbol)}([^A-Z0-9]|\$)'),
        );
      }
      final normName = NewsRules.normalizeName(ref.companyName);
      if (normName.length >= 5) {
        final first = normName.split(' ').first;
        (_byFirstWord[first] ??= <_NameEntry>[]).add(
          _NameEntry(ref: ref, symbol: symbol, normName: normName),
        );
      }
    }
  }

  static final RegExp _nonWord = RegExp(r'[^A-Z0-9]');
  static final RegExp _tokenSplit = RegExp(r'[^A-Z0-9]+');

  final Map<String, StockRef> _refs = {};
  final Map<String, RegExp> _symbolRegexes = {};
  final Map<String, List<_NameEntry>> _byFirstWord = {};

  /// Word-boundary symbol + name matching against a prebuilt index.
  List<AffectedStock> match(String text) {
    final normText = ' ${NewsRules.normalizeName(text)} ';
    final upper = text.toUpperCase();
    final tokens = upper.split(_tokenSplit).toSet();
    final direction = NewsRules.classifyDirection(text);
    final seen = <String>{};
    final hits = <AffectedStock>[];

    void addHit(String symbol, String reason) {
      if (!seen.add(symbol)) return;
      final ref = _refs[symbol]!;
      hits.add(AffectedStock(
        symbol: symbol,
        companyName: ref.companyName,
        sector: ref.sector,
        direction: direction,
        reason: reason,
        isFno: ref.isFno,
        impactScore: 0,
      ));
    }

    // Symbols: plain ones via the token set, odd ones (M&M, BAJAJ-AUTO)
    // via regexes cached at construction.
    for (final entry in _symbolRegexes.entries) {
      if (entry.value.hasMatch(upper)) {
        addHit(entry.key, 'News me symbol mention');
      }
    }
    for (final token in tokens) {
      if (_refs.containsKey(token) && !_symbolRegexes.containsKey(token)) {
        addHit(token, 'News me symbol mention');
      }
    }

    // Company names: only candidates whose first word appears in the text.
    for (final token in tokens) {
      final candidates = _byFirstWord[token];
      if (candidates == null) continue;
      for (final candidate in candidates) {
        if (seen.contains(candidate.symbol)) continue;
        // Word-boundary name match (padded spaces) — names under 5
        // normalised chars are never indexed, so "TATA" alone cannot
        // catch "TATA MOTORS".
        if (normText.contains(' ${candidate.normName} ')) {
          addHit(candidate.symbol, 'News me company naam');
        }
      }
    }
    return hits;
  }
}

class _NameEntry {
  const _NameEntry({
    required this.ref,
    required this.symbol,
    required this.normName,
  });

  final StockRef ref;
  final String symbol;
  final String normName;
}

/// Extra pure helpers for the 1.5.55 bundle: daily digest ranking and the
/// News × Jodi cross-signal.
abstract final class NewsSignalsRules {
  /// Digest ranking: impact dominates, then kind weight, then freshness.
  static int digestScore({
    required int maxImpact,
    required NewsKind kind,
    DateTime? published,
    DateTime? now,
  }) {
    final kindWeight = switch (kind) {
      NewsKind.foBan => 3,
      NewsKind.results => 2,
      NewsKind.announcement => 2,
      NewsKind.corporateAction => 2,
      NewsKind.boardMeeting => 1,
      NewsKind.headline => 1,
      NewsKind.telegram => 1,
    };
    final ageHours = (now != null && published != null)
        ? now.difference(published).inHours
        : 24;
    final freshness = ageHours <= 6 ? 3 : ageHours <= 24 ? 1 : 0;
    return maxImpact * 2 + kindWeight + freshness;
  }

  /// News × Jodi: does the offline jodi engine agree with the news direction?
  /// "Agrees" = the stock currently passes the jodi gates with 2× cover
  /// (ATM or OTM buy verdict). Honest label either way.
  static ({bool agrees, String label}) jodiSignal({
    required bool isFno,
    required double ltp,
    required double atr,
    required double avgDailyMove15,
    required List<double> monthlyRangePcts,
    required double? atmJodiPrice,
    required double? otmJodiPrice,
  }) {
    if (!isFno) return (agrees: false, label: '');
    final result = AiJodiEngine.analyze(AiJodiInput(
      symbol: 'X',
      companyName: '',
      ltp: ltp,
      atr: atr,
      avgDailyMove15: avgDailyMove15,
      monthlyRangePcts: monthlyRangePcts,
      atmJodiPrice: atmJodiPrice,
      otmJodiPrice: otmJodiPrice,
    ));
    final agrees = result.verdict == AiJodiVerdict.atmBuy ||
        result.verdict == AiJodiVerdict.otmBuy;
    return (
      agrees: agrees,
      label: agrees
          ? '🔥 News + Jodi dono bol rahe hain — ${result.verdict.label}'
          : 'Jodi: ${result.verdict.label}',
    );
  }
}
