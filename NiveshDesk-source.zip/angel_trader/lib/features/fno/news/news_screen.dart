// ---------------------------------------------------------------------------
// news_screen.dart — the F&O "News" page (1.5.52).
//
// Feed card per news item: matched stocks + sector + effect direction right
// under the news, and a "Deep research" link that opens the advanced panel
// inline (AI suggestion, entry/exit levels, jodi-long idea). Auto-loads on
// open with a Rescan button — the same pattern as AI Jodi Study.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/layout/desktop_layout.dart';
import '../../../core/widgets/page_scroll.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/widgets/motion.dart';
import '../../../data/local/dao/fno_contract_dao.dart';
import '../../../data/local/dao/settings_dao.dart';
import '../../../services/stock_suggestion_service.dart';
import '../../magic_formula/magic_basket_provider.dart';
import '../study/fno_study_provider.dart';
import 'news_models.dart';
import 'news_provider.dart';
import 'news_rules.dart';
import 'news_service.dart';

class NewsScreen extends StatefulWidget {
  const NewsScreen({super.key});

  @override
  State<NewsScreen> createState() => _NewsScreenState();
}

class _NewsScreenState extends State<NewsScreen> {
  bool _autoLoadRequested = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || _autoLoadRequested) return;
      _autoLoadRequested = true;
      final provider = context.read<NewsProvider>();
      provider.loadChannels();
      provider.loadMyStocks();
      if (!provider.loadedOnce && !provider.isRunning) {
        provider.load();
      }
    });
  }

  Future<void> _showChannels(
    BuildContext context,
    NewsProvider provider,
  ) async {
    final controller = TextEditingController();
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (sheetContext) => Padding(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: MediaQuery.of(sheetContext).viewInsets.bottom + 16,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Trusted Telegram channels',
              style: Theme.of(sheetContext).textTheme.titleMedium,
            ),
            const SizedBox(height: 4),
            Text(
              'Sirf PUBLIC channels — app unka t.me/s/ preview padhta hai.',
              style: Theme.of(sheetContext).textTheme.bodySmall,
            ),
            const SizedBox(height: 12),
            for (final channel in provider.channels)
              ListTile(
                dense: true,
                leading: const Icon(Icons.send_rounded),
                title: Text('@$channel'),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () {
                    provider.removeChannel(channel);
                    Navigator.of(sheetContext).pop();
                  },
                ),
              ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: controller,
                    decoration: const InputDecoration(
                      labelText: 'Channel add karo (t.me link ya @handle)',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton(
                  onPressed: () {
                    provider.addChannel(controller.text);
                    Navigator.of(sheetContext).pop();
                  },
                  child: const Text('Add'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<NewsProvider>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('News'),
        actions: [
          IconButton(
            tooltip: 'Telegram channels',
            icon: const Icon(Icons.forum_rounded),
            onPressed: () => _showChannels(context, provider),
          ),
          IconButton(
            tooltip: 'Rules',
            icon: const Icon(Icons.help_outline_rounded),
            onPressed: () => _showRules(context),
          ),
        ],
      ),
      // 1.5.92 — PC fix: poora page ek hi scroll (header + chips + news).
      body: PageScroll.children(padding: EdgeInsets.zero, [
        _HeaderStrip(provider: provider),
        if (provider.error != null)
          _ErrorStrip(message: provider.error!, provider: provider),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  '${provider.visibleItems.length} news — sabse nayi upar',
                  style: Theme.of(context).textTheme.labelSmall,
                ),
              ),
              OutlinedButton.icon(
                onPressed: provider.isRunning
                    ? null
                    : () {
                        provider.load();
                      },
                icon: const Icon(Icons.refresh_rounded, size: 18),
                label: const Text('Rescan'),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
          child: Row(
            children: [
              FilterChip(
                label: const Text('Sabhi'),
                selected: provider.scope == NewsFeedScope.all,
                onSelected: (_) => provider.setScope(NewsFeedScope.all),
              ),
              const SizedBox(width: 8),
              FilterChip(
                label: const Text('Mere stocks (basket)'),
                selected: provider.scope == NewsFeedScope.basket,
                onSelected: (_) => provider.setScope(NewsFeedScope.basket),
              ),
              const SizedBox(width: 8),
              FilterChip(
                label: const Text('F&O stocks'),
                selected: provider.scope == NewsFeedScope.fno,
                onSelected: (_) => provider.setScope(NewsFeedScope.fno),
              ),
            ],
          ),
        ),
        if (provider.scope == NewsFeedScope.basket &&
            provider.mySymbols.isEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
            child: Text(
              'Basket me koi stock nahi — Magic Formula → Basket me stocks add karo.',
              style: Theme.of(context).textTheme.labelSmall,
            ),
          ),
        if (provider.scope == NewsFeedScope.fno && provider.fnoSymbols.isEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
            child: Text(
              'F&O stock list nahi mili — contract book load hone do ya '
              '3-Month Study chalao.',
              style: Theme.of(context).textTheme.labelSmall,
            ),
          ),
        if (provider.isRunning && provider.items.isEmpty)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 40),
            child: Center(child: CircularProgressIndicator()),
          )
        else if (provider.items.isEmpty)
          const _EmptyState()
        else
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (provider.digest.isNotEmpty &&
                    provider.scope == NewsFeedScope.all) ...[
                  FadeSlideIn(
                    index: 0,
                    child: _DigestCard(items: provider.digest),
                  ),
                  const SizedBox(height: 8),
                ],
                if (!DesktopLayout.isWide(context))
                  for (final item in provider.visibleItems) ...[
                    FadeSlideIn(
                      index: provider.visibleItems.indexOf(item) + 1,
                      child: _NewsCard(item: item),
                    ),
                    const SizedBox(height: 8),
                  ]
                else
                  // Desktop 1.5.73: news cards 2-col grid.
                  Builder(
                    builder: (context) {
                      final cols = DesktopLayout.columns(
                        context,
                        minTile: 430,
                        max: 2,
                      );
                      final tileW =
                          (MediaQuery.sizeOf(context).width / cols - 22).clamp(
                            380.0,
                            720.0,
                          );
                      return Wrap(
                        spacing: 10,
                        runSpacing: 8,
                        children: [
                          for (final item in provider.visibleItems)
                            SizedBox(
                              width: tileW,
                              child: FadeSlideIn(
                                index: provider.visibleItems.indexOf(item) + 1,
                                child: _NewsCard(item: item),
                              ),
                            ),
                        ],
                      );
                    },
                  ),
                if (provider.visibleItems.isEmpty) const _EmptyState(),
              ],
            ),
          ),
      ]),
    );
  }

  void _showRules(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      builder: (sheetContext) => Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'News module — kaise kaam karta hai',
              style: Theme.of(sheetContext).textTheme.titleMedium,
            ),
            const SizedBox(height: 8),
            const Text(
              '• News: NSE official RSS, F&O ban list, Google News aur aapke '
              'trusted Telegram channels se.\n'
              '• Affected stocks: news text me company naam/symbol match.\n'
              '• Effect direction: keyword rules (positive/negative/mixed).\n'
              '• Deep research: rule-based AI — entry/exit levels official '
              'high/low + ATR se, jodi long (straddle/strangle) F&O stocks pe.\n'
              '• Koi guarantee nahi — scenario plan hi hai.',
            ),
            const SizedBox(height: 12),
            Text(
              NewsRules.disclaimer,
              style: Theme.of(sheetContext).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
}

class _HeaderStrip extends StatelessWidget {
  const _HeaderStrip({required this.provider});
  final NewsProvider provider;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final loaded = provider.lastLoadedAt;
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(12, 12, 12, 0),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: theme.colorScheme.primaryContainer.withValues(alpha: 0.35),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'F&O News + AI research',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            'Har news ke niche affected stocks · sector · effect · deep research'
            '${loaded == null ? '' : ' · updated ${loaded.hour.toString().padLeft(2, '0')}:${loaded.minute.toString().padLeft(2, '0')}'}',
            style: theme.textTheme.bodySmall,
          ),
        ],
      ),
    );
  }
}

class _ErrorStrip extends StatelessWidget {
  const _ErrorStrip({required this.message, required this.provider});
  final String message;
  final NewsProvider provider;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.errorContainer,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          const Icon(Icons.error_outline),
          const SizedBox(width: 8),
          Expanded(child: Text(message, maxLines: 3)),
          TextButton(
            onPressed: () => provider.load(),
            child: const Text('Retry'),
          ),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.newspaper_rounded, size: 48),
            const SizedBox(height: 8),
            Text(
              'Koi news nahi mili — Rescan dabao',
              style: Theme.of(context).textTheme.bodyLarge,
            ),
          ],
        ),
      ),
    );
  }
}

class _DigestCard extends StatelessWidget {
  const _DigestCard({required this.items});
  final List<NewsItem> items;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      margin: EdgeInsets.zero,
      color: theme.colorScheme.primaryContainer.withValues(alpha: 0.3),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.bolt_rounded, size: 18),
                const SizedBox(width: 4),
                Text(
                  'Aaj ka digest — top ${items.length}',
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            for (final item in items)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 2),
                child: Text(
                  '${item.kind.emoji} ${item.matchedLine} — ${item.title}',
                  style: theme.textTheme.labelSmall,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _NewsCard extends StatefulWidget {
  const _NewsCard({required this.item});
  final NewsItem item;

  @override
  State<_NewsCard> createState() => _NewsCardState();
}

class _NewsCardState extends State<_NewsCard> {
  bool _researchOpen = false;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final item = widget.item;
    final published = item.publishedAt;
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Source + kind + time
            Row(
              children: [
                Text(item.kind.emoji, style: const TextStyle(fontSize: 14)),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    '${item.kind.label} · ${item.sourceLabel}',
                    style: theme.textTheme.labelSmall,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                if (published != null)
                  Text(
                    '${published.day.toString().padLeft(2, '0')}/'
                    '${published.month.toString().padLeft(2, '0')} '
                    '${published.hour.toString().padLeft(2, '0')}:'
                    '${published.minute.toString().padLeft(2, '0')}',
                    style: theme.textTheme.labelSmall,
                  ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              item.title,
              style: theme.textTheme.titleSmall?.copyWith(
                fontWeight: FontWeight.w700,
              ),
            ),
            if (item.body.isNotEmpty && item.body != item.title) ...[
              const SizedBox(height: 4),
              Text(
                item.body,
                style: theme.textTheme.bodySmall,
                maxLines: 4,
                overflow: TextOverflow.ellipsis,
              ),
            ],
            const SizedBox(height: 8),
            // Affected stocks + sector + direction
            Wrap(
              spacing: 6,
              runSpacing: 4,
              children: [
                for (final stock in item.affected.take(6))
                  Chip(
                    visualDensity: VisualDensity.compact,
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    label: Text(
                      '${stock.direction.emoji} ${stock.symbol}'
                      '${stock.sector.isEmpty ? '' : ' · ${stock.sector}'}',
                      style: theme.textTheme.labelSmall,
                    ),
                  ),
                if (item.affected.length > 6)
                  Text(
                    '+${item.affected.length - 6} aur',
                    style: theme.textTheme.labelSmall,
                  ),
              ],
            ),
            if (item.affected.isEmpty)
              Text(
                'Koi listed stock match nahi hua',
                style: theme.textTheme.labelSmall,
              ),
            if (item.research != null) ...[
              const SizedBox(height: 8),
              TextButton.icon(
                onPressed: () => setState(() => _researchOpen = !_researchOpen),
                icon: Icon(
                  _researchOpen ? Icons.expand_less : Icons.biotech_rounded,
                  size: 18,
                ),
                label: Text(
                  _researchOpen ? 'Deep research band karo' : 'Deep research',
                ),
              ),
              if (_researchOpen) _ResearchPanel(research: item.research!),
            ],
            if (item.link != null)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: SelectableText(
                  item.link!,
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: theme.colorScheme.primary,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _ResearchPanel extends StatelessWidget {
  const _ResearchPanel({required this.research});
  final DeepResearch research;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 4),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.4),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Most affected callout
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: theme.colorScheme.primaryContainer.withValues(alpha: 0.5),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Sabse zyada effect', style: theme.textTheme.labelSmall),
                Text(
                  research.mostAffectedReason,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          for (final stock in research.stocks) ...[
            _StockResearchBlock(stock: stock),
            const SizedBox(height: 8),
          ],
          const Divider(height: 1),
          const SizedBox(height: 6),
          Text(
            research.disclaimer,
            style: theme.textTheme.labelSmall?.copyWith(
              fontStyle: FontStyle.italic,
            ),
          ),
        ],
      ),
    );
  }
}

class _StockResearchBlock extends StatelessWidget {
  const _StockResearchBlock({required this.stock});
  final StockResearch stock;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final levels = stock.levels;
    final jodi = stock.jodi;
    String fmt(double? v) => v == null ? '—' : Fmt.price(v);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '▶ ${stock.symbol}',
          style: theme.textTheme.titleSmall?.copyWith(
            fontWeight: FontWeight.w700,
          ),
        ),
        if (stock.jodiSignalLabel.isNotEmpty) ...[
          const SizedBox(height: 2),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: stock.jodiAgrees
                  ? Colors.green.shade100
                  : theme.colorScheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              stock.jodiSignalLabel,
              style: theme.textTheme.labelSmall?.copyWith(
                fontWeight: FontWeight.w700,
                color: stock.jodiAgrees
                    ? Colors.green.shade900
                    : theme.colorScheme.onSurfaceVariant,
              ),
            ),
          ),
        ],
        const SizedBox(height: 2),
        Text(stock.suggestion, style: theme.textTheme.bodySmall),
        const SizedBox(height: 4),
        if (levels != null && levels.hasLevels)
          Text(
            'Entry ${fmt(levels.entry)} · SL ${fmt(levels.stop)} · '
            'Target ${fmt(levels.target)}  (${levels.basis})',
            style: theme.textTheme.labelSmall,
          ),
        if (jodi != null)
          Text(
            '${jodi.label}: ₹${jodi.premium.toStringAsFixed(1)} · '
            'break-even ${jodi.breakEvenLower.toStringAsFixed(0)}–'
            '${jodi.breakEvenUpper.toStringAsFixed(0)} · ${jodi.note} · ${jodi.ivStar}',
            style: theme.textTheme.labelSmall,
          ),
        Text(stock.dataNote, style: theme.textTheme.labelSmall),
      ],
    );
  }
}

/// Builds the screen's provider from the app-level singletons.
NewsProvider buildNewsProvider({
  required FnoStudyProvider study,
  required SettingsDao settings,
  required StockSuggestionService suggestions,
  MagicBasketProvider? baskets,
  FnoContractDao? contracts,
}) => NewsProvider(
  service: NewsService(),
  settings: settings,
  suggestions: suggestions,
  study: study,
  baskets: baskets,
  contracts: contracts,
);
