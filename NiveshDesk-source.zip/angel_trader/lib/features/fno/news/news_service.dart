// ---------------------------------------------------------------------------
// news_service.dart — phone-side fetchers for the News module (1.5.52).
//
// Sources (Option C hybrid):
//   1. Official NSE RSS feeds (announcements, corporate actions, circulars)
//   2. The official F&O ban CSV
//   3. Google News RSS (free, no key)
//   4. Public Telegram channel previews (t.me/s/<handle>) — the trusted
//      channels watch-list
//   5. The official NSE CM bhavcopy ZIP → daily OHLC for level plans
//
// Same transport rules as the rest of the app: browser-like UA, the NSE
// archives host + referer recipe, no cookies/tokens. Fetch failures are
// surfaced honestly — the caller shows what arrived and what did not.
// ---------------------------------------------------------------------------

import 'dart:convert';

import 'package:archive/archive.dart';
import 'package:http/http.dart' as http;

import 'news_parsers.dart';

class NewsFetchException implements Exception {
  NewsFetchException(this.message);
  final String message;
  @override
  String toString() => message;
}

class NewsService {
  NewsService({http.Client? client, DateTime Function()? clock})
      : _client = client ?? http.Client(),
        _clock = clock ?? DateTime.now;

  final http.Client _client;
  final DateTime Function() _clock;

  /// Browser-like UA — the NSE archives host refuses bare clients.
  static const Map<String, String> _headers = {
    'User-Agent':
        'Mozilla/5.0 (Linux; Android 13; K) AppleWebKit/537.36 '
        '(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml,text/csv,*/*',
    'Accept-Language': 'en-IN,en;q=0.9',
  };

  static const String _nseHost = 'nsearchives.nseindia.com';

  /// NSE corporate-information RSS feeds. Path names come from NSE's own
  /// RSS page; a feed that moves is skipped honestly (absence stays absence).
  static const List<({String path, String label})> nseRssFeeds = [
    (path: '/content/RSS/Online_announcements.xml', label: 'NSE announcement'),
    (path: '/content/RSS/Corporate_action.xml', label: 'NSE corporate action'),
    (path: '/content/RSS/Circulars.xml', label: 'NSE circular'),
    (path: '/content/RSS/Sast_Regulation29.xml', label: 'NSE SAST Reg-29'),
    (path: '/content/RSS/Board_Meetings.xml', label: 'NSE board meeting'),
    (path: '/content/RSS/Financial_results.xml', label: 'NSE results'),
  ];

  static const String foSecBanPath = '/content/fo/fo_secban.csv';

  // -- generic fetch --------------------------------------------------------

  Future<String> _getText(Uri uri, {String? referer}) async {
    final headers = {
      ..._headers,
      if (referer != null) 'Referer': 'https://$_nseHost$referer',
    };
    final response = await _client.get(uri, headers: headers);
    if (response.statusCode != 200) {
      throw NewsFetchException(
          '${uri.host}${uri.path} → HTTP ${response.statusCode}');
    }
    return response.body;
  }

  // -- official NSE feeds ---------------------------------------------------

  /// All NSE RSS items that parse. Individual feed failures are collected in
  /// [errors] instead of aborting the whole load.
  Future<({List<RssItem> items, List<String> errors})> fetchNseRss() async {
    final items = <RssItem>[];
    final errors = <String>[];
    for (final feed in nseRssFeeds) {
      try {
        final xml = await _getText(
          Uri.https(_nseHost, feed.path),
          referer: '/all-reports',
        );
        items.addAll(NewsParsers.parseRssFeed(xml, fallbackSource: feed.label));
      } catch (e) {
        errors.add('${feed.label}: $e');
      }
    }
    return (items: items, errors: errors);
  }

  /// The official F&O ban list — symbols in ban plus the trade date.
  Future<({List<String> symbols, DateTime? tradeDate, String? error})>
      fetchFoSecBan() async {
    try {
      final csv = await _getText(
        Uri.https(_nseHost, foSecBanPath),
        referer: '/all-reports',
      );
      final parsed = NewsParsers.parseFoSecBan(csv);
      return (symbols: parsed.symbols, tradeDate: parsed.tradeDate, error: null);
    } catch (e) {
      return (symbols: const <String>[], tradeDate: null, error: '$e');
    }
  }

  // -- Google News ----------------------------------------------------------

  /// Google News RSS — free, no key. [queries] are raw search strings;
  /// `when:1d` is appended when the caller wants just the latest day.
  Future<({List<RssItem> items, List<String> errors})> fetchGoogleNews(
      List<String> queries) async {
    final items = <RssItem>[];
    final errors = <String>[];
    for (final query in queries) {
      try {
        final uri = Uri.https('news.google.com', '/rss/search', {
          'q': query,
          'hl': 'en-IN',
          'gl': 'IN',
          'ceid': 'IN:en',
        });
        final xml = await _getText(uri);
        items.addAll(NewsParsers.parseRssFeed(xml, fallbackSource: 'Google News'));
      } catch (e) {
        errors.add('Google News "$query": $e');
      }
    }
    return (items: items, errors: errors);
  }

  // -- Telegram public channels --------------------------------------------

  /// Public channel preview — no login, no API. Only public channels work;
  /// private ones stay honest-missing.
  Future<({List<TelegramPost> posts, String? error})> fetchTelegramChannel(
      String handle) async {
    final clean = handle
        .replaceAll(RegExp(r'^https?://t\.me/'), '')
        .replaceAll(RegExp(r'^@'), '')
        .replaceAll(RegExp(r'^s/'), '')
        .trim();
    if (clean.isEmpty || !RegExp(r'^[A-Za-z0-9_]+$').hasMatch(clean)) {
      return (posts: const <TelegramPost>[], error: 'Invalid channel: $handle');
    }
    try {
      final html = await _getText(
          Uri.https('t.me', '/s/$clean'));
      final posts = NewsParsers.parseTelegramPreview(html);
      return (
        posts: posts,
        error: posts.isEmpty
            ? 'Koi post nahi mila (private ya band ho sakta hai)'
            : null,
      );
    } catch (e) {
      return (posts: const <TelegramPost>[], error: '$e');
    }
  }

  // -- official OHLC for level plans ---------------------------------------

  /// Latest official NSE CM bhavcopy as per-symbol daily OHLC. Walks back up
  /// to 14 calendar days (weekends/holidays) exactly like the scan does.
  Future<({Map<String, OhlcBar> bars, DateTime? tradeDate, String? error})>
      fetchDailyOhlc() async {
    Object? lastError;
    final today = DateTime(_clock().year, _clock().month, _clock().day);
    for (var offset = 0; offset < 14; offset++) {
      final date = today.subtract(Duration(days: offset));
      final dateKey = '${date.year}'
          '${date.month.toString().padLeft(2, '0')}'
          '${date.day.toString().padLeft(2, '0')}';
      final uri = Uri.https(
        _nseHost,
        '/content/cm/BhavCopy_NSE_CM_0_0_0_${dateKey}_F_0000.csv.zip',
      );
      try {
        final response = await _client.get(uri, headers: {
          ..._headers,
          'Referer': 'https://$_nseHost/all-reports',
        });
        if (response.statusCode != 200) {
          lastError = NewsFetchException('HTTP ${response.statusCode}');
          continue;
        }
        final archive = ZipDecoder().decodeBytes(response.bodyBytes);
        String? csv;
        for (final file in archive) {
          if (file.isFile && file.name.toLowerCase().endsWith('.csv')) {
            csv = utf8.decode(file.content as List<int>);
            break;
          }
        }
        if (csv == null) {
          lastError = NewsFetchException('ZIP me CSV nahi');
          continue;
        }
        final bars = NewsParsers.parseBhavcopyOhlc(csv);
        if (bars.isEmpty) {
          lastError = NewsFetchException('Bhavcopy me rows nahi');
          continue;
        }
        return (bars: bars, tradeDate: date, error: null);
      } catch (e) {
        lastError = e;
      }
    }
    return (
      bars: const <String, OhlcBar>{},
      tradeDate: null,
      error: '${lastError ?? 'Bhavcopy nahi mila'}',
    );
  }
}
