// ---------------------------------------------------------------------------
// news_provider.dart — orchestrates the News module (1.5.52).
//
// Loads official feeds + Google News + the Telegram watch-list + the F&O ban
// file, matches every item to the stocks it touches, classifies the effect,
// and (where official price data exists) builds the deep-research payload.
// All maths lives in news_rules.dart — this class only coordinates.
// ---------------------------------------------------------------------------

import 'package:flutter/foundation.dart';

import '../../../data/local/dao/fno_contract_dao.dart';
import '../../../data/local/dao/settings_dao.dart';
import '../../../services/stock_suggestion_service.dart';
import '../../magic_formula/magic_basket_provider.dart';
import '../study/fno_study_provider.dart';
import '../study/study_engine.dart';
import 'news_models.dart';
import 'news_rules.dart';
import 'news_sector_map.dart';
import 'news_service.dart';
import 'news_signals.dart';

/// Feed filter chips (1.5.55 basket; 1.5.68 F&O).
enum NewsFeedScope { all, basket, fno }

/// Pure filter behind the three chips — screen se alag, testable.
///
/// `all` = poora feed; `basket` = jin items ke affected stocks basket me hain;
/// `fno` = jin items ke affected stocks **F&O segment** ke hain (contract
/// book / 3-Month Study universe). Symbol sets empty hon to list honestly
/// khaali — koi fake match nahi.
List<NewsItem> visibleNewsFor(
  List<NewsItem> items,
  NewsFeedScope scope,
  Set<String> basketSymbols,
  Set<String> fnoSymbols,
) {
  switch (scope) {
    case NewsFeedScope.all:
      return items;
    case NewsFeedScope.basket:
      return [
        for (final item in items)
          if (item.affected.any(
              (stock) => basketSymbols.contains(stock.symbol.toUpperCase())))
            item,
      ];
    case NewsFeedScope.fno:
      return [
        for (final item in items)
          if (item.affected.any(
              (stock) => fnoSymbols.contains(stock.symbol.toUpperCase())))
            item,
      ];
  }
}

class NewsProvider extends ChangeNotifier {
  NewsProvider({
    required NewsService service,
    required SettingsDao settings,
    required StockSuggestionService suggestions,
    required FnoStudyProvider study,
    MagicBasketProvider? baskets,
    FnoContractDao? contracts,
  })  : _service = service,
        _settings = settings,
        _suggestions = suggestions,
        _study = study,
        _baskets = baskets,
        _contracts = contracts;

  final NewsService _service;
  final SettingsDao _settings;
  final StockSuggestionService _suggestions;
  final FnoStudyProvider _study;
  final MagicBasketProvider? _baskets;
  final FnoContractDao? _contracts;

  static const String _channelsKey = 'news_tg_channels';

  /// Preset watch-list — the channel the user asked for by name.
  static const List<String> presetChannels = ['Stock_aaj_or_kal'];

  static const int maxItems = 80;

  static const List<String> googleQueries = [
    'Indian stock market when:1d',
    'NSE BSE results when:1d',
    'share market India when:1d',
  ];

  // -- state ----------------------------------------------------------------

  List<NewsItem> items = const [];

  /// Aaj ka digest — top-5 by the rule-based digest score (1.5.55).
  List<NewsItem> digest = const [];
  List<String> errors = const [];
  List<String> channels = presetChannels;
  bool isRunning = false;
  bool loadedOnce = false;
  DateTime? lastLoadedAt;
  String? error;

  /// Feed filter (1.5.55 basket; 1.5.68 F&O) — 3 chips: Sabhi / Basket / F&O.
  NewsFeedScope scope = NewsFeedScope.all;
  Set<String> mySymbols = const {};

  /// F&O stocks — contract book underlyings ∪ 3-Month Study rows (wahi
  /// universe jo news matching already use karta hai). Empty = filter list
  /// honestly missing, fake list kabhi nahi.
  Set<String> fnoSymbols = const {};

  /// The feed the UI shows — [visibleNewsFor] karta hai asli filtering.
  List<NewsItem> get visibleItems =>
      visibleNewsFor(items, scope, mySymbols, fnoSymbols);

  void setScope(NewsFeedScope value) {
    scope = value;
    notifyListeners();
  }

  /// Loads the symbol sets for the "Mere stocks" (basket) and "F&O stocks"
  /// filters.
  Future<void> loadMyStocks() async {
    final baskets = _baskets;
    if (baskets != null) {
      mySymbols = await baskets.allMemberSymbols();
    }
    final fno = <String>{};
    final contracts = _contracts;
    if (contracts != null) {
      try {
        fno.addAll(
          (await contracts.allUnderlyings()).map((s) => s.toUpperCase()),
        );
      } catch (_) {
        // Book unreadable = F&O list honestly missing; study rows below may
        // still fill it.
      }
    }
    for (final row in _study.allRows) {
      fno.add(row.symbol.toUpperCase());
    }
    fnoSymbols = fno;
    notifyListeners();
  }

  // -- watch-list -----------------------------------------------------------

  Future<void> loadChannels() async {
    try {
      final map = await _settings.raw();
      final raw = map['news_tg_channels'];
      if (raw != null && raw.trim().isNotEmpty) {
        channels = raw
            .split(',')
            .map((h) => h.trim())
            .where((h) => h.isNotEmpty)
            .toList();
      }
    } catch (_) {
      channels = presetChannels;
    }
    if (channels.isEmpty) channels = presetChannels;
    notifyListeners();
  }

  Future<void> addChannel(String handle) async {
    final clean = handle
        .replaceAll(RegExp(r'^https?://t\.me/'), '')
        .replaceAll(RegExp(r'^@'), '')
        .trim();
    if (clean.isEmpty || channels.contains(clean)) return;
    channels = [...channels, clean];
    await _persistChannels();
    notifyListeners();
  }

  Future<void> removeChannel(String handle) async {
    channels = channels.where((h) => h != handle).toList();
    if (channels.isEmpty) channels = presetChannels;
    await _persistChannels();
    notifyListeners();
  }

  Future<void> _persistChannels() async {
    try {
      await _settings.put(_channelsKey, channels.join(','));
    } catch (_) {
      // Persistence is a convenience — the list still works for this session.
    }
  }

  // -- load -----------------------------------------------------------------

  /// Full load: feeds + matching + deep research. Returns false on a hard
  /// failure; soft per-source failures land in [errors] and the feed still
  /// shows whatever arrived.
  Future<bool> load() async {
    if (isRunning) return false;
    isRunning = true;
    error = null;
    notifyListeners();

    final loadErrors = <String>[];
    final rawItems = <_RawNews>[];
    try {
      // 1. Official NSE RSS.
      final nse = await _service.fetchNseRss();
      loadErrors.addAll(nse.errors);
      for (final item in nse.items) {
        rawItems.add(_RawNews(
          title: item.title,
          body: item.description,
          link: item.link,
          published: item.published,
          sourceLabel: item.sourceLabel,
          kind: _officialKind(item.sourceLabel),
        ));
      }

      // 2. F&O ban list.
      final ban = await _service.fetchFoSecBan();
      if (ban.error != null) loadErrors.add('F&O ban: ${ban.error}');
      if (ban.symbols.isNotEmpty) {
        final dateLabel = ban.tradeDate == null
            ? ''
            : ' (${ban.tradeDate!.day.toString().padLeft(2, '0')}-'
                '${_monthShort(ban.tradeDate!.month)}-${ban.tradeDate!.year})';
        rawItems.add(_RawNews(
          title:
              'F&O ban list$dateLabel — ${ban.symbols.length} securities in ban',
          body: 'MWPL 95% cross: ${ban.symbols.join(', ')}. '
              'Ban me sirf position kam ho sakti hai — naye F&O position nahi.',
          link: 'https://www.nseindia.com/products-services/'
              'equity-derivatives-risk-management-sec-ban',
          published: ban.tradeDate,
          sourceLabel: 'NSE official',
          kind: NewsKind.foBan,
          banSymbols: ban.symbols,
        ));
      }

      // 3. Google News.
      final google = await _service.fetchGoogleNews(googleQueries);
      loadErrors.addAll(google.errors);
      for (final item in google.items) {
        rawItems.add(_RawNews(
          title: item.title,
          body: item.description,
          link: item.link,
          published: item.published,
          sourceLabel: item.sourceLabel.isEmpty
              ? 'Google News'
              : 'Google News · ${item.sourceLabel}',
          kind: NewsKind.headline,
        ));
      }

      // 4. Telegram watch-list.
      for (final channel in channels) {
        final tg = await _service.fetchTelegramChannel(channel);
        if (tg.error != null) loadErrors.add('tg @$channel: ${tg.error}');
        for (final post in tg.posts) {
          rawItems.add(_RawNews(
            title: _telegramTitle(post.text),
            body: post.text,
            link: post.link,
            published: post.published,
            sourceLabel: 'tg: $channel',
            kind: NewsKind.telegram,
          ));
        }
      }

      // 5. Official OHLC for level plans.
      final ohlc = await _service.fetchDailyOhlc();
      if (ohlc.error != null) loadErrors.add('Bhavcopy OHLC: ${ohlc.error}');

      // 6. Matching universe + study rows.
      final universe = await _buildUniverse();
      final matcher = NewsMatcher(universe.values.toList());
      final rowBySymbol = {
        for (final row in _study.allRows) row.symbol.toUpperCase(): row,
      };

      // 7. Match + research + sort.
      final built = <NewsItem>[];
      final seenTitles = <String>{};
      for (final raw in rawItems) {
        try {
          final dedupeKey =
              '${raw.title.toUpperCase()}|${raw.published?.day}';
          if (!seenTitles.add(dedupeKey)) continue;

          final text = '${raw.title} ${raw.body}';
          List<AffectedStock> affected;
          if (raw.banSymbols != null) {
            affected = [
              for (final symbol in raw.banSymbols!)
                AffectedStock(
                  symbol: symbol,
                  companyName: universe[symbol]?.companyName ?? symbol,
                  sector: sectorFor(symbol),
                  direction: EffectDirection.mixed,
                  reason: 'MWPL 95% cross — F&O ban',
                  isFno: universe[symbol]?.isFno ?? true,
                  impactScore: universe[symbol]?.isFno ?? true ? 3 : 1,
                ),
            ];
            affected =
                NewsRules.rankAffected(title: raw.title, matched: affected);
          } else {
            final matched = matcher.match(text);
            affected = NewsRules.rankAffected(
              title: raw.title,
              matched: matched,
            );
          }

        DeepResearch? research;
        if (affected.isNotEmpty) {
          final levelsBySymbol = <String,
              ({double? high, double? low, double? atr})>{};
          final jodiBySymbol = <String, JodiIdea?>{};
          final dataNotes = <String, String>{};
          final jodiSignals =
              <String, ({bool agrees, String label})>{};
          for (final stock in affected) {
            final bar = ohlc.bars[stock.symbol];
            final row = rowBySymbol[stock.symbol];
            levelsBySymbol[stock.symbol] = (
              high: bar?.high,
              low: bar?.low,
              atr: row?.atr,
            );
            final highImpact = stock.impactScore >= 4;
            jodiBySymbol[stock.symbol] = NewsRules.buildJodiIdea(
              isFno: stock.isFno,
              highImpact: highImpact,
              atmStrike: row?.atmStrike,
              ceLtp: row?.ce?.ltp,
              peLtp: row?.pe?.ltp,
              stranglePeStrike: row?.strangle?.pe?.strike,
              strangleCeStrike: row?.strangle?.ce?.strike,
              strangleTotal: row?.strangle?.total,
              ivRank: row?.ivRank ?? IvRank.unknown,
            );
            // News × Jodi cross-signal (1.5.55) — engine verdict for the
            // stock while this news is fresh.
            if (row != null) {
              jodiSignals[stock.symbol] = NewsSignalsRules.jodiSignal(
                isFno: true,
                ltp: row.ltp,
                atr: row.atr,
                avgDailyMove15: row.avgDailyMove15,
                monthlyRangePcts: [
                  for (final month in row.months) month.rangePct,
                ],
                atmJodiPrice: (row.ce?.ltp != null && row.pe?.ltp != null)
                    ? row.ce!.ltp! + row.pe!.ltp!
                    : null,
                otmJodiPrice: row.strangle?.total,
              );
            }
            dataNotes[stock.symbol] = bar == null
                ? 'Price data nahi — direction only'
                : row != null
                    ? 'Levels: bhavcopy H/L + study ATR · jodi: live premium'
                    : 'Levels: bhavcopy H/L + session-range proxy (ATR nahi)';
          }
          research = NewsRules.buildResearch(
            title: raw.title,
            ranked: affected,
            levelsBySymbol: levelsBySymbol,
            jodiBySymbol: jodiBySymbol,
            dataNotes: dataNotes,
            jodiSignals: jodiSignals,
          );
        }

        built.add(NewsItem(
          id: '${raw.sourceLabel}|${raw.link ?? raw.title}',
          publishedAt: raw.published,
          title: raw.title,
          body: raw.body,
          kind: raw.kind,
          sourceLabel: raw.sourceLabel,
          link: raw.link,
          affected: affected,
          research: research,
        ));
        } catch (_) {
          // Ek kharab item poora feed nahi rokega — skip karke aage badho.
          continue;
        }
      }

      built.sort((a, b) {
        final at = a.publishedAt ?? DateTime.fromMillisecondsSinceEpoch(0);
        final bt = b.publishedAt ?? DateTime.fromMillisecondsSinceEpoch(0);
        return bt.compareTo(at);
      });

      items = built.length > maxItems
          ? built.sublist(0, maxItems)
          : List.unmodifiable(built);

      // Aaj ka digest — top-5 by the rule-based score (1.5.55).
      final scored = <NewsItem, int>{};
      for (final item in items) {
        var maxImpact = 0;
        for (final stock in item.affected) {
          if (stock.impactScore > maxImpact) maxImpact = stock.impactScore;
        }
        scored[item] = NewsSignalsRules.digestScore(
          maxImpact: maxImpact,
          kind: item.kind,
          published: item.publishedAt,
          now: DateTime.now(),
        );
      }
      final rankedDigest = scored.keys.toList()
        ..sort((a, b) => (scored[b] ?? 0).compareTo(scored[a] ?? 0));
      digest = List.unmodifiable(
        rankedDigest.take(5).toList(growable: false),
      );

      // Cross-module chips for AI Jodi Study (1.5.55).
      NewsSignals.instance.updateFrom(items);

      errors = List.unmodifiable(loadErrors);
      lastLoadedAt = DateTime.now();
      loadedOnce = true;
      isRunning = false;
      notifyListeners();
      return true;
    } catch (e) {
      error = '$e';
      errors = List.unmodifiable(loadErrors);
      isRunning = false;
      loadedOnce = true;
      notifyListeners();
      return false;
    }
  }

  // -- helpers --------------------------------------------------------------

  Future<Map<String, StockRef>> _buildUniverse() async {
    final out = <String, StockRef>{};
    final fnoSymbols = {
      for (final row in _study.allRows) row.symbol.toUpperCase(),
    };
    try {
      final master = await _suggestions.master();
      for (final stock in master) {
        final symbol = stock.symbol.toUpperCase();
        if (symbol.isEmpty || out.containsKey(symbol)) continue;
        out[symbol] = StockRef(
          symbol: symbol,
          companyName: stock.companyName,
          sector: sectorFor(symbol),
          isFno: fnoSymbols.contains(symbol),
        );
      }
    } catch (_) {
      // Master unavailable → fall back to the study rows only (honest).
    }
    for (final symbol in fnoSymbols) {
      out.putIfAbsent(
        symbol,
        () => StockRef(
          symbol: symbol,
          companyName: symbol,
          sector: sectorFor(symbol),
          isFno: true,
        ),
      );
    }
    return out;
  }

  static NewsKind _officialKind(String label) {
    final lower = label.toLowerCase();
    if (lower.contains('corporate action')) return NewsKind.corporateAction;
    if (lower.contains('board meeting')) return NewsKind.boardMeeting;
    if (lower.contains('results')) return NewsKind.results;
    return NewsKind.announcement;
  }

  static String _telegramTitle(String text) {
    final firstLine =
        text.split('\n').map((l) => l.trim()).firstWhere((l) => l.isNotEmpty,
            orElse: () => text);
    return firstLine.length > 90 ? '${firstLine.substring(0, 90)}…' : firstLine;
  }

  static String _monthShort(int month) => const [
        'JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN',
        'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC',
      ][month - 1];
}

/// Internal carry type between fetch and build stages.
class _RawNews {
  const _RawNews({
    required this.title,
    required this.body,
    required this.link,
    required this.published,
    required this.sourceLabel,
    required this.kind,
    this.banSymbols,
  });

  final String title;
  final String body;
  final String? link;
  final DateTime? published;
  final String sourceLabel;
  final NewsKind kind;
  final List<String>? banSymbols;
}
