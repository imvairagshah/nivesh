// ---------------------------------------------------------------------------
// news_models.dart — plain data types for the F&O News module (1.5.52).
//
// One news item arrives from an official feed, a Google News headline, or a
// public Telegram channel; the engine attaches the stocks it can match, the
// direction the rules see, and (where price data exists) a deep-research
// panel. Every optional number stays nullable — absence is absence, never a
// guess.
// ---------------------------------------------------------------------------

import 'package:flutter/foundation.dart';

/// Where a news item came from. The label is shown on the card so the user
/// always knows whose word it is.
enum NewsKind {
  announcement('Announcement', '📄'),
  boardMeeting('Board meeting', '🗓️'),
  corporateAction('Corporate action', '💰'),
  results('Results', '📊'),
  foBan('F&O ban', '🚫'),
  headline('Headline', '📰'),
  telegram('Telegram', '✈️');

  const NewsKind(this.label, this.emoji);

  final String label;
  final String emoji;
}

/// Rule-based effect direction. Never a promise — just what the keywords say.
enum EffectDirection {
  positive('Positive', '🟢'),
  negative('Negative', '🔴'),
  mixed('Mixed', '⚪'),
  unknown('Pata nahi', '❔');

  const EffectDirection(this.label, this.emoji);

  final String label;
  final String emoji;
}

/// One stock the news touches.
@immutable
class AffectedStock {
  const AffectedStock({
    required this.symbol,
    required this.companyName,
    required this.sector,
    required this.direction,
    required this.reason,
    required this.isFno,
    required this.impactScore,
  });

  final String symbol;
  final String companyName;

  /// Curated sector label — `''` when we genuinely do not know (honest '—').
  final String sector;

  final EffectDirection direction;

  /// Why the engine thinks this stock is affected — printed as-is.
  final String reason;

  /// Whether the name is in the F&O universe (options jodi only possible here).
  final bool isFno;

  /// Ranking score — bigger means the news hits this stock harder.
  final int impactScore;

  AffectedStock copyWith({EffectDirection? direction, String? reason, int? impactScore}) =>
      AffectedStock(
        symbol: symbol,
        companyName: companyName,
        sector: sector,
        direction: direction ?? this.direction,
        reason: reason ?? this.reason,
        isFno: isFno,
        impactScore: impactScore ?? this.impactScore,
      );
}

/// Entry / exit levels from the last session's official high/low + ATR.
/// Nulls mean the data is not there — the UI prints '—', never a number.
@immutable
class TradePlanLevels {
  const TradePlanLevels({
    required this.direction,
    this.entry,
    this.stop,
    this.target,
    required this.basis,
  });

  final EffectDirection direction;
  final double? entry;
  final double? stop;
  final double? target;

  /// Human label for where the numbers came from — always shown.
  final String basis;

  bool get hasLevels => entry != null && stop != null;
}

/// The "jodi long" idea for a high-impact news stock (options only).
@immutable
class JodiIdea {
  const JodiIdea({
    required this.label,
    required this.premium,
    required this.breakEvenLower,
    required this.breakEvenUpper,
    required this.ivStar,
    required this.note,
  });

  final String label;
  final double premium;
  final double breakEvenLower;
  final double breakEvenUpper;
  final String ivStar;

  /// Rule the strikes came from — never a promise about the price.
  final String note;
}

/// Deep-research payload for one stock.
@immutable
class StockResearch {
  const StockResearch({
    required this.symbol,
    required this.suggestion,
    required this.levels,
    required this.jodi,
    required this.dataNote,
    this.jodiAgrees = false,
    this.jodiSignalLabel = '',
  });

  final String symbol;

  /// The "AI suggestion" field — rule-based plan text (Hinglish).
  final String suggestion;

  final TradePlanLevels? levels;
  final JodiIdea? jodi;

  /// What data was / was not available — honest label.
  final String dataNote;

  /// News × Jodi cross-signal (1.5.55): true when the offline jodi engine
  /// currently gives this stock a buy verdict (ATM/OTM, 2× cover).
  final bool jodiAgrees;

  /// Human label for the cross-signal — empty when not applicable.
  final String jodiSignalLabel;
}

/// Everything the "Deep research" link opens.
@immutable
class DeepResearch {
  const DeepResearch({
    required this.mostAffectedSymbol,
    required this.mostAffectedReason,
    required this.stocks,
    required this.disclaimer,
  });

  final String? mostAffectedSymbol;
  final String mostAffectedReason;
  final List<StockResearch> stocks;
  final String disclaimer;
}

/// One news card in the feed.
@immutable
class NewsItem {
  const NewsItem({
    required this.id,
    required this.publishedAt,
    required this.title,
    required this.body,
    required this.kind,
    required this.sourceLabel,
    this.link,
    required this.affected,
    this.research,
  });

  final String id;
  final DateTime? publishedAt;
  final String title;
  final String body;
  final NewsKind kind;

  /// Attribution — 'NSE RSS', 'Google News', 'tg: Stock_aaj_or_kal' …
  final String sourceLabel;
  final String? link;

  final List<AffectedStock> affected;
  final DeepResearch? research;

  String get matchedLine => affected.isEmpty
      ? 'Koi stock match nahi hua'
      : affected
          .map((a) => '${a.direction.emoji} ${a.symbol}')
          .join(' · ');
}
