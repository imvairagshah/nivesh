// ---------------------------------------------------------------------------
// news_signals.dart — tiny in-memory bridge between News and AI Jodi (1.5.55).
//
// After every news load the provider writes per-symbol high-impact signals
// here; the AI Jodi table reads them to show the 📰 / 🔥 News+Jodi chips.
// Session-only by design — no phone state is invented if News was never
// opened (the chip simply does not show).
// ---------------------------------------------------------------------------

import 'package:flutter/foundation.dart';

import 'news_models.dart';

@immutable
class NewsSignal {
  const NewsSignal({
    required this.highImpactCount,
    required this.topHeadline,
    required this.latestAt,
  });

  /// How many high-impact news items touched this symbol in the window.
  final int highImpactCount;

  /// The strongest headline — shown in the jodi detail on tap.
  final String topHeadline;

  final DateTime? latestAt;
}

class NewsSignals {
  NewsSignals._();

  static final NewsSignals instance = NewsSignals._();

  /// Signals older than this are ignored (stale news is not a signal).
  static const Duration window = Duration(hours: 48);

  DateTime? updatedAt;
  final Map<String, NewsSignal> bySymbol = {};

  NewsSignal? forSymbol(String symbol) => bySymbol[symbol.toUpperCase()];

  /// Rebuilds the map from a loaded feed. High-impact = the engine's impact
  /// score reached the "most affected" band (>= 4) for that symbol.
  void updateFrom(List<NewsItem> items, {DateTime? now}) {
    final clock = now ?? DateTime.now();
    bySymbol.clear();
    for (final item in items) {
      final published = item.publishedAt;
      if (published == null) continue;
      if (clock.difference(published) > window) continue;
      for (final stock in item.affected) {
        if (stock.impactScore < 4) continue;
        final key = stock.symbol.toUpperCase();
        final existing = bySymbol[key];
        bySymbol[key] = NewsSignal(
          highImpactCount: (existing?.highImpactCount ?? 0) + 1,
          topHeadline: existing == null
              ? item.title
              : (stock.impactScore >= 4 ? item.title : existing.topHeadline),
          latestAt: published.isAfter(existing?.latestAt ?? published)
              ? published
              : (existing?.latestAt ?? published),
        );
      }
    }
    updatedAt = clock;
  }

  void clear() {
    bySymbol.clear();
    updatedAt = null;
  }
}
