// ---------------------------------------------------------------------------
// ai_export.dart — XLSX / CSV / text recap for the AI Suggestion list.
//
// Same shape as the 3-Month Study's exporter (one column list, one Read Me
// sheet, one Hinglish recap) so a file from either tool reads the same way in
// Excel or in a messaging app.
//
// What is deliberately in here: the *risk* columns too — result date and the
// strategy's own "kyu" line. A list that can be forwarded must carry the reason
// and the warning with it, not just the ticker.
// ---------------------------------------------------------------------------

import 'dart:io';

import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';

import 'ai_suggestion.dart';

/// Header block the export needs — separate from the result so a filtered list
/// can be exported with honest counts.
class AiExportMeta {
  const AiExportMeta({
    required this.asOf,
    required this.runAt,
    required this.rowCount,
    required this.withOptions,
    required this.filters,
    this.funnel = '',
  });

  final DateTime asOf;
  final DateTime runAt;
  final int rowCount;
  final int withOptions;

  /// The thresholds the list obeys — printed in the Read Me so a file can be
  /// checked against the rules that produced it.
  final AiFilters filters;
  final String funnel;
}

class AiExportService {
  AiExportService();

  static const String disclaimer =
      'Ye list sirf analysis ke liye hai. Ye buy/sell recommendation nahi hai — '
      'trading se pehle khud verify karo. Options me nuksan bada ho sakta hai.';

  /// Column headers — index order is shared by every writer.
  static const List<String> headers = [
    'Rank',
    'Symbol',
    'Company',
    'CMP',
    'RSI(14)',
    'ATR %',
    'Avg Range %',
    'Volume (x)',
    '52w high se %',
    'Turnover (Rs cr)',
    'Score',
    'Study score',
    'Pattern',
    'Direction',
    'Expected movement',
    'Technical rationale',
    'Result date',
    'Result in days',
    'Action',
    'Strategy',
    'Strike type',
    'Suggested jodi',
    'IV %',
    'Jodi total (Rs)',
    'Lot size',
    'Kyu (strategy)',
  ];

  static String money(num? value, {int decimals = 2}) =>
      value == null ? '—' : value.toStringAsFixed(decimals);

  static String isoDate(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-'
      '${d.month.toString().padLeft(2, '0')}-'
      '${d.day.toString().padLeft(2, '0')}';

  static String defaultFileName(DateTime asOf) =>
      'NiveshDesk_AI_Suggestion_${isoDate(asOf)}.xlsx';

  static String csvFileName(DateTime asOf) =>
      'NiveshDesk_AI_Suggestion_${isoDate(asOf)}.csv';

  /// The cells for one idea, in [headers] order.
  static List<String> rowCells(AiSuggestion row, DateTime today) {
    final snap = row.snapshot;
    final options = row.options;
    final days = row.resultDate == null || !row.resultConfirmed
        ? '—'
        : '${DateTime(row.resultDate!.year, row.resultDate!.month, row.resultDate!.day)
            .difference(DateTime(today.year, today.month, today.day))
            .inDays}';

    return [
      '${row.rank}',
      row.symbol,
      row.name,
      money(snap.ltp),
      snap.rsi.toStringAsFixed(0),
      snap.atrPct.toStringAsFixed(2),
      snap.avgRangePct.toStringAsFixed(2),
      '${snap.volumeRatio.toStringAsFixed(1)}x',
      snap.fromHighPct.toStringAsFixed(2),
      snap.turnoverCrore.toStringAsFixed(1),
      row.score.toStringAsFixed(0),
      row.studyScore.toStringAsFixed(1),
      row.pattern.label,
      row.direction.label,
      row.move.label,
      row.rationaleLine,
      row.resultDate == null ? '—' : isoDate(row.resultDate!),
      days,
      row.strategy.action,
      row.strategy.name,
      row.strategy.strikeType,
      row.strategy.pair,
      options?.avgIv == null ? '—' : options!.avgIv!.toStringAsFixed(1),
      options?.straddleTotal == null
          ? '—'
          : options!.straddleTotal!.toStringAsFixed(2),
      options == null || options.lotSize == 0 ? '—' : '${options.lotSize}',
      row.strategy.why,
    ];
  }

  /// Sheet 1: what this file is, and the rules that produced it.
  List<List<String>> readMeSheet(AiExportMeta meta) => [
        ['NiveshDesk — F&O AI Suggestion'],
        ['Study date', isoDate(meta.asOf)],
        ['Banaya', isoDate(meta.runAt)],
        ['Ideas', '${meta.rowCount}'],
        ['Option jodi ke saath', '${meta.withOptions}'],
        [if (meta.funnel.isNotEmpty) 'Funnel', if (meta.funnel.isNotEmpty) meta.funnel],
        [],
        ['Filter (jo bhi list me hai, inhi niyamon se aaya hai)'],
        ['Min 3-month study score', meta.filters.minStudyScore.toStringAsFixed(1)],
        ['Min momentum score', meta.filters.minScore.toStringAsFixed(0)],
        ['Min turnover (Rs cr/day)', meta.filters.minTurnoverCrore.toStringAsFixed(0)],
        ['RSI oversold / overbought',
            '${meta.filters.rsiOversold.toStringAsFixed(0)} / ${meta.filters.rsiOverbought.toStringAsFixed(0)}'],
        ['Volume spike', '${meta.filters.volumeSpike.toStringAsFixed(1)}x'],
        ['52w high se doori', '${meta.filters.nearHighPct.toStringAsFixed(0)}%'],
        ['Result ki chhutti (din)', '${meta.filters.eventBlockDays}'],
        ['Top N', '${meta.filters.topN}'],
        [],
        ['Kaise banta hai'],
        ['1', 'Har F&O stock ke candles se RSI, 9/21 EMA, 50 DMA, ATR, volume aur '
            '52-week high/low.'],
        ['2', 'Pattern (breakout / breakdown / pullback / bounce / range / '
            'overbought / oversold) aur momentum score (0-100).'],
        ['3', '3-Month Study ka score gate, turnover (liquidity) gate, phir top N.'],
        ['4', 'Sirf un top N ke liye option ki jodi: ATM pair + OTM pair local '
            'contract book se; premium ek batched quote se; IV premium se '
            'Black-Scholes se solve.'],
        ['5', 'Result date NSE ke board-meeting feed se (sirf confirm date, koi '
            'andaza nahi). Result paas ho to nayi position nahi — IV crush aur '
            'gap ka jokhim.'],
        [],
        [disclaimer],
      ];

  Future<File> writeXlsx({
    required List<AiSuggestion> rows,
    required AiExportMeta meta,
    DateTime? today,
    String? fileName,
  }) async {
    final day = today ?? meta.asOf;
    final book = Excel.createExcel();

    final readMe = book['Read Me'];
    for (final line in readMeSheet(meta)) {
      readMe.appendRow([for (final cell in line) TextCellValue(cell)]);
    }

    final all = book['Ideas'];
    all.appendRow([for (final header in headers) TextCellValue(header)]);
    for (final row in rows) {
      all.appendRow([for (final cell in rowCells(row, day)) TextCellValue(cell)]);
    }

    // `createExcel()` ships a default sheet; the Read Me replaces it.
    if (book.sheets.containsKey('Sheet1')) book.delete('Sheet1');

    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/${fileName ?? defaultFileName(meta.asOf)}');
    await file.writeAsBytes(book.encode()!, flush: true);
    return file;
  }

  Future<File> writeCsv({
    required List<AiSuggestion> rows,
    required AiExportMeta meta,
    DateTime? today,
    String? fileName,
  }) async {
    final day = today ?? meta.asOf;
    final buffer = StringBuffer()
      ..writeln('# NiveshDesk F&O — AI Suggestion (${isoDate(meta.asOf)})')
      ..writeln('# $disclaimer')
      ..writeln(headers.map(_csv).join(','));

    for (final row in rows) {
      buffer.writeln(rowCells(row, day).map(_csv).join(','));
    }

    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/${fileName ?? csvFileName(meta.asOf)}');
    await file.writeAsString(buffer.toString(), flush: true);
    return file;
  }

  /// Short Hinglish summary that reads fine in a messaging app.
  static String recap(List<AiSuggestion> rows, AiExportMeta meta) {
    final buffer = StringBuffer()
      ..writeln('*NiveshDesk — F&O AI Suggestion*')
      ..writeln('Data: ${isoDate(meta.asOf)} · ideas: ${rows.length}')
      ..writeln();

    for (final row in rows.take(8)) {
      buffer.writeln('${row.rank}. ${row.symbol} — ${row.direction.label} '
          '(${row.move.label}) · score ${row.score.toStringAsFixed(0)}');
      buffer.writeln('   CMP ${money(row.snapshot.ltp)} · ${row.rationaleLine}');
      buffer.writeln('   ${row.strategy.action} ${row.strategy.name} — '
          '${row.strategy.pair} (${row.strategy.strikeType})');
      final line = row.resultLine(meta.asOf);
      if (line.isNotEmpty) buffer.writeln('   $line');
    }

    buffer
      ..writeln()
      ..writeln(disclaimer);
    return buffer.toString();
  }

  static String _csv(String value) {
    final needsQuotes =
        value.contains(',') || value.contains('"') || value.contains('\n');
    final escaped = value.replaceAll('"', '""');
    return needsQuotes ? '"$escaped"' : escaped;
  }
}
