// ---------------------------------------------------------------------------
// ai_backtest.dart — "ye rule kitni baar sahi pada?" (the hit-rate report).
//
// The AI Suggestion engine is a rule engine, so a rule can be *counted*. This
// file replays the very same signals over history and reports what would have
// happened — nothing more. It is deliberately honest about what it cannot do:
//
//   1. NO LOOK-AHEAD. The signal on bar `i` only ever sees bars 0…i, and the
//      trade is entered at the **next session's open** (you cannot act on a
//      close you have not seen yet).
//   2. UNDERLYING, NOT OPTION. The app has no historical option premiums, so
//      every number here is the stock's own move. An option's P/L also carries
//      theta and IV — this report never claims to be that.
//   3. NO COSTS. Brokerage, STT, GST, slippage and bid-ask are NOT included.
//      A 1.8 % average is therefore an upper bound, and the screen says so.
//   4. SMALL SAMPLES ARE FLAGGED, never dressed up. Fewer than ~30 trades is
//      noise, and the report calls it noise.
//   5. AMBIGUITY IS RESOLVED AGAINST THE TRADE: if a bar could have hit both
//      the stop and the target, the stop is assumed (the pessimistic read).
//
// Pure: no Flutter, no database, no network — the whole thing is unit-tested
// against hand-built candles whose outcome you can check by eye.
// ---------------------------------------------------------------------------

import '../../../data/remote/dto/candle.dart';
import 'ai_indicators.dart';
import 'ai_suggestion.dart';

/// How a replayed trade ended.
enum BtExit {
  /// The target was touched inside the horizon — the plan's own 1 : 2.
  target,

  /// The stop was touched first.
  stop,

  /// Neither level was touched; the position was marked at the horizon.
  horizon;

  String get hinglish => switch (this) {
        BtExit.target => 'target laga',
        BtExit.stop => 'stop laga',
        BtExit.horizon => 'samay khatam',
      };
}

/// What the replay does, and the knobs the user can turn.
///
/// Defaults match the live plan (ai_plan.dart): risk = 1 ATR, target = 2 × risk,
/// 10 sessions to work, and the same RSI / volume thresholds the scan uses.
class BtConfig {
  const BtConfig({
    this.horizonBars = 10,
    this.atrMultiple = 1,
    this.rewardMultiple = 2,
    this.warmupBars = 60,
    this.volumeSpike = 1.5,
    this.oversold = 35,
    this.overbought = 65,
  });

  /// How many sessions the trade is given to work.
  final int horizonBars;

  /// Stop distance, in ATRs.
  final double atrMultiple;

  /// Reward, as a multiple of the risk (2 → a 1 : 2 plan).
  final double rewardMultiple;

  /// Bars needed before the engine will judge a stock at all (RSI 14, EMA 21,
  /// 50 DMA all need room). Same number the live scan uses.
  final int warmupBars;

  /// A breakout only counts on real participation: last session's volume ÷ the
  /// average of the 20 before it.
  final double volumeSpike;

  final double oversold;
  final double overbought;

  /// Bars a series must hold before the replay will trust it at all.
  int get requiredBars => warmupBars + horizonBars + 2;

  BtConfig copyWith({
    int? horizonBars,
    double? atrMultiple,
    double? rewardMultiple,
    int? warmupBars,
    double? volumeSpike,
    double? oversold,
    double? overbought,
  }) =>
      BtConfig(
        horizonBars: horizonBars ?? this.horizonBars,
        atrMultiple: atrMultiple ?? this.atrMultiple,
        rewardMultiple: rewardMultiple ?? this.rewardMultiple,
        warmupBars: warmupBars ?? this.warmupBars,
        volumeSpike: volumeSpike ?? this.volumeSpike,
        oversold: oversold ?? this.oversold,
        overbought: overbought ?? this.overbought,
      );

  /// `10 din · stop 1 ATR · target 2x`
  String get line => '$horizonBars din · stop ${_num(atrMultiple)} ATR · '
      'target ${_num(rewardMultiple)}x';
}

/// A signal the replay is willing to take: a pattern with an agreed direction.
class BtSignal {
  const BtSignal({
    required this.pattern,
    required this.direction,
    required this.atr,
  });

  final AiPattern pattern;
  final AiDirection direction;

  /// The ATR at the signal bar — the yardstick for the stop and the target.
  final double atr;

  bool get bullish => direction == AiDirection.bullish;
}

/// The result of looking at one bar.
///
/// [mixed] is kept separate on purpose: a bar where the pattern says "up" and
/// the engine's own direction read says "down" is not a trade, and the report
/// says how many were thrown away rather than quietly dropping them.
class BtSignalCheck {
  const BtSignalCheck.none()
      : signal = null,
        mixed = false;

  const BtSignalCheck.mixed()
      : signal = null,
        mixed = true;

  const BtSignalCheck.take(this.signal) : mixed = false;

  final BtSignal? signal;
  final bool mixed;
}

/// One replayed trade, with every number that produced the verdict.
class BtTrade {
  const BtTrade({
    required this.symbol,
    required this.date,
    required this.pattern,
    required this.direction,
    required this.entry,
    required this.stop,
    required this.target,
    required this.risk,
    required this.exitPrice,
    required this.exit,
    required this.barsHeld,
  });

  final String symbol;

  /// The signal bar (the trade is taken on the **next** session's open).
  final DateTime date;
  final AiPattern pattern;
  final AiDirection direction;

  final double entry;
  final double stop;
  final double target;

  /// `entry − stop` — always positive.
  final double risk;
  final double exitPrice;
  final BtExit exit;
  final int barsHeld;

  bool get bullish => direction == AiDirection.bullish;

  /// Signed move in the trade's direction, in percent of the entry.
  double get returnPct =>
      entry <= 0 ? 0 : (exitPrice - entry) / entry * 100 * (bullish ? 1 : -1);

  /// The same move in units of risk: `+2` = the target, `−1` = the stop.
  double get rMultiple =>
      risk <= 0 ? 0 : (exitPrice - entry) / risk * (bullish ? 1 : -1);

  bool get hitTarget => exit == BtExit.target;
  bool get hitStop => exit == BtExit.stop;

  /// The plainest question of all: did it go the way the rule said?
  bool get rightDirection => returnPct > 0;
}

/// The honest scoreboard over a set of trades.
class BtStats {
  const BtStats({
    required this.samples,
    this.wins = 0,
    this.losses = 0,
    this.timeouts = 0,
    this.directionHits = 0,
    this.avgReturnPct = 0,
    this.medianReturnPct = 0,
    this.avgR = 0,
    this.totalR = 0,
    this.best = 0,
    this.worst = 0,
    this.maxDrawdownR = 0,
  });

  static const BtStats empty = BtStats(samples: 0);

  /// How many times the rule fired.
  final int samples;

  /// Target reached inside the horizon.
  final int wins;

  /// Stop hit.
  final int losses;

  /// Neither level touched — marked to market at the horizon.
  final int timeouts;

  /// Trades that closed in the direction the rule said (the plainest metric).
  final int directionHits;

  final double avgReturnPct;
  final double medianReturnPct;

  /// Expectancy in units of risk — `0.9` means "ausat me har trade par 0.9R".
  final double avgR;
  final double totalR;

  final double best;
  final double worst;

  /// Worst peak-to-trough run of the sequence, in R. A string of good trades
  /// can still hide a stretch that would have blown an account.
  final double maxDrawdownR;

  factory BtStats.of(List<BtTrade> trades) {
    if (trades.isEmpty) return BtStats.empty;

    var wins = 0;
    var losses = 0;
    var timeouts = 0;
    var directionHits = 0;
    var sumReturn = 0.0;
    var sumR = 0.0;
    var best = double.negativeInfinity;
    var worst = double.infinity;

    for (final trade in trades) {
      if (trade.hitTarget) wins++;
      if (trade.hitStop) losses++;
      if (trade.exit == BtExit.horizon) timeouts++;
      if (trade.rightDirection) directionHits++;
      sumReturn += trade.returnPct;
      sumR += trade.rMultiple;
      if (trade.returnPct > best) best = trade.returnPct;
      if (trade.returnPct < worst) worst = trade.returnPct;
    }

    final returns = [for (final t in trades) t.returnPct]..sort();
    final median = returns.length % 2 == 1
        ? returns[returns.length ~/ 2]
        : (returns[returns.length ~/ 2 - 1] + returns[returns.length ~/ 2]) / 2;

    // Drawdown of the running R curve — the sequence matters, not just the sum.
    var equity = 0.0;
    var peak = 0.0;
    var drawdown = 0.0;
    for (final trade in trades) {
      equity += trade.rMultiple;
      if (equity > peak) peak = equity;
      final drop = peak - equity;
      if (drop > drawdown) drawdown = drop;
    }

    return BtStats(
      samples: trades.length,
      wins: wins,
      losses: losses,
      timeouts: timeouts,
      directionHits: directionHits,
      avgReturnPct: sumReturn / trades.length,
      medianReturnPct: median,
      avgR: sumR / trades.length,
      totalR: sumR,
      best: best == double.negativeInfinity ? 0 : best,
      worst: worst == double.infinity ? 0 : worst,
      maxDrawdownR: drawdown,
    );
  }

  /// How often the *target* was reached — the plan's own promise.
  double get targetRatePct => samples == 0 ? 0 : wins / samples * 100;

  /// How often the direction was right — the claim the card actually makes.
  double get directionPct =>
      samples == 0 ? 0 : directionHits / samples * 100;

  double get stopRatePct => samples == 0 ? 0 : losses / samples * 100;
  double get timeoutRatePct => samples == 0 ? 0 : timeouts / samples * 100;

  bool get isEmpty => samples == 0;

  /// Below 30 trades the number moves for no reason — say so, do not spin it.
  bool get enoughSamples => samples >= 30;

  String get confidenceLabel => samples < 10
      ? 'bahut kam sample — sirf jankari ke liye'
      : samples < 30
          ? 'kam sample — is par bharosa nahi'
          : samples < 100
              ? 'theek-thaak sample'
              : 'achchha sample';

  /// `120 baar aaya · 58% sahi disha · ausat +1.8%`
  String get headline => samples == 0
      ? 'Is niyam par koi trade hi nahi bana.'
      : '$samples baar aaya · ${directionPct.toStringAsFixed(0)}% sahi disha · '
          'ausat ${signed(avgReturnPct, 1)}%';

  /// `+1.8` / `−0.4` — a signed percent, never a bare number.
  static String signed(double value, [int digits = 1]) =>
      '${value >= 0 ? '+' : '−'}${value.abs().toStringAsFixed(digits)}';
}

/// One row of the "kaunsa rule kitna sahi" table.
class BtPatternRow {
  const BtPatternRow({required this.pattern, required this.stats});

  final AiPattern pattern;
  final BtStats stats;
}

/// One row of the "kaunsa stock" table.
class BtSymbolRow {
  const BtSymbolRow({required this.symbol, required this.stats});

  final String symbol;
  final BtStats stats;
}

/// Everything one replay produced.
class BtResult {
  const BtResult({
    required this.config,
    required this.trades,
    required this.symbolsScanned,
    required this.skipped,
    required this.mixedSignals,
    required this.shortHistory,
    required this.downloads,
    required this.years,
    required this.from,
    required this.to,
    required this.duration,
    required this.cancelled,
  });

  final BtConfig config;

  /// Every replayed trade, oldest first.
  final List<BtTrade> trades;

  /// Symbols with enough history to be judged.
  final int symbolsScanned;

  /// `symbol → kyun chhoota` (too little data, broker error…).
  final Map<String, String> skipped;

  /// Bars where the pattern and the engine's direction read disagreed.
  final int mixedSignals;

  /// Symbols whose history was shorter than the window asked for — the report
  /// covers what existed, and says how many were short.
  final int shortHistory;

  /// How many series had to be fetched (0 = the whole run came from cache).
  final int downloads;

  final int years;
  final DateTime? from;
  final DateTime? to;
  final Duration duration;
  final bool cancelled;

  /// The service's own skips (a symbol whose candles never arrived) merged in.
  BtResult withSkips(Map<String, String> extra) => BtResult(
        config: config,
        trades: trades,
        symbolsScanned: symbolsScanned,
        skipped: <String, String>{...skipped, ...extra},
        mixedSignals: mixedSignals,
        shortHistory: shortHistory,
        downloads: downloads,
        years: years,
        from: from,
        to: to,
        duration: duration,
        cancelled: cancelled,
      );

  BtStats get overall => BtStats.of(trades);

  /// One row per signal that actually fired, most frequent first.
  List<BtPatternRow> get byPattern {
    final groups = <AiPattern, List<BtTrade>>{};
    for (final trade in trades) {
      groups.putIfAbsent(trade.pattern, () => <BtTrade>[]).add(trade);
    }
    final rows = [
      for (final entry in groups.entries)
        BtPatternRow(pattern: entry.key, stats: BtStats.of(entry.value)),
    ]..sort((a, b) => b.stats.samples.compareTo(a.stats.samples));
    return rows;
  }

  /// `symbol → trades`, for the per-stock table.
  List<BtSymbolRow> symbols({int limit = 10, int minSamples = 5}) {
    final groups = <String, List<BtTrade>>{};
    for (final trade in trades) {
      groups.putIfAbsent(trade.symbol, () => <BtTrade>[]).add(trade);
    }
    final rows = [
      for (final entry in groups.entries)
        if (entry.value.length >= minSamples)
          BtSymbolRow(symbol: entry.key, stats: BtStats.of(entry.value)),
    ]..sort((a, b) {
        final bySamples = b.stats.samples.compareTo(a.stats.samples);
        return bySamples != 0
            ? bySamples
            : a.symbol.compareTo(b.symbol);
      });
    return rows.take(limit).toList();
  }

  /// The best stocks by average R (among those that fired at least a few times).
  List<BtSymbolRow> bestSymbols({int limit = 5, int minSamples = 5}) {
    final rows = symbols(limit: 1000, minSamples: minSamples)
      ..sort((a, b) => b.stats.avgR.compareTo(a.stats.avgR));
    return rows.take(limit).toList();
  }

  List<BtSymbolRow> worstSymbols({int limit = 5, int minSamples = 5}) {
    final rows = symbols(limit: 1000, minSamples: minSamples)
      ..sort((a, b) => a.stats.avgR.compareTo(b.stats.avgR));
    return rows.take(limit).toList();
  }

  /// `1 Jan 2023 – 9 Oct 2026` (or `—` when nothing ran).
  String get periodLine {
    if (from == null || to == null) return '—';
    return '${_date(from!)} – ${_date(to!)}';
  }

  /// The line the screen leads with: coverage, then the verdict.
  String get coverageLine =>
      '$symbolsScanned stock · ${trades.length} trade · $years saal ka '
      'itihaas ($periodLine)';

  /// `213 me se 12 ke paas poora itihaas nahi tha.`
  String? get shortfallNote => shortHistory == 0
      ? null
      : '$shortHistory stock ke paas poore $years saal ka itihaas nahi tha — '
          'unka hisaab jitna data tha utne me hua.';

  String get networkNote => downloads == 0
      ? 'Pura run phone ke cache se hua — ek bhi internet call nahi gayi.'
      : '$downloads stock ka itihaas broker se liya gaya (ab cache me hai — '
          'agli baar offline chalega).';

  static String _date(DateTime d) =>
      '${d.day} ${_month(d.month)} ${d.year}';

  static String _month(int m) => const [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', //
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
      ][m - 1];
}

/// What one symbol's replay produced.
class BtSymbolRun {
  const BtSymbolRun({
    required this.trades,
    required this.mixed,
    required this.bars,
    this.short = false,
  });

  final List<BtTrade> trades;
  final int mixed;
  final int bars;

  /// `true` when the series was too short to judge at all.
  final bool short;
}

// ---------------------------------------------------------------------------
// The signal itself
// ---------------------------------------------------------------------------

/// Should bar `i` of [bars] be judged?
///
/// [window] is `bars[0…i]` and [snap] is its snapshot — the same pair the live
/// scan builds, so the replay can never drift from what the app would have
/// suggested that evening.
BtSignalCheck signalAt(
  List<Candle> window,
  AiSnapshot snap, {
  required BtConfig config,
}) {
  final pattern = detectPattern(
    window,
    snap,
    oversold: config.oversold,
    overbought: config.overbought,
    volumeSpike: config.volumeSpike,
  );

  // Only the four patterns the card actually trades. `range` is not a trade,
  // and the overbought / oversold lines are a warning, not a signal.
  final intended = switch (pattern) {
    AiPattern.breakout || AiPattern.pullback => AiDirection.bullish,
    AiPattern.breakdown || AiPattern.bounce => AiDirection.bearish,
    _ => null,
  };
  if (intended == null) return const BtSignalCheck.none();

  // The engine's own direction read must agree. A "breakout" in a stock the
  // moving averages call down is a contradiction, not a trade — and the report
  // counts how many it threw away instead of hiding them.
  final read = resolveDirection(snap, snap.return3m, snap.stackUp);
  if (read != intended) return const BtSignalCheck.mixed();

  if (snap.atr <= 0) return const BtSignalCheck.none();

  return BtSignalCheck.take(
    BtSignal(pattern: pattern, direction: intended, atr: snap.atr),
  );
}

/// Runs the trade a signal on bar [index] would have produced.
///
/// Returns `null` when there is no room to run it (fewer than `horizonBars`
/// sessions left after the entry) — an unfinished trade is not counted.
BtTrade? evaluateAt(
  List<Candle> bars,
  int index,
  BtSignal signal, {
  required BtConfig config,
  required String symbol,
}) {
  final entryIndex = index + 1;
  final lastIndex = index + config.horizonBars;
  if (lastIndex >= bars.length) return null;

  final entryBar = bars[entryIndex];
  final entry = entryBar.open > 0 ? entryBar.open : entryBar.close;
  final risk = signal.atr * config.atrMultiple;
  if (risk <= 0) return null;

  final bullish = signal.bullish;
  final stop = bullish ? entry - risk : entry + risk;
  final target = bullish ? entry + risk * config.rewardMultiple : entry - risk * config.rewardMultiple;

  // Walk the horizon one bar at a time. A stop is checked before a target on
  // the same bar: the pessimistic read, so the report can never flatter itself.
  for (var j = entryIndex; j <= lastIndex; j++) {
    final bar = bars[j];
    if (bullish) {
      if (bar.open <= stop) {
        return _close(symbol, bars, index, signal, config, entry, stop, target,
            risk, bar.open, BtExit.stop, j);
      }
      if (bar.low <= stop) {
        return _close(symbol, bars, index, signal, config, entry, stop, target,
            risk, stop, BtExit.stop, j);
      }
      if (bar.high >= target) {
        return _close(symbol, bars, index, signal, config, entry, stop, target,
            risk, target, BtExit.target, j);
      }
    } else {
      if (bar.open >= stop) {
        return _close(symbol, bars, index, signal, config, entry, stop, target,
            risk, bar.open, BtExit.stop, j);
      }
      if (bar.high >= stop) {
        return _close(symbol, bars, index, signal, config, entry, stop, target,
            risk, stop, BtExit.stop, j);
      }
      if (bar.low <= target) {
        return _close(symbol, bars, index, signal, config, entry, stop, target,
            risk, target, BtExit.target, j);
      }
    }
  }

  // Neither level: mark it at the horizon's close and call it what it is.
  return _close(symbol, bars, index, signal, config, entry, stop, target, risk,
      bars[lastIndex].close, BtExit.horizon, lastIndex);
}

BtTrade _close(
  String symbol,
  List<Candle> bars,
  int index,
  BtSignal signal,
  BtConfig config,
  double entry,
  double stop,
  double target,
  double risk,
  double exitPrice,
  BtExit exit,
  int exitIndex,
) =>
    BtTrade(
      symbol: symbol,
      date: bars[index].time,
      pattern: signal.pattern,
      direction: signal.direction,
      entry: entry,
      stop: stop,
      target: target,
      risk: risk,
      exitPrice: exitPrice,
      exit: exit,
      barsHeld: exitIndex - index,
    );

/// Replays one symbol's whole series.
BtSymbolRun runSymbol(
  String symbol,
  List<Candle> bars, {
  required BtConfig config,
}) {
  if (bars.length < config.requiredBars) {
    return BtSymbolRun(trades: const <BtTrade>[], mixed: 0, bars: bars.length, short: true);
  }

  final gate = BtGate(bars, config);
  final trades = <BtTrade>[];
  var mixed = 0;

  // The last bar that still leaves `horizonBars` sessions after the entry.
  final lastSignal = bars.length - 1 - config.horizonBars;

  for (var i = 0; i <= lastSignal; i++) {
    gate.advance(i);
    if (i + 1 < config.warmupBars) continue; // warm-up: no verdict yet
    if (!gate.fires()) continue; // cheap, exact pre-check (see _RollingGate)

    final window = bars.sublist(0, i + 1);
    final snap = buildSnapshot(window);
    final check = signalAt(window, snap, config: config);

    if (check.mixed) {
      mixed++;
      continue;
    }
    final signal = check.signal;
    if (signal == null) continue;

    final trade =
        evaluateAt(bars, i, signal, config: config, symbol: symbol);
    if (trade != null) trades.add(trade);
  }

  return BtSymbolRun(trades: trades, mixed: mixed, bars: bars.length);
}

/// Replays a whole universe. Pure and synchronous — the caller (a service)
/// owns the loading, the progress and the cancellation.
BtResult runBacktest(
  Map<String, List<Candle>> history, {
  required BtConfig config,
  required int years,
  int downloads = 0,
  bool cancelled = false,
  Duration duration = Duration.zero,
}) {
  final trades = <BtTrade>[];
  final skipped = <String, String>{};
  var mixed = 0;
  var short = 0;
  DateTime? from;
  DateTime? to;

  for (final entry in history.entries) {
    final run = runSymbol(entry.key, entry.value, config: config);
    if (run.short) {
      skipped[entry.key] =
          'Sirf ${run.bars} bars mile — kam se kam ${config.requiredBars} chahiye.';
      continue;
    }
    trades.addAll(run.trades);
    mixed += run.mixed;
    if (run.bars < years * 250 * 0.7) short++;

    if (entry.value.isNotEmpty) {
      final first = entry.value.first.time;
      final last = entry.value.last.time;
      if (from == null || first.isBefore(from)) from = first;
      if (to == null || last.isAfter(to)) to = last;
    }
  }

  trades.sort((a, b) => a.date.compareTo(b.date));

  return BtResult(
    config: config,
    trades: trades,
    symbolsScanned: history.length - skipped.length,
    skipped: skipped,
    mixedSignals: mixed,
    shortHistory: short,
    downloads: downloads,
    years: years,
    from: from,
    to: to,
    duration: duration,
    cancelled: cancelled,
  );
}

// ---------------------------------------------------------------------------
// The cheap gate
// ---------------------------------------------------------------------------
//
// Building a full snapshot for every bar of every symbol would be ~500 million
// operations for a 3-year run — minutes on a phone. But a signal can only be
// one of four patterns, and each has a *necessary* condition that costs almost
// nothing:
//
//   breakout   close > the highest high of the previous 20 sessions (with volume)
//   breakdown  close < the lowest low of the previous 20 sessions (with volume)
//   pullback   ema9 > ema21 > sma50, and the close sits between ema9 and ema21
//   bounce     the mirror image
//
// EMA and SMA over a window that always starts at bar 0 are recursive, so they
// can be carried forward one bar at a time and stay **bit-identical** to
// `emaLast` / `smaLast` (ai_backtest_test.dart pins that). The gate only ever
// decides *which bars to look at*: every bar it lets through still goes through
// `buildSnapshot` + `detectPattern`, the same code the live scan runs — so a
// slower-but-never-wrong trade-off.
// ---------------------------------------------------------------------------
class BtGate {
  BtGate(this.bars, this.config);

  final List<Candle> bars;
  final BtConfig config;

  // Rolling EMA state (seeded exactly like emaLast: a plain average of the
  // first `period` closes, then Wilder-style smoothing — because the window
  // always starts at bar 0 the recursion never has to be restarted).
  double _ema9 = 0;
  double _ema21 = 0;
  double _seed9 = 0;
  double _seed21 = 0;
  bool _ema9Ready = false;
  bool _ema21Ready = false;

  // Rolling 50-close sum for the SMA.
  final List<double> _last50 = <double>[];
  double _sum50 = 0;

  int _at = -1;
  late double _close;
  late double _sma50;
  late double _volumeRatio;
  late double _prevHigh;
  late double _prevLow;

  void advance(int i) {
    // The loop only ever moves forward, one bar at a time.
    assert(i == _at + 1, 'the gate must walk the series in order');
    _at = i;
    final bar = bars[i];
    _close = bar.close;

    // ---- EMAs ------------------------------------------------------------
    if (!_ema9Ready) {
      _seed9 += _close;
      if (i == 8) {
        _ema9 = _seed9 / 9;
        _ema9Ready = true;
      }
    } else {
      _ema9 = _close * (2 / 10) + _ema9 * (8 / 10);
    }

    if (!_ema21Ready) {
      _seed21 += _close;
      if (i == 20) {
        _ema21 = _seed21 / 21;
        _ema21Ready = true;
      }
    } else {
      _ema21 = _close * (2 / 22) + _ema21 * (20 / 22);
    }

    // ---- SMA 50 ----------------------------------------------------------
    _last50.add(_close);
    _sum50 += _close;
    if (_last50.length > 50) _sum50 -= _last50.removeAt(0);
    // smaLast returns null (→ the snapshot falls back to the last close) until
    // 50 closes exist; the gate must fall back the same way.
    _sma50 = _last50.length >= 50 ? _sum50 / 50 : _close;

    // ---- volume: this bar against the 20 before it -----------------------
    // buildSnapshot averages bars[len-21 … len-2] — the 20 sessions *before*
    // the last one — so the current bar is not part of its own average.
    var volSum = 0.0;
    if (i >= 21) {
      for (var j = i - 20; j <= i - 1; j++) {
        volSum += bars[j].volume;
      }
    }
    final volAvg = i >= 21 ? volSum / 20 : 0.0;
    _volumeRatio = volAvg > 0 ? bars[i].volume / volAvg : 1.0;

    // ---- 20-session extremes (the 20 bars before this one) ---------------
    var high = 0.0;
    var low = double.infinity;
    final start = i - 20 < 0 ? 0 : i - 20;
    for (var j = start; j < i; j++) {
      if (bars[j].high > high) high = bars[j].high;
      if (bars[j].low < low) low = bars[j].low;
    }
    _prevHigh = high;
    _prevLow = low == double.infinity ? 0 : low;
  }

  bool get _stackUp => _ema9 > _ema21 && _ema21 > _sma50;
  bool get _stackDown => _ema9 < _ema21 && _ema21 < _sma50;

  /// `true` when the bar *could* be one of the four traded patterns.
  bool fires() {
    final strong = _volumeRatio >= config.volumeSpike;
    if (_close > _prevHigh && strong) return true;
    if (_close < _prevLow && strong) return true;
    if (_stackUp && _close < _ema9 && _close > _ema21) return true;
    if (_stackDown && _close > _ema9 && _close < _ema21) return true;
    return false;
  }

  /// Exposed for the equivalence test (the gate must never be *wrong*).
  double get ema9 => _ema9Ready ? _ema9 : _close;
  double get ema21 => _ema21Ready ? _ema21 : _close;
  double get sma50 => _sma50;
  double get volumeRatio => _volumeRatio;
  double get prevHigh => _prevHigh;
  double get prevLow => _prevLow;
}

/// `1482` / `1482.3` — the config line reads better without trailing zeros.
String _num(double value) =>
    value == value.roundToDouble() ? value.toStringAsFixed(0) : value.toStringAsFixed(1);
