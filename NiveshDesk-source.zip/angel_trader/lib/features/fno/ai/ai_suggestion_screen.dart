// ---------------------------------------------------------------------------
// ai_suggestion_screen.dart — tool #3 of the F&O module: "AI Suggestion".
//
// What it shows: a ranked Top-N list (default 20) of F&O stocks where the
// technical picture and the 3-month study agree, and — for each one — the option
// trade that follows from that read.
//
// The order of every card is the order the brief asked for:
//
//   1. Rank
//   2. Stock name
//   3. Direction
//   4. Expected movement
//   5. Technical rationale   (numbers only — no verdict without a figure)
//   6. Options strategy → Action / Strategy / Strike type / Suggested jodi
//
// "AI" here is a local, deterministic rule engine (lib/features/fno/ai/*). No
// model call, no API key, no internet for the thinking — the only network use is
// the same broker candles/quotes the rest of the app already needs. Same candles
// + same filters therefore always give the same list.
//
// The filters are the user's, not ours: they live in Settings and every run
// obeys them exactly. Editing a filter marks the list on screen stale.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/widgets/motion.dart';
import '../../../services/ai_suggestion_service.dart'
    show AiGate, AiNearMiss;
import '../../settings/settings_provider.dart';
import '../study/study_delivery.dart'
    show StudyDeliveryOutcome, StudyDeliveryService, StudyExportKind;
import '../study/study_export.dart' show StudyExportService;
import 'ai_export.dart' show AiExportService;
import 'ai_suggestion.dart';
import 'ai_backtest_screen.dart' show AiBacktestScreen;
import 'ai_suggestion_provider.dart';

class AiSuggestionScreen extends StatefulWidget {
  const AiSuggestionScreen({super.key});

  @override
  State<AiSuggestionScreen> createState() => _AiSuggestionScreenState();
}

class _AiSuggestionScreenState extends State<AiSuggestionScreen> {
  @override
  void initState() {
    super.initState();
    // Only resolves the F&O universe — never a scan on open.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      context.read<AiSuggestionProvider>().bootstrap();
    });
  }

  static IconData _exportIcon(StudyExportKind kind) => switch (kind) {
        StudyExportKind.whatsapp => Icons.chat_bubble_outline_rounded,
        StudyExportKind.excel => Icons.grid_on_rounded,
        StudyExportKind.csv => Icons.description_outlined,
        StudyExportKind.telegram => Icons.send_rounded,
      };

  Future<void> _export(BuildContext context, StudyExportKind kind) async {
    final provider = context.read<AiSuggestionProvider>();
    final settings = context.read<SettingsProvider>();
    final messenger = ScaffoldMessenger.of(context);

    final rows = provider.suggestions;
    if (rows.isEmpty) {
      messenger.showSnackBar(
        const SnackBar(content: Text('Pehle scan chalao — list khaali hai.')),
      );
      return;
    }

    final meta = provider.exportMeta;
    if (meta == null) return;
    final export = AiExportService();
    final delivery = StudyDeliveryService(export: StudyExportService());

    StudyDeliveryOutcome outcome;
    try {
      switch (kind) {
        case StudyExportKind.whatsapp:
          outcome = await delivery
              .shareText(AiExportService.recap(rows, meta));
        case StudyExportKind.excel:
          outcome = await delivery.shareFile(
            await export.writeXlsx(rows: rows, meta: meta),
            'NiveshDesk AI Suggestion',
          );
        case StudyExportKind.csv:
          outcome = await delivery.shareFile(
            await export.writeCsv(rows: rows, meta: meta),
            'NiveshDesk AI Suggestion (CSV)',
          );
        case StudyExportKind.telegram:
          final file = await export.writeXlsx(rows: rows, meta: meta);
          outcome = await delivery.sendTelegramFile(
            file: file,
            caption: AiExportService.recap(rows, meta),
            settings: settings.settings,
          );
      }
    } catch (e) {
      outcome = StudyDeliveryOutcome(ok: false, message: 'Export fail: $e');
    }

    if (!context.mounted) return;
    messenger.showSnackBar(
      SnackBar(
        content: Text(outcome.message),
        backgroundColor: outcome.ok ? null : Theme.of(context).colorScheme.error,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<AiSuggestionProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Suggestion'),
        actions: [
          PopupMenuButton<StudyExportKind>(
            tooltip: 'Export',
            icon: const Icon(Icons.ios_share_rounded),
            onSelected: (kind) => _export(context, kind),
            itemBuilder: (_) => [
              for (final kind in StudyExportKind.values)
                PopupMenuItem<StudyExportKind>(
                  value: kind,
                  child: Row(
                    children: [
                      Icon(_exportIcon(kind), size: 17),
                      const SizedBox(width: 10),
                      Text(kind.label),
                    ],
                  ),
                ),
            ],
          ),
          IconButton(
            tooltip: 'Filter',
            icon: const Icon(Icons.tune_rounded),
            onPressed: () => showAiFilterSheet(context),
          ),
          IconButton(
            tooltip: 'Read Me',
            icon: const Icon(Icons.help_outline_rounded),
            onPressed: () => showAiReadMe(context),
          ),
          IconButton(
            tooltip: 'Hit rate / backtest',
            icon: const Icon(Icons.query_stats_rounded),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => const AiBacktestScreen(),
              ),
            ),
          ),
          PopupMenuButton<String>(
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'scan', child: Text('Dobara scan karo')),
              PopupMenuItem(value: 'skips', child: Text('Kaun chhoota')),
              PopupMenuItem(value: 'reset', child: Text('Filter default karo')),
            ],
            onSelected: (value) {
              final p = context.read<AiSuggestionProvider>();
              if (value == 'scan') {
                p.scan();
              } else if (value == 'skips') {
                showAiSkipsSheet(context, p.skipGroups);
              } else if (value == 'reset') {
                context.read<SettingsProvider>().resetAiFilters();
              }
            },
          ),
        ],
      ),
      body: Column(
        children: [
          _AiBanner(provider: provider),
          _AiScanBar(provider: provider),
          if (provider.error != null) _AiErrorStrip(message: provider.error!),
          const Divider(height: 1),
          Expanded(
            child: provider.suggestions.isEmpty
                ? _AiEmptyState(provider: provider)
                : _SuggestionList(provider: provider),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Banner — universe, last run, and the filters the list was built with
// ---------------------------------------------------------------------------

class _AiBanner extends StatelessWidget {
  const _AiBanner({required this.provider});

  final AiSuggestionProvider provider;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final colors = MarketColors.of(context);
    final result = provider.result;

    return Container(
      width: double.infinity,
      color: scheme.primaryContainer.withOpacity(0.4),
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.auto_awesome_rounded, size: 16, color: scheme.primary),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  result == null
                      ? 'Top ${provider.filters.topN} F&O momentum ideas'
                      : '${result.rows.length} ideas · ${Fmt.date(result.asOf)} ke data se',
                  style: const TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              if (provider.stale)
                Chip(
                  label: const Text('filter badla',
                      style: TextStyle(fontSize: 10)),
                  backgroundColor: colors.stale.withOpacity(0.15),
                  side: BorderSide(color: colors.stale.withOpacity(0.4)),
                  visualDensity: VisualDensity.compact,
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            provider.universeSize > 0
                ? 'Universe: ${provider.universeSize} of ${provider.universeTotal} F&O stocks'
                : 'F&O list resolve ho rahi hai…',
            style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
          ),
          const SizedBox(height: 2),
          if (result != null && provider.funnelLine.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 2),
              child: Text(
                provider.funnelLine,
                style: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          Text(
            _filtersLine(provider.filters),
            style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
          ),
          if (provider.stale)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                'Filter badal gaye hain — ye list purane filter ki hai. Dobara '
                'scan karo.',
                style: TextStyle(fontSize: 10.5, color: colors.stale),
              ),
            ),
          if (provider.note != null)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                provider.note!,
                style: TextStyle(
                  fontSize: 10.5,
                  fontStyle: FontStyle.italic,
                  color: scheme.onSurfaceVariant,
                ),
              ),
            ),
        ],
      ),
    );
  }

  /// The thresholds the list obeys, printed so it can always be read back.
  static String _filtersLine(AiFilters f) =>
      'Filter: study score ≥ ${f.minStudyScore.toStringAsFixed(1)} · momentum ≥ '
      '${f.minScore.toStringAsFixed(0)} · RSI ${f.rsiOversold.toStringAsFixed(0)}/'
      '${f.rsiOverbought.toStringAsFixed(0)} · volume ≥ '
      '${f.volumeSpike.toStringAsFixed(1)}x · 52w high se '
      '${f.nearHighPct.toStringAsFixed(0)}% · top ${f.topN}';
}

// ---------------------------------------------------------------------------
// Scan bar
// ---------------------------------------------------------------------------

class _AiScanBar extends StatelessWidget {
  const _AiScanBar({required this.provider});

  final AiSuggestionProvider provider;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final running = provider.busy;

    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: running ? null : () => provider.scan(),
                  icon: const Icon(Icons.auto_awesome_rounded, size: 17),
                  label: const Text('Scan karo'),
                ),
              ),
              if (provider.running) ...[
                const SizedBox(width: 8),
                OutlinedButton(
                  onPressed: provider.cancel,
                  child: const Text('Rok do'),
                ),
              ],
            ],
          ),
          if (provider.running && provider.progress != null) ...[
            const SizedBox(height: 8),
            LinearProgressIndicator(
              value: provider.progressValue.clamp(0.01, 1.0),
              minHeight: 4,
              borderRadius: BorderRadius.circular(999),
            ),
            const SizedBox(height: 5),
            Text(
              provider.progressLine,
              style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
            ),
          ],
        ],
      ),
    );
  }
}

class _AiErrorStrip extends StatelessWidget {
  const _AiErrorStrip({required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      color: scheme.errorContainer.withOpacity(0.5),
      padding: const EdgeInsets.fromLTRB(14, 8, 14, 8),
      child: Row(
        children: [
          Icon(Icons.error_outline_rounded, size: 15, color: scheme.error),
          const SizedBox(width: 8),
          Expanded(
            child: Text(message,
                style: TextStyle(fontSize: 11.5, color: scheme.error)),
          ),
          TextButton(
            onPressed: () => context.read<AiSuggestionProvider>().clearError(),
            child: const Text('Band karo', style: TextStyle(fontSize: 11)),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// List + card
// ---------------------------------------------------------------------------

class _SuggestionList extends StatelessWidget {
  const _SuggestionList({required this.provider});

  final AiSuggestionProvider provider;

  @override
  Widget build(BuildContext context) {
    final rows = provider.suggestions;
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 24),
      itemCount: rows.length,
      itemBuilder: (context, index) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: FadeSlideIn(
          index: index,
          child: AiSuggestionCard(row: rows[index]),
        ),
      ),
    );
  }
}

/// One idea, in the order the brief asks for: rank, stock, direction, expected
/// movement, the technical reason, then the option trade.
///
/// Public so it can be pinned by a widget test — this card *is* the feature.
class AiSuggestionCard extends StatelessWidget {
  const AiSuggestionCard({required this.row, super.key, DateTime? today})
      : _today = today;

  final AiSuggestion row;

  /// Reference day for "Result: X din me" — the scan's own day when exporting,
  /// today when on screen.
  final DateTime? _today;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final colors = MarketColors.of(context);
    final dirColor = switch (row.direction) {
      AiDirection.bullish => colors.gain,
      AiDirection.bearish => colors.loss,
      AiDirection.sideways => colors.flat,
    };
    final snap = row.snapshot;
    final today = _today ?? DateTime.now();

    return PressScale(
      child: Material(
        color: scheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(13, 12, 13, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 1 + 2: rank, stock, score
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 26,
                    height: 26,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: scheme.primary.withOpacity(0.14),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      '${row.rank}',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        color: scheme.primary,
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          row.symbol,
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        if (row.name.isNotEmpty)
                          Text(
                            row.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 10.5,
                              color: scheme.onSurfaceVariant,
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: scheme.primary.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      row.score.toStringAsFixed(0),
                      style: TextStyle(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w800,
                        color: scheme.primary,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 9),

              // 3 + 4: direction and expected movement
              Row(
                children: [
                  Expanded(
                    child: _Field(
                      label: 'Direction',
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            row.direction == AiDirection.bullish
                                ? Icons.trending_up_rounded
                                : row.direction == AiDirection.bearish
                                    ? Icons.trending_down_rounded
                                    : Icons.trending_flat_rounded,
                            size: 15,
                            color: dirColor,
                          ),
                          const SizedBox(width: 5),
                          Text(
                            '${row.direction.label} (${row.direction.hinglish})',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: dirColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _Field(
                      label: 'Expected movement',
                      child: Text(
                        row.move.label,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),

              // the numbers behind the read
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  _Chip(text: 'CMP ${Fmt.price(snap.ltp)}'),
                  _Chip(text: 'RSI ${snap.rsi.toStringAsFixed(0)}'),
                  _Chip(text: 'ATR ${snap.atrPct.toStringAsFixed(1)}%'),
                  _Chip(text: 'Range ${snap.avgRangePct.toStringAsFixed(1)}%'),
                  _Chip(text: 'turnover ₹${snap.turnoverCrore.toStringAsFixed(1)} cr'),
                  _Chip(text: 'pattern: ${row.pattern.label}'),
                  _Chip(text: 'study ${row.studyScore.toStringAsFixed(1)}/12'),
                  if (row.resultLine(today).isNotEmpty)
                    _Chip(
                      text: row.resultLine(today),
                      color: row.options?.isEvent(5) ?? false
                          ? colors_stale(context)
                          : null,
                    ),
                ],
              ),
              const SizedBox(height: 8),

              // 5: technical rationale
              _Field(
                label: 'Technical rationale',
                child: Text(
                  row.rationaleLine,
                  style: TextStyle(
                    fontSize: 11.5,
                    height: 1.35,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ),

              const Padding(
                padding: EdgeInsets.symmetric(vertical: 10),
                child: Divider(height: 1),
              ),

              // 6: the option trade
              Row(
                children: [
                  Icon(Icons.rocket_launch_outlined,
                      size: 14, color: scheme.primary),
                  const SizedBox(width: 6),
                  Text(
                    'OPTIONS STRATEGY',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.7,
                      color: scheme.primary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 7),
              _kv(context, 'Action', row.strategy.action,
                  valueColor: row.strategy.action == 'Sell'
                      ? colors.loss
                      : row.strategy.wait
                          ? colors.stale
                          : colors.gain),
              _kv(context, 'Strategy', row.strategy.name),
              _kv(context, 'Strike type', row.strategy.strikeType),
              _kv(context, 'Suggested jodi', row.strategy.pair),
              if (row.options != null && row.options!.premiumLine.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Row(
                    children: [
                      _Chip(text: row.options!.premiumLine),
                      if (row.options!.lotSize > 0) ...[
                        const SizedBox(width: 6),
                        _Chip(text: 'lot ${row.options!.lotSize}'),
                      ],
                    ],
                  ),
                ),
              const SizedBox(height: 5),
              Text(
                row.strategy.why,
                style: TextStyle(
                  fontSize: 11,
                  height: 1.35,
                  color: scheme.onSurfaceVariant,
                ),
              ),
              if (row.plan != null) ...[
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 10),
                  child: Divider(height: 1),
                ),
                Row(
                  children: [
                    Icon(Icons.flag_outlined, size: 14, color: scheme.primary),
                    const SizedBox(width: 6),
                    Text(
                      'TRADE PLAN',
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.7,
                        color: scheme.primary,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 7),
                _kv(context, 'Entry', row.plan!.entryLine),
                _kv(context, 'Stop',
                    '₹${_num(row.plan!.stop)} (${_pct(-row.plan!.risk / row.plan!.entry)})'),
                _kv(context, 'Target',
                    '₹${_num(row.plan!.target)} (${_pct(row.plan!.reward / row.plan!.entry)})'),
                _kv(
                  context,
                  'Risk : Reward',
                  '1 : ${row.plan!.rr.toStringAsFixed(1)}',
                  valueColor: row.plan!.worthIt ? colors_gain(context) : colors_stale(context),
                ),
                if (row.plan!.premium != null) ...[
                  _kv(context, 'Premium', '₹${_num(row.plan!.premium!)}'),
                  _kv(
                    context,
                    'Option stop / target',
                    '₹${_num(row.plan!.premiumStop!)} / ₹${_num(row.plan!.premiumTarget!)}',
                  ),
                  _kv(context, '1 lot',
                      '${row.plan!.lotSize} qty · ₹${_num(row.plan!.lotCost!)}'),
                  _kv(
                    context,
                    'Jokhim (1 lot)',
                    '₹${_num(row.plan!.riskPerLot!)} = capital ka '
                        '${row.plan!.capitalAtRiskPct.toStringAsFixed(1)}%',
                    valueColor: row.plan!.tooBig ? colors_loss(context) : null,
                  ),
                  _kv(
                    context,
                    'Kitne lot',
                    row.plan!.tooBig
                        ? '1 lot bhi limit se upar — chhod do ya filter dhila karo'
                        : '${row.plan!.lots} lot (${row.plan!.riskPct.toStringAsFixed(1)}% niyam)',
                    valueColor: row.plan!.tooBig ? colors_loss(context) : null,
                  ),
                ] else ...[
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(
                      'Premium likhne (sell) wali strategy hai — iska kharcha '
                      'margin hai, premium nahi. Lot size broker ke quote par '
                      'dekho.',
                      style: TextStyle(
                        fontSize: 10.5,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                  ),
                ],
              ],
              if (row.strategy.action == 'Sell')
                Padding(
                  padding: const EdgeInsets.only(top: 7),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(Icons.warning_amber_rounded,
                          size: 14, color: colors.loss),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          'Ye premium likhne (sell) wali strategy hai — nuksan '
                          'bada ho sakta hai. Pehle paper trade me azmao.',
                          style: TextStyle(fontSize: 10.5, color: colors.loss),
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _kv(BuildContext context, String label, String value,
      {Color? valueColor}) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(bottom: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 92,
            child: Text(
              label,
              style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                fontSize: 11.5,
                fontWeight: FontWeight.w700,
                color: valueColor,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// The result chip turns amber when the announcement is inside the event window.
Color colors_stale(BuildContext context) => MarketColors.of(context).stale;

Color colors_gain(BuildContext context) => MarketColors.of(context).gain;

Color colors_loss(BuildContext context) => MarketColors.of(context).loss;

/// `1482` / `1482.35`
String _num(double value) {
  // Round away the floating-point dust first: a risk of 12.6 x 250 lots is
  // 3150.0000000000005, and "₹3150.00" reads like a bug.
  final rounded = (value * 100).roundToDouble() / 100;
  return rounded == rounded.roundToDouble()
      ? rounded.toStringAsFixed(0)
      : rounded.toStringAsFixed(2);
}

/// `+1.8%` — signed, so a stop can never be misread as a target.
String _pct(double fraction) =>
    '${fraction >= 0 ? '+' : '-'}${(fraction * 100).abs().toStringAsFixed(1)}%';

class _Field extends StatelessWidget {
  const _Field({required this.label, required this.child});

  final String label;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant),
        ),
        const SizedBox(height: 2),
        child,
      ],
    );
  }
}

class _Chip extends StatelessWidget {
  const _Chip({required this.text, this.color});

  final String text;

  /// Set when the chip is a warning (e.g. a result due inside the event
  /// window) — it then borrows the "stale" amber.
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final tint = color;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(999),
        border: Border.all(
          color: tint?.withOpacity(0.6) ??
              scheme.outlineVariant.withOpacity(0.8),
        ),
        color: tint?.withOpacity(0.12),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 10,
          color: tint ?? scheme.onSurfaceVariant,
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Empty state
// ---------------------------------------------------------------------------

class _AiEmptyState extends StatelessWidget {
  const _AiEmptyState({required this.provider});

  final AiSuggestionProvider provider;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final hasRun = provider.result != null;

    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.auto_awesome_rounded, size: 42, color: scheme.primary),
            const SizedBox(height: 14),
            Text(
              hasRun ? 'Koi stock filter pass nahi hua' : 'Abhi koi list nahi',
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            Text(
              hasRun
                  ? 'Filter thoda dheela karke dobara scan karo — Settings ya '
                      'upar tune wale icon se.'
                  : 'Scan karo: poore F&O universe ke candles padhe jayenge, har '
                      'stock ko score milta hai, aur sabse strong '
                      '${provider.filters.topN} neeche list me aate hain.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12,
                height: 1.4,
                color: scheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              provider.universeSize > 0
                  ? '${provider.universeSize} F&O stocks taiyar hain'
                  : 'F&O list resolve ho rahi hai…',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Filter sheet — the user's thresholds, edited in place
// ---------------------------------------------------------------------------

/// Opens the filter sheet. Every change is written straight to Settings, so the
/// next scan (and every other screen) obeys it.
Future<void> showAiFilterSheet(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (_) => const _AiFilterSheet(),
  );
}

class _AiFilterSheet extends StatelessWidget {
  const _AiFilterSheet();

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();
    final f = settings.aiFilters;
    final scheme = Theme.of(context).colorScheme;

    void apply(AiFilters next) => settings.setAiFilters(next);

    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(18, 4, 18, 18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'AI Suggestion ke filter',
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 6),
            Text(
              'Jo bhi yahan set hoga, agli list usi ke hisaab se banegi. '
              'Badlav turant save ho jata hai.',
              style: TextStyle(
                fontSize: 11.5,
                height: 1.35,
                color: scheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 6),
            _Slider(
              label: 'Min 3-month study score',
              value: f.minStudyScore,
              min: 0,
              max: 12,
              divisions: 24,
              format: (v) => v.toStringAsFixed(1),
              onChanged: (v) => apply(f.copyWith(minStudyScore: v)),
            ),
            _Slider(
              label: 'Min momentum score',
              value: f.minScore,
              min: 0,
              max: 100,
              divisions: 20,
              format: (v) => v.toStringAsFixed(0),
              onChanged: (v) => apply(f.copyWith(minScore: v)),
            ),
            _Slider(
              label: 'RSI oversold (is se neeche = sasta)',
              value: f.rsiOversold,
              min: 10,
              max: 50,
              divisions: 40,
              format: (v) => v.toStringAsFixed(0),
              onChanged: (v) => apply(f.copyWith(
                rsiOversold: v,
                rsiOverbought: f.rsiOverbought < v + 5 ? v + 5 : f.rsiOverbought,
              )),
            ),
            _Slider(
              label: 'RSI overbought (is se upar = mehenga)',
              value: f.rsiOverbought,
              min: 50,
              max: 90,
              divisions: 40,
              format: (v) => v.toStringAsFixed(0),
              onChanged: (v) => apply(f.copyWith(
                rsiOverbought: v,
                rsiOversold: f.rsiOversold > v - 5 ? v - 5 : f.rsiOversold,
              )),
            ),
            _Slider(
              label: 'Volume spike (x, 20-din ke average se)',
              value: f.volumeSpike,
              min: 0.5,
              max: 5,
              divisions: 45,
              format: (v) => '${v.toStringAsFixed(1)}x',
              onChanged: (v) => apply(f.copyWith(volumeSpike: v)),
            ),
            _Slider(
              label: '52-week high se kitna % neeche tak "near high"',
              value: f.nearHighPct,
              min: 1,
              max: 25,
              divisions: 24,
              format: (v) => '${v.toStringAsFixed(0)}%',
              onChanged: (v) => apply(f.copyWith(nearHighPct: v)),
            ),
            _Slider(
              label: 'Min turnover (₹ crore/day) — patle stock kat jayenge',
              value: f.minTurnoverCrore,
              min: 0,
              max: 100,
              divisions: 20,
              format: (v) => '${v.toStringAsFixed(0)} cr',
              onChanged: (v) => apply(f.copyWith(minTurnoverCrore: v)),
            ),
            _Slider(
              label: 'Result kitne din pehle ho to trade roke',
              value: f.eventBlockDays.toDouble(),
              min: 0,
              max: 15,
              divisions: 15,
              format: (v) => v.toStringAsFixed(0),
              onChanged: (v) => apply(f.copyWith(eventBlockDays: v.round())),
            ),
            _Slider(
              label: 'Ek trade me capital ka kitna % jokhim',
              value: f.riskPct,
              min: 0.5,
              max: 5,
              divisions: 18,
              format: (v) => '${v.toStringAsFixed(1)}%',
              onChanged: (v) => apply(f.copyWith(riskPct: v)),
            ),
            _Slider(
              label: 'Kharidne ke liye kam se kam din (DTE)',
              value: f.buyMinDte.toDouble(),
              min: 0,
              max: 30,
              divisions: 30,
              format: (v) => '${v.toStringAsFixed(0)} din',
              onChanged: (v) => apply(f.copyWith(buyMinDte: v.round())),
            ),
            _Slider(
              label: 'Bechne ke liye zyada se zyada din (DTE)',
              value: f.sellMaxDte.toDouble(),
              min: 3,
              max: 45,
              divisions: 42,
              format: (v) => '${v.toStringAsFixed(0)} din',
              onChanged: (v) => apply(f.copyWith(sellMaxDte: v.round())),
            ),
            _Slider(
              label: 'List me kitne stocks',
              value: f.topN.toDouble(),
              min: 5,
              max: 50,
              divisions: 9,
              format: (v) => v.toStringAsFixed(0),
              onChanged: (v) => apply(f.copyWith(topN: v.round())),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                TextButton.icon(
                  onPressed: () => context.read<SettingsProvider>().resetAiFilters(),
                  icon: const Icon(Icons.restart_alt_rounded, size: 17),
                  label: const Text('Default karo'),
                ),
                const Spacer(),
                FilledButton.icon(
                  onPressed: () {
                    Navigator.of(context).pop();
                    context.read<AiSuggestionProvider>().scan();
                  },
                  icon: const Icon(Icons.auto_awesome_rounded, size: 17),
                  label: const Text('Scan karo'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _Slider extends StatelessWidget {
  const _Slider({
    required this.label,
    required this.value,
    required this.min,
    required this.max,
    required this.divisions,
    required this.format,
    required this.onChanged,
  });

  final String label;
  final double value;
  final double min;
  final double max;
  final int divisions;
  final String Function(double) format;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(label,
                    style: TextStyle(
                        fontSize: 11.5, color: scheme.onSurfaceVariant)),
              ),
              Text(
                format(value),
                style:
                    const TextStyle(fontSize: 12, fontWeight: FontWeight.w800),
              ),
            ],
          ),
          Slider(
            value: value.clamp(min, max),
            min: min,
            max: max,
            divisions: divisions,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// "Kaun chhoota" sheet
// ---------------------------------------------------------------------------

Future<void> showAiSkipsSheet(BuildContext context, List<AiSkipGroup> groups) {
  final provider = context.read<AiSuggestionProvider>();
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (_) => _AiSkipsSheet(
      groups: groups,
      filters: provider.filters,
      funnel: provider.funnelLine,
      nearMisses: provider.nearMisses(),
      dropped: provider.droppedCount,
    ),
  );
}

class _AiSkipsSheet extends StatelessWidget {
  const _AiSkipsSheet({
    required this.groups,
    required this.filters,
    required this.funnel,
    required this.nearMisses,
    required this.dropped,
  });

  final List<AiSkipGroup> groups;
  final AiFilters filters;
  final String funnel;
  final List<AiNearMiss> nearMisses;
  final int dropped;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final nothingToShow = groups.isEmpty && nearMisses.isEmpty;
    return SafeArea(
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.8,
        child: nothingToShow
            ? Padding(
                padding: const EdgeInsets.all(24),
                child: Center(
                  child: Text(
                    'Koi stock nahi chhoota — sab scan hue.',
                    style: TextStyle(color: scheme.onSurfaceVariant),
                  ),
                ),
              )
            : ListView(
                padding: const EdgeInsets.fromLTRB(18, 4, 18, 20),
                children: [
                  // How the list was whittled down — the answer to "itne kam
                  // kyun hain?" without having to guess.
                  if (funnel.isNotEmpty) ...[
                    Text(
                      'FUNNEL',
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.8,
                        color: scheme.primary,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      funnel,
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                  if (nearMisses.isNotEmpty) ...[
                    const SizedBox(height: 14),
                    Text(
                      'FILTER SE BAHAR — sabse nazdik ${nearMisses.length} '
                      '(kul $dropped)',
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.8,
                        color: scheme.primary,
                      ),
                    ),
                    const SizedBox(height: 6),
                    for (final miss in nearMisses)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 3),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(
                                miss.symbol,
                                style: const TextStyle(
                                  fontSize: 11.5,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                            Text(
                              miss.gate == AiGate.study
                                  ? 'study ${miss.studyScore.toStringAsFixed(1)}'
                                  : 'momentum ${miss.score.toStringAsFixed(0)}',
                              style: TextStyle(
                                fontSize: 11,
                                color: scheme.onSurfaceVariant,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              miss.gate == AiGate.study
                                  ? 'bar ${filters.minStudyScore.toStringAsFixed(1)}'
                                  : 'bar ${filters.minScore.toStringAsFixed(0)}',
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                color: _missColor(context),
                              ),
                            ),
                          ],
                        ),
                      ),
                    const SizedBox(height: 8),
                    Text(
                      'Inhe list me lane ke liye Settings (ya tune icon) se bar '
                      'thoda neeche karo, phir dobara scan karo.',
                      style: TextStyle(
                        fontSize: 10.5,
                        fontStyle: FontStyle.italic,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                  if (groups.isNotEmpty) ...[
                    const SizedBox(height: 14),
                    Text(
                      'KYUN CHHOOTA (data nahi mila)',
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.8,
                        color: scheme.primary,
                      ),
                    ),
                    const SizedBox(height: 8),
                  ],
                  for (final group in groups) ...[
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 7, vertical: 2),
                          decoration: BoxDecoration(
                            color: scheme.errorContainer.withOpacity(0.7),
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(
                            '${group.count}',
                            style: TextStyle(
                              fontSize: 10.5,
                              fontWeight: FontWeight.w800,
                              color: scheme.error,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            group.reason,
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 5),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Text(
                        group.symbols.join(', '),
                        style: TextStyle(
                          fontSize: 11,
                          height: 1.35,
                          color: scheme.onSurfaceVariant,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
      ),
    );
  }

  /// The "missed by" figure reads as a shortfall, so it uses the loss colour.
  Color _missColor(BuildContext context) => MarketColors.of(context).loss;
}


// ---------------------------------------------------------------------------
// Read Me
// ---------------------------------------------------------------------------

Future<void> showAiReadMe(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (_) => const _AiReadMeSheet(),
  );
}

class _AiReadMeSheet extends StatelessWidget {
  const _AiReadMeSheet();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    const bullets = [
      ('Rank', 'Score ke hisaab se — 1 sabse strong.'),
      ('Direction', 'Bullish / Bearish / Sideways: 3-month trend + 9/21 EMA aur '
          '50 DMA ka stack.'),
      ('Expected movement', 'Pattern se: breakout, breakdown, pullback, range…'),
      ('Technical rationale', 'Sirf numbers: RSI, 3-month return, volume, '
          '52-week high se doori, up months.'),
      ('Options strategy', 'Action, strategy, strike type aur jodi — '
          'niche likhe niyam se.'),
    ];
    const rules = [
      'Trending + premium sasti → ATM option kharido (Directional Buy).',
      'Trending + premium mehengi (option jitna charge kare, us se zyada stock '
          'chale) → spread: ATM kharido, OTM becho.',
      'Breakout + ATR 2.5% se upar → Straddle (ATM jodi).',
      'Sideways + premium mehengi → Strangle sell (OTM jodi). Risk bada — card '
          'par chetawani hai.',
      'Sideways + premium sasti → Wait. Koi trade nahi.',
      '**Result paas ho to koi nayi position nahi** (IV crush kharidne wale ka, '
          'gap ka jokhim bechne wale ka).',
      '**Turnover patla ho to koi trade nahi** — spread hi nuksan karwa deta '
          'hai.',
    ];

    Widget sectionTitle(String text) => Padding(
          padding: const EdgeInsets.only(top: 14, bottom: 6),
          child: Text(
            text,
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.8,
              color: scheme.primary,
            ),
          ),
        );

    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(18, 4, 18, 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'AI Suggestion kaise kaam karta hai',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 8),
            Text(
              'Yahan koi online AI nahi hai. Ye ek local rule engine hai: aapke '
              'phone me maujood candles par fixed niyam chalte hain. Is liye '
              'same data + same filter = hamesha same list. Koi guess nahi, koi '
              'internet par bheja gaya data nahi.',
              style: TextStyle(
                  fontSize: 12, height: 1.45, color: scheme.onSurfaceVariant),
            ),
            sectionTitle('CARD PAR KYA HAI'),
            for (final (title, body) in bullets)
              Padding(
                padding: const EdgeInsets.only(bottom: 7),
                child: RichText(
                  text: TextSpan(
                    style: TextStyle(
                      fontSize: 11.5,
                      height: 1.4,
                      color: scheme.onSurface,
                    ),
                    children: [
                      TextSpan(
                        text: '$title — ',
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      TextSpan(text: body),
                    ],
                  ),
                ),
              ),
            sectionTitle('OPTION TRADE KE NIYAM'),
            for (final rule in rules)
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('•  ',
                        style: TextStyle(
                            fontSize: 11.5, fontWeight: FontWeight.w800)),
                    Expanded(
                      child: Text(rule,
                          style: const TextStyle(fontSize: 11.5, height: 1.4)),
                    ),
                  ],
                ),
              ),
            sectionTitle('FILTER'),
            Text(
              'Tune wale icon se RSI, volume, near-high, min score aur list ki '
              'lambai badlo — sab Settings me save ho jata hai. Filter badalne '
              'ke baad list purani ho jati hai, is liye dobara scan karo.',
              style: TextStyle(
                  fontSize: 11.5, height: 1.4, color: scheme.onSurfaceVariant),
            ),
            const SizedBox(height: 14),
            Text(
              'Ye salah nahi hai. Option me nuksan bada ho sakta hai — pehle '
              'paper trade me azmao.',
              style: TextStyle(
                fontSize: 11,
                fontStyle: FontStyle.italic,
                color: scheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
