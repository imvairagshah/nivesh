// ---------------------------------------------------------------------------
// ai_indicators.dart — the numbers behind "AI Suggestion" (pure, no network).
//
// "AI" here means a **local rule engine**: real indicators + the 3-month study,
// scored and ranked on the phone. No model, no API key, no internet — so the
// same input always gives the same list, and every line can be explained.
//
// Everything in this file is a pure function over a candle list, which is why
// it is unit-tested against hand-checked fixtures rather than trusted.
// ---------------------------------------------------------------------------

import 'dart:math' as math;

import '../../../data/remote/dto/candle.dart';
import '../study/study_engine.dart' show avgHighLow, wilderAtr;

/// One stock's technical picture, computed from its daily candles.
class AiSnapshot {
  const AiSnapshot({
    required this.ltp,
    required this.rsi,
    required this.ema9,
    required this.ema21,
    required this.sma50,
    required this.high52w,
    required this.low52w,
    required this.atr,
    required this.atrPct,
    this.avgRangePct = 0,
    required this.volumeRatio,
    required this.return3m,
    required this.turnoverCrore,
    required this.bars,
  });

  final double ltp;

  /// Wilder RSI (the app-wide default period, 14).
  final double rsi;
  final double ema9;
  final double ema21;
  final double sma50;

  /// 52-week (250 trading sessions) extremes.
  final double high52w;
  final double low52w;

  final double atr;
  final double atrPct;

  /// Simple (High − Low) average of the last 14 sessions as % of price —
  /// "din ka average range" bina gap ke (ATR me gap bhi count hota hai).
  /// Optional so anything that builds an [AiSnapshot] in a test stays valid.
  final double avgRangePct;

  /// Last session's volume ÷ the average of the 20 sessions before it.
  /// `1.5` = aaj 50% zyada volume.
  final double volumeRatio;

  /// 3-month return in percent (the study's own window, ~63 sessions).
  final double return3m;

  /// Average cash-market turnover of the last 20 sessions, in ₹ crore.
  ///
  /// The honest test of "can I actually trade this?": a breakout in a stock that
  /// turns over ₹2 crore a day fills badly, and the option's bid-ask eats the
  /// edge. Analyst's filter, not a model's opinion.
  final double turnoverCrore;

  /// How many daily bars the numbers were built from (fewer bars = weaker).
  final int bars;

  /// Distance below the 52-week high, in percent (0 = at the high).
  double get fromHighPct =>
      high52w <= 0 ? 0 : (high52w - ltp) / high52w * 100;

  /// Distance above the 52-week low, in percent.
  double get fromLowPct => low52w <= 0 ? 0 : (ltp - low52w) / low52w * 100;

  /// `true` when the short average sits above the long one — the plainest
  /// trend read there is.
  bool get stackUp => ema9 > ema21 && ema21 > sma50;

  /// …and the mirror image.
  bool get stackDown => ema9 < ema21 && ema21 < sma50;
}

/// Wilder's RSI — the same smoothing the rest of the app uses for ATR, so the
/// two never disagree about what a "move" is.
///
/// Returns 50 for a series with no losses and no gains (a flat line): an
/// unknown RSI is not an extreme RSI.
double wilderRsi(List<Candle> candles, {int period = 14}) {
  if (candles.length < period + 1) return 50;

  var gainSum = 0.0;
  var lossSum = 0.0;
  for (var i = 1; i <= period; i++) {
    final delta = candles[i].close - candles[i - 1].close;
    if (delta >= 0) {
      gainSum += delta;
    } else {
      lossSum -= delta;
    }
  }

  var avgGain = gainSum / period;
  var avgLoss = lossSum / period;

  for (var i = period + 1; i < candles.length; i++) {
    final delta = candles[i].close - candles[i - 1].close;
    final gain = delta > 0 ? delta : 0.0;
    final loss = delta < 0 ? -delta : 0.0;
    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;
  }

  if (avgLoss == 0) return avgGain == 0 ? 50 : 100;
  final rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
}

/// Exponential moving average's **last** value, seeded with a plain average of
/// the first [period] points (the standard seed, and what charting apps show).
double? emaLast(List<double> values, int period) {
  if (values.length < period) return null;
  final k = 2 / (period + 1);
  var seed = 0.0;
  for (var i = 0; i < period; i++) {
    seed += values[i];
  }
  var ema = seed / period;
  for (var i = period; i < values.length; i++) {
    ema = values[i] * k + ema * (1 - k);
  }
  return ema;
}

/// Simple moving average's last value.
double? smaLast(List<double> values, int period) {
  if (values.length < period) return null;
  var sum = 0.0;
  for (var i = values.length - period; i < values.length; i++) {
    sum += values[i];
  }
  return sum / period;
}

/// Builds the whole technical picture for one stock.
///
/// [bars] should carry at least ~60 sessions; 52-week numbers simply cover
/// whatever history exists (a 90-bar series gives a 90-day "52-week" high, and
/// the row says how many bars it used rather than pretending).
AiSnapshot buildSnapshot(List<Candle> bars, {int rsiPeriod = 14}) {
  final closes = [for (final bar in bars) bar.close];
  final last = closes.isEmpty ? 0.0 : closes.last;

  final atr = wilderAtr(bars);
  final avgRange = avgHighLow(bars);
  final window = bars.length > 250 ? bars.sublist(bars.length - 250) : bars;
  var high = 0.0;
  var low = double.infinity;
  for (final bar in window) {
    if (bar.high > high) high = bar.high;
    if (bar.low < low) low = bar.low;
  }

  // 3-month return: the study's own window is 63 sessions.
  final back = bars.length > 63 ? bars[bars.length - 64].close : closes.first;
  final return3m = back > 0 ? (last / back - 1) * 100 : 0.0;

  // Volume spike: today against the 20 sessions before it.
  double volumeRatio = 1;
  if (bars.length > 21) {
    var sum = 0;
    for (var i = bars.length - 21; i < bars.length - 1; i++) {
      sum += bars[i].volume;
    }
    final avg = sum / 20;
    if (avg > 0) volumeRatio = bars.last.volume / avg;
  }

  // Turnover: close × volume, averaged over the last 20 sessions, in ₹ crore.
  var turnover = 0.0;
  if (bars.isNotEmpty) {
    final window = bars.length > 20 ? bars.sublist(bars.length - 20) : bars;
    var sum = 0.0;
    for (final bar in window) {
      sum += bar.close * bar.volume;
    }
    turnover = sum / window.length / 1e7; // ₹ → ₹ crore
  }

  return AiSnapshot(
    ltp: last,
    rsi: wilderRsi(bars, period: rsiPeriod),
    ema9: emaLast(closes, 9) ?? last,
    ema21: emaLast(closes, 21) ?? last,
    sma50: smaLast(closes, 50) ?? last,
    high52w: high,
    low52w: low == double.infinity ? 0 : low,
    atr: atr,
    atrPct: last > 0 ? atr / last * 100 : 0,
    avgRangePct: last > 0 ? avgRange / last * 100 : 0,
    volumeRatio: volumeRatio,
    return3m: return3m,
    turnoverCrore: turnover,
    bars: bars.length,
  );
}

// ---------------------------------------------------------------------------
// Chart patterns
// ---------------------------------------------------------------------------

/// The handful of patterns this engine claims to recognise — deliberately few,
/// and each one is a definition you can check on a chart by eye.
enum AiPattern {
  breakout('Breakout', '20-din ka high todha, volume ke saath'),
  breakdown('Breakdown', '20-din ka low toda, volume ke saath'),
  pullback('Pullback', 'Uptrend me EMA9 ke neeche — girawat kharidne wali'),
  bounce('Pullback rally', 'Downtrend me EMA9 ke upar — rally bechne wali'),
  extendedUp('Overbought', 'RSI overbought zone me — upar se thakawat'),
  extendedDown('Oversold', 'RSI oversold zone me — neeche se bounce'),
  range('Range / Build-up', 'Koi clear breakout nahi — range me ghoom raha');

  const AiPattern(this.label, this.hint);

  final String label;
  final String hint;
}

/// Classifies the last session against the previous 20.
///
/// Order matters: a stock that broke out *and* is overbought is reported as a
/// breakout (that is the tradeable fact) — the RSI line still shows, so the
/// user sees both.
AiPattern detectPattern(
  List<Candle> bars,
  AiSnapshot snap, {
  double oversold = 35,
  double overbought = 65,
  double volumeSpike = 1.5,
}) {
  if (bars.length < 22) return AiPattern.range;

  final previous = bars.sublist(bars.length - 21, bars.length - 1);
  var highest = 0.0;
  var lowest = double.infinity;
  for (final bar in previous) {
    if (bar.high > highest) highest = bar.high;
    if (bar.low < lowest) lowest = bar.low;
  }

  final close = bars.last.close;
  final strong = snap.volumeRatio >= volumeSpike;

  if (close > highest && strong) return AiPattern.breakout;
  if (close < lowest && strong) return AiPattern.breakdown;

  if (snap.rsi >= overbought) return AiPattern.extendedUp;
  if (snap.rsi <= oversold) return AiPattern.extendedDown;

  if (snap.stackUp && close < snap.ema9 && close > snap.ema21) {
    return AiPattern.pullback;
  }
  if (snap.stackDown && close > snap.ema9 && close < snap.ema21) {
    return AiPattern.bounce;
  }
  return AiPattern.range;
}

/// `true` when the last two sessions made a higher high **and** a higher low.
bool isHigherHigh(List<Candle> bars) {
  if (bars.length < 2) return false;
  final last = bars[bars.length - 1];
  final before = bars[bars.length - 2];
  return last.high > before.high && last.low > before.low;
}

/// How many of the last [months]-worth of sessions closed green (0…1).
double greenShare(List<Candle> bars, {int lookback = 21}) {
  if (bars.isEmpty) return 0;
  final window = bars.length > lookback
      ? bars.sublist(bars.length - lookback)
      : bars;
  var green = 0;
  for (var i = 1; i < window.length; i++) {
    if (window[i].close > window[i - 1].close) green++;
  }
  return window.length > 1 ? green / (window.length - 1) : 0;
}

/// How far below the 52-week high the position score spreads over.
///
/// 25 %: at the high → 100, 12.5 % below → 50, 25 % or more below → 0.
const double kPositionBandPct = 25;

/// 0…100 momentum score: trend, 52-week position, RSI zone, volume, consistency.
///
/// A transparent weighted sum (not a model): every part is printed on the card,
/// so a score can be argued with instead of being taken on faith.
double momentumScore(
  AiSnapshot snap, {
  required double oversold,
  required double overbought,
  required double volumeSpike,
  required double nearHighPct,
  required double greenRatio,
  required double upMonths,
}) {
  // Trend: 3-month return, capped at ±40 % so one freak move cannot own the list.
  final trend = (snap.return3m.clamp(-40, 40) + 40) / 80 * 100;

  // Position: how close to its 52-week high it trades.
  //
  // Scored over a WIDE band ([kPositionBandPct], 25 %), not over the user's
  // [nearHighPct] (5 %). With a 5 % band every stock more than 5 % below its
  // high scored zero — a stock 6 % under the high tied with one 40 % under, and
  // the whole list collapsed to a handful of names sitting exactly at their
  // highs. [nearHighPct] stays what it is: the "near the high" *label*.
  final position =
      (100 - (snap.fromHighPct / kPositionBandPct) * 100).clamp(0, 100);

  // RSI zone: 55–68 is the sweet spot for momentum; above overbought fades.
  final rsi = snap.rsi;
  final rsiScore = rsi >= overbought
      ? 45.0
      : rsi <= oversold
          ? 55.0 // oversold in an uptrend is often the entry, not the exit
          : ((rsi - 40).clamp(0, 30) / 30 * 100).clamp(0, 100);

  // Volume: at or above the user's spike threshold scores full marks.
  final volume =
      (snap.volumeRatio / math.max(volumeSpike, 0.1) * 100).clamp(0, 100);

  // Consistency: green days + up months out of the study's three.
  final consistency = (greenRatio * 0.5 + (upMonths / 3) * 0.5) * 100;

  return trend * 0.30 +
      position * 0.20 +
      rsiScore * 0.20 +
      volume * 0.15 +
      consistency * 0.15;
}
