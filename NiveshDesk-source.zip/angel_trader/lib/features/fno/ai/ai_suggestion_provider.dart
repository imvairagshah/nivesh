// ---------------------------------------------------------------------------
// ai_suggestion_provider.dart — state for the F&O "AI Suggestion" screen.
//
// The engine itself is local and deterministic (lib/services/
// ai_suggestion_service.dart); this class only owns:
//   • resolving the F&O universe to instruments (same path as the 3-month
//     study, so both features agree on what "the F&O universe" means),
//   • running/cancelling a scan and exposing progress,
//   • remembering that the filters changed since the last scan, so a stale
//     list is never presented as if it obeyed the new thresholds.
// ---------------------------------------------------------------------------

import 'package:flutter/foundation.dart';

import '../../../data/local/dao/ipo_dao.dart';
import '../../../data/local/dao/scrip_dao.dart';
import '../../../data/remote/dto/scrip.dart';
import '../../../services/earnings_calendar_service.dart';
import '../../../services/ai_suggestion_service.dart'
    show AiNearMiss, AiProgress, AiSkip, AiSuggestionResult, AiSuggestionService;
import '../../../services/fno_universe.dart';
import '../../../services/scrip_master_service.dart';
import '../../../services/universe_catalog.dart';
import '../../settings/settings_provider.dart';
import 'ai_export.dart' show AiExportMeta;
import 'ai_suggestion.dart';

/// Where the screen is in its lifecycle.
enum AiStatus {
  /// Nothing has been run yet.
  idle,

  /// Universe / scrip resolution in flight (fast, local).
  resolving,

  /// The scan is running.
  running,

  /// A finished result is on screen.
  ready,

  /// The last run failed before producing anything.
  error,
}

class AiSuggestionProvider extends ChangeNotifier {
  AiSuggestionProvider({
    required AiSuggestionService service,
    required SettingsProvider settings,
    required ScripDao scripDao,
    required IpoDao ipoDao,
    required ScripMasterService scripMaster,
    required EarningsCalendarService earnings,
    FnoUniverse? fnoUniverse,
  })  : _service = service,
        _settings = settings,
        _scripDao = scripDao,
        _ipoDao = ipoDao,
        _scripMaster = scripMaster,
        _earnings = earnings,
        _fno = fnoUniverse {
    _settings.addListener(_onSettingsChanged);
  }

  final AiSuggestionService _service;
  final SettingsProvider _settings;
  final ScripDao _scripDao;
  final IpoDao _ipoDao;
  final ScripMasterService _scripMaster;

  /// Result dates — the only "event" data the app has, and the one that can
  /// turn a right direction into a loss (IV crush) or a sold strangle into a
  /// blow-up (gap). Never a guess: only NSE-announced dates are used.
  final EarningsCalendarService _earnings;

  FnoUniverse? _fno;

  AiStatus _status = AiStatus.idle;
  AiSuggestionResult? _result;
  AiProgress? _progress;
  String? _error;
  String? _note;
  bool _cancelled = false;
  bool _masterChecked = false;
  bool _eventsKnown = false;

  /// `true` when the last run had result dates to check against.
  bool get eventsKnown => _eventsKnown;

  /// True when the filters moved after the list on screen was produced.
  bool _stale = false;

  UniverseResolution _universe = UniverseResolution.empty;
  bool _resolvingUniverse = false;

  // ---- getters ------------------------------------------------------------

  AiStatus get status => _status;
  AiSuggestionResult? get result => _result;
  AiProgress? get progress => _progress;
  String? get error => _error;
  String? get note => _note;

  /// True while a scan (or the universe work before it) is in flight.
  bool get running => _status == AiStatus.running;
  bool get busy => _status == AiStatus.running || _status == AiStatus.resolving;
  bool get resolvingUniverse => _resolvingUniverse;
  bool get stale => _stale;
  bool get hasResult => _result != null && _result!.rows.isNotEmpty;

  int get universeSize => _universe.size;
  int get universeTotal => _fno?.length ?? _universe.size;
  List<String> get missing => _universe.missing;

  /// Thresholds the next (or the last) run used.
  AiFilters get filters => _settings.aiFilters;

  /// Progress as a 0…1 bar value, plus the Hinglish line under it.
  double get progressValue => _progress?.fraction ?? 0;
  String get progressLine => _progress?.label ?? '';
  int get shortlisted => _result?.rows.length ?? 0;

  /// `213 scan hue · 41 study gate paar · 12 momentum gate paar · 12 list me`
  String get funnelLine => _result?.funnelLine ?? '';

  /// How many were judged and fell at a filter (empty until the first scan).
  int get droppedCount => _result?.drops.length ?? 0;

  /// The closest misses — the honest answer to "itne kam kyun hain?".
  List<AiNearMiss> nearMisses([int limit = 10]) =>
      _result?.nearMisses(limit) ?? const <AiNearMiss>[];

  bool get canScan => !busy && !_universe.isEmpty;

  @override
  void dispose() {
    _settings.removeListener(_onSettingsChanged);
    super.dispose();
  }

  /// A filter moved in Settings: the list on screen was produced with the old
  /// numbers, so flag it instead of silently pretending it still applies.
  void _onSettingsChanged() {
    if (_result == null) return;
    _stale = true;
    notifyListeners();
  }

  // -------------------------------------------------------------------------
  // Lifecycle
  // -------------------------------------------------------------------------

  /// Opening the tab only resolves the universe — it never fires a scan on its
  /// own (same rule as the 3-month study).
  Future<void> bootstrap() => resolveUniverse();

  Future<void> resolveUniverse() async {
    _resolvingUniverse = true;
    if (_status == AiStatus.idle) _status = AiStatus.resolving;
    notifyListeners();
    try {
      final fno = _fno ??= await FnoUniverse.load();
      _universe = await UniverseCatalog.resolve(
        UniverseCatalog.fno,
        scripDao: _scripDao,
        ipoDao: _ipoDao,
        resolver: await _scripMaster.resolver(),
        fnoSymbols: fno.symbols,
      );
      if (fno.isEmpty) {
        _error = 'F&O list (assets/data/fno_symbols.csv) nahi mili.';
      } else if (_universe.isEmpty) {
        _error = 'F&O stocks ke tokens nahi mile — Scrip master update karo.';
      }
    } catch (e) {
      _error = 'Universe resolve nahi hua: $e';
      _status = AiStatus.error;
    } finally {
      _resolvingUniverse = false;
      if (_status == AiStatus.resolving) _status = AiStatus.idle;
      notifyListeners();
    }
  }

  /// Pulls the scrip master once when the F&O universe resolved thin, then
  /// resolves again. Mirrors FnoStudyProvider.ensureUniverse.
  Future<void> ensureUniverse({bool forceSync = false}) async {
    await resolveUniverse();
    if (_masterChecked && !forceSync) return;
    final expected = _fno?.length ?? 0;
    if (expected <= 0) return;
    if (_universe.size >= (expected * 0.8).floor() && !forceSync) {
      _masterChecked = true;
      return;
    }
    if (_scripMaster.isRefreshing) return;

    _note = 'Scrip master update ho raha hai — F&O list sirf '
        '${_universe.size}/$expected stocks resolve hui thi.';
    notifyListeners();
    try {
      await _scripMaster.refresh(force: true);
      await _scripMaster.resolver(forceRebuild: true);
      await resolveUniverse();
      _note = _universe.size >= expected
          ? 'Scrip master update ho gaya — poore ${_universe.size} F&O stocks mil gaye.'
          : 'Scrip master update ho gaya — ${_universe.size}/$expected stocks resolve hue.';
    } catch (e) {
      _note = 'Scrip master update fail hua ($e). Jo stocks mile sirf wahi scan honge.';
    } finally {
      _masterChecked = true;
      notifyListeners();
    }
  }

  // -------------------------------------------------------------------------
  // Scan
  // -------------------------------------------------------------------------

  Future<void> scan() async {
    if (busy) return;
    if (_universe.isEmpty) await ensureUniverse();
    if (_universe.isEmpty) {
      _error ??= 'F&O stocks ke tokens nahi mile — Scrip master update karo.';
      _status = AiStatus.error;
      notifyListeners();
      return;
    }

    _status = AiStatus.running;
    _cancelled = false;
    _error = null;
    _stale = false;
    _progress = AiProgress(
      stage: 'Taiyaari',
      done: 0,
      total: _universe.size,
      fraction: 0,
      elapsed: Duration.zero,
    );
    notifyListeners();

    // The calendar is cached for a day and only reaches out to NSE when it is
    // stale — a failure here must not stop the scan, it only costs the event
    // check.
    final events = <String, EarningsInfo>{};
    try {
      final calendar = await _earnings.load();
      events.addAll(calendar.bySymbol);
    } catch (_) {
      // No event data → the scan runs without the result check, and says so.
    }
    _eventsKnown = events.isNotEmpty;

    try {
      final res = await _service.run(
        universe: _universe.scrips,
        filters: _settings.aiFilters,
        companyNames: _fno?.companyNames ?? const {},
        events: events,
        capital: _settings.settings.startingCapital,
        onProgress: (p) {
          _progress = p;
          notifyListeners();
        },
        isCancelled: () => _cancelled,
      );
      _result = res;
      _status = AiStatus.ready;
      _note = res.rows.isEmpty
          ? (res.cancelled
              ? 'Scan beech me roka gaya — list adhoori hai.'
              : 'Is baar koi stock filter pass nahi hua. ${res.funnelLine} — '
                  'filter thoda dheela karke dobara scan karo.')
          : '${res.funnelLine}.';
      if (res.rows.length < res.filters.topN && !res.cancelled) {
        _note = '$_note List me ${res.filters.topN} ki jagah '
            '${res.rows.length} hain — is se zyada stock filter paar nahi kar '
            'paaye.';
      }
      if (!_eventsKnown) {
        _note = '$_note Result-date check is baar nahi ho paya (NSE calendar '
            'nahi mila) — result wale stock bhi list me ho sakte hain.';
      }
      if (res.skips.isNotEmpty) {
        _note = '$_note ${res.skips.length} stock chhoot gaye — “kaun chhoota” '
            'me dekho.';
      }
    } catch (e) {
      _error = 'Scan fail hua: $e';
      _status = AiStatus.error;
    } finally {
      if (_status == AiStatus.running) _status = AiStatus.ready;
      _progress = null;
      notifyListeners();
    }
  }

  void cancel() {
    if (!running) return;
    _cancelled = true;
    _note = 'Scan roka ja raha hai…';
    notifyListeners();
  }

  void clearError() {
    _error = null;
    if (_status == AiStatus.error) _status = AiStatus.idle;
    notifyListeners();
  }

  /// Kept for the screen's "filter" affordance: the list is rebuilt from
  /// Settings, so this only clears the stale flag after the user re-scans.
  void dismissNote() {
    _note = null;
    notifyListeners();
  }

  /// Convenience for tests / the filter sheet.
  List<AiSuggestion> get suggestions => _result?.rows ?? const <AiSuggestion>[];

  /// What the export writes in its Read Me.
  AiExportMeta? get exportMeta {
    final res = _result;
    if (res == null) return null;
    return AiExportMeta(
      asOf: res.asOf,
      runAt: res.runAt,
      rowCount: res.rows.length,
      withOptions: res.rows.where((r) => r.options != null).length,
      filters: res.filters,
      funnel: res.funnelLine,
    );
  }

  /// Skips grouped by reason, most common first.
  List<AiSkipGroup> get skipGroups => AiSkipGroup.group(_result?.skips ?? const <AiSkip>[]);

  /// Distinct scrips currently resolved (used by the empty state).
  List<Scrip> get scrips => _universe.scrips;
}

/// A reason plus every symbol that hit it — powers the "kaun chhoota" sheet.
class AiSkipGroup {
  final String reason;
  final List<String> symbols;

  const AiSkipGroup({required this.reason, required this.symbols});

  int get count => symbols.length;

  static List<AiSkipGroup> group(List<AiSkip> skips) {
    final map = <String, List<String>>{};
    for (final s in skips) {
      map.putIfAbsent(s.reason, () => <String>[]).add(s.symbol);
    }
    final groups = map.entries
        .map((e) => AiSkipGroup(reason: e.key, symbols: e.value..sort()))
        .toList()
      ..sort((a, b) => b.count.compareTo(a.count));
    return groups;
  }
}
