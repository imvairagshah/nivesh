// ---------------------------------------------------------------------------
// ai_backtest_screen.dart — "ye rule kitni baar sahi pada?" (hit-rate report).
//
// The screen's job is not to look clever, it is to be readable and honest:
//
//   • the headline is a COUNT, not a promise (`120 baar aaya · 58% sahi disha ·
//     ausat +1.8%`) — the exact shape the user asked for;
//   • every number carries the sample it came from, and a small sample is
//     labelled as noise instead of being dressed up;
//   • a fixed "ye kya nahi hai" card states the three things this report cannot
//     know (option premiums, costs, the future). That card is not optional: a
//     backtest that hides its limits is a sales pitch.
//
// The run itself is a local, offline replay over the candles already on the
// phone (see services/ai_backtest_service.dart).
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../data/local/dao/candle_dao.dart';
import '../../../data/local/dao/ipo_dao.dart';
import '../../../data/local/dao/scrip_dao.dart';
import '../../../services/ai_backtest_service.dart';
import '../../../services/market_data_service.dart';
import '../../../services/scrip_master_service.dart';
import '../../settings/settings_provider.dart';
import 'ai_backtest.dart';
import 'ai_backtest_provider.dart';

/// Opens the report. The provider is created here (everything it needs is
/// already above it in the tree), so the screen stays self-contained.
class AiBacktestScreen extends StatelessWidget {
  const AiBacktestScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<AiBacktestProvider>(
      create: (ctx) => AiBacktestProvider(
        service: AiBacktestService(
          source: ctx.read<MarketDataService>(),
          candles: ctx.read<CandleDao>(),
        ),
        settings: ctx.read<SettingsProvider>(),
        scripDao: ctx.read<ScripDao>(),
        ipoDao: ctx.read<IpoDao>(),
        scripMaster: ctx.read<ScripMasterService>(),
      )..bootstrap(),
      child: const _AiBacktestView(),
    );
  }
}

class _AiBacktestView extends StatelessWidget {
  const _AiBacktestView();

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<AiBacktestProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Hit rate / Backtest'),
        actions: [
          IconButton(
            tooltip: 'Ye kya hai',
            icon: const Icon(Icons.help_outline_rounded),
            onPressed: () => showBacktestReadMe(context),
          ),
        ],
      ),
      body: Column(
        children: [
          _BtControls(provider: provider),
          if (provider.error != null)
            _BtStrip(
              message: provider.error!,
              color: Theme.of(context).colorScheme.error,
            ),
          const Divider(height: 1),
          Expanded(
            child: provider.hasResult
                ? AiBacktestReport(result: provider.result!)
                : _BtEmptyState(provider: provider),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Controls
// ---------------------------------------------------------------------------

class _BtControls extends StatelessWidget {
  const _BtControls({required this.provider});

  final AiBacktestProvider provider;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final result = provider.result;

    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Kitna itihaas, aur har trade ko kitna samay',
            style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              _ChoiceRow<int>(
                label: 'Itihaas',
                value: provider.years,
                options: const [1, 2, 3],
                labelFor: (v) => '$v saal',
                onChanged: provider.busy ? null : provider.setYears,
              ),
              _ChoiceRow<int>(
                label: 'Har trade ko',
                value: provider.horizonBars,
                options: const [5, 10, 15],
                labelFor: (v) => '$v din',
                onChanged: provider.busy ? null : provider.setHorizon,
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: provider.busy ? null : provider.run,
                  icon: const Icon(Icons.play_arrow_rounded, size: 18),
                  label: Text(provider.hasResult ? 'Dobara chalao' : 'Chalao'),
                ),
              ),
              if (provider.running) ...[
                const SizedBox(width: 10),
                OutlinedButton(
                  onPressed: provider.cancel,
                  child: const Text('Roko'),
                ),
              ],
            ],
          ),
          if (provider.running) ...[
            const SizedBox(height: 10),
            LinearProgressIndicator(value: provider.progressValue),
            const SizedBox(height: 6),
            Text(
              provider.progressLine,
              style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
            ),
          ],
          if (result != null && provider.stale && !provider.busy) ...[
            const SizedBox(height: 8),
            Text(
              'Setting badli hai — upar diye number abhi ke hisaab me nahi hain. '
              '“Dobara chalao” dabao.',
              style: TextStyle(fontSize: 11, color: scheme.tertiary),
            ),
          ],
          if (provider.note != null && !provider.running) ...[
            const SizedBox(height: 8),
            Text(
              provider.note!,
              style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant),
            ),
          ],
        ],
      ),
    );
  }
}

class _ChoiceRow<T> extends StatelessWidget {
  const _ChoiceRow({
    required this.label,
    required this.value,
    required this.options,
    required this.labelFor,
    required this.onChanged,
  });

  final String label;
  final T value;
  final List<T> options;
  final String Function(T) labelFor;
  final ValueChanged<T>? onChanged;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 11.5,
            color: Theme.of(context).colorScheme.onSurfaceVariant,
          ),
        ),
        const SizedBox(width: 6),
        for (final option in options)
          Padding(
            padding: const EdgeInsets.only(right: 5),
            child: ChoiceChip(
              label: Text(labelFor(option)),
              selected: option == value,
              onSelected: onChanged == null ? null : (_) => onChanged!(option),
              visualDensity: VisualDensity.compact,
              materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
            ),
          ),
      ],
    );
  }
}

class _BtStrip extends StatelessWidget {
  const _BtStrip({required this.message, required this.color});

  final String message;
  final Color color;

  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        color: color.withValues(alpha: 0.12),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        child: Text(message, style: TextStyle(fontSize: 12, color: color)),
      );
}

// ---------------------------------------------------------------------------
// Empty state
// ---------------------------------------------------------------------------

class _BtEmptyState extends StatelessWidget {
  const _BtEmptyState({required this.provider});

  final AiBacktestProvider provider;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return ListView(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 24),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Kya ye rule sach me kaam karta hai?',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Is hisse me app apne hi purane data par wahi signal doharata '
                  'hai jo “AI Suggestion” aaj de raha hai — aur ginta hai ki '
                  'kitni baar sahi pada.',
                  style: TextStyle(fontSize: 12, height: 1.4),
                ),
                const SizedBox(height: 10),
                _bullet('Signal shaam ko milta hai, trade agle din ke open par '
                    'hota hai — aaj ka result kal ke data se nahi banaya jata.'),
                _bullet('Stop = 1 ATR, target = 2 × stop (wahi plan jo card par '
                    'hai).'),
                _bullet('Hisab phone ke cache se hota hai — internet par koi '
                    'model/API call nahi jati.'),
                const SizedBox(height: 10),
                Text(
                  'Pehli baar ${provider.years} saal ka data nahi mila to wo '
                  'broker se ek baar liya jayega (har stock ke liye ek request) '
                  '— uske baad ye hamesha offline chalega.',
                  style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        const _BtHonestCard(),
      ],
    );
  }

  Widget _bullet(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 5),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('•  ', style: TextStyle(fontSize: 12)),
            Expanded(
              child: Text(text, style: const TextStyle(fontSize: 12, height: 1.35)),
            ),
          ],
        ),
      );
}

// ---------------------------------------------------------------------------
// The report
// ---------------------------------------------------------------------------

/// The report itself — public so the numbers on it can be pinned by a widget
/// test (the screen above it owns the provider and the run).
class AiBacktestReport extends StatelessWidget {
  const AiBacktestReport({super.key, required this.result});

  final BtResult result;

  @override
  Widget build(BuildContext context) {
    final overall = result.overall;

    return ListView(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 24),
      children: [
        _BtHeadline(result: result, stats: overall),
        const SizedBox(height: 12),
        _BtStatGrid(stats: overall),
        const SizedBox(height: 12),
        if (result.byPattern.isNotEmpty) _BtPatternTable(result: result),
        if (result.bestSymbols().isNotEmpty) ...[
          const SizedBox(height: 12),
          _BtSymbolTable(result: result),
        ],
        const SizedBox(height: 12),
        const _BtHonestCard(),
        const SizedBox(height: 12),
        _BtFinePrint(result: result),
      ],
    );
  }
}

class _BtHeadline extends StatelessWidget {
  const _BtHeadline({required this.result, required this.stats});

  final BtResult result;
  final BtStats stats;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final good = stats.avgReturnPct >= 0;

    return Card(
      color: good
          ? scheme.primaryContainer.withValues(alpha: 0.35)
          : scheme.errorContainer.withValues(alpha: 0.35),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              stats.headline,
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 6),
            Text(
              result.coverageLine,
              style: TextStyle(fontSize: 11.5, color: scheme.onSurfaceVariant),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                _BtChip(
                  text: stats.confidenceLabel,
                  tone: stats.enoughSamples ? _Tone.plain : _Tone.warn,
                ),
                _BtChip(text: result.config.line),
                _BtChip(text: result.periodLine),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _BtStatGrid extends StatelessWidget {
  const _BtStatGrid({required this.stats});

  final BtStats stats;

  @override
  Widget build(BuildContext context) {
    final rows = <List<String>>[
      ['Trade', '${stats.samples}', 'jitni baar rule aaya'],
      ['Sahi disha', '${stats.directionPct.toStringAsFixed(0)}%',
        '${stats.directionHits} trade sahi disha me band'],
      ['Target laga', '${stats.targetRatePct.toStringAsFixed(0)}%',
        '${stats.wins} trade me 1 : 2 poora hua'],
      ['Stop laga', '${stats.stopRatePct.toStringAsFixed(0)}%',
        '${stats.losses} trade me stop chala'],
      ['Samay khatam', '${stats.timeoutRatePct.toStringAsFixed(0)}%',
        '${stats.timeouts} trade bina kisi level ke band'],
      ['Ausat natija', '${BtStats.signed(stats.avgReturnPct)}%',
        'madhy (median) ${BtStats.signed(stats.medianReturnPct)}%'],
      ['Ausat R', '${BtStats.signed(stats.avgR, 2)}R',
        'kul ${BtStats.signed(stats.totalR, 1)}R — 1R = 1 ATR ka jokhim'],
      ['Sabse bura daur', '−${stats.maxDrawdownR.toStringAsFixed(1)}R',
        'lagatar kitna jokhim ek saath ghat sakta tha'],
      ['Sabse achchha / bura',
        '${BtStats.signed(stats.best)}% / ${BtStats.signed(stats.worst)}%',
        'ek trade ka hadd-se-hadd natija'],
    ];

    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        child: Column(
          children: [
            for (final row in rows)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 5),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: 118,
                      child: Text(
                        row[0],
                        style: const TextStyle(
                          fontSize: 11.5,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 74,
                      child: Text(
                        row[1],
                        style: const TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    Expanded(
                      child: Text(
                        row[2],
                        style: TextStyle(
                          fontSize: 10.5,
                          height: 1.3,
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _BtPatternTable extends StatelessWidget {
  const _BtPatternTable({required this.result});

  final BtResult result;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Kaunsa rule kitna sahi',
              style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 4),
            Text(
              'Har signal ka apna hisaab — koi rule doosre ke natije ke piche '
              'chhup nahi sakta.',
              style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
            ),
            const SizedBox(height: 8),
            for (final row in result.byPattern)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Row(
                  children: [
                    Expanded(
                      flex: 4,
                      child: Text(
                        row.pattern.label,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        '${row.stats.samples} baar',
                        style: const TextStyle(fontSize: 11.5),
                      ),
                    ),
                    Expanded(
                      flex: 3,
                      child: Text(
                        '${row.stats.directionPct.toStringAsFixed(0)}% sahi · '
                        '${BtStats.signed(row.stats.avgReturnPct)}%',
                        style: TextStyle(
                          fontSize: 11.5,
                          fontWeight: FontWeight.w700,
                          color: row.stats.avgReturnPct >= 0
                              ? _gain(context)
                              : _loss(context),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _BtSymbolTable extends StatelessWidget {
  const _BtSymbolTable({required this.result});

  final BtResult result;

  @override
  Widget build(BuildContext context) {
    final best = result.bestSymbols(limit: 5);
    final worst = result.worstSymbols(limit: 5);

    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Kaunse stock me rule ne kaam kiya',
              style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 4),
            Text(
              'Sirf wahi stock jinme kam se kam 5 trade bane. Ye “kharido” ki '
              'salah nahi hai — sirf purani ginti hai.',
              style: TextStyle(
                fontSize: 10.5,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 8),
            _symbolGroup(context, 'Sabse achche', best),
            const SizedBox(height: 10),
            _symbolGroup(context, 'Sabse kamzor', worst),
          ],
        ),
      ),
    );
  }

  Widget _symbolGroup(
    BuildContext context,
    String heading,
    List<BtSymbolRow> rows,
  ) {
    if (rows.isEmpty) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          heading,
          style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 4),
        for (final row in rows)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: Row(
              children: [
                SizedBox(
                  width: 86,
                  child: Text(
                    row.symbol,
                    style: const TextStyle(
                      fontSize: 11.5,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                Text(
                  '${row.stats.samples} trade',
                  style: const TextStyle(fontSize: 11),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    '${row.stats.directionPct.toStringAsFixed(0)}% sahi · '
                    '${BtStats.signed(row.stats.avgReturnPct)}% · '
                    '${BtStats.signed(row.stats.avgR, 2)}R',
                    style: TextStyle(
                      fontSize: 11,
                      color: row.stats.avgR >= 0 ? _gain(context) : _loss(context),
                    ),
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// The honesty cards — never optional, never collapsed
// ---------------------------------------------------------------------------

class _BtHonestCard extends StatelessWidget {
  const _BtHonestCard();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Card(
      color: scheme.tertiaryContainer.withValues(alpha: 0.35),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Ye kya nahi hai — pehle ye padh lo',
              style: TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w800,
                color: scheme.onTertiaryContainer,
              ),
            ),
            const SizedBox(height: 8),
            _line('Ye koi guarantee nahi hai. Bazar badalta hai — purana '
                'natija aane wale natije ki guarantee nahi deta.'),
            _line('Hisab stock (underlying) ka hai, option ka nahi. Purane '
                'premium ka itihaas app ke paas nahi hai, aur option me theta '
                'aur IV bhi chalte hain — asli option ka natija alag ho sakta '
                'hai.'),
            _line('Kharcha shamil nahi hai: brokerage, STT/GST, slippage aur '
                'bid-ask is hisaab me nahi hain. Asli natija inke baad thoda '
                'kam hoga.'),
            _line('Jo sample chhota hai us par bharosa nahi karna chahiye — '
                'upar har number ke saath likha hai ki kitne trade the.'),
          ],
        ),
      ),
    );
  }

  Widget _line(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('•  ', style: TextStyle(fontSize: 12)),
            Expanded(
              child: Text(
                text,
                style: const TextStyle(fontSize: 11.5, height: 1.4),
              ),
            ),
          ],
        ),
      );
}

class _BtFinePrint extends StatelessWidget {
  const _BtFinePrint({required this.result});

  final BtResult result;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final shortfall = result.shortfallNote;
    final lines = <String>[
      result.networkNote,
      if (shortfall != null) shortfall,
      if (result.mixedSignals > 0)
        '${result.mixedSignals} baar pattern aur direction ek doosre se alag '
            'ishara de rahe the — aise din trade gina hi nahi gaya (engine '
            'unko “mixed” keh kar chhod deta hai).',
      if (result.skipped.isNotEmpty)
        '${result.skipped.length} stock ka data nahi mila, is liye wo hisaab '
            'me nahi hain.',
      'Hisab ka samay: ${result.duration.inSeconds} second · '
          '${result.config.warmupBars} bars ka warm-up har stock ke shuru me '
          'chhoda gaya.',
    ];

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Puri jankari',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 6),
            for (final line in lines)
              Padding(
                padding: const EdgeInsets.only(bottom: 5),
                child: Text(
                  line,
                  style: TextStyle(
                    fontSize: 11,
                    height: 1.35,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Small shared bits
// ---------------------------------------------------------------------------

enum _Tone { plain, warn }

class _BtChip extends StatelessWidget {
  const _BtChip({required this.text, this.tone = _Tone.plain});

  final String text;
  final _Tone tone;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final warn = tone == _Tone.warn;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: warn
            ? scheme.tertiaryContainer.withValues(alpha: 0.5)
            : scheme.surfaceContainerHighest.withValues(alpha: 0.6),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 10.5,
          fontWeight: FontWeight.w700,
          color: warn ? scheme.onTertiaryContainer : scheme.onSurfaceVariant,
        ),
      ),
    );
  }
}

Color _gain(BuildContext context) {
  final scheme = Theme.of(context).colorScheme;
  return scheme.brightness == Brightness.dark
      ? const Color(0xFF7BD88F)
      : const Color(0xFF0B7A3B);
}

Color _loss(BuildContext context) {
  final scheme = Theme.of(context).colorScheme;
  return scheme.brightness == Brightness.dark
      ? const Color(0xFFFF8A80)
      : const Color(0xFFB3261E);
}

// ---------------------------------------------------------------------------
// Read Me
// ---------------------------------------------------------------------------

/// The plain-language note: what was counted, and what it can never tell you.
void showBacktestReadMe(BuildContext context) {
  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) => DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.75,
      maxChildSize: 0.92,
      minChildSize: 0.4,
      builder: (_, controller) => ListView(
        controller: controller,
        padding: const EdgeInsets.fromLTRB(18, 6, 18, 24),
        children: const [
          Text(
            'Hit rate / backtest — kaise padha jaye',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
          ),
          SizedBox(height: 12),
          Text(
            'Ye report app ke apne purane candles par wahi signal dohara kar '
            'banti hai jo “AI Suggestion” aaj de raha hai. Koi model, koi '
            'internet call, koi andaza nahi — sirf ginti.',
            style: TextStyle(fontSize: 12.5, height: 1.45),
          ),
          SizedBox(height: 12),
          Text('Signal ka matlab', style: TextStyle(fontWeight: FontWeight.w800)),
          SizedBox(height: 4),
          Text(
            'Card jab “Breakout / Breakdown / Pullback / Bounce” kahe aur uski '
            'direction (upar/neeche) bhi usi taraf ho, to ek trade gina jata '
            'hai. Dono ishare alag hon to wo din chhod diya jata hai — aur '
            '“Puri jankari” me likha hai ki kitne chhode.',
            style: TextStyle(fontSize: 12, height: 1.45),
          ),
          SizedBox(height: 12),
          Text('Trade kaise chalta hai', style: TextStyle(fontWeight: FontWeight.w800)),
          SizedBox(height: 4),
          Text(
            'Shaam ko signal → agle din ke OPEN par entry. Stop = 1 ATR, '
            'target = 2 × stop. Har trade ko 5/10/15 din ka samay. Ek hi din '
            'me dono level chhuye to stop mana jata hai (sakht nazariya). '
            'Koi level na chhue to aakhiri din ke close par band.',
            style: TextStyle(fontSize: 12, height: 1.45),
          ),
          SizedBox(height: 12),
          Text('Number ka matlab', style: TextStyle(fontWeight: FontWeight.w800)),
          SizedBox(height: 4),
          Text(
            '• “Sahi disha” = trade jis disha me liya gaya tha usi me band hua.\n'
            '• “Ausat R” = har trade me kitna “jokhim” mila. 1R ka matlab hai '
            'jitna stop ka nuksan tha utna munafa.\n'
            '• “Sabse bura daur” = lagatar kitna nuksan ek saath jhelna pada '
            'hota — ye number bade munafe se zyada bataata hai.',
            style: TextStyle(fontSize: 12, height: 1.45),
          ),
          SizedBox(height: 12),
          Text('Had', style: TextStyle(fontWeight: FontWeight.w800)),
          SizedBox(height: 4),
          Text(
            'Purana premium ka data nahi hai (is liye hisaab stock ka hai, '
            'option ka nahi), kharcha shamil nahi hai, aur chhote sample par '
            'koi nishchit baat nahi kahi ja sakti. Ye report faisla lene me '
            'madad karti hai, faisla khud nahi leti.',
            style: TextStyle(fontSize: 12, height: 1.45),
          ),
        ],
      ),
    ),
  );
}
