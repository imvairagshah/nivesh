// ---------------------------------------------------------------------------
// ai_plan.dart — the part that turns a read into a trade you can actually take.
//
// A "suggestion" without an entry, a stop and a size is an opinion. This file
// is arithmetic over numbers the scan already has (ATR, 20-day range, premium,
// lot size, capital) and it is deliberately conservative:
//
//   • risk is defined FIRST (1 × ATR, or −40 % of the premium),
//   • the target is 2 × that risk (a plain 1 : 2 plan, not a wish),
//   • size follows from "capital ka kitna % ek trade me dau par lagana hai".
//
// Pure: no Flutter, no database, no network — so it is tested against
// hand-checked arithmetic.
// ---------------------------------------------------------------------------

import 'ai_indicators.dart';
import 'ai_suggestion.dart';

/// One trade plan. Every rupee figure is derived, never invented.
class AiTradePlan {
  const AiTradePlan({
    required this.entry,
    required this.stop,
    required this.target,
    required this.risk,
    required this.reward,
    required this.entryNote,
    this.premium,
    this.premiumStop,
    this.premiumTarget,
    this.lotCost,
    this.riskPerLot,
    this.lotSize = 0,
    this.lots = 0,
    this.capital = 0,
    this.riskPct = 1.5,
  });

  /// Where the trade is taken — CMP, or above the breakout level.
  final double entry;

  /// Underlying price that says "this idea was wrong".
  final double stop;

  /// Underlying price at which the plan books profit.
  final double target;

  /// `entry − stop` (always positive).
  final double risk;

  /// `target − entry` (always positive).
  final double reward;

  /// `CMP ke upar (breakout level)` / `CMP ke aas-paas`.
  final String entryNote;

  /// The leg's premium, when the plan is an option trade.
  final double? premium;

  /// Premium stop: −40 % of the premium (options decay; a small move in the
  /// stock can still lose 40 % of a short-dated option).
  final double? premiumStop;

  /// Premium target: +80 % (a 1 : 2 plan on the premium too).
  final double? premiumTarget;

  /// `premium × lotSize` — what one lot costs.
  final double? lotCost;

  /// What one lot loses if the stop is hit.
  final double? riskPerLot;

  final int lotSize;

  /// How many lots the risk budget allows (0 = even one lot is too big).
  final int lots;

  final double capital;

  /// The user's risk budget, in percent of capital per trade.
  final double riskPct;

  /// `1 : 2.0` — reward per unit of risk.
  double get rr => risk <= 0 ? 0 : reward / risk;

  /// `true` when the plan is worth taking by its own numbers.
  bool get worthIt => rr >= 1.5;

  /// `true` when even one lot breaks the risk budget.
  bool get tooBig => premium != null && lots == 0;

  /// How much of the capital one lot actually risks, in percent.
  double get capitalAtRiskPct =>
      capital <= 0 || riskPerLot == null ? 0 : riskPerLot! / capital * 100;

  /// `₹1,482 ke upar (20-din ka high)` / `₹1,455 (−1.8 %)`.
  String get entryLine => entryNote;
}

/// Builds the plan for one idea.
///
/// [snap] carries CMP, ATR, the 52-week high and the 20-session range;
/// [pattern] decides whether the entry is a trigger above the market or simply
/// CMP; [premium] + [lotSize] turn the underlying plan into an option plan.
AiTradePlan buildTradePlan({
  required AiSnapshot snap,
  required AiDirection direction,
  required AiPattern pattern,
  double? premium,
  int lotSize = 0,
  double capital = 0,
  double riskPct = 1.5,
  double atrMultiple = 1,
  double rewardMultiple = 2,
}) {
  final atr = snap.atr;
  final cmp = snap.ltp;
  final bullish = direction != AiDirection.bearish;

  // ---- entry ---------------------------------------------------------------
  // A breakout is only a trade if it actually breaks: wait for the level.
  final usesTrigger = pattern == AiPattern.breakout ||
      pattern == AiPattern.breakdown ||
      pattern == AiPattern.extendedUp;
  final entry = usesTrigger ? (cmp + (bullish ? 0.25 * atr : -0.25 * atr)) : cmp;
  final entryNote = usesTrigger
      ? '₹${_money(entry)} ke upar (CMP ₹${_money(cmp)})'
      : '₹${_money(cmp)} ke aas-paas';

  // ---- stop: one ATR against the trade -------------------------------------
  final risk = atr * atrMultiple;
  final stop = bullish ? entry - risk : entry + risk;

  // ---- target: two units of risk, capped at a real level -------------------
  var reward = risk * rewardMultiple;
  var target = bullish ? entry + reward : entry - reward;
  if (bullish && snap.high52w > entry && snap.high52w < target) {
    // The 52-week high is resistance — do not plan through it.
    target = snap.high52w;
    reward = target - entry;
  } else if (!bullish && snap.low52w < entry && snap.low52w > target) {
    target = snap.low52w;
    reward = entry - target;
  }

  // ---- option leg: −40 % stop, +80 % target, 1 : 2 -------------------------
  double? premiumStop;
  double? premiumTarget;
  double? lotCost;
  double? riskPerLot;
  var lots = 0;

  if (premium != null && premium > 0 && lotSize > 0) {
    premiumStop = premium * 0.6;
    premiumTarget = premium * 1.8;
    lotCost = premium * lotSize;
    riskPerLot = (premium - premiumStop) * lotSize;

    final budget = capital * riskPct / 100;
    if (budget > 0 && riskPerLot > 0) {
      lots = (budget / riskPerLot).floor();
    }
  }

  return AiTradePlan(
    entry: entry,
    stop: stop,
    target: target,
    risk: risk,
    reward: reward,
    entryNote: entryNote,
    premium: premium,
    premiumStop: premiumStop,
    premiumTarget: premiumTarget,
    lotCost: lotCost,
    riskPerLot: riskPerLot,
    lotSize: lotSize,
    lots: lots,
    capital: capital,
    riskPct: riskPct,
  );
}

/// `1482` / `1482.35` — prices without a currency symbol (the UI adds it).
String _money(double value) =>
    value == value.roundToDouble() ? value.toStringAsFixed(0) : value.toStringAsFixed(2);
