// ---------------------------------------------------------------------------
// ai_backtest_provider.dart — state for the hit-rate report.
//
// Deliberately thin: it resolves the F&O universe (the same list the AI
// Suggestion scan uses, so the two features can never disagree about what "the
// universe" is), runs the replay, and owns the progress/cancel plumbing. Every
// number on the screen is computed by the pure engine in ai_backtest.dart.
//
// It also never fires a run on its own — the report costs history, and the user
// asks for it.
// ---------------------------------------------------------------------------

import 'package:flutter/foundation.dart';

import '../../../data/local/dao/ipo_dao.dart';
import '../../../data/local/dao/scrip_dao.dart';
import '../../../services/ai_backtest_service.dart';
import '../../../services/ai_suggestion_service.dart' show AiProgress, AiSkip;
import '../../../services/fno_universe.dart';
import '../../../services/scrip_master_service.dart';
import '../../../services/universe_catalog.dart';
import '../../settings/settings_provider.dart';
import 'ai_backtest.dart';
import 'ai_suggestion_provider.dart' show AiSkipGroup;

enum AiBacktestStatus { idle, resolving, running, ready, error }

class AiBacktestProvider extends ChangeNotifier {
  AiBacktestProvider({
    required AiBacktestService service,
    required SettingsProvider settings,
    required ScripDao scripDao,
    required IpoDao ipoDao,
    required ScripMasterService scripMaster,
    FnoUniverse? fnoUniverse,
  })  : _service = service,
        _settings = settings,
        _scripDao = scripDao,
        _ipoDao = ipoDao,
        _scripMaster = scripMaster,
        _fno = fnoUniverse;

  final AiBacktestService _service;
  final SettingsProvider _settings;
  final ScripDao _scripDao;
  final IpoDao _ipoDao;
  final ScripMasterService _scripMaster;
  FnoUniverse? _fno;

  AiBacktestStatus _status = AiBacktestStatus.idle;
  BtResult? _result;
  AiProgress? _progress;
  String? _error;
  String? _note;
  bool _cancelled = false;
  bool _stale = false;

  /// How much history to replay.
  int _years = 2;

  /// How many sessions each trade is given.
  int _horizonBars = 10;

  UniverseResolution _universe = UniverseResolution.empty;

  // ---- getters ------------------------------------------------------------

  AiBacktestStatus get status => _status;
  BtResult? get result => _result;
  AiProgress? get progress => _progress;
  String? get error => _error;
  String? get note => _note;
  bool get stale => _stale;

  int get years => _years;
  int get horizonBars => _horizonBars;

  bool get running => _status == AiBacktestStatus.running;
  bool get busy => running || _status == AiBacktestStatus.resolving;
  bool get hasResult => _result != null && _result!.trades.isNotEmpty;

  int get universeSize => _universe.size;
  double get progressValue => _progress?.fraction ?? 0;
  String get progressLine => _progress?.label ?? '';

  /// The config the next run will use — built from the user's own filters, so
  /// the report describes *their* engine, not a default one.
  BtConfig get config {
    final filters = _settings.aiFilters;
    return BtConfig(
      horizonBars: _horizonBars,
      volumeSpike: filters.volumeSpike,
      oversold: filters.rsiOversold,
      overbought: filters.rsiOverbought,
    );
  }

  /// The current result's config (what the numbers on screen were made with).
  BtConfig? get usedConfig => _result?.config;

  /// Symbols that fell out of the run, grouped by reason.
  List<AiSkipGroup> get skipGroups => AiSkipGroup.group(
        [
          for (final entry in (_result?.skipped ?? const {}).entries)
            AiSkip(entry.key, entry.value),
        ],
      );

  void setYears(int value) {
    if (_years == value) return;
    _years = value;
    _stale = _result != null;
    notifyListeners();
  }

  void setHorizon(int value) {
    if (_horizonBars == value) return;
    _horizonBars = value;
    _stale = _result != null;
    notifyListeners();
  }

  // -------------------------------------------------------------------------
  // Universe
  // -------------------------------------------------------------------------

  Future<void> bootstrap() => resolveUniverse();

  Future<void> resolveUniverse() async {
    _status = AiBacktestStatus.resolving;
    notifyListeners();
    try {
      final fno = _fno ??= await FnoUniverse.load();
      _universe = await UniverseCatalog.resolve(
        UniverseCatalog.fno,
        scripDao: _scripDao,
        ipoDao: _ipoDao,
        resolver: await _scripMaster.resolver(),
        fnoSymbols: fno.symbols,
      );
      if (_universe.isEmpty) {
        _error = 'F&O stocks ke tokens nahi mile — Scrip master update karo.';
        _status = AiBacktestStatus.error;
      }
    } catch (e) {
      _error = 'Universe resolve nahi hua: $e';
      _status = AiBacktestStatus.error;
    } finally {
      if (_status == AiBacktestStatus.resolving) {
        _status = AiBacktestStatus.idle;
      }
      notifyListeners();
    }
  }

  // -------------------------------------------------------------------------
  // Run
  // -------------------------------------------------------------------------

  Future<void> run() async {
    if (busy) return;
    if (_universe.isEmpty) await resolveUniverse();
    if (_universe.isEmpty) {
      _error ??= 'F&O stocks ke tokens nahi mile — Scrip master update karo.';
      _status = AiBacktestStatus.error;
      notifyListeners();
      return;
    }

    _status = AiBacktestStatus.running;
    _cancelled = false;
    _error = null;
    _note = null;
    _progress = AiProgress(
      stage: 'Taiyaari',
      done: 0,
      total: _universe.size,
      fraction: 0,
      elapsed: Duration.zero,
    );
    notifyListeners();

    try {
      final result = await _service.run(
        universe: _universe.scrips,
        config: config,
        years: _years,
        onProgress: (p) {
          _progress = p;
          notifyListeners();
        },
        isCancelled: () => _cancelled,
      );
      _result = result;
      _stale = false;
      _status = AiBacktestStatus.ready;

      if (result.cancelled) {
        _note = 'Backtest beech me roka gaya — ye hisaab adhoora hai.';
      } else if (result.trades.isEmpty) {
        _note = 'Is window me koi signal hi nahi aaya. Horizon badha kar '
            '($horizonBars din) ya zyada saal chun kar dekho.';
      } else if (!result.overall.enoughSamples) {
        _note = 'Sirf ${result.trades.length} trade mile — itne kam sample par '
            'koi nishchit baat nahi kahi ja sakti.';
      }
    } catch (e) {
      _error = 'Backtest fail hua: $e';
      _status = AiBacktestStatus.error;
    } finally {
      if (_status == AiBacktestStatus.running) {
        _status = AiBacktestStatus.ready;
      }
      _progress = null;
      notifyListeners();
    }
  }

  void cancel() {
    if (!running) return;
    _cancelled = true;
    _note = 'Backtest roka ja raha hai…';
    notifyListeners();
  }

  void clearError() {
    _error = null;
    if (_status == AiBacktestStatus.error) {
      _status = AiBacktestStatus.idle;
    }
    notifyListeners();
  }
}
