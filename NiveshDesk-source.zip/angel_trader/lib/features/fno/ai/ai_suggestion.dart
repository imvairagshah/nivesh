// ---------------------------------------------------------------------------
// ai_suggestion.dart — one "AI Suggestion" row: direction, expected move, the
// technical reason, and the option trade that follows from it.
//
// Pure: no network, no database, no Flutter. The service collects the data, this
// file turns it into the words the user reads and the trade the card suggests.
//
// The option rules are written down here in one place (see [resolveStrategy])
// instead of being sprinkled through the UI — they are the part a trader will
// argue with, so they must be legible and testable.
// ---------------------------------------------------------------------------

import 'ai_indicators.dart';
import 'ai_plan.dart';

/// What the user can tune. Every default is a starting point, never a law — the
/// Settings screen edits these and the scan obeys them exactly.
class AiFilters {
  const AiFilters({
    this.rsiOversold = 35,
    this.rsiOverbought = 65,
    this.volumeSpike = 1.5,
    this.nearHighPct = 5,
    this.minStudyScore = 5,
    this.minScore = 45,
    this.minTurnoverCrore = 10,
    this.eventBlockDays = 5,
    this.riskPct = 1.5,
    this.buyMinDte = 7,
    this.sellMaxDte = 20,
    this.topN = 20,
  });

  /// RSI at or below this is "oversold" (the brief's own example: 30 → 35).
  final double rsiOversold;

  /// RSI at or above this is "overbought".
  final double rsiOverbought;

  /// Last session's volume must be at least this multiple of the 20-day average
  /// to count as a spike.
  final double volumeSpike;

  /// "Near the 52-week high" band, in percent.
  final double nearHighPct;

  /// Minimum 3-month study score (0…12). 5 = "upar ki taraf, par kamaal ka
  /// nahi" — the bottom of what is worth showing.
  final double minStudyScore;

  /// Minimum momentum score (0…100) to reach the list at all. 45 keeps a real
  /// Top 20 on screen in an ordinary market; raise it (Settings) for a stricter
  /// list — the scan note always says how many fell at this gate.
  final double minScore;

  /// Minimum average cash turnover (₹ crore/day, 20 sessions) — below this the
  /// stock's options are too thin to fill honestly.
  final double minTurnoverCrore;

  /// How close a **confirmed** result date may be before every new option
  /// position is refused (IV crush on buys, gap risk on sells).
  final int eventBlockDays;

  /// How much of the paper capital one trade may risk, in percent. Size is
  /// computed from it — a plan that needs more is refused, not quietly rounded.
  final double riskPct;

  /// Fewest days to expiry a **bought** option may have: theta eats a
  /// short-dated option faster than the stock can move.
  final int buyMinDte;

  /// Most days to expiry a **sold** strangle may have: beyond this, theta is
  /// too slow to be worth the margin and the gap risk.
  final int sellMaxDte;

  /// How many rows the screen shows (the brief asks for 20).
  final int topN;

  AiFilters copyWith({
    double? rsiOversold,
    double? rsiOverbought,
    double? volumeSpike,
    double? nearHighPct,
    double? minStudyScore,
    double? minScore,
    double? minTurnoverCrore,
    int? eventBlockDays,
    double? riskPct,
    int? buyMinDte,
    int? sellMaxDte,
    int? topN,
  }) =>
      AiFilters(
        rsiOversold: rsiOversold ?? this.rsiOversold,
        rsiOverbought: rsiOverbought ?? this.rsiOverbought,
        volumeSpike: volumeSpike ?? this.volumeSpike,
        nearHighPct: nearHighPct ?? this.nearHighPct,
        minStudyScore: minStudyScore ?? this.minStudyScore,
        minScore: minScore ?? this.minScore,
        minTurnoverCrore: minTurnoverCrore ?? this.minTurnoverCrore,
        eventBlockDays: eventBlockDays ?? this.eventBlockDays,
        riskPct: riskPct ?? this.riskPct,
        buyMinDte: buyMinDte ?? this.buyMinDte,
        sellMaxDte: sellMaxDte ?? this.sellMaxDte,
        topN: topN ?? this.topN,
      );

  static const AiFilters defaults = AiFilters();
}

/// Which way the engine thinks the stock goes next.
enum AiDirection {
  bullish('Bullish', 'upar'),
  bearish('Bearish', 'neeche'),
  sideways('Sideways', 'range me');

  const AiDirection(this.label, this.hinglish);

  final String label;
  final String hinglish;
}

/// What the card says happens next — a plain phrase, not a promise.
enum AiMove {
  breakout('Strong Breakout'),
  gapUp('Gap up'),
  breakdown('Breakdown'),
  pullback('Pullback'),
  bounce('Pullback rally'),
  consolidation('Range / Build-up'),
  cooling('Thakawat (overbought)');

  const AiMove(this.label);

  final String label;
}

/// The option trade suggested for one row.
class AiStrategy {
  const AiStrategy({
    required this.action,
    required this.name,
    required this.strikeType,
    required this.pair,
    required this.why,
    this.wait = false,
  });

  /// `Buy` / `Sell` / `Wait`.
  final String action;

  /// `Directional Buy` / `Bull Call Spread` / `Straddle (ATM jodi)` …
  final String name;

  /// `ATM` / `OTM` / `ATM + OTM` (or `—` when there is no trade).
  final String strikeType;

  /// `CE 2650 + PE 2650` — the actual contracts to trade.
  final String pair;

  /// One line on why this trade, not another.
  final String why;

  /// `true` when the honest answer is "do nothing yet".
  final bool wait;

  static const AiStrategy none = AiStrategy(
    action: 'Wait',
    name: 'Koi trade nahi',
    strikeType: '—',
    pair: '—',
    why: 'Is stock ke options ka data nahi mila.',
    wait: true,
  );
}

/// The numbers the strategy rules need from the option side.
class AiOptionContext {
  const AiOptionContext({
    this.atmStrike,
    this.otmCeStrike,
    this.otmPeStrike,
    this.avgIv,
    this.straddleTotal,
    this.ivExpensive = false,
    this.edgePct,
    this.lotSize = 0,
    this.daysToExpiry = 0,
    this.daysToResult,
    this.thin = false,
  });

  final double? atmStrike;
  final double? otmCeStrike;
  final double? otmPeStrike;

  /// Average IV of the ATM pair, in percent (reverse-solved from its premium).
  final double? avgIv;

  /// What the ATM jodi actually costs right now, from the broker's quotes.
  final double? straddleTotal;

  /// `true` when the premium charges more per day than the stock moves.
  final bool ivExpensive;

  /// ATR% − IV/√252 — what the stock does versus what the option charges for.
  final double? edgePct;

  final int lotSize;

  /// Calendar days to expiry — a strategy without it is a guess.
  final int daysToExpiry;

  /// Calendar days to the next **confirmed** result (null = none announced).
  final int? daysToResult;

  /// `true` when the quoted premium is so small the strike is effectively
  /// untradeable (a wide bid-ask would eat the whole edge).
  final bool thin;

  bool get hasPair => atmStrike != null && lotSize > 0;

  /// `true` when a result lands inside the holding window — the one event that
  /// can make a correct direction lose money (IV crush) or a short premium blow
  /// up (gap).
  ///
  /// Only counts when the announcement lands **inside** the trade's window:
  /// an option that expires before the result never sees the crush (IV usually
  /// rises into an event, which helps a buyer).
  bool isEvent(int eventBlockDays) {
    final days = daysToResult;
    if (days == null || days < 0) return false;
    final window =
        daysToExpiry > 0 && daysToExpiry < eventBlockDays ? daysToExpiry : eventBlockDays;
    return days <= window;
  }

  /// `IV 20% · jodi ₹13.50` — the two facts a trader wants before the trade.
  String get premiumLine {
    final parts = <String>[];
    if (avgIv != null) parts.add('IV ${avgIv!.toStringAsFixed(0)}%');
    if (straddleTotal != null && straddleTotal! > 0) {
      parts.add('jodi ₹${straddleTotal!.toStringAsFixed(2)}');
    }
    return parts.join(' · ');
  }
}

/// One row of the Top-N list.
class AiSuggestion {
  const AiSuggestion({
    required this.symbol,
    required this.name,
    required this.rank,
    required this.score,
    required this.studyScore,
    required this.snapshot,
    required this.pattern,
    required this.direction,
    required this.move,
    required this.rationale,
    required this.strategy,
    this.options,
    this.resultDate,
    this.resultConfirmed = false,
    this.plan,
  });

  final String symbol;
  final String name;

  /// 1-based position in the list.
  final int rank;

  /// Momentum score, 0…100.
  final double score;

  /// The 3-month study's own score, 0…12.
  final double studyScore;

  final AiSnapshot snapshot;
  final AiPattern pattern;
  final AiDirection direction;
  final AiMove move;

  /// Bullet reasons (`RSI 62 · volume 2.1x · 52w high se 1.2% neeche`).
  final List<String> rationale;
  final AiStrategy strategy;

  /// The option numbers behind [strategy] — null until the scan priced them.
  final AiOptionContext? options;

  /// Next **confirmed** result date (NSE board meeting), never a guess.
  final DateTime? resultDate;

  /// `true` when [resultDate] is an announced date rather than an estimate.
  final bool resultConfirmed;

  /// Entry / stop / target / size — the plan that makes this a trade rather
  /// than an opinion. Null for "wait" rows and for rows nothing was priced for.
  final AiTradePlan? plan;

  /// `Result: 12 din me` / `Result: aaj` / null when nothing is announced.
  String resultLine(DateTime today) {
    final date = resultDate;
    if (date == null || !resultConfirmed) return '';
    final days = DateTime(date.year, date.month, date.day)
        .difference(DateTime(today.year, today.month, today.day))
        .inDays;
    if (days < 0) return '';
    if (days == 0) return 'Result: aaj';
    if (days == 1) return 'Result: kal';
    return 'Result: $days din me';
  }

  /// The card's one-line reason.
  String get rationaleLine => rationale.join(' · ');

  AiSuggestion copyWithRank(int value) => AiSuggestion(
        symbol: symbol,
        name: name,
        rank: value,
        score: score,
        studyScore: studyScore,
        snapshot: snapshot,
        pattern: pattern,
        direction: direction,
        move: move,
        rationale: rationale,
        strategy: strategy,
        options: options,
        resultDate: resultDate,
        resultConfirmed: resultConfirmed,
        plan: plan,
      );
}

/// Which way the stock is pointed: the study's 3-month trend, tempered by the
/// moving-average stack (a 3-month uptrend that has rolled over is not bullish).
AiDirection resolveDirection(AiSnapshot snap, double return3m, bool stackUp) {
  // Both halves agree → the plain answer.
  if (snap.stackDown && return3m < 0) return AiDirection.bearish;
  if (snap.stackUp && return3m > 0) return AiDirection.bullish;

  // Mixed signals: the moving averages are the fresher of the two, so they get
  // the last word — but a quarter that is still strongly up is not ignored.
  if (snap.stackDown) {
    return return3m > 3 ? AiDirection.bullish : AiDirection.sideways;
  }
  if (snap.stackUp) {
    return return3m > 0 ? AiDirection.bullish : AiDirection.sideways;
  }

  // No stack either way (a choppy market) → fall back on the quarter.
  if (stackUp && return3m > 0) return AiDirection.bullish;
  return return3m.abs() < 3 ? AiDirection.sideways : AiDirection.bullish;
}

/// The phrase under "Expected Movement".
AiMove resolveMove(AiPattern pattern, AiDirection direction) {
  switch (pattern) {
    case AiPattern.breakout:
      return AiMove.breakout;
    case AiPattern.breakdown:
      return AiMove.breakdown;
    case AiPattern.pullback:
      return AiMove.pullback;
    case AiPattern.bounce:
      return AiMove.bounce;
    case AiPattern.extendedUp:
      return AiMove.cooling;
    case AiPattern.extendedDown:
      return direction == AiDirection.bullish ? AiMove.gapUp : AiMove.bounce;
    case AiPattern.range:
      return AiMove.consolidation;
  }
}

/// The option trade, from the direction + pattern + what the premium costs.
///
/// The rules, in plain words (the same text is in the screen's Read Me):
///
///   • Trending stock, premium reasonable (option jitna charge karta hai us se
///     zyada stock chalta hai) → **directional buy** of the ATM option.
///   • Trending but premium mehengi (IV/√252 ≥ 1.25 × ATR%) → **spread**: ATM kharido,
///     uske baad wala OTM becho. Cost ghat ti hai, risk fixed rehta hai.
///   • Breakout with a big ATR and no cheap premium → **straddle (ATM jodi)** —
///     dono taraf bada move ho to hi fayda.
///   • Sideways + IV high → **strangle sell (OTM jodi)** — premium likhne wale
///     ke liye, risk bada, is liye card par likha hai.
///   • Sideways + IV low → **wait**. Koi trade nahi.
///   • Overbought / no option data → **wait**.
///   • A **confirmed result** inside the user's event window (default 5 days) →
///     **wait**, whatever the chart says: a bought option loses to the IV crush
///     and a sold strangle carries gap risk.
///   • A premium too thin to fill → **wait** (the spread is bigger than the
///     edge).
AiStrategy resolveStrategy({
  required AiDirection direction,
  required AiPattern pattern,
  required AiSnapshot snap,
  required AiOptionContext options,
  AiFilters filters = AiFilters.defaults,
}) {
  if (!options.hasPair) return AiStrategy.none;

  // An event beats every other argument. A confirmed result inside the window
  // means: a bought option loses on the IV crush even when the direction is
  // right, and a sold strangle carries gap risk through the announcement. Both
  // answers are "wait" — and the card says why.
  final daysToResult = options.daysToResult;
  if (options.isEvent(filters.eventBlockDays)) {
    final when = daysToResult == 0
        ? 'aaj'
        : daysToResult == 1
            ? 'kal'
            : '$daysToResult din me';
    return AiStrategy(
      action: 'Wait',
      name: 'Koi trade nahi',
      strikeType: '—',
      pair: '—',
      why: 'Result $when hai — IV crush (kharidne wale ke liye) aur gap ka '
          'jokhim (bechne wale ke liye). Result ke baad dekho.',
      wait: true,
    );
  }

  // Expiry day itself: nothing new is opened — theta and pin risk are not worth
  // a "maybe".
  if (options.daysToExpiry <= 0) {
    return const AiStrategy(
      action: 'Wait',
      name: 'Koi trade nahi',
      strikeType: '—',
      pair: '—',
      why: 'Aaj expiry hai — nayi position ka sahi waqt nahi (theta aur pin '
          'risk). Agle expiry me dekho.',
      wait: true,
    );
  }

  // Days to expiry: the same idea is a good trade in one contract and a bad one
  // in the next. Buys need time (theta), sells need the clock running but not
  // too long (theta is fastest near expiry).
  final willSell = direction == AiDirection.sideways && options.ivExpensive;
  final dte = options.daysToExpiry;
  if (willSell) {
    if (dte > filters.sellMaxDte) {
      return AiStrategy(
        action: 'Wait',
        name: 'Koi trade nahi',
        strikeType: '—',
        pair: '—',
        why: 'Is expiry me $dte din bache hain — theta abhi dheema chalega. '
            'Premium likhne ke liye ${filters.sellMaxDte} din ya us se kam '
            'wala expiry chuno.',
        wait: true,
      );
    }
    if (dte < 3) {
      return AiStrategy(
        action: 'Wait',
        name: 'Koi trade nahi',
        strikeType: '—',
        pair: '—',
        why: 'Sirf $dte din bache hain — itne kam din me premium bhi kam milta '
            'hai aur gap ka jokhim poora rehta hai.',
        wait: true,
      );
    }
  } else if (dte < filters.buyMinDte) {
    return AiStrategy(
      action: 'Wait',
      name: 'Koi trade nahi',
      strikeType: '—',
      pair: '—',
      why: 'Is expiry me sirf $dte din bache hain — theta har din premium '
          'khaata hai, aur stock ke move ka waqt hi nahi milega '
          '(kam se kam ${filters.buyMinDte} din chahiye).',
      wait: true,
    );
  }

  // A premium this small means the strike barely trades: the bid-ask spread is
  // bigger than the edge.
  if (options.thin) {
    return AiStrategy(
      action: 'Wait',
      name: 'Koi trade nahi',
      strikeType: '—',
      pair: '—',
      why: 'Is strike par premium bahut patla hai — kharidne/bechne me spread '
          'hi nuksan karwa dega.',
      wait: true,
    );
  }

  final atm = options.atmStrike!;
  final atmText = _money(atm);
  final ceOtm = options.otmCeStrike;
  final peOtm = options.otmPeStrike;
  final expensive = options.ivExpensive;
  final lotText = options.lotSize > 0 ? ' · 1 lot = ${options.lotSize} qty' : '';

  String otmCe() => ceOtm == null ? _money(atm) : _money(ceOtm);
  String otmPe() => peOtm == null ? _money(atm) : _money(peOtm);

  switch (direction) {
    case AiDirection.bullish:
      // A breakout on a big ATR is the one case where buying both sides pays:
      // the move is expected to be larger than the premium implies.
      if (pattern == AiPattern.breakout && snap.atrPct >= 2.5) {
        return AiStrategy(
          action: 'Buy',
          name: 'Straddle (ATM jodi)',
          strikeType: 'ATM',
          pair: 'CE $atmText + PE $atmText',
          why: 'Breakout volume ke saath aur ATR ${snap.atrPct.toStringAsFixed(1)}% '
              '— move premium se bada hone par hi fayda.$lotText',
        );
      }
      if (expensive) {
        return AiStrategy(
          action: 'Buy',
          name: 'Bull Call Spread',
          strikeType: 'ATM + OTM',
          pair: 'CE $atmText kharido · CE ${otmCe()} becho',
          why: 'Premium mehengi (IV ${options.avgIv?.toStringAsFixed(0) ?? '—'}% '
              '— stock se zyada charge) — OTM bech kar cost kam ki.$lotText',
        );
      }
      return AiStrategy(
        action: 'Buy',
        name: 'Directional Buy',
        strikeType: 'ATM',
        pair: 'CE $atmText',
        why: 'Uptrend + RSI ${snap.rsi.toStringAsFixed(0)} · seedha CE '
            'kharidna sabse simple hai.$lotText',
      );

    case AiDirection.bearish:
      if (pattern == AiPattern.breakdown && snap.atrPct >= 2.5) {
        return AiStrategy(
          action: 'Buy',
          name: 'Straddle (ATM jodi)',
          strikeType: 'ATM',
          pair: 'CE $atmText + PE $atmText',
          why: 'Breakdown volume ke saath aur ATR '
              '${snap.atrPct.toStringAsFixed(1)}% — dono taraf tez move.$lotText',
        );
      }
      if (expensive) {
        return AiStrategy(
          action: 'Buy',
          name: 'Bear Put Spread',
          strikeType: 'ATM + OTM',
          pair: 'PE $atmText kharido · PE ${otmPe()} becho',
          why: 'Premium mehengi (IV ${options.avgIv?.toStringAsFixed(0) ?? '—'}% '
              '— stock se zyada charge) — OTM bech kar cost kam ki.$lotText',
        );
      }
      return AiStrategy(
        action: 'Buy',
        name: 'Directional Buy',
        strikeType: 'ATM',
        pair: 'PE $atmText',
        why: 'Downtrend + RSI ${snap.rsi.toStringAsFixed(0)} · seedha PE '
            'kharidna sabse simple hai.$lotText',
      );

    case AiDirection.sideways:
      if (expensive) {
        return AiStrategy(
          action: 'Sell',
          name: 'Strangle (OTM jodi)',
          strikeType: 'OTM',
          pair: 'CE ${otmCe()} + PE ${otmPe()} becho',
          why: 'Range + premium mehengi (IV '
              '${options.avgIv?.toStringAsFixed(0) ?? '—'}%) — premium likhne ka '
              'mauka. Risk bada: bada move ho to nuksan$lotText',
        );
      }
      return const AiStrategy(
        action: 'Wait',
        name: 'Koi trade nahi',
        strikeType: '—',
        pair: '—',
        why: 'Range me hai aur premium mehengi nahi — breakout ka wait karo.',
        wait: true,
      );
  }
}

/// `2650`, `2650.50` — strike/premium text without a currency symbol.
String _money(double value) =>
    value == value.roundToDouble() ? '${value.toInt()}' : value.toStringAsFixed(2);

/// The bullet reasons shown on the card — every one is a number the user can
/// check, never a verdict without a figure behind it.
List<String> buildRationale({
  required AiSnapshot snap,
  required AiPattern pattern,
  required AiDirection direction,
  required double return3m,
  required int upMonths,
  required AiFilters filters,
}) {
  final out = <String>[
    'RSI ${snap.rsi.toStringAsFixed(0)}',
    '${return3m >= 0 ? '+' : ''}${return3m.toStringAsFixed(1)}% 3 mahine me',
  ];

  if (snap.volumeRatio >= filters.volumeSpike) {
    out.add('volume ${snap.volumeRatio.toStringAsFixed(1)}x');
  }
  if (snap.fromHighPct <= filters.nearHighPct) {
    out.add('52w high se ${snap.fromHighPct.toStringAsFixed(1)}% neeche');
  }
  if (upMonths > 0) out.add('$upMonths up month');
  if (pattern != AiPattern.range) out.add(pattern.label.toLowerCase());
  if (direction == AiDirection.sideways && snap.atrPct > 0) {
    out.add('ATR ${snap.atrPct.toStringAsFixed(1)}%');
  }
  return out;
}
