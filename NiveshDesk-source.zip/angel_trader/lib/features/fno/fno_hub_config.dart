// ---------------------------------------------------------------------------
// fno_hub_config.dart — "kaun sa tool kis section me" ka ek hi sach.
//
// 1.5.93: hub ka design ab category rows hai (Study / Index / Options /
// Calendar), har row ek line ka. User long-press karke row ko upar-neeche
// kar sakta hai — wahi order settings me `fno_hub_order` key par save hota hai.
//
// Order ka format: {"study": ["study", "adv"], "index": ["bankex"], ...}
// Naya tool add karo to purane saved order me wo automatically apne section ke
// aakhir me aa jaata hai (mergeHubOrder) — user ka order kharab nahi hota.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';

/// Hub ke chaar section — order yahi rehta hai, andar ke tools user set karta hai.
enum HubSection {
  study('study', 'SCREENER & STUDY', Color(0xFF0B6B4F)),
  strategies('index', 'INDEX STRATEGIES', Color(0xFF0E7490)),
  options('options', 'OPTIONS DATA', Color(0xFF6D28D9)),
  calendar('calendar', 'CALENDAR & AI', Color(0xFFB9822A));

  const HubSection(this.id, this.label, this.color);

  final String id;
  final String label;
  final Color color;
}

/// Ek tool ka poora description — icon, ek line, badge, section.
class HubTool {
  const HubTool({
    required this.id,
    required this.title,
    required this.blurb,
    required this.icon,
    required this.section,
    this.badge,
  });

  final String id;
  final String title;

  /// Ek hi line — compact row (1.5.93 decision: "sirf naam + 1 line").
  final String blurb;
  final IconData icon;
  final HubSection section;

  /// 'LIVE' / 'NEW' / 'NAYA' — null = koi badge nahi.
  final String? badge;
}

/// Hub ke saare tools. Naya tool yahin add karo — screen khud dikha degi.
const List<HubTool> kHubTools = [
  HubTool(
    id: 'study',
    title: '3-Month Study',
    blurb: 'Trend, ATR, 3M high/low se doori, ATM IV aur edge',
    icon: Icons.query_stats_rounded,
    section: HubSection.study,
    badge: 'LIVE',
  ),
  HubTool(
    id: 'adv',
    title: '3-Month Study · Advance Filter',
    blurb: 'Wahi study, sudhare hue niyam + score (Best Buy / Watch)',
    icon: Icons.filter_alt_rounded,
    section: HubSection.study,
    badge: 'NAYA',
  ),
  HubTool(
    id: 'bankex',
    title: 'Bankex–Bank Nifty Strategies',
    blurb: 'Regime detection + 6 defined-risk spread strategies',
    icon: Icons.account_balance_rounded,
    section: HubSection.strategies,
    badge: 'NEW',
  ),
  HubTool(
    id: 'stock_oi',
    title: 'Stock OI Build–Unwind',
    blurb: 'Aaj kis strike par badi position bani ya windup hui',
    icon: Icons.bar_chart_rounded,
    section: HubSection.options,
    badge: 'NAYA',
  ),
  HubTool(
    id: 'extremes',
    title: '52W · ATH · Dividend',
    blurb: '52W high/low se doori, all-time high, aane wale dividend',
    icon: Icons.show_chart_rounded,
    section: HubSection.options,
    badge: 'NAYA',
  ),
  HubTool(
    id: 'results',
    title: 'Results Calendar',
    blurb: 'Kis stock ke results kab — F&O universe',
    icon: Icons.event_rounded,
    section: HubSection.calendar,
    badge: 'LIVE',
  ),
  HubTool(
    id: 'ai',
    title: 'AI Suggestion',
    blurb: 'Rule-based idea + entry/exit levels',
    icon: Icons.auto_awesome_rounded,
    section: HubSection.calendar,
    badge: 'LIVE',
  ),
];

/// Tool id se tool dhoondo (unknown id → null).
HubTool? hubToolById(String id) {
  for (final tool in kHubTools) {
    if (tool.id == id) return tool;
  }
  return null;
}

/// Default order: section-wise, config ki tarteeb me.
Map<String, List<String>> defaultHubOrder() {
  final map = <String, List<String>>{
    for (final section in HubSection.values) section.id: <String>[],
  };
  for (final tool in kHubTools) {
    map[tool.section.id]!.add(tool.id);
  }
  return map;
}

/// Saved JSON ko default ke saath merge karta hai.
///
/// - saved me jo ids hain aur config me bhi hain → usi tarteeb me
/// - naye tools (saved me nahi) → apne section ke aakhir me
/// - hataye gaye tools (config me nahi) → chhod do
/// - kharab/adhoora JSON → default order (crash nahi)
Map<String, List<String>> mergeHubOrder(Object? saved) {
  final defaults = defaultHubOrder();
  if (saved is! Map) return defaults;

  final known = {for (final tool in kHubTools) tool.id: tool};
  final merged = <String, List<String>>{
    for (final section in HubSection.values) section.id: <String>[],
  };

  // 1) saved tarteeb, par sirf wahi tools jo abhi bhi usi section me hain.
  for (final section in HubSection.values) {
    final raw = saved[section.id];
    if (raw is! List) continue;
    for (final entry in raw) {
      final id = '$entry';
      final tool = known[id];
      if (tool == null) continue;
      if (tool.section != section) continue; // section badla → naya section
      if (merged[section.id]!.contains(id)) continue; // duplicate
      merged[section.id]!.add(id);
    }
  }

  // 2) jo reh gaye (naye tools) → apne section ke aakhir me.
  for (final tool in kHubTools) {
    final bucket = merged[tool.section.id]!;
    if (!bucket.contains(tool.id)) bucket.add(tool.id);
  }
  return merged;
}

/// Order ko JSON-friendly map me badlo (sirf ids).
Map<String, List<String>> hubOrderToJson(Map<String, List<String>> order) => {
  for (final entry in order.entries)
    if (entry.value.isNotEmpty) entry.key: List<String>.from(entry.value),
};

/// Ek id ko section ke andar naye index par le jao (drag-drop ka core).
///
/// `toIndex` wahi semantics rakhta hai jo ReorderableListView ka hota hai:
/// item ko hatane ke baad wali position. Index bounds me clamp hota hai,
/// unknown id par list waisi hi return hoti hai.
List<String> moveInSection(List<String> ids, String movingId, int toIndex) {
  final from = ids.indexOf(movingId);
  if (from < 0) return List<String>.from(ids);
  final next = List<String>.from(ids)..removeAt(from);
  final target = toIndex.clamp(0, next.length);
  next.insert(target, movingId);
  return next;
}
