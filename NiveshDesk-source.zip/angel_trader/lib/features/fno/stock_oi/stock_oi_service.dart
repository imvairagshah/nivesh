// ---------------------------------------------------------------------------
// stock_oi_service.dart — 1.5.86 official NSE F&O bhavcopy → StockOiBook.
//
// Sourcing exchange-official hi hai (`nsearchives.nseindia.com` ka UDiFF
// `BhavCopy_NSE_FO_…csv.zip`) — wahi file jo F&O Scanner use karta hai. File
// na mile (holiday/weekend/abhi publish nahi hui) to ek-ek din peeche walk
// karta hai, isliye screen kabhi "khaali din" par nahi atakti.
//
// Cache: parsed book memory me (date-wise) — symbol/expiry badalne par dobara
// download nahi hota. Force refresh se dobara.
// ---------------------------------------------------------------------------

import 'dart:convert';

import 'package:archive/archive.dart';

import '../../../core/utils/markets.dart';
import '../../../services/magic_formula_data_source.dart';
import 'stock_oi_engine.dart';

typedef OiBytesGetter = Future<List<int>> Function(
  Uri uri, {
  String? refererPath,
});

class StockOiFetchException implements Exception {
  const StockOiFetchException(this.message);
  final String message;
  @override
  String toString() => message;
}

class StockOiService {
  StockOiService({OiBytesGetter? getBytes, DateTime Function()? clock})
      : _getBytes = getBytes ?? NseMagicFormulaHttp().getBytes,
        _clock = clock ?? MarketCalendar.nowIst;

  final OiBytesGetter _getBytes;
  final DateTime Function() _clock;

  static const String _host = 'nsearchives.nseindia.com';

  /// date-key → parsed book (memory cache).
  final Map<String, StockOiBook> _cache = {};

  static Uri foBhavcopyUrl(DateTime date) => Uri.https(
        _host,
        '/content/fo/BhavCopy_NSE_FO_0_0_0_'
        '${date.year}${date.month.toString().padLeft(2, '0')}'
        '${date.day.toString().padLeft(2, '0')}_F_0000.csv.zip',
      );

  /// Latest available book — aaj se peeche walk (max [maxWalkBack] din).
  /// `onProgress` se UI ko status milta hai.
  Future<({StockOiBook book, DateTime tradeDate})> load({
    DateTime? onOrBefore,
    int maxWalkBack = 10,
    bool force = false,
    void Function(String stage)? onProgress,
  }) async {
    final start = onOrBefore ?? _clock();
    Object? lastError;
    for (var offset = 0; offset < maxWalkBack; offset++) {
      final date = DateTime(start.year, start.month, start.day)
          .subtract(Duration(days: offset));
      final key = _key(date);

      final cached = _cache[key];
      if (cached != null && !force) {
        return (book: cached, tradeDate: date);
      }

      onProgress?.call(
          'NSE F&O bhavcopy — ${date.day.toString().padLeft(2, '0')}/'
          '${date.month.toString().padLeft(2, '0')}/${date.year}…');
      try {
        final csv = await _downloadCsv(foBhavcopyUrl(date));
        final book = parseStockOptionOi(csv, date);
        if (book.rowCount == 0) {
          // File mili par stock options nahi — agla din try karo.
          lastError = 'stock-option rows nahi mile';
          continue;
        }
        _cache[key] = book;
        return (book: book, tradeDate: date);
      } catch (e) {
        lastError = e;
      }
    }
    throw StockOiFetchException(
      'NSE F&O bhavcopy nahi mili ($maxWalkBack din tak) — '
      '${lastError ?? 'network check karo'}.',
    );
  }

  Future<String> _downloadCsv(Uri zipUrl) async {
    final bytes = await _getBytes(zipUrl, refererPath: '/all-reports');
    final archive = ZipDecoder().decodeBytes(bytes);
    for (final file in archive) {
      if (file.isFile && file.name.toLowerCase().endsWith('.csv')) {
        return utf8.decode(file.content as List<int>);
      }
    }
    throw StockOiFetchException('ZIP me CSV nahi: $zipUrl');
  }

  String _key(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-'
      '${d.day.toString().padLeft(2, '0')}';

  void clearCache() => _cache.clear();
}
