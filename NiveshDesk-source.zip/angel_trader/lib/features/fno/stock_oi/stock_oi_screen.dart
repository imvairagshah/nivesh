// ---------------------------------------------------------------------------
// stock_oi_screen.dart — 1.5.86 "F&O Stock OI Build–Unwind".
//
// Ek symbol + expiry chuno → dikhata hai:
//   • top build-ups  (nayi long/short positions)
//   • top unwinds    (position windup / covering)
//   • poori strike-wise chain (CE | PE: OI, ΔOI, Δ%, price%) signal ke saath
//
// Data official NSE UDiFF FO bhavcopy se (EOD) — koi guess nahi. Rules:
// price × OI 2×2 matrix (engine me defined), filters Balanced/Strict/All,
// sort by ΔOI qty ya ΔOI %.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../core/layout/desktop_layout.dart';
import '../../../core/utils/share_helper.dart';
import '../../../core/widgets/ui.dart';
import 'stock_oi_engine.dart';
import 'stock_oi_service.dart';

class StockOiScreen extends StatefulWidget {
  const StockOiScreen({super.key});

  @override
  State<StockOiScreen> createState() => _StockOiScreenState();
}

class _StockOiScreenState extends State<StockOiScreen> {
  final _service = StockOiService();

  StockOiBook? _book;
  DateTime? _tradeDate;
  String? _error;
  bool _loading = true;

  String? _symbol;
  DateTime? _expiry;
  OiFilter _filter = OiFilter.balanced;
  OiSort _sort = OiSort.byQty;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load({bool force = false}) async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final res = await _service.load(force: force);
      if (!mounted) return;
      final symbols = res.book.symbols;
      setState(() {
        _book = res.book;
        _tradeDate = res.tradeDate;
        _loading = false;
        _symbol ??= symbols.isEmpty ? null : symbols.first;
      });
      _ensureExpiry();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = '$e';
      });
    }
  }

  void _ensureExpiry() {
    final snap = _snapshot;
    if (snap == null) return;
    final expiries = snap.expiries;
    if (expiries.isEmpty) return;
    final current = _expiry;
    final valid = current != null && expiries.any((e) => _sameDay(e, current));
    if (!valid) {
      setState(() => _expiry = expiries.first);
    }
  }

  StockOiSnapshot? get _snapshot =>
      _symbol == null ? null : _book?.bySymbol[_symbol];

  static bool _sameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final wide = DesktopLayout.isWide(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('📊 Stock OI Build–Unwind', style: TextStyle(fontSize: 15)),
        actions: [
          IconButton(
            tooltip: 'F&O bhavcopy refresh (dobara download)',
            icon: const Icon(Icons.refresh_rounded),
            onPressed: _loading ? null : () => _load(force: true),
          ),
          IconButton(
            tooltip: 'Report share',
            icon: const Icon(Icons.share_rounded),
            onPressed: _snapshot == null ? null : () => ShareHelper.shareText(_asText()),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: CenteredWidth(
        max: wide ? 1100 : double.infinity,
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
                ? _errorBody(scheme)
                : _body(scheme),
      ),
    );
  }

  Widget _errorBody(ColorScheme scheme) => Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('❌ F&O bhavcopy nahi mili',
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      color: scheme.error)),
              const SizedBox(height: 8),
              Text(_error!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 11.5, height: 1.5)),
              const SizedBox(height: 14),
              FilledButton.tonalIcon(
                onPressed: () => _load(force: true),
                icon: const Icon(Icons.refresh_rounded, size: 18),
                label: const Text('Dobara try karo'),
              ),
            ],
          ),
        ),
      );

  Widget _body(ColorScheme scheme) {
    final snap = _snapshot;
    final expiry = _expiry;
    if (snap == null || expiry == null) {
      return const Center(
        child: Text('Koi stock option data nahi mila.',
            style: TextStyle(fontSize: 12)),
      );
    }
    final summary = snap.summary(expiry, _filter);
    final builds = snap.topBuilds(
        expiry: expiry, filter: _filter, sort: _sort);
    final unwinds = snap.topUnwinds(
        expiry: expiry, filter: _filter, sort: _sort);

    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 26),
      children: [
        _sourceBanner(scheme),
        const SizedBox(height: 10),
        _legendCard(scheme),
        const SizedBox(height: 10),
        Card(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(child: _symbolPicker(scheme)),
                    const SizedBox(width: 8),
                    Expanded(child: _expiryPicker(scheme)),
                  ],
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 6,
                  runSpacing: 4,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    const Text('Filter',
                        style: TextStyle(
                            fontSize: 10.5, fontWeight: FontWeight.w700)),
                    for (final f in OiFilter.presets)
                      ChoiceChip(
                        label: Text(
                          f == OiFilter.all
                              ? 'All'
                              : '${f.label} (OI≥${_k(f.minOi)} · ≥${f.minOiChangePct.round()}%)',
                          style: const TextStyle(fontSize: 10),
                        ),
                        selected: _filter == f,
                        onSelected: (_) => setState(() => _filter = f),
                      ),
                  ],
                ),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 6,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    const Text('Sort',
                        style: TextStyle(
                            fontSize: 10.5, fontWeight: FontWeight.w700)),
                    for (final s in OiSort.values)
                      ChoiceChip(
                        label: Text(s.label,
                            style: const TextStyle(fontSize: 10)),
                        selected: _sort == s,
                        onSelected: (_) => setState(() => _sort = s),
                      ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    _stat(scheme, '🟢 Builds', '${summary.builds}',
                        scheme.primary),
                    _stat(scheme, '🟠 Unwinds', '${summary.unwinds}',
                        scheme.error),
                    _stat(scheme, 'Net ΔOI', _signed(summary.netOiChange),
                        summary.netOiChange >= 0
                            ? scheme.primary
                            : scheme.error),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        _movesCard(
          scheme,
          title: '🔨 Top build-ups',
          subtitle: 'Nayi positions bani (long ya short)',
          legs: builds,
          empty: 'Filter ke andar koi build-up nahi mila.',
        ),
        const SizedBox(height: 10),
        _movesCard(
          scheme,
          title: '🌀 Top unwinds',
          subtitle: 'Position windup / covering (OI ghata)',
          legs: unwinds,
          empty: 'Filter ke andar koi unwind nahi mila.',
        ),
        const SizedBox(height: 10),
        _chainCard(scheme, snap, expiry),
      ],
    );
  }

  // ------------------------------------------------------------------ pieces

  Widget _sourceBanner(ColorScheme scheme) => Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: scheme.primaryContainer,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(
          '🏛️ Official NSE F&O bhavcopy · trade date ${_d(_tradeDate)} · '
          'EOD data (market close ke baad). Live intraday OI nahi — broker '
          'quotes me OI field nahi aata.',
          style: const TextStyle(fontSize: 10.5, height: 1.45),
        ),
      );

  Widget _legendCard(ColorScheme scheme) => InfoSection(
        emoji: '📐',
        title: 'Rules — price × OI',
        tooltip: 'Standard OI interpretation: price direction + OI change '
            'se pata chalta hai nayi position bani ya purani band hui.',
        children: [
          for (final s in [
            OiSignal.longBuildup,
            OiSignal.shortBuildup,
            OiSignal.shortCovering,
            OiSignal.longUnwinding,
          ])
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 1.5),
              child: Text('${s.emoji} ${s.label} — ${s.meaning}',
                  style: const TextStyle(fontSize: 10.5, height: 1.4)),
            ),
        ],
      );

  Widget _symbolPicker(ColorScheme scheme) {
    final symbols = _book?.symbols ?? const <String>[];
    return DropdownButtonFormField<String>(
      key: const ValueKey('oi-symbol'),
      initialValue: _symbol,
      isExpanded: true,
      decoration: const InputDecoration(
        labelText: 'Stock',
        isDense: true,
        border: OutlineInputBorder(),
      ),
      items: [
        for (final s in symbols)
          DropdownMenuItem(
              value: s,
              child: Text(s, style: const TextStyle(fontSize: 12))),
      ],
      onChanged: (v) {
        if (v == null) return;
        setState(() {
          _symbol = v;
          _expiry = null;
        });
        _ensureExpiry();
      },
    );
  }

  Widget _expiryPicker(ColorScheme scheme) {
    final expiries = _snapshot?.expiries ?? const <DateTime>[];
    return DropdownButtonFormField<DateTime>(
      key: const ValueKey('oi-expiry'),
      initialValue: _expiry,
      isExpanded: true,
      decoration: const InputDecoration(
        labelText: 'Expiry',
        isDense: true,
        border: OutlineInputBorder(),
      ),
      items: [
        for (final e in expiries)
          DropdownMenuItem(
              value: e,
              child: Text(DateFormat('dd MMM yyyy').format(e),
                  style: const TextStyle(fontSize: 12))),
      ],
      onChanged: (v) => setState(() => _expiry = v),
    );
  }

  Widget _stat(ColorScheme scheme, String label, String value, Color color) =>
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label,
                style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant)),
            Text(value,
                style: TextStyle(
                    fontSize: 14, fontWeight: FontWeight.w900, color: color)),
          ],
        ),
      );

  Widget _movesCard(
    ColorScheme scheme, {
    required String title,
    required String subtitle,
    required List<StockOiLeg> legs,
    required String empty,
  }) =>
      Card(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 11),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title,
                  style: const TextStyle(
                      fontSize: 12, fontWeight: FontWeight.w800)),
              Text(subtitle,
                  style: TextStyle(
                      fontSize: 9.5, color: scheme.onSurfaceVariant)),
              const SizedBox(height: 6),
              if (legs.isEmpty)
                Text(empty,
                    style: TextStyle(
                        fontSize: 10.5, color: scheme.onSurfaceVariant))
              else
                for (final l in legs)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 2.5),
                    child: Row(
                      children: [
                        SizedBox(
                          width: 58,
                          child: Text(l.strike.toStringAsFixed(0),
                              style: const TextStyle(
                                  fontSize: 11, fontWeight: FontWeight.w800)),
                        ),
                        SizedBox(
                          width: 34,
                          child: Text(l.optionType,
                              style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w800,
                                  color: l.isCall
                                      ? scheme.primary
                                      : scheme.error)),
                        ),
                        Expanded(
                          child: Text(
                            '${l.signal.emoji} ${l.signal.label}',
                            style: const TextStyle(fontSize: 10.5),
                          ),
                        ),
                        SizedBox(
                          width: 74,
                          child: Text(_signed(l.oiChange),
                              textAlign: TextAlign.right,
                              style: TextStyle(
                                  fontSize: 10.5,
                                  fontWeight: FontWeight.w800,
                                  color: l.oiChange >= 0
                                      ? scheme.primary
                                      : scheme.error)),
                        ),
                        SizedBox(
                          width: 56,
                          child: Text('${_signed(l.oiChangePct)}%',
                              textAlign: TextAlign.right,
                              style: TextStyle(
                                  fontSize: 10,
                                  color: scheme.onSurfaceVariant)),
                        ),
                      ],
                    ),
                  ),
            ],
          ),
        ),
      );

  Widget _chainCard(ColorScheme scheme, StockOiSnapshot snap, DateTime expiry) {
    final strikes = snap.strikesFor(expiry);
    final legs = snap.forExpiry(expiry);
    StockOiLeg? legFor(double strike, String type) {
      for (final l in legs) {
        if (l.strike == strike && l.optionType == type) return l;
      }
      return null;
    }

    const wStrike = 64.0;
    const wChange = 96.0;
    const wPct = 62.0;
    const total = wStrike + wChange + wPct + wChange + wPct;

    Widget hdr(String t, double w, {bool right = false}) => SizedBox(
          width: w,
          child: Text(t,
              textAlign: right ? TextAlign.right : TextAlign.left,
              style: TextStyle(
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                  color: scheme.onSurfaceVariant)),
        );

    Widget changeCell(StockOiLeg? l) {
      if (l == null) {
        return SizedBox(
            width: wChange,
            child: Text('—',
                textAlign: TextAlign.right,
                style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant)));
      }
      return SizedBox(
        width: wChange,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Text(_k(l.oiChange),
                style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    color: l.oiChange >= 0 ? scheme.primary : scheme.error)),
            Padding(
              padding: const EdgeInsets.only(left: 3),
              child: Text(l.signal.emoji, style: const TextStyle(fontSize: 9)),
            ),
          ],
        ),
      );
    }

    Widget pctCell(StockOiLeg? l) => SizedBox(
          width: wPct,
          child: Text(l == null ? '—' : '${_signed(l.oiChangePct)}%',
              textAlign: TextAlign.right,
              style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant)),
        );

    Widget row(double strike) {
      final ce = legFor(strike, 'CE');
      final pe = legFor(strike, 'PE');
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 2.5),
        child: Row(
          children: [
            SizedBox(
              width: wStrike,
              child: Text(strike.toStringAsFixed(0),
                  style: const TextStyle(
                      fontSize: 10.5, fontWeight: FontWeight.w700)),
            ),
            changeCell(ce),
            pctCell(ce),
            changeCell(pe),
            pctCell(pe),
          ],
        ),
      );
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('📋 Strike-wise OI (${DateFormat('dd MMM').format(expiry)})',
                style: const TextStyle(
                    fontSize: 12, fontWeight: FontWeight.w800)),
            Text('Poora chain — ΔOI qty + ΔOI %. Emoji = signal.',
                style: TextStyle(
                    fontSize: 9.5, color: scheme.onSurfaceVariant)),
            const SizedBox(height: 8),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: SizedBox(
                width: total,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        hdr('Strike', wStrike),
                        hdr('CE ΔOI', wChange, right: true),
                        hdr('CE %', wPct, right: true),
                        hdr('PE ΔOI', wChange, right: true),
                        hdr('PE %', wPct, right: true),
                      ],
                    ),
                    const Divider(height: 10),
                    for (final s in strikes) row(s),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'CE/PE alag rows hote hain (bhavcopy me). OI qty me hai (lots '
              'nahi). ΔOI % = ΔOI ÷ kal ka OI.',
              style: TextStyle(
                  fontSize: 9, height: 1.4, color: scheme.onSurfaceVariant),
            ),
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------------ helpers

  static String _d(DateTime? d) =>
      d == null ? '—' : DateFormat('dd MMM yyyy').format(d);

  static String _signed(double v) =>
      '${v >= 0 ? '+' : '−'}${_k(v.abs())}';

  /// 120000 → 1.2L, 5000 → 5,000 (Indian short form).
  static String _k(double v) {
    final n = v.round();
    if (n.abs() >= 10000000) return '${(n / 10000000).toStringAsFixed(2)}Cr';
    if (n.abs() >= 100000) return '${(n / 100000).toStringAsFixed(2)}L';
    return NumberFormat.decimalPattern('en_IN').format(n);
  }

  String _asText() {
    final snap = _snapshot;
    final expiry = _expiry;
    if (snap == null || expiry == null) return '';
    final b = StringBuffer()
      ..writeln('=== ${snap.symbol} · Stock OI Build–Unwind ===')
      ..writeln('Trade date: ${_d(_tradeDate)} · Expiry: ${_d(expiry)}')
      ..writeln('Filter: ${_filter.label} · Sort: ${_sort.label}');
    void section(String title, List<StockOiLeg> legs) {
      b.writeln('\n$title');
      for (final l in legs) {
        b.writeln('• ${l.strike.toStringAsFixed(0)} ${l.optionType} — '
            '${l.signal.label} · ΔOI ${_signed(l.oiChange)} '
            '(${_signed(l.oiChangePct)}%) · OI ${_k(l.oi)}');
      }
    }

    section('BUILD-UPS:', snap.topBuilds(
        expiry: expiry, filter: _filter, sort: _sort));
    section('UNWINDS:', snap.topUnwinds(
        expiry: expiry, filter: _filter, sort: _sort));
    b.writeln('\nSource: NSE official F&O bhavcopy (EOD).');
    return b.toString();
  }
}
