// ---------------------------------------------------------------------------
// stock_oi_engine.dart — 1.5.86 "F&O Stock OI Build–Unwind".
//
// Sawal: din bhar me kis STRIKE par badi position BANI (OI build) ya WINDDOWN
// hui (OI unwind) — aur kis type ki (long/short)?
//
// Data: NSE ki official UDiFF F&O bhavcopy (STO = stock options rows). Har row
// me strike, CE/PE, `OpnIntrst` (OI), `ChngInOpnIntrst` (ΔOI) aur close/prev
// close hote hain → price × OI ka 2×2 matrix = signal, guess nahi.
//
// BASIC RULES (user-confirmed 1.5.86):
//   price ↑ + OI ↑ → Long build-up     (nayi buy positions)
//   price ↓ + OI ↑ → Short build-up    (nayi sell positions)
//   price ↑ + OI ↓ → Short covering    (short windup)
//   price ↓ + OI ↓ → Long unwinding    (long windup)
//   OI change ~0   → Flat
//
// Filters (default "balanced", user-confirmed): OI ≥ 5000 qty AND |ΔOI %| ≥ 10.
// Sab kuch pure functions — CSV text in, result out (unit-testable).
// ---------------------------------------------------------------------------

import 'dart:math' as math;

/// Ek strike-side ka OI snapshot (CE ya PE).
class StockOiLeg {
  const StockOiLeg({
    required this.symbol,
    required this.expiry,
    required this.strike,
    required this.optionType,
    required this.oi,
    required this.oiChange,
    required this.close,
    required this.previousClose,
    this.lotSize = 0,
  });

  final String symbol;
  final DateTime expiry;
  final double strike;

  /// `CE` | `PE`.
  final String optionType;

  /// `OpnIntrst` — aaj ka open interest (qty, not lots).
  final double oi;

  /// `ChngInOpnIntrst` — kal se change (qty, signed).
  final double oiChange;

  final double close;
  final double previousClose;
  final int lotSize;

  bool get isCall => optionType == 'CE';

  /// Kal ka OI (change se derive — bhavcopy me seedha column nahi hota).
  double get previousOi => oi - oiChange;

  /// ΔOI % — kal ke OI par. Kal OI 0/unknown ho to 0 (divide-by-zero nahi).
  double get oiChangePct => previousOi <= 0 ? 0 : oiChange / previousOi * 100;

  /// Price change % (close vs prev close).
  double get priceChangePct =>
      previousClose <= 0 ? 0 : (close - previousClose) / previousClose * 100;

  OiSignal get signal => classifySignal(
        priceChangePct: priceChangePct,
        oiChangePct: oiChangePct,
      );
}

/// Price × OI matrix ka natija.
enum OiSignal {
  longBuildup('Long build-up', '🟢', 'Price ↑ + OI ↑ — nayi buy positions'),
  shortBuildup('Short build-up', '🔴', 'Price ↓ + OI ↑ — nayi sell positions'),
  shortCovering('Short covering', '🟡', 'Price ↑ + OI ↓ — short windup'),
  longUnwinding('Long unwinding', '🟠', 'Price ↓ + OI ↓ — long windup'),
  flat('Flat', '⚪', 'OI me meaningful change nahi');

  const OiSignal(this.label, this.emoji, this.meaning);
  final String label;
  final String emoji;
  final String meaning;

  bool get isBuild => this == longBuildup || this == shortBuildup;
  bool get isUnwind => this == shortCovering || this == longUnwinding;
}

/// Price × OI rules. `flatBandPct` = itna % se kam move "no move" maana jaata
/// hai (warna 0.01% price aur 0.01% OI par bhi signal aa jayega).
OiSignal classifySignal({
  required double priceChangePct,
  required double oiChangePct,
  double priceBandPct = 0.05,
  double oiBandPct = 1.0,
}) {
  if (oiChangePct.abs() < oiBandPct) return OiSignal.flat;
  final up = priceChangePct > priceBandPct;
  final down = priceChangePct < -priceBandPct;
  if (up) return oiChangePct > 0 ? OiSignal.longBuildup : OiSignal.shortCovering;
  if (down) return oiChangePct > 0 ? OiSignal.shortBuildup : OiSignal.longUnwinding;
  // Price flat par OI badha/ghata — direction ka pata nahi, par build/unwind
  // dikhana galat hoga; flat hi honest hai.
  return OiSignal.flat;
}

/// Filter presets (user: default balanced).
class OiFilter {
  const OiFilter({
    required this.label,
    required this.minOi,
    required this.minOiChangePct,
  });

  final String label;
  final double minOi;
  final double minOiChangePct;

  static const balanced =
      OiFilter(label: 'Balanced', minOi: 5000, minOiChangePct: 10);
  static const strict =
      OiFilter(label: 'Strict', minOi: 10000, minOiChangePct: 20);
  static const all = OiFilter(label: 'All', minOi: 0, minOiChangePct: 0);

  static const presets = [balanced, strict, all];

  bool passes(StockOiLeg leg) =>
      leg.oi >= minOi && leg.oiChangePct.abs() >= minOiChangePct;
}

/// Sort options (user: dono).
enum OiSort {
  byQty('ΔOI qty', 'absolute change'),
  byPct('ΔOI %', 'relative change');

  const OiSort(this.label, this.hint);
  final String label;
  final String hint;

  double valueOf(StockOiLeg leg) =>
      this == OiSort.byQty ? leg.oiChange.abs() : leg.oiChangePct.abs();
}

/// Ek symbol ka expiry-wise poora set.
class StockOiSnapshot {
  const StockOiSnapshot({
    required this.symbol,
    required this.tradeDate,
    required this.legs,
  });

  final String symbol;
  final DateTime tradeDate;
  final List<StockOiLeg> legs;

  /// Kitni expiries hain (dropdown ke liye, ascending).
  List<DateTime> get expiries {
    final set = <DateTime>{for (final l in legs) l.expiry};
    final list = set.toList()..sort();
    return list;
  }

  List<StockOiLeg> forExpiry(DateTime expiry) =>
      legs.where((l) => _sameDay(l.expiry, expiry)).toList();

  /// Strikes ascending (chain table ke liye).
  List<double> strikesFor(DateTime expiry) {
    final set = <double>{for (final l in forExpiry(expiry)) l.strike};
    final list = set.toList()..sort();
    return list;
  }

  /// Top build-ups (qty ya % — user's sort), filter ke saath.
  List<StockOiLeg> topBuilds({
    required DateTime expiry,
    required OiFilter filter,
    required OiSort sort,
    int limit = 10,
  }) =>
      _ranked(expiry, filter, sort)
          .where((l) => l.signal.isBuild && l.oiChange > 0)
          .take(limit)
          .toList();

  /// Top unwinds (OI ghata) — same sort.
  List<StockOiLeg> topUnwinds({
    required DateTime expiry,
    required OiFilter filter,
    required OiSort sort,
    int limit = 10,
  }) =>
      _ranked(expiry, filter, sort)
          .where((l) => l.signal.isUnwind || l.oiChange < 0)
          .take(limit)
          .toList();

  List<StockOiLeg> _ranked(DateTime expiry, OiFilter filter, OiSort sort) {
    final list = forExpiry(expiry).where(filter.passes).toList()
      ..sort((a, b) => sort.valueOf(b).compareTo(sort.valueOf(a)));
    return list;
  }

  /// Summary — kitne strikes par build vs unwind (filter ke andar).
  ({int builds, int unwinds, double netOiChange}) summary(
      DateTime expiry, OiFilter filter) {
    var builds = 0;
    var unwinds = 0;
    var net = 0.0;
    for (final l in forExpiry(expiry)) {
      if (!filter.passes(l)) continue;
      net += l.oiChange;
      if (l.oiChange > 0) {
        builds++;
      } else if (l.oiChange < 0) {
        unwinds++;
      }
    }
    return (builds: builds, unwinds: unwinds, netOiChange: net);
  }

  static bool _sameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;
}

/// Result — poore bhavcopy se (symbol → snapshot), plus parsing stats.
class StockOiBook {
  const StockOiBook({required this.bySymbol, required this.rowCount});

  final Map<String, StockOiSnapshot> bySymbol;
  final int rowCount;

  List<String> get symbols => bySymbol.keys.toList()..sort();
}

// ---------------------------------------------------------------------------
// Pure parser — UDiFF F&O bhavcopy CSV → stock-option OI rows.
// ---------------------------------------------------------------------------

const Set<String> _indexSymbols = {
  'NIFTY',
  'BANKNIFTY',
  'FINNIFTY',
  'MIDCPNIFTY',
  'NIFTYNXT50',
  'BANKEX',
  'SENSEX',
  'SENSEX50',
};

String _normHeader(String s) =>
    s.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

int _col(List<String> header, List<String> names) {
  final norm = header.map(_normHeader).toList();
  for (final n in names) {
    final idx = norm.indexOf(_normHeader(n));
    if (idx >= 0) return idx;
  }
  return -1;
}

/// `2026-11-26` / `26-Nov-2026` / `26NOV2026` → DateTime.
DateTime? parseOiDate(String raw) {
  final text = raw.trim();
  if (text.isEmpty) return null;
  final iso = DateTime.tryParse(text);
  if (iso != null) return DateTime(iso.year, iso.month, iso.day);
  final cleaned = text.toUpperCase().replaceAll(RegExp(r'[-/\s]'), '');
  if (cleaned.length >= 9) {
    final day = int.tryParse(cleaned.substring(0, 2));
    final mon = _months.indexOf(cleaned.substring(2, 5));
    final year = int.tryParse(cleaned.substring(5, 9));
    if (day != null && mon >= 0 && year != null) {
      return DateTime(year, mon + 1, day);
    }
  }
  return null;
}

const List<String> _months = [
  'JAN',
  'FEB',
  'MAR',
  'APR',
  'MAY',
  'JUN',
  'JUL',
  'AUG',
  'SEP',
  'OCT',
  'NOV',
  'DEC',
];

/// CSVs may quote fields; keep it simple (bhavcopy me commas nahi hote).
List<String> splitOiCsv(String line) => line.split(',');

/// Saari stock-option rows ek book me — symbol ke hisaab se group.
StockOiBook parseStockOptionOi(String csv, DateTime tradeDate) {
  final lines = csv.split(RegExp(r'[\r\n]+'));
  if (lines.isEmpty) return const StockOiBook(bySymbol: {}, rowCount: 0);
  final header = splitOiCsv(lines.first);
  final iSymbol = _col(header, ['TckrSymb', 'Symbol']);
  final iExpiry = _col(header, ['XpryDt', 'ExpiryDt', 'ExpiryDate']);
  final iType = _col(header, ['FinInstrmTp']);
  final iOpt = _col(header, ['OptnTp', 'OptionTyp']);
  final iStrike = _col(header, ['StrkPric', 'StrikePrice', 'Strike']);
  final iOi = _col(header, ['OpnIntrst', 'OpenInt', 'OpenInterest']);
  final iChg =
      _col(header, ['ChngInOpnIntrst', 'ChgInOI', 'ChangeInOpenInterest']);
  final iClose = _col(header, ['ClsPric', 'ClosePrice', 'Close']);
  final iPrev = _col(header, ['PrvsClsgPric', 'PrevClose', 'PrevClsgPric']);
  final iLot = _col(header, ['NewBrdLotQty', 'MarketLot', 'LotSize']);
  if (iSymbol < 0 || iExpiry < 0 || iStrike < 0 || iOi < 0 || iChg < 0) {
    return const StockOiBook(bySymbol: {}, rowCount: 0);
  }

  final rows = <String, List<StockOiLeg>>{};
  var rowCount = 0;
  for (var i = 1; i < lines.length; i++) {
    final line = lines[i].trim();
    if (line.isEmpty) continue;
    final parts = splitOiCsv(line);
    if (parts.length <= math.max(iOi, iChg)) continue;
    String at(int idx) =>
        idx >= 0 && idx < parts.length ? parts[idx].trim() : '';
    double? numAt(int idx) {
      final raw = at(idx);
      if (raw.isEmpty) return null;
      return double.tryParse(raw);
    }

    final symbol = at(iSymbol).toUpperCase();
    if (symbol.isEmpty || _indexSymbols.contains(symbol)) continue;

    // UDiFF: FinInstrmTp == 'STO' (stock option). Classic fallback me type
    // column hi nahi hota — tab OptnTp CE/PE par bharosa.
    final type = at(iType).toUpperCase();
    final opt = at(iOpt).toUpperCase();
    final isStockOption =
        type.isNotEmpty ? type == 'STO' : (opt == 'CE' || opt == 'PE');
    if (!isStockOption) continue;
    if (opt != 'CE' && opt != 'PE') continue; // sirf options

    final expiry = parseOiDate(at(iExpiry));
    final strike = numAt(iStrike);
    final oi = numAt(iOi);
    final chg = numAt(iChg);
    if (expiry == null || strike == null || strike <= 0) continue;
    if (oi == null || oi <= 0 || chg == null) continue;

    rows.putIfAbsent(symbol, () => []).add(StockOiLeg(
          symbol: symbol,
          expiry: expiry,
          strike: strike,
          optionType: opt,
          oi: oi,
          oiChange: chg,
          close: numAt(iClose) ?? 0,
          previousClose: numAt(iPrev) ?? 0,
          lotSize: numAt(iLot)?.round() ?? 0,
        ));
    rowCount++;
  }

  final bySymbol = <String, StockOiSnapshot>{
    for (final e in rows.entries)
      e.key: StockOiSnapshot(
        symbol: e.key,
        tradeDate: tradeDate,
        legs: e.value,
      ),
  };
  return StockOiBook(bySymbol: bySymbol, rowCount: rowCount);
}
