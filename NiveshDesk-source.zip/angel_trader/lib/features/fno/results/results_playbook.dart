// ---------------------------------------------------------------------------
// results_playbook.dart — "is stock ke pichle result din me kya hua tha?"
//
// Not a prediction. A habit sheet: for each of the last few result days it
// reads three numbers straight off the cached candles —
//
//   pehle 5 din   the run-up into the announcement (5 sessions before → the
//                 session before): does this stock get bid up into results?
//   result din    the gap at the open and the close-to-close move
//   agla din      what the next session did with it
//
// Only dates the exchange actually announced are used (the results calendar
// already guarantees that). No estimated dates, no "AI said", no guarantee —
// three or four samples is a habit, not a law, and the page says so.
//
// Pure: no Flutter, no database, no network.
// ---------------------------------------------------------------------------

import '../../../data/local/models/result_stamp.dart';
import '../../../data/remote/dto/candle.dart';

/// How many past results the sheet shows.
const int kPlaybookEpisodes = 6;

/// Sessions before the announcement the "run-up" window covers.
const int kRunUpSessions = 5;

/// What one announced result day did, in percent.
class ResultEpisode {
  const ResultEpisode({
    required this.date,
    required this.period,
    this.runUpPct,
    this.gapPct,
    this.dayPct,
    this.nextDayPct,
  });

  /// The announced result date.
  final DateTime date;

  /// `Q1 FY26` — the label the exchange filed it under (may be empty).
  final String period;

  /// Close 5 sessions before → close the session before the result.
  final double? runUpPct;

  /// Open of the result day vs the previous close (the overnight reaction).
  final double? gapPct;

  /// Result-day close vs the previous close.
  final double? dayPct;

  /// Next session's close vs the result-day close.
  final double? nextDayPct;

  String textOf(double? value) {
    if (value == null) return '—';
    return '${value >= 0 ? '+' : '−'}${value.abs().toStringAsFixed(1)}%';
  }

  String get runUpText => textOf(runUpPct);
  String get gapText => textOf(gapPct);
  String get dayText => textOf(dayPct);
  String get nextDayText => textOf(nextDayPct);
}

/// The habit sheet for one stock.
class ResultPlaybook {
  const ResultPlaybook({
    required this.symbol,
    required this.episodes,
    required this.up,
    required this.down,
    required this.avgAbsDayPct,
    required this.maxAbsDayPct,
    required this.avgAbsGapPct,
    this.olderThanCache = 0,
    this.noCandles = false,
    this.candleFrom,
    this.candleTo,
  });

  final String symbol;

  /// Kitne announced result itihaas me the, par itne purane candles phone me
  /// nahi hone ke karan chhod diye gaye. Chhupaya nahi jata — warna aadmi
  /// sochega "iske sirf 2 result hue hain".
  final int olderThanCache;

  /// Phone me is stock ka koi bhi candle nahi pada.
  final bool noCandles;

  /// Candle cache ka daayra (khaali hone par null).
  final DateTime? candleFrom;
  final DateTime? candleTo;

  /// Newest first. Empty when the stock has no usable result history.
  final List<ResultEpisode> episodes;

  /// Result days that closed green / red (a 0.0 % day counts as neither).
  final int up;
  final int down;

  /// Average absolute result-day move — "is din ye stock kitna hilta hai".
  final double? avgAbsDayPct;

  final double? maxAbsDayPct;

  /// Average absolute overnight gap.
  final double? avgAbsGapPct;

  int get samples => episodes.length;

  bool get isEmpty => episodes.isEmpty;

  /// Below this, "habit" would be the wrong word.
  static const int minSamples = 3;

  bool get sufficient => samples >= minSamples;

  /// Candle cache ka daayra, seedhe shabdon me — "sirf 2 result kyun".
  String get rangeNote {
    if (noCandles) {
      return 'Candle cache me data nahi mila. Result row tap par ye '
          'Angel One se download hote hain; login + internet zaroori hai. '
          'Golden Cross ya 3-Month Study scan bhi cache bhar sakta hai.';
    }
    final from = candleFrom;
    final to = candleTo;
    if (from == null || to == null) return '';
    final line = 'Candles phone me ${_day(from)} se ${_day(to)} tak hain.';
    if (olderThanCache == 0) return line;
    return '$line Itihaas me $olderThanCache aur purane result hain, par un '
        'dinon ke candles phone me nahi — isliye woh yahan nahi hain.';
  }

  /// The line under the heading: an honest count, every time.
  ///
  /// Khaali hone par bhi **wajah** batayi jati hai — "itihaas nahi mila" aur
  /// "candles nahi hain" alag-alag baatein hain, aur dono ka ilaaj alag hai.
  String get note {
    if (isEmpty) {
      if (noCandles) {
        return 'Is stock ke candles phone me nahi hain — isliye pichle result '
            'ka hisaab nahi ban sakta. Row tap par Angel One se download ke '
            'liye login + internet zaroori hai.';
      }
      if (olderThanCache > 0) {
        return 'NSE ke itihaas me $olderThanCache result mile, par un dinon ke '
            'candles phone me nahi hain. Angel One login + internet se row '
            'dobara tap karke download ki koshish karein.';
      }
      return 'Is stock ka koi announced result itihaas nahi mila. '
          'Results calendar refresh karke phir dekhiye.';
    }
    if (!sufficient) {
      return 'Sirf $samples result mile — itne se pattern nahi keh sakte, '
          'sirf dekh lijiye.';
    }
    final average = avgAbsDayPct;
    if (average == null) {
      return '$samples result mile — move ka data adhoora hai.';
    }
    return '$samples result · result din aam taur par ±${average.toStringAsFixed(1)}% '
        'chala hai (up $up / down $down)';
  }

  /// `±2.4%` or `—`, for the Results Calendar tile.
  String get tileText {
    final average = avgAbsDayPct;
    if (average == null) return '';
    return 'pichle $samples result: ±${average.toStringAsFixed(1)}%';
  }
}

/// Builds the sheet for one stock from its candles and its announced dates.
///
/// [dates] are the *past* result dates for the symbol (newest or oldest, it
/// does not matter — the sheet sorts them). The official date is shown on the
/// sheet; a filing after 15:30 IST uses the first candle on/after the next
/// calendar day, so the measured move belongs to the first session that could
/// actually react to the result.
ResultPlaybook buildPlaybook({
  required String symbol,
  required List<Candle> bars,
  required List<ResultStamp> dates,
  int maxEpisodes = kPlaybookEpisodes,
  DateTime? candleFrom,
  DateTime? candleTo,
}) {
  if (bars.isEmpty || dates.isEmpty) {
    return ResultPlaybook(
      symbol: symbol,
      episodes: const [],
      up: 0,
      down: 0,
      avgAbsDayPct: null,
      maxAbsDayPct: null,
      avgAbsGapPct: null,
      noCandles: bars.isEmpty,
      candleFrom: candleFrom,
      candleTo: candleTo,
    );
  }

  final sorted = [...bars]..sort((a, b) => a.time.compareTo(b.time));
  final episodes = <ResultEpisode>[];
  final seen = <String>{};
  var olderThanCache = 0;

  final orderedDates = [...dates]
    ..sort((a, b) => b.date.compareTo(a.date)); // newest first

  for (final entry in orderedDates) {
    final key = _dayKey(entry.date);
    if (!seen.add(key)) continue; // the same day filed twice is one result

    final index = _indexOnOrAfter(sorted, entry.reactionDate ?? entry.date);
    // Index 0 has no previous close, and a date past the last candle has
    // nothing to read at all. Dono ka matlab: is din ka hisaab nahi ban sakta.
    if (index <= 0 || index >= sorted.length) {
      if (index <= 0) olderThanCache++;
      continue;
    }

    final bar = sorted[index];
    final previous = sorted[index - 1];

    final double? runUp;
    final runUpIndex = index - 1 - kRunUpSessions;
    if (runUpIndex >= 0 && sorted[runUpIndex].close > 0) {
      runUp = (previous.close / sorted[runUpIndex].close - 1) * 100;
    } else {
      runUp = null;
    }

    final double? gap = previous.close > 0
        ? (bar.open - previous.close) / previous.close * 100
        : null;
    final double? day = previous.close > 0
        ? (bar.close - previous.close) / previous.close * 100
        : null;

    final double? nextDay;
    if (index + 1 < sorted.length && bar.close > 0) {
      nextDay = (sorted[index + 1].close / bar.close - 1) * 100;
    } else {
      nextDay = null;
    }

    episodes.add(
      ResultEpisode(
        date: entry.date,
        period: entry.period,
        runUpPct: runUp,
        gapPct: gap,
        dayPct: day,
        nextDayPct: nextDay,
      ),
    );

    if (episodes.length >= maxEpisodes) break;
  }

  var up = 0;
  var down = 0;
  var daySum = 0.0;
  var dayMax = 0.0;
  var gapSum = 0.0;
  var dayCount = 0;
  var gapCount = 0;

  for (final episode in episodes) {
    final day = episode.dayPct;
    if (day != null) {
      if (day > 0) up++;
      if (day < 0) down++;
      daySum += day.abs();
      if (day.abs() > dayMax) dayMax = day.abs();
      dayCount++;
    }
    final gap = episode.gapPct;
    if (gap != null) {
      gapSum += gap.abs();
      gapCount++;
    }
  }

  return ResultPlaybook(
    symbol: symbol,
    episodes: episodes,
    up: up,
    down: down,
    avgAbsDayPct: dayCount == 0 ? null : daySum / dayCount,
    maxAbsDayPct: dayCount == 0 ? null : dayMax,
    avgAbsGapPct: gapCount == 0 ? null : gapSum / gapCount,
    olderThanCache: olderThanCache,
    noCandles: false,
    candleFrom: candleFrom,
    candleTo: candleTo,
  );
}

/// First candle on or after [date] (compared by IST calendar day).
int _indexOnOrAfter(List<Candle> bars, DateTime date) {
  final target = DateTime(date.year, date.month, date.day);
  for (var i = 0; i < bars.length; i++) {
    final bar = bars[i].istDate;
    final day = DateTime(bar.year, bar.month, bar.day);
    if (!day.isBefore(target)) return i;
  }
  return bars.length;
}

String _day(DateTime date) =>
    '${date.day.toString().padLeft(2, '0')} '
    '${_monthName(date.month)} ${date.year}';

String _monthName(int month) => const [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
][(month - 1).clamp(0, 11)];

String _dayKey(DateTime date) =>
    '${date.year.toString().padLeft(4, '0')}-'
    '${date.month.toString().padLeft(2, '0')}-'
    '${date.day.toString().padLeft(2, '0')}';
