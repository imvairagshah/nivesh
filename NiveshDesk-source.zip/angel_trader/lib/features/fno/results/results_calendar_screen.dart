// ---------------------------------------------------------------------------
// results_calendar_screen.dart — "saari F&O companies ka next result kab".
//
// Its own page, opened from the F&O hub. It has nothing to do with the
// 3-Month Study: no scan button, no candles, no snapshot — just the F&O list
// and the dates NSE has on record (or our flagged estimate where NSE has not
// announced a board meeting yet).
//
// Reading order on the page:
//   1. header      — kitni companies, kitni confirm / anumanit / missing
//   2. search + filters
//   3. the list    — date tile, symbol, company, countdown
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import 'result_playbook_sheet.dart';
import 'results_calendar_provider.dart';

class ResultsCalendarScreen extends StatefulWidget {
  const ResultsCalendarScreen({super.key});

  @override
  State<ResultsCalendarScreen> createState() => _ResultsCalendarScreenState();
}

class _ResultsCalendarScreenState extends State<ResultsCalendarScreen> {
  final TextEditingController _search = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Universe + cached calendar. NSE is only touched when the day's cache is
    // missing or stale — opening this page never starts a scan or a download.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final provider = context.read<ResultsCalendarProvider>();
      if (!provider.hasLoaded) provider.bootstrap();
    });
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ResultsCalendarProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Results Calendar'),
        actions: [
          IconButton(
            tooltip: 'NSE se dobara',
            onPressed: provider.isLoading ? null : () => provider.refresh(),
            icon: provider.isLoading
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.refresh_rounded),
          ),
          IconButton(
            tooltip: 'Read Me',
            icon: const Icon(Icons.help_outline_rounded),
            onPressed: () => _showReadMe(context),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: provider.refresh,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.only(bottom: 26),
          children: [
            _Header(provider: provider),
            _SearchAndFilters(controller: _search, provider: provider),
            _CountLine(provider: provider),
            if (provider.isLoading && !provider.hasLoaded)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 40),
                child: Center(child: CircularProgressIndicator()),
              )
            else if (provider.rows.isEmpty)
              _Empty(provider: provider)
            else
              ...provider.rows.map(
                (row) => _ResultTile(row: row, today: provider.today),
              ),
            const _FooterNote(),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// 1. Header — headline counts always describe the *whole* F&O list
// ---------------------------------------------------------------------------

class _Header extends StatelessWidget {
  const _Header({required this.provider});

  final ResultsCalendarProvider provider;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final colors = MarketColors.of(context);
    final fetchedAt = provider.fetchedAt;

    return Container(
      margin: const EdgeInsets.fromLTRB(12, 12, 12, 0),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            scheme.primaryContainer.withOpacity(0.75),
            scheme.surfaceContainerLow,
          ],
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.event_available_rounded,
                size: 20,
                color: scheme.primary,
              ),
              const SizedBox(width: 8),
              const Expanded(
                child: Text(
                  'Next results — saari F&O companies',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            provider.usingFallbackUniverse
                ? 'F&O list (CSV) load nahi hui — NSE jitni companies deta hai '
                      'utni hi dikh rahi hain.'
                : '${provider.total} F&O companies — jinke board meeting ka '
                      'notice aa chuka hai (confirm) wo upar, baki neeche unke '
                      'pichle result ke saath.',
            style: TextStyle(
              fontSize: 11.5,
              height: 1.35,
              color: scheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              _Stat(
                value: provider.confirmedCount,
                label: 'confirm',
                color: scheme.primary,
              ),
              const SizedBox(width: 8),
              _Stat(
                value: provider.lastKnownCount,
                label: 'pichla result',
                color: colors.nearHigh,
              ),
              const SizedBox(width: 8),
              _Stat(
                value: provider.missingCount,
                label: 'NSE me nahi',
                color: scheme.onSurfaceVariant,
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            fetchedAt == null || fetchedAt.millisecondsSinceEpoch == 0
                ? 'NSE se data abhi tak nahi aaya.'
                : 'NSE se aakhri baar: ${Fmt.dateTime(fetchedAt)} · app din me '
                      'ek hi baar poochta hai.',
            style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
          ),
          if (provider.note != null && provider.note!.isNotEmpty) ...[
            const SizedBox(height: 6),
            Text(
              provider.note!,
              style: TextStyle(fontSize: 10.5, color: colors.stale),
            ),
          ],
        ],
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat({required this.value, required this.label, required this.color});

  final int value;
  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: scheme.surface.withOpacity(0.55),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '$value',
              style: TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w800,
                color: color,
              ),
            ),
            Text(
              label,
              style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// 2. Search + filters
// ---------------------------------------------------------------------------

class _SearchAndFilters extends StatelessWidget {
  const _SearchAndFilters({required this.controller, required this.provider});

  final TextEditingController controller;
  final ResultsCalendarProvider provider;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
          child: SizedBox(
            height: 40,
            child: TextField(
              controller: controller,
              onChanged: (value) =>
                  context.read<ResultsCalendarProvider>().setQuery(value),
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                isDense: true,
                hintText: 'Symbol ya company search karo',
                hintStyle: const TextStyle(fontSize: 12.5),
                prefixIcon: const Icon(Icons.search_rounded, size: 18),
                suffixIcon: provider.query.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.close_rounded, size: 16),
                        onPressed: () {
                          controller.clear();
                          context.read<ResultsCalendarProvider>().setQuery('');
                        },
                      ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 8,
                ),
              ),
              style: const TextStyle(fontSize: 13),
            ),
          ),
        ),
        SizedBox(
          height: 34,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            itemCount: ResultsFilter.values.length,
            separatorBuilder: (_, __) => const SizedBox(width: 6),
            itemBuilder: (context, index) {
              final filter = ResultsFilter.values[index];
              return ChoiceChip(
                label: Text(
                  filter.label,
                  style: const TextStyle(fontSize: 11.5),
                ),
                selected: provider.filter == filter,
                onSelected: (_) =>
                    context.read<ResultsCalendarProvider>().setFilter(filter),
                visualDensity: VisualDensity.compact,
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                showCheckmark: false,
              );
            },
          ),
        ),
      ],
    );
  }
}

class _CountLine extends StatelessWidget {
  const _CountLine({required this.provider});

  final ResultsCalendarProvider provider;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 8, 14, 4),
      child: Text(
        'Dikhaye ja rahe: ${provider.rows.length} / ${provider.total}',
        style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// 3. The list
// ---------------------------------------------------------------------------

class _ResultTile extends StatelessWidget {
  const _ResultTile({required this.row, required this.today});

  final ResultRow row;
  final DateTime today;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final days = row.daysAway(today);

    final tagColor = row.nextConfirmed
        ? scheme.primary
        : scheme.onSurfaceVariant;

    // Agar is stock ka hisaab kabhi ban chuka ho to ek line ka saaransh;
    // warna sirf chevron (213 rows ke liye candles padhna mehenga padega).
    final summary = context.select<ResultsCalendarProvider, String>((provider) {
      final playbook = provider.playbookOf(row.symbol);
      return playbook?.tileText ?? '';
    });

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () => showResultPlaybookSheet(context, row: row),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 7),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _DateTile(date: row.nextDate),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              row.symbol,
                              style: const TextStyle(
                                fontSize: 13.5,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                          if (row.newlyDeclared) ...[
                            _StatusTag(label: 'NAYA', color: scheme.tertiary),
                            const SizedBox(width: 4),
                          ],
                          _StatusTag(label: row.tagLabel, color: tagColor),
                        ],
                      ),
                      if (row.name.isNotEmpty)
                        Text(
                          row.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 11.5,
                            color: scheme.onSurfaceVariant,
                          ),
                        ),
                      if (row.newlyDeclaredAt != null)
                        Text(
                          'NSE broadcast: ${Fmt.dateTime(row.newlyDeclaredAt!)}',
                          style: TextStyle(
                            fontSize: 10,
                            color: scheme.tertiary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      const SizedBox(height: 2),
                      Text(
                        _detail(row, days),
                        style: TextStyle(
                          fontSize: 11,
                          height: 1.3,
                          color: row.hasDate
                              ? scheme.onSurface
                              : scheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 4),
                Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: PlaybookHint(summary: summary),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// The line under the company name.
  ///
  /// A company with an announced date gets `date · countdown · pichla result …`.
  /// A company without one gets **only** the last result, said plainly —
  /// `Pichla result: 04 Nov 2025 · Q2 · quarter ended Sep 2025 · 62 din hue`.
  /// Nothing here is estimated: an invented date reads as a fact, so there is
  /// no date at all until NSE publishes the board-meeting intimation.
  String _detail(ResultRow row, int? days) {
    final next = row.nextDate;
    if (next == null) {
      final last = row.lastResultLine(today);
      return last.isEmpty
          ? 'NSE ke results feed me abhi nahi mila'
          : 'Pichla result: $last';
    }
    final when = '${Fmt.date(next)} · ${ResultRow.countdown(days ?? 0)}';
    final last = row.lastDate;
    return last == null ? when : '$when · pichla result ${Fmt.date(last)}';
  }
}

/// The little calendar square: day number + month, or a dash when unknown.
class _StatusTag extends StatelessWidget {
  const _StatusTag({required this.label, required this.color});

  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
    decoration: BoxDecoration(
      color: color.withOpacity(0.12),
      borderRadius: BorderRadius.circular(50),
      border: Border.all(color: color.withOpacity(0.45)),
    ),
    child: Text(
      label,
      style: TextStyle(
        fontSize: 9.5,
        fontWeight: FontWeight.w700,
        color: color,
      ),
    ),
  );
}

class _DateTile extends StatelessWidget {
  const _DateTile({required this.date});

  final DateTime? date;

  static const List<String> _months = [
    'JAN',
    'FEB',
    'MAR',
    'APR',
    'MAY',
    'JUN',
    'JUL',
    'AUG',
    'SEP',
    'OCT',
    'NOV',
    'DEC',
  ];

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final date = this.date;

    return Container(
      width: 52,
      padding: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest.withOpacity(0.6),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        children: [
          Text(
            date == null ? '—' : '${date.day}',
            style: TextStyle(
              fontSize: date == null ? 14 : 16,
              fontWeight: FontWeight.w800,
              color: scheme.onSurface,
            ),
          ),
          Text(
            date == null ? '' : _months[date.month - 1],
            style: TextStyle(
              fontSize: 9.5,
              letterSpacing: 0.5,
              fontWeight: FontWeight.w700,
              color: scheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}

class _Empty extends StatelessWidget {
  const _Empty({required this.provider});

  final ResultsCalendarProvider provider;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final colors = MarketColors.of(context);
    // Nothing dated anywhere (and no search) = the fetch is the problem, not
    // the filter. Say so and offer the retry — even when a filter is on: the
    // page now opens on Confirm, so "Confirm me kuch nahi hai" would otherwise
    // hide the real reason (NSE down) behind a filter message.
    final fetchProblem = !provider.hasAnyData && provider.query.trim().isEmpty;

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 34, 20, 34),
      child: Column(
        children: [
          Icon(
            fetchProblem ? Icons.cloud_off_rounded : Icons.event_busy_rounded,
            size: 34,
            color: fetchProblem ? colors.stale : scheme.onSurfaceVariant,
          ),
          const SizedBox(height: 10),
          Text(
            fetchProblem
                ? 'NSE se abhi koi results date nahi aa payi — na internet, na '
                      'NSE ka jawab. Neeche dobara try karo.'
                : provider.emptyReason,
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12.5, color: scheme.onSurfaceVariant),
          ),
          if (fetchProblem) ...[
            const SizedBox(height: 14),
            FilledButton.tonalIcon(
              onPressed: provider.isLoading ? null : () => provider.refresh(),
              icon: provider.isLoading
                  ? const SizedBox(
                      width: 14,
                      height: 14,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.refresh_rounded, size: 18),
              label: const Text('Dubara try karo'),
            ),
          ],
        ],
      ),
    );
  }
}

class _FooterNote extends StatelessWidget {
  const _FooterNote();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: Text(
        'confirm = NSE par board meeting ka notice aa chuka hai (date pakki).\n'
        'Baki companies ke aage koi date nahi likhi — NSE ne abhi notice hi '
        'nahi diya, is liye unki line me sirf PICHLA RESULT (kab aaya tha, '
        'kaunsa quarter, kitne din hue) likha hai.\n'
        'Koi bhi date andaze se nahi banayi jaati — andaza pakki date jaisa '
        'lagta hai, is liye app chup rehna behtar samajhta hai.\n'
        'Source: NSE corporate filings (board meetings + financial results). '
        'Angel SmartAPI me results calendar nahi hota.',
        style: TextStyle(
          fontSize: 10.5,
          height: 1.45,
          color: scheme.onSurfaceVariant,
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Read Me
// ---------------------------------------------------------------------------

void _showReadMe(BuildContext context) {
  showDialog<void>(
    context: context,
    builder: (context) => AlertDialog(
      title: const Text('Results Calendar — Read Me'),
      content: const SingleChildScrollView(
        child: Text(
          'Ye page sirf ek kaam karta hai: saari F&O companies ki next '
          'result ki date dikhana — sirf wahi date jo NSE ne khud '
          'batayi ho.\n\n'
          '• confirm — NSE par company ne board meeting ka notice de diya hai '
          '(date pakki maan sakte hain).\n'
          '• NSE me nahi — is company ka abhi koi notice nahi aaya. Aisi '
          'line me neeche "Pichla result: <date> · <quarter> · kitne din hue" '
          'likha hota hai, taaki pata rahe aakhri baar result kab aaya '
          'tha.\n'
          '• Kisi bhi date ka andaza nahi lagaya jaata. Pehle app pichle '
          'result me ~91 din jod kar "anumanit" date chapa karta tha — wo '
          'ab band hai, kyun ki andaze ki date asli date jaisi lagti hai.\n\n'
          'Data NSE ke public corporate filings se aata hai — SmartAPI me ye '
          'endpoint nahi hai. App din me ek hi baar poochta hai; baaki time '
          'phone me cached rehta hai. Upar ke refresh button se, ya list ko '
          'neeche kheench ke dobara la sakte ho.\n\n'
          'Ye page 3-Month Study se bilkul alag hai — koi scan nahi chalta, '
          'koi candle download nahi hota.',
          style: TextStyle(fontSize: 12.5, height: 1.4),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Samajh gaya'),
        ),
      ],
    ),
  );
}
