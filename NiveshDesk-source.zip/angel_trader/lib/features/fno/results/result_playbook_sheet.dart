// ---------------------------------------------------------------------------
// result_playbook_sheet.dart — Result Calendar ki row tap karne par khulne
// wali sheet: **"is stock ke pichle result din me kya hua tha?"**
//
// Har result ke liye chaar number, seedhe candles se:
//   pehle 5 din   result se pahle ka run-up (kya bhav uthaya jata hai?)
//   gap           result wali subah ka opening gap
//   result din    us din ka close-to-close move
//   agla din      market ne agle din us move ke saath kya kiya
//
// YE BHAVISHYA NAHIN HAI. Do-char nishaniyan ek aadat bata sakti hain, kanoon
// nahi — isliye sheet me "kitne result mile" hamesha likha rehta hai, aur
// "kuch nahi mila" bhi chhupaya nahi jata.
//
// Pehle phone ka candle cache dekha jata hai. Range kam ho to sirf tapped
// stock ke daily candles Angel One se aate aur cache me save hote hain; iske
// liye login + internet chahiye. Dates NSE ki announced history se hain —
// andaze ki koi date nahi.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import 'results_calendar_provider.dart';
import 'results_playbook.dart';

/// Row tap karne par yahi khulta hai.
Future<void> showResultPlaybookSheet(
  BuildContext context, {
  required ResultRow row,
}) => showModalBottomSheet<void>(
  context: context,
  isScrollControlled: true,
  useSafeArea: true,
  showDragHandle: true,
  builder: (_) => _PlaybookSheet(row: row),
);

class _PlaybookSheet extends StatefulWidget {
  const _PlaybookSheet({required this.row});

  final ResultRow row;

  @override
  State<_PlaybookSheet> createState() => _PlaybookSheetState();
}

class _PlaybookSheetState extends State<_PlaybookSheet> {
  Future<ResultPlaybook>? _future;

  @override
  void initState() {
    super.initState();
    final provider = context.read<ResultsCalendarProvider>();
    _future = provider.playbookFor(widget.row);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: FutureBuilder<ResultPlaybook>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return SizedBox(
              height: 220,
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const CircularProgressIndicator(),
                    const SizedBox(height: 12),
                    Text(
                      'Is stock ke candles check / download ho rahe hain…',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 11.5,
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }
          if (snapshot.hasError) {
            final scheme = Theme.of(context).colorScheme;
            return _SheetPad(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.cloud_off_rounded, color: scheme.error, size: 28),
                  const SizedBox(height: 8),
                  Text(
                    snapshot.error.toString(),
                    textAlign: TextAlign.center,
                    style: TextStyle(color: scheme.error, fontSize: 12),
                  ),
                  const SizedBox(height: 6),
                  TextButton.icon(
                    onPressed: () => setState(() {
                      _future = context
                          .read<ResultsCalendarProvider>()
                          .playbookFor(widget.row);
                    }),
                    icon: const Icon(Icons.refresh_rounded, size: 17),
                    label: const Text('Dobara koshish'),
                  ),
                ],
              ),
            );
          }
          final playbook = snapshot.data;
          if (playbook == null) {
            return const _SheetPad(child: Text('Kuch nahi mila.'));
          }
          return _PlaybookBody(row: widget.row, playbook: playbook);
        },
      ),
    );
  }
}

class _SheetPad extends StatelessWidget {
  const _SheetPad({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) =>
      Padding(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), child: child);
}

// ---------------------------------------------------------------------------
// Body
// ---------------------------------------------------------------------------

class _PlaybookBody extends StatelessWidget {
  const _PlaybookBody({required this.row, required this.playbook});

  final ResultRow row;
  final ResultPlaybook playbook;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          _Heading(row: row),
          const SizedBox(height: 10),
          _Note(playbook: playbook),
          if (playbook.episodes.isNotEmpty) ...[
            const SizedBox(height: 12),
            _StatRow(playbook: playbook),
            const SizedBox(height: 14),
            _EpisodeTable(playbook: playbook),
          ],
          const SizedBox(height: 14),
          _Range(playbook: playbook),
          const SizedBox(height: 12),
          _Honest(),
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton(
              onPressed: () => Navigator.of(context).maybePop(),
              child: const Text('Band karo'),
            ),
          ),
        ],
      ),
    );
  }
}

class _Heading extends StatelessWidget {
  const _Heading({required this.row});

  final ResultRow row;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
          decoration: BoxDecoration(
            color: scheme.primary.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            row.symbol,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w800,
              color: scheme.primary,
            ),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            row.name.isEmpty ? 'Pichle result ka hisaab' : row.name,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 12.5),
          ),
        ),
      ],
    );
  }
}

class _Note extends StatelessWidget {
  const _Note({required this.playbook});

  final ResultPlaybook playbook;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest.withValues(alpha: 0.45),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        playbook.note,
        style: TextStyle(fontSize: 11.5, color: scheme.onSurface),
      ),
    );
  }
}

class _StatRow extends StatelessWidget {
  const _StatRow({required this.playbook});

  final ResultPlaybook playbook;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final market = MarketColors.of(context);

    Widget cell(String label, String value, {Color? color}) => Expanded(
      child: Container(
        margin: const EdgeInsets.only(right: 6),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(9),
          border: Border.all(
            color: scheme.outlineVariant.withValues(alpha: 0.6),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant),
            ),
            const SizedBox(height: 2),
            Text(
              value,
              style: TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w700,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );

    final avg = playbook.avgAbsDayPct;
    final max = playbook.maxAbsDayPct;
    final gap = playbook.avgAbsGapPct;

    return Row(
      children: [
        cell(
          'up / down',
          '${playbook.up} / ${playbook.down}',
          color: market.forValue((playbook.up - playbook.down).toDouble()),
        ),
        cell('aam move', avg == null ? '—' : '±${avg.toStringAsFixed(1)}%'),
        cell('sabse bada', max == null ? '—' : '${max.toStringAsFixed(1)}%'),
        cell('subah ka gap', gap == null ? '—' : '±${gap.toStringAsFixed(1)}%'),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Table
// ---------------------------------------------------------------------------

class _EpisodeTable extends StatelessWidget {
  const _EpisodeTable({required this.playbook});

  final ResultPlaybook playbook;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final market = MarketColors.of(context);

    Widget valueCell(String text, double? pct) => Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
      child: Text(
        text,
        textAlign: TextAlign.right,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w600,
          color: pct == null ? scheme.onSurfaceVariant : market.forValue(pct),
        ),
      ),
    );

    final rows = <TableRow>[
      TableRow(
        decoration: BoxDecoration(
          color: scheme.surfaceContainerHighest.withValues(alpha: 0.7),
        ),
        children: [
          for (final label in const [
            'Din',
            'Pehle 5 din',
            'Gap',
            'Result din',
            'Agla din',
          ])
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
              child: Text(
                label,
                textAlign: label == 'Din' ? TextAlign.left : TextAlign.right,
                style: TextStyle(
                  fontSize: 9.5,
                  fontWeight: FontWeight.w700,
                  color: scheme.onSurfaceVariant,
                ),
              ),
            ),
        ],
      ),
    ];

    for (var i = 0; i < playbook.episodes.length; i++) {
      final episode = playbook.episodes[i];
      rows.add(
        TableRow(
          decoration: BoxDecoration(
            color: i.isOdd
                ? scheme.surfaceContainerHighest.withValues(alpha: 0.25)
                : null,
          ),
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 7),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    Fmt.dateShort(episode.date),
                    style: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  if (episode.period.isNotEmpty)
                    Text(
                      episode.period,
                      style: TextStyle(
                        fontSize: 9,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                ],
              ),
            ),
            valueCell(episode.runUpText, episode.runUpPct),
            valueCell(episode.gapText, episode.gapPct),
            valueCell(episode.dayText, episode.dayPct),
            valueCell(episode.nextDayText, episode.nextDayPct),
          ],
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Table(
          columnWidths: const <int, TableColumnWidth>{
            0: FlexColumnWidth(1.5),
            1: FlexColumnWidth(1.1),
            2: FlexColumnWidth(0.9),
            3: FlexColumnWidth(1.1),
            4: FlexColumnWidth(1.0),
          },
          border: TableBorder.all(
            color: scheme.outlineVariant.withValues(alpha: 0.45),
            width: 0.5,
          ),
          children: rows,
        ),
        const SizedBox(height: 6),
        Text(
          'Pehle 5 din = result se pahle ke 5 session. Gap = result wali subah '
          'ka opening gap. Result din = us din ka close-to-close. Agla din = '
          'market ne agle din kya kiya.',
          style: TextStyle(fontSize: 9.5, color: scheme.onSurfaceVariant),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Data provenance + honesty
// ---------------------------------------------------------------------------

class _Range extends StatelessWidget {
  const _Range({required this.playbook});

  final ResultPlaybook playbook;

  @override
  Widget build(BuildContext context) {
    final note = playbook.rangeNote;
    if (note.isEmpty) return const SizedBox.shrink();
    final scheme = Theme.of(context).colorScheme;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(Icons.info_outline_rounded, size: 14, color: scheme.outline),
        const SizedBox(width: 6),
        Expanded(
          child: Text(
            note,
            style: TextStyle(fontSize: 10.5, color: scheme.onSurfaceVariant),
          ),
        ),
      ],
    );
  }
}

class _Honest extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: scheme.errorContainer.withValues(alpha: 0.35),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        'Ye itihaas hai, bhavishya nahi. Do-char result se aadat padhti hai, '
        'koi guarantee nahi — result ke din khabar, guidance aur poora bazaar '
        'badal jata hai. Koi bhi date andazi se nahi banayi gayi: sirf NSE ki '
        'announced dates.',
        style: TextStyle(fontSize: 10.5, color: scheme.onErrorContainer),
      ),
    );
  }
}

/// Row ke upar lagne wala chhota sa ishara — chevron, aur (agar hisaab ban
/// chuka ho to) ek line ka saaransh.
class PlaybookHint extends StatelessWidget {
  const PlaybookHint({super.key, required this.summary});

  /// `pichle 4 result: ±2.4%` — khaali ho to kuch nahi likha jata.
  final String summary;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (summary.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(right: 4),
            child: Text(
              summary,
              style: TextStyle(fontSize: 10, color: scheme.primary),
            ),
          ),
        Icon(
          Icons.chevron_right_rounded,
          size: 16,
          color: scheme.onSurfaceVariant,
        ),
      ],
    );
  }
}
