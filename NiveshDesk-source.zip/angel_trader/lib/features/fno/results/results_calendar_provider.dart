// ---------------------------------------------------------------------------
// results_calendar_provider.dart — "saari F&O companies ka next result kab?".
//
// This is a standalone tool with its own page. It deliberately shares no scan
// or snapshot state with the 3-Month Study screen. It does reuse the common
// daily-candle cache: an on-tap playbook reads it and fetches only this stock
// when the NSE result window is not covered. The day-cached NSE calendar
// ([EarningsCalendarService]) is also shared, so NSE is asked at most once/day.
//
// The page must cover the *whole* F&O list (213 names), not just the companies
// NSE happened to mention. So the list is built by walking the shipped F&O
// universe and looking each symbol up in the calendar; a company with no row
// still gets a line, marked "NSE me abhi nahi mila". Headline counts always
// describe the full list — never a filtered subset (1.5.6 rule).
//
// Two kinds of line, and the UI never blurs them:
//   • confirm — NSE carries a board-meeting intimation, so the date is a fact
//   • no date — nothing announced: the line shows the company's **last** result
//     (kab aaya tha) instead. Nothing here is ever guessed: builds ≤ 1.5.12
//     invented a "next" date a quarter after the last filing, and the user
//     asked for it gone (a guess reads as a fact, and it moves the row).
// ---------------------------------------------------------------------------

import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../../core/utils/formatters.dart' show Fmt;
import '../../../data/local/dao/candle_dao.dart';
import '../../../data/local/dao/result_history_dao.dart';
import '../../../data/local/models/result_stamp.dart';
import '../../../data/remote/api_client.dart' show ApiException;
import '../../../data/remote/dto/candle.dart';
import '../../../data/remote/dto/scrip.dart';
import '../../../services/candle_source.dart';
import '../../../services/earnings_calendar_service.dart';
import '../../../services/fno_universe.dart';
import 'results_playbook.dart';

/// F&O symbol → Angel One cash scrip (normally `SBIN-EQ` on NSE).
typedef ResultScripResolver = Future<Scrip?> Function(ResultRow row);

/// Friendly error shown in the result sheet when the one-stock candle request
/// cannot be made. (The exception's text is safe for the UI.)
class ResultPlaybookLoadException implements Exception {
  const ResultPlaybookLoadException(this.message);

  final String message;

  @override
  String toString() => message;
}

/// How the list is narrowed. Filtering never changes the headline counts.
enum ResultsFilter {
  all('Sab'),
  confirmed('Confirm'),
  newlyDeclared('Naya declared'),
  missing('NSE me nahi');

  const ResultsFilter(this.label);

  final String label;
}

/// One company's line on the Results Calendar page.
class ResultRow {
  const ResultRow({
    required this.symbol,
    required this.name,
    this.nextDate,
    this.nextLabel = '',
    this.nextConfirmed = false,
    this.lastDate,
    this.lastLabel = '',
    this.newlyDeclaredAt,
  });

  final String symbol;
  final String name;

  /// Next results day — NSE's own announcement, or null (nothing intimated).
  final DateTime? nextDate;
  final String nextLabel;
  final bool nextConfirmed;

  /// Day of the latest filed result (null = not in the feed).
  final DateTime? lastDate;
  final String lastLabel;

  /// Official NSE broadcast/publication date for a result-meeting notice less
  /// than 48 hours old. Null unless the timestamp is verified from NSE.
  final DateTime? newlyDeclaredAt;

  bool get newlyDeclared => newlyDeclaredAt != null;
  bool get hasDate => nextDate != null;

  /// `true` when this line is NSE's own announcement.
  bool get announced => nextConfirmed;

  /// Whole days from [today] to [nextDate]; negative once the day has passed.
  int? daysAway(DateTime today) {
    final next = nextDate;
    if (next == null) return null;
    final a = DateTime(next.year, next.month, next.day);
    final b = DateTime(today.year, today.month, today.day);
    return a.difference(b).inDays;
  }

  /// `aaj` / `kal` / `17 din baaki` — the same phrasing the study panel uses.
  static String countdown(int days) {
    if (days < 0) return 'ho gaya';
    if (days == 0) return 'aaj';
    if (days == 1) return 'kal';
    return '$days din baaki';
  }

  /// What the chip on the right says.
  String get tagLabel => nextConfirmed ? 'confirm' : 'NSE me nahi';

  /// `Pichla result: 04 Nov 2025 · Q2 · quarter ended Sep 2025 · 62 din hue` —
  /// the line a company with no announced date is represented by. Empty when
  /// even the last result is unknown.
  String lastResultLine(DateTime today) {
    final last = lastDate;
    if (last == null) return '';
    final days = DateTime(
      today.year,
      today.month,
      today.day,
    ).difference(DateTime(last.year, last.month, last.day)).inDays;
    final quarter = lastLabel.isEmpty ? '' : ' · $lastLabel';
    final ago = days <= 0 ? '' : ' · $days din hue';
    return '${Fmt.date(last)}$quarter$ago';
  }
}

class ResultsCalendarProvider extends ChangeNotifier {
  ResultsCalendarProvider({
    required EarningsCalendarService earnings,
    CandleDao? candles,
    ResultHistoryDao? history,
    CandleSource? candleSource,
    ResultScripResolver? resolveScrip,
    FnoUniverse? fnoUniverse,
    DateTime Function()? now,
  }) : _earnings = earnings,
       _candles = candles,
       _history = history,
       _candleSource = candleSource,
       _resolveScrip = resolveScrip,
       _fno = fnoUniverse,
       _now = now ?? DateTime.now;

  final EarningsCalendarService _earnings;

  /// Playbook ke liye: cached candles (pehle isi ko dekhta hai).
  final CandleDao? _candles;

  /// Playbook ke liye: NSE se aaye pichle announced results.
  final ResultHistoryDao? _history;

  /// Cached range kam pade to **sirf tapped stock** ke daily candles mangta hai.
  final CandleSource? _candleSource;

  /// Cash scrip token (e.g. `SBIN-EQ`) ko local scrip master se resolve karta hai.
  final ResultScripResolver? _resolveScrip;

  final DateTime Function() _now;

  FnoUniverse? _fno;
  EarningsCalendar? _calendar;

  bool _loading = false;
  bool _loaded = false;
  String? _note;

  /// When the last attempt finished (even if it failed) — shown on the page so
  /// "nothing is coming" can be told apart from "never tried".
  DateTime? _attemptedAt;
  String _query = '';

  /// Opens on **Confirm**: the page exists for dates NSE actually announced.
  /// ("Sab" is one tap away, and the headline counts always describe the whole
  /// list — filtering never changes them.)
  ResultsFilter _filter = ResultsFilter.confirmed;
  Timer? _newAnnouncementExpiryTimer;

  // ---- getters -----------------------------------------------------------

  /// `true` while the universe or NSE fetch is in flight.
  bool get isLoading => _loading;

  /// `true` once [bootstrap] (or a refresh) has finished at least once.
  bool get hasLoaded => _loaded;

  /// Fetch problem / NSE remark — shown under the header when it exists.
  String? get note => _note;

  /// When the calendar was last taken from NSE (null = never).
  DateTime? get fetchedAt => _calendar?.fetchedAt;

  /// When the app last *asked* NSE (success or failure) — this page only.
  DateTime? get attemptedAt => _attemptedAt;

  String get query => _query;
  ResultsFilter get filter => _filter;

  DateTime get today => _now();

  /// `true` when the shipped F&O CSV could not be read and we fell back to the
  /// symbols NSE happened to mention — the header says so instead of pretending.
  bool get usingFallbackUniverse =>
      (_fno?.symbols.isEmpty ?? true) && !(_calendar?.isEmpty ?? true);

  /// `true` when *at least one* company has a date. When this is false the page
  /// has nothing real to show and must say why instead of looking broken.
  bool get hasAnyData => allRows.any((row) => row.hasDate);

  /// `true` when the last NSE attempt failed (or brought nothing at all).
  bool get fetchFailed => _earnings.lastFetchFailed;

  /// The F&O list, or (CSV missing) whatever NSE gave us.
  List<String> get _symbols {
    final fno = _fno;
    if (fno != null && fno.symbols.isNotEmpty) return fno.symbols;
    final calendar = _calendar;
    if (calendar != null && calendar.bySymbol.isNotEmpty) {
      return calendar.bySymbol.keys.toList()..sort();
    }
    return const [];
  }

  /// Headline number: the whole list, filter or search ke bina.
  int get total => _symbols.length;

  /// Companies whose next date NSE has actually announced.
  int get confirmedCount => allRows.where((r) => r.hasDate).length;

  int get newlyDeclaredCount => allRows.where((r) => r.newlyDeclared).length;

  /// Companies whose *last* result is on record — the line the calendar prints
  /// for every company with no announced date.
  int get lastKnownCount => allRows.where((r) => r.lastDate != null).length;

  /// Companies with no announced date (they still get a row).
  int get missingCount => allRows.where((r) => !r.hasDate).length;

  List<ResultRow>? _rowsMemo;

  /// Every company, nearest date first; no-date rows last (symbol order).
  List<ResultRow> get allRows {
    final memo = _rowsMemo;
    if (memo != null) return memo;

    final calendar = _calendar;
    final names = _fno?.companyNames ?? const <String, String>{};
    final rows = <ResultRow>[];
    for (final symbol in _symbols) {
      final info = calendar?.of(symbol) ?? EarningsInfo.none;
      // Only NSE's own announcement counts as a date; a leftover guessed row
      // from an older build's cache is treated as "no date".
      rows.add(
        ResultRow(
          symbol: symbol,
          name: names[symbol] ?? '',
          nextDate: info.announcedNext,
          nextLabel: info.nextConfirmed ? info.nextLabel : '',
          nextConfirmed: info.hasAnnouncedNext,
          lastDate: info.lastDate,
          lastLabel: info.lastLabel,
          newlyDeclaredAt: info.hasAnnouncedNext
              ? _earnings.newlyDeclaredAt(symbol, info.announcedNext)
              : null,
        ),
      );
    }
    rows.sort((a, b) {
      final x = a.nextDate;
      final y = b.nextDate;
      if (x == null && y == null) return a.symbol.compareTo(b.symbol);
      if (x == null) return 1;
      if (y == null) return -1;
      final byDate = x.compareTo(y);
      return byDate != 0 ? byDate : a.symbol.compareTo(b.symbol);
    });
    _scheduleNewAnnouncementExpiry(rows);
    return _rowsMemo = rows;
  }

  void _scheduleNewAnnouncementExpiry(List<ResultRow> rows) {
    _newAnnouncementExpiryTimer?.cancel();
    final now = _now();
    final expiry = rows
        .map((row) => row.newlyDeclaredAt)
        .whereType<DateTime>()
        .map(
          (at) => at.add(EarningsCalendarService.newResultAnnouncementLifetime),
        )
        .where((at) => at.isAfter(now))
        .fold<DateTime?>(null, (soonest, at) {
          if (soonest == null || at.isBefore(soonest)) return at;
          return soonest;
        });
    if (expiry == null) return;
    _newAnnouncementExpiryTimer = Timer(expiry.difference(now), () {
      _newAnnouncementExpiryTimer = null;
      _rowsMemo = null;
      notifyListeners();
    });
  }

  @override
  void dispose() {
    _newAnnouncementExpiryTimer?.cancel();
    super.dispose();
  }

  /// What the list widget renders: search + filter applied on top of [allRows].
  List<ResultRow> get rows {
    final q = _query.trim().toUpperCase();
    return allRows.where((row) {
      final matchesFilter = switch (_filter) {
        ResultsFilter.all => true,
        ResultsFilter.confirmed => row.hasDate,
        ResultsFilter.newlyDeclared => row.newlyDeclared,
        ResultsFilter.missing => !row.hasDate,
      };
      if (!matchesFilter) return false;
      if (q.isEmpty) return true;
      return row.symbol.contains(q) || row.name.toUpperCase().contains(q);
    }).toList();
  }

  /// `Kuch nahi mila` description for the empty state.
  String get emptyReason {
    final searching = _query.trim().isNotEmpty;
    final filtering = _filter != ResultsFilter.all;
    if (searching && filtering) {
      return 'Is search + "${_filter.label}" filter me koi company nahi hai.';
    }
    if (searching) return 'Is search se koi company nahi mili.';
    if (filtering) {
      if (_filter == ResultsFilter.newlyDeclared) {
        return 'Pichhle 2 din me NSE broadcast date se verify hui koi nayi '
            'result announcement nahi mili.';
      }
      // Point at the way out: the filter is the reason, not the data.
      return allRows.isEmpty
          ? '"${_filter.label}" me abhi koi company nahi hai.'
          : '"${_filter.label}" me abhi koi company nahi hai — "Sab" dabao, '
                'poori list dikh jayegi.';
    }
    return 'List khaali hai — F&O symbols load nahi hue.';
  }

  // ---- playbook ----------------------------------------------------------

  /// Ek stock ka "pichle results me kya hua tha" — row tap karne par khulta hai.
  ///
  /// Pehle local cache me **broker wala symbol** dekhta hai (`SBIN-EQ`, plain
  /// `SBIN` nahi — purana lookup isi wajah se saved candles miss kar sakta tha).
  /// Agar NSE ki announced result dates ke aas-paas candles kam hon, to Sirf
  /// us tapped stock ke candles Angel One se ek baar laata hai, SQLite me save
  /// karta hai, phir playbook banata hai. Koi scan / quote / doosre stock ki
  /// request nahi. Dates phir bhi sirf NSE announcements se aati hain.
  final Map<String, ResultPlaybook> _playbooks = <String, ResultPlaybook>{};
  final Map<String, Future<ResultPlaybook>> _playbookJobs =
      <String, Future<ResultPlaybook>>{};

  /// Pehle se bana hua playbook (turant dikhane ke liye), warna `null`.
  ResultPlaybook? playbookOf(String symbol) =>
      _playbooks[symbol.trim().toUpperCase()];

  Future<ResultPlaybook> playbookFor(ResultRow row) {
    final symbol = row.symbol.trim().toUpperCase();
    final cached = _playbooks[symbol];
    if (cached != null) return Future.value(cached);
    final running = _playbookJobs[symbol];
    if (running != null) return running;

    late final Future<ResultPlaybook> job;
    job = _loadPlaybook(row).whenComplete(() {
      if (identical(_playbookJobs[symbol], job)) {
        _playbookJobs.remove(symbol);
      }
    });
    _playbookJobs[symbol] = job;
    return job;
  }

  Future<ResultPlaybook> _loadPlaybook(ResultRow row) async {
    final symbol = row.symbol.trim().toUpperCase();
    final historyDao = _history;
    final candleDao = _candles;

    // 1. Dates: NSE ka announced itihaas. Na ho to sirf aakhiri result —
    //    ek episode hi sahi, par woh bhi andaza nahi, hakikat hai.
    final dates = <ResultStamp>[
      if (historyDao != null) ...await historyDao.forSymbol(symbol),
    ];
    if (dates.isEmpty) {
      final last = row.lastDate;
      if (last != null) {
        dates.add(ResultStamp(date: last, period: row.lastLabel));
      }
    }

    // 2. Broker scrip resolve karo. Candle cache/REST dono ka key `SBIN-EQ`
    //    hota hai; row ka plain F&O ticker `SBIN` hai.
    Scrip? scrip;
    Object? scripResolveError;
    final resolveScrip = _resolveScrip;
    if (resolveScrip != null) {
      try {
        scrip = await resolveScrip(row);
      } catch (error) {
        // Still read a possible legacy/plain-symbol cache. Only surface this
        // if a download is needed and no usable local bars are available.
        scripResolveError = error;
      }
    }

    final exchange = scrip?.exchange.code ?? 'NSE';
    final candleSymbol = scrip?.symbol ?? symbol;
    var bars = candleDao == null
        ? const <Candle>[]
        : await _cachedBars(
            candleDao,
            exchange: exchange,
            brokerSymbol: candleSymbol,
            displaySymbol: symbol,
          );

    // 3. Missing/short window → one rate-limited daily-candle request for this
    //    stock only. No network when the local cache already covers the results.
    final window = _requiredCandleWindow(dates);
    final source = _candleSource;
    if (dates.isNotEmpty &&
        window != null &&
        candleDao != null &&
        source != null &&
        !_covers(bars, window.$1, window.$2)) {
      if (scrip == null) {
        if (bars.isEmpty) {
          if (scripResolveError != null) {
            throw ResultPlaybookLoadException(
              'Angel One ka scrip master nahi khul paya. Internet check karke '
              'row dobara tap karein. ($scripResolveError)',
            );
          }
          throw ResultPlaybookLoadException(
            'Angel One ke local scrip master me "$symbol" nahi mila. '
            'Settings me scrip master refresh karke phir tap karein.',
          );
        }
      } else {
        try {
          final fetched = await source.fetchDailyCandles(
            scrip: scrip,
            from: window.$1,
            to: window.$2,
          );
          if (fetched.isNotEmpty) {
            try {
              await candleDao.saveBars(
                exchange: exchange,
                symbol: candleSymbol,
                bars: fetched,
              );
              bars = await _cachedBars(
                candleDao,
                exchange: exchange,
                brokerSymbol: candleSymbol,
                displaySymbol: symbol,
              );
            } catch (_) {
              // DB write is a cache optimization: use the fetched bars now.
              bars = _mergeBars(bars, fetched);
            }
          } else if (bars.isEmpty) {
            throw const ResultPlaybookLoadException(
              'Angel One ne is stock ke liye candles nahi bheje. Login, '
              'internet aur scrip master check karke dobara tap karein.',
            );
          }
        } on ApiException catch (error) {
          if (bars.isEmpty) {
            throw ResultPlaybookLoadException(
              error.isAuthError
                  ? 'Candles ke liye Angel One me login zaroori hai. Login '
                        'karke company row dobara tap karein.'
                  : 'Angel One se candles nahi aaye. Internet check karke '
                        'dobara tap karein. (${error.message})',
            );
          }
        } on ResultPlaybookLoadException {
          rethrow;
        } catch (error) {
          if (bars.isEmpty) {
            throw ResultPlaybookLoadException(
              'Candles download nahi hue. Internet check karke dobara tap '
              'karein. ($error)',
            );
          }
        }
      }
    }

    final playbook = buildPlaybook(
      symbol: symbol,
      bars: bars,
      dates: dates,
      candleFrom: bars.isEmpty ? null : bars.first.istDate,
      candleTo: bars.isEmpty ? null : bars.last.istDate,
    );
    _playbooks[symbol] = playbook;
    return playbook;
  }

  /// Read the broker-suffix series first; merge the older plain-symbol cache
  /// too, if one exists (makes old local databases work without a reset).
  Future<List<Candle>> _cachedBars(
    CandleDao dao, {
    required String exchange,
    required String brokerSymbol,
    required String displaySymbol,
  }) async {
    final brokerBars = await dao.barsFor(
      exchange: exchange,
      symbol: brokerSymbol,
    );
    if (brokerSymbol.toUpperCase() == displaySymbol.toUpperCase()) {
      return brokerBars;
    }
    final olderBars = await dao.barsFor(
      exchange: exchange,
      symbol: displaySymbol,
    );
    return _mergeBars(olderBars, brokerBars);
  }

  List<Candle> _mergeBars(List<Candle> first, List<Candle> second) {
    final byTime = <int, Candle>{};
    for (final bar in first) {
      byTime[bar.time.millisecondsSinceEpoch] = bar;
    }
    // Broker-suffix series wins on a duplicate timestamp.
    for (final bar in second) {
      byTime[bar.time.millisecondsSinceEpoch] = bar;
    }
    final merged = byTime.values.toList()
      ..sort((a, b) => a.time.compareTo(b.time));
    return merged;
  }

  (DateTime, DateTime)? _requiredCandleWindow(List<ResultStamp> dates) {
    if (dates.isEmpty) return null;
    final targetDays = dates
        .map((stamp) => _dateOnly(stamp.reactionDate ?? stamp.date))
        .toList();
    targetDays.sort((a, b) => a.compareTo(b));
    final first = targetDays.first.subtract(const Duration(days: 14));
    final last = targetDays.last.add(const Duration(days: 14));
    final today = _dateOnly(_now());
    final end = last.isAfter(today) ? today : last;
    if (end.isBefore(first)) return null;
    return (
      DateTime(first.year, first.month, first.day, 9, 15),
      DateTime(end.year, end.month, end.day, 15, 30),
    );
  }

  bool _covers(List<Candle> bars, DateTime from, DateTime to) {
    if (bars.isEmpty) return false;
    // Candle windows start/end on trading days, not weekends/holidays; 5 days
    // of grace still leaves enough room for the 5-session run-up + next day.
    final fromGrace = _dateOnly(from).add(const Duration(days: 5));
    final toGrace = _dateOnly(to).subtract(const Duration(days: 5));
    return !bars.first.istDate.isAfter(fromGrace) &&
        !bars.last.istDate.isBefore(toGrace);
  }

  DateTime _dateOnly(DateTime date) =>
      DateTime(date.year, date.month, date.day);

  /// Refresh ke baad purane playbook fenk do — itihaas badal sakta hai.
  void clearPlaybooks() {
    _playbooks.clear();
  }

  // ---- actions -----------------------------------------------------------

  /// Opening the page: universe + whatever the cache (or today's NSE fetch)
  /// holds. Never blocks the UI thread on NSE more than once a day.
  Future<void> bootstrap() => _load(force: false);

  /// Pull-to-refresh / button: asks NSE again and rewrites the cache.
  Future<void> refresh() => _load(force: true);

  Future<void> _load({required bool force}) async {
    if (_loading) return;
    _loading = true;
    notifyListeners();
    _note = null;

    try {
      _fno ??= await FnoUniverse.load();
      _calendar = await _earnings.load(force: force);
      // A warning line is shown when the fetch failed — and also when the page
      // has no dates at all, so it can never sit there blank and silent.
      final empty = _calendar?.isEmpty ?? true;
      _note = _earnings.lastFetchFailed || empty
          ? (_earnings.note ??
                'NSE se data abhi nahi aaya. "Dubara try karo" dabao.')
          : null;
    } catch (e) {
      _note = force
          ? 'NSE se refresh nahi hua ($e). Purani list dikhayi ja rahi hai.'
          : 'Results calendar load nahi hua ($e).';
    } finally {
      _loading = false;
      _loaded = true;
      _attemptedAt = _now();
      _rowsMemo = null;
      _playbooks.clear(); // NSE se naya itihaas aa sakta hai
      notifyListeners();
    }
  }

  void setQuery(String value) {
    if (_query == value) return;
    _query = value;
    notifyListeners();
  }

  void setFilter(ResultsFilter value) {
    if (_filter == value) return;
    _filter = value;
    notifyListeners();
  }
}
