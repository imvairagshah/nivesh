// ---------------------------------------------------------------------------
// extremes_service.dart — 1.5.90 data plumbing for the extremes screen.
//
// Flow (user-approved):
//   1. Universe = F&O scanner list (`FnoUniverse`, ~180 stocks).
//   2. 52W high/low — daily candles. Pehle phone ke cache (CandleDao) se,
//      warna broker se (official) aur cache me save.
//   3. Filter — sirf wo stocks jo 52W high/low ke **5%** ke andar (3/5/10%
//      se badla ja sakta hai).
//   4. ATH/ATL — sirf un filtered stocks ke liye, saal-dar-saal chunk karke
//      (Angel ek call me ~1 saal deta hai). Cache me save, isliye dobara fast.
//   5. Dividend — NSE official event calendar (ex-date + amount) + corporate
//      announcements (declaration date). Sirf naye/upcoming.
//
// Sequential + progressive: `onProgress` har stock par call hota hai, UI rows
// stream karti dikhti hai. Cancel support.
// ---------------------------------------------------------------------------

import '../../../core/utils/markets.dart';
import '../../../data/local/dao/candle_dao.dart';
import '../../../data/remote/dto/candle.dart';
import '../../../data/remote/dto/scrip.dart';
import '../../../services/earnings_calendar_service.dart';
import '../../../services/fno_universe.dart';
import '../../../services/market_data_service.dart';
import '../../../services/scrip_master_service.dart';
import 'extremes_engine.dart';

/// Ek scan ka poora result + gaps.
class ExtremesResult {
  const ExtremesResult({
    required this.tradeDate,
    required this.scanned,
    required this.failed,
    required this.all,
    required this.near,
    required this.dividends,
    this.athPending = const [],
    this.athLoaded = 0,
    this.dividendNote,
  });

  final DateTime tradeDate;

  /// Kitne stocks ki 52W ban gayi.
  final int scanned;

  /// Jinki history nahi mili (honest gap).
  final List<String> failed;

  /// Saare scanned stocks (52W ke saath).
  final List<StockExtreme> all;

  /// Filter ke andar wale (sorted: sabse nazdeek pehle).
  final List<StockExtreme> near;

  /// Symbol → dividend (naya/upcoming).
  final Map<String, DividendEvent> dividends;

  /// Jinke ATH abhi load ho rahe hain (UI progress).
  final List<String> athPending;
  final int athLoaded;

  final String? dividendNote;

  ExtremesResult copyWith({
    List<StockExtreme>? near,
    List<StockExtreme>? all,
    List<String>? athPending,
    int? athLoaded,
    Map<String, DividendEvent>? dividends,
    String? dividendNote,
  }) =>
      ExtremesResult(
        tradeDate: tradeDate,
        scanned: scanned,
        failed: failed,
        all: all ?? this.all,
        near: near ?? this.near,
        dividends: dividends ?? this.dividends,
        athPending: athPending ?? this.athPending,
        athLoaded: athLoaded ?? this.athLoaded,
        dividendNote: dividendNote ?? this.dividendNote,
      );
}

class ExtremesService {
  ExtremesService({
    required MarketDataService marketData,
    required CandleDao candles,
    required ScripMasterService scripMaster,
    Future<String> Function(Uri uri)? nseGet,
    FnoUniverse? universe,
    DateTime Function()? clock,
  })  : _marketData = marketData,
        _candles = candles,
        _scripMaster = scripMaster,
        _nseGet = nseGet,
        _universe = universe,
        _clock = clock ?? MarketCalendar.nowIst;

  final MarketDataService _marketData;
  final CandleDao _candles;
  final ScripMasterService _scripMaster;
  final Future<String> Function(Uri uri)? _nseGet;
  final FnoUniverse? _universe;
  final DateTime Function() _clock;

  /// ATH ke liye kitne saal peeche jayein (Angel ~1 saal per call).
  static const int athYears = 15;

  /// ATH sirf itne stocks ke liye (proximity wale) — warna 180 × 15 calls.
  static const int athMaxSymbols = 30;

  /// 52W ke liye minimum bars.
  static const int minBars = 60;

  /// Cache purana ho to dobara fetch (calendar din).
  static const int staleAfterDays = 5;

  bool _cancelled = false;
  void cancel() => _cancelled = true;

  Future<ExtremesResult> scan({
    double withinPct = 5,
    void Function(String stage, int done, int total)? onProgress,
    void Function(ExtremesResult partial)? onPartial,
    bool loadAth = true,
    bool loadDividends = true,
  }) async {
    _cancelled = false;
    final now = _clock();
    final today = DateTime(now.year, now.month, now.day);

    final universe = _universe ?? await FnoUniverse.load();
    final symbols = universe.symbols;
    final resolver = await _scripMaster.resolver();

    final all = <StockExtreme>[];
    final failed = <String>[];

    // ---- 1 + 2: 52W ----
    for (var i = 0; i < symbols.length; i++) {
      if (_cancelled) break;
      final symbol = symbols[i];
      onProgress?.call('52W highs/lows', i + 1, symbols.length);
      try {
        final scrip = resolver
            .resolve(symbol, preferredExchange: Exchange.nse)
            .scrip;
        if (scrip == null) {
          failed.add('$symbol — token nahi mila');
          continue;
        }
        final bars = await _barsFor(scrip, today);
        if (bars.length < minBars || bars.length < 20) {
          failed.add('$symbol — kaafi history nahi (${bars.length} bars)');
          continue;
        }
        final close = bars.last.close;
        final w52 = Extremes.week52(bars, asOf: today);
        if (w52 == null) {
          failed.add('$symbol — 52W calculate nahi hui');
          continue;
        }
        all.add(StockExtreme(
          symbol: symbol,
          companyName: universe.companyNames[symbol] ?? '',
          close: close,
          high52: w52.high,
          low52: w52.low,
        ));
      } catch (e) {
        failed.add('$symbol — ${_short(e)}');
      }
    }

    var near = Extremes.near52(all, withinPct: withinPct);
    var result = ExtremesResult(
      tradeDate: today,
      scanned: all.length,
      failed: failed,
      all: all,
      near: near,
      dividends: const {},
    );
    onPartial?.call(result);
    if (_cancelled) return result;

    // ---- dividend (independent, fast) ----
    if (loadDividends && _nseGet != null) {
      try {
        final divs = await _loadDividends(symbols.toSet(), today);
        result = result.copyWith(
          dividends: divs,
          dividendNote: divs.isEmpty
              ? 'NSE par abhi koi naya dividend declaration nahi mila.'
              : null,
        );
        onPartial?.call(result);
      } catch (e) {
        result = result.copyWith(
            dividendNote: 'Dividend source fail: ${_short(e)}');
        onPartial?.call(result);
      }
    }

    // ---- ATH/ATL: sirf proximity wale (max 30) ----
    if (loadAth) {
      final targets = near.take(athMaxSymbols).toList();
      var loaded = 0;
      final pending = targets.map((e) => e.symbol).toList();
      result = result.copyWith(athPending: pending, athLoaded: 0);
      onPartial?.call(result);

      for (final target in targets) {
        if (_cancelled) break;
        onProgress?.call(
            'ATH/ATL ${target.symbol}', loaded + 1, targets.length);
        try {
          final scrip = resolver
              .resolve(target.symbol, preferredExchange: Exchange.nse)
              .scrip;
          if (scrip == null) {
            loaded++;
            continue;
          }
          final history = await _fullHistory(scrip, today);
          final allTime = Extremes.allTime(history);
          if (allTime != null) {
            final updated = target.copyWith(
              ath: allTime.high,
              athDate: allTime.highDate,
              atl: allTime.low,
              atlDate: allTime.lowDate,
            );
            final idx = near.indexWhere((e) => e.symbol == target.symbol);
            if (idx >= 0) near[idx] = updated;
            final allIdx = result.all.indexWhere((e) => e.symbol == target.symbol);
            final allList = [...result.all];
            if (allIdx >= 0) allList[allIdx] = updated;
            result = result.copyWith(all: allList);
          }
        } catch (_) {}
        loaded++;
        pending.remove(target.symbol);
        result = result.copyWith(
          near: near,
          athPending: [...pending],
          athLoaded: loaded,
        );
        onPartial?.call(result);
      }
      result = result.copyWith(athPending: const []);
      onPartial?.call(result);
    }

    return result;
  }

  // ------------------------------------------------------------------ data

  /// Daily bars — cache pehle, zaroorat par broker se + cache save.
  Future<List<Candle>> _barsFor(Scrip scrip, DateTime today) async {
    final cached = await _candles.barsFor(
      exchange: scrip.exchange.code,
      symbol: scrip.symbol,
      from: today.subtract(const Duration(days: 430)),
      to: today,
    );
    final fresh = cached.isNotEmpty &&
        today.difference(_day(cached.last)).inDays <= staleAfterDays;
    if (cached.length >= minBars && fresh) return cached;

    try {
      final fetched = await _marketData.fetchDailyCandlesLookback(
        scrip: scrip,
        days: 400,
        until: today,
      );
      if (fetched.isNotEmpty) {
        await _candles.saveBars(
          exchange: scrip.exchange.code,
          symbol: scrip.symbol,
          bars: fetched,
          replaceWindow: true,
          windowFrom: today.subtract(const Duration(days: 430)),
          windowTo: today,
        );
      }
      if (fetched.length >= cached.length) return fetched;
    } catch (_) {
      // Network fail — jo cache hai wahi use karo (honest, purana ho to UI
      // trade date se pata chalta hai).
    }
    return cached;
  }

  /// Poora itihaas (saal-dar-saal chunk) — cache + broker. `athYears` tak.
  Future<List<Candle>> _fullHistory(Scrip scrip, DateTime today) async {
    final byDay = <int, Candle>{};
    void addAll(Iterable<Candle> bars) {
      for (final b in bars) {
        byDay[_day(b).millisecondsSinceEpoch] = b;
      }
    }

    final oldest =
        DateTime(today.year - athYears, today.month, today.day);
    addAll(await _candles.barsFor(
      exchange: scrip.exchange.code,
      symbol: scrip.symbol,
      from: oldest,
      to: today,
    ));

    // Chalta hua saal — 1 call (cache ke saath overlap theek hai).
    addAll(await _marketData.fetchDailyCandlesLookback(
      scrip: scrip,
      days: 400,
      until: today,
    ));

    // Pichhle saal — ek-ek chunk, par cache me pehle se ho to skip.
    for (var y = 1; y < athYears; y++) {
      if (_cancelled) break;
      final end = DateTime(today.year - y, today.month, today.day);
      final start = DateTime(today.year - y - 1, today.month, today.day);
      final have = byDay.keys.where((k) {
        final d = DateTime.fromMillisecondsSinceEpoch(k);
        return !d.isBefore(start) && !d.isAfter(end);
      }).length;
      if (have > 180) continue; // ye saal cache me poora hai
      try {
        final bars = await _marketData.fetchDailyCandles(
          scrip: scrip,
          from: DateTime(start.year, start.month, start.day, 9, 15),
          to: DateTime(end.year, end.month, end.day, 15, 30),
        );
        if (bars.isNotEmpty) {
          addAll(bars);
          await _candles.saveBars(
            exchange: scrip.exchange.code,
            symbol: scrip.symbol,
            bars: bars,
          );
        }
      } catch (_) {
        // Is saal ka data nahi mila — ATH "jitna itihaas mila" par based hoga.
      }
    }

    final list = byDay.values.toList()
      ..sort((a, b) => a.time.compareTo(b.time));
    return list;
  }

  Future<Map<String, DividendEvent>> _loadDividends(
      Set<String> universe, DateTime today) async {
    final get = _nseGet!;
    final from = _d(today.subtract(const Duration(days: 45)));
    final to = _d(today.add(const Duration(days: 75)));

    var events = <DividendEvent>[];
    var announcements = <DividendEvent>[];

    try {
      final body = await get(Uri.parse(
          'https://www.nseindia.com/api/event-calendar?index=equities'
          '&from_date=$from&to_date=$to'));
      events = Extremes.parseEventCalendar(body);
    } catch (_) {}

    try {
      final body = await get(Uri.parse(
          'https://www.nseindia.com/api/corporate-announcements?index=equities'
          '&from_date=$from&to=$to'));
      announcements = Extremes.parseDividendAnnouncements(body);
    } catch (_) {}

    return Extremes.mergeDividends(
      events: events,
      announcements: announcements,
      universe: universe,
      asOf: today,
    );
  }

  static String _d(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}-'
      '${d.month.toString().padLeft(2, '0')}-${d.year}';

  static DateTime _day(Candle b) {
    final ist = b.time.toUtc().add(const Duration(hours: 5, minutes: 30));
    return DateTime(ist.year, ist.month, ist.day);
  }

  static String _short(Object e) {
    final text = '$e';
    return text.length > 60 ? '${text.substring(0, 60)}…' : text;
  }
}

/// Production wiring — NseHttp (cookie warm-up) ka same client.
Future<String> Function(Uri) nseExtremesGet() {
  final http = NseHttp();
  return http.get;
}
