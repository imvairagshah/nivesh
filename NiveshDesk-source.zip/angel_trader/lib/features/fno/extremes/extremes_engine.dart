// ---------------------------------------------------------------------------
// extremes_engine.dart — 1.5.90 "52W / All-Time Extremes + Dividends".
//
// Rule (user): table me **sirf wahi stocks** jo 52-week high ya low ke
// **5% ke andar** hain (filter 3/5/10% se badla ja sakta hai), aur "kitna
// door hai" percentage me dikhta hai.
//
// Data:
//   • 52W high/low — daily candles (pichhle 365 din), broker official.
//   • ATH/ATL      — same series ka poora itihaas (saal-dar-saal chunked,
//                    sirf proximity wale stocks ke liye — 180 stocks ka
//                    full history practical nahi).
//   • Dividend     — NSE official **event calendar** (ex-date + amount) aur
//                    **corporate announcements** (declaration date). Sirf
//                    **naye / aane wale** — past history nahi (user).
//
// Sab calculations pure hain — hamesha se pehle brackets me, koi guess nahi.
// ---------------------------------------------------------------------------

import 'dart:convert';

import '../../../data/remote/dto/candle.dart';

/// Ek symbol ka extreme snapshot (kuch fields baad me bhar sakti hain).
class StockExtreme {
  const StockExtreme({
    required this.symbol,
    this.companyName = '',
    this.close = 0,
    this.high52,
    this.low52,
    this.ath,
    this.athDate,
    this.atl,
    this.atlDate,
    this.dividend,
    this.note,
  });

  final String symbol;
  final String companyName;

  /// Aaj ka close/LTP (last candle).
  final double close;

  final double? high52;
  final double? low52;

  final double? ath;
  final DateTime? athDate;
  final double? atl;
  final DateTime? atlDate;

  final DividendEvent? dividend;

  /// Data gap ka honest reason (e.g. "history nahi mili").
  final String? note;

  double? get distToHigh52Pct => high52 == null || high52! <= 0 || close <= 0
      ? null
      : (high52! - close) / high52! * 100;

  double? get distToLow52Pct => low52 == null || low52! <= 0 || close <= 0
      ? null
      : (close - low52!) / low52! * 100;

  double? get distToAthPct => ath == null || ath! <= 0 || close <= 0
      ? null
      : (ath! - close) / ath! * 100;

  double? get distToAtlPct => atl == null || atl! <= 0 || close <= 0
      ? null
      : (close - atl!) / atl! * 100;

  /// `true` = 52W high ke [withinPct] % ke andar.
  bool nearHigh52(double withinPct) {
    final d = distToHigh52Pct;
    return d != null && d.abs() <= withinPct;
  }

  bool nearLow52(double withinPct) {
    final d = distToLow52Pct;
    return d != null && d.abs() <= withinPct;
  }

  /// Filter rule: high ya low — kisi ke bhi 5% ke andar.
  bool nearAny52(double withinPct) =>
      nearHigh52(withinPct) || nearLow52(withinPct);

  /// `true` = all-time high ke [withinPct] % ke andar.
  bool nearAthHigh(double withinPct) {
    final d = distToAthPct;
    return d != null && d.abs() <= withinPct;
  }

  bool nearAthLow(double withinPct) {
    final d = distToAtlPct;
    return d != null && d.abs() <= withinPct;
  }

  /// ATH ka wahi niyam: all-time high ya low — kisi ke bhi [withinPct] % me.
  bool nearAnyAth(double withinPct) =>
      nearAthHigh(withinPct) || nearAthLow(withinPct);

  StockExtreme copyWith({
    double? close,
    double? high52,
    double? low52,
    double? ath,
    DateTime? athDate,
    double? atl,
    DateTime? atlDate,
    DividendEvent? dividend,
    String? note,
  }) => StockExtreme(
    symbol: symbol,
    companyName: companyName,
    close: close ?? this.close,
    high52: high52 ?? this.high52,
    low52: low52 ?? this.low52,
    ath: ath ?? this.ath,
    athDate: athDate ?? this.athDate,
    atl: atl ?? this.atl,
    atlDate: atlDate ?? this.atlDate,
    dividend: dividend ?? this.dividend,
    note: note ?? this.note,
  );
}

/// NSE se aaya dividend event — sirf naya/upcoming (user: past history nahi).
class DividendEvent {
  const DividendEvent({
    required this.symbol,
    required this.amountPerShare,
    this.exDate,
    this.announcedDate,
    this.purpose = '',
  });

  final String symbol;

  /// ₹ per share (purpose text se parse; 0 = amount nahi mila).
  final double amountPerShare;

  /// Ex-dividend date (event calendar) — future ya recent.
  final DateTime? exDate;

  /// Declaration/announcement date (corporate announcements).
  final DateTime? announcedDate;

  final String purpose;

  /// Price ka kitna % (user's ask) — close 0 ho to null.
  double? pctOfPrice(double close) =>
      close <= 0 || amountPerShare <= 0 ? null : amountPerShare / close * 100;

  /// Kaunsa date "kab" ke liye dikhayein — ex-date pehle, warna announcement.
  DateTime? get primaryDate => exDate ?? announcedDate;
}

/// Ek symbol ka 52W + all-time high/low.
class ExtremeRange {
  const ExtremeRange({
    required this.high,
    required this.low,
    this.highDate,
    this.lowDate,
  });
  final double high;
  final double low;
  final DateTime? highDate;
  final DateTime? lowDate;
}

class Extremes {
  Extremes._();

  /// 52-week (pichhle 365 din) high/low — sirf us window ke bars se.
  static ExtremeRange? week52(
    List<Candle> bars, {
    required DateTime asOf,
    int days = 365,
  }) {
    if (bars.isEmpty) return null;
    final cutoff = DateTime(
      asOf.year,
      asOf.month,
      asOf.day,
    ).subtract(Duration(days: days));
    var hi = double.negativeInfinity;
    var lo = double.infinity;
    DateTime? hiDate;
    DateTime? loDate;
    var any = false;
    for (final b in bars) {
      final day = _day(b);
      if (day.isBefore(cutoff)) continue;
      any = true;
      if (b.high > hi) {
        hi = b.high;
        hiDate = day;
      }
      if (b.low < lo && b.low > 0) {
        lo = b.low;
        loDate = day;
      }
    }
    if (!any || hi <= 0 || lo == double.infinity) return null;
    return ExtremeRange(high: hi, low: lo, highDate: hiDate, lowDate: loDate);
  }

  /// All-time high/low — jo bars diye gaye hain unme se (jitna itihaas
  /// available hai utna hi — isliye caller chapter/chunk karke poora itihaas
  /// deta hai, aur UI "history se" label dikhata hai).
  static ExtremeRange? allTime(List<Candle> bars) {
    if (bars.isEmpty) return null;
    var hi = double.negativeInfinity;
    var lo = double.infinity;
    DateTime? hiDate;
    DateTime? loDate;
    for (final b in bars) {
      if (b.high > hi) {
        hi = b.high;
        hiDate = _day(b);
      }
      if (b.low < lo && b.low > 0) {
        lo = b.low;
        loDate = _day(b);
      }
    }
    if (hi <= 0 || lo == double.infinity) return null;
    return ExtremeRange(high: hi, low: lo, highDate: hiDate, lowDate: loDate);
  }

  static DateTime _day(Candle b) {
    final ist = b.time.toUtc().add(const Duration(hours: 5, minutes: 30));
    return DateTime(ist.year, ist.month, ist.day);
  }

  /// Filter + sort: sirf 52W ke 5% ke andar wale, sabse pehle nazdeek.
  static List<StockExtreme> near52(
    Iterable<StockExtreme> all, {
    double withinPct = 5,
  }) {
    final list = all.where((e) => e.nearAny52(withinPct)).toList();
    list.sort((a, b) {
      final da = _minDist(a);
      final db = _minDist(b);
      return da.compareTo(db);
    });
    return list;
  }

  static double _minDist(StockExtreme e) {
    final h = e.distToHigh52Pct?.abs() ?? double.infinity;
    final l = e.distToLow52Pct?.abs() ?? double.infinity;
    return h < l ? h : l;
  }

  /// 1.5.94 — "Sabhi stocks" view ke liye: saare scanned stocks, par tarteeb
  /// wahi (jo high/low ke sabse nazdeek hai wo pehle). Distance na ho to last.
  static List<StockExtreme> byProximity52(Iterable<StockExtreme> all) {
    final list = all.toList();
    list.sort((a, b) => _minDist(a).compareTo(_minDist(b)));
    return list;
  }

  /// All-time high/low ka wahi niyam: sirf wo stocks jo APNE ATH **ya** ATL ke
  /// [withinPct] % ke andar hain, sabse nazdeek pehle. ATH load na hua ho to
  /// wo row is list me nahi aati (honest — andaza nahi).
  static List<StockExtreme> nearAth(
    Iterable<StockExtreme> all, {
    double withinPct = 5,
  }) {
    final list = all.where((e) => e.nearAnyAth(withinPct)).toList();
    list.sort((a, b) => _minDistAth(a).compareTo(_minDistAth(b)));
    return list;
  }

  /// "Sabhi stocks" (ATH tab) — sirf jinka ATH load hua hai, tarteeb close se.
  static List<StockExtreme> byProximityAth(Iterable<StockExtreme> all) {
    final list = all.where((e) => e.ath != null || e.atl != null).toList();
    list.sort((a, b) => _minDistAth(a).compareTo(_minDistAth(b)));
    return list;
  }

  static double _minDistAth(StockExtreme e) {
    final h = e.distToAthPct?.abs() ?? double.infinity;
    final l = e.distToAtlPct?.abs() ?? double.infinity;
    return h < l ? h : l;
  }

  // -------------------------------------------------------------------------
  // NSE dividend parsing (pure)
  // -------------------------------------------------------------------------

  static final RegExp _rsAmount = RegExp(
    r'(?:rs\.?|inr|₹)\s*([0-9]+(?:\.[0-9]+)?)',
    caseSensitive: false,
  );

  /// `"Annual General Meeting/Dividend - Rs 5 Per Share"` → 5.0
  static double parseDividendAmount(String purpose) {
    final text = purpose.trim();
    if (text.isEmpty) return 0;
    final m = _rsAmount.firstMatch(text);
    if (m != null) return double.tryParse(m.group(1)!) ?? 0;
    // "- 5 Per Share" style (no Rs prefix)
    final m2 = RegExp(
      r'([0-9]+(?:\.[0-9]+)?)\s*per\s*share',
      caseSensitive: false,
    ).firstMatch(text);
    if (m2 != null) return double.tryParse(m2.group(1)!) ?? 0;
    return 0;
  }

  static DateTime? parseNseDate(String raw) {
    final text = raw.trim();
    if (text.isEmpty) return null;
    // "26-Nov-2026" / "26-11-2026" / "2026-11-26 00:00:00"
    final iso = DateTime.tryParse(text);
    if (iso != null) return DateTime(iso.year, iso.month, iso.day);
    final m = RegExp(r'^(\d{1,2})[-/](\d{1,2})[-/](\d{4})').firstMatch(text);
    if (m != null) {
      return DateTime(
        int.parse(m.group(3)!),
        int.parse(m.group(2)!),
        int.parse(m.group(1)!),
      );
    }
    final m2 = RegExp(r'^(\d{1,2})-([A-Za-z]{3})-(\d{4})').firstMatch(text);
    if (m2 != null) {
      final mon = _months.indexWhere((x) => x == m2.group(2)!.toUpperCase());
      if (mon >= 0) {
        return DateTime(
          int.parse(m2.group(3)!),
          mon + 1,
          int.parse(m2.group(1)!),
        );
      }
    }
    return null;
  }

  static const List<String> _months = [
    'JAN',
    'FEB',
    'MAR',
    'APR',
    'MAY',
    'JUN',
    'JUL',
    'AUG',
    'SEP',
    'OCT',
    'NOV',
    'DEC',
  ];

  static String _field(Map<String, dynamic> m, List<String> keys) {
    for (final k in keys) {
      for (final e in m.entries) {
        if (e.key.toLowerCase() == k.toLowerCase()) {
          return '${e.value ?? ''}'.trim();
        }
      }
    }
    return '';
  }

  /// NSE `event-calendar` JSON → dividend events (jinke ex-date hain).
  /// Row shape: `{symbol, company, purpose, bm_desc, exDate, recDate, …}`.
  static List<DividendEvent> parseEventCalendar(String jsonText) {
    final rows = _decodeList(jsonText);
    final out = <DividendEvent>[];
    for (final row in rows) {
      final symbol = _field(row, ['symbol']).toUpperCase();
      if (symbol.isEmpty) continue;
      final purpose = _field(row, ['purpose', 'subject', 'desc', 'bm_purpose']);
      if (!purpose.toUpperCase().contains('DIVIDEND')) continue;
      final amount = parseDividendAmount(purpose);
      final exDate = parseNseDate(_field(row, ['exDate', 'ex_date']));
      final recDate = parseNseDate(_field(row, ['recDate', 'recordDate']));
      out.add(
        DividendEvent(
          symbol: symbol,
          amountPerShare: amount,
          exDate: exDate ?? recDate,
          announcedDate: parseNseDate(_field(row, ['bm_desc', 'an_dt'])),
          purpose: purpose,
        ),
      );
    }
    return out;
  }

  /// NSE `corporate-announcements` JSON → dividend **declarations**
  /// (`subject` has "Dividend"; `an_dt` = announcement date).
  static List<DividendEvent> parseDividendAnnouncements(String jsonText) {
    final rows = _decodeList(jsonText);
    final out = <DividendEvent>[];
    for (final row in rows) {
      final symbol = _field(row, ['symbol']).toUpperCase();
      final subject = _field(row, ['subject', 'desc']);
      if (symbol.isEmpty || !subject.toUpperCase().contains('DIVIDEND')) {
        continue;
      }
      out.add(
        DividendEvent(
          symbol: symbol,
          amountPerShare: parseDividendAmount(subject),
          announcedDate: parseNseDate(_field(row, ['an_dt', 'date'])),
          purpose: subject,
        ),
      );
    }
    return out;
  }

  /// Dividend rows screen ke liye: symbol ke hisaab se sort (ex-date pehle,
  /// phir declaration date), optional proximity filter. Pure — testable.
  /// 1.5.94 — sirf **aane wale** dividends. Jis stock ka dividend aane wala
  /// nahi hai, uska naam hi table me nahi aana chahiye (user rule).
  ///
  /// Rule: ex-date aaj ya aage ho → rakho. Ex-date pata nahi par declaration
  /// pichhle [declaredGraceDays] din me aayi ho (naya elaan, ex-date TBA) →
  /// rakho. Baaki sab hatao (purane / beet chuke).
  static Map<String, DividendEvent> upcomingDividends(
    Map<String, DividendEvent> dividends, {
    DateTime? asOf,
    int declaredGraceDays = 7,
  }) {
    final now = asOf ?? DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final graceStart = today.subtract(Duration(days: declaredGraceDays));

    final out = <String, DividendEvent>{};
    for (final entry in dividends.entries) {
      final ex = entry.value.exDate;
      if (ex != null) {
        final exDay = DateTime(ex.year, ex.month, ex.day);
        if (!exDay.isBefore(today)) out[entry.key] = entry.value;
        continue;
      }
      final announced = entry.value.announcedDate;
      if (announced != null) {
        final day = DateTime(announced.year, announced.month, announced.day);
        if (!day.isBefore(graceStart)) out[entry.key] = entry.value;
      }
    }
    return out;
  }

  static List<MapEntry<String, DividendEvent>> sortedDividends(
    Map<String, DividendEvent> dividends, {
    Set<String>? onlySymbols,
  }) {
    final rows = [
      for (final e in dividends.entries)
        if (onlySymbols == null || onlySymbols.contains(e.key)) e,
    ];
    rows.sort((a, b) {
      final da = a.value.primaryDate;
      final db = b.value.primaryDate;
      if (da == null && db == null) return a.key.compareTo(b.key);
      if (da == null) return 1;
      if (db == null) return -1;
      return da.compareTo(db);
    });
    return rows;
  }

  static List<Map<String, dynamic>> _decodeList(String jsonText) {
    try {
      final decoded = jsonText.trim();
      if (decoded.isEmpty) return const [];
      final dynamic parsed = jsonDecode(decoded);
      final List<dynamic> list = parsed is Map
          ? (parsed['data'] is List ? parsed['data'] as List : const [])
          : (parsed is List ? parsed : const []);
      return [
        for (final r in list)
          if (r is Map) r.map((k, v) => MapEntry('$k', v)),
      ];
    } catch (_) {
      return const [];
    }
  }

  /// NSE dividend rows ko symbol ke hisaab se merge karo:
  /// event-calendar se amount/ex-date, announcements se declaration date.
  static Map<String, DividendEvent> mergeDividends({
    required List<DividendEvent> events,
    required List<DividendEvent> announcements,
    Set<String>? universe,
    DateTime? asOf,
  }) {
    final bySymbol = <String, DividendEvent>{};
    final now = asOf ?? DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    for (final e in events) {
      if (universe != null && !universe.contains(e.symbol)) continue;
      // Sirf aane wale / haal ke (past itihaas nahi — user).
      final d = e.primaryDate;
      if (d != null && d.isBefore(today.subtract(const Duration(days: 30)))) {
        continue;
      }
      bySymbol[e.symbol] = e;
    }

    for (final a in announcements) {
      if (universe != null && !universe.contains(a.symbol)) continue;
      final d = a.announcedDate;
      if (d != null && d.isBefore(today.subtract(const Duration(days: 45)))) {
        continue; // purani khabar
      }
      final existing = bySymbol[a.symbol];
      if (existing == null) {
        bySymbol[a.symbol] = a;
      } else {
        bySymbol[a.symbol] = DividendEvent(
          symbol: a.symbol,
          amountPerShare: existing.amountPerShare > 0
              ? existing.amountPerShare
              : a.amountPerShare,
          exDate: existing.exDate,
          announcedDate: a.announcedDate ?? existing.announcedDate,
          purpose: existing.purpose.isNotEmpty ? existing.purpose : a.purpose,
        );
      }
    }
    return bySymbol;
  }
}
