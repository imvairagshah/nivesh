// ---------------------------------------------------------------------------
// extremes_screen.dart — 1.5.90 "52W / All-Time Extremes + Dividends".
//
// Teen alag tables (tabs):
//   1. 📈 52-Week High/Low — sirf wo stocks jo 52W high ya low ke 5% ke andar
//      hain, aur "kitna door hai" % me.
//   2. 🏔️ All-Time High/Low — wahi proximity wale stocks, ATH/ATL + date.
//   3. 💰 Dividends — sirf **naye / aane wale** declarations (past history
//      nahi), amount + price ka % + date.
//
// Filter chips (3% / 5% / 10%) se proximity badalti hai. Scan progressive
// hai: rows aate jate dikhte hain, ATH sirf proximity wale stocks ka load
// hota hai (official Angel history, saal-dar-saal chunked + cached).
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../core/widgets/page_scroll.dart';

import '../../../core/layout/desktop_layout.dart';
import '../../../core/utils/share_helper.dart';
import 'extremes_engine.dart';
import 'extremes_service.dart';

class ExtremesScreen extends StatefulWidget {
  const ExtremesScreen({super.key, required this.service});
  final ExtremesService service;

  @override
  State<ExtremesScreen> createState() => _ExtremesScreenState();
}

class _ExtremesScreenState extends State<ExtremesScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs = TabController(length: 3, vsync: this);

  ExtremesResult? _result;
  bool _scanning = true;
  String _stage = 'Shuru ho raha hai…';
  int _done = 0;
  int _total = 0;
  double _withinPct = 5;

  /// 1.5.94 — default sirf 5% ke andar wale. "Sabhi stocks" chip se poora
  /// universe. Dono tabs ka apna switch (52W aur ATH).
  bool _showAll52 = false;
  bool _showAllAth = false;

  @override
  void initState() {
    super.initState();
    _run();
  }

  @override
  void dispose() {
    widget.service.cancel();
    _tabs.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    setState(() {
      _scanning = true;
      _result = null;
      _stage = 'F&O list load ho rahi hai…';
      _done = 0;
      _total = 0;
    });
    try {
      final res = await widget.service.scan(
        withinPct: _withinPct,
        onProgress: (stage, done, total) {
          if (!mounted) return;
          setState(() {
            _stage = stage;
            _done = done;
            _total = total;
          });
        },
        onPartial: (partial) {
          if (!mounted) return;
          setState(() => _result = partial);
        },
      );
      if (!mounted) return;
      setState(() {
        _result = res;
        _scanning = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _scanning = false;
        _stage = 'Scan fail: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final wide = DesktopLayout.isWide(context);
    final res = _result;
    final near = res?.near ?? const <StockExtreme>[];

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          '📈 52W · ATH · Dividend',
          style: TextStyle(fontSize: 15),
        ),
        actions: [
          IconButton(
            tooltip: 'Rescan',
            icon: const Icon(Icons.refresh_rounded),
            onPressed: _scanning ? null : _run,
          ),
          IconButton(
            tooltip: 'Report share',
            icon: const Icon(Icons.share_rounded),
            onPressed: res == null
                ? null
                : () => ShareHelper.shareText(_asText(res)),
          ),
          const SizedBox(width: 4),
        ],
        bottom: TabBar(
          controller: _tabs,
          labelStyle: const TextStyle(
            fontSize: 11.5,
            fontWeight: FontWeight.w700,
          ),
          tabs: const [
            Tab(text: '📈 52-Week'),
            Tab(text: '🏔️ All-Time'),
            Tab(text: '💰 Dividend'),
          ],
        ),
      ),
      // 1.5.94 — PC scroll fix: har tab **ek hi scroll** (PageScroll), usi
      // page me status bar + chips + table — 3-Month Study jaisa. Koi fixed
      // header + andar ki list wala double scroll nahi.
      body: CenteredWidth(
        max: wide ? 1180 : double.infinity,
        child: TabBarView(
          controller: _tabs,
          children: [
            _week52Tab(scheme, near, res),
            _allTimeTab(scheme, near, res),
            _dividendTab(scheme, res, near),
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------------ status

  Widget _statusBar(ColorScheme scheme, {bool showChips = true}) {
    final res = _result;
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              if (_scanning) ...[
                const SizedBox(
                  width: 12,
                  height: 12,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
                const SizedBox(width: 8),
              ],
              Expanded(
                child: Text(
                  _scanning && _total > 0
                      ? '$_stage ($_done/$_total)…'
                      : (res == null
                            ? _stage
                            : '${res.near.length} stocks 52W ke $_withinPct% ke andar · '
                                  '${res.scanned} scan hue · ${_d(res.tradeDate)}'),
                  style: const TextStyle(fontSize: 10.5),
                ),
              ),
              if (showChips)
                for (final pct in [3.0, 5.0, 10.0])
                  Padding(
                    padding: const EdgeInsets.only(left: 4),
                    child: ChoiceChip(
                      label: Text(
                        '${pct.round()}%',
                        style: const TextStyle(fontSize: 9.5),
                      ),
                      selected: _withinPct == pct,
                      visualDensity: VisualDensity.compact,
                      onSelected: (_) {
                        setState(() => _withinPct = pct);
                        if (!_scanning) _run();
                      },
                    ),
                  ),
            ],
          ),
          if (_scanning)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: LinearProgressIndicator(
                value: _total > 0 ? (_done / _total).clamp(0.0, 1.0) : null,
              ),
            ),
        ],
      ),
    );
  }

  // ------------------------------------------------------------- table 1 (52W)

  Widget _week52Tab(
    ColorScheme scheme,
    List<StockExtreme> near,
    ExtremesResult? res,
  ) {
    // 1.5.94 — default: sirf chune hue % (5%) ke andar. "Sabhi stocks" par
    // poora scanned universe, tarteeb wahi (sabse nazdeek pehle).
    final rows = _showAll52 && res != null
        ? Extremes.byProximity52(res.all)
        : near;

    return PageScroll.children(
      padding: const EdgeInsets.fromLTRB(10, 0, 10, 24),
      [
        _statusBar(scheme),
        _scopeRow(
          all: _showAll52,
          onChanged: (v) => setState(() => _showAll52 = v),
          hint: _showAll52
              ? 'Sabhi ${res?.all.length ?? 0} scanned stocks — 52W high/low se '
                    'doori ke hisaab se (sabse nazdeek pehle).'
              : 'Sirf wo stocks jo 52-week high **ya** low ke $_withinPct% ke '
                    'andar hain.',
        ),
        if (rows.isEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 20),
            child: _empty(
              'Koi stock 52W high/low ke $_withinPct% ke andar nahi hai.\n'
              'Upar "Sabhi stocks" chuno to poori list dikhegi.',
            ),
          )
        else
          Card(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
              child: Column(
                children: [
                  _headerRow(scheme, const [
                    ('Stock', 2),
                    ('LTP', 1),
                    ('52W High', 1),
                    ('High se', 1),
                    ('52W Low', 1),
                    ('Low se', 1),
                  ]),
                  const Divider(height: 10),
                  for (final e in rows) _week52Row(scheme, e),
                ],
              ),
            ),
          ),
      ],
    );
  }

  /// "5% ke andar" / "Sabhi stocks" switch — dono tabs (52W + ATH) me same.
  Widget _scopeRow({
    required bool all,
    required ValueChanged<bool> onChanged,
    required String hint,
  }) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(top: 6, bottom: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              ChoiceChip(
                label: Text(
                  'Sirf $_withinPct% ke andar',
                  style: const TextStyle(fontSize: 9.5),
                ),
                selected: !all,
                visualDensity: VisualDensity.compact,
                onSelected: (_) => onChanged(false),
              ),
              const SizedBox(width: 6),
              ChoiceChip(
                label: const Text(
                  'Sabhi stocks',
                  style: TextStyle(fontSize: 9.5),
                ),
                selected: all,
                visualDensity: VisualDensity.compact,
                onSelected: (_) => onChanged(true),
              ),
            ],
          ),
          const SizedBox(height: 6),
          _note(scheme, hint),
        ],
      ),
    );
  }

  Widget _week52Row(ColorScheme scheme, StockExtreme e) {
    final nearHigh = e.nearHigh52(_withinPct);
    final nearLow = e.nearLow52(_withinPct);
    final tag = nearHigh && nearLow
        ? '◆ HIGH+LOW'
        : (nearHigh ? '▲ HIGH' : (nearLow ? '▼ LOW' : '—'));
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  e.symbol,
                  style: const TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text(
                  '${tag}${e.companyName.isEmpty ? '' : ' · ${_short(e.companyName)}'}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 9,
                    color: nearHigh || nearLow
                        ? scheme.primary
                        : scheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          _cell(e.close, money: true),
          _cell(e.high52, money: true),
          _cell(e.distToHigh52Pct, pct: true, mark: nearHigh),
          _cell(e.low52, money: true),
          _cell(e.distToLow52Pct, pct: true, mark: nearLow),
        ],
      ),
    );
  }

  // --------------------------------------------------------- table 2 (all-time)

  Widget _allTimeTab(
    ColorScheme scheme,
    List<StockExtreme> near,
    ExtremesResult? res,
  ) {
    // 1.5.94 — wahi niyam ATH par bhi: default sirf wo stocks jo APNE all-time
    // high **ya** low ke $_withinPct% me hain. "Sabhi stocks" par har wo stock
    // jiska ATH load hua hai.
    final loadedAll = [
      for (final e in (res?.all ?? const <StockExtreme>[]))
        if (e.ath != null || e.atl != null) e,
      // purane partial results me near list me hi ATH hota hai.
      for (final e in near)
        if ((e.ath != null || e.atl != null) &&
            !(res?.all ?? const <StockExtreme>[]).any(
              (x) => x.symbol == e.symbol,
            ))
          e,
    ];
    final rows = _showAllAth
        ? Extremes.byProximityAth(loadedAll)
        : Extremes.nearAth(loadedAll, withinPct: _withinPct);
    final pending = res?.athPending ?? const <String>[];

    return PageScroll.children(
      padding: const EdgeInsets.fromLTRB(10, 0, 10, 24),
      [
        _statusBar(scheme),
        _scopeRow(
          all: _showAllAth,
          onChanged: (v) => setState(() => _showAllAth = v),
          hint: _showAllAth
              ? 'Sabhi stocks jinka ATH load hua (${loadedAll.length}) — '
                    'all-time high/low se doori ke hisaab se.'
              : 'Sirf wo stocks jo all-time high **ya** low ke $_withinPct% ke '
                    'andar hain. ATH/ATL official Angel history se (cache hoti '
                    'hai, pehli baar thoda time lagta hai).',
        ),
        if (pending.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Text(
              '⏳ ATH load ho raha hai: ${res?.athLoaded ?? 0} done · '
              'baaki ${pending.length}',
              style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant),
            ),
          ),
        if (rows.isEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 20),
            child: _empty(
              'Abhi tak koi stock all-time high/low ke $_withinPct% ke andar '
              'nahi hai.\n"Sabhi stocks" chuno to jitne ATH load hue hain wo '
              'dikhenge.',
            ),
          )
        else
          Card(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
              child: Column(
                children: [
                  _headerRow(scheme, const [
                    ('Stock', 2),
                    ('LTP', 1),
                    ('All-time High', 1),
                    ('High se', 1),
                    ('All-time Low', 1),
                    ('Low se', 1),
                  ]),
                  const Divider(height: 10),
                  for (final e in rows) _allTimeRow(scheme, e),
                ],
              ),
            ),
          ),
      ],
    );
  }

  Widget _allTimeRow(ColorScheme scheme, StockExtreme e) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(
      children: [
        Expanded(
          flex: 2,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                e.symbol,
                style: const TextStyle(
                  fontSize: 11.5,
                  fontWeight: FontWeight.w800,
                ),
              ),
              Text(
                'ATH ${_d(e.athDate)}${e.atlDate == null ? '' : ' · ATL ${_d(e.atlDate)}'}',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 8.5, color: scheme.onSurfaceVariant),
              ),
            ],
          ),
        ),
        _cell(e.close, money: true),
        _cell(e.ath, money: true),
        _cell(e.distToAthPct, pct: true, mark: (e.distToAthPct ?? 99) <= 5),
        _cell(e.atl, money: true),
        _cell(e.distToAtlPct, pct: true, mark: (e.distToAtlPct ?? 99) <= 5),
      ],
    ),
  );

  // ----------------------------------------------------------- table 3 (dividend)

  Widget _dividendTab(
    ColorScheme scheme,
    ExtremesResult? res,
    List<StockExtreme> near,
  ) {
    if (res == null) {
      return PageScroll.children(
        padding: const EdgeInsets.fromLTRB(10, 0, 10, 24),
        [
          _statusBar(scheme, showChips: false),
          const SizedBox(height: 24),
          _empty('Scan chal raha hai…'),
        ],
      );
    }

    // 1.5.94 — sirf **aane wale** dividends. Jis stock ka dividend aane wala
    // nahi, uska naam hi nahi. Koi percentage filter nahi — sirf seedha data:
    // stock · ₹/share · price · price ka % · ex-date.
    final bySymbol = <String, StockExtreme>{
      for (final e in res.all) e.symbol: e,
      for (final e in near) e.symbol: e,
    };
    final rows = Extremes.sortedDividends(
      Extremes.upcomingDividends(res.dividends),
    );

    return PageScroll.children(
      padding: const EdgeInsets.fromLTRB(10, 0, 10, 24),
      [
        _statusBar(scheme, showChips: false),
        Padding(
          padding: const EdgeInsets.only(top: 6, bottom: 8),
          child: _note(
            scheme,
            'Sirf **aane wale** dividends — jis stock ka dividend aane wala '
            'nahi hai wo yahan aata hi nahi. NSE event calendar (ex-date + '
            'amount) aur announcements (declaration) se.',
          ),
        ),
        if (res.dividendNote != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Text(
              'ℹ️ ${res.dividendNote}',
              style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant),
            ),
          ),
        if (rows.isEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 20),
            child: _empty(
              'Abhi koi aane wala dividend nahi mila.\nNSE par naya '
              'declaration aane par Rescan dabao.',
            ),
          )
        else
          Card(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
              child: Column(
                children: [
                  _headerRow(scheme, const [
                    ('Stock', 2),
                    ('₹ / share', 1),
                    ('Price', 1),
                    ('Price ka %', 1),
                    ('Ex-date', 1),
                  ]),
                  const Divider(height: 10),
                  for (final entry in rows)
                    _dividendRow(
                      scheme,
                      bySymbol[entry.key] ?? StockExtreme(symbol: entry.key),
                      entry.value,
                    ),
                ],
              ),
            ),
          ),
      ],
    );
  }

  Widget _dividendRow(ColorScheme scheme, StockExtreme e, DividendEvent d) {
    final pct = d.pctOfPrice(e.close);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  e.symbol,
                  style: const TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                if (d.purpose.isNotEmpty)
                  Text(
                    d.purpose,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 8.5,
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
              ],
            ),
          ),
          _textCell(
            d.amountPerShare > 0
                ? '₹${d.amountPerShare.toStringAsFixed(2)}'
                : '—',
          ),
          _textCell(e.close > 0 ? _num(e.close) : '—'),
          _textCell(
            pct == null ? '—' : '${pct.toStringAsFixed(2)}%',
            color: scheme.primary,
            bold: true,
          ),
          _textCell(_d(d.exDate)),
        ],
      ),
    );
  }

  // ------------------------------------------------------------------ pieces

  Widget _headerRow(ColorScheme scheme, List<(String, int)> cols) => Row(
    children: [
      for (final (label, flex) in cols)
        Expanded(
          flex: flex,
          child: Text(
            label,
            textAlign: flex == 2 ? TextAlign.left : TextAlign.right,
            style: TextStyle(
              fontSize: 9,
              fontWeight: FontWeight.w800,
              color: scheme.onSurfaceVariant,
            ),
          ),
        ),
    ],
  );

  Widget _cell(
    double? value, {
    bool money = false,
    bool pct = false,
    bool mark = false,
  }) {
    final scheme = Theme.of(context).colorScheme;
    String text = '—';
    if (value != null && value.isFinite) {
      text = money ? _num(value) : '${value.toStringAsFixed(2)}%';
    }
    return Expanded(
      child: Text(
        text,
        textAlign: TextAlign.right,
        style: TextStyle(
          fontSize: 10.5,
          fontWeight: mark ? FontWeight.w900 : FontWeight.w600,
          color: mark ? scheme.primary : scheme.onSurface,
        ),
      ),
    );
  }

  Widget _textCell(String text, {Color? color, bool bold = false}) => Expanded(
    child: Text(
      text,
      textAlign: TextAlign.right,
      style: TextStyle(
        fontSize: 10,
        fontWeight: bold ? FontWeight.w800 : FontWeight.w500,
        color: color ?? Theme.of(context).colorScheme.onSurface,
      ),
    ),
  );

  Widget _note(ColorScheme scheme, String text) => Text(
    text.replaceAll('**', ''),
    style: TextStyle(
      fontSize: 9.5,
      height: 1.45,
      color: scheme.onSurfaceVariant,
    ),
  );

  Widget _empty(String message) => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Text(
        message,
        textAlign: TextAlign.center,
        style: const TextStyle(fontSize: 12, height: 1.5),
      ),
    ),
  );

  static String _num(double v) {
    if (v >= 100000) return NumberFormat('#,##,##0').format(v.round());
    return v.toStringAsFixed(v >= 100 ? 0 : 2);
  }

  static String _d(DateTime? d) =>
      d == null ? '—' : DateFormat('dd MMM yy').format(d);

  static String _short(String s) =>
      s.length <= 26 ? s : '${s.substring(0, 26)}…';

  String _asText(ExtremesResult res) {
    final b = StringBuffer()
      ..writeln('=== 52W / ATH / Dividend (F&O stocks) ===')
      ..writeln('Trade date: ${_d(res.tradeDate)} · filter: $_withinPct%');
    b.writeln('\n52-WEEK HIGH/LOW (${res.near.length}):');
    for (final e in res.near) {
      b.writeln(
        '• ${e.symbol} — LTP ${_num(e.close)} · 52W H ${_num(e.high52 ?? 0)} '
        '(${e.distToHigh52Pct?.toStringAsFixed(2) ?? '—'}%) · 52W L '
        '${_num(e.low52 ?? 0)} (${e.distToLow52Pct?.toStringAsFixed(2) ?? '—'}%)',
      );
    }
    final withAth = res.near.where((e) => e.ath != null);
    if (withAth.isNotEmpty) {
      b.writeln('\nALL-TIME:');
      for (final e in withAth) {
        b.writeln(
          '• ${e.symbol} — ATH ${_num(e.ath!)} (${_d(e.athDate)}) · '
          'ATL ${_num(e.atl!)} (${_d(e.atlDate)})',
        );
      }
    }
    final divs = Extremes.sortedDividends(
      Extremes.upcomingDividends(res.dividends),
    );
    if (divs.isNotEmpty) {
      b.writeln('\nDIVIDENDS (sirf aane wale):');
      final bySymbol = {for (final e in res.all) e.symbol: e};
      for (final entry in divs) {
        final close = bySymbol[entry.key]?.close ?? 0;
        final pct = entry.value.pctOfPrice(close);
        b.writeln(
          '• ${entry.key} — ₹${entry.value.amountPerShare} · '
          'price ${close > 0 ? _num(close) : '—'} · '
          '${pct == null ? '—' : '${pct.toStringAsFixed(2)}%'} · '
          'ex ${_d(entry.value.exDate)}',
        );
      }
    }
    return b.toString();
  }
}
