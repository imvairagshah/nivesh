// ---------------------------------------------------------------------------
// extremes_screen.dart — 1.5.90 "52W / All-Time Extremes + Dividends".
//
// Teen alag tables (tabs):
//   1. 📈 52-Week High/Low — sirf wo stocks jo 52W high ya low ke 5% ke andar
//      hain, aur "kitna door hai" % me.
//   2. 🏔️ All-Time High/Low — wahi proximity wale stocks, ATH/ATL + date.
//   3. 💰 Dividends — sirf **naye / aane wale** declarations (past history
//      nahi), amount + price ka % + date.
//
// Filter chips (3% / 5% / 10%) se proximity badalti hai. Scan progressive
// hai: rows aate jate dikhte hain, ATH sirf proximity wale stocks ka load
// hota hai (official Angel history, saal-dar-saal chunked + cached).
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../core/layout/desktop_layout.dart';
import '../../../core/utils/share_helper.dart';
import 'extremes_engine.dart';
import 'extremes_service.dart';

class ExtremesScreen extends StatefulWidget {
  const ExtremesScreen({super.key, required this.service});
  final ExtremesService service;

  @override
  State<ExtremesScreen> createState() => _ExtremesScreenState();
}

class _ExtremesScreenState extends State<ExtremesScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs = TabController(length: 3, vsync: this);

  ExtremesResult? _result;
  bool _scanning = true;
  String _stage = 'Shuru ho raha hai…';
  int _done = 0;
  int _total = 0;
  double _withinPct = 5;
  bool _dividendOnlyNear = false;

  @override
  void initState() {
    super.initState();
    _run();
  }

  @override
  void dispose() {
    widget.service.cancel();
    _tabs.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    setState(() {
      _scanning = true;
      _result = null;
      _stage = 'F&O list load ho rahi hai…';
      _done = 0;
      _total = 0;
    });
    try {
      final res = await widget.service.scan(
        withinPct: _withinPct,
        onProgress: (stage, done, total) {
          if (!mounted) return;
          setState(() {
            _stage = stage;
            _done = done;
            _total = total;
          });
        },
        onPartial: (partial) {
          if (!mounted) return;
          setState(() => _result = partial);
        },
      );
      if (!mounted) return;
      setState(() {
        _result = res;
        _scanning = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _scanning = false;
        _stage = 'Scan fail: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final wide = DesktopLayout.isWide(context);
    final res = _result;
    final near = res?.near ?? const <StockExtreme>[];

    return Scaffold(
      appBar: AppBar(
        title: const Text('📈 52W · ATH · Dividend', style: TextStyle(fontSize: 15)),
        actions: [
          IconButton(
            tooltip: 'Rescan',
            icon: const Icon(Icons.refresh_rounded),
            onPressed: _scanning ? null : _run,
          ),
          IconButton(
            tooltip: 'Report share',
            icon: const Icon(Icons.share_rounded),
            onPressed: res == null ? null : () => ShareHelper.shareText(_asText(res)),
          ),
          const SizedBox(width: 4),
        ],
        bottom: TabBar(
          controller: _tabs,
          labelStyle: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700),
          tabs: const [
            Tab(text: '📈 52-Week'),
            Tab(text: '🏔️ All-Time'),
            Tab(text: '💰 Dividend'),
          ],
        ),
      ),
      body: CenteredWidth(
        max: wide ? 1180 : double.infinity,
        child: Column(
          children: [
            _statusBar(scheme),
            Expanded(
              child: TabBarView(
                controller: _tabs,
                children: [
                  _week52Tab(scheme, near),
                  _allTimeTab(scheme, near, res),
                  _dividendTab(scheme, res, near),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------------ status

  Widget _statusBar(ColorScheme scheme) {
    final res = _result;
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              if (_scanning) ...[
                const SizedBox(
                    width: 12,
                    height: 12,
                    child: CircularProgressIndicator(strokeWidth: 2)),
                const SizedBox(width: 8),
              ],
              Expanded(
                child: Text(
                  _scanning && _total > 0
                      ? '$_stage ($_done/$_total)…'
                      : (res == null
                          ? _stage
                          : '${res.near.length} stocks 52W ke $_withinPct% ke andar · '
                              '${res.scanned} scan hue · ${_d(res.tradeDate)}'),
                  style: const TextStyle(fontSize: 10.5),
                ),
              ),
              for (final pct in [3.0, 5.0, 10.0])
                Padding(
                  padding: const EdgeInsets.only(left: 4),
                  child: ChoiceChip(
                    label: Text('${pct.round()}%',
                        style: const TextStyle(fontSize: 9.5)),
                    selected: _withinPct == pct,
                    visualDensity: VisualDensity.compact,
                    onSelected: (_) {
                      setState(() => _withinPct = pct);
                      if (!_scanning) _run();
                    },
                  ),
                ),
            ],
          ),
          if (_scanning)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: LinearProgressIndicator(
                value: _total > 0 ? (_done / _total).clamp(0.0, 1.0) : null,
              ),
            ),
        ],
      ),
    );
  }

  // ------------------------------------------------------------- table 1 (52W)

  Widget _week52Tab(ColorScheme scheme, List<StockExtreme> near) {
    if (near.isEmpty) {
      return _empty('Koi stock 52W high/low ke $_withinPct% ke andar nahi hai.');
    }
    return ListView(
      padding: const EdgeInsets.fromLTRB(10, 0, 10, 24),
      children: [
        _note(scheme,
            'Rule: sirf wo stocks jo 52-week high **ya** low ke $_withinPct% ke '
            'andar hain. "Door" = LTP se kitna % door hai.'),
        const SizedBox(height: 8),
        Card(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
            child: Column(
              children: [
                _headerRow(scheme, const [
                  ('Stock', 2),
                  ('LTP', 1),
                  ('52W High', 1),
                  ('High se', 1),
                  ('52W Low', 1),
                  ('Low se', 1),
                ]),
                const Divider(height: 10),
                for (final e in near) _week52Row(scheme, e),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _week52Row(ColorScheme scheme, StockExtreme e) {
    final nearHigh = e.nearHigh52(_withinPct);
    final nearLow = e.nearLow52(_withinPct);
    final tag = nearHigh && nearLow
        ? '◆ HIGH+LOW'
        : (nearHigh ? '▲ HIGH' : (nearLow ? '▼ LOW' : '—'));
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(e.symbol,
                    style: const TextStyle(
                        fontSize: 11.5, fontWeight: FontWeight.w800)),
                Text(
                  '${tag}${e.companyName.isEmpty ? '' : ' · ${_short(e.companyName)}'}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 9,
                      color: nearHigh || nearLow
                          ? scheme.primary
                          : scheme.onSurfaceVariant),
                ),
              ],
            ),
          ),
          _cell(e.close, money: true),
          _cell(e.high52, money: true),
          _cell(e.distToHigh52Pct, pct: true, mark: nearHigh),
          _cell(e.low52, money: true),
          _cell(e.distToLow52Pct, pct: true, mark: nearLow),
        ],
      ),
    );
  }

  // --------------------------------------------------------- table 2 (all-time)

  Widget _allTimeTab(
      ColorScheme scheme, List<StockExtreme> near, ExtremesResult? res) {
    if (near.isEmpty) {
      return _empty('Koi stock 52W ke $_withinPct% ke andar nahi hai — '
          'ATH table bhi khaali rahegi (ye pehle wale rule par chalti hai).');
    }
    final withAth = near.where((e) => e.ath != null).toList();
    final pending = res?.athPending ?? const <String>[];
    return ListView(
      padding: const EdgeInsets.fromLTRB(10, 0, 10, 24),
      children: [
        _note(scheme,
            'ATH/ATL **official Angel history** se (saal-dar-saal chunk, cache '
            'hoti hai) — pehli baar thoda time lagta hai. Wahi stocks jo 52W '
            'filter me aaye hain.'),
        if (pending.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 6, bottom: 4),
            child: Text('⏳ ATH load ho raha hai: ${res?.athLoaded ?? 0} done · '
                'baaki ${pending.length}',
                style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant)),
          ),
        const SizedBox(height: 6),
        if (withAth.isEmpty)
          Text('Abhi tak koi ATH load nahi hua…',
              style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant))
        else
          Card(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
              child: Column(
                children: [
                  _headerRow(scheme, const [
                    ('Stock', 2),
                    ('LTP', 1),
                    ('All-time High', 1),
                    ('High se', 1),
                    ('All-time Low', 1),
                    ('Low se', 1),
                  ]),
                  const Divider(height: 10),
                  for (final e in withAth) _allTimeRow(scheme, e),
                ],
              ),
            ),
          ),
      ],
    );
  }

  Widget _allTimeRow(ColorScheme scheme, StockExtreme e) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(
          children: [
            Expanded(
              flex: 2,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(e.symbol,
                      style: const TextStyle(
                          fontSize: 11.5, fontWeight: FontWeight.w800)),
                  Text(
                    'ATH ${_d(e.athDate)}${e.atlDate == null ? '' : ' · ATL ${_d(e.atlDate)}'}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: 8.5, color: scheme.onSurfaceVariant),
                  ),
                ],
              ),
            ),
            _cell(e.close, money: true),
            _cell(e.ath, money: true),
            _cell(e.distToAthPct, pct: true, mark: (e.distToAthPct ?? 99) <= 5),
            _cell(e.atl, money: true),
            _cell(e.distToAtlPct, pct: true, mark: (e.distToAtlPct ?? 99) <= 5),
          ],
        ),
      );

  // ----------------------------------------------------------- table 3 (dividend)

  Widget _dividendTab(
      ColorScheme scheme, ExtremesResult? res, List<StockExtreme> near) {
    if (res == null) {
      return _empty('Scan chal raha hai…');
    }
    // 1.5.91 — ab **saare F&O stocks** ke upcoming dividends (52W filter se
    // independent). Proximity wale stocks ka close/company scan se aata hai;
    // baaki ke liye % "—" (close unknown) — guess nahi.
    final bySymbol = <String, StockExtreme>{
      for (final e in res.all) e.symbol: e,
      for (final e in near) e.symbol: e,
    };

    final nearSet = {for (final e in near) e.symbol};
    final rows = Extremes.sortedDividends(
      res.dividends,
      onlySymbols: _dividendOnlyNear ? nearSet : null,
    );

    return ListView(
      padding: const EdgeInsets.fromLTRB(10, 0, 10, 24),
      children: [
        Row(
          children: [
            Expanded(
              child: _note(scheme,
                  'Sirf **naye / aane wale** dividends (past history nahi) — NSE '
                  'event calendar (ex-date + amount) aur corporate announcements '
                  '(declaration date) se. **Saare F&O stocks** (proximity filter '
                  'se independent).'),
            ),
            ChoiceChip(
              label: const Text('52W ke andar wale',
                  style: TextStyle(fontSize: 9.5)),
              selected: _dividendOnlyNear,
              visualDensity: VisualDensity.compact,
              onSelected: (v) => setState(() => _dividendOnlyNear = v),
            ),
          ],
        ),
        if (res.dividendNote != null)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text('ℹ️ ${res.dividendNote}',
                style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant)),
          ),
        const SizedBox(height: 8),
        if (rows.isEmpty)
          Text(
              _dividendOnlyNear
                  ? 'In (52W proximity) stocks me koi naya dividend declaration nahi hai.'
                  : 'F&O stocks me koi naya dividend declaration nahi mila.',
              style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant))
        else
          Card(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
              child: Column(
                children: [
                  _headerRow(scheme, const [
                    ('Stock', 2),
                    ('₹ / share', 1),
                    ('Price ka %', 1),
                    ('Ex-date', 1),
                    ('Declared', 1),
                  ]),
                  const Divider(height: 10),
                  for (final entry in rows)
                    _dividendRow(
                      scheme,
                      bySymbol[entry.key] ??
                          StockExtreme(symbol: entry.key),
                      entry.value,
                    ),
                ],
              ),
            ),
          ),
      ],
    );
  }

  Widget _dividendRow(ColorScheme scheme, StockExtreme e, DividendEvent d) {
    final pct = d.pctOfPrice(e.close);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(e.symbol,
                    style: const TextStyle(
                        fontSize: 11.5, fontWeight: FontWeight.w800)),
                if (d.purpose.isNotEmpty)
                  Text(d.purpose,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontSize: 8.5, color: scheme.onSurfaceVariant)),
              ],
            ),
          ),
          _textCell(d.amountPerShare > 0
              ? '₹${d.amountPerShare.toStringAsFixed(2)}'
              : '—'),
          _textCell(pct == null ? '—' : '${pct.toStringAsFixed(2)}%',
              color: scheme.primary, bold: true),
          _textCell(_d(d.exDate)),
          _textCell(_d(d.announcedDate)),
        ],
      ),
    );
  }

  // ------------------------------------------------------------------ pieces

  Widget _headerRow(ColorScheme scheme, List<(String, int)> cols) => Row(
        children: [
          for (final (label, flex) in cols)
            Expanded(
              flex: flex,
              child: Text(label,
                  textAlign: flex == 2 ? TextAlign.left : TextAlign.right,
                  style: TextStyle(
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      color: scheme.onSurfaceVariant)),
            ),
        ],
      );

  Widget _cell(double? value,
      {bool money = false, bool pct = false, bool mark = false}) {
    final scheme = Theme.of(context).colorScheme;
    String text = '—';
    if (value != null && value.isFinite) {
      text = money
          ? _num(value)
          : '${value.toStringAsFixed(2)}%';
    }
    return Expanded(
      child: Text(text,
          textAlign: TextAlign.right,
          style: TextStyle(
            fontSize: 10.5,
            fontWeight: mark ? FontWeight.w900 : FontWeight.w600,
            color: mark ? scheme.primary : scheme.onSurface,
          )),
    );
  }

  Widget _textCell(String text, {Color? color, bool bold = false}) => Expanded(
        child: Text(text,
            textAlign: TextAlign.right,
            style: TextStyle(
                fontSize: 10,
                fontWeight: bold ? FontWeight.w800 : FontWeight.w500,
                color: color ?? Theme.of(context).colorScheme.onSurface)),
      );

  Widget _note(ColorScheme scheme, String text) => Text(
        text.replaceAll('**', ''),
        style: TextStyle(
            fontSize: 9.5, height: 1.45, color: scheme.onSurfaceVariant),
      );

  Widget _empty(String message) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(message,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 12, height: 1.5)),
        ),
      );

  static String _num(double v) {
    if (v >= 100000) return NumberFormat('#,##,##0').format(v.round());
    return v.toStringAsFixed(v >= 100 ? 0 : 2);
  }

  static String _d(DateTime? d) =>
      d == null ? '—' : DateFormat('dd MMM yy').format(d);

  static String _short(String s) =>
      s.length <= 26 ? s : '${s.substring(0, 26)}…';

  String _asText(ExtremesResult res) {
    final b = StringBuffer()
      ..writeln('=== 52W / ATH / Dividend (F&O stocks) ===')
      ..writeln('Trade date: ${_d(res.tradeDate)} · filter: $_withinPct%');
    b.writeln('\n52-WEEK HIGH/LOW (${res.near.length}):');
    for (final e in res.near) {
      b.writeln('• ${e.symbol} — LTP ${_num(e.close)} · 52W H ${_num(e.high52 ?? 0)} '
          '(${e.distToHigh52Pct?.toStringAsFixed(2) ?? '—'}%) · 52W L '
          '${_num(e.low52 ?? 0)} (${e.distToLow52Pct?.toStringAsFixed(2) ?? '—'}%)');
    }
    final withAth = res.near.where((e) => e.ath != null);
    if (withAth.isNotEmpty) {
      b.writeln('\nALL-TIME:');
      for (final e in withAth) {
        b.writeln('• ${e.symbol} — ATH ${_num(e.ath!)} (${_d(e.athDate)}) · '
            'ATL ${_num(e.atl!)} (${_d(e.atlDate)})');
      }
    }
    if (res.dividends.isNotEmpty) {
      b.writeln('\nDIVIDENDS (naye/upcoming):');
      for (final e in res.dividends.entries) {
        b.writeln('• ${e.key} — ₹${e.value.amountPerShare} · ex ${_d(e.value.exDate)} '
            '· declared ${_d(e.value.announcedDate)}');
      }
    }
    return b.toString();
  }
}
