// ---------------------------------------------------------------------------
// fno_hub_screen.dart — the entry point of the F&O module.
//
// 1.5.93 redesign (user decision): category rows (design "B"), har row
// **sirf naam + ek line** (compact), aur user **long-press karke row ko
// upar-neeche** kar sakta hai — order `fno_hub_order` key me save rehta hai.
//
// Section ka order fix hai (Study → Index → Options → Calendar), tools ka
// order user ka apna. Ek hi page scroll (PageScroll) — koi nested list nahi.
// ---------------------------------------------------------------------------

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/widgets/page_scroll.dart';
import '../../data/local/app_database.dart';
import '../../data/local/dao/candle_dao.dart';
import '../../data/local/dao/settings_dao.dart';
import 'ai/ai_suggestion_screen.dart';
import 'bankex/bankex_screen.dart';
import 'extremes/extremes_screen.dart';
import 'extremes/extremes_service.dart';
import 'fno_hub_config.dart';
import 'results/results_calendar_screen.dart';
import 'stock_oi/stock_oi_screen.dart';
import 'study/fno_study_screen.dart';
import 'study_adv/study_adv_screen.dart';

/// Order kahan save hota hai — test me fake store pass kar sakte hain.
abstract class FnoHubOrderStore {
  Future<Map<String, List<String>>> load();
  Future<void> save(Map<String, List<String>> order);
}

/// Asli store: settings table me ek JSON key.
class SettingsHubOrderStore implements FnoHubOrderStore {
  SettingsHubOrderStore([SettingsDao? dao])
    : _dao = dao ?? SettingsDao(AppDatabase.instance);

  static const String key = 'fno_hub_order';

  final SettingsDao _dao;

  @override
  Future<Map<String, List<String>>> load() async {
    try {
      final raw = await _dao.raw();
      final text = raw[key];
      if (text == null || text.isEmpty) return defaultHubOrder();
      return mergeHubOrder(jsonDecode(text));
    } catch (_) {
      // DB kharab / pehla launch — default order hi theek hai.
      return defaultHubOrder();
    }
  }

  @override
  Future<void> save(Map<String, List<String>> order) async {
    try {
      await _dao.put(key, jsonEncode(hubOrderToJson(order)));
    } catch (_) {
      // Save fail ho to bhi is session ka order chalta rahega.
    }
  }
}

class FnoHubScreen extends StatefulWidget {
  const FnoHubScreen({super.key, this.orderStore});

  /// Tests ke liye inject kar sakte hain; app me null = settings wala store.
  final FnoHubOrderStore? orderStore;

  @override
  State<FnoHubScreen> createState() => _FnoHubScreenState();
}

class _FnoHubScreenState extends State<FnoHubScreen> {
  late final FnoHubOrderStore _store =
      widget.orderStore ?? SettingsHubOrderStore();

  Map<String, List<String>> _order = defaultHubOrder();
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _loadOrder();
  }

  Future<void> _loadOrder() async {
    final order = await _store.load();
    if (!mounted) return;
    setState(() {
      _order = order;
      _loaded = true;
    });
  }

  void _dropTool(String sectionId, String toolId, int rawIndex) {
    final ids = _order[sectionId];
    if (ids == null) return;
    final from = ids.indexOf(toolId);
    var target = rawIndex;
    if (from >= 0 && from < target) target -= 1;
    final next = moveInSection(ids, toolId, target);
    setState(() => _order = {..._order, sectionId: next});
    _store.save(_order);
  }

  Future<void> _resetOrder() async {
    setState(() => _order = defaultHubOrder());
    await _store.save(_order);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Order wapas default par set ho gaya.')),
    );
  }

  void _openTool(BuildContext context, String id) {
    final route = switch (id) {
      'study' => MaterialPageRoute<void>(
        builder: (_) => const FnoStudyScreen(),
      ),
      'adv' => MaterialPageRoute<void>(builder: (_) => const StudyAdvScreen()),
      'bankex' => MaterialPageRoute<void>(
        builder: (_) => const BankexStrategiesScreen(),
      ),
      'stock_oi' => MaterialPageRoute<void>(
        builder: (_) => const StockOiScreen(),
      ),
      'extremes' => MaterialPageRoute<void>(
        builder: (_) => ExtremesScreen(
          service: ExtremesService(
            marketData: context.read(),
            candles: CandleDao(AppDatabase.instance),
            scripMaster: context.read(),
            nseGet: nseExtremesGet(),
          ),
        ),
      ),
      'results' => MaterialPageRoute<void>(
        builder: (_) => const ResultsCalendarScreen(),
      ),
      'ai' => MaterialPageRoute<void>(
        builder: (_) => const AiSuggestionScreen(),
      ),
      _ => null,
    };
    if (route == null) return;
    Navigator.of(context).push(route);
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('F&O Module'),
        actions: [
          IconButton(
            tooltip: 'Order reset karo',
            onPressed: _loaded ? _resetOrder : null,
            icon: const Icon(Icons.restart_alt_rounded),
          ),
        ],
      ),
      body: PageScroll.children([
        _HubHeader(scheme: scheme, toolCount: kHubTools.length),
        if (!_loaded)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 40),
            child: Center(child: CircularProgressIndicator()),
          )
        else
          for (final section in HubSection.values) ...[
            if (_order[section.id]?.isNotEmpty ?? false) ...[
              _SectionHeader(section: section),
              _SectionCard(
                section: section,
                ids: _order[section.id]!,
                onTapTool: (id) => _openTool(context, id),
                onDrop: (id, index) => _dropTool(section.id, id, index),
              ),
              const SizedBox(height: 18),
            ],
          ],
        const _ComingSoonTools(),
        const SizedBox(height: 8),
      ], padding: const EdgeInsets.fromLTRB(14, 8, 14, 28)),
    );
  }
}

// ---------------------------------------------------------------------------
// Header
// ---------------------------------------------------------------------------

class _HubHeader extends StatelessWidget {
  const _HubHeader({required this.scheme, required this.toolCount});

  final ColorScheme scheme;
  final int toolCount;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(
              Icons.candlestick_chart_rounded,
              size: 20,
              color: scheme.primary,
            ),
            const SizedBox(width: 8),
            Text(
              '$toolCount F&O tools',
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Row(
          children: [
            Icon(
              Icons.drag_indicator_rounded,
              size: 14,
              color: scheme.onSurfaceVariant,
            ),
            const SizedBox(width: 4),
            Expanded(
              child: Text(
                'Row ko dabaye rakho aur upar-neeche kheencho — aapka order '
                'save ho jayega.',
                style: TextStyle(
                  fontSize: 11.5,
                  height: 1.35,
                  color: scheme.onSurfaceVariant,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
      ],
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader({required this.section});

  final HubSection section;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 8),
      child: Text(
        section.label,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w800,
          letterSpacing: 1.0,
          color: section.color,
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Section card — rows + drag & drop
// ---------------------------------------------------------------------------

class _SectionCard extends StatelessWidget {
  const _SectionCard({
    required this.section,
    required this.ids,
    required this.onTapTool,
    required this.onDrop,
  });

  final HubSection section;
  final List<String> ids;
  final ValueChanged<String> onTapTool;

  /// (toolId, insertion index in the *current* list)
  final void Function(String toolId, int rawIndex) onDrop;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final tools = [
      for (final id in ids) hubToolById(id),
    ].whereType<HubTool>().toList(growable: false);

    return Container(
      decoration: BoxDecoration(
        color: scheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: scheme.outlineVariant.withOpacity(0.7)),
      ),
      child: Column(
        children: [
          for (var i = 0; i < tools.length; i++) ...[
            if (i > 0)
              Divider(
                height: 1,
                indent: 14,
                endIndent: 14,
                color: scheme.outlineVariant.withOpacity(0.55),
              ),
            _DraggableToolRow(
              key: ValueKey('${section.id}:${tools[i].id}'),
              tool: tools[i],
              index: i,
              onTap: () => onTapTool(tools[i].id),
              onDrop: onDrop,
            ),
          ],
        ],
      ),
    );
  }
}

class _DraggableToolRow extends StatefulWidget {
  const _DraggableToolRow({
    super.key,
    required this.tool,
    required this.index,
    required this.onTap,
    required this.onDrop,
  });

  final HubTool tool;
  final int index;
  final VoidCallback onTap;
  final void Function(String toolId, int rawIndex) onDrop;

  @override
  State<_DraggableToolRow> createState() => _DraggableToolRowState();
}

class _DraggableToolRowState extends State<_DraggableToolRow> {
  bool _hovering = false;
  bool _insertAbove = true;

  void _updateHover(Offset globalOffset) {
    final box = context.findRenderObject() as RenderBox?;
    if (box == null || !box.hasSize) return;
    final local = box.globalToLocal(globalOffset);
    final above = local.dy < box.size.height / 2;
    if (above != _insertAbove || !_hovering) {
      setState(() {
        _hovering = true;
        _insertAbove = above;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final tool = widget.tool;

    final row = Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: widget.onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 11, 8, 11),
          child: Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: tool.section.color.withOpacity(0.10),
                  borderRadius: BorderRadius.circular(11),
                ),
                child: Icon(tool.icon, size: 19, color: tool.section.color),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            tool.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 14.5,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        if (tool.badge != null) ...[
                          const SizedBox(width: 8),
                          _Badge(label: tool.badge!, color: tool.section.color),
                        ],
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      tool.blurb,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 11.5,
                        height: 1.3,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 6),
              Tooltip(
                message: 'Hold karke upar-neeche karo',
                child: Icon(
                  Icons.drag_indicator_rounded,
                  size: 18,
                  color: scheme.onSurfaceVariant.withOpacity(0.8),
                ),
              ),
              Icon(
                Icons.chevron_right_rounded,
                size: 20,
                color: scheme.onSurfaceVariant,
              ),
            ],
          ),
        ),
      ),
    );

    final line = Container(
      height: 2.5,
      margin: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: tool.section.color,
        borderRadius: BorderRadius.circular(2),
      ),
    );

    return DragTarget<String>(
      onWillAcceptWithDetails: (details) => details.data != tool.id,
      onMove: (details) => _updateHover(details.offset),
      onLeave: (_) {
        if (_hovering) setState(() => _hovering = false);
      },
      onAcceptWithDetails: (details) {
        final rawIndex = _insertAbove ? widget.index : widget.index + 1;
        setState(() => _hovering = false);
        widget.onDrop(details.data, rawIndex);
      },
      builder: (context, candidate, rejected) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (_hovering && _insertAbove) line,
            LongPressDraggable<String>(
              data: tool.id,
              delay: const Duration(milliseconds: 220),
              dragAnchorStrategy: pointerDragAnchorStrategy,
              feedback: Material(
                color: Colors.transparent,
                child: Opacity(
                  opacity: 0.95,
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 460),
                    child: _DragFeedback(tool: tool),
                  ),
                ),
              ),
              childWhenDragging: Opacity(opacity: 0.32, child: row),
              child: row,
            ),
            if (_hovering && !_insertAbove) line,
          ],
        );
      },
    );
  }
}

class _DragFeedback extends StatelessWidget {
  const _DragFeedback({required this.tool});

  final HubTool tool;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHigh,
        borderRadius: BorderRadius.circular(12),
        boxShadow: const [
          BoxShadow(
            color: Colors.black26,
            blurRadius: 16,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          Icon(tool.icon, size: 18, color: tool.section.color),
          const SizedBox(width: 10),
          Flexible(
            child: Text(
              tool.title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 13.5,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  const _Badge({required this.label, required this.color});

  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 9,
          fontWeight: FontWeight.w800,
          letterSpacing: 0.5,
          color: color,
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Coming soon
// ---------------------------------------------------------------------------

class _ComingSoonTools extends StatelessWidget {
  const _ComingSoonTools();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final tools = <(String, String)>[
      ('Greeks Calculator', 'Delta / Theta / Vega'),
      ('Strategy Builder', 'CE + PE payoff'),
      ('F&O Paper Trade', 'Lot ke saath paper trade'),
    ];

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: scheme.outlineVariant.withOpacity(0.7)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'AAGE KE TOOLS (jald aa rahe hain)',
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.8,
              color: scheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 10),
          for (final (title, subtitle) in tools)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                children: [
                  Icon(
                    Icons.schedule_rounded,
                    size: 14,
                    color: scheme.onSurfaceVariant,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(width: 6),
                  Flexible(
                    child: Text(
                      '· $subtitle',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 11,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
