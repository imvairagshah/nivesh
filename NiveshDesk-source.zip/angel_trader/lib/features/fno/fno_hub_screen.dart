// ---------------------------------------------------------------------------
// fno_hub_screen.dart — the entry point of the F&O module.
//
// The bottom navigation has five equity tabs and stays that way; F&O opens from
// the app bar as its own hub, because the module is a *different kind of
// instrument* (derivatives, expiries, lots, IV) and mixing it into the equity
// tabs would make both worse.
//
// Three tools are live — the 3-Month Study, the Results Calendar and AI
// Suggestion. The rest are shown as "jald aa raha hai" so the shape of the
// module is visible instead of being a mystery menu.
// ---------------------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../data/local/app_database.dart';
import '../../data/local/dao/candle_dao.dart';

import '../../core/theme/app_theme.dart';
import '../../core/widgets/motion.dart';
import 'ai/ai_suggestion_screen.dart';
import 'bankex/bankex_screen.dart';
import 'extremes/extremes_screen.dart';
import 'extremes/extremes_service.dart';
import 'stock_oi/stock_oi_screen.dart';
import 'study/fno_study_screen.dart';
import 'study_adv/study_adv_screen.dart';
import 'results/results_calendar_screen.dart';

class FnoHubScreen extends StatelessWidget {
  const FnoHubScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(title: const Text('F&O Module')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 28),
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  scheme.primaryContainer.withOpacity(0.75),
                  scheme.surfaceContainerLow,
                ],
              ),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.candlestick_chart_rounded,
                        size: 22, color: scheme.primary),
                    const SizedBox(width: 10),
                    const Text(
                      'F&O tools',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  'Ye module sirf futures aur options ke liye hai — alag tools, '
                  'alag calculations. Equity wale tabs (IPO, Golden Cross, RSI, '
                  'Paper, Reports) waise hi chalte rahenge.',
                  style: TextStyle(
                    fontSize: 12,
                    height: 1.4,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Candles, option book aur IV Angel One ke apne data se aate '
                  'hain. Ek hi cheez SmartAPI me nahi hai — company ke '
                  'results dates — wo NSE ke public corporate filings se '
                  'aati hai.',
                  style: TextStyle(
                    fontSize: 11,
                    height: 1.35,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          FadeSlideIn(
            index: 0,
            child: _ToolCard(
              icon: Icons.query_stats_rounded,
              title: '3-Month Study',
              badge: 'LIVE',
              subtitle:
                  'Har F&O stock ka 3 mahine ka trend, ATR, 3M high/low se doori, '
                  'ATM option ka IV aur edge — ek sortable table me.',
              bullets: const [
                'Trend: STRONG UP / UP / SIDEWAYS / DOWN / STRONG DOWN',
                'ATM CE/PE premium, IV aur IV rank',
                '🎯 Best Buy tag + "agar kal jodi buy ki hoti" ka P&L',
                'Excel / CSV / WhatsApp / Telegram export',
              ],
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => const FnoStudyScreen()),
              ),
            ),
          ),
          const SizedBox(height: 12),
          FadeSlideIn(
            index: 0,
            child: _ToolCard(
              icon: Icons.account_balance_rounded,
              title: 'Bankex–Bank Nifty Strategies',
              badge: 'NEW',
              subtitle:
                  'PDF Strategy Library ke rules se Bankex/Bank Nifty options '
                  'spreads — regime detection + 6 strategies (defined risk).',
              bullets: const [
                '🧭 Regime: Bullish/Bearish/Rangebound/Volatile (VIX, PCR, trend)',
                '🦋 Iron Butterfly · 🛡️ Short Strangle + Hedge · 📅 Calendar',
                '🌋 Straddle/Strangle · ⚖️ Diagonal Ratio · 🔀 Pair Trade',
                'Har leg: strike %OTM, credit targets, DTE gates, exit rules',
              ],
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                    builder: (_) => const BankexStrategiesScreen()),
              ),
            ),
          ),
          const SizedBox(height: 12),
          FadeSlideIn(
            index: 1,
            child: _ToolCard(
              icon: Icons.bar_chart_rounded,
              title: 'Stock OI Build–Unwind',
              badge: 'NAYA',
              subtitle:
                  'Din me kis STRIKE par badi position bani ya windup hui — '
                  'official NSE F&O bhavcopy (OI + ΔOI) se, stock options ke liye.',
              bullets: const [
                '🔨 Build-ups: Long/short buildup strikes (price × OI rules)',
                '🌀 Unwinds: Short covering + long unwinding strikes',
                '🎯 Filter: OI ≥ 5,000 · ΔOI ≥ 10% (Balanced/Strict/All)',
                '📋 Strike-wise chain: CE + PE ka OI, ΔOI qty aur ΔOI %',
              ],
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => const StockOiScreen()),
              ),
            ),
          ),
          const SizedBox(height: 12),
          FadeSlideIn(
            index: 2,
            child: Builder(builder: (context) {
              return _ToolCard(
                icon: Icons.insights_rounded,
                title: '52W · ATH · Dividend',
                badge: 'NAYA',
                subtitle:
                    'F&O stocks jo 52-week high/low ke 5% ke andar hain — '
                    'distance %, all-time high/low aur naye dividend declarations.',
                bullets: const [
                  '📈 52-Week: sirf 5% ke andar wale stocks + distance %',
                  '🏔️ All-Time High/Low — official history se (date ke saath)',
                  '💰 Dividend: naya/upcoming + ₹ per share + price ka %',
                  'Filter: 3% / 5% / 10% proximity (default 5%)',
                ],
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => ExtremesScreen(
                      service: ExtremesService(
                        marketData: context.read(),
                        candles: CandleDao(AppDatabase.instance),
                        scripMaster: context.read(),
                        nseGet: nseExtremesGet(),
                      ),
                    ),
                  ),
                ),
              );
            }),
          ),
          const SizedBox(height: 12),
          FadeSlideIn(
            index: 3,
            child: _ToolCard(
              icon: Icons.filter_alt_rounded,
              title: '3 Month Study with Advance Filter',
              badge: 'NAYA',
              subtitle:
                  'Wahi 3-Month Study, chaar sudhaar ke saath — alag page. '
                  'Purana page bilkul waise hi hai.',
              bullets: const [
                '🎯 Best Buy ab sirf “IV sasta” par nahi — edge bhi chahiye',
                'Doori ka ek hi paimaana · adhura mahina poora mahina nahi',
                'Turnover (liquidity) + expiry ki rok · min-score slider',
                'Har row par DO score: naya aur purana — farq aapki aankh se',
                'Naya tab: “Score ka hisab” — kya score sach me kaam karta hai',
              ],
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => const StudyAdvScreen(),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          FadeSlideIn(
            index: 2,
            child: _ToolCard(
              icon: Icons.event_available_rounded,
              title: 'Results Calendar',
              badge: 'LIVE',
              subtitle:
                  'Saari F&O companies ki next result date — ek list me, date ke '
                  'hisaab se.',
              bullets: const [
                'confirm = NSE par board meeting ka notice aa chuka hai',
                'Baki companies ke aage pichla result ki date — koi andaza nahi',
                'Din me ek hi baar NSE fetch; baaki time phone me cached',
              ],
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => const ResultsCalendarScreen(),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          FadeSlideIn(
            index: 3,
            child: _ToolCard(
              icon: Icons.auto_awesome_rounded,
              title: 'AI Suggestion',
              badge: 'LIVE',
              subtitle:
                  'Poore F&O universe ko scan kar ke top 20 ideas — har ek ke '
                  'saath direction, expected move, wajah aur option ki jodi.',
              bullets: const [
                'Local rule engine: koi online AI nahi, same data = same list',
                'Pattern pehchan: breakout, breakdown, pullback, range',
                'Option strategy: Buy/Sell, ATM ya OTM, exact jodi ke saath',
                'Saare filter aapke — RSI, volume, score, list ki lambai',
              ],
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => const AiSuggestionScreen(),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          const _ComingSoonTools(),
        ],
      ),
    );
  }
}

class _ToolCard extends StatelessWidget {
  const _ToolCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.bullets,
    required this.onTap,
    this.badge,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final List<String> bullets;
  final VoidCallback onTap;
  final String? badge;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final colors = MarketColors.of(context);

    return PressScale(
      child: Material(
        color: scheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: scheme.primary.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(icon, size: 19, color: scheme.primary),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        title,
                        style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    if (badge != null)
                      Container(
                        padding:
                            const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                        decoration: BoxDecoration(
                          color: colors.gain.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Text(
                          badge!,
                          style: TextStyle(
                            fontSize: 9.5,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 0.5,
                            color: colors.gain,
                          ),
                        ),
                      ),
                    const SizedBox(width: 4),
                    Icon(Icons.chevron_right_rounded,
                        size: 20, color: scheme.onSurfaceVariant),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  subtitle,
                  style: TextStyle(
                    fontSize: 12,
                    height: 1.4,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
                const SizedBox(height: 10),
                for (final line in bullets)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 5),
                          child: Container(
                            width: 4,
                            height: 4,
                            decoration: BoxDecoration(
                              color: scheme.primary,
                              shape: BoxShape.circle,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            line,
                            style: const TextStyle(fontSize: 11.5, height: 1.3),
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ComingSoonTools extends StatelessWidget {
  const _ComingSoonTools();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    const tools = [
      ('Option Chain', 'Strike-wise OI, premium aur IV — expiry ke hisaab se.'),
      ('Greeks Calculator', 'Delta / Theta / Vega se position ka risk samjho.'),
      ('Strategy Builder', 'CE + PE mila ke payoff dekhna (straddle, spread…).'),
      ('F&O Paper Trade', 'Options ko paper book me lot ke saath trade karna.'),
    ];

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: scheme.outlineVariant.withOpacity(0.7)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'AAGE KE TOOLS (jald aa rahe hain)',
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.8,
              color: scheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 10),
          for (final (title, subtitle) in tools)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.schedule_rounded,
                      size: 15, color: scheme.onSurfaceVariant),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          style: const TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        Text(
                          subtitle,
                          style: TextStyle(
                            fontSize: 11,
                            height: 1.3,
                            color: scheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
