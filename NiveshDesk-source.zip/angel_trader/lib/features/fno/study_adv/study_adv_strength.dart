// ---------------------------------------------------------------------------
// study_adv_strength.dart — "kaunsa stock chala hai, kaunsa pichhad raha hai?"
//
// The study scores a stock against its OWN history (trend, levels, IV). This
// ranks it against the rest of the F&O universe instead: the same 3 months,
// but the question is *who moved most*, which is what you need when you are
// choosing between two equally good setups.
//
// Ranking is inside the universe only — comparing with NIFTY would mean
// fetching index candles (a new request every run), so it is off by default.
//
// Pure: no Flutter, no database, no network.
// ---------------------------------------------------------------------------

import '../../../data/remote/dto/candle.dart';

/// ~1 month and ~3 months of trading sessions.
const int kSessionsPerMonth = 21;
const int kSessionsPerQuarter = 63;

/// Return over the last [sessions] sessions, in percent.
///
/// Null when the history is shorter than the window — a 3-month return over
/// 40 sessions is not a 3-month return.
double? returnOver(List<Candle> bars, int sessions) {
  if (bars.length <= sessions) return null;
  final last = bars.last.close;
  final then = bars[bars.length - 1 - sessions].close;
  if (then <= 0) return null;
  return (last / then - 1) * 100;
}

/// Where a stock sits in the universe: `Top 25%`, `Neeche 25%`, etc.
enum StrengthQuartile {
  top('Top 25%', 'sabse aage'),
  upper('Upper 25–50%', 'upar ki taraf'),
  lower('Lower 50–75%', 'neeche ki taraf'),
  bottom('Neeche 25%', 'sabse peeche'),
  unknown('—', 'ranking ke liye data kam');

  const StrengthQuartile(this.label, this.hint);

  final String label;
  final String hint;
}

/// One stock on the "Majbooti" tab.
class StudyStrengthRow {
  const StudyStrengthRow({
    required this.symbol,
    required this.ltp,
    this.return1m,
    this.return3m,
    required this.rank,
    required this.total,
    required this.quartile,
    required this.aboveOwnAverage,
  });

  final String symbol;
  final double ltp;

  /// Last ~1 month, percent. Null when the history is too short.
  final double? return1m;

  /// Last ~3 months, percent. Null when the history is too short.
  final double? return3m;

  /// 1 = the strongest of the universe (by the 1-month return).
  final int rank;
  final int total;

  final StrengthQuartile quartile;

  /// `true` when the price is above its own 50-session average.
  final bool? aboveOwnAverage;

  String get rankText => '$rank/$total';

  /// `+3.2%` / `−1.4%` / `—` — the sign is always spelled out, never a bare
  /// number the reader has to interpret.
  String textOf(double? value) {
    if (value == null) return '—';
    return '${value >= 0 ? '+' : '−'}${value.abs().toStringAsFixed(1)}%';
  }

  String get return1mText => textOf(return1m);
  String get return3mText => textOf(return3m);
}

/// Builds the strength board: every stock with its 1M/3M return and where
/// that puts it in the universe.
///
/// Sorted strongest first, ties broken by symbol so the order never shuffles.
List<StudyStrengthRow> buildStrengthRows(
  Map<String, List<Candle>> bars, {
  int month = kSessionsPerMonth,
  int quarter = kSessionsPerQuarter,
}) {
  final rows = <StudyStrengthRow>[];

  for (final entry in bars.entries) {
    final series = entry.value;
    if (series.isEmpty) continue;

    rows.add(StudyStrengthRow(
      symbol: entry.key,
      ltp: series.last.close,
      return1m: returnOver(series, month),
      return3m: returnOver(series, quarter),
      rank: 0, // filled in below
      total: 0,
      quartile: StrengthQuartile.unknown,
      aboveOwnAverage: _aboveAverage(series, 50),
    ));
  }

  // Rank on the 1-month return: it is the horizon a trader is actually
  // choosing between setups on. Stocks without a 1-month number go last.
  rows.sort((a, b) {
    final aValue = a.return1m;
    final bValue = b.return1m;
    if (aValue == null && bValue != null) return 1;
    if (bValue == null && aValue != null) return -1;
    if (aValue != null && bValue != null && aValue != bValue) {
      return bValue.compareTo(aValue);
    }
    return a.symbol.compareTo(b.symbol);
  });

  final total = rows.length;
  final ranked = <StudyStrengthRow>[];
  for (var i = 0; i < rows.length; i++) {
    final row = rows[i];
    ranked.add(StudyStrengthRow(
      symbol: row.symbol,
      ltp: row.ltp,
      return1m: row.return1m,
      return3m: row.return3m,
      rank: row.return1m == null ? 0 : i + 1,
      total: total,
      quartile: row.return1m == null
          ? StrengthQuartile.unknown
          : _quartile(i, total),
      aboveOwnAverage: row.aboveOwnAverage,
    ));
  }

  return ranked;
}

StrengthQuartile _quartile(int index, int total) {
  if (total <= 0) return StrengthQuartile.unknown;
  final share = (index + 1) / total;
  if (share <= 0.25) return StrengthQuartile.top;
  if (share <= 0.50) return StrengthQuartile.upper;
  if (share <= 0.75) return StrengthQuartile.lower;
  return StrengthQuartile.bottom;
}

bool? _aboveAverage(List<Candle> bars, int period) {
  if (bars.length < period) return null;
  var sum = 0.0;
  for (final bar in bars.sublist(bars.length - period)) {
    sum += bar.close;
  }
  return bars.last.close > sum / period;
}
