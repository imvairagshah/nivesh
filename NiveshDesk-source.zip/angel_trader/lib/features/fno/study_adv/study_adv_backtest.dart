// ---------------------------------------------------------------------------
// study_adv_backtest.dart — "kya score sach me kaam karta hai?" (C1)
//
// The 12-point study score was designed, not measured: four factors, weights
// that felt right. This file measures it. It replays the study over history the
// same honest way the AI backtest does:
//
//   • the score at bar `i` only ever sees bars 0…i (no look-ahead);
//   • the trade is taken at bar `i`'s close and measured `horizon` sessions
//     later — a Friday-style checkpoint every `stride` sessions, not every
//     session (a full-session stride would be ~5× slower for no extra truth);
//   • SIDEWAYS rows are skipped: the study itself says AVOID, so there is no
//     trade to count;
//   • an UP trend is measured long, a DOWN trend short — the study's own
//     suggestion decides the side, so this counts the suggestion, not a guess.
//
// Two scores are measured side by side (advanced and classic), because the
// interesting question is not "is the score magic?" but "did the corrections
// make it better?".
//
// Pure: no Flutter, no database, no network.
// ---------------------------------------------------------------------------

import '../../../data/remote/dto/candle.dart';
import '../../../data/remote/dto/scrip.dart';
import '../study/study_engine.dart';

/// How the replay is run.
class StudyBacktestConfig {
  const StudyBacktestConfig({
    this.horizonBars = 10,
    this.stride = 5,
    this.warmupBars = kStudyMinimumBars,
    this.bucketEdges = const [4, 7, 9],
  });

  /// Kitne session aage ka natija dekha jata hai.
  final int horizonBars;

  /// Har kitne session par score nikal kar trade gina jata hai.
  final int stride;

  /// Study ko kam se kam itne bar chahiye (60).
  final int warmupBars;

  /// Bucket ke daande: `< 4 | 4–7 | 7–9 | ≥ 9`.
  final List<double> bucketEdges;

  /// `10 din · har 5 session par · 60 bar warm-up`
  String get line => '$horizonBars din · har $stride session par · '
      '$warmupBars bar warm-up';

  /// Bars a series must hold before it can be judged at all.
  int get requiredBars => warmupBars + horizonBars + 2;
}

/// One score band's honest report card.
class StudyBucket {
  const StudyBucket({
    required this.label,
    required this.samples,
    required this.wins,
    required this.avgReturnPct,
    required this.medianReturnPct,
    required this.best,
    required this.worst,
  });

  /// `0–4` / `4–7` / `7–9` / `9–12`
  final String label;
  final int samples;
  final int wins;

  final double avgReturnPct;
  final double medianReturnPct;
  final double best;
  final double worst;

  static const StudyBucket empty = StudyBucket(
    label: '',
    samples: 0,
    wins: 0,
    avgReturnPct: 0,
    medianReturnPct: 0,
    best: 0,
    worst: 0,
  );

  bool get isEmpty => samples == 0;
  bool get enoughSamples => samples >= 30;

  /// `61% sahi disha`
  double get winRatePct => samples == 0 ? 0 : wins / samples * 100;

  /// `214 baar · 61% sahi disha · ausat +2.1%`
  String get line => samples == 0
      ? 'koi trade nahi'
      : '$samples baar · ${winRatePct.toStringAsFixed(0)}% sahi disha · '
          'ausat ${_signed(avgReturnPct)}%';

  /// `bahut kam sample` / `kam sample` / `theek-thaak` / `achchha sample`
  String get confidenceLabel => samples < 10
      ? 'bahut kam sample'
      : samples < 30
          ? 'kam sample'
          : samples < 100
              ? 'theek-thaak sample'
              : 'achchha sample';
}

/// The whole measurement: two score sets, four bands each.
class StudyScoreBacktest {
  const StudyScoreBacktest({
    required this.config,
    required this.advanced,
    required this.classic,
    required this.symbols,
    required this.skipped,
    required this.evaluations,
    required this.trades,
    required this.barsUsed,
  });

  final StudyBacktestConfig config;

  /// Buckets of the corrected score (this page's numbers).
  final List<StudyBucket> advanced;

  /// Buckets of the classic score (the old page's numbers).
  final List<StudyBucket> classic;

  /// Symbols with enough history to judge.
  final int symbols;

  /// `symbol → kyun chhoota`.
  final int skipped;

  /// How many (symbol, session) checkpoints were scored.
  final int evaluations;

  /// How many became trades (sideways checkpoints are not trades).
  final int trades;

  /// Average sessions of history the run actually had.
  final int barsUsed;

  bool get isEmpty => trades == 0;

  /// `true` when a higher band did better than the one below it, right across.
  ///
  /// This is the one claim worth making: a score that does not at least order
  /// the outcomes is decoration.
  bool get separates {
    final usable = advanced.where((b) => b.samples > 0).toList();
    if (usable.length < 2) return false;
    for (var i = 1; i < usable.length; i++) {
      if (usable[i].avgReturnPct <= usable[i - 1].avgReturnPct) return false;
    }
    return true;
  }

  /// The plain-language verdict, honest either way.
  String get verdict {
    if (isEmpty) return 'Is window me koi trade hi nahi bana.';
    final top = advanced.last;
    final bottom = advanced.first;
    if (separates) {
      return 'Score badhne ke saath natija badhta dikh raha hai: '
          '${bottom.label} band me ausat ${_signed(bottom.avgReturnPct)}%, '
          '${top.label} band me ${_signed(top.avgReturnPct)}%.';
    }
    return 'Score badhne ke saath natija SAAPH nahi badhta '
        '(${bottom.label}: ${_signed(bottom.avgReturnPct)}%, '
        '${top.label}: ${_signed(top.avgReturnPct)}%) — is score ko '
        '“jitna zyada utna achchha” maan kar mat chalo.';
  }

  /// Do the corrected rules order outcomes better than the old ones?
  String get comparisonNote {
    final a = advanced.where((b) => b.samples > 0).toList();
    final c = classic.where((b) => b.samples > 0).toList();
    if (a.length < 2 || c.length < 2) {
      return 'Tulna ke liye har band me kaafi sample nahi mile.';
    }
    final spreadNew = a.last.avgReturnPct - a.first.avgReturnPct;
    final spreadOld = c.last.avgReturnPct - c.first.avgReturnPct;
    if (spreadNew > spreadOld + 0.2) {
      return 'Naye niyam sabse achche aur sabse kamzor band ke beech '
          '${_signed(spreadNew)}% ka farq dikhate hain, purane niyam sirf '
          '${_signed(spreadOld)}% — matlab sudhaar ne score ko '
          'zyada matlab-purna banaya.';
    }
    if (spreadOld > spreadNew + 0.2) {
      return 'Is window me PURANE niyam zyada saaf farq dikhate hain '
          '(purana ${_signed(spreadOld)}% vs naya ${_signed(spreadNew)}%) — '
          'ye natija yahan ke data ka hai, aage badal sakta hai.';
    }
    return 'Dono niyam lagbhag ek jaisa farq dikhate hain '
        '(naya ${_signed(spreadNew)}%, purana ${_signed(spreadOld)}%).';
  }
}

/// Replays the study over [history] and measures both score sets.
///
/// [scripFor] builds the instrument the engine expects for a plain ticker —
/// passed in so this file stays free of any universe/DAO knowledge.
StudyScoreBacktest runStudyBacktest(
  Map<String, List<Candle>> history, {
  required StudyBacktestConfig config,
  required Scrip Function(String symbol) scripFor,
}) {
  final advancedSamples = <double, List<double>>{
    for (final edge in _bands(config)) edge: <double>[],
  };
  final classicSamples = <double, List<double>>{
    for (final edge in _bands(config)) edge: <double>[],
  };

  var symbols = 0;
  var skipped = 0;
  var evaluations = 0;
  var trades = 0;
  var barsTotal = 0;

  for (final entry in history.entries) {
    final bars = entry.value;
    if (bars.length < config.requiredBars) {
      skipped++;
      continue;
    }
    symbols++;
    barsTotal += bars.length;

    final scrip = scripFor(entry.key);
    final lastSignal = bars.length - 1 - config.horizonBars;

    for (var i = config.warmupBars - 1; i <= lastSignal; i += config.stride) {
      final window = bars.sublist(0, i + 1);
      final row = computeStudy(
        scrip: scrip,
        candles: window,
        rules: StudyRules.advanced,
      );
      if (row == null) continue;
      evaluations++;

      // SIDEWAYS rows are not trades — the study itself says AVOID.
      if (row.trend == Trend3M.sideways) continue;

      final classic = computeStudy(scrip: scrip, candles: window);
      final side = row.trend.isUp ? 1.0 : -1.0;
      final entryPrice = bars[i].close;
      final exitPrice = bars[i + config.horizonBars].close;
      if (entryPrice <= 0) continue;
      final forward = (exitPrice - entryPrice) / entryPrice * 100 * side;

      trades++;
      advancedSamples[_bandOf(config, row.score)]!.add(forward);
      if (classic != null) {
        classicSamples[_bandOf(config, classic.score)]!.add(forward);
      }
    }
  }

  return StudyScoreBacktest(
    config: config,
    advanced: _buckets(config, advancedSamples),
    classic: _buckets(config, classicSamples),
    symbols: symbols,
    skipped: skipped,
    evaluations: evaluations,
    trades: trades,
    barsUsed: symbols == 0 ? 0 : (barsTotal / symbols).round(),
  );
}

// ---------------------------------------------------------------------------
// Banding helpers
// ---------------------------------------------------------------------------

/// The lower edge of every band, in ascending order.
List<double> _bands(StudyBacktestConfig config) =>
    <double>[0, ...config.bucketEdges];

/// Which band a score falls in (`9.4` → `9`).
double _bandOf(StudyBacktestConfig config, double score) {
  var band = 0.0;
  for (final edge in config.bucketEdges) {
    if (score >= edge) band = edge.toDouble();
  }
  return band;
}

List<StudyBucket> _buckets(
  StudyBacktestConfig config,
  Map<double, List<double>> samples,
) {
  final edges = _bands(config);
  final rows = <StudyBucket>[];
  for (var i = 0; i < edges.length; i++) {
    final from = edges[i];
    final to = i + 1 < edges.length ? edges[i + 1] : 12.0;
    final values = samples[from] ?? const <double>[];
    rows.add(_bucket('${_num(from)}–${_num(to)}', values));
  }
  return rows;
}

StudyBucket _bucket(String label, List<double> values) {
  if (values.isEmpty) {
    return StudyBucket(
      label: label,
      samples: 0,
      wins: 0,
      avgReturnPct: 0,
      medianReturnPct: 0,
      best: 0,
      worst: 0,
    );
  }
  var wins = 0;
  var sum = 0.0;
  var best = double.negativeInfinity;
  var worst = double.infinity;
  for (final value in values) {
    if (value > 0) wins++;
    sum += value;
    if (value > best) best = value;
    if (value < worst) worst = value;
  }
  final sorted = [...values]..sort();
  final median = sorted.length % 2 == 1
      ? sorted[sorted.length ~/ 2]
      : (sorted[sorted.length ~/ 2 - 1] + sorted[sorted.length ~/ 2]) / 2;

  return StudyBucket(
    label: label,
    samples: values.length,
    wins: wins,
    avgReturnPct: sum / values.length,
    medianReturnPct: median,
    best: best,
    worst: worst,
  );
}

/// `+2.1` / `−0.4` — a signed percent, never a bare number.
String _signed(double value) =>
    '${value >= 0 ? '+' : '−'}${value.abs().toStringAsFixed(1)}';

String _num(double value) =>
    value == value.roundToDouble() ? value.toStringAsFixed(0) : value.toStringAsFixed(1);
