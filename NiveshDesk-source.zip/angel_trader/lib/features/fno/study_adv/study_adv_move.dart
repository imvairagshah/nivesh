// ---------------------------------------------------------------------------
// study_adv_move.dart — "aaj ye stock kitna chal sakta hai?"
//
// Two different questions, kept apart on purpose:
//
//   EXPECTED RANGE   what a normal session looks like for THIS stock (ATR),
//                    scaled by √sessions for a week. An estimate of the
//                    stock's own habit — never a promise about today.
//   GAP HISTORY      what this stock has actually done at the open: how often
//                    it gaps more than 1 % / 2 %, and the biggest gap it has
//                    opened with recently.
//
// Both are read off the candles the study already cached: no new requests,
// no new data source, nothing to subscribe to.
//
// Pure: no Flutter, no database, no network.
// ---------------------------------------------------------------------------

import 'dart:math' as math;

import '../../../data/remote/dto/candle.dart';

/// How many sessions of gap history the page reports on.
const int kGapLookback = 60;

/// The gap sizes the page counts (`≥ 1 %`, `≥ 2 %`).
const List<double> kGapThresholds = [1.0, 2.0];

/// Today's expected range, in rupees, from a 14-day ATR.
///
/// ±[atr] is the honest unit: ATR already IS the average daily range, so one
/// ATR is the move a normal day makes. For [sessions] ahead the random-walk
/// scaling √(sessions) is used — and labelled as an estimate, because a stock
/// is not a coin.
double expectedMove({required double atr, int sessions = 1}) {
  if (atr <= 0 || sessions <= 0) return 0;
  return atr * math.sqrt(sessions);
}

/// One stock on the "Aaj ki move" tab.
class StudyMoveRow {
  const StudyMoveRow({
    required this.symbol,
    required this.ltp,
    required this.atr,
    required this.atrPct,
    required this.expectedDay,
    required this.expectedWeek,
    required this.avgGapPct,
    required this.maxGapPct,
    required this.gapCounts,
    required this.gapSessions,
    required this.lastRangeVsAtr,
  });

  final String symbol;
  final double ltp;

  /// 14-session ATR in rupees.
  final double atr;

  /// ATR as a share of the price, in percent.
  final double atrPct;

  /// ±₹ for one session.
  final double expectedDay;

  /// ±₹ for a five-session week (ATR × √5).
  final double expectedWeek;

  /// Average absolute overnight gap over the lookback, in percent.
  final double avgGapPct;

  /// The biggest absolute gap in the lookback, in percent.
  final double maxGapPct;

  /// How many of the last [gapSessions] opens gapped ≥ each threshold.
  /// Keyed by the threshold (`1.0` → count).
  final Map<double, int> gapCounts;

  /// How many sessions the gap history actually covers (0 = not enough data).
  final int gapSessions;

  /// The last session's own range as a multiple of its ATR
  /// (`1.0` = a perfectly average day).
  final double? lastRangeVsAtr;

  /// `₹2.00` — the one number a trader sizes a stop with.
  String get expectedDayText => '±₹${expectedDay.toStringAsFixed(2)}';

  /// `1.5%` — the same number as a share of the price.
  String get atrPctText => '${atrPct.toStringAsFixed(1)}%';

  /// `12/60 din 1%+ gap` — the habit, with the sample size next to it, so a
  /// small sample never reads like a law.
  String gapText(double threshold) {
    if (gapSessions == 0) return 'gap: data kam';
    final count = gapCounts[threshold] ?? 0;
    return '$count/$gapSessions din ${threshold.toStringAsFixed(0)}%+ gap';
  }

  /// `1.2×` — the last session against the stock's own habit.
  String get lastRangeText =>
      lastRangeVsAtr == null ? '—' : '${lastRangeVsAtr!.toStringAsFixed(1)}×';
}

/// Builds the move table from cached candles.
///
/// [atrBySymbol] comes from the study's own rows (it already computes a Wilder
/// ATR); when a stock has no study row the ATR is computed here from the same
/// candles, so the tab still works without a scan.
List<StudyMoveRow> buildMoveRows(
  Map<String, List<Candle>> bars, {
  Map<String, double> atrBySymbol = const {},
  int lookback = kGapLookback,
  List<double> thresholds = kGapThresholds,
}) {
  final rows = <StudyMoveRow>[];

  for (final entry in bars.entries) {
    final series = entry.value;
    if (series.length < 3) continue;

    final atr = atrBySymbol[entry.key] ?? _wilderAtr(series);
    if (atr <= 0) continue;

    final last = series.last;
    final atrPct = last.close <= 0 ? 0.0 : atr / last.close * 100;

    // ---- gaps: open vs the previous close, over the lookback -------------
    final start = series.length > lookback ? series.length - lookback : 0;
    var sum = 0.0;
    var max = 0.0;
    var counted = 0;
    final counts = <double, int>{
      for (final threshold in thresholds) threshold: 0,
    };

    for (var i = start; i < series.length; i++) {
      if (i == 0) continue;
      final previous = series[i - 1].close;
      if (previous <= 0) continue;
      final gap = (series[i].open - previous).abs() / previous * 100;
      sum += gap;
      if (gap > max) max = gap;
      counted++;
      for (final threshold in thresholds) {
        if (gap >= threshold) counts[threshold] = (counts[threshold] ?? 0) + 1;
      }
    }

    // ---- the last session against the stock's own habit -------------------
    final double? lastRangeVsAtr =
        atr > 0 ? (last.high - last.low) / atr : null;

    rows.add(StudyMoveRow(
      symbol: entry.key,
      ltp: last.close,
      atr: atr,
      atrPct: atrPct,
      expectedDay: expectedMove(atr: atr),
      expectedWeek: expectedMove(atr: atr, sessions: 5),
      avgGapPct: counted == 0 ? 0 : sum / counted,
      maxGapPct: max,
      gapCounts: counts,
      gapSessions: counted,
      lastRangeVsAtr: lastRangeVsAtr,
    ));
  }

  rows.sort((a, b) => b.atrPct.compareTo(a.atrPct));
  return rows;
}

/// Wilder's 14-session ATR, for symbols the study never scored.
double _wilderAtr(List<Candle> bars, {int period = 14}) {
  if (bars.length < period + 1) return 0;

  var sum = 0.0;
  for (var i = bars.length - period; i < bars.length; i++) {
    final bar = bars[i];
    final previous = bars[i - 1].close;
    final range = math.max(
      bar.high - bar.low,
      math.max((bar.high - previous).abs(), (bar.low - previous).abs()),
    );
    sum += range;
  }
  return sum / period;
}
