// ---------------------------------------------------------------------------
// study_adv_mytrades.dart — "Mera hisaab": kaunsa setup fayda deta hai?
//
// Baaki sab screens batati hain ki BAZAAR kaisa hai. Ye batati hai ki US
// bazaar me aapne kya kiya: har band hua paper trade joda jata hai us study
// snapshot se jo us stock ka sabse kareeb (aur aage) tha — phir natija
// banta hai score, trend aur IV ke hisaab se.
//
// Imaandaari isi file me likhi hai, screen me nahi:
//
//   • jis bucket me [SetupBucket.minTrades] se kam trade hain, wo
//     [SetupBucket.sufficient] = false hota hai aur screen us par likhti hai
//     ki itne me kuch pakka nahi;
//   • jin trades ka koi snapshot mila hi nahi, wo [unmatched] me gine jate
//     hain — chhupaye nahi jate;
//   • snapshot purana ho to [stale] ginti badhti hai, kyunki "us din study ne
//     kya kaha tha" aur "aaj kya kehti hai" alag baat hai.
//
// Pure: no Flutter, no database, no network.
// ---------------------------------------------------------------------------

import '../../../data/local/models/paper_trade.dart';
import '../../../data/local/models/study_snapshot.dart';

/// Ek bucket: "score 8+ → 14 trade, 64% win, ₹3,200 net".
class SetupBucket {
  const SetupBucket({
    required this.key,
    required this.label,
    required this.closed,
    required this.wins,
    required this.netPnl,
    required this.best,
    required this.worst,
  });

  /// Stable id (`score_top`, `trend_up`, `iv_low`) — sorting me bhi kaam aata hai.
  final String key;
  final String label;

  final int closed;
  final int wins;

  /// Net realised P&L rupees me (charges kat kar).
  final double netPnl;

  final double best;
  final double worst;

  /// Is se kam trade ho to win rate ek pattern nahi, ek ittefaq hai.
  static const int minTrades = 10;

  bool get sufficient => closed >= minTrades;
  bool get isEmpty => closed == 0;

  /// `wins / closed` — kuch bhi band na hua ho to 0 (zero se bhaag nahi).
  double get winRate => closed == 0 ? 0 : wins / closed;

  /// Har band hue trade ka ausat rupees — yahi number compound hota hai.
  double get expectancy => closed == 0 ? 0 : netPnl / closed;

  /// `64%` — text ban kar, taaki screen galti se `0.64` na likh de.
  String get winRateText => '${(winRate * 100).toStringAsFixed(0)}%';

  /// `+₹229` / `−₹110` — sign likh kar (U+2212 ne is app ko pehle kaata hai).
  String get expectancyText =>
      '${expectancy >= 0 ? '+' : '−'}₹${expectancy.abs().toStringAsFixed(0)}';

  /// `−₹410` — sabse bada nuksaan, jise aam aadmi win rate se zyada yaad rakhta hai.
  String get worstText => '−₹${worst.abs().toStringAsFixed(0)}';

  /// Jo line screen par padhi jayegi — 10 se kam trade ho to chetavni ke saath.
  String get note {
    if (isEmpty) return 'Abhi koi trade nahi';
    if (!sufficient) {
      return 'sirf $closed trade — itne se kuch pakka nahi';
    }
    return '$closed trade · win $winRateText · har trade par $expectancyText';
  }
}

/// Poore tab ka natija.
class MyTradesReport {
  const MyTradesReport({
    required this.byScore,
    required this.byTrend,
    required this.byIvRank,
    required this.matched,
    required this.unmatched,
    required this.stale,
    required this.closedTrades,
  });

  /// Score ke hisaab se (0–5, 5–8, 8+).
  final List<SetupBucket> byScore;

  /// Trend ke hisaab se (upar / seedha / neeche).
  final List<SetupBucket> byTrend;

  /// IV rank ke hisaab se (low / medium / high).
  final List<SetupBucket> byIvRank;

  /// Jin trades ka snapshot mil gaya.
  final int matched;

  /// Jin trades ka koi snapshot hi nahi mila (study me kabhi nahi aaya).
  final int unmatched;

  /// Jin trades ka snapshot 30 din se purana tha.
  final int stale;

  /// Kul kitne band hue trade the.
  final int closedTrades;

  bool get isEmpty => closedTrades == 0;

  /// Upar wali line — hamesha ginti ke saath, kabhi khokhla davda nahi.
  String get note {
    if (isEmpty) {
      return 'Abhi tak koi trade band nahi hua — Paper Trading me kuch lijiye, '
          'phir yahan aapka apna hisaab dikhega.';
    }
    final thin = [
      ...byScore,
      ...byTrend,
      ...byIvRank,
    ].where((bucket) => !bucket.isEmpty && !bucket.sufficient).length;

    final buffer = StringBuffer('$closedTrades band hue trade me se '
        '$matched ka study se joda mila');
    if (unmatched > 0) buffer.write(' · $unmatched ka nahi mila');
    if (stale > 0) buffer.write(' · $stale purani study se (30 din se zyada)');
    if (thin > 0) {
      buffer.write(' · $thin bucket me 10 se kam trade — wahan kuch pakka nahi');
    }
    return buffer.toString();
  }

  /// Sabse bada nuksaan wala bucket — screen ise pehle dikhati hai, kyunki
  /// yahi wo jagah hai jahan aadmi sabse mehengi galti karta hai.
  SetupBucket? get worstBucket {
    final nonEmpty = [
      ...byScore,
      ...byTrend,
      ...byIvRank,
    ].where((bucket) => !bucket.isEmpty).toList(growable: false);
    if (nonEmpty.isEmpty) return null;
    nonEmpty.sort((a, b) => a.expectancy.compareTo(b.expectancy));
    return nonEmpty.first;
  }

  /// Sabse achha bucket (sirf tab jab [SetupBucket.minTrades] se upar ho).
  SetupBucket? get bestBucket {
    final solid = [
      ...byScore,
      ...byTrend,
      ...byIvRank,
    ].where((bucket) => bucket.sufficient).toList(growable: false);
    if (solid.isEmpty) return null;
    solid.sort((a, b) => b.expectancy.compareTo(a.expectancy));
    return solid.first;
  }
}

/// Band hue trades ko unke study snapshot se jod kar bucket banata hai.
///
/// Sirf wahi trades gine jate hain jin par nateeja likha hai
/// (`realizedPnl != null`) — khula hua trade abhi kahani nahi hai.
MyTradesReport buildMyTradesReport({
  required List<Trade> trades,
  required Map<String, StudySnapshotRow> snapshots,
  Duration staleAfter = const Duration(days: 30),
}) {
  final closed = [
    for (final trade in trades)
      if (trade.realizedPnl != null) trade,
  ];

  final scoreGroups = <String, _Accumulator>{
    for (final band in _scoreBands) band.key: _Accumulator(band.label),
  };
  final trendGroups = <String, _Accumulator>{
    for (final band in _trendBands) band.key: _Accumulator(band.label),
  };
  final ivGroups = <String, _Accumulator>{
    for (final band in _ivBands) band.key: _Accumulator(band.label),
  };

  var matched = 0;
  var unmatched = 0;
  var stale = 0;

  for (final trade in closed) {
    final snapshot = snapshots[_plain(trade.symbol)];
    if (snapshot == null) {
      unmatched++;
      continue;
    }
    matched++;

    // Jo snapshot trade ke BAAD ka ho, wo batata hi nahi ki trade lene waqt
    // study kya keh rahi thi — isliye wo hamesha "purana" hai. Baaki mein jo
    // [staleAfter] se zyada door ho, wo bhi (study ki baat purani pad gayi).
    if (!snapshot.savedAt.isBefore(trade.executedAt)) {
      stale++;
    } else if (trade.executedAt.difference(snapshot.savedAt) > staleAfter) {
      stale++;
    }

    final pnl = trade.realizedPnl!;
    scoreGroups[_scoreKey(snapshot.score)]!.add(pnl);
    trendGroups[_trendKey(snapshot.trend)]!.add(pnl);
    ivGroups[_ivKey(snapshot.ivRank)]!.add(pnl);
  }

  return MyTradesReport(
    byScore: _buckets(scoreGroups),
    byTrend: _buckets(trendGroups),
    byIvRank: _buckets(ivGroups),
    matched: matched,
    unmatched: unmatched,
    stale: stale,
    closedTrades: closed.length,
  );
}

/// `RELIANCE-EQ` → `RELIANCE`. Trade book broker wale symbol rakhta hai.
String _plain(String symbol) {
  final upper = symbol.trim().toUpperCase();
  final dash = upper.indexOf('-');
  return dash <= 0 ? upper : upper.substring(0, dash);
}

// ---- buckets --------------------------------------------------------------

class _Band {
  const _Band(this.key, this.label);
  final String key;
  final String label;
}

const List<_Band> _scoreBands = [
  _Band('score_top', 'Top (8 se upar)'),
  _Band('score_mid', 'Theek (5 se 8)'),
  _Band('score_low', 'Kam (5 se neeche)'),
];

const List<_Band> _trendBands = [
  _Band('trend_up', 'Upar (UP / STRONG UP)'),
  _Band('trend_flat', 'Seedha (SIDEWAYS)'),
  _Band('trend_down', 'Neeche (DOWN / STRONG DOWN)'),
  _Band('trend_unknown', 'Trend pata nahi'),
];

const List<_Band> _ivBands = [
  _Band('iv_low', 'IV kam (sasta)'),
  _Band('iv_mid', 'IV beech'),
  _Band('iv_high', 'IV zyada (mehnga)'),
  _Band('iv_unknown', 'IV pata nahi'),
];

String _scoreKey(double score) {
  if (score >= 8) return 'score_top';
  if (score >= 5) return 'score_mid';
  return 'score_low';
}

String _trendKey(String trend) {
  final value = trend.trim().toUpperCase();
  if (value.contains('STRONG UP') || value == 'UP') return 'trend_up';
  if (value.contains('STRONG DOWN') || value == 'DOWN') return 'trend_down';
  if (value.contains('SIDEWAYS')) return 'trend_flat';
  return 'trend_unknown';
}

String _ivKey(String ivRank) {
  final value = ivRank.trim().toUpperCase();
  if (value.contains('LOW')) return 'iv_low';
  if (value.contains('HIGH')) return 'iv_high';
  if (value.contains('MEDIUM') || value.contains('BEECH')) return 'iv_mid';
  return 'iv_unknown';
}

// ---- jama karne wala ------------------------------------------------------

class _Accumulator {
  _Accumulator(this.label);

  final String label;
  int closed = 0;
  int wins = 0;
  double net = 0;
  double best = 0;
  double worst = 0;

  void add(double pnl) {
    closed++;
    if (pnl > 0) wins++;
    net += pnl;
    if (pnl > best) best = pnl;
    if (pnl < worst) worst = pnl;
  }
}

List<SetupBucket> _buckets(Map<String, _Accumulator> groups) {
  final buckets = [
    for (final entry in groups.entries)
      SetupBucket(
        key: entry.key,
        label: entry.value.label,
        closed: entry.value.closed,
        wins: entry.value.wins,
        netPnl: entry.value.net,
        best: entry.value.best,
        worst: entry.value.worst,
      ),
  ];

  // Paise wale bucket pehle, phir jinme zyada trade hain; khaali bucket sabse
  // neeche — naye journal wala aadmi zero ki deewar na dekhe.
  buckets.sort((a, b) {
    if (a.isEmpty != b.isEmpty) return a.isEmpty ? 1 : -1;
    final byMoney = b.netPnl.compareTo(a.netPnl);
    if (byMoney != 0) return byMoney;
    return b.closed.compareTo(a.closed);
  });
  return buckets;
}
