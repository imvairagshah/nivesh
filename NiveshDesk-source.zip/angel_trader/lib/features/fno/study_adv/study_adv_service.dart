// ---------------------------------------------------------------------------
// study_adv_service.dart — data path for "3 Month Study with Advance Filter".
//
// It does two jobs and owns no maths:
//
//   1. `run()` asks the existing study service for the universe scored under
//      BOTH rule sets (one extra call to the pure engine per stock — no extra
//      network at all) and pairs them into [StudyAdvRow]s.
//   2. `backtest()` pulls each symbol's history (cache first, like the AI
//      backtest: a run over an already-cached window costs ZERO requests) and
//      hands it to the pure replay in study_adv_backtest.dart.
//
// The classic page is untouched by any of this: `persist: false` keeps an
// advance run from overwriting the classic page's saved snapshot, and the
// classic rules are never given to the study service as its own output.
// ---------------------------------------------------------------------------

import '../../../core/utils/markets.dart';
import '../../../data/local/dao/candle_dao.dart';
import '../../../data/remote/api_client.dart';
import '../../../data/remote/dto/candle.dart';
import '../../../data/remote/dto/scrip.dart';
import '../../../services/fno_study_service.dart';
import '../study/study_engine.dart';
import 'study_adv_backtest.dart';
import 'study_adv_filters.dart';
import '../../../services/candle_source.dart';

class StudyAdvService {
  StudyAdvService({
    required FnoStudyService study,
    required CandleSource source,
    required CandleDao candles,
    DateTime Function()? clock,
  })  : _study = study,
        _source = source,
        _candles = candles,
        _clock = clock ?? DateTime.now;

  final FnoStudyService _study;
  final CandleSource _source;
  final CandleDao _candles;
  final DateTime Function() _clock;

  /// Trading sessions in a year — the yardstick for "is the cache enough?".
  static const int sessionsPerYear = 250;

  /// Extra calendar days so the 60-bar warm-up is not taken out of the period
  /// being reported on.
  static const int calendarSlackDays = 150;

  /// A cached series is trusted when it holds at least this share of the
  /// sessions the window should have.
  static const double cacheSufficiency = 0.7;

  /// One run: both rule sets, gates applied.
  Future<StudyAdvResult> run({
    required List<Scrip> universe,
    required StudyAdvFilters filters,
    Map<String, String> companyNames = const {},
    DateTime? asOf,

    /// `SYMBOL → results date` (NSE-announced only). Read when the
    /// result-date gate is on: a stock about to report is held back with a
    /// reason, never dropped silently (B3).
    Map<String, DateTime> resultsDates = const {},

    /// Where IV may come from (B1) — passed straight through to the study.
    StudyIvSource ivSource = StudyIvSource.auto,
    void Function(FnoStudyProgress progress)? onProgress,
    bool Function()? isCancelled,
  }) async {
    final started = _clock();

    final result = await _study.run(
      universe: universe,
      companyNames: companyNames,
      asOf: asOf,
      rules: StudyRules.advanced,
      compareWith: StudyRules.classic,
      persist: false, // never overwrite the classic page's snapshot
      ivSource: ivSource,
      onProgress: onProgress,
      isCancelled: isCancelled,
    );

    final rows = buildAdvRows(
      result.rows,
      result.compareRows,
      filters,
      resultsDates: resultsDates,
      asOf: result.asOf,
    );

    return StudyAdvResult(
      rows: rows,
      filters: filters,
      asOf: result.asOf,
      duration: _clock().difference(started),
      scanned: result.scanned,
      cancelled: result.cancelled,
    );
  }

  /// The score measurement (C1), over locally cached history.
  Future<StudyScoreBacktest> backtest({
    required List<Scrip> universe,
    required StudyBacktestConfig config,
    required int years,
    DateTime? asOf,
    void Function(FnoStudyProgress progress)? onProgress,
    bool Function()? isCancelled,
  }) async {
    final started = _clock();
    final day = asOf ?? _clock();
    final lookbackDays = years * 365 + calendarSlackDays;
    final from = day.subtract(Duration(days: lookbackDays));
    final enough = (years * sessionsPerYear * cacheSufficiency).round();

    final history = <String, List<Candle>>{};
    var skipped = 0;

    for (var i = 0; i < universe.length; i++) {
      if (isCancelled?.call() ?? false) break;
      final scrip = universe[i];
      final plain = Scrip.plainSymbol(scrip.symbol);

      try {
        var bars = await _readCache(scrip, from, day);
        final reachesNow = bars.isNotEmpty &&
            !bars.last.istDate.isBefore(_midnight(day));
        if (!(reachesNow && bars.length >= enough)) {
          // The cache is shorter than the window the user asked for: fetch it
          // once and keep it, so the next run is offline.
          final fresh = await _source.fetchDailyCandles(
            scrip: scrip,
            from: DateTime(from.year, from.month, from.day, 9, 15),
            to: DateTime(day.year, day.month, day.day, 15, 30),
          );
          if (fresh.isNotEmpty) {
            await _writeCache(scrip, fresh, from, day);
            bars = fresh;
          }
        }
        if (bars.isNotEmpty) history[plain] = bars;
      } on ApiException catch (_) {
        // A stock we cannot load is simply not measured — and the report says
        // how many were left out.
        skipped++;
      } catch (_) {
        skipped++;
      }

      onProgress?.call(
        FnoStudyProgress(
          stage: StudyStage.candles,
          done: i + 1,
          total: universe.length,
          current: plain,
          fraction: 0.85 * ((i + 1) / (universe.isEmpty ? 1 : universe.length)),
          elapsed: _clock().difference(started),
        ),
      );
      await Future<void>.delayed(Duration.zero); // keep the UI alive
    }

    onProgress?.call(
      FnoStudyProgress(
        stage: StudyStage.scoring,
        done: universe.length,
        total: universe.length,
        fraction: 0.95,
        elapsed: _clock().difference(started),
      ),
    );
    await Future<void>.delayed(Duration.zero);

    final backtest = runStudyBacktest(
      history,
      config: config,
      scripFor: (symbol) => Scrip(
        token: symbol,
        symbol: '$symbol-EQ',
        name: symbol,
        exchange: Exchange.nse,
      ),
    );

    // The loader's own skips (series too short to judge) plus the ones that
    // never arrived at all.
    return StudyScoreBacktest(
      config: backtest.config,
      advanced: backtest.advanced,
      classic: backtest.classic,
      symbols: backtest.symbols,
      skipped: backtest.skipped + skipped,
      evaluations: backtest.evaluations,
      trades: backtest.trades,
      barsUsed: backtest.barsUsed,
    );
  }

  /// Sirf phone me pahle se maujood candles — **ek bhi network call nahi**.
  ///
  /// Ye offline analysis (IVP/IVR, DP, trend) ka kachha maal hai: scanner ya
  /// study chalate waqt history download ho chuki hoti hai, to yahan se bas
  /// padhna hai.
  ///
  /// [universe] diya jaye to unhi stocks ke candles padhe jate hain. Na diya
  /// jaye to **jo kuch bhi phone me hai** — isse ye page tab bhi kaam karta
  /// hai jab F&O universe abhi resolve hi nahi hua (aur universe resolve karne
  /// ke liye network/token ki zaroorat nahi padti).
  ///
  /// Jis stock ke kaafi candles nahi hain, wo natije me nahi aata — aur kitne
  /// stock ke data mile, ye ginti screen par likhi jati hai.
  Future<Map<String, List<Candle>>> cachedBars({
    List<Scrip>? universe,
    int days = 420,
    void Function(int done, int total)? onProgress,
  }) async {
    final now = _clock();
    final to = DateTime(now.year, now.month, now.day, 15, 30);
    final from = to.subtract(Duration(days: days));

    final out = <String, List<Candle>>{};
    var done = 0;

    if (universe != null) {
      for (final scrip in universe) {
        final bars = await _readCache(scrip, from, to);
        if (bars.length >= 25) out[Scrip.plainSymbol(scrip.symbol)] = bars;
        done++;
        onProgress?.call(done, universe.length);
      }
      return out;
    }

    // Universe ke bina: phone me maujood har series.
    final series = await _candles.cachedSeries();
    for (final entry in series) {
      if (entry.symbol.isEmpty) continue;
      final bars = await _readCacheRaw(entry.exchange, entry.symbol, from, to);
      if (bars.length >= 25) out[Scrip.plainSymbol(entry.symbol)] = bars;
      done++;
      onProgress?.call(done, series.length);
    }
    return out;
  }

  /// Sirf EK stock ke candles, plain symbol se (`RELIANCE`).
  ///
  /// Plan card ke liye — row khulte hi poora universe padhna barbaadi hai.
  /// Phone me jo hai wahi deta hai; koi network call nahi.
  Future<List<Candle>> barsForSymbol(String plainSymbol, {int days = 420}) async {
    final now = _clock();
    final to = DateTime(now.year, now.month, now.day, 15, 30);
    final from = to.subtract(Duration(days: days));

    final wanted = plainSymbol.trim().toUpperCase();
    if (wanted.isEmpty) return const <Candle>[];

    final series = await _candles.cachedSeries();
    for (final entry in series) {
      if (Scrip.plainSymbol(entry.symbol) != wanted) continue;
      if (entry.exchange.isEmpty) continue;
      final bars = await _readCacheRaw(entry.exchange, entry.symbol, from, to);
      if (bars.isNotEmpty) return bars;
    }
    return const <Candle>[];
  }

  Future<List<Candle>> _readCache(Scrip scrip, DateTime from, DateTime to) async {
    return _readCacheRaw(scrip.exchange.code, scrip.symbol, from, to);
  }

  Future<List<Candle>> _readCacheRaw(
    String exchange,
    String symbol,
    DateTime from,
    DateTime to,
  ) async {
    try {
      return await _candles.barsFor(
        exchange: exchange,
        symbol: symbol,
        from: from,
        to: to,
      );
    } catch (_) {
      return const <Candle>[];
    }
  }

  Future<void> _writeCache(
    Scrip scrip,
    List<Candle> bars,
    DateTime from,
    DateTime to,
  ) async {
    try {
      await _candles.saveBars(
        exchange: scrip.exchange.code,
        symbol: scrip.symbol,
        bars: bars,
        replaceWindow: true,
        windowFrom: DateTime(from.year, from.month, from.day, 9, 15),
        windowTo: DateTime(to.year, to.month, to.day, 15, 30),
      );
    } catch (_) {
      // Caching is a nice-to-have; the run still uses what it fetched.
    }
  }
}

DateTime _midnight(DateTime day) => DateTime(day.year, day.month, day.day);
