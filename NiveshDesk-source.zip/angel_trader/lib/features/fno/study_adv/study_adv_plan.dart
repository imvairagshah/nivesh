// ---------------------------------------------------------------------------
// study_adv_plan.dart — "aaj kya kare": entry, stop, target.
//
// Teen raaste, kyunki teen alag kaam hain:
//
//   STOCK          bhav kharido/becho. Stop = 1×ATR ya DP wale support ke
//                  neeche (jo bhi entry ke kareeb ho — chhota nuksaan pehle).
//   OPTION KHARIDO premium do, aur spot ke level se premium ka hisaab karo
//                  (delta mile to delta se, nahi mile to 40/80% ke convention
//                  se — aur likh do ki kaunsa hai).
//   OPTION BECHO   jodi (strangle). Yahan ATR ka stop premium par nahi chalta:
//                  bechne wala premium ka aadha le kar nikalta hai, aur
//                  premium 1.5× ho jaye to maan leta hai ki galat ho gaya.
//
// Imaandaari isi file me likhi hai:
//   • ye MECHANICAL niyam hai — results, news, gap isme shaamil nahi;
//   • delta na mile to wahi likha jata hai (chhup kar koi "exact" number
//     nahi banaya jata);
//   • jahan hisaab hi nahi ban sakta (jaise seedha bazaar me stock plan),
//     wahan "koi plan nahi" likha jata hai — khaali jagah nahi chhodhi jati.
//
// Pure: no Flutter, no database, no network.
// ---------------------------------------------------------------------------

import '../study/black_scholes.dart' show OptionType;
import '../study/study_engine.dart';
import 'study_adv_analysis.dart' show DpRow;

/// Stock: kharidna, bechna, ya kuch nahi.
enum PlanSide { buy, sell, none }

extension PlanSideLabel on PlanSide {
  String get label => switch (this) {
        PlanSide.buy => 'kharido',
        PlanSide.sell => 'becho (short)',
        PlanSide.none => 'koi plan nahi',
      };
}

/// Stop kis cheez se nikala — screen par likha jata hai, chhupaya nahi.
enum StopBasis {
  atr('1×ATR'),
  dp('DP support ke neeche'),
  dpResistance('DP resistance ke upar');

  const StopBasis(this.label);

  final String label;
}

/// Stock ka plan: entry / stop / target, aur kaunsa stop chuna gaya.
class StockPlan {
  const StockPlan({
    required this.side,
    required this.entry,
    required this.stop,
    required this.target,
    required this.basis,
    required this.atrStop,
    this.dpStop,
  });

  final PlanSide side;

  /// CMP (ya jo bhav aapne diya).
  final double entry;
  final double stop;
  final double target;

  final StopBasis basis;

  /// 1×ATR wala stop (hamesha banta hai).
  final double atrStop;

  /// DP wala stop (support/resistance na mile to null).
  final double? dpStop;

  /// Nuksaan, bhav ka % (hamesha positive).
  double get riskPct => (entry - stop).abs() / entry * 100;

  /// Munafa, bhav ka %.
  double get rewardPct => (target - entry).abs() / entry * 100;

  /// `1 : 2.0` — risk se reward ka banta.
  double get rewardRatio => riskPct == 0 ? 0 : rewardPct / riskPct;

  String get ratioText => '1 : ${rewardRatio.toStringAsFixed(1)}';

  /// Stop, bhav se kitna door — '−1.8%'.
  String get stopPctText => _pctOf(stop);

  /// Target, bhav se kitna door — '+3.7%'.
  String get targetPctText => _pctOf(target);

  String _pctOf(double value) {
    final pct = (value - entry).abs() / entry * 100;
    return '${value >= entry ? '+' : '−'}${pct.toStringAsFixed(1)}%';
  }

  /// Dono stop me se kyun yahi chuna — ek line.
  String get basisNote {
    final dp = dpStop;
    if (basis == StopBasis.atr && dp == null) {
      return 'stop 1×ATR se (DP par koi level nahi mila)';
    }
    if (basis == StopBasis.atr) {
      return 'stop 1×ATR se — DP wala stop isse door tha';
    }
    return 'stop DP ke level se — 1×ATR wala isse door tha';
  }

  /// Short delivery me nahi hota — ye baat likhni padti hai.
  String get sideNote => side == PlanSide.sell
      ? 'stock bechna (short) sirf intraday ya futures me hota hai — delivery me nahi'
      : '';
}

/// Option kharidne ka plan: premium ka entry/stop/target.
class OptionBuyPlan {
  const OptionBuyPlan({
    required this.type,
    required this.strike,
    required this.premium,
    required this.stopPremium,
    required this.targetPremium,
    required this.spotStop,
    required this.spotTarget,
    required this.usedDelta,
  });

  /// 'CE' ya 'PE'.
  final String type;
  final double strike;

  /// Abhi ka premium.
  final double premium;
  final double stopPremium;
  final double targetPremium;

  /// Spot ke wahi level jin par ye premium wala hisaab tikka hai.
  final double spotStop;
  final double spotTarget;

  /// `true` = delta mila tha, hisaab spot se juda hai. `false` = 40/80% ka
  /// convention — ye baat screen par likhi jati hai.
  final bool usedDelta;

  double get stopPct => (stopPremium - premium) / premium * 100;
  double get targetPct => (targetPremium - premium) / premium * 100;

  String get note => usedDelta
      ? 'premium ka hisaab delta se (spot ke level ke saath)'
      : 'delta nahi mila — premium stop/target 40% / 80% ke convention se';
}

/// Jodi (strangle) bechne ka plan.
class OptionSellPlan {
  const OptionSellPlan({
    required this.premium,
    required this.stopPremium,
    required this.targetPremium,
    this.ceStrike,
    this.peStrike,
    this.safeLow,
    this.safeHigh,
  });

  /// Aaj milne wala kul premium (CE + PE).
  final double premium;

  /// Premium 1.5× ho jaye to nikalna — bechne wale ka stop yahi hota hai.
  final double stopPremium;

  /// Premium ka aadha — bechne wale ka target yahi hota hai.
  final double targetPremium;

  final double? ceStrike;
  final double? peStrike;

  /// Jis band ke andar jodi ko nuksaan nahi badhta (strikes ± aadha ATR).
  final double? safeLow;
  final double? safeHigh;

  /// `true` jab dono strike ke premium mil gaye ho.
  bool get isComplete => premium > 0;

  String get bandNote {
    final low = safeLow;
    final high = safeHigh;
    if (low == null || high == null) return '';
    return 'jab tak spot ₹${low.toStringAsFixed(0)} – ₹${high.toStringAsFixed(0)} '
        'ke beech rahe, jodi ko khaas nuksaan nahi';
  }
}

/// Ek stock ka poora plan — jo bhi ban sake.
class TradePlan {
  const TradePlan({
    required this.symbol,
    this.stock,
    this.optionBuy,
    this.optionSell,
    required this.notes,
  });

  final String symbol;

  /// Stock ka plan (seedhe bazaar me null).
  final StockPlan? stock;

  /// CE ya PE kharidne ka plan (trend ke hisaab se).
  final OptionBuyPlan? optionBuy;

  /// Jodi bechne ka plan.
  final OptionSellPlan? optionSell;

  /// Imaandaari ki line — kabhi khaali nahi.
  final String notes;

  bool get isEmpty =>
      stock == null && optionBuy == null && optionSell == null;
}

/// Plan banata hai — sirf phone me maujood cheezon se.
///
/// [atr] rupee me (14-din Wilder), [dp] 1.5.23 wala support/resistance.
TradePlan buildTradePlan({
  required String symbol,
  required double cmp,
  required double atr,
  required Trend3M trend,
  DpRow? dp,
  StudyOptionLeg? ce,
  StudyOptionLeg? pe,
  ({double total, double? ceStrike, double? peStrike})? jodi,
  double? ceDelta,
  double? peDelta,
}) {
  final notes = <String>[];
  final stock = buildStockPlan(cmp: cmp, atr: atr, dp: dp, trend: trend);
  if (stock == null) {
    notes.add('Bazaar seedha (SIDEWAYS) hai — stock me kharidne/bechne ka '
        'koi pakka plan nahi; aisi jagah jodi bechna hi socha jata hai.');
  }

  final buyLeg = trend.isDown ? pe : ce; // neeche ke trend me PE, upar me CE
  final buyDelta = trend.isDown ? peDelta : ceDelta;
  final OptionBuyPlan? optionBuy =
      buyLeg == null ? null : buildOptionBuyPlan(
              leg: buyLeg,
              plan: stock,
              cmp: cmp,
              atr: atr,
              delta: buyDelta,
            );

  final OptionSellPlan? optionSell =
      jodi == null ? null : buildOptionSellPlan(jodi: jodi, atr: atr);

  if (optionBuy == null && optionSell == null) {
    notes.add('Is stock ke option legs ka bhav nahi mila — plan sirf stock ke '
        'liye hai.');
  }
  if (!_hasAnyDelta(ceDelta, peDelta)) {
    notes.add('Option premium ka stop/target delta ke bina 40% / 80% ke '
        'convention se hai — broker se delta/IV mile to yahi hisaab spot se '
        'jud jayega.');
  }

  notes.add(
    'Ye MECHANICAL niyam hai (1×ATR / 2×ATR aur DP ke level) — isme results, '
    'khabar ya subah ka gap shaamil nahi. Koi guarantee nahi.',
  );

  return TradePlan(
    symbol: symbol,
    stock: stock,
    optionBuy: optionBuy,
    optionSell: optionSell,
    notes: notes.join(' '),
  );
}

bool _hasAnyDelta(double? ceDelta, double? peDelta) =>
    ((ceDelta ?? 0) > 0) || ((peDelta ?? 0) > 0);

/// Stock ka plan. Seedhe bazaar (SIDEWAYS) me `null` — wahan koi plan nahi.
StockPlan? buildStockPlan({
  required double cmp,
  required double atr,
  required Trend3M trend,
  DpRow? dp,
}) {
  if (atr <= 0 || cmp <= 0) return null;
  if (!trend.isUp && !trend.isDown) return null;

  if (trend.isUp) {
    final atrStop = cmp - atr;
    final dpStop = dp?.nearestDown?.price == null
        ? null
        : dp!.nearestDown!.price * 0.995; // support ke thoda neeche
    final stop = _nearer(cmp, atrStop, dpStop, higherIsNearer: true);
    return StockPlan(
      side: PlanSide.buy,
      entry: cmp,
      stop: stop.value,
      target: cmp + 2 * atr,
      basis: stop.basis,
      atrStop: atrStop,
      dpStop: dpStop,
    );
  }

  // Neeche ka trend → bechna. Stop upar, target neeche.
  final atrStop = cmp + atr;
  final dpStop = dp?.nearestUp?.price == null
      ? null
      : dp!.nearestUp!.price * 1.005; // resistance ke thoda upar
  final stop = _nearer(cmp, atrStop, dpStop, higherIsNearer: false);
  return StockPlan(
    side: PlanSide.sell,
    entry: cmp,
    stop: stop.value,
    target: cmp - 2 * atr,
    basis: stop.basis,
    atrStop: atrStop,
    dpStop: dpStop,
  );
}

/// Dono stop me se jo entry ke kareeb ho, wo — chhota nuksaan pehle.
({double value, StopBasis basis}) _nearer(
  double cmp,
  double atrStop,
  double? dpStop, {
  required bool higherIsNearer,
}) {
  if (dpStop == null) {
    return (value: atrStop, basis: StopBasis.atr);
  }

  if (higherIsNearer) {
    // Khareedne me stop bhav se neeche hota hai: jo zyada (bhav ke kareeb).
    if (dpStop > atrStop && dpStop < cmp) {
      return (value: dpStop, basis: StopBasis.dp);
    }
    return (value: atrStop, basis: StopBasis.atr);
  }

  // Bechne me stop bhav se upar: jo kam (bhav ke kareeb).
  if (dpStop < atrStop && dpStop > cmp) {
    return (value: dpStop, basis: StopBasis.dpResistance);
  }
  return (value: atrStop, basis: StopBasis.atr);
}

/// Option kharidne ka plan: premium, aur spot ke level.
OptionBuyPlan? buildOptionBuyPlan({
  required StudyOptionLeg leg,
  StockPlan? plan,
  required double cmp,
  required double atr,
  double? delta,
}) {
  final premium = leg.ltp;
  if (premium == null || premium <= 0) return null;
  if (atr <= 0) return null;

  final spotStop = plan?.stop ?? (cmp - atr);
  final spotTarget = plan?.target ?? (cmp + 2 * atr);

  final double stopPremium;
  final double targetPremium;
  final bool usedDelta = (delta ?? 0) > 0.02;

  if (usedDelta) {
    // Premium ka badlav ≈ delta × spot ka badlav. Kabhi bhi 0 se neeche nahi.
    stopPremium = (premium + delta! * (spotStop - cmp)).clamp(
      premium * 0.05,
      premium * 10,
    );
    targetPremium = premium + delta * (spotTarget - cmp);
  } else {
    // Convention: premium ka 40% gaya to nikalna, 80% aaya to nikalna.
    stopPremium = premium * 0.6;
    targetPremium = premium * 1.8;
  }

  return OptionBuyPlan(
    type: leg.type == OptionType.call ? 'CE' : 'PE',
    strike: leg.strike,
    premium: premium,
    stopPremium: stopPremium,
    targetPremium: targetPremium,
    spotStop: spotStop,
    spotTarget: spotTarget,
    usedDelta: usedDelta,
  );
}

/// Jodi bechne ka plan — premium ka aadha target, 1.5× stop.
OptionSellPlan? buildOptionSellPlan({
  required ({double total, double? ceStrike, double? peStrike}) jodi,
  required double atr,
}) {
  if (jodi.total <= 0) return null;

  final ceStrike = jodi.ceStrike;
  final peStrike = jodi.peStrike;

  return OptionSellPlan(
    premium: jodi.total,
    stopPremium: jodi.total * 1.5,
    targetPremium: jodi.total * 0.5,
    ceStrike: ceStrike,
    peStrike: peStrike,
    // Strikes ke aas-paas aadha ATR ki chhoti si gunjaaish — iske bahar
    // nuksaan badhne lagta hai.
    safeLow: peStrike == null ? null : peStrike - atr * 0.5,
    safeHigh: ceStrike == null ? null : ceStrike + atr * 0.5,
  );
}
