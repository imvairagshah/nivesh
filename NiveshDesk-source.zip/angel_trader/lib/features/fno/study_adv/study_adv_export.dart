// ---------------------------------------------------------------------------
// study_adv_export.dart — the advance-filter page's export.
//
// Same 40 columns the classic 3-Month Study ships (so the file opens in the
// same sheets and habits), PLUS the three columns that make this page worth
// exporting at all:
//
//   • **Score (purana)** — what the old rules would have said,
//   • **Farq**          — naya − purana, so the corrections are visible,
//   • **Chhoota kyun**  — which gate held the row back (blank when it didn't).
//
// Delivery is NOT duplicated: the files and the recap text are handed to the
// classic `StudyDeliveryService`, so WhatsApp / Excel / CSV / Telegram behave
// exactly as they do everywhere else in the app.
// ---------------------------------------------------------------------------

import 'dart:io';

import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';

import '../study/study_delivery.dart' show StudyExportKind;
import '../study/study_export.dart';
import 'study_adv_filters.dart';

class StudyAdvExportService {
  StudyAdvExportService();

  /// The classic 40, then the three this page adds.
  static const List<String> headers = [
    ...StudyExportService.headers,
    'Score (purana)',
    'Farq',
    'Chhoota kyun',
  ];

  /// Where 'Score' sits in the classic 40 — the one cell this page rewrites.
  static const int scoreIndex = 5;

  static List<ExportCell> rowCells(StudyAdvRow row) {
    final cells = StudyExportService.rowCells(row.row);
    // The classic file rounds the score to a whole number. This page prints
    // the new score next to the old one, so both have to read in the same
    // units — otherwise 11 vs 9.5 leaves a reader doing the maths twice.
    cells[scoreIndex] = TextCellValue(row.row.score.toStringAsFixed(1));

    return [
      ...cells,
      TextCellValue(
        row.classic == null ? '' : row.classic!.score.toStringAsFixed(1),
      ),
      TextCellValue(row.classic == null ? '' : _signed(row.scoreDelta)),
      TextCellValue(row.blocked ? row.gate!.label : ''),
    ];
  }

  static String _signed(double value) =>
      '${value >= 0 ? '+' : '−'}${value.abs().toStringAsFixed(1)}';

  static String defaultFileName(DateTime asOf, {bool csv = false}) =>
      'NiveshDesk-3M-Advance-Filter-${StudyExportService.isoDate(asOf)}.'
      '${csv ? 'csv' : 'xlsx'}';

  /// Three sheets, like the classic workbook: Read Me, every stock, best buys.
  Future<File> writeXlsx({
    required List<StudyAdvRow> rows,
    required FnoStudyExportMeta meta,
    String? fileName,
  }) async {
    final book = Excel.createExcel();

    final readMe = book['Read Me'];
    for (final line in _readMe(meta)) {
      readMe.appendRow([for (final cell in line) cell ?? TextCellValue('')]);
    }

    final all = book['Sabhi Stock'];
    _appendHeader(all);
    for (final row in rows) {
      all.appendRow([for (final cell in rowCells(row)) cell ?? TextCellValue('')]);
    }

    final best = book['Best Buy'];
    _appendHeader(best);
    final bestRows = rows.where((r) => r.row.isBestBuy).toList();
    if (bestRows.isEmpty) {
      best.appendRow([
        TextCellValue('Aaj koi stock 🎯 Best Buy criteria pe nahi utra. '
            'Neeche top 20 stocks (naye score ke hisaab se) hain.'),
      ]);
    }
    for (final row in (bestRows.isEmpty ? rows.take(20) : bestRows)) {
      best.appendRow([for (final cell in rowCells(row)) cell ?? TextCellValue('')]);
    }

    if (book.sheets.containsKey('Sheet1')) book.delete('Sheet1');

    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/${fileName ?? defaultFileName(meta.asOf)}');
    await file.writeAsBytes(book.encode()!, flush: true);
    return file;
  }

  Future<File> writeCsv({
    required List<StudyAdvRow> rows,
    required FnoStudyExportMeta meta,
    String? fileName,
  }) async {
    final buffer = StringBuffer()
      ..writeln('# NiveshDesk — 3 Month Study with Advance Filter')
      ..writeln('# Score = naye (sudhaare hue) niyam · Score (purana) = '
          'classic study ke niyam')
      ..writeln('# ${StudyExportService.disclaimer}')
      ..writeln(headers.map(_csv).join(','));

    for (final row in rows) {
      buffer.writeln(rowCells(row).map((cell) => _csv(_text(cell))).join(','));
    }

    final dir = await getApplicationDocumentsDirectory();
    final file = File(
        '${dir.path}/${fileName ?? defaultFileName(meta.asOf, csv: true)}');
    await file.writeAsString(buffer.toString(), flush: true);
    return file;
  }

  /// The WhatsApp/Telegram recap: top 12 by the new score, both scores on each
  /// line, and an honest head-count at the end.
  String recap(List<StudyAdvRow> rows, FnoStudyExportMeta meta) {
    final buffer = StringBuffer()
      ..writeln('NiveshDesk — 3M Study with Advance Filter')
      ..writeln('${StudyExportService.isoDate(meta.asOf)} · '
          '${meta.rowCount} stock · ${meta.bestBuyCount} 🎯 Best Buy')
      ..writeln();

    final top = [...rows]
      ..sort((a, b) => b.row.score.compareTo(a.row.score));
    for (final row in top.take(12)) {
      final classic = row.classic;
      buffer
        ..write('${row.row.rank}. ${row.row.symbol} — '
            'naya ${row.row.score.toStringAsFixed(1)}')
        ..write(classic == null
            ? ' (purana nahi mila)'
            : ' | purana ${classic.score.toStringAsFixed(1)} '
                '(${_signed(row.scoreDelta)})')
        ..writeln(' · ${row.row.opportunityTag}');
      if (row.blocked) buffer.writeln('   chhoota: ${row.gate!.label}');
    }

    buffer
      ..writeln()
      ..writeln(StudyExportService.disclaimer);
    return buffer.toString();
  }

  List<List<ExportCell?>> _readMe(FnoStudyExportMeta meta) => [
        ...StudyExportService.readMeSheet(meta),
        [TextCellValue('')],
        [
          TextCellValue(
            'Ye file "3 Month Study with Advance Filter" page ki hai — purane '
            '"3-Month Study" page ke hisaab se yahan kuch niyam sudhaare gaye '
            'hain (🎯 ke liye edge bhi chahiye, doori ka ek hi paimaana, '
            'adhura mahina poora mahina nahi, expiry paas to 🎯 nahi).',
          ),
        ],
        [
          TextCellValue(
            'Score = naye niyam ka score. Score (purana) = wahi stock, wahi '
            'data, classic niyam ke saath. Farq = naya − purana. (Classic '
            'file score ko poore ank mein likhti hai; yahan dono ek hi '
            'paimaane par hain — ek dashamlav tak.)',
          ),
        ],
        [
          TextCellValue(
            'Chhoota kyun: is page ke filter ne row ko rok diya tha '
            '(kam turnover / aaj expiry / expiry paas / score kam).',
          ),
        ],
      ];

  static void _appendHeader(Sheet sheet) =>
      sheet.appendRow([for (final header in headers) TextCellValue(header)]);

  /// A cell as text — `CellValue` is sealed and each kind carries a different
  /// type, so the writer needs one place that knows all of them.
  static String _text(ExportCell cell) => switch (cell) {
        null => '',
        TextCellValue() => cell.value.toString(),
        IntCellValue() => '${cell.value}',
        DoubleCellValue() => '${cell.value}',
        BoolCellValue() => '${cell.value}',
        _ => cell.toString(),
      };

  static String _csv(String value) {
    final escaped = value.replaceAll('"', '""');
    return '"$escaped"';
  }
}

/// Which ways out the page offers — the classic four, unchanged.
typedef StudyAdvExportKind = StudyExportKind;
