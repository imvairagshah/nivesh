// ---------------------------------------------------------------------------
// study_adv_volatility.dart — IV vs RV: "option mehnge hain ya saste?"
//
// This is the question a rupee figure cannot answer. IV 18 % means nothing on
// its own: if the stock has actually been moving 24 % a year, that 18 % is
// CHEAP (you are buying movement below what it delivers); if it has been
// moving 12 %, the same 18 % is expensive.
//
//   VRP = IV − RV   (both annualised, in percent)
//       >  0 → the option is pricing more movement than the stock delivers
//       <  0 → the option is cheap against the stock's own behaviour
//
// It is an observation about the past, not a forecast — the page says so.
//
// Pure: no Flutter, no database, no network.
// ---------------------------------------------------------------------------

import 'dart:math' as math;

import '../../../data/remote/dto/candle.dart';

/// Trading sessions in a year — the yardstick RV is annualised with.
const int kSessionsPerYear = 252;

/// Realised volatility over [window] sessions, annualised, in percent.
///
/// Close-to-close log returns, **sample** standard deviation (n−1), scaled by
/// √252. Null when there is not enough clean history — a blank is honest, a
/// number out of thin air is not.
double? realisedVolatility(List<Candle> bars, {int window = 20}) {
  if (bars.length < window + 1) return null;

  final closes = <double>[];
  for (final bar in bars) {
    final close = bar.close;
    if (close <= 0 || close.isNaN || close.isInfinite) return null;
    closes.add(close);
  }
  if (closes.length < window + 1) return null;

  final recent = closes.sublist(closes.length - (window + 1));
  final returns = <double>[];
  for (var i = 1; i < recent.length; i++) {
    returns.add(math.log(recent[i] / recent[i - 1]));
  }
  if (returns.length < 2) return null;

  final mean = returns.reduce((a, b) => a + b) / returns.length;
  final variance = returns
          .map((r) => (r - mean) * (r - mean))
          .reduce((a, b) => a + b) /
      (returns.length - 1);

  return math.sqrt(variance) * math.sqrt(kSessionsPerYear) * 100;
}

/// What the gap between IV and RV means, in the user's words.
enum VrpVerdict {
  /// IV is well above what the stock has actually been doing.
  expensive('mehnga', 'IV, asli hilchal se zyada — bechne wale ki bazaari'),

  /// IV is below the stock's own movement.
  cheap('sasta', 'IV, asli hilchal se kam — kharidne wale ko sasta mil raha'),

  /// Inside the noise band.
  fair('theek-thaak', 'IV aur asli hilchal paas-paas — koi khaas fayda nahi'),

  /// No IV for this stock (degraded row, or no scan yet).
  unknown('IV nahi', 'Is stock ki IV nahi mili');

  const VrpVerdict(this.label, this.hint);

  final String label;
  final String hint;
}

/// One stock on the volatility tab.
class StudyVolatilityRow {
  const StudyVolatilityRow({
    required this.symbol,
    required this.ltp,
    this.iv,
    this.rv,
    this.window = 20,
  });

  final String symbol;
  final double ltp;

  /// Implied volatility in percent (from the scan: broker, or our own solve).
  final double? iv;

  /// Realised volatility in percent over the last [window] sessions.
  final double? rv;

  final int window;

  /// IV − RV, in **percentage points**. Null when either side is missing.
  double? get vrp {
    final i = iv;
    final r = rv;
    if (i == null || r == null) return null;
    return i - r;
  }

  /// IV ÷ RV. `1.0` = priced exactly at what the stock delivers.
  double? get vrpRatio {
    final i = iv;
    final r = rv;
    if (i == null || r == null || r <= 0) return null;
    return i / r;
  }

  /// How far IV must be from RV before the page calls it anything at all.
  /// Two points is inside the day-to-day noise of both estimates.
  static const double deadBand = 2.0;

  VrpVerdict get verdict {
    final gap = vrp;
    if (gap == null) return VrpVerdict.unknown;
    if (gap >= deadBand) return VrpVerdict.expensive;
    if (gap <= -deadBand) return VrpVerdict.cheap;
    return VrpVerdict.fair;
  }

  /// `+4.1` / `−2.6` / `—`, signed so the table reads at a glance.
  String get vrpText {
    final gap = vrp;
    if (gap == null) return '—';
    return '${gap >= 0 ? '+' : '−'}${gap.abs().toStringAsFixed(1)}';
  }
}

/// The volatility table: every stock with its IV, its own movement, and the
/// gap between them.
///
/// Sorted **mehnga pehle** — a seller works from the top, a buyer from the
/// bottom, and neither has to sort the page to do it.
List<StudyVolatilityRow> buildVolatility({
  required Map<String, List<Candle>> bars,
  required Map<String, double> ivBySymbol,
  int window = 20,
}) {
  final rows = <StudyVolatilityRow>[];

  for (final entry in bars.entries) {
    final symbol = entry.key;
    final series = entry.value;
    if (series.isEmpty) continue;

    final rv = realisedVolatility(series, window: window);
    final iv = ivBySymbol[symbol];
    // A stock with neither number teaches nothing — leave it out entirely
    // rather than filling the table with dashes.
    if (rv == null && iv == null) continue;

    rows.add(StudyVolatilityRow(
      symbol: symbol,
      ltp: series.last.close,
      iv: iv,
      rv: rv,
      window: window,
    ));
  }

  rows.sort((a, b) {
    // Rows with a verdict first, then by the size of the gap (biggest first).
    final aGap = a.vrp;
    final bGap = b.vrp;
    if (aGap == null && bGap != null) return 1;
    if (bGap == null && aGap != null) return -1;
    if (aGap != null && bGap != null && aGap != bGap) {
      return bGap.compareTo(aGap);
    }
    return a.symbol.compareTo(b.symbol);
  });

  return rows;
}
