// ---------------------------------------------------------------------------
// study_adv_filters.dart — the model behind "3 Month Study with Advance Filter".
//
// Two things this page owns that the classic study does not:
//
//   1. FILTERS WITH A REASON. Every row that fails a filter keeps a gate and a
//      line (`turnover 4.2 cr < 10 cr`), so the list can never shrink without
//      saying why — the 1.5.17 lesson, applied up front.
//   2. TWO SCORES SIDE BY SIDE. Each row carries the corrected (advanced) row
//      and, when it exists, the same stock scored by the classic rules. The
//      point is comparison, not replacement: nothing here changes what the
//      old page prints.
//
// Pure — no Flutter, no database, no network — so the filter rules are unit
// tested directly.
// ---------------------------------------------------------------------------

import '../study/study_engine.dart';

/// Why a row is not on the list.
enum AdvGate {
  /// Aaj expiry hai — theta aur pin risk ka din.
  expiryDay('aaj expiry'),

  /// Expiry bahut paas — buyer ke liye theta, seller ke liye gap.
  nearExpiry('expiry paas'),

  /// 20-din ka average turnover kam — jise aap bhar hi nahi sakte.
  turnover('turnover kam'),

  /// Results paas hain — gap risk ka din (B3). Sirf NSE ki announced date.
  results('results paas'),

  /// Naye (corrected) score se neeche.
  score('score kam');

  const AdvGate(this.label);

  final String label;
}

/// What the advance-filter page lets the user turn.
class StudyAdvFilters {
  const StudyAdvFilters({
    this.minScore = 0,
    this.minTurnoverCrore = 10,
    this.blockExpiryDay = true,
    this.blockNearExpiryDays = 0,
    this.blockResultsDays = 0,
  });

  /// New (advanced) score ke neeche wale chhup jayein. `0` = filter band.
  final double minScore;

  /// ₹ crore/day, 20-session average. `0` = filter band.
  final double minTurnoverCrore;

  /// Aaj expiry hai → trade mat lo. Default ON: ye sirf nuksan se bachata hai,
  /// list nahi ghatata (ek din me 1-2 stock hi hote hain aise).
  final bool blockExpiryDay;

  /// `3` ka matlab: jisme 3 ya kam din bache hain wo bhi bahar. Default OFF —
  /// ye seedha list chhota karta hai, is liye user khud chalayega.
  final int blockNearExpiryDays;

  /// `5` ka matlab: jiske results 5 din ke andar hain (aaj bhi shamil) wo
  /// bahar. Default OFF — 1.5.17 ka rule: nayi rok band rahe, chip dikhe.
  ///
  /// Sirf **NSE ki announced** date ginti hai (1.5.14); anumaan se kisi ko
  /// nahi roka jata. Dates na milin to ye gate kisi ko nahi rokta — aur page
  /// likh kar batata hai.
  final int blockResultsDays;

  static const StudyAdvFilters defaults = StudyAdvFilters();

  StudyAdvFilters copyWith({
    double? minScore,
    double? minTurnoverCrore,
    bool? blockExpiryDay,
    int? blockNearExpiryDays,
    int? blockResultsDays,
  }) =>
      StudyAdvFilters(
        minScore: minScore ?? this.minScore,
        minTurnoverCrore: minTurnoverCrore ?? this.minTurnoverCrore,
        blockExpiryDay: blockExpiryDay ?? this.blockExpiryDay,
        blockNearExpiryDays: blockNearExpiryDays ?? this.blockNearExpiryDays,
        blockResultsDays: blockResultsDays ?? this.blockResultsDays,
      );

  /// `score 6+ · turnover 10 cr+ · aaj expiry chhod`
  String get line {
    final parts = <String>[
      if (minScore > 0) 'score ${minScore.toStringAsFixed(0)}+',
      if (minTurnoverCrore > 0)
        'turnover ${minTurnoverCrore.toStringAsFixed(0)} cr+',
      if (blockExpiryDay) 'aaj expiry chhod',
      if (blockNearExpiryDays > 0) 'expiry ≤ $blockNearExpiryDays din chhod',
      if (blockResultsDays > 0) 'results ≤ $blockResultsDays din chhod',
    ];
    return parts.isEmpty ? 'koi filter nahi' : parts.join(' · ');
  }
}

/// One stock on the advance-filter page: the corrected row, the classic row,
/// and the gate that kept it off the list (if any).
class StudyAdvRow {
  const StudyAdvRow({
    required this.row,
    this.classic,
    this.gate,
    this.daysToResults,
  });

  /// Scored with [StudyRules.advanced] — this page's own numbers.
  final StudyRow row;

  /// The same stock, same data, scored with the classic rules (what the old
  /// page and the AI Suggestion gate would say). Null only if the second pass
  /// was not asked for.
  final StudyRow? classic;

  /// Non-null when a filter removed it. The row is still kept — that is the
  /// whole difference between a filter and a silent disappearance.
  final AdvGate? gate;

  /// Calendar days to the next announced results date (null = none known).
  ///
  /// Kept on the row so the card can say "results 2 din me" even when the
  /// gate is off — a number the user is about to trade into should not wait
  /// for a filter.
  final int? daysToResults;

  bool get blocked => gate != null;

  double get turnoverCrore => row.turnoverCrore;

  /// Naya score minus purana score: `−1.5` matlab naye niyam ne ise neeche
  /// rakha (teaching the user what the corrections did).
  double get scoreDelta => classic == null ? 0 : row.score - classic!.score;

  /// `turnover 4.2 cr < 10 cr` — the number that failed, next to the bar.
  String gateLine(StudyAdvFilters filters) => switch (gate) {
        null => '',
        AdvGate.expiryDay => 'aaj expiry hai',
        AdvGate.nearExpiry =>
          'expiry ${row.daysToExpiry} din baad (≤ ${filters.blockNearExpiryDays})',
        AdvGate.results => 'results $daysToResults din me '
            '(≤ ${filters.blockResultsDays} din — NSE ki date)',
        AdvGate.turnover =>
          'turnover ${turnoverCrore.toStringAsFixed(1)} cr < '
              '${filters.minTurnoverCrore.toStringAsFixed(0)} cr',
        AdvGate.score => 'score ${row.score.toStringAsFixed(1)} < '
            '${filters.minScore.toStringAsFixed(0)}',
      };
}

/// Why a row failed, and how many failed with it — the "kaun chhoota" sheet.
class AdvGateGroup {
  const AdvGateGroup(this.gate, this.rows);

  final AdvGate gate;
  final List<StudyAdvRow> rows;

  int get count => rows.length;
}

/// The whole advance-filter run.
class StudyAdvResult {
  const StudyAdvResult({
    required this.rows,
    required this.filters,
    required this.asOf,
    required this.duration,
    required this.scanned,
    this.cancelled = false,
  });

  /// Every scored stock, blocked ones included (they carry their gate).
  final List<StudyAdvRow> rows;

  final StudyAdvFilters filters;
  final DateTime asOf;
  final Duration duration;
  final int scanned;
  final bool cancelled;

  List<StudyAdvRow> get visible => [for (final r in rows) if (!r.blocked) r];
  List<StudyAdvRow> get blocked => [for (final r in rows) if (r.blocked) r];

  /// Rows whose new score moved them off a 🎯 the classic rules would have
  /// given them — the single most useful thing this page shows.
  List<StudyAdvRow> get downgraded => [
        for (final r in rows)
          if (!r.blocked &&
              (r.classic?.isBestBuy ?? false) &&
              !r.row.isBestBuy)
            r,
      ];

  int get bestBuys => visible.where((r) => r.row.isBestBuy).length;

  /// Rows whose history never even filled the study's own 63-session window —
  /// their "3-month" numbers cover less than three months, and the page says so.
  int get shortHistoryRows =>
      rows.where((r) => r.row.bars < kStudyWindowBars).length;

  bool get hasShortHistory => shortHistoryRows > 0;

  List<AdvGateGroup> get gateGroups {
    final groups = <AdvGate, List<StudyAdvRow>>{};
    for (final row in blocked) {
      groups.putIfAbsent(row.gate!, () => <StudyAdvRow>[]).add(row);
    }
    return [
      for (final entry in groups.entries) AdvGateGroup(entry.key, entry.value),
    ]..sort((a, b) => b.count.compareTo(a.count));
  }

  /// `213 scan · 168 list me · 45 filter se bahar (28 turnover · 17 score)`
  String get funnelLine {
    final blocked = this.blocked.length;
    final parts = <String>[
      '$scanned scan hue',
      '${visible.length} list me',
      '$blocked filter se bahar',
    ];
    if (blocked > 0) {
      final detail = [
        for (final group in gateGroups) '${group.count} ${group.gate.label}',
      ].join(' · ');
      parts.add('($detail)');
    }
    return parts.join(' · ');
  }
}

/// Applies the filters to one row and says which gate stopped it.
///
/// Order matters: an expiry-day block is reported before a turnover miss,
/// because "aaj expiry hai" is the reason a trader actually cares about.
AdvGate? gateFor(
  StudyRow row,
  StudyAdvFilters filters, {
  /// Calendar days to the next announced results date (null = unknown).
  int? daysToResults,
}) {
  final dte = row.daysToExpiry;
  if (filters.blockExpiryDay && dte != null && dte <= 0) {
    return AdvGate.expiryDay;
  }
  if (filters.blockNearExpiryDays > 0 &&
      dte != null &&
      dte <= filters.blockNearExpiryDays) {
    return AdvGate.nearExpiry;
  }
  // Results: a gap risk like expiry, so it is reported at the same height.
  // Only a date NSE itself announced counts (1.5.14) — never a guess.
  if (filters.blockResultsDays > 0 &&
      daysToResults != null &&
      daysToResults >= 0 &&
      daysToResults <= filters.blockResultsDays) {
    return AdvGate.results;
  }
  if (filters.minTurnoverCrore > 0 && row.turnoverCrore < filters.minTurnoverCrore) {
    return AdvGate.turnover;
  }
  if (row.score < filters.minScore) return AdvGate.score;
  return null;
}

/// Pairs the two rule sets, applies the gates, and sorts: 🎯 pehle, phir naya
/// score ghata-te hue, tie par naam (kabhi shuffle nahi hota).
List<StudyAdvRow> buildAdvRows(
  List<StudyRow> advanced,
  Map<String, StudyRow> classic,
  StudyAdvFilters filters, {

  /// `SYMBOL → announced results date`. Plain dates, not service objects, so
  /// this file stays pure and the rule is testable without any network.
  Map<String, DateTime> resultsDates = const {},
  DateTime? asOf,
}) {
  final today = asOf ?? DateTime.now();
  final day = DateTime(today.year, today.month, today.day);

  // Symbols arrive in whatever case the feed used; normalise once so a
  // lower-cased calendar still matches an upper-cased row.
  final bySymbol = <String, DateTime>{
    for (final entry in resultsDates.entries)
      entry.key.trim().toUpperCase(): entry.value,
  };

  int? daysTo(String symbol) {
    final date = bySymbol[symbol.trim().toUpperCase()];
    if (date == null) return null;
    final midnight = DateTime(date.year, date.month, date.day);
    return midnight.difference(day).inDays;
  }

  final rows = <StudyAdvRow>[
    for (final row in advanced)
      StudyAdvRow(
        row: row,
        classic: classic[row.symbol],
        daysToResults: daysTo(row.symbol),
        gate: gateFor(row, filters, daysToResults: daysTo(row.symbol)),
      ),
  ];

  rows.sort((a, b) {
    // Rows the filters removed go last — they are kept for the "kaun chhoota"
    // sheet, but they must never push a tradable row down the list.
    final aBlocked = a.blocked ? 1 : 0;
    final bBlocked = b.blocked ? 1 : 0;
    if (aBlocked != bBlocked) return aBlocked - bBlocked;
    final aBest = a.row.isBestBuy ? 0 : 1;
    final bBest = b.row.isBestBuy ? 0 : 1;
    if (aBest != bBest) return aBest - bBest;
    final byScore = b.row.score.compareTo(a.row.score);
    if (byScore != 0) return byScore;
    return a.row.symbol.compareTo(b.row.symbol);
  });

  return rows;
}
