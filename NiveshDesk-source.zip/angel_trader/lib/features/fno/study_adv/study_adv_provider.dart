// ---------------------------------------------------------------------------
// study_adv_provider.dart — state for "3 Month Study with Advance Filter".
//
// Thin on purpose: it resolves the F&O universe (the same list the classic
// study and the AI Suggestion scan use, so all three can never disagree about
// what "the universe" is), runs the two jobs the page offers, and owns the
// progress/cancel plumbing. Every number comes from the pure layers.
//
// Nothing runs by itself — a study costs history and requests, so the user
// asks for it.
// ---------------------------------------------------------------------------

import 'dart:async' show unawaited;
import 'dart:math' as math;

import 'package:flutter/foundation.dart';

import '../../../core/utils/markets.dart';
import '../study/iv_sheet.dart';
import '../../../data/local/dao/ipo_dao.dart';
import '../../../data/local/dao/scrip_dao.dart';
import '../../../services/fno_study_service.dart' show FnoStudyProgress;
import '../../../services/fno_universe.dart';
import '../../../services/scrip_master_service.dart';
import '../../../services/universe_catalog.dart';
import '../../../services/earnings_calendar_service.dart';
import '../../../services/live_feed_service.dart';
import '../../settings/settings_provider.dart';
import '../../../data/local/dao/trade_dao.dart';
import '../../../data/local/models/study_snapshot.dart';
import '../../../data/remote/dto/candle.dart';
import '../study/study_engine.dart';
import '../study/study_export.dart' show FnoStudyExportMeta;
import '../study/black_scholes.dart' show OptionType;
import 'study_adv_analysis.dart';
import 'study_adv_backtest.dart';
import 'study_adv_mytrades.dart';
import 'study_adv_plan.dart';
import 'study_adv_filters.dart';
import 'study_adv_service.dart';

enum StudyAdvStatus { idle, resolving, running, ready, error }

/// What the table can be sorted by.
enum StudyAdvSort {
  score('Score (naya)'),
  classic('Score (purana)'),
  delta('Farq'),
  edge('Edge %'),
  ltp('Price'),
  move('3M Move %'),
  trend('Trend'),
  turnover('Turnover'),
  atr('ATR %'),
  symbol('Naam'),
  // 1.5.76 — IV sheet ke IVP/IVR se sort (option BUY: sasta premium pehle).
  // In menu entries ka order label me fixed hai — tap = seedha wahi order.
  ivpAsc('IVP (sasta pehle)'),
  ivpDesc('IVP (mehenga pehle)'),
  ivrAsc('IVR (low pehle)'),
  ivrDesc('IVR (high pehle)');

  const StudyAdvSort(this.label);

  final String label;

  /// Fixed-order entries: label jo promise karta hai wahi order, toggle nahi.
  bool get fixedDirection =>
      this == ivpAsc || this == ivpDesc || this == ivrAsc || this == ivrDesc;

  bool get fixedDescending => this == ivpDesc || this == ivrDesc;
}

class StudyAdvProvider extends ChangeNotifier {
  StudyAdvProvider({
    required StudyAdvService service,
    required ScripDao scripDao,
    required IpoDao ipoDao,
    required ScripMasterService scripMaster,
    required LiveFeedService feed,
    required SettingsProvider settings,
    required EarningsCalendarService earnings,
    TradeDao? trades,
    FnoUniverse? fnoUniverse,
  })  : _service = service,
        _scripDao = scripDao,
        _ipoDao = ipoDao,
        _scripMaster = scripMaster,
        _feed = feed,
        _settings = settings,
        _earnings = earnings,
        _trades = trades,
        _fno = fnoUniverse;

  final StudyAdvService _service;
  final ScripDao _scripDao;
  final IpoDao _ipoDao;
  final ScripMasterService _scripMaster;

  /// Shared with every other screen: one WebSocket session for the whole app.
  final LiveFeedService _feed;
  final SettingsProvider _settings;
  final EarningsCalendarService _earnings;

  /// Paper trades ka hisaab — app-level shared DAO (nullable: purane tests
  /// bina iske chalte hain).
  final TradeDao? _trades;

  FnoUniverse? _fno;

  /// Namespace under which this page registers its WebSocket extras.
  static const String feedOwner = 'fno_study_adv';

  StudyAdvStatus _status = StudyAdvStatus.idle;
  StudyAdvResult? _result;
  StudyScoreBacktest? _backtest;
  FnoStudyProgress? _progress;
  String? _error;
  String? _note;
  bool _cancelled = false;
  bool _stale = false;

  StudyAdvFilters _filters = StudyAdvFilters.defaults;
  StudyAdvSort _sort = StudyAdvSort.score;
  bool _sortDescending = true;

  /// Which of the two jobs is running (`null` when nothing is).
  String? _job;

  /// The row whose detail panel is open (`null` = nothing open).
  String? _expandedSymbol;
  final List<String> _liveSubscribed = <String>[];

  /// Results calendar: `SYMBOL → EarningsInfo`, filled on first expand.
  Map<String, EarningsInfo> _earningsMap = const {};
  bool _earningsLoading = false;
  String? _earningsNote;

  int _years = 1;
  int _horizonBars = 10;

  // ---- offline analysis (IVP/IVR, DP, trend) ------------------------------

  /// Phone me maujood candles — ek hi baar padhe jate hain, phir har window
  /// badalne par dobara padhne ki zaroorat nahi.
  Map<String, List<Candle>> _bars = const {};
  StudyAdvAnalysis? _analysis;
  bool _analysisLoading = false;
  String? _analysisError;

  /// Plan (B4): khule hue row ke candles — sirf utna hi padha jata hai.
  final Map<String, List<Candle>> _planBars = {};
  final Map<String, TradePlan> _plans = {};

  /// Paper trades ka aaina (4tha tab).
  MyTradesReport? _myTrades;
  bool _myTradesLoading = false;
  String? _myTradesError;

  UniverseResolution _universe = UniverseResolution.empty;

  // ---- getters ------------------------------------------------------------

  StudyAdvStatus get status => _status;
  StudyAdvResult? get result => _result;
  StudyScoreBacktest? get backtest => _backtest;
  FnoStudyProgress? get progress => _progress;
  String? get error => _error;
  String? get note => _note;
  bool get stale => _stale;

  StudyAdvFilters get filters => _filters;
  StudyAdvSort get sort => _sort;
  bool get sortDescending => _sortDescending;

  int get years => _years;
  int get horizonBars => _horizonBars;

  bool get busy => _status == StudyAdvStatus.running || _status == StudyAdvStatus.resolving;
  bool get running => _status == StudyAdvStatus.running;
  bool get hasResult => _result != null && _result!.rows.isNotEmpty;
  String? get job => _job;

  int get universeSize => _universe.size;

  /// Offline analysis ke liye padhe gaye candles (`SYMBOL → candles`).
  Map<String, List<Candle>> get bars => _bars;

  StudyAdvAnalysis? get analysis => _analysis;
  bool get analysisLoading => _analysisLoading;
  String? get analysisError => _analysisError;
  bool get hasAnalysis => _analysis != null && !_analysis!.isEmpty;

  /// "Aaj kya kare" wala plan — row khulte hi banta hai (offline).
  TradePlan? planFor(String symbol) => _plans[symbol.trim().toUpperCase()];

  /// Plan ke liye is stock ke candles mile ya nahi.
  bool planReady(String symbol) =>
      _planBars.containsKey(symbol.trim().toUpperCase());

  MyTradesReport? get myTrades => _myTrades;
  bool get myTradesLoading => _myTradesLoading;
  String? get myTradesError => _myTradesError;
  double get progressValue => _progress?.fraction ?? 0;
  String get progressLine => _progress?.label ?? '';

  /// Rows after sorting — what the table and any export would use.
  List<StudyAdvRow> get rows {
    final result = _result;
    if (result == null) return const <StudyAdvRow>[];
    final list = [...result.visible]..sort(_compare);
    return list;
  }

  /// Blocked rows, grouped and ready for the "kaun chhoota" sheet.
  List<AdvGateGroup> get gateGroups => _result?.gateGroups ?? const <AdvGateGroup>[];

  /// Rows the corrected rules demoted from a 🎯 the classic rules gave them.
  List<StudyAdvRow> get downgraded => _result?.downgraded ?? const <StudyAdvRow>[];

  // ---- the open row (detail panel, live premiums, results) ----------------

  String? get expandedSymbol => _expandedSymbol;

  /// The advanced row behind the open panel (`null` when nothing is open).
  StudyRow? get expandedRow {
    final symbol = _expandedSymbol;
    if (symbol == null) return null;
    for (final row in _result?.rows ?? const <StudyAdvRow>[]) {
      if (row.row.symbol == symbol) return row.row;
    }
    return null;
  }

  /// The same stock's classic row, so the panel can show both scores.
  StudyRow? get expandedClassic {
    final symbol = _expandedSymbol;
    if (symbol == null) return null;
    for (final row in _result?.rows ?? const <StudyAdvRow>[]) {
      if (row.row.symbol == symbol) return row.classic;
    }
    return null;
  }

  /// Live premiums for the two ATM legs, `{'CE': 42.5, 'PE': 38.4}`.
  Map<String, double> get livePremiums =>
      _liveFor([expandedRow?.ce, expandedRow?.pe]);

  /// Live premiums for the kal wale ATM legs (same keys).
  Map<String, double> get liveKalPremiums =>
      _liveFor([expandedRow?.kalCe, expandedRow?.kalPe]);

  /// Live premiums for the OTM jodi (strangle).
  Map<String, double> get liveStrangle =>
      _liveFor([expandedRow?.strangle?.ce, expandedRow?.strangle?.pe]);

  /// Live premiums for the kal wali OTM jodi.
  Map<String, double> get liveKalStrangle =>
      _liveFor([expandedRow?.kalStrangle?.ce, expandedRow?.kalStrangle?.pe]);

  Map<String, double> _liveFor(List<StudyOptionLeg?> legs) {
    final map = <String, double>{};
    for (final leg in legs) {
      if (leg == null) continue;
      final tick =
          _feed.ticksBySubscription['${Exchange.nfo.wsType}:${leg.token}'];
      final ltp = tick?.ltp;
      if (ltp == null) continue;
      map[leg.type == OptionType.call ? 'CE' : 'PE'] = ltp;
    }
    return map;
  }

  bool get liveFeedActive => _settings.settings.liveFeedEnabled;

  Map<String, EarningsInfo> get earnings => _earningsMap;
  bool get isLoadingEarnings => _earningsLoading;
  String? get earningsNote => _earningsNote;

  EarningsInfo? earningsFor(String symbol) =>
      _earningsMap[symbol.trim().toUpperCase()];

  /// `SYMBOL → results date`, NSE-announced only (1.5.14). Plain dates so the
  /// gate rule stays pure; an empty map means the gate blocks nobody.
  Map<String, DateTime> _resultsDates() => {
        for (final entry in _earningsMap.entries)
          if (entry.value.announcedNext case final date?) entry.key: date,
      };

  /// Company results: SQLite cache first, NSE at most once a day.
  Future<void> ensureEarnings() async {
    if (_earningsLoading) return;
    _earningsLoading = true;
    _notify();
    try {
      final calendar = await _earnings.load();
      _earningsMap = calendar.bySymbol;
      _earningsNote = calendar.isEmpty
          ? (_earnings.note ?? 'NSE ke results feed me kuch nahi mila.')
          : _earnings.note;
    } catch (e) {
      _earningsNote = 'Results dates nahi mili ($e).';
    } finally {
      _earningsLoading = false;
      _notify();
    }
  }

  /// Metadata the export carries into its Read Me / recap.
  FnoStudyExportMeta get exportMeta {
    final result = _result;
    final rows = this.rows;
    return FnoStudyExportMeta(
      asOf: result?.asOf ?? DateTime.now(),
      runAt: result?.asOf ?? DateTime.now(),
      rowCount: rows.length,
      bestBuyCount: rows.where((r) => r.row.isBestBuy).length,
      withOptions: rows.where((r) => r.row.avgIv != null).length,
    );
  }

  /// Opens (or closes) a row's detail panel, and moves the live subscription
  /// with it — the two legs of the open row keep ticking, nothing else does.
  void toggleExpanded(StudyAdvRow row) {
    _expandedSymbol = _expandedSymbol == row.row.symbol ? null : row.row.symbol;
    if (_expandedSymbol != null) {
      unawaited(ensureEarnings());
      // Plan sirf khule hue stock ke liye banta hai — 213 stock ke candles
      // ek saath padhne ki zaroorat nahi.
      unawaited(ensurePlan(row.row.symbol));
    }
    _syncLiveSubscriptions();
    _notify();
  }

  void collapse() {
    _expandedSymbol = null;
    _syncLiveSubscriptions();
    _notify();
  }

  void _syncLiveSubscriptions() {
    _clearLiveSubscriptions();

    final row = expandedRow;
    if (row == null || !_settings.settings.liveFeedEnabled) {
      _feed.clearExtraSubscriptions(feedOwner);
      return;
    }

    // Today's ATM legs, the kal wale ATM legs, and both OTM jodis — exactly
    // the pairs the panel prints, so nothing on it freezes while the rest
    // moves.
    final seen = <String>{};
    final subscriptions = <FeedSubscription>[];
    for (final leg in [
      row.ce,
      row.pe,
      row.kalCe,
      row.kalPe,
      row.strangle?.ce,
      row.strangle?.pe,
      row.kalStrangle?.ce,
      row.kalStrangle?.pe,
    ]) {
      if (leg == null) continue;
      if (!seen.add(leg.token)) continue;
      subscriptions.add(FeedSubscription(
        token: leg.token,
        exchange: Exchange.nfo,
        priceKey: 'NFO:${leg.symbol}',
      ));
    }

    if (subscriptions.isEmpty) {
      _feed.clearExtraSubscriptions(feedOwner);
      return;
    }

    _liveSubscribed
      ..clear()
      ..addAll(subscriptions.map((sub) => sub.id));
    _feed.setExtraSubscriptions(feedOwner, subscriptions);
  }

  void _clearLiveSubscriptions() {
    if (_liveSubscribed.isEmpty) return;
    _liveSubscribed.clear();
    _feed.clearExtraSubscriptions(feedOwner);
  }

  /// Set in [dispose]: a late answer (the results calendar finishing after the
  /// page was closed) must not wake a dead notifier.
  bool _disposed = false;

  void _notify() {
    if (_disposed) return;
    notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _feed.clearExtraSubscriptions(feedOwner);
    super.dispose();
  }

  int Function(StudyAdvRow, StudyAdvRow) get _compare {
    final flip = _sortDescending ? -1 : 1;
    double? by(StudyAdvRow r) => switch (_sort) {
          StudyAdvSort.score => r.row.score,
          StudyAdvSort.classic => r.classic?.score ?? 0,
          StudyAdvSort.delta => r.scoreDelta,
          StudyAdvSort.edge => r.row.edgePct ?? -999,
          StudyAdvSort.ltp => r.row.ltp,
          StudyAdvSort.move => r.row.total3mPct,
          StudyAdvSort.turnover => r.turnoverCrore,
          StudyAdvSort.atr => r.row.atrPct,
          StudyAdvSort.trend => r.row.trend.index.toDouble(),
          StudyAdvSort.symbol => 0,
          // 1.5.76 — IV sheet se IVP/IVR (sheet set na ho to null = list me
          // sabse neeche, honest "no data").
          StudyAdvSort.ivpAsc || StudyAdvSort.ivpDesc =>
            IvSheetStore.instance.forSymbol(r.row.symbol)?.ivp,
          StudyAdvSort.ivrAsc || StudyAdvSort.ivrDesc =>
            IvSheetStore.instance.forSymbol(r.row.symbol)?.ivr,
        };
    return (a, b) {
      if (_sort == StudyAdvSort.symbol) {
        return flip * a.row.symbol.compareTo(b.row.symbol);
      }
      final av = by(a);
      final bv = by(b);
      if (av == null && bv == null) return a.row.symbol.compareTo(b.row.symbol);
      if (av == null) return 1; // IV value nahi = dono direction me last.
      if (bv == null) return -1;
      final diff = flip * av.compareTo(bv);
      return diff != 0 ? diff : a.row.symbol.compareTo(b.row.symbol);
    };
  }

  // ---- controls -----------------------------------------------------------

  void setFilters(StudyAdvFilters value) {
    _filters = value;
    _stale = _result != null;
    _notify();
  }

  void setMinScore(double value) => setFilters(_filters.copyWith(minScore: value));

  void setMinTurnover(double value) =>
      setFilters(_filters.copyWith(minTurnoverCrore: value));

  void setBlockExpiryDay(bool value) =>
      setFilters(_filters.copyWith(blockExpiryDay: value));

  void setBlockNearExpiry(int days) =>
      setFilters(_filters.copyWith(blockNearExpiryDays: days));

  /// `0` = results wali rok band.
  void setBlockResults(int days) =>
      setFilters(_filters.copyWith(blockResultsDays: days));

  void resetFilters() {
    _filters = StudyAdvFilters.defaults;
    _stale = _result != null;
    _notify();
  }

  void sortBy(StudyAdvSort column) {
    // 1.5.76 — IVP/IVR entries ka order label me fixed hai (sasta/mehenga,
    // low/high) — inme direction toggle nahi hota, seedha set hota hai.
    if (column.fixedDirection) {
      _sort = column;
      _sortDescending = column.fixedDescending;
      _notify();
      return;
    }
    if (_sort == column) {
      _sortDescending = !_sortDescending;
    } else {
      _sort = column;
      // Names read A→Z, and the trend ladder reads STRONG UP first — every
      // other column starts at its biggest number.
      _sortDescending =
          column != StudyAdvSort.symbol && column != StudyAdvSort.trend;
    }
    _notify();
  }

  void setYears(int value) {
    if (_years == value) return;
    _years = value;
    _stale = _backtest != null;
    _notify();
  }

  void setHorizon(int value) {
    if (_horizonBars == value) return;
    _horizonBars = value;
    _stale = _backtest != null;
    _notify();
  }

  // ---- universe -----------------------------------------------------------

  Future<void> bootstrap() => resolveUniverse();

  Future<void> resolveUniverse() async {
    _status = StudyAdvStatus.resolving;
    _notify();
    try {
      final fno = _fno ??= await FnoUniverse.load();
      _universe = await UniverseCatalog.resolve(
        UniverseCatalog.fno,
        scripDao: _scripDao,
        ipoDao: _ipoDao,
        resolver: await _scripMaster.resolver(),
        fnoSymbols: fno.symbols,
      );
      if (_universe.isEmpty) {
        _error = 'F&O stocks ke tokens nahi mile — Scrip master update karo.';
        _status = StudyAdvStatus.error;
      }
    } catch (e) {
      _error = 'Universe resolve nahi hua: $e';
      _status = StudyAdvStatus.error;
    } finally {
      if (_status == StudyAdvStatus.resolving) {
        _status = StudyAdvStatus.idle;
      }
      _notify();
    }
  }

  // ---- jobs ---------------------------------------------------------------

  /// The corrected study (both rule sets).
  Future<void> scan() => _runJob('scan', () async {
        // The results gate can only block a row it knows the date of, so the
        // calendar is loaded first — one cached NSE request for the whole
        // universe, never one per stock. Skipped when the gate is off.
        if (_filters.blockResultsDays > 0) await ensureEarnings();

        final result = await _service.run(
          universe: _universe.scrips,
          filters: _filters,
          companyNames: _fno?.companyNames ?? const {},
          resultsDates: _resultsDates(),
          // B1: the IV setting, so "apna hisaab" costs zero greek calls here
          // too.
          ivSource: StudyIvSource.fromName(_settings.settings.studyIvSource),
          onProgress: (p) {
            _progress = p;
            _notify();
          },
          isCancelled: () => _cancelled,
        );
        _result = result;
        _stale = false;
        _note = result.rows.isEmpty
            ? 'Is baar koi stock nahi mila.'
            : result.funnelLine;
        // "Mera hisaab" ke liye yaad rakho ki aaj study ne kya kaha — kal ka
        // nateeja aaj ke trade se milaya jayega.
        unawaited(_saveSnapshots());
        // Abhi-abhi history download hui hai — offline analysis usi se turant
        // tajja ho jaye, taaki user ko dobara dabana na pade.
        unawaited(analyse(force: true));
        if (result.hasShortHistory) {
          _note = '$_note · ${result.shortHistoryRows} stock ka itihaas 3 '
              'mahine se kam hai (kam data) — “kaun chhoota” me dekho.';
        }
        // A gate that could not see any date blocked nobody — say so rather
        // than letting an empty chip imply the list is results-free.
        if (_filters.blockResultsDays > 0 && _resultsDates().isEmpty) {
          _note = '$_note · Results dates NSE se nahi mili, is liye results '
              'wale filter ne kisi ko nahi roka.';
        }
      });

  /// Does the score actually order outcomes? (C1)
  Future<void> measure() => _runJob('measure', () async {
        final result = await _service.backtest(
          universe: _universe.scrips,
          config: StudyBacktestConfig(horizonBars: _horizonBars),
          years: _years,
          onProgress: (p) {
            _progress = p;
            _notify();
          },
          isCancelled: () => _cancelled,
        );
        _backtest = result;
        _stale = false;
        _note = result.isEmpty
            ? 'Is window me koi trade hi nahi bana.'
            : '${result.trades} trade · ${result.symbols} stock · '
                'ausat ${result.barsUsed} session har stock ke.';
      });

  /// "Aaj kya kare" wala plan: khule hue stock ke candles padho (sirf ek
  /// stock), ATR aur DP nikaalo, phir [buildTradePlan] se hisaab banao.
  ///
  /// Sab kuch phone me hai — ek bhi naya request nahi. Dobara nahi padha jata
  /// (ek baar mil gaye to yaad rahte hain).
  Future<void> ensurePlan(String symbol) async {
    final key = symbol.trim().toUpperCase();
    if (key.isEmpty || _planBars.containsKey(key)) return;

    List<Candle> bars;
    try {
      bars = await _service.barsForSymbol(key);
    } catch (_) {
      bars = const <Candle>[];
    }
    _planBars[key] = bars;

    final row = _rowFor(key);
    if (row != null && bars.isNotEmpty) {
      _plans[key] = buildTradePlan(
        symbol: key,
        cmp: bars.last.close,
        atr: _atrOf(bars),
        trend: row.trend,
        dp: _dpOf(bars, key),
        ce: row.ce,
        pe: row.pe,
        jodi: _jodiOf(row),
      );
    }
    _notify();
  }

  /// Is symbol ki study row (kisi bhi rule set se).
  StudyRow? _rowFor(String symbol) {
    for (final row in _result?.rows ?? const <StudyAdvRow>[]) {
      if (row.row.symbol == symbol) return row.row;
    }
    return null;
  }

  /// Wilder ATR(14) rupee me — plan ka stop/target isi se banta hai.
  double _atrOf(List<Candle> bars, {int period = 14}) {
    if (bars.length < period + 1) return 0;
    var sum = 0.0;
    for (var i = bars.length - period; i < bars.length; i++) {
      final bar = bars[i];
      final previous = bars[i - 1].close;
      final range = math.max(
        bar.high - bar.low,
        math.max((bar.high - previous).abs(), (bar.low - previous).abs()),
      );
      sum += range;
    }
    return sum / period;
  }

  /// DP (support/resistance) — 1.5.23 wala hi hisaab, ek stock ke liye.
  DpRow? _dpOf(List<Candle> bars, String symbol) =>
      buildStudyAdvAnalysis(bars: {symbol: bars}, asOf: MarketCalendar.nowIst())
          .rows
          .firstOrNull
          ?.dp;

  ({double total, double? ceStrike, double? peStrike})? _jodiOf(StudyRow row) {
    final strangle = row.strangle;
    final ce = strangle?.ce;
    final pe = strangle?.pe;
    if (ce == null || pe == null) return null;
    final total = (ce.ltp ?? 0) + (pe.ltp ?? 0);
    if (total <= 0) return null;
    return (total: total, ceStrike: ce.strike, peStrike: pe.strike);
  }

  /// Is run ka natija snapshots me likhta hai ("Mera hisaab" ke liye).
  ///
  /// Likha na ja sake to bhi scan ka natija kaam karta hai — isliye error ko
  /// chupchap nikal diya jata hai, par note me likha jata hai.
  Future<void> _saveSnapshots() async {
    final dao = _trades;
    final result = _result;
    if (dao == null || result == null) return;
    try {
      final savedAt = result.asOf;
      final rows = [
        for (final row in result.rows)
          StudySnapshotRow(
            symbol: row.row.symbol,
            savedAt: savedAt,
            score: row.row.score,
            trend: row.row.trend.label,
            ivRank: row.row.ivRank.label,
          ),
      ];
      await dao.replaceStudySnapshots(rows);
    } catch (_) {
      // Snapshot ek sahayak kaam hai; scan ka natija is par nahi tikta.
    }
  }

  /// Offline analysis: IVP/IVR, DP aur trend — sirf phone ke purane candles
  /// se, ek bhi naya request nahi.
  ///
  /// Chahe scan chala ho ya nahi, chalta hai: yahan premium ki zaroorat hi
  /// nahi, sirf itihaas chahiye jo scanner pahle hi la chuka hai.
  Future<void> analyse({bool force = false}) async {
    if (_analysisLoading) return;
    if (_analysis != null && !force) return;

    _analysisLoading = true;
    _analysisError = null;
    _notify();
    try {
      // Universe resolve karne ki zaroorat nahi: jis stock ke candles phone me
      // hain, unka hisaab. Isse ye tab bhi chalta hai jab tokens/abhi ke
      // network ka koi kaam hi na ho — sach me offline.
      _bars = await _service.cachedBars();
      _analysis = buildStudyAdvAnalysis(
        bars: _bars,
        asOf: MarketCalendar.nowIst(),
      );
    } catch (e) {
      _analysisError = 'Analysis nahi ban paya: $e';
    } finally {
      _analysisLoading = false;
      _notify();
    }
  }

  /// "Mera hisaab": paper trading ke band hue trades ko study ke natije se
  /// jod kar — kaunsa score, trend aur IV haalat me paisa bana.
  Future<void> loadMyTrades() async {
    if (_myTradesLoading) return;
    final dao = _trades;
    if (dao == null) {
      _myTradesError = 'Trade book is page se juda nahi hai.';
      _notify();
      return;
    }

    _myTradesLoading = true;
    _myTradesError = null;
    _notify();
    try {
      final trades = await dao.allTrades();
      final snapshots = await dao.allStudySnapshots();

      final latest = <String, ({StudySnapshotRow row, DateTime savedAt})>{};
      for (final entry in snapshots.entries) {
        final rows = entry.value;
        if (rows.isEmpty) continue;
        rows.sort((a, b) => a.savedAt.compareTo(b.savedAt));
        latest[entry.key] = (row: rows.last, savedAt: rows.last.savedAt);
      }

      _myTrades = buildMyTradesReport(
        trades: trades,
        snapshots: latest.map((key, value) => MapEntry(key, value.row)),
      );
    } catch (e) {
      _myTradesError = 'Trade book nahi padha ja saka: $e';
    } finally {
      _myTradesLoading = false;
      _notify();
    }
  }

  Future<void> _runJob(String name, Future<void> Function() body) async {
    if (busy) return;
    if (_universe.isEmpty) await resolveUniverse();
    if (_universe.isEmpty) {
      _error ??= 'F&O stocks ke tokens nahi mile — Scrip master update karo.';
      _status = StudyAdvStatus.error;
      _notify();
      return;
    }

    _status = StudyAdvStatus.running;
    _job = name;
    _cancelled = false;
    _error = null;
    _note = null;
    _progress = null;
    _notify();

    try {
      await body();
      _status = StudyAdvStatus.ready;
    } catch (e) {
      _error = 'Kaam fail hua: $e';
      _status = StudyAdvStatus.error;
    } finally {
      if (_status == StudyAdvStatus.running) {
        _status = StudyAdvStatus.ready;
      }
      _job = null;
      _progress = null;
      if (_cancelled) _note = 'Beech me roka gaya — hisaab adhoora hai.';
      _notify();
    }
  }

  void cancel() {
    if (!running) return;
    _cancelled = true;
    _note = 'Roka ja raha hai…';
    _notify();
  }

  void clearError() {
    _error = null;
    if (_status == StudyAdvStatus.error) _status = StudyAdvStatus.idle;
    _notify();
  }
}
