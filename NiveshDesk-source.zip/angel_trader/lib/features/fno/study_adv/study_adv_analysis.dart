// ---------------------------------------------------------------------------
// study_adv_analysis.dart — teen offline analysis: IVP/IVR, DP, Trend.
//
// Sab kuch phone me pahle se maujood daily candles se banta hai — koi naya
// request nahi, koi naya data source nahi, internet ki zaroorat nahi. Isliye
// teeno ko ek hi baar me nikala jata hai: ek loop, teen natije.
//
//   1. IVP / IVR   apne hi pichle data se percentile. (Broker IV ka itihaas
//                  nahi milta — isliye yahan IV ka nahi, asli hilchal ka
//                  percentile hai. Sach yahi hai, chhupaya nahi gaya.)
//   2. DP          support/resistance: swing high-low se level, unke aas-paas
//                  chhoone ki ginti, aur aaj ka kareebi upar/neeche level.
//   3. Trend       SMA + EMA seEDHA upar/neeche/seedha, 1M/3M/6M/1Y window.
//
// Pure: no Flutter, no database, no network.
// ---------------------------------------------------------------------------

import 'dart:math' as math;

import '../../../data/remote/dto/candle.dart';

// ---------------------------------------------------------------------------
// 1. IVP / IVR
// ---------------------------------------------------------------------------

/// Kitne din ka itihaas dekhna hai — user control karta hai (6M/12M/3Y).
enum IvpWindow {
  months6('6 mahine', 126),
  year1('1 saal', 252),
  years3('3 saal', 756);

  const IvpWindow(this.label, this.sessions);

  final String label;

  /// Haan, trading sessions — candle count se milaya jata hai.
  final int sessions;
}

/// Ek stock ka apna volatility percentile.
class IvpRow {
  const IvpRow({
    required this.symbol,
    required this.current,
    required this.ivp,
    required this.ivr,
    required this.min,
    required this.max,
    required this.average,
    required this.days,
  });

  final String symbol;

  /// Aaj ki realised volatility (20-din, saalana %).
  final double current;

  /// IVP 0–100: kitne % dinon me volatility aaj jaisi ya usse kam thi.
  /// (Barabar wale din bhi gine jate hain — warna 100 din ek jaisi chalne par
  /// bhi percentile 0 dikhta, jo jhooth hai.)
  final double ivp;

  /// IVR 0–100: (aaj − min) / (max − min).
  final double ivr;

  /// Itihaas ki sabse kam / zyada volatility.
  final double min;
  final double max;
  final double average;

  /// Percentile kitne dinon par bani — kam data ho to yahi batata hai.
  final int days;

  static const int minDays = 40;

  /// Itne din se kam par percentile "kuch pakka" nahi keh sakte.
  bool get sufficient => days >= minDays;

  /// Seedhi bhasha — number ke saath matlab bhi.
  String get verdict {
    if (!sufficient) return 'kam data ($days din)';
    if (ivp >= 80) return 'bahut tez (premium mehnga ho sakta)';
    if (ivp >= 60) return 'upar';
    if (ivp >= 40) return 'beech';
    if (ivp >= 20) return 'neeche';
    return 'bahut shaant (premium sasta ho sakta)';
  }
}

// ---------------------------------------------------------------------------
// 2. DP — support / resistance
// ---------------------------------------------------------------------------

/// Ek level: kimat, kitni baar chhua, aur aaj se kitna door.
class DpLevel {
  const DpLevel({
    required this.price,
    required this.touches,
    required this.kind,
    required this.isNearestUp,
    required this.isNearestDown,
    required this.distancePct,
  });

  final double price;

  /// Kitni baar is zone (±[DpLevel.tolerancePct]) me aayi.
  final int touches;

  /// 'upar' (resistance) ya 'neeche' (support).
  final String kind;

  final bool isNearestUp;
  final bool isNearestDown;

  /// CMP se doori, % me (negative = neeche).
  final double distancePct;

  /// Ek level kitni doori tak "ek hi level" mana jaye.
  static const double tolerancePct = 1.2;
}

/// Ek stock ke aaj ke support / resistance.
class DpRow {
  const DpRow({
    required this.symbol,
    required this.cmp,
    required this.nearestUp,
    required this.nearestDown,
    required this.days,
  });

  final String symbol;
  final double cmp;

  /// Aaj ke bhav se upar wala sabse kareeb level (`null` = koi nahi).
  final DpLevel? nearestUp;

  /// Aaj ke bhav se neeche wala sabse kareeb level (`null` = koi nahi).
  final DpLevel? nearestDown;

  /// Kitne din ke candles dekhe gaye.
  final int days;

  bool get hasBoth => nearestUp != null && nearestDown != null;
}

// ---------------------------------------------------------------------------
// 3. Trend
// ---------------------------------------------------------------------------

/// Trend ki window — user control karta hai.
enum TrendWindow {
  month1('1 mahina', 21, 13),
  months3('3 mahine', 63, 21),
  months6('6 mahine', 126, 34),
  year1('1 saal', 252, 55);

  const TrendWindow(this.label, this.sessions, this.maPeriod);

  final String label;
  final int sessions;

  /// Moving average ki lambai is window ke hisaab se.
  final int maPeriod;
}

/// 'upar' / 'neeche' / 'seedha' — aur kabhi "kuch keh sakte hi nahi".
enum TrendDirection {
  up('upar'),
  down('neeche'),
  flat('seedha'),
  unknown('pata nahi');

  const TrendDirection(this.label);

  final String label;
}

/// Ek stock ka trend: SMA, EMA, dono ka milan, aur kitne din ka data mila.
class TrendRow {
  const TrendRow({
    required this.symbol,
    required this.cmp,
    required this.sma,
    required this.ema,
    required this.aligned,
    required this.direction,
    required this.days,
  });

  final String symbol;
  final double cmp;
  final double sma;
  final double ema;

  /// SMA aur EMA dono ek hi taraf ishara kar rahe hain — tabhi trend pakka.
  final bool aligned;

  final TrendDirection direction;

  /// Kitne din ka data mila (window se kam ho to direction `unknown`).
  final int days;

  static const int minDays = 20;

  /// `true` jab MA sach me ban paya — sirf 40 din ke data par 1 saal ki MA
  /// nahi ban sakti, chahe 40 din "kaafi" lagte ho.
  bool get sufficient => sma > 0 && days >= minDays;

  /// Bhav, SMA se kitna door (%).
  double get distanceFromMaPct => sma == 0 ? 0 : (cmp - sma) / sma * 100;

  String get verdict {
    if (!sufficient) return 'kam data ($days din)';
    if (direction == TrendDirection.unknown) return 'pata nahi';
    if (!aligned) return '${direction.label} (thoda kamzor — dono line ek mat)';
    return '${direction.label} (pakka)';
  }
}

// ---------------------------------------------------------------------------
// Ek stock, teen natije
// ---------------------------------------------------------------------------

/// Teenon analysis ka ek stock ka natija.
class StockAnalysis {
  const StockAnalysis({
    required this.symbol,
    required this.cmp,
    required this.ivp,
    required this.dp,
    required this.trend,
  });

  final String symbol;
  final double cmp;
  final IvpRow? ivp;
  final DpRow? dp;
  final TrendRow? trend;

  /// Koi bhi analysis ka data kam ho to ye sach hai.
  bool get hasThinData =>
      (ivp != null && !ivp!.sufficient) || (trend != null && !trend!.sufficient);
}

// ---------------------------------------------------------------------------
// Sab ka hisaab — ek hi loop
// ---------------------------------------------------------------------------

/// Poore universe ka analysis. Ek hi baar me banta hai (teen alag loop nahi).
class StudyAdvAnalysis {
  const StudyAdvAnalysis({
    required this.asOf,
    required this.rows,
    required this.symbols,
    required this.empty,
    required this.thin,
    required this.ivpWindow,
    required this.dpDays,
    required this.trendWindow,
  });

  final DateTime asOf;

  /// CMP ke hisaab se — sabse mehnge stock pehle.
  final List<StockAnalysis> rows;

  /// Kitne stock ke candles mile.
  final int symbols;

  /// Jinke candles hi nahi mile.
  final int empty;

  /// Jinke candles mile par poori window ke liye kaafi nahi.
  final int thin;

  final IvpWindow ivpWindow;
  final int dpDays;
  final TrendWindow trendWindow;

  bool get isEmpty => rows.isEmpty;

  /// Seedhi line jo upar likhi jayegi — ginti chhupayi nahi jati.
  String get summary {
    if (isEmpty) {
      return 'Kisi bhi stock ke candles phone me nahi mile. '
          'Pehle ek baar 3M Study chalao (history download hoti hai), '
          'phir yahan sab offline ban jayega.';
    }
    final text = StringBuffer('$symbols stock ke pichle candles se (offline)');
    if (thin > 0) text.write(' · $thin stock ka data poori window ke liye kam');
    if (empty > 0) text.write(' · $empty stock ke candles hi nahi mile');
    return text.toString();
  }

  /// Sirf IVP wale (percentile ke hisaab se, tez pehle).
  List<IvpRow> get ivpRows {
    final list = rows
        .map((row) => row.ivp)
        .whereType<IvpRow>()
        .toList(growable: false);
    list.sort((a, b) => b.ivp.compareTo(a.ivp));
    return list;
  }

  /// Sirf trend wale — pehle pakke upar, phir kamzor, phir baaki.
  List<TrendRow> get trendRows {
    final list = rows
        .map((row) => row.trend)
        .whereType<TrendRow>()
        .toList(growable: false);
    int score(TrendRow row) {
      if (!row.sufficient) return 3;
      if (row.direction == TrendDirection.up) return 0;
      if (row.direction == TrendDirection.down) return 4;
      return 2;
    }

    list.sort((a, b) {
      final diff = score(a).compareTo(score(b));
      if (diff != 0) return diff;
      return b.distanceFromMaPct.compareTo(a.distanceFromMaPct);
    });
    return list;
  }

  /// Sirf DP wale — jinke dono level mile hain, pehle.
  List<DpRow> get dpRows {
    final list = rows
        .map((row) => row.dp)
        .whereType<DpRow>()
        .toList(growable: false);
    list.sort((a, b) {
      if (a.hasBoth != b.hasBoth) return a.hasBoth ? -1 : 1;
      return a.symbol.compareTo(b.symbol);
    });
    return list;
  }
}

/// Teenon analysis ek hi baar me — [bars] `SYMBOL → candles` (purane se naye).
StudyAdvAnalysis buildStudyAdvAnalysis({
  required Map<String, List<Candle>> bars,
  required DateTime asOf,
  IvpWindow ivpWindow = IvpWindow.year1,
  int dpDays = 60,
  TrendWindow trendWindow = TrendWindow.months3,
}) {
  final rows = <StockAnalysis>[];
  var empty = 0;
  var thin = 0;

  for (final entry in bars.entries) {
    final series = entry.value;
    if (series.length < 25) {
      empty++;
      continue;
    }

    final cmp = series.last.close;
    if (cmp <= 0) {
      empty++;
      continue;
    }

    final ivp = _ivpFor(entry.key, series, ivpWindow);
    final dp = _dpFor(entry.key, series, dpDays);
    final trend = _trendFor(entry.key, series, cmp, trendWindow);

    if ((ivp != null && !ivp.sufficient) || !trend.sufficient) thin++;

    rows.add(StockAnalysis(
      symbol: entry.key,
      cmp: cmp,
      ivp: ivp,
      dp: dp,
      trend: trend,
    ));
  }

  rows.sort((a, b) => b.cmp.compareTo(a.cmp));

  return StudyAdvAnalysis(
    asOf: asOf,
    rows: rows,
    symbols: rows.length,
    empty: empty,
    thin: thin,
    ivpWindow: ivpWindow,
    dpDays: dpDays,
    trendWindow: trendWindow,
  );
}

// ---- IVP ------------------------------------------------------------------

IvpRow? _ivpFor(String symbol, List<Candle> series, IvpWindow window) {
  final volSeries = _dailyVolSeries(series);
  if (volSeries.length < 25) return null;

  final wanted = window.sessions;
  final start = volSeries.length > wanted ? volSeries.length - wanted : 0;
  final window20 = volSeries.sublist(start);
  final current = window20.last;

  final sorted = [...window20]..sort();
  final atOrBelow = sorted.where((value) => value <= current).length;
  final ivp = atOrBelow / sorted.length * 100;

  final min = sorted.first;
  final max = sorted.last;
  final ivr = max == min ? 0.0 : (current - min) / (max - min) * 100;
  final average =
      window20.reduce((value, element) => value + element) / window20.length;

  return IvpRow(
    symbol: symbol,
    current: current,
    ivp: ivp.clamp(0.0, 100.0),
    ivr: ivr.clamp(0.0, 100.0),
    min: min,
    max: max,
    average: average,
    days: window20.length,
  );
}

/// Har din ke liye pichle 20 din ki volatility (saalana %).
List<double> _dailyVolSeries(List<Candle> series, {int lookback = 20}) {
  final closes = [for (final bar in series) bar.close];
  final result = <double>[];

  // Chalti hui khidki (rolling window): har kadam par purani list ki nakal
  // banane se ~200 stock × 400 din par farq padta hai.
  final window = List<double>.filled(lookback, 0);
  var filled = 0;
  var cursor = 0;

  for (var i = 1; i < closes.length; i++) {
    final previous = closes[i - 1];
    if (previous <= 0) continue;
    window[cursor % lookback] = math.log(closes[i] / previous);
    cursor++;
    if (filled < lookback) {
      filled++;
      if (filled < lookback) continue;
    }
    result.add(_annualise(_stdDev(window)));
  }
  return result;
}

double _stdDev(List<double> values) {
  if (values.length < 2) return 0;
  final mean = values.reduce((a, b) => a + b) / values.length;
  final variance =
      values.map((v) => (v - mean) * (v - mean)).reduce((a, b) => a + b) /
          (values.length - 1);
  return math.sqrt(variance);
}

double _annualise(double dailyStdDev) => dailyStdDev * math.sqrt(252) * 100;

// ---- DP -------------------------------------------------------------------

DpRow? _dpFor(String symbol, List<Candle> series, int days) {
  if (series.length < 25) return null;

  final start = series.length > days ? series.length - days : 0;
  final window20 = series.sublist(start);
  final cmp = window20.last.close;

  final levels = <DpLevel>[];

  for (var i = 2; i < window20.length - 2; i++) {
    final bar = window20[i];
    final isHigh = bar.high >= window20[i - 1].high &&
        bar.high >= window20[i - 2].high &&
        bar.high >= window20[i + 1].high &&
        bar.high >= window20[i + 2].high;
    final isLow = bar.low <= window20[i - 1].low &&
        bar.low <= window20[i - 2].low &&
        bar.low <= window20[i + 1].low &&
        bar.low <= window20[i + 2].low;
    if (!isHigh && !isLow) continue;

    final price = isHigh ? bar.high : bar.low;
    final kind = isHigh ? 'upar' : 'neeche';

    final existing = _findLevel(levels, price);
    if (existing != null) {
      levels[existing] = DpLevel(
        price: (levels[existing].price + price) / 2,
        touches: levels[existing].touches + 1,
        kind: levels[existing].kind,
        isNearestUp: false,
        isNearestDown: false,
        distancePct: 0,
      );
    } else {
      levels.add(DpLevel(
        price: price,
        touches: 1,
        kind: kind,
        isNearestUp: false,
        isNearestDown: false,
        distancePct: 0,
      ));
    }
  }

  if (levels.isEmpty) return null;

  DpLevel? nearestUp;
  DpLevel? nearestDown;
  for (final level in levels) {
    final distance = (level.price - cmp) / cmp * 100;
    if (distance > 0) {
      if (nearestUp == null || distance < nearestUp.distancePct) {
        nearestUp = DpLevel(
          price: level.price,
          touches: level.touches,
          kind: level.kind,
          isNearestUp: true,
          isNearestDown: false,
          distancePct: distance,
        );
      }
    } else if (distance < 0) {
      if (nearestDown == null || distance > nearestDown.distancePct) {
        nearestDown = DpLevel(
          price: level.price,
          touches: level.touches,
          kind: level.kind,
          isNearestUp: false,
          isNearestDown: true,
          distancePct: distance,
        );
      }
    }
  }

  final upPrice = nearestUp?.price;
  final downPrice = nearestDown?.price;

  return DpRow(
    symbol: symbol,
    cmp: cmp,
    nearestUp: upPrice == null
        ? null
        : DpLevel(
            price: upPrice,
            touches: nearestUp!.touches,
            kind: nearestUp.kind,
            isNearestUp: true,
            isNearestDown: false,
            distancePct: nearestUp.distancePct,
          ),
    nearestDown: downPrice == null
        ? null
        : DpLevel(
            price: downPrice,
            touches: nearestDown!.touches,
            kind: nearestDown.kind,
            isNearestUp: false,
            isNearestDown: true,
            distancePct: nearestDown.distancePct,
          ),
    days: window20.length,
  );
}

int? _findLevel(List<DpLevel> levels, double price) {
  for (var i = 0; i < levels.length; i++) {
    final diff = (levels[i].price - price).abs() / price * 100;
    if (diff <= DpLevel.tolerancePct) return i;
  }
  return null;
}

// ---- Trend ----------------------------------------------------------------

TrendRow _trendFor(
  String symbol,
  List<Candle> series,
  double cmp,
  TrendWindow window,
) {
  final period = window.maPeriod;
  if (series.length < period) {
    return TrendRow(
      symbol: symbol,
      cmp: cmp,
      sma: 0,
      ema: 0,
      aligned: false,
      direction: TrendDirection.unknown,
      days: series.length,
    );
  }

  final closes = [for (final bar in series) bar.close];
  final sma = _sma(closes, period);
  final ema = _ema(closes, period);

  // Bhav MA se kitna door hai (%). Ek bilkul saath-saath chal rahi line ko
  // "neeche" kehna galat hai — aadhe percent ke andar ka farq seedha hai.
  final double distanceFromSma = sma == 0 ? 0 : (cmp - sma).abs() / sma * 100;
  final double distanceFromEma = ema == 0 ? 0 : (cmp - ema).abs() / ema * 100;
  final bool flatBand = distanceFromSma < 0.5 && distanceFromEma < 0.5;

  final aboveSma = cmp > sma;
  final aboveEma = cmp > ema;
  final aligned = aboveSma == aboveEma;

  final TrendDirection direction;
  if (flatBand) {
    direction = TrendDirection.flat;
  } else if (aligned) {
    direction = aboveSma ? TrendDirection.up : TrendDirection.down;
  } else {
    // SMA aur EMA alag-alag taraf — koi saaf disha nahi.
    direction = TrendDirection.flat;
  }

  return TrendRow(
    symbol: symbol,
    cmp: cmp,
    sma: sma,
    ema: ema,
    aligned: aligned,
    direction: direction,
    days: series.length,
  );
}

double _sma(List<double> values, int period) {
  if (values.length < period) return 0;
  var sum = 0.0;
  for (final value in values.sublist(values.length - period)) {
    sum += value;
  }
  return sum / period;
}

double _ema(List<double> values, int period) {
  if (values.length < period) return 0;
  final multiplier = 2 / (period + 1);
  var ema = _sma(values.sublist(0, period), period);
  for (var i = period; i < values.length; i++) {
    ema = (values[i] - ema) * multiplier + ema;
  }
  return ema;
}
