// ---------------------------------------------------------------------------
// app.dart — dependency bootstrap + root widget.
//
// Services are built once, before the first frame that needs them, and handed to
// the widget tree with `provider`. Order matters:
//   1. database   → DAOs
//   2. settings   → screener band %, virtual capital, theme
//   3. scrip master (bundled seed on first run) → token resolution
//   4. auth (restores a stored session; refreshes silently when near expiry)
//   5. market data + screener providers
// ---------------------------------------------------------------------------

import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'core/theme/app_theme.dart';
import 'core/utils/markets.dart' show Exchange, MarketCalendar;
import 'core/widgets/brand.dart';
import 'core/widgets/motion.dart';
import 'data/local/app_database.dart';
import 'data/local/dao/candle_dao.dart';
import 'data/local/dao/earnings_dao.dart';
import 'data/local/dao/fno_contract_dao.dart';
import 'features/calls_board/calls_dao.dart';
import 'features/calls_board/calls_provider.dart';
import 'data/local/dao/ipo_dao.dart';
import 'data/local/dao/magic_basket_dao.dart';
import 'data/local/dao/magic_formula_dao.dart';
import 'data/local/dao/result_history_dao.dart';
import 'data/local/dao/scan_cache_dao.dart';
import 'data/local/dao/scrip_dao.dart';
import 'data/local/dao/settings_dao.dart';
import 'data/local/dao/trade_dao.dart';
import 'data/local/dao/trade_group_dao.dart';
import 'features/auth/login_screen.dart';
import 'features/fno/study/fno_study_provider.dart';
import 'features/golden_cross/cross_screener_provider.dart';
import 'features/ipo_screener/ipo_screener_provider.dart';
import 'features/magic_formula/magic_basket_provider.dart';
import 'features/magic_formula/magic_formula_provider.dart';
import 'features/magic_formula/fno_scanner/fno_scanner_provider.dart';
import 'features/magic_formula/fno_scanner/fno_scanner_service.dart';
import 'features/rsi_scanner/rsi_screener_provider.dart';
import 'features/paper_trading/paper_trading_provider.dart';
import 'features/settings/settings_provider.dart';
import 'features/shell/home_shell.dart';
import 'services/auth_service.dart';
import 'services/cross_scan_service.dart';
import 'services/rsi_scan_service.dart';
import 'services/fno_study_service.dart';
import 'services/live_feed_service.dart';
import 'services/ipo_discovery_service.dart';
import 'services/listing_levels_service.dart';
import 'services/nse_listing_service.dart';
import 'services/stock_suggestion_service.dart';
import 'services/market_data_service.dart';
import 'services/magic_formula_data_source.dart';
import 'services/earnings_calendar_service.dart';
import 'features/fno/results/results_calendar_provider.dart';
import 'features/fno/ai/ai_suggestion_provider.dart';
import 'services/ai_suggestion_service.dart';
import 'services/scrip_master_service.dart';
import 'services/secure_store.dart';
import 'services/notification_service.dart';
import 'features/alerts/alerts_center.dart';
import 'features/alerts/morning_brief.dart';
import 'data/remote/dto/scrip.dart';

/// Boot ke beech me widget hi hat gaya — koi galti nahi, bas aage kaam nahi.
/// `_start()` ise chup chaap nikal deta hai (kaali screen ka koi khatra nahi:
/// screen hai hi nahi).
class _BootAborted implements Exception {
  const _BootAborted();
}

/// Object graph built once at startup.
///
/// (`main()` lives in lib/main.dart so that the entry point stays trivially
/// readable.)
class AppServices {
  AppServices({
    required this.database,
    required this.ipoDao,
    required this.scripDao,
    required this.settingsDao,
    required this.cacheDao,
    required this.candleDao,
    required this.tradeDao,
    required this.tradeGroupDao,
    required this.magicFormulaDao,
    required this.magicFormulaProvider,
    required this.magicFormulaHttp,
    required this.magicBasketDao,
    required this.magicBasketProvider,
    required this.stockSuggestions,
    required this.fnoScanner,
    required this.fnoContracts,
    required this.secureStore,
    required this.auth,
    required this.scripMaster,
    required this.marketData,
    required this.settings,
    required this.screener,
    required this.crossScan,
    required this.crossScreener,
    required this.rsiScan,
    required this.rsiScreener,
    required this.fnoStudy,
    required this.fnoStudyProvider,
    required this.resultsCalendar,
    required this.aiSuggestions,
    required this.feed,
    required this.earnings,
    required this.paper,
    required this.levels,
    required this.discovery,
    required this.callsBoard,
  });

  final AppDatabase database;
  final IpoDao ipoDao;
  final ScripDao scripDao;
  final SettingsDao settingsDao;
  final ScanCacheDao cacheDao;
  final CandleDao candleDao;
  final TradeDao tradeDao;
  final TradeGroupDao tradeGroupDao;
  final MagicFormulaDao magicFormulaDao;
  final MagicFormulaProvider magicFormulaProvider;
  final NseMagicFormulaHttp magicFormulaHttp;

  /// Magic Formula baskets (user lists + their local state).
  final MagicBasketDao magicBasketDao;
  final MagicBasketProvider magicBasketProvider;
  final StockSuggestionService stockSuggestions;

  /// Feature 1's second function — the F&O Scanner (official bhavcopy lists).
  final FnoScannerProvider fnoScanner;

  /// Options Calls Board (1.5.71) — standalone Telegram call-channel tracker.
  final CallsProvider callsBoard;

  /// Feature 6 — the local option-contract book (F&O module).
  final FnoContractDao fnoContracts;
  final SecureStore secureStore;

  final AuthService auth;
  final ScripMasterService scripMaster;
  final MarketDataService marketData;

  final SettingsProvider settings;
  final IpoScreenerProvider screener;
  final CrossScanService crossScan;
  final CrossScreenerProvider crossScreener;

  /// Feature 5 — RSI extremes scanner (own tab).
  final RsiScanService rsiScan;
  final RsiScreenerProvider rsiScreener;

  // Feature 6 — F&O module, tool #1: the 3-Month Study.
  final FnoStudyService fnoStudy;
  final FnoStudyProvider fnoStudyProvider;

  /// F&O module — Results Calendar (its own page, shares only the NSE cache).
  final ResultsCalendarProvider resultsCalendar;

  /// F&O module — tool #3: AI Suggestion (local rule engine over the same
  /// candles and option book).
  final AiSuggestionProvider aiSuggestions;

  /// Feature 1 — fills in listing-day high/low for the bundled IPO master.
  final ListingLevelsService levels;

  /// Automatic new-IPO detection (Feature 1's "always current" half).
  final IpoDiscoveryService discovery;

  // Feature 3
  final LiveFeedService feed;
  final EarningsCalendarService earnings;
  final PaperTradingProvider paper;

  Future<void> dispose() async {
    // The paper provider owns a feed subscription and a REST timer.
    paper.dispose();
    auth.dispose();
    unawaited(feed.stop());
    marketData.dispose();
    scripMaster.dispose();
    screener.dispose();
    crossScreener.dispose();
    rsiScreener.dispose();
    fnoStudyProvider.dispose();
    magicFormulaProvider.dispose();
    magicBasketProvider.dispose();
    magicFormulaHttp.close();
    settings.dispose();
    await database.close();
  }
}

class AngelTraderApp extends StatefulWidget {
  const AngelTraderApp({super.key});

  @override
  State<AngelTraderApp> createState() => _AngelTraderAppState();
}

class _AngelTraderAppState extends State<AngelTraderApp> {
  late Future<AppServices> _bootstrap;

  /// Which step boot is on. Shown on the splash once boot is taking long, so a
  /// slow (or stuck) start says what it is doing instead of showing nothing.
  final ValueNotifier<String> _step = ValueNotifier<String>(
    'shuru ho raha hai',
  );

  /// Flipped on by the watchdog — boot that takes more than a few seconds is
  /// worth naming out loud.
  final ValueNotifier<bool> _slow = ValueNotifier<bool>(false);

  Timer? _watchdog;

  /// The boot budget itself, kept so it can be cancelled the moment boot
  /// finishes (or the widget goes away) instead of hanging around.
  Timer? _budget;

  /// Nothing, not even a stuck boot, is allowed to sit there forever: after
  /// this long the splash says so and offers a retry.
  static const Duration bootBudget = Duration(seconds: 60);

  @override
  void initState() {
    super.initState();
    _bootstrap = _start();
    _watchdog = Timer(const Duration(seconds: 12), () {
      if (mounted) _slow.value = true;
    });
  }

  @override
  void dispose() {
    _watchdog?.cancel();
    _budget?.cancel();
    _step.dispose();
    _slow.dispose();
    super.dispose();
  }

  /// Boots, with a budget: an await that never returns used to mean a silent
  /// black screen for as long as the user was willing to stare at it.
  Future<AppServices> _start() {
    final timedOut = Completer<AppServices>();
    _budget?.cancel();
    _budget = Timer(bootBudget, () {
      if (!timedOut.isCompleted) {
        timedOut.completeError(
          TimeoutException(
            'Boot me ${bootBudget.inSeconds} second se zyada lag gaye '
            '(aakhri kaam: ${_step.value}).',
          ),
        );
      }
    });

    final boot = _abortSafe(_buildServices())
      ..whenComplete(() {
        _budget?.cancel();
        _budget = null;
      });
    return Future.any<AppServices>([boot, timedOut.future]);
  }

  void _retry() {
    _slow.value = false;
    _step.value = 'dobara koshish…';
    setState(() => _bootstrap = _start());
  }

  /// Widget beech me hi hat gaya to boot ka aage ka koi matlab nahi.
  ///
  /// Aisi future kabhi complete nahi hoti — theek hai, kyun ki uska intezaar
  /// karne wala koi hai hi nahi (widget dispose ho chuka). Budget timer
  /// `whenComplete` me hat jata hai, isliye kuch bhi latka nahi rehta.
  Future<AppServices> _abortSafe(Future<AppServices> boot) async {
    try {
      return await boot;
    } on _BootAborted {
      return Completer<AppServices>().future;
    }
  }

  /// Splash ki line badalta hai — **sirf jab widget zinda ho**.
  ///
  /// Boot ke beech me widget hat jaye (screen band, test khatam, retry) to
  /// disposed notifier par likhna ek exception hai, aur release build us
  /// exception ko kaali screen bana deta hai. Isliye har jagah yahi raasta.
  void _say(String message) {
    if (!mounted) return;
    _step.value = message;
  }

  Future<AppServices> _buildServices() async {
    _say('database khul raha hai');
    final database = AppDatabase.instance;

    final ipoDao = IpoDao(database);
    final scripDao = ScripDao(database);
    final settingsDao = SettingsDao(database);
    final cacheDao = ScanCacheDao(database);
    final candleDao = CandleDao(database);
    final tradeDao = TradeDao(database);
    final tradeGroupDao = TradeGroupDao(database);
    final magicFormulaDao = MagicFormulaDao(database);
    final fnoContracts = FnoContractDao(database);
    final earningsDao = EarningsDao(database);

    _say('settings padh raha hai');
    final settings = SettingsProvider(settingsDao);
    await settings.load();
    if (!mounted) throw const _BootAborted();

    final scripMaster = ScripMasterService(
      scripDao: scripDao,
      settingsDao: settingsDao,
      // Every master refresh also rebuilds the local option book the F&O
      // module reads (near expiries only — see FnoContractCollector).
      fnoContracts: fnoContracts,
      // …and hands the pages the rewrite freed back to the OS.
      compact: database.vacuum,
    );
    // Seeds assets/data/scrip_master.json on first launch so symbol ➜ token
    // resolution works before the first network refresh.
    _say('scrip master taiyaar ho raha hai');
    await scripMaster.initialise();
    if (!mounted) throw const _BootAborted();

    _say('purani session dhoondh raha hai');
    final auth = AuthService(store: SecureStore());
    // Best effort: a device whose keystore cannot be read should still open
    // the app (and ask for a login), not stop at the splash.
    try {
      await auth.restore();
    } catch (e) {
      debugPrint('Session restore failed (login screen will show): $e');
    }
    if (!mounted) throw const _BootAborted();
    _say('screener taiyaar ho raha hai');

    final marketData = MarketDataService(auth: auth);

    // ---- 1.5.74 Notification Center ---------------------------------------
    _say('notifications taiyaar ho rahi hain');
    await NotificationService.instance.init();
    final alerts = AlertsCenter.instance;
    await alerts.load(settingsDao);
    alerts.priceFetcher = (symbols) async {
      final resolver = await scripMaster.resolver();
      final resolved = <Scrip>[];
      for (final s in symbols) {
        final scrip = resolver.resolve(s).scrip;
        if (scrip != null) resolved.add(scrip);
      }
      if (resolved.isEmpty) return {};
      final priced = await marketData.fetchLtp(resolved);
      final out = <String, double>{};
      priced.forEach((key, value) {
        final symbol = key.contains(':') ? key.split(':').last : key;
        out[symbol] = value.value;
      });
      return out;
    };
    // Price-alert checker: market hours me har 3 minute (login chahiye).
    Timer.periodic(const Duration(minutes: 3), (_) {
      if (MarketCalendar.isMarketOpen()) {
        AlertsCenter.instance.checkPriceAlerts();
      }
    });

    // Feature 1 helper: the bundled IPO master ships symbol + listing date for
    // every mainboard IPO since 2015; this service fetches each row's
    // listing-day high/low from the broker's daily candles, in resumable
    // batches, and remembers where every level came from.
    final levels = ListingLevelsService(
      ipoDao: ipoDao,
      scripMaster: scripMaster,
      candles: marketData,
      auth: auth,
    );

    // Feature 1, second helper: keeps the universe current. New listings are
    // found from the broker's own scrip master + candles (no third-party site),
    // with NSE's official equity master as a date cross-check for listings the
    // broker snapshot has not picked up yet.
    final nseListings = NseListingService(settings: settingsDao);
    final magicFormulaHttp = NseMagicFormulaHttp();
    final magicFormulaProvider = MagicFormulaProvider(
      dao: magicFormulaDao,
      dataSource: NseMagicFormulaDataSource(
        scripDao: scripDao,
        listings: nseListings,
        settings: settingsDao,
        get: magicFormulaHttp.get,
        getBytes: magicFormulaHttp.getBytes,
      ),
      settings: settingsDao,
    );
    final magicBasketDao = MagicBasketDao(database);
    final magicBasketProvider = MagicBasketProvider(magicBasketDao);
    final fnoScanner = FnoScannerProvider(
      service: FnoScannerService(
        getBytes: magicFormulaHttp.getBytes,
        cache: cacheDao,
      ),
      contracts: fnoContracts,
      marketData: marketData,
      scripMaster: scripMaster,
    );
    // Options Calls Board (1.5.71) — standalone module: user-added public
    // Telegram call channels, paper-followed SL/target, channel scoreboard.
    final callsBoard = CallsProvider(
      dao: CallsDao(database),
      contracts: fnoContracts,
      marketData: marketData,
      scripMaster: scripMaster,
    );
    final stockSuggestions = StockSuggestionService(
      listings: nseListings,
      scripDao: scripDao,
    );
    final discovery = IpoDiscoveryService(
      ipoDao: ipoDao,
      scripMaster: scripMaster,
      candles: marketData,
      auth: auth,
      nse: nseListings,
      settings: settingsDao,
    );

    final screener = IpoScreenerProvider(
      ipoDao: ipoDao,
      cacheDao: cacheDao,
      scripMaster: scripMaster,
      marketData: marketData,
      auth: auth,
      settings: settings,
      settingsDao: settingsDao,
      levels: levels,
      discovery: discovery,
    );

    // Feature 2: the cross screener reads its candles through the
    // MarketDataService (which is the CandleSource) and keeps them in SQLite.
    final crossScan = CrossScanService(
      source: marketData,
      candles: candleDao,
      cache: cacheDao,
    );
    final crossScreener = CrossScreenerProvider(
      scan: crossScan,
      scripDao: scripDao,
      ipoDao: ipoDao,
      settings: settings,
      auth: auth,
      scripMaster: scripMaster,
    );

    // Feature 5: the RSI scanner reuses the same CandleSource and the same
    // candle cache as the Golden Cross scanner (DailyBarsLoader is shared), so
    // whichever tab is scanned first makes the other's scan nearly free.
    final rsiScan = RsiScanService(
      source: marketData,
      candles: candleDao,
      cache: cacheDao,
    );
    final rsiScreener = RsiScreenerProvider(
      scan: rsiScan,
      settings: settings,
      scripDao: scripDao,
      ipoDao: ipoDao,
      scripMaster: scripMaster,
    );

    // Feature 3: the live tick feed is shared by every paper-trading surface.
    // It only dials out once a session exists and a watch list is subscribed.
    final feed = LiveFeedService(auth: auth);
    final paper = PaperTradingProvider(
      trades: tradeDao,
      groups: tradeGroupDao,
      settings: settings,
      auth: auth,
      marketData: marketData,
      feed: feed,
      scripDao: scripDao,
    );
    // Load the book before the first frame so Holdings/Reports are populated
    // even if the user opens those tabs first. Failures are kept inside the
    // provider (`paper.error`) instead of blocking app start.
    _say('paper trading ka khata padh raha hai');
    try {
      await paper.bootstrap();
      if (!mounted) throw const _BootAborted();
    } on _BootAborted {
      rethrow; // Test/widget was removed while boot awaited this provider.
    } catch (_) {
      // Reported through the provider's error banner.
    }

    // Feature 6: the F&O module. The study service reads candles through the
    // same CandleSource/cache as the equity screeners, picks its ATM strike from
    // the local option book (`fno_contracts`), then prices both legs with one
    // batched full quote and the broker's option greeks.
    final fnoStudy = FnoStudyService(
      source: marketData,
      candles: candleDao,
      cache: cacheDao,
      contracts: fnoContracts,
      marketData: marketData,
    );

    // 1.5.75 — Morning brief: 8:30 AM alarm + app-open catch-up. In-app path
    // full services use karta hai; Android ka background alarm khud bhi
    // services bana leta hai (morning_brief.dart me).
    MorningBriefScheduler.inAppRun = () async {
      await MorningBriefRunner.generate(
        study: fnoStudy,
        scripDao: scripDao,
        ipoDao: ipoDao,
        dao: settingsDao,
      );
    };
    unawaited(MorningBriefScheduler.start());
    // Results calendar (last / next quarterly result). Public NSE endpoints —
    // the same fallback role NSE already has for listing dates; cached a day.
    final earnings = EarningsCalendarService(
      dao: earningsDao,
      settings: settingsDao,
      history: ResultHistoryDao(database),
      get: NseHttp().get,
    );

    final fnoStudyProvider = FnoStudyProvider(
      study: fnoStudy,
      settings: settings,
      scripDao: scripDao,
      ipoDao: ipoDao,
      scripMaster: scripMaster,
      feed: feed,
      earnings: earnings,
    );

    // F&O module — tool #2: the Results Calendar page. Same day-cached NSE
    // calendar as the study panel, offered as a list for the whole F&O list.
    final resultsCalendar = ResultsCalendarProvider(
      earnings: earnings,
      candles: candleDao,
      history: ResultHistoryDao(database),
      candleSource: marketData,
      resolveScrip: (row) async {
        final resolver = await scripMaster.resolver();
        return resolver
            .resolve(
              row.symbol,
              preferredExchange: Exchange.nse,
              companyName: row.name,
            )
            .scrip;
      },
    );

    // F&O module — tool #3: AI Suggestion. A local rule engine over the same
    // candles and option book; no model call, so it needs nothing but what the
    // app already has.
    final aiSuggestions = AiSuggestionProvider(
      service: AiSuggestionService(
        source: marketData,
        candles: candleDao,
        contracts: fnoContracts,
        marketData: marketData,
      ),
      settings: settings,
      scripDao: scripDao,
      ipoDao: ipoDao,
      scripMaster: scripMaster,
      earnings: earnings,
    );

    _say('ho gaya');
    return AppServices(
      database: database,
      ipoDao: ipoDao,
      scripDao: scripDao,
      settingsDao: settingsDao,
      cacheDao: cacheDao,
      candleDao: candleDao,
      tradeDao: tradeDao,
      tradeGroupDao: tradeGroupDao,
      magicFormulaDao: magicFormulaDao,
      magicFormulaProvider: magicFormulaProvider,
      magicFormulaHttp: magicFormulaHttp,
      magicBasketDao: magicBasketDao,
      magicBasketProvider: magicBasketProvider,
      stockSuggestions: stockSuggestions,
      fnoScanner: fnoScanner,
      callsBoard: callsBoard,
      fnoContracts: fnoContracts,
      secureStore: SecureStore(),
      auth: auth,
      scripMaster: scripMaster,
      marketData: marketData,
      settings: settings,
      screener: screener,
      crossScan: crossScan,
      crossScreener: crossScreener,
      rsiScan: rsiScan,
      rsiScreener: rsiScreener,
      fnoStudy: fnoStudy,
      fnoStudyProvider: fnoStudyProvider,
      resultsCalendar: resultsCalendar,
      aiSuggestions: aiSuggestions,
      feed: feed,
      paper: paper,
      earnings: earnings,
      levels: levels,
      discovery: discovery,
    );
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<AppServices>(
      future: _bootstrap,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return _BootFailure(error: '${snapshot.error}');
        }
        final services = snapshot.data;
        if (services == null) {
          return ValueListenableBuilder<bool>(
            valueListenable: _slow,
            builder: (context, slow, _) => _SplashScreen(
              step: _step,
              slow: slow,
              // The retry only appears once boot has blown its budget, which
              // is the one case where a hang has been proven rather than felt.
              onRetry: slow ? _retry : null,
            ),
          );
        }

        return MultiProvider(
          providers: [
            // Data access (also used by the Feature 2 / 3 providers later).
            Provider<AppDatabase>.value(value: services.database),
            Provider<IpoDao>.value(value: services.ipoDao),
            Provider<ScripDao>.value(value: services.scripDao),
            Provider<SettingsDao>.value(value: services.settingsDao),
            // 1.5.74 — Notification Center (bell badge + history).
            ChangeNotifierProvider<AlertsCenter>.value(value: AlertsCenter.instance),
            Provider<ScanCacheDao>.value(value: services.cacheDao),
            Provider<CandleDao>.value(value: services.candleDao),
            Provider<FnoContractDao>.value(value: services.fnoContracts),
            // Paper trading's groups — read straight from the context by the
            // Group Manager screen. It was never installed (same blank-screen
            // class of bug as FnoStudyService below); the guard test in
            // `test/app_providers_test.dart` now fails if one goes missing.
            Provider<TradeGroupDao>.value(value: services.tradeGroupDao),
            // Paper trades ka DAO — "Mera hisaab" (3M advance filter) isi se
            // band hue trades padhta hai.
            Provider<TradeDao>.value(value: services.tradeDao),
            Provider<MagicFormulaDao>.value(value: services.magicFormulaDao),
            Provider<CrossScanService>.value(value: services.crossScan),
            Provider<SecureStore>.value(value: services.secureStore),

            // Services.
            ChangeNotifierProvider<AuthService>.value(value: services.auth),
            ChangeNotifierProvider<ScripMasterService>.value(
              value: services.scripMaster,
            ),
            Provider<MarketDataService>.value(value: services.marketData),
            // One WebSocket feed, one results calendar — shared by the paper
            // trading surfaces, the 3-Month Study and the advance-filter page.
            // LiveFeedService is a ChangeNotifier, so it has to be provided as
            // one — a plain Provider refuses a Listenable (it would never
            // notify anyone of a reconnection).
            ChangeNotifierProvider<LiveFeedService>.value(value: services.feed),
            Provider<EarningsCalendarService>.value(value: services.earnings),
            // The study service itself (the advance-filter page builds on top
            // of it: same candles, same option book, one shared scan). It is
            // provided here so that page can read it instead of building a
            // second one — and so a missing provider can never reach a
            // release build as a blank screen (1.5.21).
            Provider<FnoStudyService>.value(value: services.fnoStudy),

            // App state.
            ChangeNotifierProvider<SettingsProvider>.value(
              value: services.settings,
            ),
            ChangeNotifierProvider<IpoScreenerProvider>.value(
              value: services.screener,
            ),
            ChangeNotifierProvider<MagicFormulaProvider>.value(
              value: services.magicFormulaProvider,
            ),
            ChangeNotifierProvider<MagicBasketProvider>.value(
              value: services.magicBasketProvider,
            ),
            ChangeNotifierProvider<FnoScannerProvider>.value(
              value: services.fnoScanner,
            ),
            ChangeNotifierProvider<CallsProvider>.value(
              value: services.callsBoard,
            ),
            Provider<StockSuggestionService>.value(
              value: services.stockSuggestions,
            ),
            ChangeNotifierProvider<RsiScreenerProvider>.value(
              value: services.rsiScreener,
            ),
            // Feature 6 — F&O module (hub + 3-Month Study). Kept out of the
            // bottom navigation: it opens from the app bar.
            ChangeNotifierProvider<FnoStudyProvider>.value(
              value: services.fnoStudyProvider,
            ),
            ChangeNotifierProvider<ResultsCalendarProvider>.value(
              value: services.resultsCalendar,
            ),
            // F&O module — tool #3: AI Suggestion.
            ChangeNotifierProvider<AiSuggestionProvider>.value(
              value: services.aiSuggestions,
            ),
            ChangeNotifierProvider<CrossScreenerProvider>.value(
              value: services.crossScreener,
            ),
            ChangeNotifierProvider<PaperTradingProvider>.value(
              value: services.paper,
            ),
          ],
          child: const _RootApp(),
        );
      },
    );
  }
}

class _RootApp extends StatelessWidget {
  const _RootApp();

  @override
  Widget build(BuildContext context) {
    final themeMode = context.select<SettingsProvider, ThemeMode>(
      (settings) => settings.themeMode,
    );

    return MaterialApp(
      title: Brand.name,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: themeMode,
      home: const AppGate(),
    );
  }
}

/// Sends the user to the login screen until a SmartAPI session exists, or to the
/// shell when they choose to browse cached data without logging in.
class AppGate extends StatefulWidget {
  const AppGate({super.key});

  @override
  State<AppGate> createState() => _AppGateState();
}

class _AppGateState extends State<AppGate> {
  bool _browseOffline = false;

  @override
  Widget build(BuildContext context) {
    final loggedIn = context.select<AuthService, bool>(
      (auth) => auth.isLoggedIn,
    );
    if (loggedIn || _browseOffline) {
      return const HomeShell();
    }
    return LoginScreen(
      onBrowseOffline: () => setState(() => _browseOffline = true),
    );
  }
}

// ---------------------------------------------------------------------------
// Splash / failure states
// ---------------------------------------------------------------------------

///
/// The splash is built by the ROOT FutureBuilder — that is, ABOVE the app's
/// own MaterialApp, which does not exist yet because the services it needs are
/// still being built. So it has to bring its own Directionality, Theme and
/// MediaQuery.
///
/// Without them the very first frame throws ("No Directionality widget found"),
/// and a release build answers a build-time exception by painting NOTHING: the
/// user sees the bare Android window background, which in dark mode is a
/// completely black screen until boot finishes — and forever if boot never
/// does. That is the bug this class now prevents (1.5.21).
class _SplashScreen extends StatelessWidget {
  const _SplashScreen({this.step, this.slow = false, this.onRetry});

  /// What boot is busy with — only shown once boot is taking long.
  final ValueListenable<String>? step;

  /// True once the watchdog has fired.
  final bool slow;

  /// Offered only when boot has clearly overrun its budget.
  final VoidCallback? onRetry;

  @override
  Widget build(BuildContext context) {
    final brightness = MediaQuery.platformBrightnessOf(
      context,
    ); // safe: View provides it
    final theme = brightness == Brightness.dark
        ? AppTheme.dark()
        : AppTheme.light();

    return Directionality(
      textDirection: TextDirection.ltr,
      child: Theme(
        data: theme,
        child: Builder(
          builder: (context) {
            final scheme = Theme.of(context).colorScheme;

            return Scaffold(
              body: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      scheme.surface,
                      scheme.primaryContainer.withValues(alpha: 0.35),
                      scheme.surface,
                    ],
                    stops: const [0.0, 0.45, 1.0],
                  ),
                ),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // The brand mark draws itself — the app's one piece of
                      // ceremony.
                      const AnimatedBrandMark(
                        size: 108,
                        delay: Duration(milliseconds: 120),
                      ),
                      const SizedBox(height: 26),
                      const FadeSlideIn(
                        index: 3,
                        child: BrandWordmark(fontSize: 30),
                      ),
                      const SizedBox(height: 10),
                      FadeSlideIn(
                        index: 5,
                        child: Text(
                          Brand.tagline,
                          style: TextStyle(
                            fontSize: 10.5,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 1.1,
                            color: scheme.onSurfaceVariant,
                          ),
                        ),
                      ),
                      const SizedBox(height: 38),
                      SizedBox(
                        width: 150,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(4),
                          child: const LinearProgressIndicator(minHeight: 3),
                        ),
                      ),
                      const SizedBox(height: 28),
                      Text(
                        'Paper trading only · no real orders',
                        style: Theme.of(context).textTheme.labelSmall,
                      ),
                      // A boot that is taking long says what it is doing — a
                      // black screen that says nothing is how a hang hides.
                      if (slow && step != null) ...[
                        const SizedBox(height: 22),
                        ValueListenableBuilder<String>(
                          valueListenable: step!,
                          builder: (context, value, _) => Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 40),
                            child: Text(
                              'Der ho rahi hai — abhi: $value',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 11.5,
                                height: 1.35,
                                color: scheme.onSurfaceVariant,
                              ),
                            ),
                          ),
                        ),
                      ],
                      // …and once it has clearly overrun, a way out.
                      if (onRetry != null) ...[
                        const SizedBox(height: 14),
                        TextButton.icon(
                          onPressed: onRetry,
                          icon: const Icon(Icons.refresh_rounded, size: 16),
                          label: const Text('Dobara koshish karo'),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class _BootFailure extends StatelessWidget {
  const _BootFailure({required this.error});

  final String error;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      home: Scaffold(
        body: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.error_outline, size: 40),
              const SizedBox(height: 12),
              Text(
                'Startup failed',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: 8),
              const Text(
                'The local database or the bundled instrument list could not be '
                'initialised.',
              ),
              const SizedBox(height: 12),
              SelectableText(error, style: const TextStyle(fontSize: 12)),
              const SizedBox(height: 20),
              FilledButton(
                onPressed: () => Clipboard.setData(ClipboardData(text: error)),
                child: const Text('Copy error'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
