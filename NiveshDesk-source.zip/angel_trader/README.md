# NiveshDesk — Indian stock market analysis + paper trading

A Flutter (Android + iOS) app built on **Angel One SmartAPI**: an IPO proximity
screener, a Golden/Death Cross screener and a fully simulated paper-trading
module. Everything runs on the device — SQLite, no server, no real orders.

> **Renamed in 1.3.0:** the app used to be called "Angel Trader". It *reads*
> Angel One's SmartAPI but is not an Angel One product, so it now carries its own
> brand — **NiveshDesk** (निवेश + desk) — with its own logo, palette, type scale
> and motion vocabulary. See [`design/BRAND.md`](design/BRAND.md). The only
> remaining "Angel" references in the UI are accurate ones (the SmartAPI
> endpoints and the API setup docs).

> **Build status** — ✅ **All three features are complete and tested**, and the
> app now carries its own brand (**NiveshDesk**, 1.4.0): IPO proximity screener,
> Golden/Death Cross screener, paper trading with strategy groups and Reports,
> plus the full design pass and a "lite" motion kit. **1118 tests, all
> green.** See [Roadmap](#roadmap).

> **1.5.21 — "3 Month Study with Advance Filter" — wahi study, sudhaare hue
> niyam ke saath, aur dono score aapki aankh ke saamne.**

> Pichhle saal ka study page band-pheka number deta tha: **12 point**, chaar
> factor se. Par do sawal khule the — *"ye point kis hisaab se bane?"* aur
> *"in point ka koi matlab bhi hai?"* Ab ek **naya page** hai (F&O hub me
> naya card), jahan wahi study **sudhaare hue niyam** ke saath chalti hai aur
> **purana score usi row par saath-saath** likha hota hai — taaki farq chhupe
> nahi, dikhe.

> **Purana "3-Month Study" page bilkul waise hi hai** — ek number bhi nahi
> hila. Naya uske bagal me hai: same data, same engine, doosre niyam.

> **Kaunse sudhaar (sab likhe hain, koi chhupa nahi):**
> * **🎯 Best Buy ab sirf "IV sasta" par nahi milta.** Premium jis stock ki
>   asli chal se mehenga ho (edge negative), wo seedha **⏸ Watch** ho jata hai.
> * **Doori ek hi paimaane se.** Pehle 3-month high se doori ko high se aur
>   low se doori ko CMP se baanta jata tha — upar aur neeche ke point aapas me
>   barabar nahi the. Ab dono CMP se.
> * **Adhura mahina poora mahina nahi.** 2-3 session ka hissa apna "mahina"
>   ban kar consistency hila deta tha; ab wo pichhle mahine me mil jata hai.
>   Aur sirf 2 mahine dikh rahe hon to consistency 3 point nahi maangta —
>   **jitne mahine dekhe, utne point**.
> * **Expiry ke 3 din (ya kam) bache hon to 🎯 khud hi ⏸ Watch** ho jata hai —
>   theta premium ko us stock ki chal se tez khaata hai. **Aaj expiry** to
>   kabhi 🎯 nahi.
> * **Har row par turnover (20-din ausat, ₹ cr) aur expiry ke din** — liquidity
>   kam ho ya aaj expiry ho, wo row chhoot-ti hai to **kyun chhooti, row par hi
>   likha hota hai** ("turnover 4.2 cr < 10 cr"), chup-chaap ghaṭ kar nahi.

> **Filter (aap ke haath me).** Default: **liquidity ≥ ₹10 cr** aur **aaj
> expiry chhod** chalu; baaki sab band, aur **kaun chhoota** ki line hamesha
> dikhti hai. Min-score slider **0 se 12** (default 0), aur **10 tarah ke sort**
> (naya score, purana score, farq, edge, price, 3M move, **trend**, turnover,
> ATR, naam).

> **Aur sabse zaroori: "Score ka hisab" (doosra tab).** 12-point kisi ne naap
> kar nahi banaye the — ab naape jate hain. Purane candles par score nikal kar
> dekha jata hai ki us score wale stock ne aage ke **5 / 10 / 15 din** me kya
> kiya (1 / 2 / 3 saal ka itihaas). Natija chaar band me: **0–4 · 4–7 · 7–9 ·
> 9–12** — **naye niyam aur purane niyam, dono alag-alag table me**, taaki
> sawal ye rahe: *"sudhaar ne score ko zyada matlab-purna banaya ya nahi?"*
> Sideways (AVOID) wale din trade gine hi nahi jate, UP ko long aur DOWN ko
> short maan kar naapa jata hai (study ka apna suggestion), aur **"ye bita
> hua hisaab hai, koi guarantee nahi"** likha hota hai.

> **1.5.21 (dobara build, usi din).** Pehli APK me naye card par tap karte hi
> **pura blank screen** aa raha tha. Kya hua tha: naya page `FnoStudyService`
> context se maang raha tha, aur app ne wo kabhi provide hi nahi kiya tha —
> release build me aisi galti ka jawab Flutter **khaali grey box** deta hai
> (koi message nahi). Ab do cheezein badli hain: wahi service **root
> MultiProvider** me daal di gayi (`app.dart`), aur **ab koi bhi screen toote
> to khaali screen nahi** — `main.dart` Flutter ke error widget ko ek likha
> hua sandesh dikhane wale box se badal deta hai, har build me. Saath hi
> `GroupManagerScreen` ka wahi purana bug bhi theek (Settings → Group Manager
> bhi blank hi hota tha — `TradeGroupDao` bhi provide nahi tha), aur ek **naya
> jaal** (`test/app_providers_test.dart`): jo bhi type koi widget context se
> maange, use kahin na kahin provide karna hi padega — warna test laal.

> **1.5.21 (teesra build, usi din).** Doosri APK me app khulte hi **puri kali
> (black) screen** aa rahi thi — kuch bhi nahi dikhta tha. Wajah: boot ki
> **pehli frame** hi toot rahi thi. Splash screen root `FutureBuilder` me banti
> hai, yani app ke apne `MaterialApp` se **upar** — jahan `Text` ko
> `Directionality` milta hi nahi. Release build me aisi galti ka jawab
> **kuch paint na karna** hai: user ko sirf Android ka window background
> dikhta hai, jo dark mode me **kaala** hota hai.
>
> Ab: splash apna `Directionality` + `Theme` khud laata hai (**pehli frame ab
> guaranteed paint hoti hai**), error widget bhi khud `Directionality` deta
> hai (warna galti dikhate waqt wo khud galti kha jata tha), boot har kadam
> par likh kar batata hai ki chal kya raha hai (**12 second ke baad "Der ho
> rahi hai — abhi: scrip master taiyaar ho raha hai"**), aur **60 second ke
> baad "Dobara koshish karo"** ka button. Session restore ab best-effort hai —
> wo fail ho to app khulta hai, login maangta hai.
>
> Boot ke kadam (in-memory DB par): database **71 ms**, settings **9 ms**,
> scrip master **36 ms** — kahin koi atak nahi raha; sirf pehli frame mar rahi
> thi.

> **1.5.22 — "IV kahan se mile" aur "results paas" wali rok (B1 + B3).**
>
> **B1 — IV source setting.** Study ka sabse mehnga hissa broker ka greek
> endpoint tha: **har stock ke liye ek alag request** (poore F&O universe me
> ~213). Ab Settings → **F&O — 3-Month Study → "IV kahan se mile"** me teen
> raaste:
>
> | Setting | Kya hota hai |
> | --- | --- |
> | **Auto** (default, aaj jaisa) | Broker se IV maango, na mile to premium se khud solve karo |
> | **Sirf broker** | Broker ki IV — jiske liye broker ne nahi di, us row par IV **khali** rahega (koi number banaya nahi jata) |
> | **Sirf apna hisaab (Black-Scholes)** | Broker ko **ek bhi call nahi** — har IV premium se solve hoga |
>
> "Sirf apna hisaab" me scan ka pura greeks phase **kuch nahi mangta**: 213
> request ki jagah **0**. IV kam nahi hoti — wahi solver jo pehle fallback tha,
> ab poora kaam karta hai. Dono study pages (3-Month Study aur Advance Filter)
> isi setting ko mante hain.
>
> **B3 — Results-date block (sirf advance page).** Naya chip: **"results ≤ 5
> din chhod"**. On karte hi jin stock ke results 5 din ke andar hain (aaj bhi
> shamil) wo list se hat kar **"kaun chhoota"** me jate hain, apni line ke
> saath: *"results 2 din me (≤ 5 din — NSE ki date)"*.
>
> - **Sirf NSE ki announced date** ginti hai (1.5.14) — anumaan se kisi ko
>   nahi roka jata.
> - **Default OFF**, chip hamesha dikhta hai (1.5.17 ka rule).
> - Gate on hone par NSE calendar **ek hi baar** download hota hai (poore
>   universe ke liye, har stock ke liye nahi) — aur **dates na milin to page
>   likh kar batata hai** ki is filter ne kisi ko nahi roka.
> - Gate off hai to calendar download hota hi nahi.
> - Row apne saath **"results N din me"** rakhta hai chahe rok on ho ya nahi —
>   aankhon ke saamne ka number filter ka intzaar nahi karta.

> **1.5.23 — "Analysis" aur "Mera hisaab": do naye tab, poori tarah offline.**
>
> Advance Filter wale page par do naye tab. Dono ka ek hi niyam: **jo data
> phone me hai, usi se jawab** — koi naya request nahi, scan zaroori nahi.
>
> **Tab 3 — Analysis (teen cheezein, ek hi baar me):**
>
> | | Kya batata hai | Control |
> | --- | --- | --- |
> | **IVP / IVR** | Pichle dinon me se kitne % din aaj jaisi ya usse kam hilchal thi — *"premium mehnga hai ya sasta"* | 6 mahine / **1 saal** / 3 saal |
> | **DP** | Pichle dinon ke swing high-low se **aaj ke kareebi upar / neeche level**, kitni baar chhue | 20 / 40 / **60** / 120 din |
> | **Trend** | SMA + EMA — dono ek taraf to **pakka**, ulte to **seedha** | 1 mahina / **3 mahine** / 6 mahine / 1 saal |
>
> - **Sach chhupaya nahi gaya:** asli IVP/IVR ke liye IV ka *itihaas* chahiye,
>   aur broker sirf "abhi" ki IV deta hai. Isliye yahan **asli hilchal
>   (realised volatility) ka percentile** hai — matlab wahi, bas jhootha IVP
>   dikhane ki jagah sachchi baat likhi hai.
> - **Kam data ho to wahi likha jata hai** (*"kam data (30 din)"*) — na khaali
>   jagah, na khoke ka bharosa.
> - 25 se kam candle wala stock gina hi nahi jata, aur kitne stock ke data mile
>   / nahi mile — ye ginti upar likhi hoti hai.
> - Scan ke baad analysis **apne aap** tajja ho jata hai.
>
> **Tab 4 — Mera hisaab (aapka apna aaina):** har band hua paper trade joda
> jata hai us study snapshot se jo us stock ka sabse kareeb tha, phir natija
> **score / trend / IV** ke hisaab se. Jis bucket me **10 se kam** trade hain,
> wahan likha hai — *"sirf 3 trade — itne se kuch pakka nahi"*. Jin trades ka
> koi snapshot mila hi nahi (ya purana mila), wo bhi gine jate hain, chhupaye
> nahi jate.
>
> Iske liye har scan ke baad **study snapshot** save hota hai (nayi table
> `study_snapshots`, schema **v10**) — warna kal ko pata hi nahi chalega ki
> trade lene waqt study ne kya kaha tha.

> **1.5.24 — "Aaj kya kare": entry / stop / target wala plan card (B4).**
>
> Advance Filter wale page par koi bhi stock kholiye — 9-section wale panel ke
> niche ek naya card, **teenon raaste** ke saath:
>
> | | Entry | Stop | Target |
> | --- | --- | --- | --- |
> | **Stock** | CMP | 1×ATR **ya** DP wale support ke thoda neeche — *jo bhi bhav ke kareeb ho* | +2×ATR (**1:2**) |
> | **Option kharido** (CE/PE) | abhi ka premium | delta mile to spot ke level se, warna **−40% premium** | **+80% premium** |
> | **Jodi becho** (strangle) | mila hua premium | **1.5× premium** | premium ka **aadha** |
>
> - Stop **dono tarah se** dikhaya jata hai, aur likha hai ki kaunsa chuna gaya
>   aur kyun (*"stop DP ke level se — 1×ATR wala isse door tha"*).
> - **Seedha (SIDEWAYS) bazaar me stock ka plan banta hi nahi** — wahan likha
>   hai: *"koi pakka plan nahi; aisi jagah jodi bechna socha jata hai."*
> - Bechne (short) wale plan ke saath chetavni: delivery me nahi, sirf
>   intraday/futures.
> - **Sab kuch offline** — CMP, ATR aur DP ke level phone ke purane candles se.
>   Row khulte hi sirf **usi ek** stock ke candles padhe jate hain, poore
>   universe ke nahi.
> - Har plan ke neeche ek hi line: *"Ye **MECHANICAL** niyam hai (1×ATR / 2×ATR
>   aur DP ke level) — isme results, khabar ya subah ka gap shaamil nahi. Koi
>   guarantee nahi."*

> **1.5.28 — Results Calendar: nayi result meeting par NAYA.**
>
> Results Calendar ki row par **NAYA** tabhi dikhega jab NSE Board Meetings feed ke
> usi result-meeting record me `bm_timestamp` ho aur woh pichhle 48 ghante ka ho.
> `bm_date` meeting ka din hai, notice ka publication time nahi; timestamp missing
> ho to koi label nahi, aur app ka first-seen time kabhi fallback nahi banta.
> Nayi rows ka alag **Naya declared** filter hai; notice ka NSE timestamp row par
> dikhta hai, aur 48 ghante baad badge/filter eligibility khud expire ho jati hai.
>
> *Focused verification:* all 60 Results Calendar service/provider/screen tests pass,
> including live-shaped `bm_timestamp` parsing, missing/expired timestamp
> suppression, the NAYA badge/filter, and 48-hour expiry. Playbook ki NSE-date
> basis, six-sample cap aur on-tap single-stock candle fetch unchanged hain.

> **1.5.27 — Result Calendar: candle na ho to tap par Angel One se laao.**
>
> 1.5.26 me row tap hoti thi, par agar candle cache khaali hota to sheet ruk
> jati. Ek aur chhupa mismatch: screeners candles ko broker-symbol (`SBIN-EQ`)
> se save karte hain; playbook pehle plain ticker (`SBIN`) dhoondh raha tha.
>
> Ab row tap karte hi pehle broker-symbol wali cache check hoti hai. Agar NSE
> ke announced result dates ke aas-paas data **kam** ho, to sirf us tapped stock
> ke daily candles Angel One SmartAPI se aate hain, isi shared SQLite cache me
> save hote hain, aur sheet khul jati hai. Ek tap = ek stock, ek zaroori request;
> quote, scan, ya baaki 212 stocks ko touch nahi karta. Agli baar data wahi se
> milta hai — dobara download nahi.
>
> **Angel One login + internet chahiye** sirf tab jab local candle range kam
> ho. Login / network / scrip-master dikkat par seedha Hindi sandesh aur **Dobara
> koshish** button aata hai; broker data na bheje to uska bhi saaf jawab. Dates
> ab bhi sirf NSE ki announced dates; koi andaza nahi, result window jitni
> available ho utni (6 max).
>
> *Naye tests (2):* `SBIN-EQ` wali existing cache plain ticker ke bajay milti hai;
> cache miss par ek hi stock fetch/save hota hai, aur login na ho to actionable
> sandesh milta hai. SmartAPI ko sandbox se live call nahi kiya.

> **1.5.26 — Result Calendar: row tap karne par "pichle 6 result" ka hisaab.**
>
> Result Calendar ki har row ab **tap hone layak** hai. Tap karte hi ek sheet
> khulti hai: is stock ke pichle announced result dinon me kya hua tha.
>
> | | Pehle 5 din | Gap | Result din | Agla din |
> | --- | --- | --- | --- | --- |
> | **04 Nov 25** (Q2) | +1.8% | +0.9% | +2.4% | −0.6% |
> | **04 Aug 25** (Q1) | −0.7% | −1.4% | −3.1% | +0.2% |
>
> Upar chaar number: kitne **up / down** hue, result din ka **aam move**
> (±2.4%), sabse bada move, aur subah ka **gap**. Niche "kitne result mile" —
> 3 se kam ho to likha hai *"sirf 2 result mile — itne se pattern nahi keh
> sakte."*
>
> **Dates sirf NSE ki announced dates hain** (`result_history`, added in schema
> **v11** and retained in current schema **v13**; the filings feed now reaches
> roughly two years back). 15:30 ke baad ki filing ka move agle
> trading session se naapta hai, par official NSE date hi dikhata hai. Ek bhi
> andazi wali date nahi — purana
> niyam: *"kisi bhi date ka andaza nahi lagaya jaata."*
>
> — **Poore chhote raaste imaandaar**:
> - Jin result ke candles phone me nahi hain, wo chhod diye jate hain **aur
>   gin kar bataye jate hain**: *"Itihaas me 2 aur purane result hain, par un
>   dinon ke candles phone me nahi."* Chand result dikhana hi beimaani thi.
> - Candles hi na ho to wajah likhi jati hai (*"Golden Cross / 3-Month Study
>   scan chalane par candles save ho jate hain"*), khaali sheet nahi.
> - Purane build se upgrade karne par itihaas **ek baar** apne aap bhar jata
>   hai (NSE se dobara padh kar) — nahi to sheet hamesha khaali rehti.
>
> *Naye tests (21):* playbook ka hisaab (gap / result din / agla din / run-up,
> duplicate din ek hi baar, 6 ki limit, "candles se purane" ki ginti), NSE ke
> jawab se itihaas nikalna, `result_history` round-trip, aur sheet khulna /
> band hona (widget).
>
> Ek aur theek ki gayi cheez: boot ke dauraan splash ki line ab **disposed
> notifier par nahi likhi jati** (screen beech me hat jaye to release build
> us exception ko kaali screen bana deta hai).

> **1.5.25 — Paper trading: Export / Import (PDF · Excel · DB), date ke hisaab se.**

> Trade Book tab ke upar ek nayi patti — **Export / Import**. Isme teen format
> aur "kaunse din" ka chunav:
>
> | Format | Kya milta hai | Kab kaam aata hai |
> | --- | --- | --- |
> | **PDF** | Upar hisaab (legs, win rate, realised, charges, net), niche har leg ki line | Chhapna, ya kisi ko bhejna |
> | **Excel** | 3 sheet — *Hisaab*, *Legs* (raw number, formula lagao), *Matlab* | Apna hisaab lagana, pivot |
> | **DB file** | App ka data — **ALL** me poora DB, **Custom** me sirf chune hue din | Backup, ya doosre phone par le jana |
>
> **Din ka chunav — default `Sab (ALL)`.** Jab tak aap date na chunein, kuch
> chhuta nahi. Taiyar chunav: *Aaj · 7 din · 1 mahina · 3 mahine · 1 saal*, aur
> **Custom date** (se … tak, dono alag se).
>
> **Import hamesha JODTA hai (merge) — purana data kabhi nahi mitta.** Jo leg
> pehle se maujood hai (same symbol + side + qty + price + time) woh chhod di
> jati hai; baaki sab jud jata hai. Group ka milan **naam** se hota hai
> (case-insensitive), isliye "Momentum" do baar nahi banta. Cache wali
> taalikayein (scrip master, candles, settings) chhod di jati hain — woh app
> khud dobara bana leta hai, aur aapki settings overwrite karna khatarnak hota.
> Galat version ki file ho to **kuch bhi chhue bina** saaf message milta hai.
>
> Do cheezein seedhi bata di gayi hain, chhupayi nahi:
> - **ALL wali DB file badi hoti hai (30–80 MB)** — isme poora scrip master aur
>   candles hain. WhatsApp se bhejna mushkil hoga: ye **backup** ke liye hai.
> - **PDF ki body Angreezi + ankdo me hai.** App ke saath bundle font me ₹ hai,
>   par Hindi ke akshar nahi; Hindi group ka naam PDF me `?` ban jata hai (UI me
>   theek dikhta hai).
>
> *Naye tests (27):* range ka hisaab (default ALL, custom boundary), kitaab ki
> chhantai, asli .xlsx (3 sheet), asli PDF + font me ₹, DB copy/merge
> (duplicate chhut-te hain, purana data nahi mitta, galat schema par kuch nahi
> badalta).

> **1.5.21 (paanchva build).** Dono study page — **3-Month Study** aur **3 Month
> Study with Advance Filter** — me ab **ATR wale hisse me do nayi cheezein**:
>
> - **ATM jodi % of price** — CE + PE ka premium, stock ke bhav ka kitna
>   percent. `₹16.10 ka jodi, ₹130 ke stock par = 12.38%`.
> - **OTM jodi % of price** — wahi hisaab strangle (door ke strike) ke liye.
>   `₹6.50 = 5.00%`.
>
> Rupee me comparison alag-alag stock par chalta nahi (₹16 ka jodi ₹130 ke
> stock par mehenga, ₹1,000 wale par sasta) — **% se seedha muqabla hota hai.**
>
> Ye ab **teen jagah** dikhte hain: **card par** (bina tap kiye), **tap karke
> khulne wale panel me ATR ke theek neeche**, aur **export** me 2 naye column
> ke saath (Excel/CSV, aur Read Me me dono ka matlab). **Live feed** chalu hai
> to **khuli hui row ka % live premium se banta hai**, baaki row scan wale
> rate se.
>
> Jiska option data nahi mila, wahan **0% nahi** — **khaali** chhod diya jata
> hai (ek jhootha 0 kisi ko trade karwa sakta hai).

> **1.5.21 (chautha build, usi din).** Teesri APK me naye page par card khul
> to raha tha, par usme **sirf score, filter aur tag** likhe the — **jodi, kal
> jodi ka P&L, IV, ATM, results date, tap par detail, export: kuch nahi.**
> Hisaab sab ho raha tha andar hi andar, card par chhap raha tha nahi.
>
> Ab naye page ka card **purane "3-Month Study" page jaisa hi** sab kuch
> chhapta hai:
>
> - **OTM jodi** — dono strike (jaise `123.5 PE + 136.5 CE`), **₹6.50** total,
>   aur **kal ₹6.00 → Profit 0.50 pts**;
> - **IV 18.2%** · **ATM jodi ₹16.10** · **N din bache**;
> - jiska option chain na mile, wo chhupta nahi — **"option chain nahi mila"**
>   likh kar aata hai;
> - **card par tap** → wahi purana **poora detail panel** (9 hisse: price/3M
>   levels, volatility, mahine ki move, trend, ATM option, OTM jodi, Results
>   (NSE), kal jodi, kal OTM jodi) — upar **Naya / Purana / farq** score ki
>   patti;
> - **live premium** bhi wahi: ATM, kal-ATM, jodi aur kal-jodi — WebSocket se,
>   purane page ke jese hi (`fno_study_adv` naam se subscribe);
> - **export** — AppBar me share ka button, **wahi chaar raaste** (Excel, CSV,
>   WhatsApp, Telegram) aur **wahi 40 column**, plus teen naye: **Score
>   (purana)**, **Farq**, **Chhoota kyun** (kaunse gate ne roka).

> *Naye tests (123):* kaunsa gate kis number par lagta hai, gate ki line, aur
> "blocked row kabhi drop nahi hoti"; A1 (edge ke bina 🎯 nahi), A2 (ek hi
> paimaana), A3 (2-session ka mahina consistency nahi hilata), A4 (2 mahine =
> 2 point), A5 (expiry paas to 🎯 nahi), backtest me look-ahead nahi, band ka
> jod trade ke barabar, sideways par zero trade, chhota itihaas skip;
> provider me "khud chalne wala kuch nahi", ek waqt me ek kaam, filter badal
> ne par dobara scan nahi, chhooti hui row "kaun chhoota" me bachi rehti hai,
> sort ka rukh; aur card + report ki har line screen par render hokar.

> **1.5.20 — "Ye rule kitni baar sahi pada?" — ab app khud apna backtest /
> hit-rate nikalta hai.**

> Pichhle do release me engine ne batana shuru kiya: *kaun strong hai*, phir
> *kahan ghuse, kahan kate, kitna*. Ab aakhri sawal: **"ye rule sach me kaam
> karta hai ya sirf sundar lagta hai?"** Is ka jawab bhi phone par, aapke hi
> purane data se milta hai — koi model, koi internet, koi andaza nahi.

> **Kya hota hai.** App poore F&O universe ke purane candles par wahi signal
> doharata hai jo aaj "AI Suggestion" de raha hai — **Breakout / Breakdown /
> Pullback / Bounce**, aur sirf tab jab direction (upar/neeche) bhi usi taraf
> ishara kare. Phir ginta hai.

> **Hisab ka niyam (sab kuch khula hai):**
> * **Signal shaam ko, entry agle din ke open par** — aaj ka result kal ke data
>   se nahi banaya jata (koi look-ahead nahi).
> * **Stop = 1 ATR, target = 2 × stop** — wahi plan jo card par hai.
> * **Har trade ko 5 / 10 / 15 din** (aap chuno). Ek hi din me dono level
>   chhuye to **stop mana jata hai** — sakht nazariya, taaki report khud ko
>   achchha na dikhaye. Gap khula to nuksan asli open par gina jata hai.
> * Koi level na chhue to trade aakhiri din ke close par band.

> **Screen par kya dikhta hai.** Headline seedhi baat hai: **`120 baar aaya ·
> 58% sahi disha · ausat +1.8%`**. Uske niche har number apne sample ke saath:
> kitne me target laga, kitne me stop, kitne bina kuch hue, **ausat R** (1R =
> 1 ATR ka jokhim) aur **sabse bura daur** (lagatar kitna ghat sakta tha).
> Alag se table: **kaunsa rule** kitna sahi (Breakout alag, Breakdown alag),
> aur **kaunse stock** me rule ne kaam kiya ya nahi (sirf 5+ trade wale).
> Chuno: **1 / 2 / 3 saal** ka itihaas.

> **Imaandaari (ye hissa kabhi chhupaya nahi jata):**
> * **Ye koi guarantee nahi** — purana natija aage ka natija nahi batata.
> * Hisab **stock (underlying) ka hai, option ka nahi**: purane premium ka
>   itihaas app ke paas nahi hai, aur option me theta/IV bhi chalte hain.
> * **Kharcha shamil nahi** — brokerage, STT/GST, slippage, bid-ask alag se
>   katenge.
> * Chhota sample to **"kam sample — is par bharosa nahi"** chip ke saath aata
>   hai. Kitne din "mixed" the (pattern aur direction alag-alag), kitne stock
>   ka data nahi mila, aur kitna data broker se lena pada — sab likha hai.

> **Offline.** Pura run phone ke cache se hota hai. Jis stock ka itna purana
> data cache me nahi hota, wo **ek baar** liya jata hai (har stock ke liye ek
> request) aur uske baad hamesha offline chalega — report khud batati hai ki
> "0 internet call" gayi ya 12.

> *Naye tests (37):* target/stop/samay-khatam ka hisaab, gap wala nuksan,
> ek hi din me dono level (stop pehle), entry agle open par, horizon ke bahar
> ka target gina nahi jata, signal (volume ke bina nahi, mixed ginati), stats
> (ausat/median/sabse bura daur/chhota sample), poore universe ka jod aur
> "same data = same report", rolling gate ke indicators har bar snapshot se
> mile (gate chhup kar trade nahi ghatata), service me "cache ho to zero
> network call", thin cache ek baar bhara jata hai, aur report ki har line
> screen par render hokar.

> **1.5.19 — Ab har idea ke saath poora plan: entry, stop, target, aur kitne
> lot. Aur expiry ka chunaav bhi theek.**

> Pichhle release tak engine ye batata tha: *kaunsa stock strong hai, kya
> karna chahiye.* Par ek sawal chhoot raha tha — **"kahan kharidu, kahan
> katu, aur kitna?"** Ab card par ek **TRADE PLAN** hissa hai.

> **1) Expiry ka niyam (DTE).** Pehle scan sabse nazdik expiry utha leta tha —
> jo aksar aaj ya kal ki hoti hai. Ab:
> * **Expiry wale din** koi nayi position nahi: *"Aaj expiry hai — theta aur
>   pin risk."*
> * **Kharidne (Buy)** ke liye kam se kam **7 din** chahiye — theta har din
>   premium khaata hai, is liye jitni lambi expiry utni sahi.
> * **Bechne (Sell / strangle)** ke liye ulta: **3 se 20 din** ki window.
>   Pehle 3 din me gap ka jokhim poora rehta hai, aur 20 din se aage theta
>   itna dheema chalega ki munafa atak jayega.
> * Ab scan **wo expiry chunta hai jisme dino ki zaroorat poori ho** — sirf
>   "sabse nazdik" nahi. Agar koi expiry bhi kaafi door na ho to trade roka
>   jata hai, chupke se galat expiry nahi li jati.
> Teeno hadd Settings me badal sakte hain (risk %, min/max din).

> **2) TRADE PLAN — har card par.** Hisaab seedha hai aur card par likha hai:
> * **Jokhim pehle:** risk = **1 × ATR** (ya option me premium ka −40 %).
> * **Target usi se:** **2 × risk** — par **52-week high/low ke aage nahi**,
>   chahe 1:2 kharaab ho jaye. Number kharaab dikhaye jate hain, chhupaye
>   nahi.
> * **Entry:** breakout ho to CMP se 0.25 ATR upar *trigger* (`1489.05 ke upar
>   (CMP 1482.30)`), warna CMP ke aas-paas.
> * **Option:** premium stop −40 %, target +80 % (premium par bhi 1:2).
> * **Kitne lot:** `capital ka 1.5% ÷ 1 lot ki jokhim`. Ek lot bhi mehnga ho to
>   card likhta hai: **"1 lot bhi limit se upar — chhod do ya filter dhila
>   karo"** — jokhim ko chhota karne ke liye "thoda aur" ka jhansa nahi.
> * **Sell wali strategy** par lot ka hisaab nahi dikhlaya jata (uska kharcha
>   margin hai, premium nahi) — card yahi likhta hai.

> *Naye tests (20):* plan ka hisaab (risk/reward/ATR aur 52-week cap, bearish
> mirror, premium stop/target, lot size, chhoti capital par "1 lot bhi upar"),
> expiry ka chunaav, expiry-din aur kam-din wali manaahi, sell ki window, card
> par plan ki har line, aur service me expiry/plan ka judna.

> **1.5.18 — Do analyst filter: result-date check + liquidity (turnover) check,
> aur ab list export bhi.**
>
> Pichhle release ke baad maine socha: engine "kaun strong hai" to batata hai,
> par "ye trade lene layak hai" nahi. Do sabse bade chhupe jokhim ab check hote
> hain:
>
> **1) Result date (event check).** Result jitna paas, utna khatra:
> * **Kharidne wale ke liye:** result ke turant baad IV girta hai — direction
>   sahi hone par bhi premium sasta ho jata hai (IV crush).
> * **Bechne wale ke liye:** result ke din gap lag sakta hai — strangle sell me
>   nuksan bada.
> Is liye **confirm** result (sirf NSE board-meeting wali, koi andaza nahi) jis
> window me ho (default 5 din, Settings me badal sakte hain) us stock ko
> **"Wait — Result 3 din me"** milta hai. Result **expiry ke baad** ho to koi
> rok nahi — option tab tak khatam ho chuka hoga (aur IV result se pehle badhta
> hai, jo kharidne wale ke liye achchha hai).
>
> **2) Liquidity (turnover) gate.** Pichhle 20 din ka average cash turnover
> (₹ crore/din) — default **10 cr** se kam ho to stock list me aata hi nahi.
> "Breakout" aisa jise aap bhar hi nahi sakte, wo edge nahi hai. Card par
> `turnover ₹42 cr` chip, aur "kaun chhoota" me `turnover 0.4 cr < 10 cr` likha
> aata hai. Option ki taraf se bhi: jodi ka premium spot ke 0.2% se kam ho to
> "premium patla hai" keh kar trade roka jata hai.
>
> **3) Export.** Ab poori list nikal sakte hain — WhatsApp (text), Excel
> (.xlsx), CSV, Telegram. 25 column: Rank se le kar Technical rationale, Result
> date, Action/Strategy/Strike/Jodi, IV, jodi total, lot, aur **"Kyu"** —
> Excel me ek "Read Me" sheet jisme filter, funnel aur pura rule likha hai.
>
> Funnel line ab chaar kadam dikhata hai: `213 scan hue · 180 liquidity paar ·
> 41 study paar · 12 momentum paar · 12 list me`.
>
> *Naye tests (20):* turnover ka hisaab, liquidity gate (band karne par stock
> wapas aata hai), result window (3 din → Wait, 12 din → trade, expiry ke baad →
> trade, andaze wali date → ignore), user ka window, patla premium, card par
> turnover + result chip, aur export ke column/recap/Read Me.

> **1.5.17 — "Sirf 3 stocks kyu aa rahe hain?" — do wajah, dono theek.**
>
> **Wajah 1 — score ka ek hissa bahut sakht tha (hamari galti).** "52-week high
> se kitni doori" wale 20 point *5 %* ki patti par map ho rahe the: 5 % se zyada
> neeche wale **sabhi** stock ko 0 milta tha — 6 % neeche wala aur 40 % neeche
> wala barabar. Bazaar me zyada tar stock apne high se 5 % se zyada door hote
> hain, is liye score gir gaya aur 55 ki bar sirf 2-3 stock paar kar paaye. Ab
> ye hissa **25 % ki patti** par map hota hai (high par 100, 25 %+ neeche 0) —
> 8 % aur 30 % neeche wale ab barabar nahi. Aapka 5 % wala filter wahi kaam
> karta hai: wo "near 52w high" **likhai** tay karta hai, score nahi.
>
> **Wajah 2 — default bar hi sakht thi.** Min momentum score **55 → 45**, min
> 3-month study score **6.0 → 5.0** (Settings me kabhi bhi badal sakte hain).
>
> **Aur ab app khul kar batata hai ki list kahan ghanti hai.** Scan ke baad
> banner me ek **funnel** line: `213 scan hue · 41 study gate paar · 12 momentum
> gate paar · 12 list me`. "Kaun chhoota" sheet me naya hissa **FILTER SE
> BAHAR — sabse nazdik 10**: har stock ke saath uska number aur bar
> (`RELIANCE · momentum 48 | bar 45`), taaki andaza na lagana pade. List Top-N
> se chhoti ho to note khud likhta hai ki "is se zyada stock filter paar nahi
> kar paaye".
>
> *Naye tests (3):* 8 % aur 30 % neeche wale ab tie nahi karte (regression pin),
> funnel ke counter (kaunsa gate, kitne bache), aur sabse-nazdik ki list.

> **1.5.16 — Naya F&O tool: "AI Suggestion" (top 20 ideas, har ek ke saath
> option ki jodi).**
>
> Aapki baat: equity+commodity ka ek analyst/strategist jaisa module — Rank,
> Stock, Direction, Expected Movement, Technical Rationale, aur Options Strategy
> (Action / Strategy / Strike Type / Jodi), sab user-ke-filter ke saath.
>
> **"AI" ka matlab yahan:** koi online model/API nahi. Ye phone par chalne wala
> **local rule engine** hai — aapke candles, aapke indicators, aapke niyam. Is
> liye same data + same filter = hamesha same list, aur har line ke piche ek
> number hai (koi bina hisaab ki baat nahi).
>
> **Kaise chunta hai:** poore F&O universe ke candles (cache se) → RSI, 9/21 EMA,
> 50 DMA, 52-week high/low, ATR, volume, pattern (breakout / breakdown /
> pullback / bounce / range / overbought / oversold) → momentum score (0-100) →
> 3-Month Study ka score gate → top N. Sirf un top N ke liye option ki jodi
> (ATM pair + OTM pair) local contract book se, aur premium ek hi batched quote
> call me.
>
> **Option strategy ke niyam** (card par "kyu" ke saath likhe hote hain):
> * Trending + premium sasti → **ATM kharido** (Directional Buy: CE ya PE).
> * Trending + premium mehengi (IV/√252 ≥ 1.25 × ATR%) → **spread**: ATM
>   kharido, OTM becho.
> * Breakout + ATR ≥ 2.5% → **Straddle (ATM jodi)**.
> * Sideways + premium mehengi → **Strangle sell (OTM jodi)** — risk ki chetawani
>   card par hai.
> * Sideways + premium sasti → **Wait** (koi trade nahi).
>
> **Filter aapke:** RSI oversold/overbought (default 35/65), volume spike (1.5x),
> 52w-high doori (5%), min study score (6.0), min momentum score (55), list ki
> lambai (20). Screen ke tune icon ya Settings → F&O — AI Suggestion se badlo;
> badlav turant save hota hai aur agli list usi ke hisaab se banti hai. Filter
> badalne par purani list "filter badla" chip dikhane lagti hai.
>
> Network ka kharcha: candles cache se; **IV quote se Black-Scholes se solve**
> (alag greeks call nahi); OTM strike local chain se — yani poore 20 ideas ka
> kharcha **ek batched quote call** (≤50 token). Quote fail ho to bhi list
> rahti hai, sirf "jodi" ki jagah "data nahi mila" likha aata hai.
>
> *Tests (62 naye):* indicators (RSI/EMA/SMA/ATR/volume/52w, pattern, score),
> strategy rules (har direction × premium × ATR), card par sabhi field, aur
> service end-to-end (ranking, Top N cut, filter badlo to row ghat ti hai,
> broker error par skip + wajah, cancel, cache se doosra run, greeks call kabhi
> nahi).

> **1.5.15 — 3-Month Study me ab ATM jodi ke saath-saath OTM jodi (strangle)
> bhi — wahi sab functions.**
>
> Aapki baat: "ATM jodi ke liye banaya hai vesa same function strangle ke liye
> bana do" … "SABKUCH SAME, SIRF JODI ATM SE CHANGE HOKE OTM HOGI".
>
> **OTM jodi kya hai:** ek CE upar wale strike par, ek PE niche wale strike par
> (dono ATM ke bahar). Isse wahi milta hai jo ATM jodi deti hai: do legs, jodi
> ka total, "agar kal kharidi hoti" ka P&L, paper trade, live tick, export.
>
> **Strike kaise chuna jata hai (aapka rule):** `ATM CE+PE / 2` — yani ATM jodi
> ke kul premium ka aadha. Chain me upar/niche ja kar wahi pair liya jata hai
> jiska dono leg ka kul premium us aadhe ke **sabse najdik** ho. Chunaav ke
> liye Black-Scholes ka estimate use hota hai (sirf ranking ke liye); **jo
> premium aapko dikhta hai wo broker ka asli quote hai**, model ka nahi. Har
> jagah likha hai ki ye rule kya tha.
>
> Kya-kya milta hai (ATM jodi jaisa, poora):
> * **ATR ke neeche** ab do line: `Jodi total (CE+PE)` (ATM) aur
>   `OTM jodi total` — dono live tick ke saath.
> * **Naya section 6 · OTM jodi (strangle):** CE/PE strike + LTP, jodi total,
>   ATM jodi se kitna sasta/mehnga (%), aur rule ki line.
> * **Naya section 9 · Agar kal OTM jodi buy ki hoti:** kal ke close par jo OTM
>   pair milta, uska Profit/Loss — bilkul ATM wale section jaisa.
> * **Paper trade sheet** me ab dono group: `ATM jodi` aur
>   `OTM jodi (strangle)` — har leg par BUY/SELL.
> * **Live feed** OTM legs ko bhi subscribe karta hai, **export** me 4 naye
>   column (OTM CE strike, OTM PE strike, OTM jodi total, kal ka OTM P&L).
>
> Network ka kharcha: chain local DB se padhi jati hai, aur quote sirf chune
> hue pair ke 2-4 token ka mangwaya jata hai (ek batched call me 50 token).
> Chain/quote na mile to OTM jodi `null` rehti hai aur panel likhta hai
> "Is stock ki OTM jodi nahi ban payi" — koi jhoothi line nahi.
>
> *Guard tests (10+ naye):* picker OTM + symmetric hai, sasta target bahar ki
> taraf jata hai, chain/IV/expiry na ho to koi answer nahi, scan ke baad row par
> strangle + kal strangle lagte hain (170 CE / 150 PE, premium broker ka), bina
> OTM strike wali chain me kuch nahi lagta, panel me section + P&L + live tick +
> paper-trade dono group.

> **1.5.14 — teen chhote, seedhe sudhaar (aapki teen baatein).**
>
> 1. **Results Calendar ab `Confirm` filter par khulti hai.** Page ka kaam
>    announced dates dikhana hai, to ab khulte hi sirf wahi companies dikhti
>    hain jinke board meeting ka notice NSE par hai. `Sab` ek tap door hai, aur
>    headline counts hamesha **poori** F&O list ke hote hain.
> 2. **3-Month Study: ATM jodi ka total ab ATR ke theek neeche.** ATR(14) ke
>    niche wahi `Jodi total (CE+PE)` line (live tick ke saath) — ATR aur jodi
>    ka daam ek saath padhne ke liye. ATM option section me bhi wahi line hai
>    (ek hi number, ek hi helper — dono jagah same value).
> 3. **3-Month Study me anumanit (andaze ki) result date bilkul nahi.** Jo
>    declare ho chuka hai wo dikhta hai (`Last result` / announced `Next
>    result`), baaki jagah kuch nahi chapta — na koi guess, na koi "anumanit"
>    chip. F&O hub ki purani anumanit wali line bhi badal di.
>
> Saath hi: filter lagne par blank page ab asli wajah chupata nahi — NSE down
> ho to **"Dubara try karo"** wala block hi dikhta hai (pehle default filter ke
> saath sirf "Confirm me koi company nahi hai" likha hota tha).
>
> *Guard tests (6 naye/updated):* page Confirm par khulti hai + counts poori
> list ke, jodi total ATR ke neeche *aur* ATM section me (live tick dono par),
> bina option legs wali row par jodi line bilkul na ho, search/filter ke saath
> bhi retry block, aur purana anumanit text kahin nahi.

> **1.5.13 — Results Calendar me ab koi *anumanit* (guessed) date nahi; jahan
> date nahi mili wahan **pichla result** ki line.**
>
> Aapki baat: "anumanit vala nahi chahiye, aur jo nahi mile vaha niche last
> result kab aaya tha vo likh ke de do".
>
> 1. **Andaze ki date hamesha ke liye hata di.** Pehle app, NSE ka board-meeting
>    notice na hone par, pichle result me ~91 din jod kar ek date chapa karta
>    tha (chip: `anumanit`). Wo date asli nahi thi — par asli date jaisi dikhti
>    thi. Ab: notice nahi to **date nahi**.
> 2. **Har aisi company ki line me pichla result likha hai** —
>    `Pichla result: 04 Nov 2025 · Q2 · quarter ended Sep 2025 · 62 din hue`
>    (kab aaya, kaunsa quarter, kitne din hue). Jiska pichla result bhi NSE feed
>    me nahi hai, wo purani tarah `NSE ke results feed me abhi nahi mila`
>    kehta hai.
> 3. **Purane cache se koi guess wapas nahi aata.** 1.5.12 ki likhi hui guessed
>    rows (DB me `estimated = 1`) padhte hi drop ho jati hain — date hat ti hai,
>    pichla result rehta hai. Study panel ka "Next result" bhi wahi rule
>    maanta hai.
> 4. Header ka `anumanit` counter hat kar **`pichla pata`** ho gaya (kitni
>    companies ka pichla result pata hai), filter chips ab `Sab / Confirm /
>    NSE me nahi`, aur Read Me + footer bolte hain ki koi date andaze se nahi
>    banayi jaati.
>
> *Guard tests (7 naye):* koi intimation nahi → koi date nahi (merge + provider),
> legacy estimated row DAO me drop + provider me bhi nazar na aaye, announced
> date ka cache round-trip safe, "Pichla result: …" line ka exact text (screen),
> study panel me guessed date bilkul print na ho, aur filter/chip wording.

> **1.5.12 — Results Calendar khaali kyun dikh raha tha (fix + guard).**
>
> Aapki report: "abhi koi bhi data nahi aa raha". Wajah code me hi thi, aur ek
> *class* ki thi — NSE ka jawab aane par bhi app ka behaviour use "data nahi
> hai" samajh leta tha:
>
> 1. **NSE ka block/HTML page JSON jaisa parse hota tha** → 0 rows → poora
>    aane wala calendar **khaali** dikhta tha. Ab non-JSON jawab
>    **failure** hai, "NSE par kuch nahi hai" nahi.
> 2. **Khaali result cache ko mita deta tha** aur uska timestamp "aaj" set kar
>    deta tha → page khaali *aur* "aaj ka fresh" — din bhar retry hi nahi hota
>    tha. Ab: khaali result **kabhi** purani list ko nahi mitata, aur "fresh"
>    sirf tab likha jata hai jab kuch mila ho.
> 3. **Ek feed fail = poora refresh fail.** Board-meetings block hone par
>    filings ka data bhi chala jata tha. Ab dono feeds **alag-alag** chalti hain,
>    aur jo feed fail hui uska purana hissa cache se **back-fill** hota hai.
> 4. **Request shape:** NSE ke bot filter ko humara apna User-Agent
>    (`NiveshDesk…`) pasand nahi aaya — ab browser jaisa UA + plain (bina date
>    window) query ka **ek retry**.
> 5. **Page ab chup nahi rehta:** "NSE se data nahi aaya (board meetings: HTTP
>    403)" jaisi line + **"Dubara try karo"** button, aur aakhri koshish ka
>    time. Retry ab har baar hoti hai, din me ek hi nahi.
>
> *Guard tests (6 naye):* HTML block page → failure (cache safe), `[]` jawab →
> table intact + next load retry, ek feed down → doosra chalta rahe +
> back-fill, rejected date window → plain query fallback, khaali calendar kabhi
> "fresh" memo na bane, aur provider ki warning line.

> **1.5.11 — F&O options ab paper trading me poori tarah: BUY *aur* SELL.**
>
> Pehle option sirf **buy** ho sakta tha (book long-only tha — sell karne par
> "pehle buy karo" error aata tha). Ab option par **buy (long)** aur
> **sell (short / likhna)** dono ho sakte hain, aur short ko baad me **BUY se
> cover** karte hain. Sab paper hi hai — paisa nahi lagta.
>
> * Kitne **lots** trade karne hain wo chunte hain (1 lot = jo lot size us
>   contract ka hai, e.g. 1 lot × 75 qty), aur adhoora lot reject hota hai.
> * **Charge ab F&O ka sahi stack** hai: brokerage ₹20/order, STT sirf sell
>   premium par 0.1%, exchange 0.0495%, SEBI, stamp 0.003% buy par, GST 18%,
>   DP charge **nahi** (pehle equity ke rates lag rahe the, jo option ke liye
>   galat hain).
> * **P&L dono taraf** sahi: short me premium **girne** par profit banta hai;
>   stop-loss short ke liye **entry se oopar** hota hai (aap `%` daalo, app
>   price khud nikalta hai) aur hit hone par market se cover ho jata hai.
> * **Holdings** card par `LONG` / `SHORT` tag, exit ka naam short ke liye
>   "**Cover at market**", aur account value me short ki liability ka sign
>   theek (premium do baar nahi ginti).
> * F&O study ke CE/PE picker me **BUY** aur **SELL** dono buttons.
>
> *Cash note:* short ka premium cash me turant jama hota hai (broker ki tarah
> margin block karke SPAN+exposure calculate karna offline paper me possible
> nahi) — recharge/P&L ledger exact rehta hai.

> **1.5.10 — do bug fixes (aapki report se).**
>
> **(1) "Kal jodi" ka buy value galat strike se aa raha tha.** Pehle line aaj
> wale ATM strike ke CE+PE ka kal-close le rahi thi. Stock move hone par
> (jaise ALKEM 5,100 → 5,300) woh strike wahi nahi hota jo kal ATM tha, is liye
> buy value galat banti thi aur zyadatar stocks me **loss** dikh raha tha.
> Ab line **kal wale ATM strike** (pichhle session ke close se nikala gaya
> strike) ke CE+PE par banti hai: buy value = usi pair ka kal ka close, current
> value = usi pair ka aaj ka premium (live tick chalta rahega). Wording me
> strike number bhi dikhta hai, aur purane snapshot (jisme ye data nahi hai)
> saaf bolta hai "scan dobara chalao" — galat number kabhi nahi.
>
> *Audit:* ye galti ek *class* ki thi — "kal ka number aaj ke strike par
> lagana". Poori study ka audit hua: edge, IV, IV rank, ATR%, score, aur
> BUY CE/PE/AVOID suggestion sab ek hi din ke data se bante hain (recommendation
> options ko chhooti hi nahi), aur ab **4 guard tests** ye invariants pin karte
> hain — edge = aaj ka ATR% − aaj ka IV/√252, suggestion options se bilkul
> independent, CMP/aaj-ka-strike/kal-ka-strike apne-apne din ke close se, aur
> purana galat formula (`straddleLtp − kal base`) dobara kabhi possible nahi.
>
> **(2) Results Calendar me declared results ki date nahi aa rahi thi.** Do
> wajah thi: (a) NSE se board meetings sirf 7 din peeche tak maangi jaati thi,
> is liye haal ke declared results ka pata hi nahi chalta tha; (b) jo board
> meeting ho chuki hoti thi woh "next" list se hat jaati thi — aur jis company
> ki filing NSE ke filings feed me der se aati hai, wo khaali dikh jati thi.
> Ab: board meetings **100 din peeche** tak maangi jaati hain, hui hui meeting
> ka matlab hai "result declare ho gaya" (last result ki date wahi dikhti hai,
> filing feed ka intezaar nahi), aur jis meeting ka filing aa chuka hai woh
> "next" me kabhi nahi dikhti. Saath me: cache ab **naye din par khud refresh**
> hoti hai (pehle 20 ghante tak purani list chipki rehti thi).

> **1.5.9 — naya tool: Results Calendar (apna alag page).** F&O hub me doosra
> card: **saari 213 F&O companies ki next result date**, date ke hisaab se
> sorted — 3-Month Study se bilkul alag, koi scan/candle nahi. Har row: date
> tile + symbol + company + countdown (`17 din baaki`) + tag.
> **confirm** = NSE par board meeting ka notice aa chuka hai; **anumanit** =
> notice nahi aaya, date pichle filing + ~91 din se lagayi (estimate);
> **NSE me nahi** = feed me kuch nahi mila. Header me poore list ke counts
> (confirm / anumanit / missing), search, 4 filter chips, pull-to-refresh aur
> refresh button, Read Me. Estimate ko estimate hi batate hain — pakki date
> kabhi jhooth nahi bolti. NSE board-meeting window ab 7 din peeche se 120 din
> aage tak maangi jaati hai (warna agla quarter miss ho jaata). Ye page bhi
> wahi din-cache (20 h) use karta hai — din me ek hi NSE fetch.

> **1.5.8 — company ka last result kab aaya, next kab aayega.** Study panel me
> ATM option ke neeche nayi section **6 · Results (NSE)**: "Last result —
> 14 Oct 2025 · Q2 · quarter ended Sep 2025 (…din pehle)" aur "Next result —
> 22 Jan 2026 (…din baaki) · board meeting confirm". Source: NSE ke do public
> corporate-filings feeds (board meetings = **confirm** date; financial results =
> last filing), ek din ka cache, app din me ek hi baar NSE ko chhuti hai. Jahan
> NSE ne meeting announce nahi ki, next date **pichle result + ~1 quarter** se
> estimate hoti hai aur saaf "anumanit" likha aata hai — estimate ko announcement
> nahi batate. NSE se kuch na mile to line khud bataati hai (aur purani date
> cached rehti hai). (Angel SmartAPI me results-calendar endpoint nahi hai —
> isliye NSE, wahi fallback role jo aapne pehle confirm kiya tha.)

> **1.5.7 — ATM jodi ka total, aur IV source hata diya.** ATM option section me
> ab **Jodi total (CE+PE)** dikhta hai — dono legs ka mila kar kitna lagta hai
> (live tick aane par ye number bhi socket ke saath update hota hai, sirf legs
> nahi); wahi total paper-trade sheet ke header me bhi likha aata hai. Aur
> **IV source** wali line UI se hata di (IV kahan se aayi — broker chain ya
> Black-Scholes — wo ab sirf Excel/CSV ki Read Me sheet me rehta hai, screen par
> jagah nahi leta).

> **1.5.6 — heading ab **total F&O stocks** dikhati hai, resolved subset nahi.**
> Page kholte hi heading "poore 45 stocks" likh rahi thi jabki list me 213 hain:
> wo number **local book** ka resolved count tha (thin/stale master), aur usse
> lagta tha ki sirf 45 stocks scan honge — jabki scan khud master update karke
> poore 213 cover karta hai. Ab button, empty-state aur headings **F&O list ka
> total (213)** dikhate hain, aur neeche sach likha aata hai: "45 of 213 resolve
> hue — scan dabao, master update karke poore 213 ho jayenge." (Verified against
> the live master: saare 213 names NSE cash me resolve hote hain.)

> **1.5.5 — chhoti UI safai (aapke 3 points).** (1) Study panel me **CMP** ka
> label ab sirf "CMP" hai — "(study day)" hata diya (din ki jaankari Read Me
> sheet me hai hi). (2) **ATM option** section aur CE/PE picker me ab sirf **CE**
> aur **PE** likha aata hai — pehle har leg ke saath pura broker symbol
> (`RELIANCE26JAN2650CE`, yaani expiry) bhi chipka hua tha. (3) Study panel ke
> actions **side me** (right) compact ho gaye — "Paper trade me add karo" ab
> poori width me nahi chalta, chhota tonal button banke "Band karo" ke saath
> right me baithta hai.

> **1.5.4 — storage diet (measured, not guessed).** The whole question "ye app
> kitni jagah leti hai?" now has a number in the app: **Settings → Storage**
> shows the database size (about **6 MB** with a full instrument cache) and the
> row counts behind it. The broker's 34 MB master file is *never* written to
> disk — it is streamed and filtered to ~40k useful rows — and 1.5.4 trims those
> rows further: the option book no longer stores `trading_symbol` (a
> byte-for-byte copy of `symbol`) or `expiry_label` (re-assembled from the date,
> byte-for-byte the string the greeks endpoint wants), `scrips` dropped a
> write-only `updated_at`, and the far option months are kept **only during the
> roll window** — the last 10 days before expiry, when the next series actually
> matters. A **Compact karo** button reclaims what a rewrite left behind. Net
> effect: a full book costs **~4 MB instead of ~6.3 MB**, with the same data
> available. Existing installs migrate in place (rows copied, no re-download).

> **1.5.3 — roz 34 MB download karna zaroori nahi.** The daily scrip master is
> a 34 MB file (~1.45 lakh instruments). The app now asks the broker one tiny
> question first — a **1 KB request** (`Range: bytes=0-1023`) whose only job is to
> read the file's `Last-Modified` date (~0.4 s). If the broker's copy is the same
> one already stored, the 34 MB download is **skipped** and the status line says
> so ("Broker ka master file wahi hai (06/10 08:00) — 34 MB dobara download nahi
> kiya"); the stored copy's date is visible in *Settings → Scrip master → Broker
> file*. Any **forced** refresh (the *Master update karo* button, or the F&O
> coverage repair) still downloads, and if the date cannot be read the app
> downloads as before — it never guesses. (Since 1.5.2 the scan already covers
> the whole F&O universe: it re-checks its own coverage and repairs a thin master
> by itself.)

> **1.5.2 — "sirf 45 stocks hi scan ho rahe he" fix.** The study's universe is
> resolved from the **local scrip master**, and a fresh install still carries the
> thin bundled seed (122 instruments), so a 213-name F&O list resolved to ~45
> stocks and the rest vanished without a word. The scan now **checks its own
> coverage first**: if fewer than 80 % of the F&O list resolves, or the local
> option book is empty, the app downloads the daily master from Angel One,
> rebuilds the resolver and resolves again — progress and result are shown right
> under the scan bar ("Scrip master update ho gaya — poore 213 F&O stocks mil gaye,
> option book me 12,480 contracts hain"), and a **Master update karo** button lets
> you trigger it by hand. Candle fetches also retry once before a stock is
> skipped, so a transient rate-limit can no longer shrink the table.

> **1.5.1 — poora F&O universe, bina kisi cap ke.** The study used to stop at a
> configurable 60 stocks; the "stocks per scan" setting is **gone** and every scan
> now covers the **entire F&O list — all 213 names** (whatever resolves). The
> button says so ("Dobara scan — poore 213 stocks"), the progress line carries an
> ETA extrapolated from the run's own speed (a warm, cache-served scan is ~5×
> faster than a cold one, so a fixed estimate would lie), and any ticker that
> cannot be resolved is named in the banner ("210 of 213 · 3 resolve nahi hue:
> …") instead of quietly shrinking the table.

> **1.5.0 — the F&O module, tool #1: the 3-Month Study.** The equity tabs stay
> exactly as they were; F&O opens from the app bar (its own hub) because
> derivatives are a different instrument class with their own maths. The study
> takes the **last 63 trading days** of every F&O stock and answers, in one
> sortable table: how strong is the 3-month trend, where is the price relative to
> the 3M high/low (in percent **and** in ATR-days), how much did each month move,
> and — the part that actually decides a trade — **is the ATM option cheap or
> expensive right now**. For every stock it picks the ATM strike from a local
> option book built out of Angel One's own scrip master, prices the CE/PE
> (batched full quotes, so the whole universe needs ~5 requests), reads the broker's IV, and
> falls back to **Black-Scholes (bisection)** when the chain has no IV. Output:
> a 0–12 score, an **IV rank** across the whole universe, a 🎯 **Best Buy** tag,
> the one-line reason, and *"agar kal jodi buy ki hoti"* — what an ATM CE+PE
> straddle bought yesterday would have made today (**always Profit/Loss words,
> never a raw minus sign**). Stocks whose option data fails are **not dropped** —
> they stay in the table in **degraded mode** with the reason on record. Export
> to **Excel (3 sheets) / CSV / WhatsApp / Telegram**, or push either leg
> straight into the paper-trading order sheet.

> **1.4.0 — the RSI Scanner tab.** A fifth tab scans **daily candles** and answers
> the brief's question: *which stocks have RSI above 67 today, and which below 33* —
> as a table of **stock name · price · RSI**. Universes: **F&O stocks** (213 names,
> default), Nifty 50, the IPO database, all NSE equities, NSE+BSE. One pass fills
> both tables (overbought and oversold), rows that only crossed *today* are badged
> **NAYA**, and the levels/period are editable (default 14 · 67 / 33) — editing them
> re-labels the cached table instantly, with no extra API call. Wilder's smoothing,
> verified against the classic published dataset in the tests. The candle cache is
> **shared with the Golden Cross tab**, so whichever scans first makes the other
> nearly free.

> **1.3.5 — identity, not names (ISIN).** A ticker is only a label: the exchange
> renames companies and their symbols whenever it likes (LTIM → LTM in Feb 2026,
> AMIORG → ACUTAAS in Jun 2025, ZOMATO → ETERNAL in 2025). Symbols are therefore
> a bad thing to key a database on. Every row now stores its **ISIN** — the
> security's identity, which never changes on a rename — and the app reconciles
> against it on every discovery run: if the exchange master now maps a row's ISIN
> to a different ticker *and* the stored ticker no longer trades, the row is
> updated automatically (symbol + company name; listing date, levels and notes
> kept), and the screener banner names the repair. Rows shipped by older versions
> get their ISIN filled in from the master, so they are covered from the next run
> onwards. Old-style static rename handling stays as an offline fallback.

> **1.3.4 — "counter 555/559 pe atka hua hai" fix.** The scan counter stops short
> of the total when a row can never be priced: a company that renamed itself after
> the master was cut (LTIM → LTM in Feb 2026, AMIORG → ACUTAAS in Jun 2025) keeps
> an old ticker the broker no longer lists. Two things are different now:
> * renamed tickers in the bundled master are **repaired on update**, and existing
>   installs get the same repair applied to the rows they already have;
> * a row that still cannot be screened is no longer invisible — the scan bar shows
>   **"N rows need attention · M symbol exchange pe nahi"** and tapping it opens a
>   list with each row's reason plus *edit symbol* / *delete row* actions. Levels
>   that can never be fetched are marked `missing` instead of being retried
>   forever, so the "levels pending" counter can actually reach zero.

> **1.3.3 — the database keeps itself complete.** Two changes, both about the
> question *"aage jo naye IPO aayenge, unka data kahan se aayega?"*
>
> 1. **Every row now ships with its listing-day high/low.** The master is
>    pre-filled from NSE's own daily bhavcopy of each listing date (558 of 559
>    rows; the one BSE-first listing fills itself from the broker at runtime).
>    So the screener has real levels the moment the app opens, and the phone
>    never has to make ~500 candle calls to catch up.
> 2. **New listings are found automatically.** On every launch the app diffs the
>    broker's daily scrip master against the last snapshot — a symbol whose price
>    history *starts today* is a new listing, and one candle call gives its
>    listing date plus high/low. NSE's official equity master is the date
>    cross-check for listings the broker snapshot has not picked up yet. Whatever
>    is found is added to the database itself (and shown once in a banner, since
>    a rename or a demerger can look like a new listing — one tap deletes it).

> **1.3.2 — the whole post-2015 IPO universe.** The screener used to work off 39
> hand-picked IPOs. It now ships a **master of every mainboard IPO listed since
> 1 Jan 2015** (559 rows, 2015→2026) and fills in each row's **listing-day high
> and low itself** from the broker's daily candles — in resumable background
> batches, cached in SQLite forever, with live progress on the scan bar. Rows
> whose symbol is gone (delisted/renamed) are reported instead of being retried.
> The ±3 % band, filters and TradingView links are unchanged.

> **1.3.1 — IPO screener hotfix.** The screener could look completely empty with
> no explanation: without a session (or when the broker returned no prices) every
> row was dropped silently, the counters read "0 of 0 IPOs" and nothing said why.
> Now: an explicit **Scan now** button with progress and a last-scan timestamp, a
> banner that names the reason (no session / expired token / no prices / tokens
> missing / levels still being fetched) with the matching action, honest counters
> in every state, a market-closed note, and an **All screened** view plus a
> "closest right now" list so the screen always shows real numbers.

| | |
|---|---|
| **Stack** | Flutter 3.35+ (Dart 3.5+), sqflite, http, web_socket_channel, provider, fl_chart |
| **Market data** | Angel One SmartAPI — REST (`/market/v1/quote`, `/historical/v1/getCandleData`) + WebSocket 2.0 feed |
| **Storage** | SQLite (IPO database, instrument cache, price cache, scan cache, trade book) |
| **Secrets** | flutter_secure_storage (Keystore / Keychain) — never in SQLite |
| **Design** | brand mark drawn in code + launcher icons from one geometry, Material 3 tokens, motion kit — see [`design/BRAND.md`](design/BRAND.md) |
| **Tests** | 1,416 tests (unit + widget), all green — see [Testing](#testing) |

Previews: [`preview/design_preview.html`](preview/design_preview.html) — the new
brand, splash, dashboard and Reports screens — and
[`preview/ipo_screener_preview.html`](preview/ipo_screener_preview.html) for the
screener (including the new scan bar, reason banner and "closest right now"
list).

---

## Table of contents

1. [Quick start](#quick-start)
2. [Installing / building the release APK](#installing--building-the-release-apk)
3. [Angel One API setup](#angel-one-api-setup)
4. [Feature 1 — IPO proximity screener](#feature-1--ipo-proximity-screener)
5. [Feature 2 — Golden Cross / Death Cross screener](#feature-2--golden-cross--death-cross-screener)
6. [Feature 3 — Paper trading & Reports](#feature-3--paper-trading--reports)
7. [Design & branding](#design--branding)
8. [Architecture](#architecture)
9. [Data files (and how trustworthy they are)](#data-files-and-how-trustworthy-they-are)
10. [SmartAPI reference used by this app](#smartapi-reference-used-by-this-app)
11. [Testing](#testing)
12. [Troubleshooting](#troubleshooting)
13. [Roadmap](#roadmap)
14. [Disclaimer](#disclaimer)

---

## Quick start

```bash
# 1. Prerequisites: Flutter 3.38.1+ (Dart 3.10+), Android SDK / Xcode
#    (built and tested with Flutter 3.47.6 / Dart 3.13.5, JDK 17, SDK 36)
flutter --version

# 2. Install dependencies
cd angel_trader
flutter pub get

# 3. Generate the launcher icons (optional — PNGs are already committed)
python3 tool/generate_icon.py          # only needed if you change the branding
dart run flutter_launcher_icons

# 4. Run on a device or emulator
flutter run
```

First launch works **offline**: the app seeds its IPO database from
`assets/data/ipos.csv` and its symbol ➜ token map from
`assets/data/scrip_master.json`. Live prices need an Angel One login
([next section](#angel-one-api-setup)), and the full ~50 MB instrument master is
then downloaded automatically in the background.

**Platform notes**

* Android `minSdk` must be **23+** (flutter_secure_storage). `flutter build`
  picks this up from the plugins; if your manifest pins an older value, raise it
  in `android/app/build.gradle`.
* Add these to `android/app/src/main/AndroidManifest.xml` so the *Chart* button
  can hand off to a browser / the TradingView app on Android 11+:

  ```xml
  <queries>
    <intent>
      <action android:name="android.intent.action.VIEW" />
      <data android:scheme="https" />
    </intent>
  </queries>
  ```

* iOS: add `https` to nothing — `url_launcher` works out of the box; run
  `cd ios && pod install` as usual.

---

## Where the data comes from (and how it stays current)

| Piece | Source | When it is fetched |
|---|---|---|
| IPO universe (559 mainboard listings, 2015→2026) | Bundled master, cut from `ipocentral.in` year pages joined to NSE's official `EQUITY_L.csv`; `tool/build_ipo_master.py` regenerates it | On install, and on app update (merged in — rows you added or edited are never overwritten) |
| Listing-day high/low | `tool/prefill_listing_levels.py` reads the **NSE daily bhavcopy** of each row's listing date (558 of 559 rows). The rest — BSE-first listings — come from the broker's daily candle at runtime | Shipped inside the app; no network needed |
| F&O universe | `assets/data/fno_symbols.csv` — every `FUTSTK` row of the broker's scrip master (a *stock* future = an F&O company), index futures and `NSETEST` contracts filtered out. 213 names, refreshed at build time | Shipped; resolved through the ISIN-aware resolver |
| Row identity | **ISIN** per row (from NSE's `EQUITY_L.csv` at build time; filled from the same file at runtime for rows that lack one). The symbol is just a label — the ISIN is what survives a company rename | Shipped + refreshed with each discovery run |
| New listings after the master's cut-off | **Broker first**: today's scrip master minus the last snapshot, confirmed with one `getCandleData` call (its *oldest* bar is the listing session, so date + high/low come together). **NSE `EQUITY_L.csv`** supplies official dates when the broker master lags | Automatically at every launch (capped, rate-limited, snapshotted); manual re-check from the ⟳ icon beside *Scan now* |
| Live prices | Angel One `getQuote` (batches of 50, once per refresh) | Every scan — **all** resolvable rows, not just the ones in the band |
| Instrument tokens | Daily scrip master (`OpenAPIScripMaster.json`) | Once every 24 h |

Nothing about this needs a third-party site in steady state: the broker supplies
prices, tokens and candle history; NSE's public masters are the free,
unauthenticated cross-check for dates.

---

## Installing / building the release APK

A ready-to-install release build ships next to this project:

| | |
|---|---|
| **APK** | `NiveshDesk-1.5.77.apk` — **25.8 MiB** (26992670 bytes) · one file, 64-bit (arm64-v8a) phones from ~2017 onwards |
| What's in it | Everything in 1.5.54, plus the **top-3 bundle**: News × Jodi cross-signals (🔥 badge in AI Jodi table + jodi verdict badge in News deep-research), AI Jodi table **sort + verdict filter + Kal→aaj column**, and News **daily digest** + **"Mere stocks (basket)" filter** |
| App name | **NiveshDesk** (launcher label + in-app brand) |
| Package / version | `com.angeltrader.angel_trader`, versionName `1.5.94`, versionCode `2107` |
| Targets | `compileSdk`/`targetSdk` 36, `minSdk` 24 |
| Signed with | **Android debug key** (CN=Android Debug, RSA-2048, APK Signature v2) |
| SHA-256 | `954117888141a71213f0b7bab521e8b9cfbbf1c1437374853a809b2adecbcf34` |

| Known gaps | A handful of 2015→2026 names could not be traced in the NSE master (delisted/renamed — e.g. NSDL, Sah Polymers, TCNS Clothing, ICICI Securities, Barbeque Nation). Add them by hand from *IPO database → +*; every new listing after the master's cut-off is picked up automatically (1.3.3). |

**Why ~23.1 MB, and why only one file?** A Flutter release APK is ~96 % engine
binaries (`libflutter.so` + `libapp.so`) and they are stored *uncompressed*
(Android 15+ requires 16 KB-aligned native libs), so every CPU architecture you
bundle adds its full copy — a universal APK carrying arm64 **and** armv7 was
37.7 MB, half of it useless to any given phone.

**Release policy: one APK per release — `arm64-v8a` only.** Every phone from
roughly 2017 onwards is 64-bit, so a single-file build serves them all at ~23 MB
and there is never any "which file do I install?" doubt. `--target-platform
android-arm64` alone is *not* enough: it filters the Flutter engine, but plugins
still ship prebuilt libraries for every ABI (a stray 32-bit `libdartjni.so` would
let the APK install on a 32-bit phone and crash on start), so the app module also
sets `ndk { abiFilters += listOf("arm64-v8a") }`. Build it with:

```bash
flutter build apk --release --target-platform android-arm64
```

32-bit-only phones (pre-2017) are not targeted. If one ever needs support, run
`flutter build apk --release --target-platform android-arm` — and if the app is
published on Play, upload an **App Bundle** instead (`flutter build appbundle
--release`); Google then serves each phone its own slice automatically.

> The Android application id (`com.angeltrader.angel_trader`) is deliberately left
> unchanged so new builds install **over** your existing app and keep its
> database; only the display name and the icon changed. Rename the id too if you ever want
> a clean break — it would then install as a separate app.

Every build so far uses the same debug key, so 1.5.39 installs **over**
1.5.36 and older builds (same app, database and settings) — uninstall first if
you want a clean slate. Database schema is **v14** (adds the disclosed
`earnings_basis` column to the Magic Formula cache). On first open, this
release clears the older Magic Formula cache version so the next explicit
scan re-reads every filing with the hardened parser; holdings and other app
data remain untouched.

**SEBI half-yearly balance sheet:** per Reg 33(3)(f), the Statement of Assets
and Liabilities is filed with **half-year results only (Q2 = 30 Sep, Q4 = 31
Mar)**. A Q1/Q3 quarter filing carries P&L + share capital but no balance
sheet — that is why a scan run between Q1 and Q2 results season showed 45/50
rows missing Total Debt, Cash & Equivalents, Total Assets and Current
Liabilities while Market Cap and TTM EBIT worked. The scan now uses the newest
official half-year balance sheet already in the four selected filings and
shows its real date in the *Balance-sheet date* row; a filing whose
balance-sheet facts sit on an older instant than its own period end is still
refused (no date mixing, no guessing).

**Banking / insurance / NBFC filing formats (1.5.36):** SEBI's integrated
filing is not one format — listed banks, NBFCs and insurers file under their
own taxonomies (NSE's XBRL Information page: IndAS, other-than-bank, Banking,
NBFC, General Insurance, Life Insurance), with different element names and
different balance-sheet shapes. The scan now maps them, verified against the
official SEBI taxonomy packages (BSE XBRL downloads) and BSE-hosted sample
instances:

| Formula input | IndAS (already worked) | Banking | NBFC | Life/General Insurance |
|---|---|---|---|---|
| Total Assets | `Assets` / `EquityAndLiabilities` | `CapitalAndLiabilities` | `Assets` | `Assets` |
| Current Liabilities | `CurrentLiabilities` family | Deposits + Other Liabilities & Provisions (the face has no current/non-current split) | total liabilities − interest-bearing debt | `CurrentLiabilities` family |
| Total Debt | current + non-current borrowings components | the face's `Borrowings` line | Debt Securities + Borrowings + Subordinated Liabilities | the face's `Borrowings` line |
| Cash | `CashAndCashEquivalents` family | `CashAndBalancesWithReserveBankOfIndia` / CF-statement cash | `CashAndCashEquivalents` | `CashAndBankBalances` |
| Earnings | `ProfitBeforeExceptionalItemsAndTax` | **PBT proxy** | `ProfitBeforeExceptionalItemsAndTax` | **PBT proxy** |
| Market Cap shares | paid-up capital ÷ face value | same | same | paid-up ÷ face value; face value is not tagged in the insurance taxonomy, so shares = PAT ÷ EPS of the same quarter (both official facts) |

**Approved PBT proxy:** banking and insurance taxonomies tag no EBIT element.
When a whole four-quarter set carries Profit Before Tax instead, TTM PBT serves
as the earnings input and the basis is labelled *Earnings input: PBT proxy (EBIT
not tagged)* in the row detail and in the skip note. EBIT and PBT quarters are
never mixed. Formulas themselves are unchanged — ROCE = EBIT ÷ (Total Assets −
Current Liabilities), EY = EBIT ÷ EV, EV = Market Cap + Total Debt − Cash — and
no value is ever guessed: unmapped or absent fields still drop the row with the
missing field names in the skip note.

**Inline-XBRL hardening (1.5.37):** SEBI filings arrive as either a plain XBRL
instance or an inline-XBRL document (rendered HTML where the facts carry
`scale="7"` and `sign="-"` refinements over crore/lakh display text). The
parser previously read only the plain shape and only the root's direct
children, so an inline-served filing could yield display-unit numbers (tiny,
wrong by 10⁵–10⁷) or miss its balance sheet entirely. Facts are now collected
wherever they sit in the document, `scale`/`sign` are applied, and negatives
like `(13.47)` are understood — both shapes of a real BSE-hosted Bajaj Finserv
NBFC-format instance (plain XML and inline iXBRL) now parse to identical,
correct rupee values. This is the fix for BAJAJFINSV-style rows that showed
missing balance fields and an implausible ₹0.58 Cr TTM EBIT.

**Insurance-format coverage (1.5.38):** the 1.5.37 phone scan ranked 20 of 22
rows; the two skips were HDFCLIFE (missing Market Cap only) and SBILIFE
(missing Market Cap, Total Debt, Cash and Current Liabilities) — two filing
faces the earlier mappings did not fully read. Element names were taken from
the official SEBI taxonomy packages on BSE (Life/General-Insurance and IndAS
integrated taxonomies), never guessed: market cap now prefers a tagged share
count (`NumberOfShares`, the old Life/General-Insurance face line), then
paid-up ÷ per-share face value — refusing a face value that reads as a capital
total — then profit after tax ÷ EPS on one and the same period, including when
the pair is tagged only on the year-to-date context. Total debt understands the
Reg 30 "total financial indebtedness" element and a borrowings pair where only
one side exists **only** when the counterpart concept is absent from the whole
document. Current liabilities fall back to the Schedule identity
`CurrentAssets − NetCurrentAssets` (both face totals, only the difference is
derived). Anything still untagged is reported honestly by field name — no
value is ever invented.

**Baskets + official BSE data (1.5.39):** the Magic Formula screen now keeps
**named baskets** — any number of personal lists (create / rename / delete,
saved in the app's own SQLite), each holding any stocks the user chooses from
**NSE or BSE**. Adding a stock is type-ahead: as you type a symbol or company
name, suggestions come from the official NSE listing master and the broker's
local cash master (ticker + company name + exchange, dual-listed names
collapse to one row); tapping adds it to the open basket. *Scan basket* runs
those members through the exact same official pipeline, cache and ranking as
the universe scan — same ROCE/EY formulas, same honest skip notes.

Behind that, BSE-only listings stopped being an automatic skip. Prices come
from BSE's official **CM-UDiFF** EOD bhavcopy
(`BhavCopy_BSE_CM_0_0_0_<yyyymmdd>_F_0000.CSV` — same `TradDt/ISIN/TckrSymb/
FinInstrmId/ClsPric` columns as NSE's, parsed by the same offline-tested
reader; BSE's group series `A/B/T` are accepted alongside NSE's `EQ/BE`).
Filings come from BSE's public **Integrated Filing** feed
(`api.bseindia.com/BseIndiaAPI/api/Integratedfinancedata/w?scripcode=…`),
whose rows carry the XBRL instance path plus the basis and period in
`Quarter_Name` (`Consolidated-Sep-Qtr-2026`, `Standalone-Mar-Yearly-2026`, …);
the same 4-consecutive-quarters TTM, statement extraction, format mappings
and PBT proxy then apply unchanged, and only official exchange archive hosts
are ever fetched. The latest market-cap chain also gains an official
**listing-master face value** step: insurance IFLI filings tag paid-up capital
but no face value, so the face value column of the exchange's own listing
master (already used for listing dates) completes shares = paid-up ÷ face
value when the filing itself has none — never a guessed number. Both feeds
use plain browser headers (BSE's behind a client-hint fingerprint rule); no
cookies, sessions or credentials, and a scan stops honestly if an official
EOD report is unavailable. What remains missing stays missing by field name —
a thin filing (SBILIFE's Q2 face, for example, tags assets and PAT but no
current-liabilities/cash/debt lines) still drops those fields honestly rather
than inventing them.

**Face-value fall-through (1.5.40):** real filings taught the last lesson —
Bharti Airtel's Integrated Filing tags `FaceValueOfEquityShareCapital` as the
*period's issued face capital* (a total in rupees), not a per-share value, and
tags no PAT/EPS. The old chain refused the capital total (correct) but then
had nowhere left to look, so Market Cap stayed missing even though the
official NSE listing master knows the ₹5 face value. Now **every market-cap
source gets its own guarded try and falls through to the next official one**:
tagged share count → paid-up ÷ filing face value (per-share values only, ₹1–
₹1,000) → paid-up ÷ **listing-master face value** → PAT ÷ EPS on the same
period. An implausible reading at any step (capital totals, absurd share
counts) is refused and the chain moves on — a wrong ratio is never accepted.
The master's face-value parse also refuses a comma-shifted name row rather
than reading the wrong column. Phone scan after the fix: HDFCLIFE and
BHARTIARTL gain honest market caps from the master face value; SBILIFE still
honestly skips what its filing genuinely does not tag (current liabilities,
total debt, cash). *(1.5.42 correction: SBILIFE's missing lines were never
"genuinely untagged" — they live in the half-year face, see below.)*

**Half-year balance sheet for thin quarter faces (1.5.42):** the SBILIFE
report was not an honest skip — it was a gap in the half-year balance-sheet
policy. SBILIFE files one document per period (IFLI faces) with several
period columns: the **Jun-2026 quarter face** tags Assets and paid-up capital
but no liabilities/cash/borrowings lines (SEBI does not require the Statement
of Assets and Liabilities with Q1), while the **Mar-2026 document — shared
between the `Mar-Qtr` and `Mar-Yearly` rows — tags the complete statement**
(`CurrentLiabilities`, `Borrowings` 0, `CashAndBankBalances`, `Assets`).
The scan previously fell back to the half-year statement only when the newest
face had *no* balance facts at all; a thin face with stray lines blocked the
fallback. Now, when the newest face is a **June/December quarter** that cannot
supply every balance input, the balance comes **whole** from the newest
already-selected half-year statement, with that statement's own date shown
(SBILIFE shows a 31-Mar-2026 balance sheet) — fields are never mixed across
statements. A **Sep/Mar face** (where the statement *is* due) with missing
lines, or whose balance facts sit on an older instant than its period end,
stays suspect and is never back-filled — those protections are unchanged and
pinned by their own tests. Phone result: SBILIFE now ranks with its real
balance sheet; its zero borrowings read as zero debt (EV = Market Cap − Cash).

**Yahoo Finance fallback (1.5.41):** on the user's explicit decision
(24 Oct 2026), the app's sourcing rule is amended — **official exchange data
stays primary** (UDiFF EOD close + trade date display, Integrated Filing XBRL
fundamentals, listing-master face value), and **Yahoo Finance is the labeled
fallback** whenever the official chain cannot form an input. Two uses only:
(1) Market Cap, when no official share count / face value / PAT÷EPS exists;
(2) an EOD close for a **basket member** absent from the official file. Every
row that leans on it carries the marker `Market Cap: Yahoo Finance
(unofficial)` or `Price: Yahoo Finance (unofficial)` in its source line — the
official chain is always the headline, and nothing is ever silently mixed.
EBIT, debt, cash, assets and current liabilities remain **official-only**;
Yahoo's market cap is read in INR (`*.NS` / `*.BO` tickers, Yahoo's own
cookie+crumb JSON handshake) and refused otherwise. If Yahoo itself is
unreachable, the row stays honestly missing — the fallback never invents.

**Suggestion search fix (1.5.41):** the basket type-ahead no longer waits on
the NSE listing master's full download window (up to 60s on a blocked
network). It gets a small budget, then serves the broker master immediately;
a degraded list is re-tried every 30 seconds so NSE rows join as soon as a
fetch succeeds. Regression tests pin that all four reported names —
BHARTIARTL, HDFCLIFE, SBILIFE, SIEMENS — resolve through the real master
path, and that a hanging listing download cannot hold the dropdown hostage.

**Exact TTM from official period columns (1.5.43):** the SIEMENS and VAML
reports were the last structural gap — both are *engine* cases, not data
gaps. Siemens has a **September fiscal year** and BSE's integrated feed
carries no Dec-quarter rows, so its quarter rows jump Mar-2026 → Sep-2025;
Vedanta Aluminium Metal (VAML) is a **May-2026 demerger listing** with only
two quarter rows. Neither can produce four discrete quarters — yet both
documents tag the missing months' earnings inside official longer columns.
The TTM assembler (user-approved 25 Oct 2026) now covers the trailing twelve
months **exactly** from official period columns of one basis: discrete
quarter columns, the SEBI Hly / NineMths / Yearly faces, and comparative
quarter columns. Shapes: four quarters (classic), a longer column +
quarters (SIEMENS: TTM = NineMths + Q4), and a spilling Yearly cancelled by
the comparative quarter (VAML: TTM = Yearly − prior-year quarter + current
quarter). Everything is a **sum or an exact difference of tagged figures —
never an estimate**; every such cover is labelled in the row (`earningsBasis`,
e.g. `TTM = Yearly − 1 prior-year quarter + 1 quarters`). A window no
official columns can cover stays honestly missing — nothing is invented.
Mixing EBIT and PBT columns is never allowed (one basis per cover), and a
non-contiguous feed never produces a wrong window by itself: nothing is
summed unless the cover is exact.

**Suggestion search, second-line defence (1.5.43):** once a suggestion list
exists, an expired or degraded cache answers the typing dropdown instantly
while a refresh runs in the background. New listings are pinned in the
search tests too — VAML resolves by ticker and by company words alongside
BHARTIARTL, HDFCLIFE, SBILIFE and SIEMENS.

**Basket identity fix (1.5.44):** a name added to a basket from the suggestion
list arrives as a plain ticker with its six-digit BSE code on the side — and
the scrip-code resolver only ever read the symbol, so every basket-added BSE
row (SIEMENS, ABBOTINDIA, HBLENGINE, VAML, MCX, …) skipped with "BSE scrip
code official reports me nahi mili". The code now travels in the data symbol
and the resolver reads it; rows with a listing-master ISIN also resolve
through the bhavcopy exactly like the search path. Separately, a dual-listed
company's broker-master BSE row carried no ISIN and slipped past the dedupe,
so the dropdown listed the same name twice — one row of which used to break
the scan. The listing master's ISIN now enriches the broker rows and the
duplicate collapses into the single NSE row. What stays honest: DUMMYHEG is a
stale broker-master row for a company with no official filings and will still
report missing data; REIT/InvIT names and brand-new listings follow the same
rule — if a row still skips, its tap-details say exactly which inputs are
missing.

**Failure-cache fix (1.5.45):** a row that failed to build used to sit in the
local cache as "fresh" for an hour — and every retry re-pinned it — so a
fixed pipeline kept showing the same old errors ("same error abhi bhi").
Failed rows are now never served stale: every rescan retries them. On top of
that, BSE's series **IF** (listed REIT/InvIT units — BIRET, EMBASSY,
BAGMANE) is accepted into the official close file like any cash-market row,
and broker-suffixed symbols (`SIEMENS.BSE`, `SIEMENS-EQ`) match the official
ticker, so a stored basket row keeps its identity whatever suffix its source
carried.

**NIFTY 500 scan — the missing members (1.5.46):** the same 16 names kept
skipping the NIFTY 500 scan. Three real causes, each measured against the
exchanges' own 23-Oct-2026 files: (1) listed REITs trade under NSE series
**RR** (InvITs IV; SME equity SM/BZ/ST) and the close-file parser only
accepted EQ/BE plus BSE's group letters — the parser now takes the real
cash-equity vocabulary (debt/ETF series like N1/GS stay out); (2) the scan's
NSE-row members asked only NSE's Integrated Filing feed, which publishes
nothing for new listings, demerged entities and REITs — when it is empty the
**official BSE feed** (same company, six-digit scrip code from the bhavcopy)
is now tried before the row is declared missing, and the row's source says
`NSE CM-UDiFF EOD Close + BSE Integrated Filing XBRL`; (3) DUMMYHEG is a
literal row in NSE's own NIFTY 500 list ("Dummy HEG Ltd.") that trades
nowhere — it stays honestly missing, as does any name neither official feed
covers. The skip message itself ("TTM EBIT ke liye … 4 consecutive quarter
filings nahi mili") is unchanged and still the honest verdict when both
official feeds have nothing usable.

**AI Jodi Study — 3-Month Study ka naya link (1.5.47):** the study's 3-dots
menu now opens the "AI Calculation & Chart Study" page. It reuses the same
scan (one scan, two views) and applies the user's own rules, decided 25 Oct
2026: (1) **15-din gate** — roz ka average daily |close−close| move ATR(14)
se zyada; (2) **month gate** — high−low range price ka 20%+ kam se kam 2 of
3 months me ("mostly"); (3) **jodi gate** — typical monthly ₹ move jodi ke
daam se zyada. The verdict column is the strategy answer: movement jo pair
ko **2× cover** kare tabhi buy (dono legs BUY — long straddle/strangle,
direction-neutral, risk sirf premium tak, monthly expiry); bharpoor movement
par **ATM jodi**, warna sasti **OTM jodi** (aapka half-of-ATM-cost strangle
rule). Table is deliberately simple — Stock | Price | ATR | ATM jodi | OTM
jodi | Konsi buy — with "Stock add karein" for the user's own picks (manual
rows bypass the gates but keep the same maths and verdict). The engine is
pure and pinned by tests.

**AI Jodi Study — the four follow-ons (1.5.48):** (1) **tap any row** →
detail sheet with a **mini candle chart** (offline bar cache — the scan
already downloaded the candles) carrying the recommended pair's **break-even
lines** (straddle: strike ± premium; strangle: PE strike − / CE strike +
premium) and the current-price line; (2) every row shows **"Kal jodi buy ki
hoti" P&L** for both pairs (previous-close buy cost → now, ₹ and sign);
(3) the verdict column carries the **IV-rank star** — ⭐ when IV is cheap
(the deal is real), ⚠️ when IV is dear (premium sasta lagta ho to bhi soch
lo); (4) the page's export menu sends the list out as **WhatsApp/text recap,
Excel (XLSX) or CSV** through the same share sheet as the rest of the F&O
tools. Break-even, P&L and star rules are pure and pinned by tests.

**AI Jodi Study — auto-study + top-20 (1.5.49):** opening the link now
**starts the study itself** — every F&O stock is scanned (progress bar on
the page) and the output is the **top-20 best**: all-gate passers ranked by
movement-per-rupee of jodi first, then the next-best priced names to fill
twenty (each keeping its honest verdict). The list reads `allRows`, so the
study page's search box can no longer shrink it. The "Stock add" dialog had
a real bug — it excluded every scanned row, so the textbox searched an
always-empty list; it now offers exactly the stocks **not** already visible
and the search filters them as you type.

**AI Jodi Study — table redesign (1.5.50):** the six columns now have fixed
widths and the whole table **scrolls horizontally as one piece** (header
stays put, columns keep their shape — no squeezed flex fractions), money
renders in Indian ₹ grouping with tabular figures, and rows carry a light
zebra tint for scanning down the list. Vertical scroll and the tap-through
detail are unchanged.

**AI Jodi Study — Rescan (1.5.51):** the table header now carries a
**Rescan** button — one press re-runs the full F&O scan (fresh closes and
study rows) and the top-20 AI Jodi list refreshes when it finishes. The
button disables itself while a scan is already running; the progress strip
stays visible and the current table keeps showing until new results land.

**News module (1.5.52) — F&O → kebab → "News (naya)":** a hybrid feed
(Option C) that gathers **NSE official RSS** (announcements, corporate
actions, circulars, SAST), the **official F&O ban list**, **Google News**
headlines, and the user's **trusted public Telegram channels** (watch-list —
`Stock_aaj_or_kal` preset, add/remove in the app; only public channels work).
Every news card lists the **affected stocks + sector + effect direction**
(🟢/🔴/⚪/❔, keyword rules) right under the news, and a **"Deep research"**
link opens the advanced panel inline: the most-affected stock, a rule-based
**AI suggestion** per stock, an **entry/exit plan** from official last-session
high/low + ATR (1.5× volatility target), and — for high-impact F&O names — a
**jodi-long idea** (ATM straddle / OTM strangle with break-evens). Non-F&O
stocks get levels from the same official bhavcopy where available; missing
data is labeled honestly ("direction only"), never guessed. Telegram
watch-list persists between sessions.

**News scan crash fix (1.5.53):** the first News build matched every news
item against the full listing master by compiling a fresh regex per
news×stock pair (~400k compiles per scan) — on a phone that froze the UI
until Android killed the app. Matching now runs through a one-time
precomputed index (`NewsMatcher`: token→symbol map, normalised names by
first word, cached regexes only for odd symbols like `M&M`), a bad item is
skipped instead of aborting the feed, and a regression test pins a
3,000-stock × 60-news match to well under two seconds.

**AI Jodi table header scroll fix (1.5.54):** in the 1.5.50 redesign the
table header accidentally kept its own separate horizontal scroller (plus a
12px offset), so scrolling the table moved the rows but not the header and
the columns drifted apart. Header and rows now share one horizontal
scroller as a single block — columns stay aligned at every scroll offset —
while vertical scrolling keeps the header sticky above the rows.

**52W · ATH · Dividend (1.5.90) — F&O Hub ka naya tool 📈:** F&O stocks
(scanner universe, ~180) me se **sirf wahi stocks jo 52-week high ya low ke
5% ke andar** hain (filter 3% / 5% / 10%) — aur "kitna door hai" percentage
me. **Teen alag tables:**
1. **📈 52-Week High/Low** — LTP, 52W high/low, dono se distance %, ▲ HIGH /
   ▼ LOW tag (sorted: sabse nazdeek pehle).
2. **🏔️ All-Time High/Low** — ATH/ATL **date ke saath**, official Angel
   history se (saal-dar-saal chunk, `athYears = 15`, cache me save — dobara
   instant). Sirf proximity wale stocks ke liye (max 30) — 180 stocks ka full
   history practical nahi hota.
3. **💰 Dividend** — sirf **naye / aane wale** declarations (user: past
   history nahi) — NSE official **event-calendar** (ex-date + amount) aur
   **corporate-announcements** (declaration date) se; ₹ per share + **price ka
   %** + ex-date + declared date.
Scan progressive hai (rows aate jate dikhte hain, progress bar + cancel on
dispose). Engine: `lib/features/fno/extremes/` (extremes_engine pure maths +
NSE parsers, extremes_service fetch/cache, extremes_screen 3 tabs).

**Dividend table — saare F&O stocks (1.5.91):** dividend tab ab 52W proximity
filter se **independent** hai — F&O universe ke **saare** upcoming/new
declarations dikhte hain (ex-date se sorted). Ek chip ("52W ke andar wale")
se purana behaviour wapas. Jis stock ka 52W scan nahi hua uske liye "price ka
%" **—** rehta hai (close unknown — guess nahi).

**52W / ATH / Dividend — scope + dividend clean-up (1.5.94):**
- **52W tab:** default sirf wo stocks jo high **ya** low ke chune hue % (5%)
  ke andar hain. Naya chip **"Sabhi stocks"** — poora scanned universe (tarteeb
  wahi, sabse nazdeek pehle). Naya helper `Extremes.byProximity52`.
- **All-Time tab:** wahi niyam ATH par — default sirf wo stocks jo apne
  **all-time high ya low** ke 5% me hain (`Extremes.nearAth`,
  `StockExtreme.nearAnyAth`), "Sabhi stocks" par jitne ATH load hue sab.
- **Dividend tab:** sirf **aane wale** dividends — beet chuka dividend/naam
  table me aata hi nahi (`Extremes.upcomingDividends`: ex-date aaj ya aage;
  ex-date TBA ho to naya elaan 7 din ke andar). Percentage/proximity filter
  hata diya; columns ab seedhe: **stock · ₹/share · price · price ka % ·
  ex-date**.
- **Laptop scroll fix:** teeno tab ab `PageScroll` — status bar + chips +
  table **ek hi scroll** me (3-Month Study jaisa), koi double scroll nahi.

**F&O hub ka naya design (1.5.93):** hub ab **category rows** hai — chaar
section: **Screener & Study · Index Strategies · Options Data · Calendar & AI**.
Har row me icon + naam + **ek hi line** (badge LIVE/NEW/NAYA), bullets hata diye
— isliye saat tools bina scroll ek saath dikhte hain. **Order user ka apna:**
row ko **dabaye rakho (long-press) aur upar-neeche kheencho** — order turant
save (`fno_hub_order` key, JSON) aur app band karne par bhi wahi rehta hai;
AppBar ke ↺ se default order wapas. Section ka order fix hai, andar ka nahi.
Naya tool add karne par wo apne section ke aakhir me judta hai — purana order
kharab nahi hota (`mergeHubOrder`). Files: `fno_hub_config.dart` (tools +
order maths) aur `fno_hub_screen.dart` (rows + drag); tests
`test/features/fno/fno_hub_test.dart`.

**PC scroll fix — ek page = ek scroll (1.5.92):** PC/desktop build me scroll
theek kaam nahi kar raha tha (bug report). Do wajah thi — (1) screens me
**fixed toolbar/filters + andar ka `Expanded(ListView)`** = do scroll areas,
aur (2) Flutter ka default `MaterialScrollBehavior` me **mouse** drag-scroll
allowed nahi hota. Fix: naya `lib/core/widgets/page_scroll.dart` —
`PageScroll.children(...)` (header + content ek hi `SingleChildScrollView` me,
**height auto**) aur `PageScroll.builder(...)` (lazy `ListView.builder` jisme
header/footer bhi usi list ke items), saath me ek hi `ScrollController` +
`Scrollbar` (desktop par thumb visible) + optional pull-to-refresh. `app.dart`
me `scrollBehavior: AppScrollBehavior()` lagaya (mouse + trackpad + stylus
drag enabled, `ClampingScrollPhysics`). IPO screener ka double-scroll hata
diya (table ka sirf **horizontal** scroll bacha).

**Kaun-kaun se page convert hue (1.5.92):** IPO screener, Paper Trading (teeno
tab), Reports (Overall / Monthly / By group), F&O 3-Month Study, News, AI
Suggestion, AI Backtest, IPO Database — in sab me pehle fixed header + andar ka
`Expanded(ListView)` tha. Ab har page = **ek** `PageScroll` (height auto, ek hi
scrollbar), header/controls/rows sab saath scroll hote hain.

**Desktop build kaise lein:** `.exe` Windows par hi banta hai — GitHub Actions
workflow wahi hai (`GITHUB_BUILD.md`): naya `NiveshDesk-source.zip` upload →
Actions → Run workflow → artifact me `NiveshDesk.exe`. Linux par seedha
`flutter build linux --release` (isi 1.5.92 par verify kiya gaya). Mobile par
touch scroll pehle jaisa (1419 tests, 103 files).

**Stock OI Build–Unwind (1.5.86) — F&O Hub ka naya tool 📊:** "din me kis
STRIKE par badi position bani ya windup hui?" — official **NSE UDiFF F&O
bhavcopy** (`BhavCopy_NSE_FO_…csv.zip`, jisme har stock-option strike ka
`OpnIntrst` + `ChngInOpnIntrst` hota hai) se. **Rules (price × OI):** price ↑ +
OI ↑ = *Long build-up*, price ↓ + OI ↑ = *Short build-up*, price ↑ + OI ↓ =
*Short covering*, price ↓ + OI ↓ = *Long unwinding*; OI ±1% ke andar = Flat.
**Filters:** Balanced (OI ≥ 5,000 aur |ΔOI %| ≥ 10), Strict (10k / 20%),
All. **Sort:** ΔOI qty ya ΔOI %. Screen me symbol + **expiry dropdown**, builds/
unwinds summary, **Top build-ups** + **Top unwinds** lists aur poora
**strike-wise chain** (CE + PE: ΔOI qty, ΔOI %, signal emoji). Bhavcopy na mile
(holiday/weekend/abhi publish nahi) to ek-ek din peeche walk karta hai; parsed
book date-wise memory me cache hoti hai. Engine:
`lib/features/fno/stock_oi/` (stock_oi_engine pure parsers + rules,
stock_oi_service fetch/cache, stock_oi_screen UI).
Note: **EOD analysis** hai — broker ke live quotes me OI field nahi aata,
isliye intraday tick-by-tick OI possible nahi.

**Bankex–Bank Nifty Strategies (1.5.78–89) — PDF Strategy Library:** F&O Hub
ka naya tool 🏦 — `Bankex-BankNifty-Strategy-Prompt-Library.pdf` ke exact rules
se **regime detector + 6 defined-risk strategies** (1.5.80 me user-request par
P2.1/2.2/2.4/2.5 remove): P2.3 Cross-Expiry Calendar, P2.6 Long
Straddle/Strangle, P2.7 Short Strangle + cross-index hedge, P2.8 Diagonal
Ratio Backspread, P2.9 Iron Butterfly, P2.10 Delta-Neutral Pair.
**Side rule (1.5.81–82) — expiry order, sabhi cross-index strategies par:**
P2.3, P2.7, P2.8 aur P2.10 me **jiski expiry pehle** us index pe short
(near-expiry premium sabse tez decay), **jiski baad me** us pe long; same
expiry ho to higher-IV fallback. Poora dynamic — live expiry dates se, koi
index hardcoded nahi (P2.3 pehle BN-sell hardcoded tha, ab flip hota hai).
Har report ki Entry Rules me line dikhti hai: *"Side rule: BN short (expiry
pehle — DTE 14), BANKEX long (DTE 16)"*.

**Kal → Aaj P&L card (1.5.82):** har strategy report me naya card ⏮️ —
"agar ye strategy **kal** lagayi hoti to **aaj** profit hua hota ya loss, aur
kitna?" Entry = pichhle trading din ka daily candle **close** (broker
`getCandleData`, per option token, Bankex ke liye BFO segment), aaj = aaj ka
close ya live LTP. Card me per-leg ₹change + total ₹ / % premium par, W/L
count. **Honest:** kisi leg ka candle na mile to us leg ko "data nahi mila"
likha jaata hai aur **total hide** rehta hai (adhoore total se galat picture
na bane); demo mode me card saaf bolta hai ki real premium nahi hai. Sirf
premium change — brokerage/STT/slippage nahi. Engine:
`strategy_backtest.dart` (pure `computeLeg` maths + session candle cache).

**Live data fix (1.5.83) — "live market data kyu nahi aa raha":** do real bugs
the, dono fix —
1. **Option book me index contracts hi nahi the.** `FnoContractCollector` sirf
   `NFO` + `OPTSTK` (stock options) leta tha, isliye `BANKNIFTY`/`BANKEX` chain
   kabhi book me nahi aati thi → `LiveSnapshotLoader` pehle hi step par fail
   hokar demo par gir jaata tha. Ab `OPTIDX` bhi accept hota hai — sirf
   **BANKNIFTY (NFO)** aur **BANKEX (BFO)** ke liye; NIFTY weekly/BSE stock
   options ab bhi bahar (3-Month Study ka book waisa hi).
2. **Bankex quotes galat segment se ja rahe the.** `asScrip()` sab contracts ko
   `NFO` maanta tha, par BANKEX options **BFO** (BSE derivatives) me quote hote
   hain → quotes khaali → chain fail. Ab `Exchange.bfo` add hua aur
   `asScrip()` BANKEX → `BFO` deta hai (IPO screener ke chips cash-only filter
   se, isliye UI nahi badla).
Plus: **IV greeks fail hone par poora snapshot demo me nahi girta** — `atmIv = -1`
+ visible amber note (premiums/spot real rehte hain); P2.10 ka IV-differential
gate unknown-IV par honest "verify nahi ho sakta" bolta hai.
**In-feature Data Sync (1.5.84):** Bankex screen ke top par **🔧 Data Sync**
card — Bank Nifty / Bankex contract counts (0 = ❌), master source,
last sync time, aur seedha **"🔄 Scrip master / bhavcopy sync"** button
(Settings me jaane ki zaroorat nahi). Sync ke baad book dobara padha jaata hai
aur live snapshot khud reload hota hai; progress bar + stage text wahi service
se aata hai jo Settings use karta hai. Login ki zaroorat nahi (master file
public hai) — live quotes ke liye login + market-data subscription chahiye.
Book khaali ho to card khud batata hai: *"isi wajah se live data nahi aata"*.

**Live diagnose, step-by-step (1.5.85):** 🔍 Data Sync card ke andar ab
**Angel login → Book → Spot → Quotes → IV** ka ✅/❌ checklist — jo step toota
hai wahi exact reason ke saath dikhta hai (guess nahi). `LiveSnapshotLoader`
ab `LiveDiagnosis` return karta hai (per-step `DiagStep`, fatal vs non-fatal);
IV fail non-fatal hai. Bonus: quotes khaali aayein to **doosra segment
(NFO↔BFO) khud try** hota hai. Report ka **Kal → Aaj** card ab har haalat me
dikhta hai — data na ho to bada ❌ block + reason + **🔁 Dobara try** button
(pehle sirf chhoti grey line thi, isliye "card nahi dikh raha" lagta tha).

**Quote-window fix (1.5.87) — "sirf Bankex/Bank Nifty me error, baaki sab chalta hai":**
index chains me 1,000+ contracts hote hain (BN 1063, Bankex 1222). Loader poore
chain ke quotes maangta tha = **~47 sequential batched call** (50 tokens/call) →
Angel ki rate limit se chunks fail → live load mar jaata tha. Baaki features kam
tokens maangte hain, isliye wahan sab theek tha. Ab quotes sirf **ATM ±6%
window** ke liye jaate hain (strategies ko max ~4.5% OTM chahiye) → **2-4 call**
per index. Diagnose me nayi `· window` line: `144/1063 contracts (ATM ±6%)`.
Bonus: index **spot quote** na mile to chain se **ATM estimate** (CE≈PE wala
strike) hoti hai — UI par saaf warning ke saath, aur spot step non-fatal.

**ROOT CAUSE (1.5.88) — "logged in hone ke bawajood live data nahi":**
`AuthService.ensureValidSession()` sirf **in-memory** `_session` dekhta tha
(`null → false`), aur Bankex loader/backtest/background-brief apna **naya
`AuthService`** banate the — jisme session kabhi load hota hi nahi tha. Isliye
login app me successful hone ke bawajood har market-data call "Not logged in
to Angel One" se fail hoti thi, aur 1.5.79 se Bankex ka live data kabhi nahi
aaya (baaki features provider ka shared singleton use karte hain, isliye wahan
sab chalta tha). **Fix:** `ensureValidSession()` ab session `null` ho to
`restore()` (SecureStore) se load karta hai — central fix, saare callers ke
liye; plus Bankex screen loader/backtest ko provider ki **same**
`AuthService`/`MarketDataService`/`ScripMasterService` deta hai, aur background
brief explicitly `restore()` karta hai. Regression test
`test/services/auth_session_restore_test.dart` — fix hataane par **fail** hota
hai (proof). Diagnose card me **📋 Copy** button bhi — poora step text
clipboard me.

**Live polish (1.5.89) — pehle LIVE load ke do warnings:**
1. **BANKNIFTY spot estimate ho raha tha** — NSE index rows
   (`instrumenttype = AMXIDX`) scrip table me hi nahi jaate (wo cash equities
   ke liye hai), isliye `NIFTY BANK` kabhi resolve nahi hota tha. Ab master
   sync ke waqt index **tokens** cache hote hain (`scrip_index_tokens` meta —
   BANKNIFTY/BANKEX/SENSEX/INDIA VIX), aur loader spot wahin se leta hai. Table
   me kuch add nahi hua, isliye Magic Formula / RSI / study universe
   untouched.
2. **BANKEX IV "No Data Available"** — broker ka greek endpoint BSE index ke
   liye data nahi deta. Ab IV per strike **premium se Black-Scholes**
   reverse-solve hoti hai (wahi solver jo 3-Month Study use karta hai), broker
   IV pehle priority par. Diagnose me source dikhta hai:
   `ATM IV 19.3 · broker + Black-Scholes (0 broker / 142 BS strikes)`.
Rule-based (koi external AI nahi) — strike %OTM, lot 30, credit targets, DTE
gates, OI>5000, slippage sab PDF se. Report: legs, economics, greeks profile,
entry/exit/adjustments + share. Engine:
`lib/features/fno/bankex/` (models, regime_engine, strategy_engine).
**LIVE (1.5.79):** screen Angel SmartAPI se **live chain + broker greeks**
khud load karta hai (`bankex_data_service.dart`) — spot/expiry/DTE/LTP/IV sab
live; 🟢 banner par time dikhta hai. Load fail = demo par fall back (red
banner + reason). Honest gaps: OI book me nahi → PCR/max-pain "OI source
pending" (manual verify); IV-rank history nahi → P2.9 gate manual note.

**Study sort — IVP/IVR (1.5.76–77):** 3-Month Study DONO screens (classic + Advance Filter) ke sort menu me
4 naye options: **IVP (sasta pehle / mehenga pehle)** + **IVR (low / high
pehle)** — IV sheet ke values se, fixed order (label me direction, tap =
wahi order). Jinke paas IV sheet value nahi wo list me last (no data).
Sort button ab clearly dikhne wala icon hai (⋮ nahi — sort ⇅ icon + tooltip).
Purpose: IVP basis par option BUY (sasta premium = low IVP pehle).

**Morning Brief (1.5.75) — daily 8:30 AM Top 20:** Har trading day 8:30 AM
par 3-Month Study ka **Top 20 (rank order)** automatically scan hoke
notification aata hai (summary: Top 5 + "+N aur") — tap = poora list
(`MorningBriefScreen`); Notifications screen me ☀️ box bhi. Android: exact
alarm (`android_alarm_manager_plus`, reboot-safe) background isolate me
khud services bana kar scan karta hai (cached candles se offline bhi; fail =
last cached scan se brief). Desktop: app chalte hue Timer; app band =
app-open par catch-up (dono platforms). Sirf trading days (NSE holidays
MarketCalendar se). Engine: `lib/features/alerts/morning_brief.dart`.

**Notification Center (1.5.74) — alerts system:** AppBar ka 🔔 bell (unread
badge) → Notifications screen. Alerts: 📞 **Calls Board** — tracked call ka
SL/target/expired hit (classifyOutcome se); 🎯 **Price alerts** — user apna
level set karta hai (upar/neeche), one-shot; 📡 **Study/scanner signals** —
IVP ≥ 80 (mehenga) / ≤ 20 (sasta) extremes (dedupe: sirf naye) + F&O Scanner
shortlist updates. Dikhne ka tarika: **OS notification** (Android channel
"NiveshDesk Alerts" + Windows toast via local_notifier) + **in-app history**.
Price checker market hours me har 3 min (Angel login chahiye). Engine:
`lib/features/alerts/alerts_center.dart` (persist SettingsDao meta me);
OS layer `lib/services/notification_service.dart`. Desktop par app band ho to
OS pop-up nahi (background service nahi); Android par app open/hot-start me
alerts aate hain. Note: compileSdk 37 + core-library desugaring enable kiya
(flutter_local_notifications v23 requirement).

**Desktop layout (1.5.73) — wide design mode:** Desktop (Windows/Linux) par
app ab proper PC-software jaisa dikhta hai — baaye **sidebar navigation**
(NavigationRail), Study me **master-detail** (list left, detail side panel),
F&O Scanner me paanch lists **2-column grid** me, Calls Board/News cards
multi-column grid, window **1280×840**. Mobile APK compact layout bilkul waisa
hi — `DesktopLayout.isWide()` width se decide karta hai. Core helper:
`lib/core/layout/desktop_layout.dart`. Baaki screens (IPO/Golden/RSI/Paper/
Reports/forms) next cycle me wide honge.

**Desktop / laptop (Windows) build (1.5.72):** App ab Flutter **Windows
desktop** ke liye ready hai — `build_windows.bat` chalao (guide:
`DESKTOP_BUILD.md`) → `NiveshDesk.exe` + optional Inno Setup installer
(`installer.iss`). Desktop par: SQLite `sqflite_common_ffi` + bundled sqlite3
(DB `%APPDATA%` me, data safe), share/export = **Downloads folder** me save
(honest path message), window phone-size (540×980), Angel login/quotes/Telegram
sab browser-CORS ke bina seedhe chalte hain. Linux desktop build bhi
compile-verified. Mobile APK waisa hi chalta hai.

**Options Calls Board (1.5.71) — standalone module:** AppBar ka 📡
(cell-tower) icon → alag screen (F&O ke bahar). 3 tabs: **📞 Calls** (har
captured call: instrument · side · Entry/SL/T1/T2 · live LTP · status ·
points), **🏆 Scoreboard** (channel-wise Win% · W/L/E · avg pts · chhote
sample par honest warning), **📺 Channels** (khud add karo —
`https://t.me/<channel>` / `@handle` link se, jitne marzi; pause/remove bhi).
Flow: channel poll (`t.me/s/` previews, har 5 min + manual) → call messages
parse (NIFTY 25500 CE BUY @120 SL 90 TGT 150/180 jaise formats) → paper
follow (options = contract book exact strike + live quote; equity = scrip
master; **futures honestly not tracked**) → SL/target call ke apne numbers se
mechanical classify (SL priority on gaps, 5 sessions par expired). Unparseable
message = skip (guess nahi). DB v16 (`calls_channels`, `option_calls`). Paper
following hai — app trade nahi lagata.

**F&O Scanner LIVE mode (1.5.70):** Scanner ab market hours (Mon–Fri
9:15–15:30 IST) me **live** chalta hai — Top Gainers/Losers, Volume ×2 aur
plan ka Entry=LTP **Angel ke batched live quotes** se, har 5 min auto-refresh
+ ⚡ manual refresh button. Header me `⚡ LIVE HH:MM` badge + honest note.
**OI Change + CPR hamesha EOD** (bhavcopy OI, daily pivot levels) — labelled.
Live fail (Angel login/logout, network) → purana EOD scan chalta rehta hai +
honest 'EOD data' note; EOD Rescan button bhi hai. EOD bhavcopy shaam ~5 PM
ke baad milta hai — subah/dupehre EOD trade date kal ka hi hoga (wahi latest
hai), live overlay uske upar aaj ke rates chipkata hai.

**IVP/IVR study cards me (1.5.69):** 3-Month Study (detail card) aur 3-Month
Advance Study (har card ke metric grid) me ab **IVP aur IVR ke apne labelled
boxes** hain (1.5.58 style) — Opstra Google Sheet se, sheet load hote hi khud
update. Sheet me value na ho to '—' (boxes hide nahi hote). Chhota chip bhi
waisa hi hai.

**News me F&O filter (1.5.68):** News ke filters ab teen — **Sabhi** ·
**Mere stocks (basket)** · **F&O stocks** (naya). F&O filter me sirf un
news aati hain jo **F&O segment stocks** ke baare me hain (universe = local
option-contract book + 3-Month Study rows). Jaisa basket filter chalta hai
waisa hi. (Saath fix: basket filter ko entry point se basket list nahi mil
rahi thi — ab dono filters sahi kaam karte hain.)

**IV sheet — wide Google Sheet support (1.5.66; 1.5.67 rule):** Opstra sheet
ab **jitne bhi columns** ke saath chalega — parser **header se** sirf
`Ticker/Symbol`, `IVP`, `IVR` (optional `Date`) map karta hai; **baaki saare
columns ignore** (user rule: sheet se sirf IVP/IVR — IV/price/premium sab
app ki apni API/calculation sources se aate hain, pehle jaisa). Quoted cells
safe, IVP/IVR ka 0–100 rule same, gates/score bilkul same. Purani 3-column
sheet bhi chalti hai.

**F&O Scanner — Magic Formula icon ka 2nd function (1.5.63; universe fix
1.5.64; UDiFF parse fix 1.5.65):** Magic Formula icon pe ab **do option** aate
hain: ① Magic Formula (waisa hi) ② **F&O Scanner** (naya). **Universe = sirf
F&O stocks** (FO bhavcopy ke stock-futures underlyings — non-F&O cash stocks
kisi list me nahi; FO bhavcopy na mile to honest error, scan jhootha nahi).
Official UDiFF FO bhavcopy me stock futures `FinInstrmTp=STF` hote hain —
parser wahi padhta hai (STO/IDF/IDO skip). Scanner
official NSE bhavcopy (CM + FO) se **5 lists** banata
hai — Top Gainers · Top Losers · OI Change (near-month futures, build-up
label ke saath) · **Narrow CPR (daily)** (kal ke OHLC se CPR, width ATR se
normalise) · **Volume ×2** (aaj ka volume ≥ 2× 20-din average) — har list
Top-10. **Score**: har top-10 entry par points 10..1 (rank ke hisaab se),
score = points × 2 (0–100). **Shortlist** = stocks jo ≥2 lists me hain —
unke liye **trade plan**: direction votes se, Entry = LTP, **SL = 1×ATR(14),
Target = 2×ATR(14)** (mechanical rule) + **options plan** (ATM CE/PE, strike,
expiry, lot — local contract book se; real premium broker quote se; premium
SL/target = entry × 0.5 / × 1.5 rule). Missing data = '—', koi guess nahi.
Scan ek baar cache hota hai (trade date), Rescan se refresh.

**Avg Range (14) — din ka average range (1.5.62):** ATR(14) ke saath ab
**Avg Range (14)** bhi dikhta hai — pichhle 14 sessions ke **High − Low ka
simple average** (₹ + price ka %). Fark: ATR me kal ke close ke gap bhi
count hote hain aur Wilder smoothing hoti hai; ye **sirf din ka range**
hai, gap up/down chhod ke. Jagah: 3-Month Study detail (Volatility
section), Study Excel export, AI Jodi table + uska export, AI Suggestion
chips + export. Sirf display — koi gate/score/verdict nahi badla.
"Purane snapshots" me '—' dikhta hai (zero nahi).

**IPO screener — compact table (1.5.60, row fixes 1.5.61):** bade cards ab
**single-row table** me — sticky header + poora table ek horizontal scroller
me (AI Jodi jaisa): Stock · Price · Near High/Low · Listed · High · Low ·
Actions (copy + Chart). Level badge me **"Near High/Low" upar aur distance
("1.27% below") apni line me** (1.5.61); Range bar column hataya (1.5.61);
Listed/High/Low ke andar wale chhote labels hataye — labels sirf column
header me. **Row click** wahi detail sheet kholta hai jo pehle kholta tha
(saari details wahi hain); **Near High/Low badge bhi click link hai**. QuickChips
ke Near High/Near Low filters bilkul waise hi chalte hain.

**Equal-height metric boxes (1.5.59 fix):** 1.5.58 ke boxes ki height row
me upar-neeche ho rahi thi (sub line hone par box lamba). Ab `MetricGrid`
har row me sab boxes ko **same height** deta hai (equal width bhi) — rows
ab saaf line me dikhti hain. `expand` box poori row leta hai.

**Design overhaul — clean, simple, user-friendly (1.5.58):**
- **Shared design system** (`core/widgets/ui.dart`) — `MetricBox`/`MetricGrid`
  (har value apne labeled box me — text kabhi judta nahi), `InfoSection`
  (emoji + short title + tooltip), `TapChip` (press feedback), `SmoothExpand`
  (soft grow/shrink animations). Bade compound text ki jagah chhote labels +
  symbols (📈 3M High, ⚡ ATR, 🤝 jodi…) — full meaning tooltip me.
- **3-Month Study fully re-laid out** — row card me zones alag (rank ·
  symbol+trend chip · price | score · tag | ATM/OTM % chips), detail panel ke
  saare 9 sections ab metric grids me: CMP/High/Low/Range, ATR + jodi totals,
  month moves, trend score breakdown, ATM legs (CE/PE apne boxes me), OTM
  strangle, results dates, kal-P&L. Subtle fade-slide row entrances.
- **Study Advance cards** — same grid treatment (Score naya/purana/farq/edge
  boxes + emoji tag chips); detail = the redesigned study panel.
- **News** — feed cards ab fade-slide stagger me aate hain. Baaki screens
  (Home, Settings, Basket, Reports…) me calm spacing/icons already theek
  hain; unke liye yehi design system ready hai aage ke passes ke liye.

**IVP/IVR everywhere — universal sheet link (1.5.57):**
- **Settings me ek hi link** — naya "IVP/IVR sheet (Opstra)" section: Google
  Sheet link save karo, aur wahi data AI Jodi Study, 3-Month Study aur Study
  Advance — sab jagah use hota hai (shared cache). AI Jodi ka toolbar icon
  bhi wahi dialog kholta hai (shortcut).
- **Dono study screens me IVP/IVR chip** — har stock ke saath
  `⭐ IVP 30 · IVR 20` (sasta, green), `IVP 55 · IVR 60` (mid), ya
  `⚠️ IVP 72 · IVR 80` (mehnga, orange warning — sirf warning, study me
  koi verdict gate nahi). Sheet me values na hon to chip chhup jaata hai
  (missing stays missing).
- Rescan ke saath sheet bhi refresh; screen open hone par bhi.

**IVP/IVR Google Sheet + jodi Gate 4 (1.5.56):**
- **Opstra IVP/IVR sheet** — Settings me ya AI Jodi Study ke toolbar se
  Google Sheet ka link daalo (sheet "Publish to web" CSV honi chahiye, koi
  login/API key nahi). App symbol, IVP, IVR padhta hai, cache karta hai, aur
  honest "as of &lt;date&gt;" dikhata hai; missing values missing hi rehte hain.
- **Gate 4 — IV mehnga to buy demoted** — IVP/IVR ≥70 par non-manual
  "ATM/OTM buy" verdict `⚠️ IV mehnga` me badalta hai (IV crush ka risk);
  manual rows sirf warn hote hain, kabhi gate nahi. IVP/IVR ≤40 (⭐ sasta)
  ko top-list ranking me +0.5 ka score bonus.
- **Table me IVP/IVR column** + numeric IV star (⭐/⚠️) stock cell me;
  filter chips me "Abhi mat le" ke saath IV-rich rows bhi aati hain.
  Export (CSV/Excel) me IVP/IVR columns.
- **Backtest (official NSE F&O bhavcopy, 2025-09-16 → 2026-10-23, 272
  sessions, 53,021 ATM-straddle buys, hold-to-expiry; derived BS IV — Opstra
  values nahi):** cheap IV (≤40) bucket win rate **47.0%**, avg P&L
  **+₹17.67**; rich (≥70) win **40.2%**, avg **−₹28.64**; all buys win
  39.8%, avg −₹13.84. Rich-din exclude karne se win rate ~same rehta hai
  (39.6% vs 39.8%) par **average loss per buy ~half** (−₹7.25 vs −₹13.84).
  Matlab: asli edge ⭐ cheap-vol bucket me hai; rich filter worst losses
  kaat-ta hai. Method details `scripts/jodi_iv_backtest.py` + uska JSON.

**Top-3 bundle (1.5.55):**
- **News × Jodi cross-signal** — the News deep-research panel shows a
  badge per stock: 🔥 "News + Jodi dono bol rahe hain" when the offline jodi
  engine currently gives that stock a buy verdict (2× cover), otherwise an
  honest "Jodi: …" label. The AI Jodi table shows the reverse: 🔥 News+Jodi
  chips (or 📰 N news) on rows whose stock had high-impact news in the last
  48 hours (session bridge — chips appear after News has loaded).
- **AI Jodi table controls** — sort by Rank / Cover % / Price / Kal→aaj
  change, verdict filter chips (Sabhi / ATM buy / OTM buy / Abhi mat le),
  and a dedicated **Kal→aaj** column (ATM/OTM premium change vs yesterday's
  close) moved out of the verdict cell. Engine rank numbers stay stable
  when the display order changes.
- **News daily digest + Mere stocks** — an "Aaj ka digest" card ranks the
  top-5 news by a rule-based score (impact + kind + freshness), and a
  "Mere stocks (basket)" filter narrows the feed to news touching the
  user's Magic Formula basket members (empty baskets honestly say so).

**Verification:** the full serial offline test suite passed (**1,343 tests**),
including regressions for the half-yearly balance-sheet fallback, no
older-date back-fill inside a document, no mixing of older filings into a
partial quarter balance sheet, the banking/NBFC/insurance format mappings
and PBT-proxy labelling, both plain-XML and inline-XBRL parsing of a real
Bajaj Finserv NBFC instance, the insurance inputs (share-count market cap,
YTD PAT/EPS pairing, single-side borrowings, Schedule-identity current
liabilities, capital-total face-value refusal), the 1.5.39 surface (BSE
`Quarter_Name` parsing, BSE CM-UDiFF columns incl. the `FinInstrmId` scrip
code, the full BSE price+filings pipeline end-to-end on fixtures,
listing-master face-value market cap, honest skip when no scrip code exists,
basket CRUD/cascade/dedup, suggestion ranking, and basket scan through the
provider), and the 1.5.40 fall-through (capital-total face value → master
face value; implausible share count → next source; comma-shifted master
rows), and the 1.5.41 surface (Yahoo market-cap fill with the unofficial
label and missing-list cleanup, failed-fallback honesty, Yahoo price rescue
for out-of-EOD basket members, the four-name master search, and the hanging
listing-download timeout), and the 1.5.42 SBILIFE shape (thin June face →
balance whole from the shared Mar-Qtr/Mar-Yearly half-year statement, zero
borrowings read as zero debt, row ranks with the honest balance-sheet date,
while the older-date-refusal and no-mixing tests keep passing unchanged),
and the 1.5.43 TTM covers (SIEMENS shape: NineMths + quarter across a
gap-fed stream with the out-of-window quarter excluded; VAML shape: Yearly −
prior-year comparative + current quarter with the balance whole from the
half-year statement; a window that no official columns can cover stays
honestly missing; stale suggestion lists answer instantly). The changed-code
analyzer scope reported no issues. The arm64-only
APK's v2 signature, signing continuity and ZIP alignment were verified. No
live NSE requests were used for these tests/build checks. The app uses no
exchange cookies or credentials and stops honestly if a public EOD archive is
unavailable or changes. NSE's
[All Reports](https://www.nseindia.com/all-reports) page lists the dated
CM-UDiFF Common Bhavcopy Final ZIP; BSE's
[Bhav Copy page](https://www.bseindia.com/markets/MarketInfo/BhavCopy.aspx)
lists its same-format Equity (UDiFF) file; the official UDiFF formats define
the `TradDt`, `ISIN`, `TckrSymb`, `FinInstrmId`, `SctySrs`, and `ClsPric`
fields used by the offline parser tests.

```bash
# Install on a phone with USB debugging enabled
adb install -r NiveshDesk-1.5.94.apk
# …or copy the file to the phone and tap it (allow "install unknown apps")

# Rebuild it yourself — one 64-bit APK, same as the shipped file:
flutter pub get
flutter build apk --release --target-platform android-arm64
#  → build/app/outputs/flutter-apk/app-release.apk   (~23 MB)
```

This installs **over** 1.3.0 / 1.2.0, keeping the database (same package id and
debug key).

Because it is debug-signed, Android installs it happily but **Google Play will
reject it**. See [Signing for Play](#signing-for-play) below.

**Build settings worth knowing** (`android/gradle.properties`)

* `org.gradle.jvmargs=-Xmx1100m` — deliberately small so the build also works on
  a 2 GB machine. On a normal laptop raise it back to `-Xmx4G`.
* `android.builtInKotlin=true` — let AGP 9 compile the plugins' Kotlin itself.
  With this set to `false` (the current `flutter create` default),
  `package_info_plus` and `android_file_picker` apply the Kotlin Gradle Plugin
  dynamically, their Kotlin sources compile to nothing, and the build dies with
  `error: cannot find symbol … PackageInfoPlugin` while compiling the generated
  plugin registrant.
* `kotlin.compiler.execution.strategy=in-process` compiles Kotlin inside the
  Gradle JVM instead of starting a second 512 MB daemon — the difference between
  a build that finishes and one that swaps on a 2 GB machine.
* `lint { checkReleaseBuilds = false }` in `android/app/build.gradle.kts` skips
  `lintVitalRelease`, a *check* that never changes the APK. It is by far the
  heaviest task of the release build on a small box. Turn it back on (it catches
  fatal issues before shipping) on a normal development machine.
* `android/local.properties` is intentionally **not** in the repo — `flutter pub
  get` / `flutter build` regenerate it with your own SDK paths.

### Signing for Play

```bash
keytool -genkey -v -keystore ~/angel-trader.jks -keyalg RSA -keysize 2048 \
        -validity 10000 -alias angeltrader
```

Then create `android/key.properties` (keep it out of git):

```properties
storeFile=/absolute/path/to/angel-trader.jks
storePassword=…
keyAlias=angeltrader
keyPassword=…
```

…and point the release build type at it in `android/app/build.gradle.kts`,
replacing the `signingConfig = signingConfigs.getByName("debug")` line:

```kotlin
val keystoreProperties = java.util.Properties().apply {
    val f = rootProject.file("key.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

android {
    signingConfigs {
        create("release") {
            storeFile = file(keystoreProperties.getProperty("storeFile"))
            storePassword = keystoreProperties.getProperty("storePassword")
            keyAlias = keystoreProperties.getProperty("keyAlias")
            keyPassword = keystoreProperties.getProperty("keyPassword")
        }
    }
    buildTypes {
        release { signingConfig = signingConfigs.getByName("release") }
    }
}
```

---

## Angel One API setup

You need three things from Angel One: an **API key**, your **client code**, and
**TOTP enabled**. Full walkthrough with screenshots-in-words:
[`docs/SETUP.md`](docs/SETUP.md). Summary:

1. **Open an Angel One demat/trading account** (any existing account works — the
   SmartAPI is free for account holders).
2. Go to **https://smartapi.angelbroking.com** → sign in with your Angel One
   credentials.
3. **Create an app**: *My Apps* → *Create App*. Give it any name; the *redirect
   URL* is irrelevant for this app (it is not an OAuth flow). Copy the
   **API key** shown against your app (`X-PrivateKey`).
4. **Enable TOTP**: in the SmartAPI dashboard (or the Angel One app under
   *Profile → Security → TOTP*), enable TOTP for API login and copy the
   **base32 secret** (e.g. `JBSWY3DPEHPK3PXP`). This app generates the rotating
   6-digit code itself — you do **not** need Google Authenticator on the same
   phone (you can also type the 6 digits manually from any authenticator).
5. Keep handy: **client code** (`A123456`), **MPIN** (the 4-digit PIN you use in
   the Angel One app) or your login password.

Then in the app: fill the login screen → *Connect to Angel One*. Credentials go
into the platform keystore, the JWT is refreshed automatically before its daily
05:00 IST expiry, and you are only asked for the TOTP secret once.

> The API key is personal. Never commit it — the app asks for it at runtime and
> stores it encrypted, so nothing ends up in git.

---

## Feature 1 — IPO proximity screener

**Rule implemented** (exactly as specified):

```
include the IPO  ⟺  |LTP − listing-day high| ≤ 3 %   OR   |LTP − listing-day low| ≤ 3 %
```

The band is configurable (±0.5 % … ±10 %) from the filter sheet or Settings;
±3 % is the default. Boundary values are inclusive (`3.00 %` is included,
`3.10 %` is not — see `bandEpsilon` in the engine and its test).

| Spec item | Where it lives |
|---|---|
| Local database of mainboard IPOs listed after 1 Jan 2015 (symbol, company, listing date, listing high/low) | `ipos` table, `IpoDao`, seeded from `assets/data/ipos.csv` |
| Manual add / edit / delete of entries | `IpoDatabaseScreen` + `IpoFormSheet` (swipe to delete, tap to edit) |
| Fetch current LTP of each IPO on refresh | `MarketDataService.fetchLtp()` — batched **50 tokens per request** |
| ±3 % filter | `IpoScreenerEngine.evaluate()` (pure Dart, unit-tested) |
| Card: symbol, company, listing date, listing high/low, current price, level & % difference | `IpoMatchCard` |
| "Chart" button → TradingView (`NSE:SYMBOL`, `BSE:SYMBOL`) | `IpoMatch.tradingViewUrl` + `LinkOpener` |
| Filters: exchange, listing year, near high vs near low | Filter sheet + quick chips (filters never re-hit the network) |
| Extra | sort modes, search, pull-to-refresh, offline/cached banner, ± band slider, CSV import/export |

**How a refresh flows**

```
ipos (SQLite) ─▶ TokenResolver (scrip master cache) ─▶ LTP batch fetch (50/call)
                       │                                        │
                       └── rows without a token are reported ───┘
                                        ▼
                    IpoScreenerEngine.evaluate(±band, filters, sort)
                                        ▼
                       cards  +  price cache & scan cache in SQLite
```

* The screen paints the **cached** result immediately, then refreshes live — so it
  is never blank, and it keeps working with no network and no login.
* Auto-refresh runs on a timer **only while the market is open** (09:15–15:30 IST
  on a trading day that is not in the holiday calendar).
* Rows that cannot be screened (no token, no price) are counted and listed with a
  reason, and there is a one-tap *"Download instrument master & re-screen"* fix.

---

## Feature 2 — Golden Cross / Death Cross screener

**The rule implemented** (both directions, same code path):

```
Golden Cross  ⟺  SMA50[prev] ≤ SMA200[prev]  AND  SMA50[now] > SMA200[now]   (bullish)
Death  Cross  ⟺  SMA50[prev] ≥ SMA200[prev]  AND  SMA50[now] < SMA200[now]   (bearish)
```

Only completed daily bars are used, and a 200-day average is **never faked**: an
instrument with fewer than 205 bars (a fresh listing) is skipped and listed under
*"N instruments skipped · not enough history"* instead of producing a signal.

| Spec item | Where it lives |
|---|---|
| Daily candles via `getCandleData` | `services/market_data_service.dart` (the `CandleSource` implementation) |
| 50 / 200 SMA + crossover detection | `features/golden_cross/cross_engine.dart` — pure Dart, no Flutter |
| Golden cross by default, Death cross behind a toggle | `FilterChip` in the tab header; persisted as `death_cross_enabled` |
| Cross date, both SMAs, price, TradingView link | `features/golden_cross/widgets/cross_signal_card.dart` |
| Cached results per trading day | `scan_runs` (`kind = golden_cross`) via `services/cross_scan_service.dart` |
| Scan for a selected date | date chip in the header → `showDatePicker` → `setViewDate()` |
| Daily job after 6 PM IST | `CrossScreenerProvider.maybeRunDailyJob()` + `MarketCalendar.isDailyJobWindow()` |
| Toggle: Golden / Death / This session, search | `CrossFilter` + `CrossScreenerProvider.visibleSignals` |

### What the card shows

Symbol + exchange + company · a **GOLDEN/DEATH** chip with a dot when the cross
fired on the screened session · the current close · a **60-session sparkline** with
the 50-SMA, the 200-SMA and a dashed marker on the cross bar · the cross date and
how many sessions ago it happened · SMA50 / SMA200 / **gap %** · a **Chart** button
that opens `https://in.tradingview.com/chart/?symbol=NSE:SBIN` in TradingView.

Tapping a card opens a sheet with the full numbers — both averages now *and* on the
bar before the cross (which is what proves the crossover), the tokens used, and the
same chart button.

### Scan universes

The scanner never asks for 400 days of history for 5,000 companies by accident —
you pick the universe, and the size/time estimate is shown before you start:

| Universe | Instruments | First scan | Why |
|---|---|---|---|
| **Nifty 50** (default) | ~50 | ~20 s | large caps, the classic golden-cross hunting ground |
| IPO database | your Feature 1 rows | seconds | is a recent listing already crossing? |
| All NSE equities | a few thousand | ~8 min | whole-market sweep |
| All NSE + BSE | everything | longer | only after the full master is downloaded |

Universe resolution happens against **local** data (SQLite scrip master + IPO
table) through `TokenResolver`, so switching costs nothing and works offline. Any
ticker that cannot be resolved is reported (`49 of 50 resolved`) rather than
silently dropped — and a `master_*` sweep that resolves to nothing stops the scan
with an explanation instead of burning API quota.

### Rate limits, caching and the "daily job"

Angel One allows **3 candle requests/second** (180/min, 5000/hour). The scanner is
therefore:

* **sequential** — never parallel, paced by `ApiClient`'s limiter,
* **cache-first** — daily bars are immutable once a session closes, so the first
  scan of a session downloads ~275 bars per instrument into the `candles` table
  and every later scan (reopen the app, change a filter, flip to Death Cross) is
  served from SQLite with **zero** network calls,
* **resumable and cancellable** — *Stop* keeps everything already fetched and
  scanned; a failed symbol becomes a line in the *skipped* sheet, never a crash,
* **self-pruning** — bars older than 700 days are swept after each scan.

Results are persisted per trading day, so the tab opens instantly and offline, and
the header says exactly what you are looking at: `29 Sep 2025 · 47 scanned, 41 from
cache, 6 downloaded · 2h ago`.

**The 6 PM job.** There is no server in this app, so the daily scan runs *in the
app*: when you open the Golden Cross tab after **18:00 IST on a trading day**, and
today's scan is not already cached, it starts automatically (once per app launch,
only while logged in). If the phone is never opened that evening, the next open
scans the same session normally — no data is lost, it is simply not a background
daemon. If you want a phone-free notification, set a **webhook** in
Settings → *Webhook* (ntfy, a Telegram bot, or your own endpoint); it receives a
JSON `POST` only when the scan finds something:

```json
{
  "source": "angel_trader", "kind": "cross_scan",
  "asOf": "2025-09-29", "universe": "Nifty 50 · 49 of 50 resolved",
  "golden": 2, "death": 1, "scanned": 49,
  "signals": [{"symbol": "SBIN", "direction": "golden", "crossDate": "2025-09-25",
               "sma50": 806.71, "sma200": 798.42, "gapPct": 1.04, "chart": "…"}]
}
```

---

## Feature 3 — Paper trading & Reports

A complete trading desk that never sends an order. Fills are matched inside the
app against live prices and written to SQLite; the button says it and the code
proves it (no order endpoint is ever called).

### Trading

| | |
|---|---|
| **Virtual capital** | ₹1,00,000 by default; presets in *Settings → Paper trading* |
| **Orders** | BUY/SELL · MARKET (fills at the live LTP) or LIMIT (rests until the market reaches it, then fills at the market price) |
| **Stop loss** | price **or** %, tick-rounded and always below the entry; monitored on every tick and squared off at market |
| **Target** | optional; shown on the card, auto-booked only if you enable it in Settings |
| **Groups** | strategy/basket tags (chips ordered by usage, "+ New group" inline). The exit leg inherits the tag, and a position can be re-tagged later |
| **Risk tools** | risk : reward preview, break-even exit price (after both legs' charges), max affordable quantity |

Order book rows keep the reason they exist: `MARKET`, `LIMIT reached`,
`Manual fill`, `Auto-exit: stop loss`, `Auto-exit: target`, `Manual exit`.
Resting limits can be cancelled or force-filled.

### Charges — why the simulation is realistic

Every leg is billed like a genuine Angel One trade, so a strategy that only
"works" before costs will show as a loss:

* **brokerage** — ₹0 on delivery, ₹20 or 0.25 % (whichever is lower) per intraday leg
* **STT** — 0.1 % both sides on delivery, 0.025 % on the sell side intraday
* **exchange transaction charge** — NSE 0.00297 %, BSE 0.00375 %
* **SEBI fee** 0.0001 % · **stamp duty** 0.015 % (delivery buy) / 0.003 % (intraday buy)
* **GST** 18 % on (brokerage + exchange + SEBI) · **DP charge** ₹13.50 + GST on delivery sells

Realised P&L is stored **net of both legs' charges** (the entry's share is carried
on the position and settled when it closes), and totals are rounded to the paise.

### Live prices, stop monitoring

* **WebSocket 2.0** (`wss://smartapisocket.angelone.in/smart-stream`): LTP mode,
  literal `"ping"` every 10 s, 1,000-token sessions, subscription diffing (only
  the open book is streamed) and exponential reconnect with jitter.
* The order sheet asks for a **single REST quote** when you pick a symbol the
  feed is not streaming yet, so a MARKET order can always be validated.
* With the feed off, the book is valued by **REST polling** (interval from
  Settings) instead; the header shows which source is in use.
* A breached stop-loss auto-exits **immediately on the tick** (the target too, if
  you enabled auto-exit). The screen stays awake while a live book is streaming.

### Holdings · Orders · Trade book · Reports

* **Holdings** — quantity × average, invested, LTP with a live indicator,
  unrealised P&L, and a stop↔target bar showing where the price sits between them.
* **Orders** — resting limits (with the distance to fill) above, history below.
* **Trade book** — leg-level audit trail with charges and realised P&L; tap a leg
  for the full record (token, value, charges, which leg it is, chart link).
* **Reports** — three views over the same data:
  * **Overall** — realised P&L, win rate, expectancy, profit factor, biggest
    win/loss, best month + the 12-month realised bar chart (tap a bar).
  * **Monthly** — month-by-month table (empty months stay visible) with charges.
  * **By group** — month × group bars coloured from the shared palette, plus each
    basket's realised P&L, win rate and the **live unrealised P&L** of what is
    still open. Archived groups keep their history.
  * **CSV export** of the filtered trade book (12 columns) via the clipboard.

### Groups — the details

* Create up front (*Settings → Paper trading → Trade groups*) or inline while
  placing an order; names are unique and reserved words (`Ungrouped`) are refused.
* A group may be **archived** (hidden from the picker, P&L still reported) or
  **deleted** — deleting always asks where to move the trades, because history is
  never destroyed.
* Filters (Holdings / Trade book / Reports / dashboard, all sharing one selection)
  answer "how is *this* basket doing?" including the Ungrouped bucket.

Schema: `trades`, `positions`, `paper_orders`, `trade_groups` (**v3**), with a
migration that keeps existing paper trades and adds `group_id`, `charges_paid`,
`stop_loss`/`target` and the order fields.

---

## Feature 6 — F&O module: the 3-Month Study, Results Calendar, AI Suggestion

The equity tabs answer questions about *stocks*. F&O is a different instrument
class — expiries, lots, implied volatility — so it gets its own module: the
**F&O** button in the app bar opens a hub with three live tools — the
**3-Month Study**, the **Results Calendar** and **AI Suggestion** (the bottom
navigation keeps its five equity tabs).

### What the study does

For each F&O stock it takes the **last 63 trading days** and computes:

| Step | What is computed | How |
|---|---|---|
| Window | 3M high / low / range | last 63 bars; a stock with **fewer than 60 bars is skipped** with a reason (fresh listing, suspension) |
| ATR | ATR(14) and ATR % | **Wilder** smoothing: seed = mean of the first 14 true ranges, then `(prev × 13 + TR) / 14` |
| Distances | how far the price is from the 3M high/low | in percent **and** in *ATR-days* (`(level − price) / ATR`) — a level 1 ATR away is a very different trade from one 8 ATR away |
| Months | the last three calendar months' moves | month close-to-close, oldest first (`M1 … M3`) |
| Trend | STRONG UP / UP / SIDEWAYS / DOWN / STRONG DOWN | ≥ 6 % (or ≤ −6 %) **and** at least 2 months agreeing → strong; ±1.5 % → normal; everything else sideways, suggesting `BUY CE` / `BUY PE` / `AVOID` |
| Options | ATM strike, CE/PE premium, IV, IV rank, edge | strike from the **local option book**, premiums from a **batched full quote**, IV from the broker or **Black-Scholes** |
| Score | 0–12 | consistency (0/1/2+ months disagreeing) + magnitude (`|move| / 8`, capped) + proximity (distance to the level the trend points at) + IV points |
| Tag | 🎯 Best Buy / ⏸ Watch / — | 🎯 when the IV rank is **low** and the edge is not negative; ⏸ with the IV level spelled out otherwise; `-` for sideways |

Plus the line the brief asks for — **"agar kal jodi buy ki hoti"**: what an ATM
CE + PE straddle bought at yesterday's close would be worth today, in **points
and rupees × lot**. It is always printed as **Profit/Loss words** (never a raw
minus sign), and it is labelled as an *observation*, not a suggestion.

### Where the option data comes from (broker-first, no third parties)

1. **Contract book** — the daily scrip-master refresh now also streams every
   `NFO` / `OPTSTK` row through `FnoContractCollector`, keeping the **two nearest
   expiries** per underlying into the `fno_contracts` table (schema **v6**).
   Strikes arrive in paise and are converted to rupees with epsilon
   normalisation, so `129850` never becomes `1298.5000000000002` and duplicates
   cannot break the UNIQUE index.
2. **Premiums** — the scan collects every ATM leg across the universe and asks
   for them in **one `FULL`-mode quote call per 50 tokens** (full mode is what
   carries the *previous close* the straddle line needs). All 213 stocks ≈ 5
   requests.
3. **IV** — one `optionGreek` call per stock returns the whole chain for that
   expiry. When it is unavailable (or the expiry is today, where IV means
   nothing), the study **solves IV from the premium with Black-Scholes**
   (bisection over 0.5 %–500 %, accepting 1–400 %), and refuses impossible prices
   (`tinyPremium`, `belowIntrinsic`, `aboveRange`) instead of printing a number.

### Degraded mode is a first-class state

A stock whose option data fails is **never dropped**: it stays in the table with
its trend, ATR, levels and score, shows a cloud-off icon, and the reason lands in
the study's notes (`— options — Option premium quote fail hua (…): degraded
mode`). Only genuinely unscannable stocks (too little history, no candles) are
skipped — and every one of them is listed with its reason.

### The screen

* **Frozen snapshot** — opening the tab shows the last stored study; scanning is
  always an explicit tap. The only live element is the expanded stock's ATM
  premium line (the two legs are subscribed over the existing WebSocket feed
  while the detail panel is open, and released when it closes).
* **Sortable table** — default order is 🎯 best buys first, then score; every
  header is tappable, and a missing value always sorts last in both directions.
  Filter chips: 🎯 Best Buy · ⏸ Watch · AVOID · High ke paas · Low ke paas ·
  Option data nahi. Search matches symbol, company and trend.
* **Detail panel** — the seven spec sections (levels, ATR, monthly moves, trend +
  score breakdown, ATM option with live premium, yesterday's straddle P&L, the
  one-line reason) plus two actions: **paper trade me add karo** (a CE/PE picker
  that hands the leg to the existing order sheet — lots, charges, SL/target all
  still apply) and Read Me.
* **Export** — 3-sheet Excel (`Read Me` / `All Stocks` / `Best Buys`, falling
  back to the top 20 when there is no best buy today), flat CSV, a WhatsApp text
  recap, and **Telegram** (real Bot API document upload; bot token + chat id live
  in Settings). Exports follow the *filtered* table, so what you send is what you
  saw.

The study always covers the **whole** F&O universe — every stock that resolves
from the shipped list (`assets/data/fno_symbols.csv`, 213 names, broker-sourced),
through the same token/ISIN resolver as every other screener. There is
deliberately **no "stocks per scan" setting**: a study that quietly stops at N
stocks is worse than a slow one. What one run costs: 213 candle downloads on the
first scan (~75 s at Angel's 3 requests/second), ~5 batched quote calls and one
option-greek call per stock (~75 s) — roughly 2.5 minutes cold, 1.5 minutes warm.
Any tickers that cannot be resolved at all ("3 resolve nahi hue: XYZ…") are named
in the status banner, so "210 of 213" is never a silent surprise.

Settings → *F&O — 3-Month Study* holds the optional **Telegram** credentials.

---

## Design & branding

**NiveshDesk** — निवेश (investment) + *desk*. Full spec:
[`design/BRAND.md`](design/BRAND.md); visual mock:
[`preview/design_preview.html`](preview/design_preview.html).

### The logo

Three ascending bars (the screener's candles) crossed by a gold trend line that
breaks out to the top-right and ends in a dot — *the latest price*. It is drawn
twice from **one geometry**:

| | file | used for |
|---|---|---|
| Flutter `CustomPainter` | `lib/core/widgets/brand.dart` | app bar, splash, login, watermark, About |
| Pillow generator | `tool/generate_icon.py` → `assets/icon/*.png` → `dart run flutter_launcher_icons` | launcher, Android 13+ themed (monochrome) icon |

`test/core/brand_test.dart` asserts the shared invariants (bars strictly
ascending, everything inside the plate, the trend line ending above where it
started), so the icon and the in-app mark cannot silently drift apart.

### Design tokens (all in `lib/core/theme/app_theme.dart`)

* **Colour** — brand green `#0B6B4F` (dark-mode primary `#12A67C`), gold
  `#E8B242` reserved for accents, `MarketColors` for gain/loss/stale semantics
  (never used as decoration), `GroupPalette` (8) for trade-group identity.
* **Type** — one tuned `TextTheme`: tight-tracked headings, 13.5 pt body,
  small tracked labels for metadata. Money always goes through `Fmt` (Indian
  grouping).
* **Spacing / radii** — `AppSpacing` 2…32, `AppRadius` 10/14/18/24/pill.
* **Components** — app bar, cards, inputs, buttons, chips, segmented controls,
  nav bar, sheets, dialogs, snackbars, switches, sliders all styled once, so a
  screen never invents its own look.

### Motion (the "lite" bit)

`AppMotion` + `lib/core/widgets/motion.dart`, tested in
`test/core/motion_test.dart`:

| effect | where |
|---|---|
| splash: the mark draws itself (bars → line → dot, 1150 ms), wordmark fades up | app start, once |
| `NumberTicker` — figures roll instead of snapping | dashboard tiles, hero value |
| `FadeSlideIn` — 260 ms fade + 14 px lift, 45 ms stagger per item (capped) | IPO cards, cross signals, holdings, orders, trade book |
| `SwapFade` + tab fade/8 px lift | Holdings ↔ Orders ↔ Trade book, bottom-nav switches |
| fade-through page transitions | every pushed route |
| `ShimmerCard` / `ShimmerBox` skeletons | first load of the paper book and the cross tab |
| `PulseDot` | **only** where something is genuinely live (the feed chip) |
| `PressScale` (0.985) | cards that open something |

House rules: nothing longer than ~1.2 s, no bounce, loops reserved for
information (liveness/loading) rather than decoration, and every animation has a
static end state — nothing depends on motion to be understood.

---

## Architecture

```
lib/
├── main.dart                      entry point
├── app.dart                       object graph, providers, splash, login gate
├── core/
│   ├── theme/app_theme.dart       Material 3 light/dark + MarketColors extension
│   └── utils/
│       ├── markets.dart           IST clock, exchange enum, trading calendar, session windows
│       ├── formatters.dart        ₹ lakh/crore formatting, % , dates
│       ├── totp.dart              RFC 6238 TOTP generator (no plugin)
│       ├── csv_io.dart            RFC 4180 CSV reader/writer
│       ├── json_array_scanner.dart streaming parser for the 50 MB scrip master
│       └── link_opener.dart       TradingView hand-off
├── data/
│   ├── local/                     app_database.dart (SQLite schema) + models/ + dao/
│   └── remote/                    api_client.dart (headers, rate limits, retries), dto/
├── services/
│   ├── secure_store.dart          keystore-backed credentials & JWT
│   ├── auth_service.dart          loginByPassword, TOTP, token refresh, logout
│   ├── token_resolver.dart        symbol ➜ instrument token (exact/cross-exchange/name)
│   ├── scrip_master_service.dart  daily master download, streamed & batched
│   ├── market_data_service.dart   LTP batches, single LTP, daily candles (CandleSource)
│   ├── candle_source.dart         tiny interface: "give me daily bars" (fakes in tests)
│   ├── cross_scan_service.dart    Feature 2 scan: cache-first, sequential, resumable
│   └── scan_notifier.dart         optional webhook ping when hits are found
└── features/
    ├── auth/login_screen.dart
    ├── shell/home_shell.dart      4-tab bottom navigation
    ├── ipo_screener/              engine + provider + screen + widgets
    ├── golden_cross/              cross_engine (pure maths) + provider + screen
    │                              + universe_catalog + widgets (card, universe sheet)
    ├── paper_trading/             Phase 3 (roadmap screen)
    ├── reports/                   Phase 3 (roadmap screen)
    └── settings/                  provider + settings screen
```

**Design rules followed throughout**

* **Pure logic is separated from Flutter** (`engine`, `totp`, `csv_io`, `markets`,
  `json_array_scanner`, `token_resolver`) so it can be unit-tested without a device.
* **One HTTP path** (`ApiClient`) — headers, JSON envelope, rate limiting
  (350 ms spacing ≈ 2.8 req/s, under SmartAPI's 3/s ceiling), exponential backoff
  on *"Access denied because of exceeding access rate"* (which SmartAPI returns
  inside an HTTP 200 body).
* **Cache-first UI** — prices and scanner output are always written to SQLite
  before being displayed, and anything not live is labelled `cached`.
* **Streaming, not slurping** — the 50 MB instrument master never lands in memory
  as one JSON tree.

---

## Data files (and how trustworthy they are)

### `assets/data/ipos.csv` (seed database)

Columns: `Symbol, Company Name, Exchange, Listing Date, Listing High, Listing Low, Sector, Notes`
(`Listing Date` accepts `dd-MMM-yyyy` / `yyyy-MM-dd` / `dd/MM/yyyy`).

⚠️ **Read this before trading off it:** the **symbols and listing dates are real**
and were cross-checked against Angel One's live instrument master, but
**listing-day high/low are compiled from public listing-day reports** — rows that
could not be confirmed from an exchange source say `H/L approximate - verify` in
their Notes column, and the app shows Notes on the card detail sheet.

Verify or refresh your own numbers with:

* **NSE** — *Historical data* / bhavcopy for the listing date
  (`https://www.nseindia.com/reports-indices-historical-volume`), or
  **BSE** *Historical data* for the listing date;
* **Chittorgarh / Moneycontrol IPO pages** — they publish an explicit
  *"Listing Day Trading Information"* table (open / high / low / last trade), which
  is exactly the pair of numbers this screener needs.

Then import the corrected file from **IPO Screener → storage icon → Import CSV**.
Symbols that were renamed since listing already carry the **current** ticker
(`ETERNAL` for Zomato, `AWL` for Adani Wilmar) because the screener resolves live
tokens — the Notes column records the old name.

### `assets/data/scrip_master.json` (starter token map)

122 real instruments (61 NSE + 61 BSE) extracted from Angel One's published
`OpenAPIScripMaster.json`, covering every symbol in the seed CSV — so the screener
resolves tokens on first launch, offline. The full daily master (~100k rows) is
downloaded automatically after the first login, streamed and stored in SQLite
(`scrip_master_updated_at` / `scrip_master_rows` metadata in `scrip_meta`).

---

## SmartAPI reference used by this app

| Purpose | Endpoint | Notes |
|---|---|---|
| Login (2FA) | `POST /rest/auth/angelbroking/user/v1/loginByPassword` | body `{clientcode, password, totp}` |
| Session refresh | `POST /rest/auth/angelbroking/jwt/v1/generateTokens` | body `{refreshToken}` |
| Profile | `POST /rest/secure/angelbroking/user/v1/getProfile` | cosmetic header info |
| LTP (batched) | `POST /rest/secure/angelbroking/market/v1/quote/` | `{"mode":"LTP","exchangeTokens":{"NSE":["3045"]}}`, 50 tokens/call |
| Single LTP | `POST /rest/secure/angelbroking/order/v1/getLtpData` | paper-trading order form |
| Daily candles | `POST /rest/secure/angelbroking/historical/v1/getCandleData` | `interval: ONE_DAY`, ≤ 2000 days/request |
| Live stream | `wss://smartapisocket.angelone.in/smart-stream` | binary little-endian packets; used by Phase 3 |
| Instrument master | `https://margincalculator.angelbroking.com/OpenAPI_File/files/OpenAPIScripMaster.json` | ~50 MB, published daily |

Every REST call carries: `Content-Type`, `Accept`, `X-UserType: USER`,
`X-SourceID: WEB`, `X-ClientLocalIP`, `X-ClientPublicIP`, `X-MACAddress`,
`X-PrivateKey`, and `Authorization: Bearer <jwtToken>` (except login).

**Documented rate limits**: 3 req/s · 150–180 req/min · 5000 req/h for
`getCandleData`; higher caps on quotes. The app spaces requests and retries with
backoff; the Phase 2 scanner additionally pages sequentially by design.

---

## Testing

```bash
flutter test                      # everything
flutter test test/core test/data  # fast pure-Dart + SQL cores
```

387 tests, no device required:

| Area | File | What it proves |
|---|---|---|
| TOTP | `test/core/totp_test.dart` | **RFC 6238 Appendix-B vectors** (`T=59 s → 287082` …), window roll-over, base32 edge cases |
| CSV | `test/core/csv_io_test.dart` | quoted commas, embedded quotes/newlines, CRLF/BOM, round-trip |
| Calendar/IST | `test/core/markets_test.dart` | holidays, latest-trading-day walk-back, 09:15–15:30 window, 18:00 job window |
| Formatting | `test/core/formatters_test.dart` | Indian digit grouping (`₹1,00,000.00`), signed %, date parsing |
| Streaming parser | `test/core/json_array_scanner_test.dart` | objects split across chunks, braces inside strings, unicode escapes |
| Screener engine | `test/features/ipo_screener/engine_test.dart` | **the ±3 % rule**, inclusive boundary, both-bands overlap, level labels, filters, sorts, skips, staleness |
| Token resolution | `test/services/token_resolver_test.dart` | `-EQ`/exchange-prefix handling, cross-exchange, ambiguous names, master filtering |
| SQLite DAOs | `test/data/dao_test.dart` | real schema + queries (in-memory SQLite), idempotent seeding, user edits survive re-seed, caches |
| **Trade groups** | `test/data/trade_group_dao_test.dart` | group CRUD + duplicate/reserved names, archive, delete-with-reassign, **group-wise realised P&L**, win rate/profit factor, **IST month bucketing**, v1→v2 migration keeps existing trades |
| **Cross engine** | `test/features/golden_cross/cross_engine_test.dart` | SMA maths, **golden and death cross detection**, the `prev ≤ / now >` rule, "no signal without 205 bars", closest-cross-wins, as-of date filtering, sparkline window, cache round-trip |
| **Cross scanner** | `test/services/cross_scan_service_test.dart` | cache-first fetching (second scan makes **zero** network calls), skip reasons, cancellation, progress/ETA, per-session persistence, candle-cache upsert/range/prune |
| **Cross tab state** | `test/features/golden_cross/cross_screener_provider_test.dart` | bootstrap from cache, universe resolution (Nifty/IPO/NSE/all), empty-universe guard, filters/search, death-cross gating, clearing the cache keeps the candles |
| **Cross card** | `test/features/golden_cross/cross_signal_card_test.dart` | symbol/company/SMA/gap/cross-date rendering, GOLDEN vs DEATH labelling, chart button, dark mode |
| **Charges** | `test/features/paper_trading/charges_test.dart` | delivery vs intraday brokerage/STT/GST/stamp/DP, paise rounding, cash-flow signs, break-even maths |
| **Order engine** | `test/features/paper_trading/order_engine_test.dart` | market/limit fill prices, tick rounding, SL/target resolution, partial exits, validation (cash, quantity caps, long-only), max affordable quantity |
| **Portfolio maths** | `test/features/paper_trading/portfolio_math_test.dart` | invested/market value, realised vs unrealised, win rate, profit factor, filters |
| **Paper trading** | `test/features/paper_trading/paper_trading_provider_test.dart` | the whole orchestration on a real in-memory schema with a fake socket: resting LIMIT → tick → fill, tick through a stop → auto-exit with realised P&L, partial exits, group tagging/re-tagging, force-fill, cancel, reset |
| **Reports** | `test/features/paper_trading/report_math_test.dart` | monthly buckets incl. empty months, per-group roll-up with live open exposure, profit factor, best/worst month, chart group cap |
| **Feed decoding** | `test/services/feed_decoder_test.dart` | the 51/123/379-byte little-endian SmartAPI frames, control frames, malformed input |
| **Feed lifecycle** | `test/services/live_feed_service_test.dart` | headers (raw JWT), subscribe/unsubscribe payloads, subscription diffing, token routing, reconnect + re-subscribe |
| **Brand / logo** | `test/core/brand_test.dart` | the mark paints in light + dark, the entrance animation completes, the wordmark is two-tone, the geometry invariants shared with the launcher icon, accessibility label |
| **Motion kit** | `test/core/motion_test.dart` | NumberTicker counts up and re-rolls to the exact value, FadeSlideIn stagger + cap, SwapFade, PressScale passes taps through, SmoothProgressBar clamps, the loops never throw |
| Seed assets | `test/data/seed_assets_test.dart` | the shipped CSVs/JSON parse, validate, and every seeded IPO resolves to a **real token** |

The DAO tests use `sqflite_common_ffi`, so they run on the Dart VM as well as on a
device — the SQL is genuinely executed, not mocked.

---

## Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `The argument type 'CardTheme' can't be assigned to the parameter type 'CardThemeData?'` | Flutter normalised component themes. `app_theme.dart` targets **3.35+**; on an older SDK rename `CardThemeData` → `CardTheme`, `AppBarThemeData` → `AppBarTheme`, `InputDecorationThemeData` → `InputDecorationTheme`. |
| `Invalid TOTP` / `AB1051` | The phone clock drifted. Sync the clock, or switch the login screen to the **6-digit** mode and type the code from your authenticator. |
| `Access denied because of exceeding access rate` | SmartAPI throttling (it arrives inside an HTTP 200). The app already backs off and retries; wait a minute for the rest of the batch. |
| Most rows say *"Instrument token not found"* | You are still on the bundled 122-instrument starter map. Tap *"Download instrument master & re-screen"* in the footer sheet, or Settings → *Download latest*. |
| Prices look stale | Open Settings — the session card shows the token lifetime. Log in again if it expired (05:00 IST daily). Cached cards are always labelled `cached`. |
| Chart button does nothing | The Android `<queries>` block above is missing, or no browser/TradingView app is installed. |
| `flutter_secure_storage` build errors | Raise Android `minSdk` to 23+. |

---

## Roadmap

| Phase | Scope | Status |
|---|---|---|
| **1** | Login/2FA/session, scrip-master sync, IPO screener, DB + cache, dark mode, tests | ✅ complete |
| **2** | Golden/Death Cross: daily candles → 50/200 SMA → crossover, cached per trading day, sequential & resumable scan, 18:00 IST in-app daily job, optional webhook, TradingView links | ✅ complete |
| **3** | Paper trading: virtual capital, market/limit orders, charges (brokerage/STT/exchange/GST/stamp/DP), SL monitoring on the WebSocket feed, holdings with live unrealised P&L, trade book, monthly P&L bar chart (fl_chart), Reports tab, **trade groups (strategy/basket tags) with group-wise P&L** | ✅ complete |

| **4** | Rebrand to **NiveshDesk** (own logo + launcher icons drawn from one geometry), full design pass (tokens, type scale, components) and a "lite" motion kit | ✅ complete |
| **5** | RSI scanner tab: daily-candle Wilder RSI(14), 67/33 thresholds (editable), F&O / Nifty 50 / IPO / all-NSE universes, shared candle cache | ✅ complete |
| **6** | **F&O module** (app-bar hub): tool #1 **3-Month Study** — the **whole F&O universe, 213 stocks, no cap**, 63-bar window, ATR(14), ATR-days from the 3M high/low, monthly moves, trend classification, ATM option pricing + IV (broker or Black-Scholes), IV rank, 0–12 score, 🎯 Best Buy, "agar kal jodi buy ki hoti", Excel/CSV/WhatsApp/Telegram export, paper-trade hand-off · tool #2 **Results Calendar** · tool #3 **AI Suggestion** — local rule engine, Top-N ranked ideas with direction / expected move / rationale / option jodi, user-tunable filters | ✅ complete |

| **7** | **F&O module, tool #4 — "3 Month Study with Advance Filter"** (its own page, F&O hub me naya card): wahi study **sudhaare hue niyam** ke saath (edge ke bina 🎯 nahi, doori ek hi paimaane se, adhura mahina alag, expiry paas to 🎯 nahi), **har row par dono score** (naya + purana) aur **turnover / DTE**, filter (liquidity ≥ ₹10 cr, aaj expiry chhod, min-score 0–12, 10 sort), **"kaun chhoota" har chhooti hui row ke saath**, aur doosra tab **"Score ka hisab"** — purane candles par score ka backtest (0–4/4–7/7–9/9–12 band, naye aur purane niyam dono, koi guarantee nahi) · **purana 3-Month Study page bilkul waise hi** | ✅ complete |

Feature 3 was built against [`docs/FEATURE-3-SPEC.md`](docs/FEATURE-3-SPEC.md):
schema **v3** (`trades`, `positions`, `paper_orders`, `trade_groups`), the live
WebSocket 2.0 feed, the charge engine, the paper-trading provider + screens, the
Reports tab, and 100+ new tests.

Every feature so far is paper/simulation only — nothing in this app can place a
real order.

---

## Disclaimer

This app only **reads** market data. It places **no orders** — the paper-trading
module simulates fills locally. Nothing here is investment advice; verify every
price level against your broker before acting on it. Angel One SmartAPI terms and
your own broker agreement apply to the data you fetch with it.
