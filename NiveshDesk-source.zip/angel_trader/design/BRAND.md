# NiveshDesk — brand & design system

> The app is called **NiveshDesk** (निवेश + *desk*). The previous working name,
> "Angel Trader", was dropped: this app *reads* Angel One's SmartAPI but is not an
> Angel One product, and a name that borrows the broker's identity is a problem
> the moment anyone shares a screenshot. Everything visible to a user is
> NiveshDesk; the only remaining "Angel" references are accurate ones (the
> SmartAPI endpoints and the API setup docs).

---

## 1. The mark

Three ascending bars (the screener's candles) crossed by a gold trend line that
breaks out to the top-right and ends in a dot — *the latest price*. It reads at
1024 px on a home screen and at 26 px in the app bar.

There are **two implementations of one geometry**, and they must stay in sync:

| Where | File | Used for |
|---|---|---|
| Flutter `CustomPainter` | `lib/core/widgets/brand.dart` → `BrandGeometry`, `BrandMarkPainter` | app bar, splash, login, empty states, dashboard watermark, About card |
| Python + Pillow | `tool/generate_icon.py` | launcher PNGs → `assets/icon/*.png` → `dart run flutter_launcher_icons` |

Both use the same fractions of the plate's side (`BrandGeometry` ↔ the constants
at the top of `generate_icon.py`): plate radius `0.28`, bar centres
`0.30 / 0.475 / 0.65`, bar heights `0.22 / 0.33 / 0.44`, bar width `0.105`,
baseline `0.775`, trend points `(0.205, 0.655) → (0.375, 0.495) → (0.505, 0.575)
→ (0.775, 0.285)`, stroke `0.058`, tip dot `0.052`.

**Changing the mark:** edit the numbers in *both* places, run
`python3 tool/generate_icon.py`, then `dart run flutter_launcher_icons`.
`test/core/brand_test.dart` asserts the invariants (bars strictly ascending,
everything inside the plate, the trend line ending higher than it starts), so a
bad edit fails the suite instead of shipping a broken icon.

Why draw it instead of shipping PNGs: it stays sharp at every size, follows the
theme (light/dark, monochrome for Android 13+ themed icons) and can animate
itself — which is the splash screen's whole job.

---

## 2. Colour

| Token | Light | Dark | Used for |
|---|---|---|---|
| `Brand.green` | `#0B6B4F` | — | seed, primary, hero gradient |
| `Brand.greenBright` | — | `#12A67C` | primary in dark mode |
| `Brand.greenDeep` | `#074434` | — | plate shading, wordmark on light |
| `Brand.gold` | `#E8B242` | `#E8B242` | accents only: trend line, "LIVE" dot, highlights |
| `MarketColors.gain / loss / flat` | `#15803D` / `#B91C1C` / `#475569` | `#4ADE80` / `#F87171` / `#94A3B8` | every signed P&L number |
| `MarketColors.nearHigh / nearLow / stale` | teal / violet / amber | cyan / lavender / amber | IPO chips, price staleness |
| `GroupPalette` (8) | blue → purple | same in both | trade-group identity tags |

Rules: **gold is never a data colour** (it means "brand/accent"), **green/red are
never decoration** (they only ever mean gain/loss), and group colours never
change with the theme because they are identity, not signal.

## 3. Spacing, radii, type

* `AppSpacing` — 2 / 4 / 8 / 12 / 16 / 24 / 32.
* `AppRadius` — 10 (chips, small tiles), 14 (inputs, buttons), 18 (cards), 24
  (sheets, dialogs, hero), pill.
* Type: headings carry negative tracking (`-0.2 … -0.8`), body is 13.5 pt with a
  1.35 line height, labels are 10–12 pt with wide tracking for metadata rows.
  Money is *always* rendered through `Fmt` (Indian digit grouping).

## 4. Motion

One vocabulary, defined in `AppMotion` and implemented in
`lib/core/widgets/motion.dart`:

| Effect | Duration | Where |
|---|---|---|
| `NumberTicker` | 520 ms, easeOutCubic | dashboard figures roll when a tick moves them |
| `FadeSlideIn` | 260 ms + 45 ms × index (capped at 8) | list/card entrances |
| `SwapFade` | 260 ms | Holdings ↔ Orders ↔ Trade book, filter changes |
| tab switch | 260 ms fade + 8 px lift | bottom navigation |
| page push | Flutter's fade-through transition | every pushed route |
| `PressScale` | 150 ms, scale 0.985 | cards that open something |
| splash draw-in | 1150 ms (bars → line → dot) | app start, once |
| `PulseDot` | 1400 ms loop | **only** where something is genuinely live |
| `ShimmerBox` / `ShimmerCard` | 1500 ms loop | first-load skeletons |

House rules: loops are reserved for information (liveness, loading) — never
decoration; nothing animates for more than ~1.2 s; nothing bounces; loading
states are skeletons shaped like the content that is coming, not spinners.

## 5. Accessibility & platform notes

* The mark exposes `Semantics(label: 'NiveshDesk logo')`.
* Contrast: every data colour is checked against its surface in both themes
  (`MarketColors` light/dark pairs are tuned for ≥ 4.5:1 on cards).
* Motion is short and eased rather than springy, which also keeps it comfortable
  for users who are sensitive to movement; nothing relies on animation to convey
  meaning (every animation has a static end state).
* Android 13+ themed icons are supported (`app_icon_monochrome.png`).

## 6. Renaming checklist (done for 1.3.0)

- [x] `Brand` constants in `lib/core/theme/app_theme.dart`
- [x] app bar, splash, login, settings/About (`BrandLogo`, `BrandWordmark`)
- [x] `MaterialApp.title`
- [x] `android:label="NiveshDesk"` in `AndroidManifest.xml`
- [x] `flutter_launcher_icons` config (Android; iOS is `false` — there is no iOS
      project in this repo yet)
- [x] launcher assets regenerated from the new mark
- [x] README / SETUP updated

If you ever add the iOS platform (`flutter create --platforms=ios .`), set
`ios: true` in the `flutter_launcher_icons` block and update
`ios/Runner/Info.plist` (`CFBundleDisplayName = NiveshDesk`).
