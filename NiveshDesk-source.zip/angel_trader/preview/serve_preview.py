#!/usr/bin/env python3
"""Serve the repository's self-contained HTML previews on port 40217."""

import os
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

PREVIEW_DIR = Path(__file__).resolve().parent
PORT = int(os.environ.get("PORT", "40217"))


class PreviewHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(PREVIEW_DIR), **kwargs)

    def do_GET(self):
        if self.path in {"/", "/index.html"}:
            self.path = "/design_preview.html"
        super().do_GET()


if __name__ == "__main__":
    server = ThreadingHTTPServer(("0.0.0.0", PORT), PreviewHandler)
    print(
        f"Serving NiveshDesk design preview on http://0.0.0.0:{PORT}/",
        flush=True,
    )
    server.serve_forever()
